<?php
//========================================================================================================================
function ordonnerPagesDeGroupes($a,$b){
 if($a['o']==$b['o']) return 0;
 if($a['o']<=$b['o']) return -1;
 return 1;
}
//========================================================================================================================
function updateGrpPgsFiles1(){
 require_once($GLOBALS['glob_incPath1'].'/sys/__pageList.php');
 $req6='
  SELECT
   T0.`fld_id_groups` 
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0 
  ORDER BY `fld_id_groups`
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $listePages1=array(
    'index.php' => array (
      'm' => '0', // menu
      'o' => '0', // order
      'aj' => '0',
      'id' => '1',
    ),
    'login.php' => array (
      'm' => '0',
      'o' => '3',
      'aj' => '0',
      'id' => '2',
    ),
    'logout.php' => array (
      'm' => '0',
      'o' => '4',
      'aj' => '0',
      'id' => '3',
    ),
   );
   $req7='
    SELECT T0.`fld_group_id_grpspgs`     , T0.`fld_page_id_grpspgs` , T0.`fld_is_menu_grpspgs` , T0.`fld_menu_order_grpspgs`  
    FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` T0 
    WHERE T0.`fld_group_id_grpspgs` = '.$mpsr6[0].'
   ';
   $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    while($mpsr7=mysqli_fetch_row($result7)){
     $thePage = array();
     foreach($GLOBALS['__pageList'] as $k1 => $v1){
      if($v1['fld_id_pages']==$mpsr7[1]){
       $thePage=$v1;
      }
     }
     if(sizeof($thePage)>0){
      if(isset($listePages1[$thePage['fld_name_pages']])){
       $listePages1[$thePage['fld_name_pages']]['m']=$mpsr7[2];
       $listePages1[$thePage['fld_name_pages']]['o']=$mpsr7[3];
       $listePages1[$thePage['fld_name_pages']]['o']['aj']=$thePage['fld_isajax_pages'];
      }else{
       $listePages1[$thePage['fld_name_pages']]=array(
        'm'  => $mpsr7[2] , // menu
        'o'  => $mpsr7[3] , // order
        'aj' => $thePage['fld_isajax_pages'] ,
        'id' => $mpsr7[1] , // id
       );
      }
     }
    }
    mysqli_free_result($result7);
    if(sizeof($listePages1)>0){
     uasort($listePages1 , 'ordonnerPagesDeGroupes');
    }
    if(!is_dir($GLOBALS['glob_dataPath1'].'/generated/grpspgs')){
     if(!mkdir($GLOBALS['glob_dataPath1'].'/generated/grpspgs',0777,true)){
      debugSql2(array('message' => ' in ' . __FUNCTION__ . ' cannot create directory "'.$GLOBALS['glob_dataPath1'].'/generated/grpspgs"' , 'file' => __FILE__ , 'line' => __LINE__ ));
     }
    }
    if($fd=fopen($GLOBALS['glob_dataPath1'].'/generated/grpspgs/grp_'.$mpsr6[0].'.php' , 'w')){
     fwrite($fd,'<?'.'php'.CRLF.'$GLOBALS[\'glob_grpspgs\']='.var_export($listePages1,true).';');
     fclose($fd);
    }else{
      debugSql2(array('message' => ' in ' . __FUNCTION__ . ' cannot create file "'.$GLOBALS['glob_dataPath1'].'/generated/grp_'.$mpsr6[0].'"' , 'file' => __FILE__ , 'line' => __LINE__ ));     
    }
   }else{
    debugSql2(array('sqler' => ' in getGroup1 ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req7 , 'file' => __FILE__ , 'line' => __LINE__ ));
   }
  }
  mysqli_free_result($result6);
 }else{
  debugSql2(array('sqler' => ' in ' . __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6 , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
}
//============================================================================================================================================
function updatePagesOfGroups(){
 $updated=false;
 require_once($GLOBALS['glob_incPath1'].'/sys/__pageList.php');
 $listeDesPages1=array();
 foreach($GLOBALS['__pageList'] as $k1 => $v1){
  $listeDesPages1['fld_id_pages_'.$v1['fld_id_pages']]=array(
   'fld_id_pages'         => $v1['fld_id_pages'],
   'fld_name_pages'       => $v1['fld_name_pages'],
   'fld_menu_pages'     => $v1['fld_menu_pages'],
   'fld_isajax_pages'     => $v1['fld_isajax_pages'],
   'fld_localadmin_pages' => $v1['fld_localadmin_pages'],
   'fld_isuser_pages'     => $v1['fld_isuser_pages'],
   'fld_isaction_pages'   => $v1['fld_isaction_pages'],
   'isset'                => false,
  );
 }
 $req7='
  SELECT  SQL_CALC_FOUND_ROWS
    T0.`fld_page_id_grpspgs` , T0.`fld_group_id_grpspgs`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` T0 
  WHERE T0.fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].'
 ' ;
 $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr7=mysqli_fetch_row($result7)){
   $listeDesPages1['fld_id_pages_'.$mpsr7[0]]['isset'] = true;
  }
  mysqli_free_result($result7);
  foreach( $listeDesPages1 as $k1 => $v1){
   if($v1['isset']===false && isset($_POST['page'][$v1['fld_id_pages']])){
    $req8='INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET `fld_group_id_grpspgs` = '.$_POST['fld_group_id_grpspgs'].' , `fld_page_id_grpspgs` = '.$v1['fld_id_pages'].'' ;
    $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
     $updated=true;
    }else{
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req='.$req7.' ';
    }
   }else if($v1['isset']==true && !isset($_POST['page'][$v1['fld_id_pages']])){
    $req8='DELETE FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` WHERE `fld_group_id_grpspgs` = '.$_POST['fld_group_id_grpspgs'].' AND `fld_page_id_grpspgs` = '.$v1['fld_id_pages'].'' ;
    $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
     $updated=true;
    }else{
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req='.$req8.' ';
    }
   }
  }
  
  
 }else{
  $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req7));
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req='.$req7.' ';
 }
 if(true===$updated){
  $_SESSION[PGMK][NAV][BNF]['message'][]=__LINE__ . ' ' . txt2('Des mises à jour ont été faites_180_64');
 }else{
  $_SESSION[PGMK][NAV][BNF]['message'][]=__LINE__ . ' ' . txt2('Aucune mise à jour a été faite_182_64');
 }
 return $updated;
}
//============================================================================================================================================
function updateMenus(){
 $updated=false;
 $listeDesPages=array();
 
 $req7='
  SELECT  T0.`fld_page_id_grpspgs` , T0.`fld_is_menu_grpspgs`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` T0 
  WHERE T0.fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].'
 ' ;
 $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr7=mysqli_fetch_row($result7)){
//   echo __FILE__ . ' ' . __LINE__ . ' $mpsr7[1] = <pre>' . var_export( $mpsr7[1] , true ) . '</pre>' ;
   $req8='';
   if($mpsr7[1]=='1' && !isset($_POST['menu'][$mpsr7[0]])){
    // delete
    $req8='
     UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET 
     `fld_is_menu_grpspgs` = \'0\' ,
     `fld_tsupd_grpspgs` = \''.$GLOBALS['glob_setdate'].'\' 
     WHERE fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].' AND `fld_page_id_grpspgs` = '.$mpsr7[0].'' ;
   }else if($mpsr7[1]=='0' && isset($_POST['menu'][$mpsr7[0]])){
    // add
    $req8='
     UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET 
     `fld_is_menu_grpspgs` = \'1\' ,
     `fld_tsupd_grpspgs`   = \''.$GLOBALS['glob_setdate'].'\' 
     WHERE fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].' AND `fld_page_id_grpspgs` = '.$mpsr7[0].'' ;
   }
   if($req8!=''){
    $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req8='.$req8.' ';
    }else{
     if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])!=0){
      $updated=true;
     }
    }
   }
  }
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $updated , true ) . '</pre>' ; exit(0);
  mysqli_free_result($result7);
 }
 
 $listeDesMenusDeCeGroupe=array();
 $req7='
  SELECT  T0.`fld_page_id_grpspgs` , T0.`fld_is_menu_grpspgs`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` T0 
  WHERE T0.fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].'
    AND T0.`fld_is_menu_grpspgs` = \'1\'
 ';
 $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr7=mysqli_fetch_row($result7)){
   $listeDesMenusDeCeGroupe[]=$mpsr7[0];
  }
  mysqli_free_result($result7);
 }  
 
 foreach($_POST['menu'] as $k1 => $v1){
  $trouve=false;
  foreach($listeDesMenusDeCeGroupe as $k2 => $v2){
   if($v1 == $v2){
    $trouve=true;
   }
  }
  if(false===$trouve){
   $req8='
    UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET 
    `fld_is_menu_grpspgs` = \'1\' ,
    `fld_tsupd_grpspgs`   = \''.$GLOBALS['glob_setdate'].'\' 
    WHERE fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].' 
      AND `fld_page_id_grpspgs` = '.$v1.'
   ' ;
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . $req8 . '</pre>' ; exit(0);
   $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $req8 , true ) . '</pre>' ; exit(0);
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req8='.$req8.' ';
   }else{
    
    if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])==0){
//     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
     $req8='
      INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET 
         `fld_is_menu_grpspgs` = \'1\' 
       , `fld_group_id_grpspgs` = '.$_POST['fld_group_id_grpspgs'].' 
       , `fld_page_id_grpspgs`  = '.$v1.'
       , `fld_tscrt_grpspgs`   = \''.$GLOBALS['glob_setdate'].'\'
       , `fld_tsupd_grpspgs`   = \''.$GLOBALS['glob_setdate'].'\'
     ' ;
     $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
     if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
      $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req8='.$req8.' ';
     }else{
      $updated=true;
     }
    }
   }
  }
 }
 if($updated==true){
  $_SESSION[PGMK][NAV][BNF]['message'][]=__LINE__ . ' : '.txt2('Des modifications des menus ont été effectuées_106_65');
 }else{
  $_SESSION[PGMK][NAV][BNF]['message'][]=__LINE__ . ' : '.txt2('Aucune modification de menu effectuée_108_65');     
 }
 return $updated;
}
