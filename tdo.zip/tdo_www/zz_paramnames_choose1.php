<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
checkGroupPages();

if(isset($_GET['idchoose'])){
 $_SESSION[PGMK]['choose']['valueBack']=$_GET['idchoose'];
 header('Location: '.$_SESSION[PGMK]['choose']['urlBack']); 
 exit();
}

if(!isset($_SESSION[PGMK]['choose']['urlBack'])){
 header('Location: index.php?message='.urlencode(txtsys1('the_navigation_has_been_lost')));
 exit();
}
openDb1();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_key_parnams
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_label_parnams
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_comment_parnams
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_parnams
if($xsrch_id!=''){
 if(!is_numeric($xsrch_id)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_38_92') . ' : ' . txt2('fld_id_parnams_38_152');
 }
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; } // fld_key_parnams
else if($xsrch_1!=''){ $autofocus='xsrch_1'; } // fld_label_parnams
else if($xsrch_2!=''){ $autofocus='xsrch_2'; } // fld_comment_parnams
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array());
$o1.='<h1>'.txt2('page_title_list_50_18');
$o1.=' <a class="buttonBack" href="'.$_SESSION[PGMK]['choose']['urlBack'].'">Retour</a>'.CRLF;
$o1.='</h1>';

$o1.=' <form method="get" class="yyfilterForm">'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_key_parnams_57_39').'</label>'.CRLF; // fld_key_parnams
$o1.='    <input '.($xsrch_0!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_0"    id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="32" '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_1">'.txt2('fld_label_parnams_64_39').'</label>'.CRLF; // fld_label_parnams
$o1.='    <input '.($xsrch_1!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_1"    id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="32" '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_2">'.txt2('fld_comment_parnams_71_39').'</label>'.CRLF; // fld_comment_parnams
$o1.='    <input '.($xsrch_2!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_2"    id="xsrch_2"   value="'.enti1($xsrch_2).'"  size="8" maxlength="32" '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


/*
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_3">'.txt2('fld_json_parnams_78_39').'</label>'.CRLF; // fld_json_parnams
$o1.='    <input '.($xsrch_3!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_3"    id="xsrch_3"   value="'.enti1($xsrch_3).'"  size="8" maxlength="32" '.($autofocus=='xsrch_3'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;
*/

/*
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_4">'.txt2('fld_order_parnams_85_39').'</label>'.CRLF; // fld_order_parnams
$o1.='    <input '.($xsrch_4!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_4"    id="xsrch_4"   value="'.enti1($xsrch_4).'"  size="8" maxlength="32" '.($autofocus=='xsrch_4'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;
*/

/*
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_5">'.txt2('fld_isuser_parnams_92_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_5!=''?'class="yybackgroundYellow"':'').' name="xsrch_5"  id="xsrch_5" '.($autofocus=='xsrch_5'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" />'.CRLF;
$o1.='     <option value="" '.($xsrch_5==''?'  selected="selected" ':'').'> </option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_5){
  $o1.='     <option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='     <option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;
*/


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_parnams_38_152').'</label>'.CRLF; // fld_id_parnams
$o1.='    <input '.($xsrch_id!=''?'class="yybackgroundYellow"':'').'  type="text" name="xsrch_id" id="xsrch_id" value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">🔎</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
// todo adjust the request
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_parnams`      ,T0.`fld_key_parnams`     ,T0.`fld_label_parnams`   ,T0.`fld_comment_parnams` ,T0.`fld_json_parnams`    ,
   T0.`fld_order_parnams`   ,T0.`fld_isuser_parnams`  
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramnames` T0 ) 
 WHERE 1=1 
';
if($xsrch_0!='' ){
 $req6.='
  AND T0.`fld_key_parnams` LIKE \'%'.addslashes1($xsrch_0).'%\'
 '; 
}
if($xsrch_1!='' ){
 $req6.='
  AND T0.`fld_label_parnams` LIKE \'%'.addslashes1($xsrch_1).'%\'
 '; 
}
if($xsrch_2!='' ){
 $req6.='
  AND T0.`fld_comment_parnams` LIKE \'%'.addslashes1($xsrch_2).'%\'
 '; 
}
/*
if($xsrch_3!='' ){
 $req6.='
  AND T0.`fld_json_parnams` LIKE \'%'.addslashes1($xsrch_3).'%\'
 '; 
}
*/
/*
if($xsrch_4!='' ){
 $req6.='
  AND T0.`fld_order_parnams` LIKE \'%'.addslashes1($xsrch_4).'%\'
 '; 
}
*/
/*
if($xsrch_5!='' && is_numeric($xsrch_5)){
 $req6.='
  AND T0.`fld_isuser_parnams` = '.$xsrch_5.'
 '; 
}
*/
if($xsrch_id!='' && is_numeric($xsrch_id)){
 $req6.='
  AND T0.`fld_id_parnams` = '.$xsrch_id.'
 '; 
}
// todo adjust the order
$req6.='
 ORDER BY T0.`fld_id_parnams` DESC 
'; 
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 $reqCount6='SELECT FOUND_ROWS();';
 $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $mpsrcount6=mysqli_fetch_row($rescount6);
  $__count=$mpsrcount6[0];
 }
 $lsttbl='';
 if($__count==0){
  $lst.='<p>'.CRLF;
  $lst.=''.txt2('no_record_founded_184_17').''.CRLF;
  $lst.='</p>'.CRLF;
  $o1.=''.$lst.''.CRLF;  
 }else{
  $consUrlRedir=''.
                '&xsrch_0='.rawurlencode($xsrch_0). // fld_key_parnams 
                '&xsrch_1='.rawurlencode($xsrch_1). // fld_label_parnams 
                '&xsrch_2='.rawurlencode($xsrch_2). // fld_comment_parnams 
//                '&xsrch_3='.rawurlencode($xsrch_3). // fld_json_parnams 
//                '&xsrch_4='.rawurlencode($xsrch_4). // fld_order_parnams 
//                '&xsrch_5='.rawurlencode($xsrch_5). // fld_isuser_parnams 
                '&xsrch_id='.rawurlencode($xsrch_id).
                '';
  $ri=' <span class="yybtn yyunset">»</span>';
  if($__start+$__nbMax<$__count){
   $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">»</a>';
  }
  $le=' <span class="yybtn yyunset">«</span>';
  if($__xpage>0){
   $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">«</a>';
  }
  $o1.=getCss1(890); // todo adjust size
  
  $lsttbl.='<thead><tr>';
  $lsttbl.='<th style="min-width:85px;">'.txtsys1('column_action').'</th>';
  $lsttbl.='<th>'.txt2('fld_id_parnams_38_152').'</th>';
  $lsttbl.='<th>'.txt2('fld_key_parnams_57_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_label_parnams_64_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_comment_parnams_71_39').'</th>';
  $lsttbl.='</tr></thead><tbody>';
  while($mpsr6=mysqli_fetch_row($result6)){
   
   $lsttbl.='<tr><td class="yyfictif"></td>';
   
   $lsttbl.='<td data-label="'.txtsys1('column_action').'">';
   $lsttbl.='<div>';
   $lsttbl.='<a href="'.BNF.'?idchoose='.$mpsr6[0].'">'.txtsys1('text_for_the_select_button') . '</a>';
   $lsttbl.='</div>';
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_id_parnams_38_152').'" style="text-align:right;">';
   $lsttbl.=''.$mpsr6[0].''; // fld_id_parnams
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_key_parnams_57_39').'">';
   $lsttbl.=''.$mpsr6[1].''; // fld_key_parnams
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_label_parnams_64_39').'">';
   $lsttbl.=''.$mpsr6[2].''; // fld_label_parnams
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_comment_parnams_71_39').'"><pre>';
   $lsttbl.=''.mb_substr($mpsr6[3],0,100,'UTF-8').''; // fld_comment_parnams
   $lsttbl.='</pre></td>';
   
   $lsttbl.='<td class="yyfictif"></td></tr>';
   
  }
  $o1.='<table class="yytableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;
   
  $o1.=' <div>'.CRLF;
  $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_306_99').' )'.CRLF;
  $o1.=' </div>'.CRLF;
   
 }
 mysqli_free_result($result6);
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
}
$o1.='<script type="text/javascript">var globalChooseUrlBack=\''.$_SESSION[PGMK]['choose']['urlBack'].'\';</script>';
$o1.=htmlFoot0(array());
dw1($o1);
