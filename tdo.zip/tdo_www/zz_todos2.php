<?php // € utf8 check with euro sign
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb2();
//========================================================================================================================
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 if(isset($_POST['buttonSort1']) && isset($_POST['sortedTodos']) && $_POST['sortedTodos']!=''){
  $sortedIds=explode(',',$_POST['sortedTodos']);
  $order=0;
  $newTab=array();
  foreach($sortedIds as $k1=>$v1){
   if(is_numeric($v1)){
    $newTab[]=array(
     'id'    => $v1,
     'order' => $order,
    );
    $order++;
   }
  }
  if(count($newTab)>0){
   foreach($newTab as $k1 => $v1){
    $req6='
     UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` SET
       `fld_priority_todos` = '.$v1['order'].'
     WHERE `fld_id_todos`      = '.$v1['id'].' 
       AND `fld_id_user_todos` = '.$_SESSION[PGMK]['login'].' 
    ';
    $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   }
   header('Location: zz_todos1.php?m=1');
   exit();
  }
 }
 header('Location: '.BNF.'');
 exit();
}
//========================================================================================================================
$o1='';
$__count=0;
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('sort_my_todos_title_52_18').'&nbsp;<a href="zz_todos1.php" class="">'.txtsys1('back_to_the_list').'</a>'.'</h1>';
$o1.=displaySessionMessage1(BNF);

$toFooterArray=array();
//====================================================================================================
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_todos`              ,T0.`fld_priority_todos`        ,T0.`fld_id_user_todos`         ,concat( T1.`fld_login_users` ,\' \' ,T1.`fld_firstname_users` ,\' \' , T1.`fld_lastname_users` ) , 1 , 
   1                              ,T0.`fld_title_todos`           ,T0.`fld_comment_todos`         
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` T0
        , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` T1 ) 
 WHERE 1=1 
   AND T0.`fld_id_user_todos`=T1.`fld_id_users`
   AND T0.`fld_priority_todos` <80 
   AND T0.`fld_id_user_todos` = '.$_SESSION[PGMK]['login'].'  
   ORDER BY T0.`fld_priority_todos` ASC
';
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'T0.fld_id_todos'              =>$mpsr6[0],
  'T0.fld_priority_todos'        =>$mpsr6[1],
  'T0.fld_id_user_todos'         =>$mpsr6[2],
  'T1.fld_login_users'           =>$mpsr6[3],
  'T0.fld_title_todos'           =>$mpsr6[6],
  'T0.fld_comment_todos'         =>$mpsr6[7],
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}
$lst='';
$lsttbl='';
if($__count==0){
 $lst.='<p>'.CRLF;
 $lst.=''.txt2('no_record_founded_99_16').''.CRLF;
 $lst.='</p>'.CRLF;
 $o1.=''.$lst.''.CRLF;  
}else{

 $o1.=getCss1(890); // todo adjust size

 $lsttbl.='<ul id="mytodos1" style="list-style:none;padding:0;">';
 foreach($data0 as $k0=>$v0){
  $lsttbl.='<li class="thinBorder" id="'.$v0['T0.fld_id_todos'].'" class="form" style="min-height:40px;padding:5px;margin:5px;">'; // '.$v0['T0.fld_id_todos'].'
  $lsttbl.=$v0['T0.fld_priority_todos'].' '.enti1($v0['T0.fld_title_todos']);
  $lsttbl.='</li>';
 }
 $lsttbl.='</ul>';

 $o1.=''.CRLF.$lsttbl.''.CRLF;
 $o1.='<form method="post">';
 $o1.=' <input type="hidden" id="sortedTodos" name="sortedTodos" />';
 $o1.=' <button type="submit" id="buttonSort1" name="buttonSort1" value="sortTodos" style="display:none;" >'.txt2('record_this_sort_order_117_115').'</button>';
 $o1.='</form>';

 $toFooterArray=array(
  'js' => array(
   array( 
    'jsName'                  => 'sortable1'  , 
    'elementToSort'           => 'mytodos1'   , 
    'sortFunction'            => 'sortMyTodos' , 
    'inputWithSortedElements' => 'sortedTodos' , 
    'buttonSort'              => 'buttonSort1' ,
    'styleOfButton'           => 'inline-block' 
   ),
  ),
 );

}

$o1.=htmlFoot0($toFooterArray);
dw1($o1);
cleanSession1();
