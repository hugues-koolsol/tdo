<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_name_parrules
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_id_param_parrules
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_parrules
if($xsrch_id!=''){
 if(!is_numeric($xsrch_id)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_23_92') . ' : ' . txt2('fld_id_parrules_23_152');
 }
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; } // fld_name_parrules
else if($xsrch_1!=''){ $autofocus='xsrch_1'; } // fld_id_param_parrules
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_list_31_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="filterForm">'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_name_parrules_37_39').'</label>'.CRLF; // fld_name_parrules
$o1.='    <input '.($xsrch_0!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_0" id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_1">'.txt2('fld_label_parnams_43_39').'</label>'.CRLF; // ========== parent of fld_id_param_parrules
$o1.='    <input '.($xsrch_1!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_1" id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_parrules_23_152').'</label>'.CRLF; // fld_id_parrules
$o1.='    <input '.($xsrch_id!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">ðŸ”Ž</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_parrules`       ,T0.`fld_name_parrules`     ,T0.`fld_id_param_parrules` ,T1.`fld_label_parnams` 
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramrules` T0
        , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramnames` T1 ) 
 WHERE 1=1 
   AND T0.`fld_id_param_parrules`=T1.`fld_id_parnams`
';
if($xsrch_0!='' ){
 $req6.='
  AND T0.`fld_name_parrules` LIKE \'%'.addslashes1($xsrch_0).'%\'
 '; 
}
if($xsrch_1!='' ){ // =========== parent field of fld_id_param_parrules
 $req6.='
  AND T1.`fld_label_parnams` LIKE \'%'.addslashes1($xsrch_1).'%\'
 '; 
}
if($xsrch_id!='' && is_numeric($xsrch_id)){
 $req6.='
  AND T0.`fld_id_parrules` = '.$xsrch_id.'
 '; 
}
$req6.='
 ORDER BY T0.`fld_id_parrules` DESC 
'; 
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$__count=0;
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'T0.fld_id_parrules'=>$mpsr6[0], 
  'T0.fld_name_parrules'=>$mpsr6[1], 
  'T0.fld_id_param_parrules'=>$mpsr6[2], 
  'T1.fld_label_parnams'=>$mpsr6[3], 
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}
$lsttbl='';
if($__count==0){
 $lst.='<p>'.CRLF;
 $lst.=''.txt2('no_record_founded_120_16').''.CRLF;
 $lst.='<a href="zz_paramrules_action1.php?a=c">'.txt2('add_a_new_record_121_53').'</a>'.CRLF; // todo adjust 
 $lst.='</p>'.CRLF;
 $o1.=''.$lst.''.CRLF;  
}else{
 $consUrlRedir=''.
               '&xsrch_0='.rawurlencode($xsrch_0). // fld_name_parrules 
               '&xsrch_1='.rawurlencode($xsrch_1). // fld_id_param_parrules 
               '&xsrch_id='.rawurlencode($xsrch_id).
               '';
 $ri=' <span class="btn unset">Â»</span>';
 if($__start+$__nbMax<$__count){
  $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">Â»</a>';
 }
 $le=' <span class="btn unset">Â«</span>';
 if($__xpage>0){
  $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">Â«</a>';
 }

 $o1.='<div>';
 $o1.='<form method="post">';
// $o1.='<button type="submit" name="action1">'.txt0('action1').'</button>';
// $o1.='<button type="submit" name="action2">'.txt0('action2').'</button>';
 $o1.='<a href="zz_paramrules_action1.php?a=c">'.txt2('add_a_new_record_121_53').'</a>'.CRLF; // todo adjust 
 $o1.='Â '.$le.''.CRLF;  
 $o1.='Â '.$ri.''.CRLF;  
 $o1.='</form>';
 $o1.='</div>';

 $o1.=getCss1(890);

 $lsttbl.='<thead><tr>';
 $lsttbl.='<th style="min-width:125px;">'.txtsys1('column_action').'</th>';
 $lsttbl.='<th style="min-width:85px;">'.txt2('fld_id_parrules_23_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_name_parrules_37_39').'</th>';
 $lsttbl.='<th>'.txt2('T1.fld_label_parnams_155_23').'</th>'; // ======== parent field of fld_id_param_parrules
 $lsttbl.='</tr></thead><tbody>';

 foreach($data0 as $k0=>$v0){

  $lsttbl.='<tr>';

  $lsttbl.='<td data-label="'.txtsys1('column_action').'">';
  $lsttbl.='<div class="flex1">';
  $lsttbl.='<a class="txtSiz1 danger" href="zz_paramrules_action1.php?a=d&id='.$v0['T0.fld_id_parrules'].'"  title="'.txtsys1('delete_button').'">✘</a>';//✘ #10008
  $lsttbl.='<a class="txtSiz2"        href="zz_paramrules_action1.php?a=du&id='.$v0['T0.fld_id_parrules'].'" title="'.txtsys1('duplicate_button').'">&#x2398;</a>';// ⎘:x2398 📋:#128203
  $lsttbl.='<a class="txtSiz1 edit"   href="zz_paramrules_action1.php?a=u&id='.$v0['T0.fld_id_parrules'].'"  title="'.txtsys1('edit_button').'">&#9998;</a>';//✎ #9998
  $lsttbl.='</div>';
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_id_parrules_23_152').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_id_parrules'].''; // fld_id_parrules
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_name_parrules_37_39').'">';
  $lsttbl.=''.$v0['T0.fld_name_parrules'].''; // fld_name_parrules
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_label_parnams_43_39').'">'; // ====== parent field of fld_id_param_parrules
   $lsttbl.=''.$v0['T1.fld_label_parnams'].''; // fld_id_param_parrules parent of $mpsr6[2]
  $lsttbl.='</td>';

  $lsttbl.='</tr>';

 }

 $o1.='<table class="tableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;

 $o1.=' <div>'.CRLF;
 $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_189_98').' )'.CRLF;
 $o1.='   Â <a class="" href="zz_paramrules_action1.php?a=c">'.txt2('add_a_new_record_121_53').'</a>'.CRLF; // todo adjust 
 $o1.=' </div>'.CRLF;

}

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();