<?php // € utf8 check with euro sign
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
checkGroupPages();

if(isset($_GET['idchoose'])){
 $_SESSION[PGMK]['choose']['valueBack']=$_GET['idchoose'];
 header('Location: '.$_SESSION[PGMK]['choose']['urlBack']); 
 exit();
}

if(!isset($_SESSION[PGMK]['choose']['urlBack'])){
 header('Location: index.php?message='.urlencode(txtsys1('the_navigation_has_been_lost')));
 exit();
}
openDb1();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
//$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_login_users
//$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_email_users
$xsrch_8=saveSessionSearch1('xsrch_8',BNF);// fld_firstname_users
$xsrch_9=saveSessionSearch1('xsrch_9',BNF);// fld_lastname_users
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_users
$xsrch_sort=saveSessionSearch1('xsrch_sort',BNF);// fld_id_users
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if(!$listIdsOk){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_47_92') . ' : ' . txt2('fld_id_users_47_152');
 }
}
$autofocus='xsrch_8';
if($xsrch_8!=''){      $autofocus='xsrch_8'; } // fld_login_users
//else if($xsrch_1!=''){ $autofocus='xsrch_1'; } // fld_email_users
else if($xsrch_8!=''){ $autofocus='xsrch_8'; } // fld_firstname_users
else if($xsrch_9!=''){ $autofocus='xsrch_9'; } // fld_lastname_users
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('select a users_57_18');
$o1.='&nbsp;<a class="buttonBack" href="'.$_SESSION[PGMK]['choose']['urlBack'].'">Retour</a>'.CRLF;
$o1.='</h1>';

$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="yyfilterForm">'.CRLF;

/*
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_login_users_66_39').'</label>'.CRLF; // fld_login_users
$o1.='    <input '.($xsrch_0!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_0" id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;
*/

/*
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_1">'.txt2('fld_email_users_72_39').'</label>'.CRLF; // fld_email_users
$o1.='    <input '.($xsrch_1!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_1" id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="128"  '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;
*/


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_8">'.txt2('fld_firstname_users_79_39').'</label>'.CRLF; // fld_firstname_users
$o1.='    <input '.($xsrch_8!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_8" id="xsrch_8"   value="'.enti1($xsrch_8).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_8'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_9">'.txt2('fld_lastname_users_85_39').'</label>'.CRLF; // fld_lastname_users
$o1.='    <input '.($xsrch_9!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_9" id="xsrch_9"   value="'.enti1($xsrch_9).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_9'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_users_47_152').'</label>'.CRLF; // fld_id_users
$o1.='    <input '.($xsrch_id!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_sort">'.txtsys1('sort_order').'</label>'.CRLF; // sort
$o1.='    <select '.($xsrch_sort!=''?'class="yybackgroundYellow"':'').' name="xsrch_sort"  id="xsrch_sort" '.($autofocus=='xsrch_sort'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='     <option value="" '.($xsrch_sort==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
//$o1.='     <option value="'.'T0.fld_login_users'.'"           '.($xsrch_sort=='T0.fld_login_users'           ?' selected="selected" ':'').'>'.txt2('fld_login_users_66_39').'</option>'.CRLF;
//$o1.='     <option value="'.'T0.fld_email_users'.'"           '.($xsrch_sort=='T0.fld_email_users'           ?' selected="selected" ':'').'>'.txt2('fld_email_users_72_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_firstname_users'.'"       '.($xsrch_sort=='T0.fld_firstname_users'       ?' selected="selected" ':'').'>'.txt2('fld_firstname_users_79_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_lastname_users'.'"        '.($xsrch_sort=='T0.fld_lastname_users'        ?' selected="selected" ':'').'>'.txt2('fld_lastname_users_85_39').'</option>'.CRLF;
$o1.='    </select>';
$o1.='   </div>'.CRLF;
$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;// #128270
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
// todo adjust the request
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_users`              ,T0.`fld_login_users`           ,T0.`fld_email_users`           ,T0.`fld_loginisemail_users`    ,T0.`fld_group_id_users`        ,
   T1.`fld_name_groups`           ,T0.`fld_active_users`          ,T0.`fld_translate_users`       ,T0.`fld_firstname_users`       ,T0.`fld_lastname_users`        
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` T0
        , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T1 ) 
 WHERE 1=1 
   AND T0.`fld_group_id_users` = T1.`fld_id_groups`
   AND T0.`fld_active_users`   = \'1\'
   AND T0.`fld_group_id_users` <> 2
';
/*
if($xsrch_0!='' ){
 $req6.='
  AND T0.`fld_login_users` LIKE \'%'.addslashes1($xsrch_0).'%\'
 '; 
}
if($xsrch_1!='' ){
 $req6.='
  AND T0.`fld_email_users` LIKE \'%'.addslashes1($xsrch_1).'%\'
 '; 
}
*/
if($xsrch_8!='' ){
 $req6.='
  AND T0.`fld_firstname_users` LIKE \'%'.addslashes1($xsrch_8).'%\'
 '; 
}
if($xsrch_9!='' ){
 $req6.='
  AND T0.`fld_lastname_users` LIKE \'%'.addslashes1($xsrch_9).'%\'
 '; 
}
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if($listIdsOk){
  $req6.='
   AND T0.`fld_id_users` IN ('.implode(',',$xsrch_ids).') 
  '; 
 }
}
// adjust the order
if($xsrch_sort==''){ $req6.='ORDER BY T0.`fld_id_users` DESC ';}
//if($xsrch_sort=='T0.fld_login_users'){            $req6.=' ORDER BY T0.`fld_login_users` ASC  '; }
//if($xsrch_sort=='T0.fld_email_users'){            $req6.=' ORDER BY T0.`fld_email_users` ASC  '; }
if($xsrch_sort=='T0.fld_firstname_users'){        $req6.=' ORDER BY T0.`fld_firstname_users` ASC  '; }
if($xsrch_sort=='T0.fld_lastname_users'){         $req6.=' ORDER BY T0.`fld_lastname_users` ASC  '; }
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$__count=0;
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'T0.fld_id_users'              =>$mpsr6[0],
  'T0.fld_login_users'           =>$mpsr6[1],
  'T0.fld_email_users'           =>$mpsr6[2],
  'T0.fld_firstname_users'       =>$mpsr6[8],
  'T0.fld_lastname_users'        =>$mpsr6[9],
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}
$lsttbl='';
if($__count==0){
 $lst.='<p>'.CRLF;
 $lst.=''.txt2('no_record_founded_199_16').''.CRLF;
 $lst.='</p>'.CRLF;
 $o1.=''.$lst.''.CRLF;  
}else{
 $consUrlRedir=''.
//               ($xsrch_0!=''?'&amp;xsrch_0='.rawurlencode($xsrch_0):''). // fld_login_users 
//               ($xsrch_1!=''?'&amp;xsrch_1='.rawurlencode($xsrch_1):''). // fld_email_users 
               ($xsrch_8!=''?'&amp;xsrch_8='.rawurlencode($xsrch_8):''). // fld_firstname_users 
               ($xsrch_9!=''?'&amp;xsrch_9='.rawurlencode($xsrch_9):''). // fld_lastname_users 
               ($xsrch_id!=''?'&amp;xsrch_id='.rawurlencode($xsrch_id):'').
               ($xsrch_sort!=''?'&amp;xsrch_sort='.rawurlencode($xsrch_sort):'').
               '';
 $ri=' <span class="yybtn yyunset">&raquo;</span>';
 if($__start+$__nbMax<$__count){
  $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
 }
 $le=' <span class="yybtn yyunset">&laquo;</span>';
 if($__xpage>0){
  $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
 }

 $o1.='<div>';
 $o1.='<form method="post">';
 $o1.='&nbsp;'.$le.''.CRLF;  
 $o1.='&nbsp;'.$ri.''.CRLF;  
 $o1.=' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('records users_224_80').' )'.CRLF;
 $o1.='</form>';
 $o1.='</div>';

 $o1.=getCss1(890); // todo adjust size

 $lsttbl.='<thead><tr>';
 $lsttbl.='<th style="min-width:125px;">'.txtsys1('column_action').'</th>';
 $lsttbl.='<th style="min-width:85px;">'.txt2('fld_id_users_47_152').'</th>';
// $lsttbl.='<th>'.txt2('fld_login_users_66_39').'</th>';
// $lsttbl.='<th>'.txt2('fld_email_users_72_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_firstname_users_79_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_lastname_users_85_39').'</th>';
 $lsttbl.='</tr></thead><tbody>';

 foreach($data0 as $k0=>$v0){

  $lsttbl.='<tr>';

  $lsttbl.='<td data-label="'.txtsys1('column_action').'">';
  $lsttbl.='<div>';
   $lsttbl.='<a href="'.BNF.'?idchoose='.$v0['T0.fld_id_users'].'">'.txtsys1('text_for_the_select_button') . '</a>';
  $lsttbl.='</div>';
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_id_users_47_152').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_id_users'].''; // fld_id_users
  $lsttbl.='</td>';

/*  
  $lsttbl.='<td data-label="'.txt2('fld_login_users_66_39').'">';
  $lsttbl.=''.$v0['T0.fld_login_users'].''; // fld_login_users
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_email_users_72_39').'">';
  $lsttbl.=''.$v0['T0.fld_email_users'].''; // fld_email_users
  $lsttbl.='</td>';
*/


  $lsttbl.='<td data-label="'.txt2('fld_firstname_users_79_39').'">';
  $lsttbl.=''.$v0['T0.fld_firstname_users'].''; // fld_firstname_users
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_lastname_users_85_39').'">';
  $lsttbl.=''.$v0['T0.fld_lastname_users'].''; // fld_lastname_users
  $lsttbl.='</td>';

  $lsttbl.='</tr>';

 }

 $o1.='<table class="yytableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;

 $o1.=' <div>'.CRLF;
 $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('records users_224_80').' )'.CRLF;
 $o1.=' </div>'.CRLF;

}

$o1.='<script type="text/javascript">var globalChooseUrlBack=\''.$_SESSION[PGMK]['choose']['urlBack'].'\';</script>';
$o1.=htmlFoot0(array());
dw1($o1);
