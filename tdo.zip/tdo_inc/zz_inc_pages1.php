<?php
function getPages1($id){
 $nam=array();
 $n['fld_id_pages']         =0;
 $n['fld_name_pages']       ='';
 $n['fld_menu_pages']     =0;
 $n['fld_isajax_pages']     =0;
 $n['fld_isremote_pages']   =0;
 $n['fld_isuser_pages']     =0;
 $n['fld_localadmin_pages'] =0;
 $n['fld_isaction_pages']   =0;
 $n['fld_parent_pages']     =0;
 $n['fld_tsupd_pages']      ='1000-01-01 00:00:00';
 $n['fld_tscrt_pages']      ='1000-01-01 00:00:00';
 $n['fld_cntupd_pages']     =0;
 $sql='
  SELECT 
   T0.`fld_id_pages`         ,T0.`fld_name_pages`       ,T0.`fld_menu_pages`     ,T0.`fld_isajax_pages`     ,T0.`fld_isremote_pages`   ,
   T0.`fld_isuser_pages`     ,T0.`fld_localadmin_pages` ,T0.`fld_isaction_pages`   ,T0.`fld_parent_pages`     ,T0.`fld_tsupd_pages`      ,
   T0.`fld_tscrt_pages`      ,T0.`fld_cntupd_pages`     
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` T0
  WHERE T0.`fld_id_pages` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['fld_id_pages']         = $row[0];
   $n['fld_name_pages']       = $row[1];
   $n['fld_menu_pages']     = $row[2];
   $n['fld_isajax_pages']     = $row[3];
   $n['fld_isremote_pages']   = $row[4];
   $n['fld_isuser_pages']     = $row[5];
   $n['fld_localadmin_pages'] = $row[6];
   $n['fld_isaction_pages']   = $row[7];
   $n['fld_parent_pages']     = $row[8];
   $n['fld_tsupd_pages']      = $row[9];
   $n['fld_tscrt_pages']      = $row[10];
   $n['fld_cntupd_pages']     = $row[11];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
//============================================================================================================================================
function writePageList(){
 $listeDesPages=array();
 $req6='
  SELECT   T0.`fld_id_pages`  , T0.`fld_name_pages`      ,T0.`fld_menu_pages`     ,T0.`fld_isajax_pages`     ,T0.`fld_isremote_pages`   ,
   T0.`fld_isuser_pages`      ,T0.`fld_localadmin_pages` ,T0.`fld_isaction_pages`   ,T1.`fld_name_pages`
  FROM ( `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` T0 )
  LEFT JOIN  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` T1 ON T0.`fld_parent_pages` = T1.`fld_id_pages`
  ORDER BY T0.`fld_id_pages` 
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $listeDesPages[$mpsr6[1]]=array( 
    'fld_id_pages'         => $mpsr6[0],
    'fld_name_pages'       => $mpsr6[1],
    'fld_menu_pages'     => $mpsr6[2],
    'fld_isajax_pages'     => $mpsr6[3],
    'fld_isremote_pages'   => $mpsr6[4],
    'fld_isuser_pages'     => $mpsr6[5],
    'fld_localadmin_pages' => $mpsr6[6],
    'fld_isaction_pages'   => $mpsr6[7],
    'fld_parentN_pages'    => $mpsr6[8],
   );
  }
  mysqli_free_result($result6);
 }else{
  debugSql2(array('sqler' => ' in ' . __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6 , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 if($fd=fopen($GLOBALS['glob_incPath1'].'/__pageList.php','w')){
  fwrite($fd,'<'.'?php'.CRLF.'$GLOBALS[\'__pageList\']='.var_export($listeDesPages,true).';');
  fclose($fd);
  $GLOBALS['__pageList']=$listeDesPages;
 }
 if($fd=fopen('js/__pageList.js','w')){
  fwrite($fd,'var globalPageList='.json_encode($listeDesPages).';');
  fclose($fd);
 }
}
//============================================================================================================================================
