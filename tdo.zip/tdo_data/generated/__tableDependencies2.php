<?php
// this programm is generated
function dependentValuesExist1($idParentDb,$parentTable,$parentField,$value,$options=array()){
 $ret=array(
  'valuesExist' => false   ,
  'tables'      => array() ,
 );
 $sqlList=array();
 if($idParentDb==0 && $parentTable=='tdo_tbl__pages' && $parentField == 'fld_id_pages' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_page_id_grpspgs` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` WHERE `fld_page_id_grpspgs` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__grpspgs',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__groups' && $parentField == 'fld_id_groups' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_group_id_users` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` WHERE `fld_group_id_users` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__users',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__users' && $parentField == 'fld_id_users' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_id_user_todos` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` WHERE `fld_id_user_todos` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__todos',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__pages' && $parentField == 'fld_id_pages' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_page_id_lngVals` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` WHERE `fld_page_id_lngVals` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__langvalues',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__paramnames' && $parentField == 'fld_id_parnams' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_id_parname_parvals` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramvalues` WHERE `fld_id_parname_parvals` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__paramvalues',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__groups' && $parentField == 'fld_id_groups' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_parent_id_groups` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` WHERE `fld_parent_id_groups` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__groups',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__zztests' && $parentField == 'fld_id_zztests' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_id_parent_zztests` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` WHERE `fld_id_parent_zztests` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__zztests',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__pages' && $parentField == 'fld_id_pages' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_parent_pages` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` WHERE `fld_parent_pages` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__pages',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__tables' && $parentField == 'fld_id_tables' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_parent_table_id_pglnks` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tablelinks` WHERE `fld_parent_table_id_pglnks` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__tablelinks',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__tables' && $parentField == 'fld_id_tables' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_children_table_id_pglnks` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tablelinks` WHERE `fld_children_table_id_pglnks` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__tablelinks',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__paramnames' && $parentField == 'fld_id_parnams' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_id_param_parrules` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramrules` WHERE `fld_id_param_parrules` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__paramrules',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__tables' && $parentField == 'fld_id_tables' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_id_reftbl_of_view_tables` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` WHERE `fld_id_reftbl_of_view_tables` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__tables',
   'idBase' => 0,
  );
 }
 if($idParentDb==0 && $parentTable=='tdo_tbl__groups' && $parentField == 'fld_id_groups' ){
  $sqlList[]=array(
   'sql'    => 'SELECT `fld_group_id_grpspgs` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` WHERE `fld_group_id_grpspgs` = '.$value.' LIMIT 1',
   'table'  => 'tdo_tbl__grpspgs',
   'idBase' => 0,
  );
 }
 foreach( $sqlList as $k1 => $v1 ){
  if(false === $ret['valuesExist']){
   $req=mysqli_query($GLOBALS['glob_db'][$v1['idBase']]['link'],$v1['sql']);
   if(mysqli_errno($GLOBALS['glob_db'][$v1['idBase']]['link'])==0){
    while($row=mysqli_fetch_row($req)){
     $ret['valuesExist']=true;
     $ret['tables'][]=$v1['table'];
    }
    mysqli_free_result($req);
   }else{
    $ret['valuesExist']=true;
    $ret['tables'][]=$v1['table'];
    debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][[$v1['idBase']]]['link']),'reque' => $v1['sql'] , 'file' => __FILE__ , 'line' => __LINE__ ));  
   }
  }
 }
 return $ret;
}
