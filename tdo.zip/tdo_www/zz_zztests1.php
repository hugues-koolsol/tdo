<?php // € utf8 check with euro sign
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
require_once($GLOBALS['glob_noVcPath1'].'/parameters/country.php');
checkGroupPages();
openDb1();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_yorno1_zztests
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_visited_countries_zztests
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_country1_zztests
$xsrch_3=saveSessionSearch1('xsrch_3',BNF);// fld_title32_zztests
$xsrch_4=saveSessionSearch1('xsrch_4',BNF);// fld_id_parent_zztests
$xsrch_5=saveSessionSearch1('xsrch_5',BNF);// filter search for fld_id_parent_zztests defined 
$xsrch_6=saveSessionSearch1('xsrch_6',BNF);// fld_title32_zztests of parent table
$xsrch_7=saveSessionSearch1('xsrch_7',BNF);// fld_country1_zztests of parent table
$xsrch_8=saveSessionSearch1('xsrch_8',BNF);// fld_yorno1_zztests of parent table
$xsrch_9=saveSessionSearch1('xsrch_9',BNF);// fld_date1_zztests
$xsrch_10=saveSessionSearch1('xsrch_10',BNF);// fld_time1_zztests
$xsrch_11=saveSessionSearch1('xsrch_11',BNF);// fld_dttim1_zztests
$xsrch_12=saveSessionSearch1('xsrch_12',BNF);// fld_color1_zztests
$xsrch_13=saveSessionSearch1('xsrch_13',BNF);// fld_email1_zztests
$xsrch_14=saveSessionSearch1('xsrch_14',BNF);// fld_zipnum1_zztests
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_zztests
$xsrch_sort=saveSessionSearch1('xsrch_sort',BNF);
if($xsrch_4!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_4);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if(!$listIdsOk){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_must_fill_a_numeric_value_for_the_field') . ' : ' . txt1('fld_id_parent_zztests');
 }
}
if($xsrch_14!=''){
 if(!is_numeric($xsrch_14)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_must_fill_a_numeric_value_for_the_field') . ' : ' . txt1('fld_zipnum1_zztests');
 }
}
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if(!$listIdsOk){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_must_fill_a_numeric_value_for_the_field') . ' : ' . txt1('fld_id_zztests');
 }
}
if(is_array($xsrch_1) && sizeof($xsrch_1)==1 && $xsrch_1[0]==''){ // fld_visited_countries_zztests
 $xsrch_1='';
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; } // fld_yorno1_zztests
else if($xsrch_1!=''){ $autofocus='xsrch_1'; } // fld_visited_countries_zztests
else if($xsrch_2!=''){ $autofocus='xsrch_2'; } // fld_country1_zztests
else if($xsrch_3!=''){ $autofocus='xsrch_3'; } // fld_title32_zztests
else if($xsrch_4!=''){ $autofocus='xsrch_4'; } // fld_id_parent_zztests link to parent table
else if($xsrch_5!=''){ $autofocus='xsrch_5'; } // condition search for fld_id_parent_zztests defined
else if($xsrch_6!=''){ $autofocus='xsrch_6'; } // fld_title32_zztests of parent table
else if($xsrch_7!=''){ $autofocus='xsrch_7'; } // fld_country1_zztests of parent table
else if($xsrch_8!=''){ $autofocus='xsrch_8'; } // fld_yorno1_zztests of parent table
else if($xsrch_9!=''){ $autofocus='xsrch_9'; } // fld_date1_zztests
else if($xsrch_10!=''){ $autofocus='xsrch_10'; } // fld_time1_zztests
else if($xsrch_11!=''){ $autofocus='xsrch_11'; } // fld_dttim1_zztests
else if($xsrch_12!=''){ $autofocus='xsrch_12'; } // fld_color1_zztests
else if($xsrch_13!=''){ $autofocus='xsrch_13'; } // fld_email1_zztests
else if($xsrch_14!=''){ $autofocus='xsrch_14'; } // fld_zipnum1_zztests
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt1('list of zztests').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="filterForm">'.CRLF;
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt1('fld_yorno1_zztests').'</label>'.CRLF;
$o1.='    <select '.($xsrch_0!=''?'class="backgroundYellow"':'').' name="xsrch_0"  id="xsrch_0" '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='<option value="" '.($xsrch_0==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_0){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
if('NULL'==(string)$xsrch_0){
 $o1.='<option value="NULL"  selected="selected">'.txtsys1('undefined').'</option>'.CRLF;  
}else{
 $o1.='<option value="NULL">'.txtsys1('undefined').'</option>'.CRLF;   
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_1">'.txt1('fld_visited_countries_zztests').'</label>'.CRLF;
$o1.='    <select size="3" name="xsrch_1[]"   multiple="multiple" style="max-width:10em;" id="xsrch_1" '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' ';
if(is_array($xsrch_1)){
 if($xsrch_1[0]!=''){
  $o1.=' class="backgroundYellow" ';
 }
}else{
 if($xsrch_1!=''){$o1.=' class="backgroundYellow" ';}
}
$o1.='  />'.CRLF;
$o1.='<option value="" '.($xsrch_1==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
if(!is_array($xsrch_1)) $xsrch_1=array();
if(is_array($xsrch_1) && in_array( '__all_values_of_set__' , $xsrch_1 )){
 $o1.='<option value="__all_values_of_set__" selected="selected" >'.txtsys1('all_values_of_set_list').'</option>'.CRLF;
}else{
 $o1.='<option value="__all_values_of_set__">'.txtsys1('all_values_of_set_list').'</option>'.CRLF; 
}
foreach($GLOBALS['param__country']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if(in_array($kp,$xsrch_1)){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__country']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__country']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_2">'.txt1('fld_country1_zztests').'</label>'.CRLF;
$o1.='    <select '.($xsrch_2!=''?'class="backgroundYellow"':'').' name="xsrch_2"  id="xsrch_2" '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='<option value="" '.($xsrch_2==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__country']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_2){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__country']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__country']['param__Name__Display']].' </option>'.CRLF;  
 }
}
if('NULL'==(string)$xsrch_2){
 $o1.='<option value="NULL"  selected="selected">'.txtsys1('undefined').'</option>'.CRLF;  
}else{
 $o1.='<option value="NULL">'.txtsys1('undefined').'</option>'.CRLF;   
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_3">'.txt1('fld_title32_zztests').'</label>'.CRLF; // fld_title32_zztests
$o1.='    <input '.($xsrch_3!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_3" id="xsrch_3"   value="'.enti1($xsrch_3).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_3'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_4">'.txt1('fld_id_parent_zztests').'</label>'.CRLF; // fld_id_parent_zztests
$o1.='    <input '.($xsrch_4!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_4" id="xsrch_4"   value="'.enti1($xsrch_4).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_4'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
// output search for fld_id_parent_zztests defined
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_5">'.txt1('fld_id_parent_zztests is defined').'</label>'.CRLF;
$o1.='    <select '.($xsrch_5!=''?'class="backgroundYellow"':'').' name="xsrch_5"  id="xsrch_5" '.($autofocus=='xsrch_5'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" />'.CRLF;
$o1.='<option value="" '.($xsrch_5==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_5){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;



// field fld_title32_zztests of parent table

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_6">'.txt1('T1.fld_title32_zztests').'</label>'.CRLF; // fld_title32_zztests
$o1.='    <input '.($xsrch_6!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_6" id="xsrch_6"   value="'.enti1($xsrch_6).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_6'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

// field fld_country1_zztests of parent table
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_7">'.txt1('T1.fld_country1_zztests').'</label>'.CRLF;
$o1.='    <select '.($xsrch_7!=''?'class="backgroundYellow"':'').' name="xsrch_7"  id="xsrch_7" '.($autofocus=='xsrch_7'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='<option value="" '.($xsrch_7==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__country']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_7){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__country']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__country']['param__Name__Display']].' </option>'.CRLF;  
 }
}
if('NULL'==(string)$xsrch_7){
 $o1.='<option value="NULL"  selected="selected">'.txtsys1('undefined').'</option>'.CRLF;  
}else{
 $o1.='<option value="NULL">'.txtsys1('undefined').'</option>'.CRLF;   
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;

// field fld_yorno1_zztests of parent table
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_8">'.txt1('T1.fld_yorno1_zztests').'</label>'.CRLF;
$o1.='    <select '.($xsrch_8!=''?'class="backgroundYellow"':'').' name="xsrch_8"  id="xsrch_8" '.($autofocus=='xsrch_8'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='<option value="" '.($xsrch_8==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_8){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
if('NULL'==(string)$xsrch_8){
 $o1.='<option value="NULL"  selected="selected">'.txtsys1('undefined').'</option>'.CRLF;  
}else{
 $o1.='<option value="NULL">'.txtsys1('undefined').'</option>'.CRLF;   
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_9">'.txt1('fld_date1_zztests').'</label>'.CRLF; // fld_date1_zztests
$o1.='    <input '.($xsrch_9!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_9" id="xsrch_9"   value="'.enti1($xsrch_9).'"  size="8" maxlength="19"  '.($autofocus=='xsrch_9'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_10">'.txt1('fld_time1_zztests').'</label>'.CRLF; // fld_time1_zztests
$o1.='    <input '.($xsrch_10!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_10" id="xsrch_10"   value="'.enti1($xsrch_10).'"  size="8" maxlength="19"  '.($autofocus=='xsrch_10'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_11">'.txt1('fld_dttim1_zztests').'</label>'.CRLF; // fld_dttim1_zztests
$o1.='    <input '.($xsrch_11!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_11" id="xsrch_11"   value="'.enti1($xsrch_11).'"  size="8" maxlength="19"  '.($autofocus=='xsrch_11'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_12">'.txt1('fld_color1_zztests').'</label>'.CRLF; // fld_color1_zztests
$o1.='    <input type="hidden" name="xsrch_12" id="xsrch_12"   value="'.enti1($xsrch_12).'"  '.($autofocus=='xsrch_12'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='    <button '.($xsrch_12!=''?'class="backgroundYellow"':'').' style="padding:0px!important;" type="button" id="button_color_xsrch_12" onclick="javascript:setColor1(\'xsrch_12\',\'button_color_xsrch_12\',\'\',1,1,\'onChangeDateListForm1\')" style="border-style:outset;font-size:0.8em;padding:5px;">';
$o1.=($xsrch_12==''?txtsys1('color all'):($xsrch_12=='NULL'?txtsys1('color null'):($xsrch_12=='NOT NULL'?txtsys1('color not null'):$xsrch_12)));
$o1.='</button>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_13">'.txt1('fld_email1_zztests').'</label>'.CRLF; // fld_email1_zztests
$o1.='    <input '.($xsrch_13!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_13" id="xsrch_13"   value="'.enti1($xsrch_13).'"  size="8" maxlength="128"  '.($autofocus=='xsrch_13'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_14">'.txt1('fld_zipnum1_zztests').'</label>'.CRLF; // fld_zipnum1_zztests
$o1.='    <input '.($xsrch_14!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_14" id="xsrch_14"   value="'.enti1($xsrch_14).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_14'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt1('fld_id_zztests').'</label>'.CRLF; // fld_id_zztests
$o1.='    <input '.($xsrch_id!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_sort">'.txtsys1('sort_order').'</label>'.CRLF; // sort
$o1.='    <select '.($xsrch_sort!=''?'class="backgroundYellow"':'').' name="xsrch_sort"  id="xsrch_sort" '.($autofocus=='xsrch_sort'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='     <option value="" '.($xsrch_sort==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_yorno1_zztests_ASC'.'"            '.($xsrch_sort=='T0.fld_yorno1_zztests_ASC'            ?' selected="selected" ':'').'>&#8599; '.txt1('fld_yorno1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_yorno1_zztests_DESC'.'"            '.($xsrch_sort=='T0.fld_yorno1_zztests_DESC'            ?' selected="selected" ':'').'>&#8600; '.txt1('fld_yorno1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_visited_countries_zztests_ASC'.'" '.($xsrch_sort=='T0.fld_visited_countries_zztests_ASC' ?' selected="selected" ':'').'>&#8599; '.txt1('fld_visited_countries_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_visited_countries_zztests_DESC'.'" '.($xsrch_sort=='T0.fld_visited_countries_zztests_DESC' ?' selected="selected" ':'').'>&#8600; '.txt1('fld_visited_countries_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_country1_zztests_ASC'.'"          '.($xsrch_sort=='T0.fld_country1_zztests_ASC'          ?' selected="selected" ':'').'>&#8599; '.txt1('fld_country1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_country1_zztests_DESC'.'"          '.($xsrch_sort=='T0.fld_country1_zztests_DESC'          ?' selected="selected" ':'').'>&#8600; '.txt1('fld_country1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_title32_zztests_ASC'.'"           '.($xsrch_sort=='T0.fld_title32_zztests_ASC'           ?' selected="selected" ':'').'>&#8599; '.txt1('fld_title32_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_title32_zztests_DESC'.'"           '.($xsrch_sort=='T0.fld_title32_zztests_DESC'           ?' selected="selected" ':'').'>&#8600; '.txt1('fld_title32_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_id_parent_zztests_ASC'.'"         '.($xsrch_sort=='T0.fld_id_parent_zztests_ASC'         ?' selected="selected" ':'').'>&#8599; '.txt1('fld_id_parent_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_id_parent_zztests_DESC'.'"         '.($xsrch_sort=='T0.fld_id_parent_zztests_DESC'         ?' selected="selected" ':'').'>&#8600; '.txt1('fld_id_parent_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T1.fld_title32_zztests_ASC'.'"           '.($xsrch_sort=='T1.fld_title32_zztests_ASC'           ?' selected="selected" ':'').'>&#8599; '.txt1('T1.fld_title32_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T1.fld_title32_zztests_DESC'.'"           '.($xsrch_sort=='T1.fld_title32_zztests_DESC'           ?' selected="selected" ':'').'>&#8600; '.txt1('T1.fld_title32_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T1.fld_country1_zztests_ASC'.'"          '.($xsrch_sort=='T1.fld_country1_zztests_ASC'          ?' selected="selected" ':'').'>&#8599; '.txt1('T1.fld_country1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T1.fld_country1_zztests_DESC'.'"          '.($xsrch_sort=='T1.fld_country1_zztests_DESC'          ?' selected="selected" ':'').'>&#8600; '.txt1('T1.fld_country1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T1.fld_yorno1_zztests_ASC'.'"            '.($xsrch_sort=='T1.fld_yorno1_zztests_ASC'            ?' selected="selected" ':'').'>&#8599; '.txt1('T1.fld_yorno1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T1.fld_yorno1_zztests_DESC'.'"            '.($xsrch_sort=='T1.fld_yorno1_zztests_DESC'            ?' selected="selected" ':'').'>&#8600; '.txt1('T1.fld_yorno1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_date1_zztests_ASC'.'"             '.($xsrch_sort=='T0.fld_date1_zztests_ASC'             ?' selected="selected" ':'').'>&#8599; '.txt1('fld_date1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_date1_zztests_DESC'.'"             '.($xsrch_sort=='T0.fld_date1_zztests_DESC'             ?' selected="selected" ':'').'>&#8600; '.txt1('fld_date1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_time1_zztests_ASC'.'"             '.($xsrch_sort=='T0.fld_time1_zztests_ASC'             ?' selected="selected" ':'').'>&#8599; '.txt1('fld_time1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_time1_zztests_DESC'.'"             '.($xsrch_sort=='T0.fld_time1_zztests_DESC'             ?' selected="selected" ':'').'>&#8600; '.txt1('fld_time1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_dttim1_zztests_ASC'.'"            '.($xsrch_sort=='T0.fld_dttim1_zztests_ASC'            ?' selected="selected" ':'').'>&#8599; '.txt1('fld_dttim1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_dttim1_zztests_DESC'.'"            '.($xsrch_sort=='T0.fld_dttim1_zztests_DESC'            ?' selected="selected" ':'').'>&#8600; '.txt1('fld_dttim1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_color1_zztests_ASC'.'"            '.($xsrch_sort=='T0.fld_color1_zztests_ASC'            ?' selected="selected" ':'').'>&#8599; '.txt1('fld_color1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_color1_zztests_DESC'.'"            '.($xsrch_sort=='T0.fld_color1_zztests_DESC'            ?' selected="selected" ':'').'>&#8600; '.txt1('fld_color1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_email1_zztests_ASC'.'"            '.($xsrch_sort=='T0.fld_email1_zztests_ASC'            ?' selected="selected" ':'').'>&#8599; '.txt1('fld_email1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_email1_zztests_DESC'.'"            '.($xsrch_sort=='T0.fld_email1_zztests_DESC'            ?' selected="selected" ':'').'>&#8600; '.txt1('fld_email1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_zipnum1_zztests_ASC'.'"           '.($xsrch_sort=='T0.fld_zipnum1_zztests_ASC'           ?' selected="selected" ':'').'>&#8599; '.txt1('fld_zipnum1_zztests').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_zipnum1_zztests_DESC'.'"           '.($xsrch_sort=='T0.fld_zipnum1_zztests_DESC'           ?' selected="selected" ':'').'>&#8600; '.txt1('fld_zipnum1_zztests').'</option>'.CRLF;
$o1.='    </select>';
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;// #128270
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
// todo adjust the request
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_zztests`                ,T0.`fld_yorno1_zztests`            ,T0.`fld_visited_countries_zztests` ,T0.`fld_country1_zztests`          ,T0.`fld_title32_zztests`           ,
   T0.`fld_id_parent_zztests`         ,T1.`fld_title32_zztests`           ,T1.`fld_country1_zztests`          ,T1.`fld_yorno1_zztests`            ,T0.`fld_date1_zztests`             ,
   T0.`fld_time1_zztests`             ,T0.`fld_dttim1_zztests`            ,T0.`fld_color1_zztests`            ,T0.`fld_email1_zztests`            ,T0.`fld_zipnum1_zztests`           
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` T0 ) 
 LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests`  T1 ON T0.`fld_id_parent_zztests` = T1.`fld_id_zztests`
 WHERE 1=1 
';
if($xsrch_0!='' ){
 if($xsrch_0=='NULL' ){
  $req6.='
   AND T0.`fld_yorno1_zztests` = \'\'
  '; 
 }else{
  $req6.='
   AND T0.`fld_yorno1_zztests` LIKE \'%'.addslashes1($xsrch_0).'%\'
  '; 
 }
}
if($xsrch_1!='' ){
 $req6.=buildSetCondition($xsrch_1,'param__country', 'T0.`fld_visited_countries_zztests`' );
}
if($xsrch_2!='' ){
 if($xsrch_2=='NULL' ){
  $req6.='
   AND T0.`fld_country1_zztests` = \'\'
  '; 
 }else{
  $req6.='
   AND T0.`fld_country1_zztests` LIKE \'%'.addslashes1($xsrch_2).'%\'
  '; 
 }
}
if($xsrch_3!='' ){
 $req6.='
  AND T0.`fld_title32_zztests` LIKE \'%'.addslashes1($xsrch_3).'%\'
 '; 
}
if($xsrch_4!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_4);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if($listIdsOk){
  $req6.='
   AND T0.`fld_id_parent_zztests` IN ('.implode(',',$xsrch_ids).') 
  '; 
 }
}
if($xsrch_5!=''){
 if($xsrch_5=='1'){
  $req6.='
   AND T0.`fld_id_parent_zztests` IS NOT NULL
  '; 
 }else{
  $req6.='
   AND T0.`fld_id_parent_zztests` IS NULL
  '; 
 }
}
// field fld_title32_zztests of parent table
if($xsrch_6!='' ){
 $req6.='
  AND T1.`fld_title32_zztests` LIKE \'%'.addslashes1($xsrch_6).'%\'
 '; 
}
// field fld_country1_zztests of parent table
if($xsrch_7!='' ){
 if($xsrch_7=='NULL' ){
  $req6.='
   AND T1.`fld_country1_zztests` = \'\'
  '; 
 }else{
  $req6.='
   AND T1.`fld_country1_zztests` LIKE \'%'.addslashes1($xsrch_7).'%\'
  '; 
 }
}
// field fld_yorno1_zztests of parent table
if($xsrch_8!='' ){
 if($xsrch_8=='NULL' ){
  $req6.='
   AND T1.`fld_yorno1_zztests` = \'\'
  '; 
 }else{
  $req6.='
   AND T1.`fld_yorno1_zztests` LIKE \'%'.addslashes1($xsrch_8).'%\'
  '; 
 }
}
if($xsrch_9!='' ){
 if($xsrch_9=='NULL'){
  $req6.='
   AND T0.`fld_date1_zztests` IS NULL
  ';   
 }else if($xsrch_9=='NOT NULL'){
  $req6.='
   AND T0.`fld_date1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_date1_zztests` LIKE \'%'.addslashes1($xsrch_9).'%\'
  '; 
 }
}
if($xsrch_10!='' ){
 if($xsrch_10=='NULL'){
  $req6.='
   AND T0.`fld_time1_zztests` IS NULL
  ';   
 }else if($xsrch_10=='NOT NULL'){
  $req6.='
   AND T0.`fld_time1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_time1_zztests` LIKE \'%'.addslashes1($xsrch_10).'%\'
  '; 
 }
}
if($xsrch_11!='' ){
 if($xsrch_11=='NULL'){
  $req6.='
   AND T0.`fld_dttim1_zztests` IS NULL
  ';   
 }else if($xsrch_11=='NOT NULL'){
  $req6.='
   AND T0.`fld_dttim1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_dttim1_zztests` LIKE \'%'.addslashes1($xsrch_11).'%\'
  '; 
 }
}
if($xsrch_12!='' ){
 if($xsrch_12=='NULL'){
  $req6.='
   AND T0.`fld_color1_zztests` IS NULL
  ';   
 }else if($xsrch_12=='NOT NULL'){
  $req6.='
   AND T0.`fld_color1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_color1_zztests` LIKE \'%'.addslashes1($xsrch_12).'%\'
  '; 
 }
}
if($xsrch_13!='' ){
 $req6.='
  AND T0.`fld_email1_zztests` LIKE \'%'.addslashes1($xsrch_13).'%\'
 '; 
}
if($xsrch_14!='' && is_numeric($xsrch_14)){
 $req6.='
  AND T0.`fld_zipnum1_zztests` = '.$xsrch_14.'
 '; 
}
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if($listIdsOk){
  $req6.='
   AND T0.`fld_id_zztests` IN ('.implode(',',$xsrch_ids).') 
  '; 
 }
}
// adjust the order
if($xsrch_sort==''){ $req6.='ORDER BY T0.`fld_id_zztests` DESC ';}
if($xsrch_sort=='T0.fld_yorno1_zztests_ASC'){             $req6.=' ORDER BY T0.`fld_yorno1_zztests` ASC  '; }
if($xsrch_sort=='T0.fld_yorno1_zztests_DESC'){             $req6.=' ORDER BY T0.`fld_yorno1_zztests` DESC  '; }
if($xsrch_sort=='T0.fld_visited_countries_zztests_ASC'){  $req6.=' ORDER BY T0.`fld_visited_countries_zztests` ASC  '; }
if($xsrch_sort=='T0.fld_visited_countries_zztests_DESC'){  $req6.=' ORDER BY T0.`fld_visited_countries_zztests` DESC  '; }
if($xsrch_sort=='T0.fld_country1_zztests_ASC'){           $req6.=' ORDER BY T0.`fld_country1_zztests` ASC  '; }
if($xsrch_sort=='T0.fld_country1_zztests_DESC'){           $req6.=' ORDER BY T0.`fld_country1_zztests` DESC  '; }
if($xsrch_sort=='T0.fld_title32_zztests_ASC'){            $req6.=' ORDER BY T0.`fld_title32_zztests` ASC  '; }
if($xsrch_sort=='T0.fld_title32_zztests_DESC'){            $req6.=' ORDER BY T0.`fld_title32_zztests` DESC  '; }
if($xsrch_sort=='T0.fld_id_parent_zztests_ASC'){          $req6.=' ORDER BY T0.`fld_id_parent_zztests` ASC  '; }
if($xsrch_sort=='T0.fld_id_parent_zztests_DESC'){          $req6.=' ORDER BY T0.`fld_id_parent_zztests` DESC  '; }
if($xsrch_sort=='T1.fld_title32_zztests_ASC'){            $req6.=' ORDER BY T1.`fld_title32_zztests` ASC ';}
if($xsrch_sort=='T1.fld_title32_zztests_DESC'){            $req6.=' ORDER BY T1.`fld_title32_zztests` DESC ';}
if($xsrch_sort=='T1.fld_country1_zztests_ASC'){           $req6.=' ORDER BY T1.`fld_country1_zztests` ASC ';}
if($xsrch_sort=='T1.fld_country1_zztests_DESC'){           $req6.=' ORDER BY T1.`fld_country1_zztests` DESC ';}
if($xsrch_sort=='T1.fld_yorno1_zztests_ASC'){             $req6.=' ORDER BY T1.`fld_yorno1_zztests` ASC ';}
if($xsrch_sort=='T1.fld_yorno1_zztests_DESC'){             $req6.=' ORDER BY T1.`fld_yorno1_zztests` DESC ';}
if($xsrch_sort=='T0.fld_date1_zztests_ASC'){              $req6.=' ORDER BY T0.`fld_date1_zztests` ASC  '; }
if($xsrch_sort=='T0.fld_date1_zztests_DESC'){              $req6.=' ORDER BY T0.`fld_date1_zztests` DESC  '; }
if($xsrch_sort=='T0.fld_time1_zztests_ASC'){              $req6.=' ORDER BY T0.`fld_time1_zztests` ASC  '; }
if($xsrch_sort=='T0.fld_time1_zztests_DESC'){              $req6.=' ORDER BY T0.`fld_time1_zztests` DESC  '; }
if($xsrch_sort=='T0.fld_dttim1_zztests_ASC'){             $req6.=' ORDER BY T0.`fld_dttim1_zztests` ASC  '; }
if($xsrch_sort=='T0.fld_dttim1_zztests_DESC'){             $req6.=' ORDER BY T0.`fld_dttim1_zztests` DESC  '; }
if($xsrch_sort=='T0.fld_color1_zztests_ASC'){             $req6.=' ORDER BY T0.`fld_color1_zztests` ASC  '; }
if($xsrch_sort=='T0.fld_color1_zztests_DESC'){             $req6.=' ORDER BY T0.`fld_color1_zztests` DESC  '; }
if($xsrch_sort=='T0.fld_email1_zztests_ASC'){             $req6.=' ORDER BY T0.`fld_email1_zztests` ASC  '; }
if($xsrch_sort=='T0.fld_email1_zztests_DESC'){             $req6.=' ORDER BY T0.`fld_email1_zztests` DESC  '; }
if($xsrch_sort=='T0.fld_zipnum1_zztests_ASC'){            $req6.=' ORDER BY T0.`fld_zipnum1_zztests` ASC  '; }
if($xsrch_sort=='T0.fld_zipnum1_zztests_DESC'){            $req6.=' ORDER BY T0.`fld_zipnum1_zztests` DESC  '; }
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$__count=0;
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'T0.fld_id_zztests'                =>$mpsr6[0],
  'T0.fld_yorno1_zztests'            =>$mpsr6[1],
  'T0.fld_visited_countries_zztests' =>$mpsr6[2],
  'T0.fld_country1_zztests'          =>$mpsr6[3],
  'T0.fld_title32_zztests'           =>$mpsr6[4],
  'T0.fld_id_parent_zztests'         =>$mpsr6[5],
  'T1.fld_title32_zztests'           =>$mpsr6[6],
  'T1.fld_country1_zztests'          =>$mpsr6[7],
  'T1.fld_yorno1_zztests'            =>$mpsr6[8],
  'T0.fld_date1_zztests'             =>$mpsr6[9],
  'T0.fld_time1_zztests'             =>$mpsr6[10],
  'T0.fld_dttim1_zztests'            =>$mpsr6[11],
  'T0.fld_color1_zztests'            =>$mpsr6[12],
  'T0.fld_email1_zztests'            =>$mpsr6[13],
  'T0.fld_zipnum1_zztests'           =>$mpsr6[14],
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}
$lsttbl='';
if($__count==0){
 $lst.='<p>'.CRLF;
 $lst.=''.txt1('no_record_founded').''.CRLF;
 $lst.='<a href="zz_zztests_action1.php?a=c">'.txt1('add_a_new_record').'</a>'.CRLF;
 $lst.='</p>'.CRLF;
 $o1.=''.$lst.''.CRLF;  
}else{
 $consUrlRedir=''.
               ($xsrch_0!=''?'&amp;xsrch_0='.rawurlencode($xsrch_0):''). // fld_yorno1_zztests 
               ($xsrch_2!=''?'&amp;xsrch_2='.rawurlencode($xsrch_2):''). // fld_country1_zztests 
               ($xsrch_3!=''?'&amp;xsrch_3='.rawurlencode($xsrch_3):''). // fld_title32_zztests 
               ($xsrch_4!=''?'&amp;xsrch_4='.rawurlencode($xsrch_4):''). // fld_id_parent_zztests 
               ($xsrch_5!=''?'&amp;xsrch_5='.rawurlencode($xsrch_5):''). // fld_id_parent_zztests defined 
                ($xsrch_6!=''?'&amp;xsrch_6='.rawurlencode($xsrch_6):''). // fld_title32_zztests of parent
                ($xsrch_7!=''?'&amp;xsrch_7='.rawurlencode($xsrch_7):''). // fld_country1_zztests of parent
                ($xsrch_8!=''?'&amp;xsrch_8='.rawurlencode($xsrch_8):''). // fld_yorno1_zztests of parent
               ($xsrch_9!=''?'&amp;xsrch_9='.rawurlencode($xsrch_9):''). // fld_date1_zztests 
               ($xsrch_10!=''?'&amp;xsrch_10='.rawurlencode($xsrch_10):''). // fld_time1_zztests 
               ($xsrch_11!=''?'&amp;xsrch_11='.rawurlencode($xsrch_11):''). // fld_dttim1_zztests 
               ($xsrch_12!=''?'&amp;xsrch_12='.rawurlencode($xsrch_12):''). // fld_color1_zztests 
               ($xsrch_13!=''?'&amp;xsrch_13='.rawurlencode($xsrch_13):''). // fld_email1_zztests 
               ($xsrch_14!=''?'&amp;xsrch_14='.rawurlencode($xsrch_14):''). // fld_zipnum1_zztests 
               ($xsrch_id!=''?'&amp;xsrch_id='.rawurlencode($xsrch_id):'').
               ($xsrch_sort!=''?'&amp;xsrch_sort='.rawurlencode($xsrch_sort):'').
               '';
 if(is_array($xsrch_1)){
  foreach($xsrch_1 as $k1 => $v1){
   $consUrlRedir.='&amp;xsrch_1%5B%5D='.rawurlencode($v1);
  }
 }else{
  $consUrlRedir.='&amp;xsrch_1='.rawurlencode($xsrch_1); // fld_visited_countries_zztests
 }
 $ri=' <span class="btn unset">&raquo;</span>';
 if($__start+$__nbMax<$__count){
  $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
 }
 $le=' <span class="btn unset">&laquo;</span>';
 if($__xpage>0){
  $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
 }

 $o1.='<div>';
 $o1.='<form method="post">';
// $o1.='<button type="submit" name="action1">'.txt0('action1').'</button>';
// $o1.='<button type="submit" name="action2">'.txt0('action2').'</button>';
 $o1.='<a href="zz_zztests_action1.php?a=c">'.txt1('add_a_new_record').'</a>'.CRLF;
 $o1.='&nbsp;'.$le.''.CRLF;  
 $o1.='&nbsp;'.$ri.''.CRLF;  
 $o1.=' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt1('records zztests').' )'.CRLF;
 $o1.='</form>';
 $o1.='</div>';

 $o1.=getCss1(890); // todo adjust size

 $lsttbl.='<thead><tr>';
 $lsttbl.='<th style="min-width:125px;">'.txtsys1('column_action').'</th>';
 $lsttbl.='<th style="min-width:85px;">'.txt1('fld_id_zztests').'</th>';
 $lsttbl.='<th>'.txt1('fld_yorno1_zztests').'</th>';
 $lsttbl.='<th>'.txt1('fld_visited_countries_zztests').'</th>';
 $lsttbl.='<th>'.txt1('fld_country1_zztests').'</th>';
 $lsttbl.='<th>'.txt1('fld_title32_zztests').'</th>';
 $lsttbl.='<th>'.txt1('fld_id_parent_zztests').'</th>';
 $lsttbl.='<th>'.txt1('T1.fld_title32_zztests').'</th>'; // ======== parent field of fld_id_parent_zztests
 $lsttbl.='<th>'.txt1('T1.fld_country1_zztests').'</th>'; // ======== parent field of fld_id_parent_zztests
 $lsttbl.='<th>'.txt1('T1.fld_yorno1_zztests').'</th>'; // ======== parent field of fld_id_parent_zztests
 $lsttbl.='<th  style="min-width:95px;">'.txt1('fld_date1_zztests').'</th>';
 $lsttbl.='<th>'.txt1('fld_time1_zztests').'</th>';
 $lsttbl.='<th  style="min-width:95px;">'.txt1('fld_dttim1_zztests').'</th>';
 $lsttbl.='<th>'.txt1('fld_color1_zztests').'</th>';
 $lsttbl.='<th>'.txt1('fld_email1_zztests').'</th>';
 $lsttbl.='<th>'.txt1('fld_zipnum1_zztests').'</th>';
 $lsttbl.='</tr></thead><tbody>';

 foreach($data0 as $k0=>$v0){

  $lsttbl.='<tr><td class="fictif"></td>';

  $lsttbl.='<td data-label="" style="text-align:left!important;">';
  $lsttbl.='<div class="flex1">';
  $lsttbl.='<a class="txtSiz1 danger" href="zz_zztests_action1.php?a=d&amp;id='.$v0['T0.fld_id_zztests'].'" title="'.txtsys1('delete_button').'" >&#10008;</a>';//✘ #10008
  $lsttbl.='<a class="txtSiz2"        href="zz_zztests_action1.php?a=du&amp;id='.$v0['T0.fld_id_zztests'].'" title="'.txtsys1('duplicate_button').'">&#x2398;</a>';// ⎘:x2398 📋:#128203
  $lsttbl.='<a class="txtSiz1 edit"   href="zz_zztests_action1.php?a=u&amp;id='.$v0['T0.fld_id_zztests'].'" title="'.txtsys1('edit_button').'">&#9998;</a>';//✎ #9998
  $lsttbl.='</div>';
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt4('fld_id_zztests').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_id_zztests'].''; // fld_id_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt4('fld_yorno1_zztests').'" style="text-align:center;">';
  $lsttbl.=displayParam1('yorno',$v0['T0.fld_yorno1_zztests'],array('unsetPossible'=>true)); // fld_yorno1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt4('fld_visited_countries_zztests').'">';
  $lsttbl.=displayParam1('country',$v0['T0.fld_visited_countries_zztests'],array('set'=>true)); // fld_visited_countries_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt4('fld_country1_zztests').'" style="text-align:center;">';
  $lsttbl.=displayParam1('country',$v0['T0.fld_country1_zztests'],array('unsetPossible'=>true)); // fld_country1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt4('fld_title32_zztests').'">';
  $lsttbl.=''.enti1($v0['T0.fld_title32_zztests']).''; // fld_title32_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt4('fld_id_parent_zztests').'" style="text-align:center;">';
  $lsttbl.=''.enti1($v0['T0.fld_id_parent_zztests']).''; // fld_id_parent_zztests
  $lsttbl.='</td>';


// field display of the parent table fld_title32_zztests
  if($v0['T1.fld_title32_zztests']===0||is_null($v0['T1.fld_title32_zztests'])){
   $lsttbl.='<td data-label="'.txt4('T1.fld_title32_zztests').'"></td>'; 
  }else{
   $lsttbl.='<td data-label="'.txt4('T1.fld_title32_zztests').'">';
   $lsttbl.=''.enti1($v0['T1.fld_title32_zztests']).''; // fld_title32_zztests
   $lsttbl.='</td>';
  }



// field display of the parent table fld_country1_zztests
  if($v0['T1.fld_country1_zztests']===0||is_null($v0['T1.fld_country1_zztests'])){
   $lsttbl.='<td data-label="'.txt4('T1.fld_country1_zztests').'"></td>'; 
  }else{
   $lsttbl.='<td data-label="'.txt4('T1.fld_country1_zztests').'" style="text-align:center;">';
   $lsttbl.=displayParam1('country',$v0['T1.fld_country1_zztests'],array('unsetPossible'=>true)); // fld_country1_zztests
   $lsttbl.='</td>';
  }



// field display of the parent table fld_yorno1_zztests
  if($v0['T1.fld_yorno1_zztests']===0||is_null($v0['T1.fld_yorno1_zztests'])){
   $lsttbl.='<td data-label="'.txt4('T1.fld_yorno1_zztests').'"></td>'; 
  }else{
   $lsttbl.='<td data-label="'.txt4('T1.fld_yorno1_zztests').'" style="text-align:center;">';
   $lsttbl.=displayParam1('yorno',$v0['T1.fld_yorno1_zztests'],array('unsetPossible'=>true)); // fld_yorno1_zztests
   $lsttbl.='</td>';
  }


  $lsttbl.='<td data-label="'.txt4('fld_date1_zztests').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_date1_zztests'].''; // fld_date1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt4('fld_time1_zztests').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_time1_zztests'].''; // fld_time1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt4('fld_dttim1_zztests').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_dttim1_zztests'].''; // fld_dttim1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt4('fld_color1_zztests').'">'; // fld_color1_zztests
  if($v0['T0.fld_color1_zztests']==''){
   $lsttbl.=''.$v0['T0.fld_color1_zztests'].''; 
  }else{
   $val=json_decode($v0['T0.fld_color1_zztests'],true);
   $lsttbl.='<div style="display:inline-block;width:35px;height:20px;border:1px #eee outset;background-color:#'.$val['hexValue'].'"></div>';
   $lsttbl.=''.$val['hexValue'].'';
   if(isset($val['webName']) && $val['webName']!=''){
    $lsttbl.='<br />'.$val['webName'].'';
   }
   if(isset($val['pantoneName']) && $val['pantoneName']!=''){
    $lsttbl.='<br /> pantone:'.$val['pantoneName'].'';
   }
  }
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt4('fld_email1_zztests').'">';
  $lsttbl.=''.enti1($v0['T0.fld_email1_zztests']).''; // fld_email1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt4('fld_zipnum1_zztests').'" style="text-align:right;">';
  $lsttbl.=''.$v0['T0.fld_zipnum1_zztests'].''; // fld_zipnum1_zztests
  $lsttbl.='</td>';



  $lsttbl.='<td class="fictif"></td></tr>';

 }

 $o1.='<table class="tableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;

 $o1.=' <div>'.CRLF;
 $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt1('records zztests').' )'.CRLF;
 $o1.='   &nbsp;<a class="" href="zz_zztests_action1.php?a=c">'.txt1('add_a_new_record').'</a>'.CRLF;
 $o1.=' </div>'.CRLF;

}

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
