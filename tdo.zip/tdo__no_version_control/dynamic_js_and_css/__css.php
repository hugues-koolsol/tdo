<?php
$__css=array (
  1 => 
  array (
    'fld_id_css' => '1',
    'fld_name_css' => 'production',
    'fld_active_css' => '1',
    'fld_color_back_css' => '{"hexValue":"FFFDE7","webValue":"","webName":"","pantoneName":"","materialName":"Yellow 50","hsvValue":"55,9,100","rgbValue":"255,253,231"}',
    'fld_color_text_css' => '{"hexValue":"8E1818","webValue":"","webName":"","pantoneName":"","materialName":"","hsvValue":"0,83,55","rgbValue":"142,24,24"}',
    'fld_tsupd_css' => '2019-04-09-22_06_20',
    'fld_tscrt_css' => '2019-03-13 15:26:56',
    'fld_cntupd_css' => '34',
  ),
  2 => 
  array (
    'fld_id_css' => '2',
    'fld_name_css' => 'développement',
    'fld_active_css' => '1',
    'fld_color_back_css' => '{"hexValue":"ECEFF1","webValue":"","webName":"","pantoneName":"","materialName":"Blue grey 50","hsvValue":"204,2,94","rgbValue":"236,239,241"}',
    'fld_color_text_css' => '{"hexValue":"555555","webValue":"","webName":"","pantoneName":"","materialName":"","hsvValue":"0,0,33","rgbValue":"85,85,85"}',
    'fld_tsupd_css' => '2019-04-09-22_07_53',
    'fld_tscrt_css' => '2017-11-17 15:39:34',
    'fld_cntupd_css' => '233',
  ),
  3 => 
  array (
    'fld_id_css' => '3',
    'fld_name_css' => 'préproduction',
    'fld_active_css' => '1',
    'fld_color_back_css' => '{"hexValue":"E3F2FD","webValue":"","webName":"","pantoneName":"","materialName":"Blue 50","hsvValue":"205,10,99","rgbValue":"227,242,253"}',
    'fld_color_text_css' => '{"hexValue":"0D47A1","webValue":"","webName":"","pantoneName":"","materialName":"Blue 900","hsvValue":"216,91,63","rgbValue":"13,71,161"}',
    'fld_tsupd_css' => '2019-04-09-22_08_48',
    'fld_tscrt_css' => '2019-03-13 15:49:20',
    'fld_cntupd_css' => '29',
  ),
  4 => 
  array (
    'fld_id_css' => '4',
    'fld_name_css' => 'rouge',
    'fld_active_css' => '1',
    'fld_color_back_css' => '{"hexValue":"FFF4F6","webValue":"","webName":"","pantoneName":"","materialName":"","hsvValue":"351,4,100","rgbValue":"255,244,246"}',
    'fld_color_text_css' => '{"hexValue":"B71C1C","webValue":"","webName":"","pantoneName":"","materialName":"Red 900","hsvValue":"84,84,71","rgbValue":"183,28,28"}',
    'fld_tsupd_css' => '2019-04-09-22_13_39',
    'fld_tscrt_css' => '2019-03-13 17:42:26',
    'fld_cntupd_css' => '42',
  ),
  5 => 
  array (
    'fld_id_css' => '5',
    'fld_name_css' => 'green',
    'fld_active_css' => '1',
    'fld_color_back_css' => '{"hexValue":"E8F5E9","webValue":"","webName":"","pantoneName":"","materialName":"Green 50","hsvValue":"5,5,96","rgbValue":"232,245,233"}',
    'fld_color_text_css' => '{"hexValue":"1B5E20","webValue":"","webName":"","pantoneName":"","materialName":"Green 900","hsvValue":"71,71,36","rgbValue":"27,94,32"}',
    'fld_tsupd_css' => '2019-04-09-22_09_33',
    'fld_tscrt_css' => '2019-03-14 22:40:59',
    'fld_cntupd_css' => '40',
  ),
  6 => 
  array (
    'fld_id_css' => '6',
    'fld_name_css' => 'material Blue grey',
    'fld_active_css' => '0',
    'fld_color_back_css' => '{"hexValue":"ECEFF1","webValue":"","webName":"","pantoneName":"","materialName":"Blue grey 50","hsvValue":"2,2,94","rgbValue":"236,239,241"}',
    'fld_color_text_css' => '{"hexValue":"263238","webValue":"","webName":"","pantoneName":"","materialName":"Blue grey 900","hsvValue":"32,32,21","rgbValue":"38,50,56"}',
    'fld_tsupd_css' => '2019-04-09-22_10_39',
    'fld_tscrt_css' => '2019-03-17 16:40:49',
    'fld_cntupd_css' => '33',
  ),
  7 => 
  array (
    'fld_id_css' => '7',
    'fld_name_css' => 'material Blue grey sombre',
    'fld_active_css' => '1',
    'fld_color_back_css' => '{"hexValue":"263238","webValue":"","webName":"","pantoneName":"","materialName":"Blue grey 900","hsvValue":"32,32,21","rgbValue":"38,50,56"}',
    'fld_color_text_css' => '{"hexValue":"ECEFF1","webValue":"","webName":"","pantoneName":"","materialName":"Blue grey 50","hsvValue":"2,2,94","rgbValue":"236,239,241"}',
    'fld_tsupd_css' => '2019-04-09-22_15_00',
    'fld_tscrt_css' => '2019-03-17 16:59:06',
    'fld_cntupd_css' => '67',
  ),
);