<?php
// group 1:root
$GLOBALS['glob_treegrp']='1,2,3,4';