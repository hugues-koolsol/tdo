<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();
//========================================================================================================================
function import_csv($tableName,$serverId,$fieldDef){
 $nombreInsertParGroupe=100;
 
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $tableName , true ) . '</pre> <pre>' . var_export( $fieldDef , true ) . '</pre>' ; exit(0);

 $fieldList='';
 foreach($fieldDef as $k1=>$v1){
  if($v1['ignore_for_import']==false){
   $fieldList.=',`'.$v1[0].'`';
  }
 }
 
 $sqlTruncate='TRUNCATE `'.$GLOBALS['glob_db'][$serverId]['dbname'].'`.`' . $tableName .'` '.CRLF;
 mysqli_query($GLOBALS['glob_db'][$serverId]['link'], $sqlTruncate  );
 
 
 
 $sqlinsertMain='INSERT INTO `'.$GLOBALS['glob_db'][$serverId]['dbname'].'`.`' . $tableName .'` (' . substr($fieldList,1) . ') VALUES'.CRLF;
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $sqlFirst , true ) . '</pre>' ; exit(0);
 $valueLines='';
 $fileName=$GLOBALS['glob_noVcPath1'].DIRECTORY_SEPARATOR.'_restore/mysql_table_'.$serverId.'_'.$tableName.'.csv';
 if(($handle = fopen($fileName, 'r')) !== false){
  $countLines=0;
  while(($data=fgetcsv($handle, 0 , ';'  , '"'  )) !== false) { // no escape on php 5.2.17
  
   if($countLines==$nombreInsertParGroupe){
    $sqlinsert=$sqlinsertMain . $valueLines;
    mysqli_query($GLOBALS['glob_db'][$serverId]['link'], $sqlinsert  );
    if(mysqli_errno($GLOBALS['glob_db'][$serverId]['link'])==0){
    }else{
     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( mysqli_error($GLOBALS['glob_db'][$serverId]['link']) , true ) . '</pre>' ; exit(0);
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' mysqli_error() = ' . mysqli_error($GLOBALS['glob_db'][$serverId]['link']) . ' , pour $sqlinsert = ' . $sqlinsert ;
     header('Location: '.BNF);exit();
    }
    $valueLines='';
    $countLines=0;
   }
   $numData=0;
   $sqldata='';
   foreach($fieldDef as $k2 => $v2 ){
    $typeChamp=$v2[1];
    if(
       strpos(strtolower($typeChamp),'tinyint(')!==false
     ||strpos(strtolower($typeChamp),'decimal(')!==false
     ||strpos(strtolower($typeChamp),'bigint(')!==false
     ||strpos(strtolower($typeChamp),'float(')!==false
     ||strpos(strtolower($typeChamp),'double(')!==false
     ||strpos(strtolower($typeChamp),'real(')!==false
     ||strpos(strtolower($typeChamp),'bit(')!==false
     ||strpos(strtolower($typeChamp),'int(')!==false
     ||strpos(strtolower($typeChamp),'boolean')!==false
    ){
     $format='num';
    }else if(
       strpos(strtolower($typeChamp),'char')!==false
     ||strpos(strtolower($typeChamp),'text')!==false
     ||strpos(strtolower($typeChamp),'blob')!==false
     ||strpos(strtolower($typeChamp),'enum(')!==false
     ||strpos(strtolower($typeChamp),'set(')!==false
     ||strpos(strtolower($typeChamp),'timestamp')!==false
     ||strpos(strtolower($typeChamp),'datetime')!==false
     ||strpos(strtolower($typeChamp),'date')!==false
     ||strpos(strtolower($typeChamp),'time')!==false
     ||strpos(strtolower($typeChamp),'binary')!==false
     ||strpos(strtolower($typeChamp),'varbinary')!==false
     ||strpos(strtolower($typeChamp),'json')!==false
    ){
     $format='texte';
    }else{
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' typeChamp="' . $typeChamp . '" pour $numData=' . $numData . ' non pris en compte dans ' . var_export( $v1 , true );
     header('Location: '.BNF);exit();
    }
    if($sqldata!='') $sqldata.= ' , ';
    if($format=='texte'){
     if(isset($v2['transform'])){
      if($v2['transform']==''){
       $sqldata.= ' \''.addslashes(str_replace('\\"','"',str_replace('\\\\','\\', $data[$numData]  ))).'\' ';
      }else{
       $tabTransform=explode('|',$v2['transform']);
//       $sqldata.= ' \''.addslashes(str_replace('\\"','"',str_replace('\\\\','\\', mb_convert_encoding( $data[$numData] , $tabTransform[1]  , $tabTransform[0]  ) ))).'\' ';
       $sqldata.= ' \''.addslashes(str_replace('\\"','"',str_replace('\\\\','\\', $data[$numData] ))).'\' ';
      }
     }else{
      $sqldata.= ' \''.addslashes(str_replace('\\"','"',str_replace('\\\\','\\', $data[$numData] ))).'\' ';      
     }
    }else if($format=='num'){
     if($data[$numData]==''){
      $sqldata.= ' NULL ';      
     }else{
      $sqldata.= ' '.$data[$numData].' ';
     }
    }
    $numData++;
   }
   if($valueLines!='') $valueLines.=' , '.CRLF;
   $valueLines.=' ( '.$sqldata.' ) ';
   $countLines++;  
  }
  fclose($handle);
  if($valueLines!=''){
   $sqlinsert=$sqlinsertMain . $valueLines;
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $sqlinsert , true ) . '</pre>' ; exit(0);
   mysqli_query($GLOBALS['glob_db'][$serverId]['link'], $sqlinsert  );
   if(mysqli_errno($GLOBALS['glob_db'][$serverId]['link'])==0){
   }else{
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' mysqli_error() = ' . mysqli_error($GLOBALS['db'][$serverId]['link']) . ' , pour $sqlinsert = ' . $sqlinsert ;
    header('Location: '.BNF);exit();
   }
  }
 }
 
 return true;
}
//========================================================================================================================
if(count($_POST)>0){
 
 if( isset($_POST['second_thought']) && $_POST['second_thought'] == $_SESSION[PGMK][BNF]['restore_second_thought'] 
  && isset($_FILES['zipfile1']) && $_FILES['zipfile1']['error']==0  && $_FILES['zipfile1']['size']>0 
 ){
  $err=0;
  if(!is_dir($GLOBALS['glob_noVcPath1'].DIRECTORY_SEPARATOR.'_restore')){
   if(!mkdir($GLOBALS['glob_noVcPath1'].DIRECTORY_SEPARATOR.'_restore')){
    $err=1;
   }
  }
  
  $files = glob(realpath($GLOBALS['glob_noVcPath1'].DIRECTORY_SEPARATOR.'_restore').DIRECTORY_SEPARATOR.'{,.}*', GLOB_BRACE);
  foreach($files as $file){ // iterate files
   if(is_file($file)){
    unlink($file); // delete file
   }
  }
  
  $targetPath=$GLOBALS['glob_noVcPath1'].DIRECTORY_SEPARATOR.'_restore';
  $targetZip=$targetPath.DIRECTORY_SEPARATOR.'zip1.zip';
  if($err==0){
   if(!move_uploaded_file ( $_FILES['zipfile1']['tmp_name'] , $targetZip )){
    $err=1;
   }
  }
  if($err==0){
   $zip=zip_open($targetZip);
   if(is_resource($zip)){
    while($zip_entry=zip_read($zip)) {
     $file = basename(zip_entry_name($zip_entry));
     if($fd=fopen($targetPath.'/'.zip_entry_name($zip_entry),'w')){
      if(zip_entry_open( $zip , $zip_entry )){
       $goon=true;
       while($goon){
        $buff=zip_entry_read( $zip_entry ,4096 );
        if($buff!=''){
         fwrite($fd,$buff);
        }else{
         $goon=false;
        }
       }
       zip_entry_close( $zip_entry );
       fclose($fd);
      }else{
       echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
       $err=1;
      }    
     }else{
      echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
      $err=1;
     }
    }
    zip_close($zip);
   }else{
    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
    $err=1;
   }
  }
  
  if($err==0){
   unlink($targetPath.'/zip1.zip');
   unlink($targetPath.'/zipExcel.zip');
   
   $zip=zip_open($targetPath.'/zipMysql.zip');
   if(is_resource($zip)){
    while($zip_entry=zip_read($zip)) {
     $file = basename(zip_entry_name($zip_entry));
     if($fd=fopen($targetPath.'/'.zip_entry_name($zip_entry),'w')){
      if(zip_entry_open( $zip , $zip_entry )){
       $goon=true;
       while($goon){
        $buff=zip_entry_read( $zip_entry ,4096 );
        if($buff!=''){
         fwrite($fd,$buff);
        }else{
         $goon=false;
        }
       }
       zip_entry_close( $zip_entry );
       fclose($fd);
      }else{
       echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
       $err=1;
      }    
     }else{
      echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
      $err=1;
     }
    }
    zip_close($zip);
   }else{
    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
    $err=1;
   }
  }
  
  if($err==0){
   unlink($targetPath.'/zipMysql.zip');
  }  

//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_FILES , true ) . '</pre><pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
  
 }else if(isset($_POST['importTable1']) && $_POST['importTable1']!=''){
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
  $tabChamps=array();
  $listeDesChamps='';
  $sql0='DESC `'.$GLOBALS['glob_db'][$_POST['importServer1']]['dbname'].'`.`' . $_POST['importTable1'] .'`';
  $res0=mysqli_query($GLOBALS['glob_db'][$_POST['importServer1']]['link'],$sql0);
  if(mysqli_errno($GLOBALS['glob_db'][$_POST['importServer1']]['link'])==0){
   while($mpsr0=mysqli_fetch_row($res0)){
    if($listeDesChamps!='') $listeDesChamps.=' , ';
    if(
        strpos(strtolower($mpsr0[1]),'geometry'           )!==false
      ||strpos(strtolower($mpsr0[1]),'point'              )!==false
      ||strpos(strtolower($mpsr0[1]),'linestring'         )!==false
      ||strpos(strtolower($mpsr0[1]),'polygon'            )!==false
      ||strpos(strtolower($mpsr0[1]),'multipoint'         )!==false
      ||strpos(strtolower($mpsr0[1]),'multilinestring'    )!==false
      ||strpos(strtolower($mpsr0[1]),'multipolygon'       )!==false
      ||strpos(strtolower($mpsr0[1]),'geometrycollection' )!==false
    ){
     $listeDesChamps.='ST_AsText(`'.$mpsr0[0].'`)'; // ST_GeomFromText 
    }else if(
        strpos(strtolower($mpsr0[1]),'blob'           )!==false
    ){
     $listeDesChamps.='CONCAT("0x",HEX(CAST(`'.$mpsr0[0].'` AS CHAR(10000) CHARACTER SET utf8)))'; // todo, adjust size
    }else{
     $listeDesChamps.='`'.$mpsr0[0].'`';
    }
    $tabChamps[]=$mpsr0;
   }
   mysqli_free_result($res0);
  }else{
   myemail(
     __LINE__ . ' Attention les sauvegardes n\'ont pas été faites' , 
    'Erreur de sql='. $sql0 . ', mysqli_error()='.mysqli_error($GLOBALS['glob_db'][$kbase]['link']) .''.  "\r\n" .' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
    $GLOBALS['emailSendTo']
    );
   die(__FILE__ . ' ' . __LINE__ . ' Sauvegardes non effectuées');
  }
  
  $GLOBALS['table_definition'][$_POST['importServer1']][$_POST['importTable1']]=$tabChamps;
  $targetPath=$GLOBALS['glob_noVcPath1'].DIRECTORY_SEPARATOR.'_restore';
  require_once($targetPath.DIRECTORY_SEPARATOR.'php_import.php');
  
  if( isset($__tableImport[$_POST['importServer1']][$_POST['importTable1']]) ){
   
   foreach($__tableImport[$_POST['importServer1']][$_POST['importTable1']] as $k0=>$v0){
    $founded=false;
    $fieldsAreTheSame=true;
    foreach($GLOBALS['table_definition'][$_POST['importServer1']][$_POST['importTable1']] as $k1=>$v1){
     if($v0[0]==$v1[0]){
      $founded=true;
      if( $v0[1]!=$v1[1]
       || $v0[2]!=$v1[2]
       || $v0[3]!=$v1[3]
       || $v0[4]!=$v1[4]
       || $v0[5]!=$v1[5]
      ){
       $fieldsAreTheSame=false;
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : fields of table '.$_POST['importTable1'].' are different <pre>'.implode(',', $v0).'</pre><pre>'.implode(',', $v1).'</pre>';
       header('Location: '.BNF);exit();
      }
      break;
     }
    }
    if($founded==false){
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : field '.$v0[0].' of table '.$_POST['importTable1'].' is on remote but not on local<pre>'.implode(',', $v0).'</pre> ';
     header('Location: '.BNF);exit();
    }
   }
   
   
   
   foreach($GLOBALS['table_definition'][$_POST['importServer1']][$_POST['importTable1']] as $k0=>$v0){
    $founded=false;
    $fieldsAreTheSame=true;
    foreach($__tableImport[$_POST['importServer1']][$_POST['importTable1']] as $k1=>$v1){
     if($v0[0]==$v1[0]){
      $founded=true;
      if( $v0[1]!=$v1[1]
       || $v0[2]!=$v1[2]
       || $v0[3]!=$v1[3]
       || $v0[4]!=$v1[4]
       || $v0[5]!=$v1[5]
      ){
       $fieldsAreTheSame=false;
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : fields of table '.$_POST['importTable1'].' are different <pre>'.implode(',', $v0).'</pre><pre>'.implode(',', $v1).'</pre>';
       header('Location: '.BNF);exit();
      }
      break;
     }
    }
    if($founded==false){
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : field '.$v0[0].' of table '.$_POST['importTable1'].' is on local but not on remote<pre>'.implode(',', $v0).'</pre> ';
     header('Location: '.BNF);exit();
    }
   }
   if(!import_csv($_POST['importTable1'],$_POST['importServer1'],$__tableImport[$_POST['importServer1']][$_POST['importTable1']])){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : problem on import for '.$_POST['importTable1'].' ';
    header('Location: '.BNF);exit();
   }else{
    $fileName=$GLOBALS['glob_noVcPath1'].DIRECTORY_SEPARATOR.'_restore/mysql_table_'.$_POST['importServer1'].'_'.$_POST['importTable1'].'.csv';
    unlink($fileName);
    $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('message').' '. __LINE__ .' : table '.$_POST['importTable1'].' has been imported ';
    header('Location: '.BNF);exit();    
   }
  }else{
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : table '.$_POST['importTable1'].' not founded on remote ';
   header('Location: '.BNF);exit();
  }
  
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['table_definition'] , true ) . '</pre>' ; exit(0);
  
  
  
 }
 
 header('Location: '.BNF);exit();
 
}
//========================================================================================================================
$o1='';
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_333_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.='<form method="post" class="form1" id="restore1" enctype="multipart/form-data">'.CRLF;

$_SESSION[PGMK][BNF]['restore_second_thought']=mt_rand(100000,999999);
$v=number_format($_SESSION[PGMK][BNF]['restore_second_thought'],0,',',' ');

$o1.=' <div class="yyfdiv1">'.CRLF;
$o1.='  <div class="yyflab1"><div>'.txt2('enter_the_second_thought_code_20_40').'</div></div>'.CRLF;
$o1.='  <div class="yyfinp1"><div>'.CRLF;
$o1.='   <input type="text" value="" name="second_thought" id="second_thought" maxlength="6" style="width:100%;max-width:5em;" />'.CRLF;
$o1.='  <br />'.$v.' '.CRLF;
$o1.='  </div></div>'.CRLF;
$o1.=' </div>'.CRLF;


$o1.=' <div class="yyfdiv1">'.CRLF;
$o1.='  <div class="yyflab1"><div>'.txt2('zip_file_351_40').'</div></div>'.CRLF;
$o1.='  <div class="yyfinp1"><div>'.CRLF;
$o1.='   <input type="file" name="zipfile1" id="zipfile1"  />'.CRLF;
$o1.='  </div></div>'.CRLF;
$o1.=' </div>'.CRLF;

$o1.='<div class="yyfdiv1">'.CRLF;
$o1.='  <div class="yyfinp1"><div>'.CRLF;
$o1.='   <button type="submit" class="">'.txt2('upload the file_359_48').'</button>'.CRLF;
$o1.='  </div></div>'.CRLF;
$o1.='</div>'.CRLF;

$o1.=' </form>'.CRLF;

if(is_dir($GLOBALS['glob_noVcPath1'].DIRECTORY_SEPARATOR.'_restore')){

 $files = glob($GLOBALS['glob_noVcPath1'].DIRECTORY_SEPARATOR.'_restore'.DIRECTORY_SEPARATOR.'{,.}*', GLOB_BRACE);
 foreach($files as $file){ // iterate files
  if(is_file($file)){
   $filename=substr($file,strrpos($file,DIRECTORY_SEPARATOR)+1);
   if( substr($filename,0,12)=='mysql_table_'){
    
    $idServerAndTableName=substr($filename,12);
    $idServer=substr($idServerAndTableName,0,strpos($idServerAndTableName,'_'));
    $idServer=substr($idServerAndTableName,0,strpos($idServerAndTableName,'_'));
    $tableName=substr($idServerAndTableName,strpos($idServerAndTableName,'_')+1);
    $tableName=substr($tableName,0,-4); // supprime .csv
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $idServerAndTableName , true ) . '</pre> <pre>' . var_export( $idServer , true ) . '</pre> <pre>' . var_export( $tableName , true ) . '</pre>' ; exit(0);
    
    
    $o1.='<form method="post" class="" onsubmit="return myConfirm0()"><input type="hidden" value="'.$tableName.'" name="importTable1" /><input type="hidden" value="'.$idServer.'" name="importServer1" /><button type="submit" class="noHide">'.txt2('import_data_for : _381_247').'</button>&nbsp;'.$idServer.'/'.$tableName.'</form>'.CRLF;
   }
  }
 }
}


$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
