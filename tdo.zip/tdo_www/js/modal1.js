"use strict";
//====================================================================================================
function modal1(opt) {
 
 
 var backgroundModal=null;
 var modalDiv=null;
 var headerModal=null;
 var closeModalButton=null;
 var bodyModal=null;
 var parentModal=null;
 var modalIsOpen=false;
 var initPositionMouseDown={};
 var initPositionModal={};
 var theBody=document.getElementsByTagName('body')[0];
 var viewportWidth=Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
 var viewportHeight=Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
 var dimensionModale=null;
 var optionShow=null;
 
 if(viewportWidth===0 || viewportHeight===0){
  return false;
 }
 
 //===============================================================================================================================
 function mouseUpModal(event){
  window.removeEventListener('mousemove', mouseMoveModal , false );
  window.removeEventListener('mouseup'  , mouseUpModal   , false );
//  console.log(event);
 }
 //===============================================================================================================================
 function mouseMoveModal(event){
  event.stopPropagation();
  event.preventDefault();
  var deltaX=event.pageX-initPositionMouseDown.x;
  var newX=initPositionModal.x+deltaX;
  if(newX<=0) newX=0;
  var deltaY=event.pageY-initPositionMouseDown.y;
  var newY=initPositionModal.y+deltaY;
  if(newY<globalCssSettings1.sizes.menuHeight+scrollTop4Modal1) newY=globalCssSettings1.sizes.menuHeight+scrollTop4Modal1;
  modalDiv.style.left=newX+'px';
  modalDiv.style.top=newY+'px';
 }
 //===============================================================================================================================
 function mouseDownHeaderModal(event){
  initPositionMouseDown={x:event.pageX,y:event.pageY};
  initPositionModal={x:parseInt(modalDiv.style.left,10),y:parseInt(modalDiv.style.top,10)};
  window.addEventListener('mousemove', mouseMoveModal , false );
  window.addEventListener('mouseup'  , mouseUpModal   , false );
//  console.log(event);
 }
 //===============================================================================================================================
 function touchEndModal(event){
  window.removeEventListener('touchmove' , touchMoveModal , false );
  window.removeEventListener('touchend'  , touchEndModal   , false );
//  console.log(event);
 }
 //===============================================================================================================================
 function touchMoveModal(e){
  event=e.touches[0];
  e.stopPropagation();
//  e.preventDefault();
  var deltaX=event.pageX-initPositionMouseDown.x;
  if(dimensionModale.width+initPositionModal.x+deltaX>viewportWidth){
   deltaX=viewportWidth-(dimensionModale.width+initPositionModal.x);
  }
  var newX=initPositionModal.x+deltaX;
  if(newX<=0) newX=0;
 
  
  var deltaY=event.pageY-initPositionMouseDown.y;
  var newY=initPositionModal.y+deltaY;
  if(newY<globalCssSettings1.sizes.menuHeight+scrollTop4Modal1) newY=globalCssSettings1.sizes.menuHeight+scrollTop4Modal1;
  
  modalDiv.style.left=newX+'px';
  modalDiv.style.top=newY+'px';
 }
 //===============================================================================================================================
 function touchStartHeaderModal(e){
  dimensionModale=modalDiv.getBoundingClientRect();
  event=e.touches[0];
  initPositionMouseDown={x:event.pageX,y:event.pageY};
  initPositionModal={x:parseInt(modalDiv.style.left,10),y:parseInt(modalDiv.style.top,10)};
  window.addEventListener('touchmove', touchMoveModal , false );
  window.addEventListener('touchend' , touchEndModal  , false );
 }
 //===============================================================================================================================
 function buildModal(obj){
  parentModal=theBody;
  var w = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
  var h = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);

  if(w===0||h===0){
   return false;
  }

  var bckWidth=w;
  var bckHeight=h;
  
  backgroundModal=document.createElement('div');
  backgroundModal.style.top='0px';
  backgroundModal.style.left='0px';
  backgroundModal.style.width =bckWidth+'px';
  backgroundModal.style.height=bckHeight+'px';
  backgroundModal.style.backgroundColor='black';
  backgroundModal.style.opacity=0.4;
  backgroundModal.style.position='absolute';
  backgroundModal.style.display='block';
  parentModal.appendChild(backgroundModal);
  backgroundModal.addEventListener('click',closeModal,true);
  
  var childrenWidth=bckWidth;
  var childrenLeft=0;
  if(bckWidth>500){
   childrenWidth=500;
   childrenLeft=parseInt((bckWidth-500)/2,10);
  }
  
  var childrenHeight=bckHeight;
  var childrenTop=0;
  if(bckHeight>500){
   childrenHeight=500;
   childrenTop=parseInt((bckHeight-500)/2,10);
  }
  
  modalDiv=document.createElement('div');
  modalDiv.id='__modal';
  modalDiv.style.top=childrenTop+'px';
  modalDiv.style.left=childrenLeft+'px';
  modalDiv.style.width =childrenWidth+'px';
  modalDiv.style.maxHeight=childrenHeight+'px';
  modalDiv.style.backgroundColor='#'+globalCssSettings1.table.headerBackgroundColor.hexValue; //'rgba(255,255,255,0.9)';
//  modalDiv.style.opacity=0.9;
  modalDiv.style.position='absolute';
  modalDiv.style.display='none';
  modalDiv.style.boxShadow='#'+globalCssSettings1.main.mainTextColor.hexValue+' 0px 0px 6px';
  modalDiv.style.borderRadius='3px';
  modalDiv.style.overflow='scroll';
  modalDiv.style.transition='opacity 0.1s';
  
  parentModal.appendChild(modalDiv);

  headerModal=document.createElement('div');
  headerModal.id='__headerModal';
  headerModal.style.top='0px';
  headerModal.style.left='0px';
  headerModal.style.height='2em';
//  headerModal.style.backgroundColor='rgba(255,255,255,0.2)';
//  headerModal.style.opacity=1;
  headerModal.style.position='relative';
//  headerModal.style.margin='2px';
  headerModal.style.display='block';
  headerModal.style.opacity=1;
  headerModal.style.cursor='move';
  headerModal.className='yyminHeight1';  
  modalDiv.appendChild(headerModal);
  headerModal.addEventListener('mousedown', mouseDownHeaderModal, false);
  if(is_touch_device()){
   headerModal.addEventListener('touchstart', touchStartHeaderModal, false);
  }
  
  window.addEventListener('resize', myEfficientFn);
  

  closeModalButton=document.createElement('button');
  closeModalButton.style.backgroundColor='#999';
  closeModalButton.style.opacity=1;
  closeModalButton.style.lineHeight='2em';
  closeModalButton.style.color='red';
  closeModalButton.style.cursor='pointer';
  closeModalButton.style.float='right';
  closeModalButton.className='yydanger';
  headerModal.appendChild(closeModalButton);
  closeModalButton.innerHTML='×';// '&#10060;'; // &#10006; &#9587; x , X
  closeModalButton.addEventListener('click', closeModal, false);
  
  bodyModal=document.createElement('div');
  bodyModal.style.width ='100%';
  bodyModal.style.backgroundColor='#'+globalCssSettings1.main.mainBackgroundColor.hexValue;
  bodyModal.style.opacity=1;
  bodyModal.style.position='relative';
  bodyModal.style.textAlign='center';
  bodyModal.style.overflow='hidden';
  bodyModal.id='bodyModal';
  modalDiv.appendChild(bodyModal);

 }
 //===============================================================================================================================
 var myEfficientFn = debounce(function() {
//  console.log('myEfficientFn');
  var w = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
  var h = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
  backgroundModal.style.width =w+'px';
  backgroundModal.style.height=h+'px';

 }, 300);
 //===============================================================================================================================
 var scrollTop4Modal1=0;
 //===============================================================================================================================
 function showModal(obj){
  optionShow=obj;
  if(backgroundModal===null){
   buildModal(optionShow);
  }
//  console.log(document.getElementsByTagName('body')[0].scrollTop);
  scrollTop4Modal1=getScrollTopValue1();
  var w = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
  var h = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
//  console.log(w+'x'+h);
  
  var bod1=document.getElementsByTagName('body')[0];
  bod1.style.overflow='hidden';
  bod1.style.position='fixed';
  bod1.style.marginTop=(scrollTop4Modal1*-1)+'px';
  bod1.style.paddingRight=globalScrollWidth1+'px';
  bod1.style.width=w+'px';

  var navbar=document.getElementById('navbar');
  navbar.style.paddingRight=globalScrollWidth1+'px';
  
  
  modalIsOpen=true;
  var bckWidth=(parseInt(parentModal.style.width,10));
  var bckHeight=(parseInt(parentModal.style.height,10));
  backgroundModal.style.width =w+'px';
  backgroundModal.style.height=h+'px';
  backgroundModal.style.display='block';
  modalDiv.style.left=(optionShow.x)+'px';
  if(optionShow.y<globalCssSettings1.sizes.menuHeight+scrollTop4Modal1) optionShow.y=globalCssSettings1.sizes.menuHeight+scrollTop4Modal1;
  modalDiv.style.top =(optionShow.y)+'px';
  modalDiv.style.display='block';
  modalDiv.style.opacity=0.0;
  

  
  bodyModal.innerHTML='';
  bodyModal.appendChild(optionShow.bodyModalContent);
  setTimeout(afterDisplay,25);
 } 
 //===============================================================================================================================
 function afterDisplay(){
  var w = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
  var h = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
  var dimMod=modalDiv.getBoundingClientRect();
  
  var recenterVertical=true;
  if(dimMod.height+globalCssSettings1.sizes.menuHeight>h){
   modalDiv.style.height=(h-globalCssSettings1.sizes.menuHeight)+'px';
   modalDiv.style.top=(globalCssSettings1.sizes.menuHeight)+'px';
   modalDiv.style.top=(globalCssSettings1.sizes.menuHeight)+'px';
   recenterVertical=false;
  }
//  console.log(dimMod , h)

  
  if(optionShow.hasOwnProperty('fullScreenForBigScreen')){
   if(optionShow.fullScreenForBigScreen==true){
    var dimMod=modalDiv.getBoundingClientRect();
    var newSizeH=parseInt((h-globalCssSettings1.sizes.menuHeight-globalCssSettings1.sizes.footerHeight-20),10);
    var newSizeW=parseInt((w-20),10);
    
    if(w>=800 && h>=600){
     modalDiv.style.width =newSizeW+'px';
     modalDiv.style.height=newSizeH+'px';
     modalDiv.style.maxHeight='';
    }
   }
  }
  
  if(optionShow.hasOwnProperty('centerVertical')){
   if(optionShow.centerVertical==true){
    var dimMod=modalDiv.getBoundingClientRect();
    if(dimMod.height<h && recenterVertical===true){
     modalDiv.style.top=parseInt(((h-dimMod.height-globalCssSettings1.sizes.menuHeight-globalCssSettings1.sizes.footerHeight)/2+globalCssSettings1.sizes.menuHeight),10)+'px';
    }
   }
  }
  
  if(optionShow.hasOwnProperty('centerHorizontal')){
   if(optionShow.centerHorizontal==true){
    var dimMod=modalDiv.getBoundingClientRect();
    if(dimMod.width<w){
     modalDiv.style.left=parseInt((w-dimMod.width)/2,10)+'px';
    }
   }
  }
  modalDiv.focus();
  
  // disable tab stops on all elements under the background
  var mainContent=document.getElementById('mainContent');
  var gTabbableTags=["a","button","textarea","input","iframe","select"];	
  for(var j=0;j<gTabbableTags.length;j++){
   var tagElements = mainContent.getElementsByTagName(gTabbableTags[j]);
   for(var k=0;k<tagElements.length;k++){
//    console.log(tagElements[k]);
    tagElements[k].tabIndex="-1";
   }
  }
  modalDiv.style.opacity=1;
  
  
  
 }
 
 //===============================================================================================================================
 function closeModal(event){
  modalIsOpen=false;
  if(event){
   event.stopPropagation();
   event.preventDefault();
  }
  // enable tab stops on all elements under the background
  var mainContent=document.getElementById('mainContent');
  var gTabbableTags=["a","button","textarea","input","iframe","select"];	
  for(var j=0;j<gTabbableTags.length;j++){
   var tagElements = mainContent.getElementsByTagName(gTabbableTags[j]);
   for(var k=0;k<tagElements.length;k++){
//    console.log(tagElements[k]);
    tagElements[k].tabIndex="0";
   }
  }
  
  
  modalDiv.style.display='none';
  backgroundModal.style.display='none';
  var bod1=document.getElementsByTagName('body')[0];
  bod1.style.overflow='';
  bod1.style.position='';
  bod1.style.marginTop='';
  bod1.style.paddingRight='';
  bod1.style.width='';
  
  var navbar=document.getElementById('navbar');
  navbar.style.paddingRight='';
  
  window.scrollTo(0,scrollTop4Modal1);
  scrollTop4Modal1=0;
 }
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 //====================================================================================================
 function displayModalSelectRefTableForView(view_name,fld_id_server_tables){
  var modalcontent=document.createElement('div');

  var span=document.createElement('span');
  span.innerHTML='Select the reference table for the view ';
  modalcontent.appendChild(span);
  
  var can=document.getElementById('canvas1');
  var dim=can.getBoundingClientRect();
  var y=dim.top;
  var x=parseInt((dim.width-450)/2,10);
  showModal({
   bodyModalContent   : modalcontent       ,
   event              : null               ,
   x                  : x ,
   y                  : y
  });
 }
 
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 
 return {
  showModal              : function(opt)          { showModal(opt);                       },
  nope                   : function()             { /* do nothing*/                       }
 } 
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
}