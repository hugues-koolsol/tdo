<?php
if(isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST']=='localhost'){
 $GLOBALS['glob_maintenance']=false;
}else{
 $GLOBALS['glob_maintenance']=true;
}
