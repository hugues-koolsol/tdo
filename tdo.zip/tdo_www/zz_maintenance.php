<?php
// this file is temporary put on the server during maintenance operation
define('SECRET_KEY_FOR_MAINTENANCE','1234567890');
$GLOBALS['glob_incPathAreInSubFolders']=true;
if(!(isset($_GET['secretKey']) && $_GET['secretKey'] == SECRET_KEY_FOR_MAINTENANCE )){
 exit(0);
}
if(isset($_GET['getTables'])){
 
 error_reporting(0);
 if($GLOBALS['glob_incPathAreInSubFolders']==true){
  @include('tdo__no_version_control/__dbaccess.php');
 }else{
  @include('../tdo__no_version_control/__dbaccess.php');
 }
 $tableList=array();
 foreach($GLOBALS['glob_db'] as $k1=>$v1){
  if(null===$GLOBALS['glob_db'][$k1]['link']){
   $link = mysqli_connect($v1['server'],$v1['user'],$v1['password'],$v1['dbname']);
   if($link){
    $GLOBALS['glob_db'][$k1]['link']=$link;
    if(mysqli_select_db( $GLOBALS['glob_db'][$k1]['link'] , $v1['dbname'] )){
     mysqli_set_charset( $link , 'utf8mb4' );
     $listeDesTables=json_decode($_GET['tableList'],true);
     foreach( $listeDesTables as $k2 => $v2 ){
      if($v2['s']==$k1){
       $tableList[$v2['n']]=array('table_name' => $v2['n'] );
       $fieldsFounded=false;
       $req7=' SHOW FULL COLUMNS FROM `'.$v2['n'].'` IN `'.$GLOBALS['glob_db'][$k1]['dbname'].'` ';
       $result7=mysqli_query($GLOBALS['glob_db'][$k1]['link'],$req7);
       if(mysqli_errno($GLOBALS['glob_db'][$k1]['link'])==0){
        while($mpsr7=mysqli_fetch_array($result7)){
         $fieldsFounded=true;
         $fieldSize=0;
         if(strpos($mpsr7[1],'char')!==null){
          $fieldSize=(int)str_replace(')','',str_replace('(','',substr($mpsr7[1],strpos($mpsr7[1],'('))));
         }
         $isNumericField=false;
         if(strpos(strtolower($mpsr7[1]),'int(')    !==false ||
           strpos(strtolower($mpsr7[1]),'decimal(') !==false ||
           strpos(strtolower($mpsr7[1]),'float(')   !==false ||
           strpos(strtolower($mpsr7[1]),'double(')  !==false ||
           strpos(strtolower($mpsr7[1]),'real(')    !==false){
          $isNumericField=true;
         }
         $tableList[$v2['n']]['fields'][$mpsr7[0]]=array(
          'nom_champ'      => $mpsr7[0],
          'type_champ'     => $mpsr7[1],
          'Collation'      => $mpsr7[2],
          'null_possible'  => $mpsr7[3],
          'champ_cle'      => $mpsr7[4],
          'val_defaut'     => $mpsr7[5],
          'extra'          => $mpsr7[6],
          'privileges'     => $mpsr7[7],
          'comment'        => $mpsr7[8],
          'fieldSize'      => $fieldSize,
          'isNumericField' => $isNumericField
         );
        }
        mysqli_free_result($result7);
       }
       if($fieldsFounded==false){
        unset($tableList[$v2['n']]);
       }
      }
     }
    }else{
     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
    }
   }
  }
 }
 header('Content-Type: application/json');
 echo json_encode($tableList,JSON_FORCE_OBJECT);
 exit();
}