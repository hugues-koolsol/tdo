<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
require_once $GLOBALS['glob_incPath1'].'/paramkeys1.php';

openDb2();
//========================================================================================================================
function btl1(){
 return '&nbsp;<a class="btn btn-small" href="zz_paramkeys.php">'.txtsys1('back_to_the_list').'</a>';
}

//========================================================================================================================
function test_input_paramkeyKO1(){
 $err=0;
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_key_parnams']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('The key must not be empty_18_92');
  $err=1;
 }
 if($err==0){
  for($i=0;$i<strlen($_SESSION[PGMK][NAV][BNF]['fld_key_parnams']) && $err == 0;$i++){
   $c=substr($_SESSION[PGMK][NAV][BNF]['fld_key_parnams'],$i,1);
   if(!(($c>='a' && $c<='z') || ($c>='A' && $c<='Z') || ($c>='0' && $c<='9') || $c=='_' )){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the key must have letters, numbers or "_"_25_94');
    $err=1;
   }
  }
 }
 if($err==0){
  $testJson=json_decode($_SESSION[PGMK][NAV][BNF]['fld_json_parnams'],true);
  if(null===$testJson){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the json is not technically correct_33_93');
   $err=1;
  }else{
   if(isset($_GET['id'])){
    $testJson['id']=$_GET['id'];
    $_SESSION[PGMK][NAV][BNF]['fld_json_parnams']=json_encode($testJson,JSON_PRETTY_PRINT);
   }
   if(isset($testJson['fields'])){
/*
   "name"                : "language_code" ,
   "type"                : "char"          ,
   "length"              : "6"             ,
   "languageTranslation" : false           ,
*/  
    $countTranslation=0;
    foreach( $testJson['fields'] as $k1 => $v1){
     if(0===$err){
      if(isset($v1['languageTranslation']) && ( true === $v1['languageTranslation'] || ( false === $v1['languageTranslation'] && $_POST['id1'] == '1' ) ) ){
       $countTranslation++;
      }
      if($v1['name']=='badge'){
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the "name" badge is a reserved name_49_97');
       $err=1;       
      }
      if(!isset($v1['name']) || !isset($v1['type']) || !isset($v1['length']) ){
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the json must contain a field named "fields"_47_97');
       $err=1;
      }else{
       if('char'===$v1['type'] || 'int'===$v1['type'] ){
        if(is_numeric($v1['length'])){
        }else{
         $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('length must be numerical_53_99');
         $err=1;
        }
       }else{
        $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('type must be char or int_57_98');
        $err=1;
       }
      }
     }
    }
    if($countTranslation!=1){
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('One field must contain languageTranslation to true_70_95');
     $err=1;
    }
    
   }else{
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the json must contain a field named "fields"_47_97');
    $err=1;
   }
   if(isset($testJson['key'])){
    $trouve=false;
    foreach( $testJson['fields'] as $k1 => $v1){
     if($testJson['key']==$v1['name']){
      $trouve=true;
     }
    }
    if(false===$trouve){
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : "'.$v1.'" ' . txt2('this key has not be founded in the fields_78_107');
     $err=1;
    }
    if($err==0){
     foreach( $testJson['fields'] as $k1 => $v1){
      if($testJson['key']==$v1['name'] && $err==0){
       if(isset($v1['languageTranslation'])){
        $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('The key field cannot be translated_93_98');
        $err=1;
       }
       $trouve=true;
      }
     }
     
    }
   }else{
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : "'.$v1.'" ' . txt2('a key field must be given_102_104');
    $err=1;
   }
  }
 }
 return($err);
}
//========================================================================================================================
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= POST ACTIONS  =====================================================================
 //=================================================================================================================================
 //=================================================================================================================================
// echo __LINE__ . '$_POST=<pre>' . var_export($_POST,true) . '</pre>'; exit();
 $_SESSION[PGMK][NAV][BNF]['fld_key_parnams']     =isset($_POST['fld_key_parnams'])     ?$_POST['fld_key_parnams']     :'';
 $_SESSION[PGMK][NAV][BNF]['fld_label_parnams']   =isset($_POST['fld_label_parnams'])   ?$_POST['fld_label_parnams']   :'';
 $_SESSION[PGMK][NAV][BNF]['fld_comment_parnams'] =isset($_POST['fld_comment_parnams']) ?$_POST['fld_comment_parnams'] :''; 
 $_SESSION[PGMK][NAV][BNF]['fld_json_parnams']    =isset($_POST['fld_json_parnams'])    ?$_POST['fld_json_parnams']    :''; 
 $_SESSION[PGMK][NAV][BNF]['fld_isuser_parnams']  =isset($_POST['fld_isuser_parnams'])  ?$_POST['fld_isuser_parnams']  :0;

 //=================================================================================================================================
 //============================================= POST UPDATE =======================================================================
 //=================================================================================================================================
 if(isset($_POST['a'])&&$_POST['a']=='u'){ // update action

 
  if(test_input_paramkeyKO1()){
   if(isset($_POST['id1'])&&is_numeric($_POST['id1'])){
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }else{
    header("HTTP/1.1 303 See Other");header('Location: index.php');
    exit();
   }
  }
  
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_SESSION[PGMK][NAV][BNF]['fld_json_parnams'] , true ) . '</pre>' ; exit(0);
  
  $req6="UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__paramnames` SET
     `fld_key_parnams`     = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_key_parnams'])     ."'
   , `fld_label_parnams`   = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_label_parnams'])   ."'
   , `fld_comment_parnams` = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_comment_parnams']) ."'
   , `fld_json_parnams`    = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_json_parnams'])    ."'
   , `fld_isuser_parnams`  =  ".$_SESSION[PGMK][NAV][BNF]['fld_isuser_parnams']              ."
   , `fld_tsupd_parnams`   = '" . $GLOBALS['glob_setdate']                                   ."'
   , `fld_cntupd_parnams`  =  " . ((int)$_POST['fld_cntupd_parnams']+1)                      ."
  ";
  $req6.="
   WHERE `fld_id_parnams`=".$_POST['id1']."
     AND `fld_cntupd_parnams` = ".$_POST['fld_cntupd_parnams']."
  " ;
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
     break;
    default   :
     $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 2 );
    break;
   }
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
  }else{
   if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])!=1){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('this_record_has_not_been_updated_because_of_an_other_user');
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('please_retry');
    unset($_SESSION[PGMK][NAV][BNF]['fld_key_parnams']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_label_parnams']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_comment_parnams']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_json_parnams']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_isuser_parnams']);
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
   }
   include $GLOBALS['glob_dataPath1'].'/generated/_params/'.$_SESSION[PGMK][NAV][BNF]['fld_key_parnams'].'.php';
   if(isset($GLOBALS['param__'.$_SESSION[PGMK][NAV][BNF]['fld_key_parnams']])){
    require_once($GLOBALS['glob_incPath1'].'/paramkeys1.php');
    writeParamFiles($_POST['id1']);
   }
   
   sqllog1( $req6 , BNF , __LINE__ );
   $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('the_modification_has_been_recorded_at') . ' ' . substr($GLOBALS['glob_setdate'],11);
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
   
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CONFIRM DELETE ===============================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='cd'){
  
  $dataParam=incGetParam1($_REQUEST['id']);
  $founded=false;
  $dataDefJsonParams=json_decode($dataParam['fld_json_parnams'],true);
  if(isset($dataDefJsonParams['dependencies']) && sizeof($dataDefJsonParams['dependencies'])>0){
   @include $GLOBALS['glob_dataPath1'].'/generated/_params/'.$dataParam['fld_key_parnams'].'.php';
   $keyName='param__'.$dataParam['fld_key_parnams'];
   $listeDesValeursDeClesNum='';
   $listeDesValeursDeClesChar='';
   
   
   if(isset($GLOBALS[$keyName])){
//    echo __FILE__ . ' ' . __LINE__ . ' $GLOBALS[$keyName] = <pre>' . var_export( $GLOBALS[$keyName] , true ) . '</pre>' ; 
    if(isset($dataDefJsonParams['dependencies']) && sizeof($dataDefJsonParams['dependencies'])>0){
     $countLang=0;
     foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang){
      $countLang++;
      if(1 === $countLang){
       foreach( $GLOBALS[$keyName]['__values'][$klang] as $k1 => $v1 ){
 //        if(dataDefJsonParams['fields'][])
        $listeDesValeursDeClesNum.=$k1.',';
        $listeDesValeursDeClesChar.='\''.addslashes1($k1).'\',';        
       }
      }
     }
     if($listeDesValeursDeClesNum!=''){
      $listeDesValeursDeClesNum =substr($listeDesValeursDeClesNum  , 0, -1 );
      $listeDesValeursDeClesChar=substr($listeDesValeursDeClesChar , 0, -1 );
      foreach( $dataDefJsonParams['dependencies'] as $k1 => $v1){
       if(false === $founded){
        
        $typeChamp='';
        $sqlType='SHOW COLUMNS FROM `'.$GLOBALS['glob_db'][$v1['id_db']]['dbname'].'`.`'.$v1['table'].'`';
//        echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $sqlType , true ) . '</pre>' ; exit(0);
        $resultType=mysqli_query($GLOBALS['glob_db'][0]['link'],$sqlType);
        if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
         while($mpsrType=mysqli_fetch_row($resultType)){
          if($mpsrType[0]==$v1['field']){
           $typeDuChamp=strtolower($mpsrType[1]);
//           echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $typeDuChamp , true ) . '</pre>' ; exit(0);
           if(strpos($typeDuChamp,'int(')!==false || strpos($typeDuChamp,'float(')!==false || strpos($typeDuChamp,'decimal(')!==false || strpos($typeDuChamp,'double(')!==false || strpos($typeDuChamp,'real(')!==false ){
            $typeChamp='num';
           }else{
            $typeChamp='char';
           }
          }
         }
         mysqli_free_result($resultType);
        }else{
         $founded=true;
         $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
         $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
         txtlog1($xtxterr , BNF , __LINE__ , 2 );
        }
        if(false===$founded && ( $typeChamp == 'num' || $typeChamp == 'char' ) ){
 //        echo __FILE__ . ' ' . __LINE__ . ' $typeChamp = <pre>' . var_export( $typeChamp , true ) . '</pre>' ; exit(0);
         if($typeChamp=='num' && ( $typeChamp=='num' || $typeChamp == 'char' ) ){
          $req6="SELECT `".$v1['field']."` FROM `".$GLOBALS['glob_db'][$v1['id_db']]['dbname']."`.`".$v1['table']."` WHERE `".$v1['field']."` IN (".$listeDesValeursDeClesNum.") LIMIT 1";
         }else{
          $req6="SELECT `".$v1['field']."` FROM `".$GLOBALS['glob_db'][$v1['id_db']]['dbname']."`.`".$v1['table']."` WHERE `".$v1['field']."` IN (".$listeDesValeursDeClesChar.") LIMIT 1";
         }
//         echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' . $req6  . '</pre>' ; 
         $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
         if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
          while($mpsr6=mysqli_fetch_row($result6)){
           $founded=true;
           $_SESSION[PGMK][NAV][BNF]['errormessage'][]= txtsys1('error').' ' . __LINE__ . ' ' . txt1('This value is present in some tables') . ' "'.$v1['table'].'"  "'.$v1['field'].'" ';
          }
          mysqli_free_result($result6);
         }     
        }
       }
      }
     }
    }
   }
  }
  if(true===$founded){
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=d&id='.$_POST['id1']);
   exit();   
  }

  require_once $GLOBALS['glob_dataPath1'].'/generated/__tableDependencies1.php';
  $retDependantTables=dependentValuesExist1(0,'tdo_tbl__paramnames','fld_id_parnams',$_POST['id1'] );
  if(true === $retDependantTables['valuesExist']){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' . txtsys1('you_cannot_delete_because_some_values_are_still_present_in_dependant_table') . ' ' . var_export( $retDependantTables['tables'] , true ) . ' ';
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=d&id='.$_POST['id1']);   
  }

  
  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__paramnames` WHERE `fld_id_parnams`=".$_POST['id1']." " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
   txtlog1($xtxterr , BNF , __LINE__ , 2 );
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=d&id='.$_POST['id1']);
   exit();
  }else{
   sqllog1( $req6 , BNF , __LINE__ );
   unset($_SESSION[PGMK][NAV][BNF]);
   $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__paramvalues` WHERE `fld_id_parname_parvals`=".$_REQUEST['id']." " ;
   $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   sqllog1( $req6 , BNF , __LINE__ );
   
   @unlink($GLOBALS['glob_dataPath1'].'/generated/_params/'.$dataParam['fld_key_parnams'].'.php');
   header("HTTP/1.1 303 See Other");header('Location: zz_paramkeys.php');
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CREATE ACTION ================================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='c'){
  if(test_input_paramkeyKO1()){
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
   exit();
  }
  
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__paramnames` SET
     `fld_key_parnams`     = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_key_parnams'])     ."'
   , `fld_label_parnams`   = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_label_parnams'])   ."'
   , `fld_comment_parnams` = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_comment_parnams']) ."'
   , `fld_json_parnams`    = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_json_parnams'])    ."'
   , `fld_isuser_parnams`  =  ".$_SESSION[PGMK][NAV][BNF]['fld_isuser_parnams']              ."
   , `fld_order_parnams`   = '{}'
   , `fld_tsupd_parnams`   = '".$GLOBALS['glob_setdate']                                     ."'
   , `fld_tscrt_parnams`   = '".$GLOBALS['glob_setdate']                                     ."'
  " ;
//  echo __FILE__ . ' ' . __LINE__ . ' $req6 =' . $req6 . '' ; exit();
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
    break;
    default;
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 2 );
    break;
   }
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
   exit();
  }else{
   sqllog1( $req6 , BNF , __LINE__ );
   $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 2 );
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
    exit();
   }else{
    $NewCode=mysqli_fetch_row($resIns);
    $NewCode=$NewCode[0];
    mysqli_free_result($resIns);
    SetSessionMessageAndLog1( txt2('the new value has been inserted_150_36') . ' ('.$NewCode.').' , BNF , __LINE__ , 3);
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=n&id='.$NewCode);
    exit();
   }
  }
 }
}else{ // get action

 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= GET ACTION ========================================================================
 //=================================================================================================================================
 //=================================================================================================================================
 $o1=htmlHead1(array());
 $js1=array();
// echo __LINE__ . '$_SESSION[PGMK]=<pre>' . var_export( $_SESSION[PGMK] , true ) . '</pre>'; exit();
 //=================================================================================================================================
 //============================================= GET DELETE ========================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='d'){ // delete action
  $id=(isset($_GET['id'])&&is_numeric($_GET['id']))?$_GET['id']:0;
  if($id==0){
   header("HTTP/1.1 303 See Other");header('Location: zz_paramkeys.php');
   exit();
  }else{
   $xvalueName=incGetParam1($_GET['id']);
   if($xvalueName['fld_key_parnams']==''){
    header("HTTP/1.1 303 See Other");header('Location: zz_paramkeys.php');
    exit();
   }else{
    $o1.=displaySessionMessage1(BNF);
    $o1.='<form method="post" class="formDelete">'.CRLF;
    $o1.='   '.txtsys1('please_confirm_deletion_of').' : '.CRLF; 
    $o1.='   <br /><br /><b>'.enti1($xvalueName['fld_key_parnams'] . ' ' . $xvalueName['fld_label_parnams'] ).'</b><br /><br />'.CRLF;
    $o1.='   <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
    $o1.='   <input type="hidden" value="cd" name="a" id="a" />'."\r\n";
    $o1.='   <button type="submit" class="">Je confirme</button>'.CRLF;
    $o1.='</form>'."\r\n";
    $o1.=btl1();
   }
  }
 //=================================================================================================================================
 //============================================= GET UPDATE ========================================================================
 //=================================================================================================================================
 
 }else if(isset($_GET['a'])&&$_GET['a']=='u'){ // update action
  $xxxFldValues=array();
  $js1=array();
  $o1.='<h4>'.CRLF;
  $o1.=''.txt2('update a record_199_16').' ('.$_GET['id'].')'.CRLF;
  $o1.=btl1().CRLF;
  $o1.='</h4>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $name2=incGetParam1($_GET['id']);
  $xxxFldValues['fld_key_parnams']     =isset( $_SESSION[PGMK][NAV][BNF]['fld_key_parnams'] )     ? $_SESSION[PGMK][NAV][BNF]['fld_key_parnams']     : $name2['fld_key_parnams']     ;
  $xxxFldValues['fld_label_parnams']   =isset( $_SESSION[PGMK][NAV][BNF]['fld_label_parnams'] )   ? $_SESSION[PGMK][NAV][BNF]['fld_label_parnams']   : $name2['fld_label_parnams']   ;
  $xxxFldValues['fld_comment_parnams'] =isset( $_SESSION[PGMK][NAV][BNF]['fld_comment_parnams'] ) ? $_SESSION[PGMK][NAV][BNF]['fld_comment_parnams'] : $name2['fld_comment_parnams'] ;  
  $xxxFldValues['fld_json_parnams']    =isset( $_SESSION[PGMK][NAV][BNF]['fld_json_parnams'] )    ? $_SESSION[PGMK][NAV][BNF]['fld_json_parnams']    : $name2['fld_json_parnams']    ;  
  $xxxFldValues['fld_cntupd_parnams']  =isset( $_SESSION[PGMK][NAV][BNF]['fld_cntupd_parnams'] )  ? $_SESSION[PGMK][NAV][BNF]['fld_cntupd_parnams']  : $name2['fld_cntupd_parnams']  ;
  $xxxFldValues['fld_isuser_parnams']  =isset( $_SESSION[PGMK][NAV][BNF]['fld_isuser_parnams'] )  ? $_SESSION[PGMK][NAV][BNF]['fld_isuser_parnams']  : $name2['fld_isuser_parnams']  ;
 


  $o1.='<form method="post" >'.CRLF;

  $o1.=' <input type="hidden" value="u" name="a" id="a" />'.CRLF;
  $o1.=' <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;

  $o1.='<div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_key_parnams_216_23').'</div></div>'.CRLF;
  $o1.='  <div class="finp1">'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_key_parnams']).'" name="fld_key_parnams" id="fld_key_parnams" maxlength="64" />'.CRLF;
  $o1.='  </div>'.CRLF;
  $o1.='</div>'.CRLF;


  $o1.='<div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_label_parnams_243_23').'</div></div>'.CRLF;
  $o1.='  <div class="finp1">'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_label_parnams']).'" name="fld_label_parnams" id="fld_label_parnams" maxlength="64" />'.CRLF;
  $o1.='  </div>'.CRLF;
  $o1.='</div>'.CRLF;

  $o1.='<div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_json_parnams_251_22').'</div></div>'.CRLF;
  $o1.='  <div class="finp1">'.CRLF;
  $o1.='   <textarea  name="fld_json_parnams" id="fld_json_parnams" rows="25" style="width:100%" >'.enti1($xxxFldValues['fld_json_parnams']).'</textarea>'.CRLF;
  $o1.='  </div>'.CRLF;
  $o1.='</div>'.CRLF;


  $o1.='<div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_comment_parnams_224_22').'</div></div>'.CRLF;
  $o1.='  <div class="finp1">'.CRLF;
  $o1.='   <textarea  name="fld_comment_parnams" id="fld_comment_parnams"  rows="15" >'.enti1($xxxFldValues['fld_comment_parnams']).'</textarea>'.CRLF;
  $o1.='  </div>'.CRLF;
  $o1.='</div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt1('fld_isuser_parnams').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
  $retParam=displayParam2('yorno',$xxxFldValues['fld_isuser_parnams'],'fld_isuser_parnams',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  
  $o1.='<div class="fdiv1">'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="hidden" name="fld_cntupd_parnams" id="fld_cntupd_parnams" value="'.$xxxFldValues['fld_cntupd_parnams'].'" />'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('save_the_modification').'</button>'.CRLF;
  $o1.='  <div></div>'.CRLF;
  $o1.='</div>'.CRLF;



  $o1.='</form>'.CRLF;


  
 //=================================================================================================================================
 //============================================= GET VIEW ==========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='v'&&isset($_GET['id'])&&is_numeric($_GET['id'])){ // view action

 //=================================================================================================================================
 //============================================= GET CREATE ========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='c'){ // create action
 
  $o1.='<h2>'.txt2('Add a new record_251_20'). ' '.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $o1.='<form method="post" class="form1">'.CRLF;
 
  $fld_key_parnams =isset($_SESSION[PGMK][NAV][BNF]['fld_key_parnams'] )?$_SESSION[PGMK][NAV][BNF]['fld_key_parnams']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_key_parnams_216_23').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_key_parnams).'" name="fld_key_parnams" id="fld_key_parnams" maxlength="64" style="width:100%;max-width:66em;" autofocus="autofocus" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  
  $fld_label_parnams =isset($_SESSION[PGMK][NAV][BNF]['fld_label_parnams'] )?$_SESSION[PGMK][NAV][BNF]['fld_label_parnams']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_label_parnams_243_23').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_label_parnams).'" name="fld_label_parnams" id="fld_label_parnams" maxlength="64" style="width:100%;max-width:66em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

$example='{
 "comment" : "This is an example",
 "fields"  : [
  {
   "name"                : "language_code" ,
   "type"                : "char"          ,
   "length"              : 6               ,
   "comment"             : "fr, en, en-us, fr-be, ...."
  },
  {
   "name"                : "n"    ,
   "type"                : "char" ,
   "length"              : 64     ,
   "languageTranslation" : true   ,
   "comment1" : "the language name in it\'s original ",
   "comment2" : "language ( fr => Français , en => English )." ,
   "comment3" : "languageTranslation must be set in one field to true or false" 
  }
 ],
 "key" : "language_code"
}';
  $fld_json_parnams =isset($_SESSION[PGMK][NAV][BNF]['fld_json_parnams'] )?$_SESSION[PGMK][NAV][BNF]['fld_json_parnams']:$example;
  
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_json_parnams_251_22').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <textarea  name="fld_json_parnams" id="fld_json_parnams"  rows="15" >'.enti1($fld_json_parnams).'</textarea>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  
  $fld_comment_parnams =isset($_SESSION[PGMK][NAV][BNF]['fld_comment_parnams'] )?$_SESSION[PGMK][NAV][BNF]['fld_comment_parnams']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_comment_parnams_224_22').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <textarea  name="fld_comment_parnams" id="fld_comment_parnams"  rows="15" >'.enti1($fld_comment_parnams).'</textarea>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  

  $fld_isuser_parnams =isset($_SESSION[PGMK][NAV][BNF]['fld_isuser_parnams'] )?$_SESSION[PGMK][NAV][BNF]['fld_isuser_parnams']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt1('fld_isuser_parnams').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
  $retParam=displayParam2('yorno',$fld_isuser_parnams,'fld_isuser_parnams',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('record_the_element').'</button>'.CRLF;
  $o1.='   <input type="hidden" value="0" name="id1" id="id1" />'.CRLF;
  $o1.='   <input type="hidden" value="c" name="a" id="a" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  
 }
 $o1.=htmlFoot0(array('js' => $js1));
 dw1($o1);
 if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);
} 