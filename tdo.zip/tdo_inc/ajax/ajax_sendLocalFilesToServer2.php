<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 $fileOutput='';
 $someErrors=array();
 openDb2();
 $oneError=false;
 $ret['data']['keysOK']=array();
 $conn_id=ftp_connect($_SESSION[PGMK]['ftp__server'],21,3);
 if($conn_id==false){
  $ret['message'][]= __LINE__ .' : connexion KO to ' . $_SESSION[PGMK]['ftp__server'];
  $oneError=true;
 }else{
  if(ftp_login($conn_id, $_SESSION[PGMK]['ftp__user'], $_SESSION[PGMK]['ftp__password'])){ // Tentative d'identification
   if(ftp_pasv($conn_id, true)){
    $ret['message'][]= __LINE__ .' : ftp_pasv OK ' . $_SESSION[PGMK]['ftp__server'];
   }else{
    $ret['message'][]= __LINE__ .' : ftp_pasv KO ' . $_SESSION[PGMK]['ftp__server'] . '' ;
   }
   if(isset($ret['input']['require']) && $ret['input']['require'] !=''){
    require_once($ret['input']['require']);
   }else{
    require_once('zzz_tmp_ftp_presentInLocalAndAbsentOnRemote.php');   
   }
   $keyGlobal='__ftp_presentInLocalAndAbsentOnRemote';
   if(isset($ret['input']['keyGlobal']) && $ret['input']['keyGlobal'] !=''){
    $keyGlobal=$ret['input']['keyGlobal'];       
   }
   foreach($ret['input']['lstIds'] as $k1 => $v1){
    if(false===$oneError){
     $theFile=$GLOBALS[$keyGlobal]['data'][$v1];
     $retPut=@ftp_put( 
      $conn_id , 
      '/'.$_SESSION[PGMK]['ftp__path'].'/'.$theFile['path_local'] , 
      $theFile['path_local'] , 
      FTP_BINARY 
     );
     if(true!==$retPut){
      $ret['message'][]= __LINE__ .' : send file KO to ' . var_export( $theFile , true );
      $oneError=true;
     }else{
      $ret['data']['keysOK'][]=$v1;
     }
    }
   }
  }else{
   $ret['message'][]= __LINE__ .' : login ftp KO ';
   $err=1;
  }
  ftp_close($conn_id); // Fermeture de la connexion
 }
 if(false===$oneError){
  $ret['status']='OK';
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}