<?php  // € utf8 check with euro sign
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_incPath1'].'/__param_log.php');
checkGroupPages();
require_once $GLOBALS['glob_incPath1'].'/zz_inc_log1.php';

openDb1();
//========================================================================================================================
function btl1(){
 return '&nbsp;<a href="zz_log1.php" class="">'.txtsys1('back_to_the_list').'</a>';
}
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= POST ACTIONS  =====================================================================
 //=================================================================================================================================
 //=================================================================================================================================
// echo __LINE__ . '$_POST=<pre>' . var_export($_POST,true) . '</pre>'; exit();
 $_SESSION[PGMK][NAV][BNF]['fld_tag_log']               =isset($_POST['fld_tag_log'])               ?$_POST['fld_tag_log']               : ''; // null possible
 $_SESSION[PGMK][NAV][BNF]['fld_timstp_log']            =isset($_POST['fld_timstp_log'])            ?$_POST['fld_timstp_log']            : ''; 
 //=================================================================================================================================
 //============================================= POST UPDATE =======================================================================
 //=================================================================================================================================
 if(isset($_POST['a'])&&$_POST['a']=='u'){ // update action
  if($_SESSION[PGMK]['login']!=1){
   header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
   exit();
  }
  $req6="UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__log` SET
     `fld_tag_log`    = ".($_SESSION[PGMK][NAV][BNF]['fld_tag_log']==''?'NULL':"'".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_tag_log']) ."'")."
   , `fld_timstp_log` ='".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_timstp_log'])."'
   WHERE `fld_id_log`=".$_POST['id1']."
  ";
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
     break;
    default   :
     $xtxterr=txtsys1('error').' "' . __LINE__ . '" mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    break;
   }
   header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
  }else{
   if(isset($_POST['save_the_modification_and_back_to_list'])){
    header('Location: zz_log1.php');
    exit();
   }else{
    $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('the_modification_has_been_recorded_at') . ' ' . substr($GLOBALS['glob_setdate'],11);
    header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }
  }
 //=================================================================================================================================
 //============================================= POST CONFIRM DELETE ===============================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='cd'){
  if($_SESSION[PGMK]['login']!=1){
   header('Location: zz_log1.php');
   exit();
  }
  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__log` WHERE `fld_id_log`=".$_POST['id1']." " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==1451){ // foreign key constraint
    $xtxterr=txtsys1('error').' "' . __LINE__ . '" ' . txtsys1('constraint_fail');
   }else{
    $xtxterr=txtsys1('error').' "' . __LINE__ . '" mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
   }
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
   header('Location: '.BNF.'?a=d&id='.$_POST['id1']);
   exit();
  }else{
   unset($_SESSION[PGMK][NAV][BNF]);
   header('Location: zz_log1.php');
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CREATE ACTION ================================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='c'){
  header('Location: zz_log1.php');
  exit();
 }
 
}else{ // get action

 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= GET ACTION ========================================================================
 //=================================================================================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='du'){ // duplicate action
  header('Location: '.BNF.'?a=c' );
  exit();
 }
 
 $o1=htmlHead1(array());
 $js1=array();
// echo __LINE__ . '$_SESSION[PGMK]=<pre>' . var_export( $_SESSION[PGMK] , true ) . '</pre>'; exit();
 //=================================================================================================================================
 //============================================= GET DELETE ========================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='d'){ // delete action
  $id=(isset($_GET['id'])&&is_numeric($_GET['id']))?$_GET['id']:0;
  if($id==0){
   header('Location: zz_log1.php');
   exit();
  }else{
   $xvalueName=getinc_tdo_log1($_GET['id']);
   if($xvalueName['T0_fld_id_log']=='' || $_SESSION[PGMK]['login']!=1){
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_delete_this_value');
    header('Location: zz_log1.php');
    exit();
   }else{
    require_once $GLOBALS['glob_incPath1'].'/__tableDependencies1.php';
    $retDependantTables=dependentValuesExist1(0,'tdo_tbl__log',$_GET['id'] );
    if(isset($retDependantTables['valuesExist']) && $retDependantTables['valuesExist']==true){
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <div>'.CRLF;
     $o1.=__LINE__ . ' '.txtsys1('dependent_values_exist').''.CRLF;
     $o1.=' <ul>'.CRLF;
     foreach( $retDependantTables['tables'] as $k1 => $v1){
      $o1.='  <li>'.$v1.'</li>'.CRLF;
     }
     $o1.=' </ul>'.CRLF;
     $o1.=' </div>'.CRLF;
     $o1.=btl1();
    }else{
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <form method="post" class="yyformDelete">'.CRLF;
     $o1.='   '.txtsys1('please_confirm_deletion_of').' : '.CRLF;
     $o1.='   <br /><br /><b>'.
           '('.$xvalueName['T0_fld_id_log'].') '.
           '</b><br />'.CRLF;
     $o1.='   <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
     $o1.='   <input type="hidden" value="cd" name="a" id="a" />'."\r\n";
     $o1.='   <button type="submit" class="yydanger">'.txtsys1('i_confirm_the_deletion_button').'</button>'.CRLF;
     $o1.=btl1();
     $o1.=' </form>'."\r\n";
      
    }
   }
  }
 //=================================================================================================================================
 //============================================= GET UPDATE ========================================================================
 //=================================================================================================================================
 
 }else if(isset($_GET['a'])&&$_GET['a']=='u'){ // update action
  $xxxFldValues=array();
  $js1=array();
  $o1.='<h2>'.txt2('update a log_156_20').' ('.$_GET['id'].')'.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $name2=getinc_tdo_log1($_GET['id']);
  $xxxFldValues['T0_fld_timstp_log']            =isset( $_SESSION[PGMK][NAV][BNF]['fld_timstp_log'] )            ? $_SESSION[PGMK][NAV][BNF]['fld_timstp_log']            : $name2['T0_fld_timstp_log']            ;
  $xxxFldValues['T0_fld_text_log']              =isset( $_SESSION[PGMK][NAV][BNF]['fld_text_log'] )              ? $_SESSION[PGMK][NAV][BNF]['fld_text_log']              : $name2['T0_fld_text_log']              ;
  $xxxFldValues['T0_fld_bnf_log']               =isset( $_SESSION[PGMK][NAV][BNF]['fld_bnf_log'] )               ? $_SESSION[PGMK][NAV][BNF]['fld_bnf_log']               : $name2['T0_fld_bnf_log']               ;
  $xxxFldValues['T0_fld_line_log']              =isset( $_SESSION[PGMK][NAV][BNF]['fld_line_log'] )              ? $_SESSION[PGMK][NAV][BNF]['fld_line_log']              : $name2['T0_fld_line_log']              ;
  $xxxFldValues['T0_fld_user_id_log']           =isset( $_SESSION[PGMK][NAV][BNF]['fld_user_id_log'] )           ? $_SESSION[PGMK][NAV][BNF]['fld_user_id_log']           : $name2['T0_fld_user_id_log']           ;
  $xxxFldValues['T0_fld_typ_log']               =isset( $_SESSION[PGMK][NAV][BNF]['fld_typ_log'] )               ? $_SESSION[PGMK][NAV][BNF]['fld_typ_log']               : $name2['T0_fld_typ_log']               ;
  $xxxFldValues['T0_fld_tag_log']               =isset( $_SESSION[PGMK][NAV][BNF]['fld_tag_log'] )               ? $_SESSION[PGMK][NAV][BNF]['fld_tag_log']               : $name2['T0_fld_tag_log']               ;


  $o1.='<form method="post" enctype="multipart/form-data">'.CRLF;

  $o1.=' <input type="hidden" value="u" name="a" id="a" />'.CRLF;
  $o1.=' <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
  $o1.=' <input type="hidden" value="'.$name2['T0_fld_timstp_log'].'" name="fld_timstp_log" id="fld_timstp_log" />'.CRLF;


  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div style="word-break:break-word;">'.txt2('fld_text_log_176_73').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <textarea readonly style="border-width:0;" autofocus="autofocus"  name="fld_text_log" id="fld_text_log"  rows="30" >'.htmlentities($xxxFldValues['T0_fld_text_log'],ENT_COMPAT).'</textarea>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div style="word-break:break-word;">'.txt2('fld_bnf_log_183_73').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   source =<span>'.enti1($xxxFldValues['T0_fld_bnf_log']).'</span>'.CRLF;
  $o1.='    &nbsp; &nbsp; , &nbsp; &nbsp; line =<span>'.enti1($xxxFldValues['T0_fld_line_log']).'</span>'.CRLF;
  $o1.='    &nbsp; &nbsp; , &nbsp; &nbsp; user id =<span>'.enti1($xxxFldValues['T0_fld_user_id_log']).'</span>'.CRLF;
  $retParam=displayParam1('log',$xxxFldValues['T0_fld_typ_log'],'fld_typ_log',array('unsetPossible'=>false,'dropDown'=>false));
  $o1.='    &nbsp; &nbsp; , &nbsp; &nbsp; type =<span>'.$retParam.'</span>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;



  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div style="word-break:break-word;">'.txt2('fld_tag_log_196_73').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <input  type="text" value="'.enti1($xxxFldValues['T0_fld_tag_log']).'" name="fld_tag_log" id="fld_tag_log" maxlength="64" style="width:100%;max-width:32em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.='<div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <button type="submit" class="">'.txtsys1('save_the_modification').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="save_the_modification_and_back_to_list">'.txtsys1('save_the_modification_and_back_to_list').'</button>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.='</div>'.CRLF;

  $o1.='</form>'.CRLF;

 //=================================================================================================================================
 //============================================= GET VIEW ==========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='v'&&isset($_GET['id'])&&is_numeric($_GET['id'])){ // view action
  // if you vant to do something here, go !
 //=================================================================================================================================
 //============================================= GET CREATE ========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='c'){ // create action
 
  $o1.='<h2>'.txt2('Add a new log_222_20'). ' '.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $o1.='<div class="yywarning">No create on log</div>'.CRLF;

 }
 $o1.=htmlFoot0(array('js' => $js1));
 dw1($o1);
 if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);
}
