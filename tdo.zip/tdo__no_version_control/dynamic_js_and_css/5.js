var globalCssSettings1={
    "main": {
        "mainBackgroundColor": {
            "hexValue": "E8F5E9",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 50",
            "hsvValue": "5,5,96",
            "rgbValue": "232,245,233",
            "type": "color"
        },
        "mainBackgroundColEnd": {
            "hexValue": "BFFCC6",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "127,24,99",
            "rgbValue": "191,252,198"
        },
        "mainTextColor": {
            "hexValue": "1B5E20",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 900",
            "hsvValue": "71,71,36",
            "rgbValue": "27,94,32",
            "type": "color"
        },
        "thinBorderColor": {
            "hexValue": "DCEDC8",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Light green 100",
            "hsvValue": "15,15,92",
            "rgbValue": "220,237,200",
            "type": "color"
        },
        "linkStartBackgroundColor": {
            "hexValue": "C8E6C9",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 100",
            "hsvValue": "13,13,90",
            "rgbValue": "200,230,201",
            "type": "color"
        },
        "linkEndBackground": {
            "hexValue": "66BB6A",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 400",
            "hsvValue": "45,45,73",
            "rgbValue": "102,187,106",
            "type": "color"
        },
        "linkUnsetTextColor": {
            "hexValue": "66BB6A",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 400",
            "hsvValue": "45,45,73",
            "rgbValue": "102,187,106",
            "type": "color"
        },
        "activeFilterBackground": {
            "hexValue": "ffff00",
            "type": "color"
        },
        "activeFilterColor": {
            "hexValue": "1B5E20",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 900",
            "hsvValue": "71,71,36",
            "rgbValue": "27,94,32",
            "type": "color"
        },
        "inputBorderWidth": {
            "type": "SomeValues",
            "valueList": "1px,2px,3px",
            "value": "2px",
            "hr_after": false
        }
    },
    "menu": {
        "topColor": {
            "hexValue": "A5D6A7",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 200",
            "hsvValue": "22,22,83",
            "rgbValue": "165,214,167",
            "type": "color"
        },
        "bottomColor": {
            "hexValue": "C8E6C9",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 100",
            "hsvValue": "13,13,90",
            "rgbValue": "200,230,201",
            "type": "color"
        },
        "textColor": {
            "hexValue": "1B5E20",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 900",
            "hsvValue": "71,71,36",
            "rgbValue": "27,94,32",
            "type": "color"
        },
        "borderColor": {
            "hexValue": "A5D6A7",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 200",
            "hsvValue": "22,22,83",
            "rgbValue": "165,214,167",
            "type": "color"
        },
        "activeBackgroundColor": {
            "hexValue": "81C784",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 300",
            "hsvValue": "35,35,78",
            "rgbValue": "129,199,132",
            "type": "color"
        }
    },
    "table": {
        "headerBackgroundColor": {
            "hexValue": "A5D6A7",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 200",
            "hsvValue": "22,22,83",
            "rgbValue": "165,214,167",
            "type": "color"
        },
        "headerTextColor": {
            "type": "color",
            "hexValue": "666666"
        },
        "linkTextColor": {
            "hexValue": "000000",
            "webValue": "000000",
            "webName": "black",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,0",
            "rgbValue": "0,0,0",
            "type": "color"
        },
        "nthchildBackgroundColor": {
            "hexValue": "D0E5D1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "122,9,90",
            "rgbValue": "208,229,209",
            "type": "color"
        }
    },
    "backgrounds": {
        "dangerBackground": {
            "hexValue": "EF5300",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "21,100,94",
            "rgbValue": "239,83,0",
            "type": "color"
        },
        "danger2Background": {
            "hexValue": "C64200",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "20,100,78",
            "rgbValue": "198,66,0"
        },
        "dangerText": {
            "hexValue": "E8F5E9",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 50",
            "hsvValue": "5,5,96",
            "rgbValue": "232,245,233",
            "type": "color"
        },
        "editBackground": {
            "hexValue": "388E3C",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 700",
            "hsvValue": "60,60,55",
            "rgbValue": "56,142,60",
            "type": "color"
        },
        "edit2Background": {
            "hexValue": "2C6D2E",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "121,59,43",
            "rgbValue": "44,109,46"
        },
        "editText": {
            "hexValue": "E8F5E9",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 50",
            "hsvValue": "5,5,96",
            "rgbValue": "232,245,233",
            "type": "color"
        },
        "successBackground": {
            "type": "color",
            "hexValue": "8BC34A"
        },
        "success2Background": {
            "hexValue": "8BC34A"
        },
        "successText": {
            "hexValue": "485B28",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "82,56,36",
            "rgbValue": "72,91,40"
        },
        "errorBackground": {
            "type": "color",
            "hexValue": "FD3131"
        },
        "error2Background": {
            "hexValue": "BA2525",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,80,73",
            "rgbValue": "186,37,37"
        },
        "errorText": {
            "hexValue": "FFFF33",
            "webValue": "FFFF33",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "80,80,100",
            "rgbValue": "255,255,51"
        },
        "warningBackground": {
            "hexValue": "FFA500"
        },
        "warning2Background": {
            "hexValue": "C17A00",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "38,100,76",
            "rgbValue": "193,122,0"
        },
        "warningText": {
            "hexValue": "704500",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "37,100,44",
            "rgbValue": "112,69,0"
        }
    },
    "badge": {
        "badge0Background": {
            "type": "color",
            "hexValue": "FF0000"
        },
        "badge0TextColor": {
            "hexValue": "FFFFFF",
            "webValue": "FFFFFF",
            "webName": "white",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,100",
            "rgbValue": "255,255,255",
            "type": "color"
        },
        "badge1Background": {
            "hexValue": "7CFC00",
            "webValue": "7CFC00",
            "webName": "lawngreen",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "100,100,98",
            "rgbValue": "124,252,0",
            "type": "color"
        },
        "badge1TextColor": {
            "type": "color",
            "hexValue": "000000",
            "hr_after": true
        },
        "badge2Background": {
            "type": "color",
            "hexValue": "FFFF00"
        },
        "badge2TextColor": {
            "type": "color",
            "hexValue": "0000FF",
            "hr_after": true
        },
        "badge3Background": {
            "type": "color",
            "hexValue": "FF00FF"
        },
        "badge3TextColor": {
            "type": "color",
            "hexValue": "FFFF00",
            "hr_after": true
        },
        "badge4Background": {
            "type": "color",
            "hexValue": "00FFFF"
        },
        "badge4TextColor": {
            "type": "color",
            "hexValue": "0000FF",
            "hr_after": true
        },
        "badge5Background": {
            "type": "color",
            "hexValue": "4CAF50"
        },
        "badge5TextColor": {
            "type": "color",
            "hexValue": "FFEB3B",
            "hr_after": true
        },
        "badge6Background": {
            "type": "color",
            "hexValue": "FFEBEE"
        },
        "badge6TextColor": {
            "type": "color",
            "hexValue": "C62828",
            "hr_after": true
        },
        "badge7Background": {
            "type": "color",
            "hexValue": "1E88E5"
        },
        "badge7TextColor": {
            "type": "color",
            "hexValue": "E3F2FD",
            "hr_after": true
        },
        "badge8Background": {
            "type": "color",
            "hexValue": "FFE082"
        },
        "badge8TextColor": {
            "type": "color",
            "hexValue": "F06292",
            "hr_after": true
        }
    },
    "other": {
        "autocompleteInput": {
            "type": "yorno",
            "value": "0"
        }
    },
    "sizes": {
        "menuHeight": 55,
        "footerHeight": 20
    }
};