<?php
function getTdo_tables1($id){
 $nam=array();
 $n['fld_id_tables']                =0;
 $n['fld_id_server_tables']         =0;
 $n['fld_name_tables']              ='';
 $n['fld_system_tables']            ='0';
 $n['fld_view_tables']              =0;
 $n['fld_id_reftbl_of_view_tables'] =null; 
 $n['fld_log_tables']               =1; 
 $n['fld_remote_tables']            =1; 
 $n['fld_restore_transform_tables'] =''; 
 $n['fld_tsupd_tables']             ='1000-01-01 00:00:00';
 $n['fld_tscrt_tables']             ='1000-01-01 00:00:00';
 $n['fld_cntupd_tables']            =0;
 $sql='
  SELECT 
   T0.`fld_id_tables`                ,T0.`fld_id_server_tables`   , T0.`fld_name_tables`      ,T0.`fld_system_tables`            ,T0.`fld_view_tables`  ,
   T0.`fld_id_reftbl_of_view_tables` ,T0.`fld_log_tables`         , T0.`fld_remote_tables`    ,T0.`fld_restore_transform_tables` ,T0.`fld_tsupd_tables` ,
   T0.`fld_tscrt_tables`             ,   T0.`fld_cntupd_tables` 
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T0
  WHERE T0.`fld_id_tables` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['fld_id_tables']                = $row[0];
   $n['fld_id_server_tables']         = $row[1];
   $n['fld_name_tables']              = $row[2];
   $n['fld_system_tables']            = $row[3];
   $n['fld_view_tables']              = $row[4];
   $n['fld_id_reftbl_of_view_tables'] = $row[5];
   $n['fld_log_tables']               = $row[6];
   $n['fld_remote_tables']            = $row[7];
   $n['fld_restore_transform_tables'] = $row[8];
   $n['fld_tsupd_tables']             = $row[9];
   $n['fld_tscrt_tables']             = $row[10];
   $n['fld_cntupd_tables']            = $row[11];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
