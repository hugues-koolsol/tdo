<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 openDb1();
 $oneError=false;
 $someErrors=array();

 $req6="
  UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
    `fld_value_lngVals`   = '".addslashes1($ret['input']['value'])   ."'
  , `fld_tsupd_lngVals`   = '".$GLOBALS['glob_setdate']                  ."'
  WHERE
      `fld_key_lngVals`     = '".addslashes1($ret['input']['key'])     ."'
  AND `fld_lang_lngVals`    = '".addslashes1($ret['input']['lang'])    ."'
  AND `fld_type_lngVals`    = 'system'
 " ;
 $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
  $oneError=true;
  $someErrors[]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']) . ' req6=' . $req6;
 }
 if(false===$oneError){
  $ret['status']='OK';
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}