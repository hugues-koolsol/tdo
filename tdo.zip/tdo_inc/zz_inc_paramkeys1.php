<?php
function incGetParam1($id){
 $nam=array();
 $n['fld_id_parnams']      =0;
 $n['fld_key_parnams']     ='';
 $n['fld_label_parnams']   ='';
 $n['fld_comment_parnams'] ='';
 $n['fld_json_parnams']    ='';
 $n['fld_order_parnams']   ='';
 $n['fld_isuser_parnams']  =0;
 $n['fld_tscrt_parnams']   ='1000-01-01 00:00:00';
 $n['fld_tsupd_parnams']   ='1000-01-01 00:00:00';
 $n['fld_cntupd_parnams']  =0;
 $sql='
  SELECT 
   T0.`fld_id_parnams`      ,T0.`fld_key_parnams`     ,T0.`fld_label_parnams`   ,T0.`fld_comment_parnams` ,T0.`fld_json_parnams`    ,
   T0.`fld_order_parnams`   ,T0.`fld_isuser_parnams`  ,T0.`fld_tscrt_parnams`   ,T0.`fld_tsupd_parnams`   ,T0.`fld_cntupd_parnams`  
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramnames` T0
  WHERE T0.`fld_id_parnams` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['fld_id_parnams']      = $row[0];
   $n['fld_key_parnams']     = $row[1];
   $n['fld_label_parnams']   = $row[2];
   $n['fld_comment_parnams'] = $row[3];
   $n['fld_json_parnams']    = $row[4];
   $n['fld_order_parnams']   = $row[5];
   $n['fld_isuser_parnams']  = $row[6];
   $n['fld_tscrt_parnams']   = $row[7];
   $n['fld_tsupd_parnams']   = $row[8];
   $n['fld_cntupd_parnams']  = $row[9];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n); 
}
//===============================================================================================================
function sort_param_order2($a,$b){
 if(!isset($a['__order']) || !isset($b['__order'])) return 0;
 if($a['__order'] == $b['__order']) {
  return 0;
 }
 return ($a['__order'] < $b['__order']) ? -1 : 1; 
}
//===============================================================================================================
function writeParamFiles($id){
 $params=array();

 $dataParam=incGetParam1($id);
 $dataDefJsonParams=json_decode($dataParam['fld_json_parnams'],true);
 $dataDefOrder=json_decode($dataParam['fld_order_parnams'],true);
 
 $fieldNameDisplay='';
 $fieldNameParamSort='';
 $keyType='';
 foreach( $dataDefJsonParams['fields'] as $kparam => $vparam){
  if(isset($vparam['languageTranslation'])){
   $fieldNameDisplay=$vparam['name'];
   if($vparam['languageTranslation']==true){
    $fieldNameParamSort=$vparam['name'];
   }
  }
  if($vparam['name']==$dataDefJsonParams['key']){
   $keyType=$vparam['type'];
  }
 }
 $req6='
  SELECT  T0.`fld_json_parvals`  , T0.`fld_id_parvals`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramvalues` T0 
  WHERE T0.`fld_id_parname_parvals`  = ' . $id . '
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $data=null;
  while($mpsr6=mysqli_fetch_row($result6)){
   $data=json_decode($mpsr6[0],true);
   foreach($data as $k1 => $v1){
    $data[$k1]['fld_id_parvals']=$mpsr6[1];
    $params[$k1]=$data[$k1];
   }
  }
  mysqli_free_result($result6);
  
  if(1==$id){
   $ordres=json_decode($dataParam['fld_order_parnams'],true);
   if(!is_null($ordres)){
    foreach($params as $k1 => $v1){
     if(in_array($v1['fld_id_parvals'],$ordres)){
      $order = array_search($v1['fld_id_parvals'], $ordres);
      $params[$k1]['__order']=$order;
     }else{
      $params[$k1]['__order']=-1;
     }
    }
    uasort($params, 'sort_param_order2');
   }
   $toWrite='<'.'?php'.CRLF.'$GLOBALS[\'glob__availableLanguages\']='.var_export($params,true).';';
   file_put_contents($GLOBALS['glob_noVcPath1'].'/parameters/'.$dataParam['fld_key_parnams'].'.php',$toWrite);
  }else{
   $newTab=array();
   $newTab['param__Name__Display'] = $fieldNameDisplay;
   $newTab['param__Name__Sort']    = $fieldNameParamSort;
   $newTab['param__Name__key']     = $dataDefJsonParams['key'];
   $newTab['param__Key__type']     = $keyType;
   
   
   if($fieldNameParamSort!=''){
    foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang){
     foreach( $params as $k1 => $v1 ){
      $newTab['__values'][$klang][$v1[$newTab['param__Name__key']]]=array();
      foreach($v1 as $k2 => $v2){
       if($k2==$newTab['param__Name__Sort']){
        $newTab['__values'][$klang][$v1[$newTab['param__Name__key']]][$fieldNameDisplay]=$v2[$klang];
       }else{
        $newTab['__values'][$klang][$v1[$newTab['param__Name__key']]][$k2]=$v2;
       }
      }
     }
    }
    $newTabTrie=array();
    if(!is_null($dataDefOrder)){
     foreach( $newTab['__values'] as $k1 => $v1 ){
      if(isset($dataDefOrder[$k1])){
       foreach( $v1 as $k2 => $v2 ){
        if(in_array($v2['fld_id_parvals'],$dataDefOrder[$k1])){
         $order = array_search($v2['fld_id_parvals'], $dataDefOrder[$k1]);
         $newTab['__values'][$k1][$k2]['__order']=$order;
        }else{
         $newTab['__values'][$k1][$k2]['__order']=-1;
        }
       }
      }
     }
     foreach( $newTab as $k1 => $v1 ){
      if($k1=='__values'){
       foreach($v1 as $k2 => $v2){
        uasort($v2, 'sort_param_order2'); 
        $newTabTrie[$k1][$k2]=$v2;
       }
      }else{
       $newTabTrie[$k1]=$v1;
      }
     }
    }else{
     $newTabTrie=$newTab; 
    }
    $newTabTrie['param__definition']     = $dataDefJsonParams;
    $toWrite='<'.'?php'.CRLF.'$GLOBALS[\'param__'.$dataParam['fld_key_parnams'].'\']='.var_export($newTabTrie,true).';';
    file_put_contents($GLOBALS['glob_noVcPath1'].'/parameters/'.$dataParam['fld_key_parnams'].'.php',$toWrite);
   }else{ // keyNameParamSort = ''
    die('todo');
   }
  }
 }else{
  $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
  $_SESSION[PGMK][NAV]['errormessage'][]=$xtxterr;
  txtlog1($xtxterr , BNF , __LINE__ , 'error' );
 }
}
