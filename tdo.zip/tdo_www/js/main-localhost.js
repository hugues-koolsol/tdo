//=====================================================================================================================
function checkNullFieldInLinksBetweenTables1(par){
 if(par.tableId==0) return;
 document.getElementById(par.htmlfield).addEventListener('change' , 
  function(){   
   var r = new XMLHttpRequest();
   r.open("POST",'za_ajax.php?checkNullFieldInLinksBetweenTables1',true); // ajax_writeGeneratedFile2.php
   r.timeout=6000;
   r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
   r.onreadystatechange = function () {
    if (r.readyState != 4 || r.status != 200) return;
    try{
     var jsonRet=JSON.parse(r.responseText);
     if(jsonRet.status=='OK'){
      if(jsonRet.data.nullPossible=='YES'){
       document.getElementById('fld_link_mandatory_pglnks_1').checked=true;
      }else{
       document.getElementById('fld_link_mandatory_pglnks_0').checked=true;       
      }
      return;
     }else{
      console.error(r.responseText);
     }
    }catch(e){
     console.error(e,r);
    }
   };
   r.onerror=function(e){
    console.error('e=',e);
   }
   var data={
    funct          : 'checkNullFieldInLinksBetweenTables1',
    htmlfield      : par.htmlfield ,
    dbfield        : document.getElementById(par.htmlfield).value ,
    tableId        : par.tableId   ,
   }
   r.send('data='+encodeURIComponent(JSON.stringify(data)));
  }  
 );
}
//=====================================================================================================================
function fillLinkField1(optionadd,fieldName,inputId){
 var oldValue=document.getElementById(inputId).value;
 var element=document.getElementById(inputId);
 if(optionadd==0){
  element.value=fieldName
 }else{
  if(oldValue==''){
   element.value=fieldName
  }else{
   var newValue=oldValue+','+fieldName;
   element.value=newValue;
  }
 }
 if("createEvent" in document) {
  var evt = document.createEvent("HTMLEvents");
  evt.initEvent("change", false, true);
  element.dispatchEvent(evt);
 }else{
  element.fireEvent("onchange"); 
 }
}
//=====================================================================================================================
function insertThisPageInPagesAndGroup1(file_name,fld_id_pages,fld_id_grpspgs){
 var r = new XMLHttpRequest();
 r.open("POST",'za_ajax.php?insertThisPageInPagesAndGroup1',true); // ajax_writeGeneratedFile2.php
 r.timeout=6000;
 r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
 r.onreadystatechange = function () {
  if (r.readyState != 4 || r.status != 200) return;
  try{
   var jsonRet=JSON.parse(r.responseText);
   if(jsonRet.status=='OK'){
    if((jsonRet.fld_id_pages!=0 &&jsonRet.fld_id_grpspgs!=0)){
     document.getElementById('insertThisPageInPagesAndGroup1').innerHTML='Good job !';
    }else{
     document.getElementById('insertThisPageInPagesAndGroup1').innerHTML='Bad job !';     
    }
    return;
   }else{
    console.error(r.responseText);
   }
  }catch(e){
   console.error(e,r);
  }
 };
 r.onerror=function(e){
  console.error('e=',e);
 }
 var data={
  funct          : 'insertThisPageInPagesAndGroup1',
  file_name      : file_name                   ,
  fld_id_pages   : parseInt(fld_id_pages,10)   ,
  fld_id_grpspgs : parseInt(fld_id_grpspgs,10) ,
  lang           : globLang                    ,
 }
 r.send('data='+encodeURIComponent(JSON.stringify(data)));
}
//=====================================================================================================================
function fileNameChangeInGen1(){
 if(document.getElementById('file_name')){
  var r = new XMLHttpRequest();
  r.open("POST",'za_ajax.php?fileNameChangeInGen1',true); // ajax_writeGeneratedFile2.php
  r.timeout=6000;
  r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
  r.onreadystatechange = function () {
   if (r.readyState != 4 || r.status != 200) return;
   try{
    var jsonRet=JSON.parse(r.responseText);
    if(jsonRet.status=='OK'){
     if(false || (jsonRet.fld_id_pages==0||jsonRet.fld_id_grpspgs==0)){
      document.getElementById('insertThisPageInPagesAndGroup1').innerHTML='<a href="javascript:insertThisPageInPagesAndGroup1(\''+document.getElementById('file_name').value+'\','+jsonRet.fld_id_pages+','+jsonRet.fld_id_grpspgs+')">'+txt2('Give access to group 1_114_239')+'</a>';
     }
     return;
    }else{
     console.error(r.responseText);
    }
   }catch(e){
    console.error(r.responseText,e);
   }
  };
  r.onerror=function(e){
   console.error('e=',e);
  }
  var data={
   funct        : 'fileNameChangeInGen1',
   file_name    : document.getElementById('file_name').value,
  }
  r.send('data='+encodeURIComponent(JSON.stringify(data)));
 }
 
}
//=====================================================================================================================
function writeGeneratedFile2(fileType){
 var r = new XMLHttpRequest();
 r.open("POST",'za_ajax.php?writeGeneratedFile2',true); // ajax_writeGeneratedFile2.php
 r.timeout=6000;
 r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
 r.onreadystatechange = function () {
  if (r.readyState != 4 || r.status != 200) return;
  try{
   var jsonRet=JSON.parse(r.responseText);
   if(jsonRet.status=='OK'){
    if(fileType!='inc1'){
     setTimeout(fileNameChangeInGen1,50);
    }
    alert('Done !');
    return;
   }else{
    console.error(r.responseText);
   }
  }catch(e){
   console.error(r.responseText);
  }
 };
 r.onerror=function(e){
  console.error('e=',e);
 }
 var data={
  funct        : 'writeGeneratedFile2',
  type         : document.getElementById('file_name').getAttribute('data-type'),
  file_name    : document.getElementById('file_name').value,
  file_source  : document.getElementById('file_source').value,
 }
 r.send('data='+encodeURIComponent(JSON.stringify(data)));
}
//=====================================================================================================================
function writeGeneratedFile1(fileType){
 var r = new XMLHttpRequest();
 r.open("POST",'za_ajax.php?writeGeneratedFile1',true); // ajax_writeGeneratedFile1.php
 r.timeout=6000;
 r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
 r.onreadystatechange = function () {
  if (r.readyState != 4 || r.status != 200) return;
  try{
   var jsonRet=JSON.parse(r.responseText);
   if(jsonRet.status=='OK'){
    if(jsonRet.alreadyExist===true &&!confirm(txt2('Generated file already exists on disk\nClick ok to rewrite it._180_52'))){
     return;
    }
    writeGeneratedFile2(jsonRet.input.fileType);
    return;
   }else{
    console.error(r.responseText);
   }
  }catch(e){
   console.error(e,r);
  }
 };
 r.onerror=function(e){
  console.error(e);
 }
 var data={
  funct     : 'writeGeneratedFile1',
  type      : document.getElementById('file_name').getAttribute('data-type'),
  file_name : document.getElementById('file_name').value,
  fileType  : fileType,
 }
 r.send('data='+encodeURIComponent(JSON.stringify(data)));
}
//=====================================================================================================================
function checkAll1(idGeneralCheck,baseElement,prefix){
 var toCheck=document.getElementById(idGeneralCheck).checked;
 var lst=document.getElementById(baseElement).getElementsByTagName('input');
 for(var i=0;i<lst.length;i++){
  if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
   lst[i].checked=toCheck;
  }
 }
}
//=====================================================================================================================
function deleteFromSever1(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
   var data={
    funct   : 'deleteFromServer1',
    lstIds  : lstIds,
   };
   ajaxCall({
    data    : data,
    url     : 'deleteFromServer1',
    retu    : afterDeleteFromServer1,
    timeout : 30000
   });
  }
 }
}
//=====================================================================================================================
function afterDeleteFromServer1(dataJson,objSend){
 if(dataJson.status && dataJson.status=='OK'){
  if(dataJson.data.keysOK){
   for(var elem in dataJson.data.keysOK){
    document.getElementById('checkDeleteFromServer_'+dataJson.data.keysOK[elem]).checked=false;
    document.getElementById(dataJson.data.keysOK[elem]).style.display='none';
   }
  }
 }else{
  console.error(dataJson,objSend);
 }
}
//=====================================================================================================================
function putToSever1(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
   var data={
    funct   : 'sendLocalFilesToServer1',
    lstIds  : lstIds,
   };
   ajaxCall({
    data    : data,
    url     : 'sendLocalFilesToServer1',
    retu    : afterSendLocalFilesToServer1,
    timeout : 30000
   });
   
  }
 }
}
//=====================================================================================================================
function afterSendLocalFilesToServer1(dataJson,objSend){
 if(dataJson.status && dataJson.status=='OK'){
  if(dataJson.data.keysOK){
   for(var elem in dataJson.data.keysOK){
    document.getElementById('checkPutToServer_'+dataJson.data.keysOK[elem]).checked=false;
    document.getElementById(dataJson.data.keysOK[elem]).style.display='none';
   }
  }
 }else{
  console.error(dataJson,objSend);
 }
}
//=====================================================================================================================
function putToSever2(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
   var data={
    funct   : 'sendLocalFilesToServer2',
    lstIds  : lstIds,
   };
   ajaxCall({
    data    : data,
    url     : 'sendLocalFilesToServer2',
    retu    : afterSendLocalFilesToServer2,
    timeout : 30000
   });
  }
 }
}
//=====================================================================================================================
function translateJs1(i){
 var data={
  funct   : 'translateJs1',
  line    : document.getElementById('trjs__inp_'+i).getAttribute('data-line'),
  column  : document.getElementById('trjs__inp_'+i).getAttribute('data-col'),
  key     : document.getElementById('trjs__ke_'+i).innerHTML,
  value   : document.getElementById('trjs__va_'+i).value,
  page    : 'js/main.js',
  lang    : globLang ,
  elem    : 'trjs__va_'+i ,
  butt    : 'trjs__inp_'+i ,
  page_id : 0 ,
 }

 ajaxCall({
  data  : data,
  url   : 'translateJs1',
  retu  : afterTranslateJs1
 });

}
//=====================================================================================================================
function afterTranslateJs1(dataJson,objSend){
 document.getElementById(objSend.data.elem).style.background='lime';
 document.getElementById(objSend.data.butt).style.display='none';
}
//=====================================================================================================================
function afterSendLocalFilesToServer2(dataJson,objSend){
 if(dataJson.status && dataJson.status=='OK'){
  if(dataJson.data.keysOK){
   for(var elem in dataJson.data.keysOK){
    document.getElementById('checkPutToServer_'+dataJson.data.keysOK[elem]).checked=false;
    document.getElementById(dataJson.data.keysOK[elem]).style.display='none';
   }
  }else{
   console.error(dataJson,objSend);
  }
 }else{
  console.error(dataJson,objSend);
 }
}
//=====================================================================================================================
function putToSever3(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
   var data={
    funct     : 'sendLocalFilesToServer2',
    require   : 'zzz_tmp_ftp_lstSpecialFiles.php',
    keyGlobal : '__ftp_lstSpecialFiles',
    lstIds    : lstIds,
   };
   ajaxCall({
    data    : data,
    url     : 'sendLocalFilesToServer2',
    retu    : afterSendLocalFilesToServer2,
    timeout : 30000
   });
  }
 }
}
//=====================================================================================================================
function callBackTable1(context,tree){
 switch(context.action){
 
  case 'afterReorganize' :
   var txt='';
   for(var elem in tree){
    txt+=','+tree[elem].id;
   }
   document.getElementById('sortedPages2').value=txt.substr(1,txt.length);
  break;
  


  case 'afterFold' :
  break;
  
  
  
  case 'init' :
   
   var txt='';
   
   for(var elem in tree){
    txt+=','+tree[elem].id;
   }
   
   document.getElementById('sortedPages2').value=txt.substr(1,txt.length);
  break;
  
  
  
  default:
  break;
  
 }
}
//=====================================================================================================================
function sortTable2(par){
 var oMyTree2=new cMyTree1('oMyTree2','myTreeId2',jsonTree2,options2,callBackTable1); 
}
//=====================================================================================================================
function callBackTest1(context,tree){
 switch(context.action){
 
  case 'afterReorganize' :
   var txt='';
   for(var elem in tree){
    txt+='|'+tree[elem].id+','+tree[elem].parentId+'';
   }
   document.getElementById('sortedPages2').value=txt.substr(1,txt.length);
  break;
  


  case 'afterFold' :
  break;
  
  
  
  case 'init' :
   
   var txt='';
   
   for(var elem in tree){
    txt+='|'+tree[elem].id+','+tree[elem].parentId+'';
   }
   
   document.getElementById('sortedPages2').value=txt.substr(1,txt.length);
  break;
  
  
  
  default:
  break;
  
 }
}
var oMyTree2=null;
//=====================================================================================================================
function sortTest1(par){
 oMyTree2=new cMyTree1('oMyTree2','myTreeId2',jsonTree2,param1,callBackTest1); 
}
//=====================================================================================================================
//=====================================================================================================================
function localhostDoLocalPage(par){
 for( var i=0;i<par.length;i++){
  if(par[i].localhost && par[i].localhost===true ){
   switch(par[i].jsName){

    case 'fileNameChangeInGen1'                : fileNameChangeInGen1()                      ; break;
    case 'checkNullFieldInLinksBetweenTables1' : checkNullFieldInLinksBetweenTables1(par[i]) ; break;
    case 'design1'                             : design1(par[i])                             ; break;
    case 'sortTable2'                          : sortTable2(par[i])                          ; break;
    case 'sortTest1'                           : sortTest1(par[i])                           ; break;
    
    
    default:
     console.error(par[i].jsName + ' not treated in localhostDoLocalPage' )
     break;
   }
  }
 }
}
//=====================================================================================================================