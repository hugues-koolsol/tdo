<?php
$GLOBALS['glob_grpspgs']=array (
  'index.php' => 
  array (
    'm' => '1',
    'o' => '0',
    'aj' => '0',
    'id' => '1',
  ),
  'login.php' => 
  array (
    'm' => '1',
    'o' => '0',
    'aj' => '0',
    'id' => '2',
  ),
  'logout.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
    'id' => '3',
  ),
);