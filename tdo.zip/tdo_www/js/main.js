var globalTimeoutSlowServer=1500; // after 1.5 seconds of waiting response a message appears.
var dkW=0,dkH=0;
if(typeof (window.innerWidth) === 'number'){
 dkW = window.innerWidth;
 dkH = window.innerHeight;
}else{
 if(document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
  dkW = document.documentElement.clientWidth;
  dkH = document.documentElement.clientHeight;
 }else{
  if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
   dkW = document.body.clientWidth;
   dkH = document.body.clientHeight;
  }
 }
}
//console.log(dkW)
//=====================================================================================================================
function fillValueField1(fieldName,value){
 document.getElementById(fieldName).value=value;
}
//=====================================================================================================================
function fillLinkField1(fieldName,inputId){
 document.getElementById(inputId).value=fieldName;
}
//=====================================================================================================================
function closeColor1(divId){
 document.getElementById(divId).style.display='none';
}
//=====================================================================================================================
function putColor1(valueId,value,buttonId,divId,displayId,objTxt,withColorNull,searchColorMode,forceValue){
 console.log('objTxt=',objTxt,'forceValue=',forceValue,'displayId='+displayId);
 if(forceValue!==null && typeof(forceValue) != "undefined"){
  if(displayId!=''){
   document.getElementById(displayId).innerHTML=forceValue;
  }
  document.getElementById(valueId).value=forceValue;
  if(searchColorMode==1){
   if(forceValue==''){
    document.getElementById(buttonId).innerHTML=txt2('color all_30_54');
   }else if(forceValue=='NULL'){
    document.getElementById(buttonId).innerHTML=txt2('color null_32_54');    
   }else if(forceValue=='NOT NULL'){
    document.getElementById(buttonId).innerHTML=txt2('color not null_34_54');    
   }
  }
 }else{
  console.log('searchColorMode='+searchColorMode,'divId='+divId);
  if(searchColorMode==1){
   document.getElementById(valueId).value=value;
   document.getElementById(buttonId).innerHTML=value;
  }else{
   if(displayId!=''){
    var disp='';
    var obj=JSON.parse(objTxt);
    disp+='<div style="width:35px;height:35px;border:1px #eee inset;background-color:#'+obj.hexValue+'"></div>';   
    disp+='<div>'+obj.hexValue+(obj.webName!=''?','+obj.webName:'')+(obj.pantoneName!=''?',pantoneName='+obj.pantoneName:'')+'</div>';   
    document.getElementById(displayId).innerHTML=disp;
   }
   document.getElementById(valueId).value=objTxt;
  }
  // {"hexValue":"7FFFD4","webValue":"7FFFD4","webName":"aquamarine","pantoneName":"","hsvName":"50,50,100"}
 }
 closeColor1(divId); 
}
//=====================================================================================================================
function fillDivColor1(valueId,buttonId,divId,displayId,withColorNull,searchColorMode,colorInit){
 console.log('colorInit='+colorInit);

  var couleurActuelle=document.getElementById(valueId).value.substr(1).toUpperCase();
  if(couleurActuelle>='000000'&&couleurActuelle<='FFFFFF'){
  }else{
   couleurActuelle='FFFFFF';
  }
 
 var x='<div>';
 x+='<a href="javascript:closeColor1(\''+divId+'\')" style="color:red;">&times;</a>';
 if(searchColorMode==1){
  x+='<a href="javascript:putColor1(\''+valueId+'\',\'\',\''+buttonId+'\',\''+divId+'\',\''+displayId+'\',{},\''+withColorNull+'\',\''+searchColorMode+'\',\'\')">'+txt2('color all_30_54')+'</a>';
  x+='<a href="javascript:putColor1(\''+valueId+'\',\'\',\''+buttonId+'\',\''+divId+'\',\''+displayId+'\',{},\''+withColorNull+'\',\''+searchColorMode+'\',\'NULL\')">'+txt2('color null_32_54')+'</a>';
  x+='<a href="javascript:putColor1(\''+valueId+'\',\'\',\''+buttonId+'\',\''+divId+'\',\''+displayId+'\',{},\''+withColorNull+'\',\''+searchColorMode+'\',\'NOT NULL\')">'+txt2('color not null_34_54')+'</a>';
 }else{
  x+='<a href="javascript:putColor1(\''+valueId+'\',\'\',\''+buttonId+'\',\''+divId+'\',\''+displayId+'\',{},\''+withColorNull+'\',\''+searchColorMode+'\',\'\')">'+txt2('color null_32_54')+'</a>';  
 }
 x+='</div>';
 x+='<iframe width="468" height="500" border="0" ';
 x+=' src="js/_cpicker/index.html?version=0';
 x+='&withColorNull='+withColorNull+'';
 x+='&searchColorMode='+searchColorMode+'';
 x+='&divId='+divId+'';
 x+='&displayId='+displayId+'';
 x+='&buttonId='+buttonId+'';
 x+='&v='+couleurActuelle+'';
 x+='&c=putColor1(\''+valueId+'\',[value],[buttonId],[divId],[displayId],[obj],[withColorNull],[searchColorMode])"';
 x+='></iframe>';
 x+='<br style="clear:both;"/>';
// console.log('x=',x);
 document.getElementById(divId).innerHTML= x;
 
}
//=====================================================================================================================
function setColor1(valueId,buttonId,displayId,withColorNull,searchColorMode){ // 
// console.log(valueId,buttonId);
 var widthPop=470;
 var heightPop=500;
 try{
  var divId=document.getElementById('div_of_'+buttonId);
  if(null==divId){
//   console.log('ici');
   var divId=document.createElement('div');
   divId.id='div_of_'+buttonId;
   divId.style.width=widthPop+'px';
   divId.style.height=heightPop+'px';
   divId.style.position='absolute';
   divId.style.backgroundColor='white';
   divId.style.left='0px';
   divId.style.top='0px';
   divId.style.border='2px #eee outset';
   divId.style.border='2px #eee outset';
   divId.style.display='none';
   document.getElementsByTagName('body')[0].appendChild(divId);
//   console.log('ici 2');
  }
 }catch(e){
 }
 var pos1=document.getElementById(buttonId).getBoundingClientRect();
 divId.style.top=(parseInt(pos1.top,10)+getScrollTop1())+'px';
 if(parseInt(pos1.left,10)+widthPop>dkW){
  if((dkW-widthPop-30)<0){
   divId.style.left='0px';
  }else{
   divId.style.left=(dkW-widthPop-30)+'px';
  }
 }else{
  divId.style.left=parseInt(pos1.left,10)+'px';
 }
 divId.style.display='block';
 var hourInit=0,minutInit=0,secondInit=0;
 var yearInit=0,monthInit=0,dayInit=0;
 
 var value=document.getElementById(valueId).value;
 if(value=='NULL' ||value=='NOT NULL' || value==''){
  var colorInit='#ffffff';
 }else{
  var colorInit=value;
 }
 
 fillDivColor1(valueId,buttonId,'div_of_'+buttonId,displayId,withColorNull,searchColorMode,colorInit);
}

//=====================================================================================================================
function nextMonthDateTime1(valueId,buttonId,divId,nM,nY,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit){
 if(nM==12){
  nM='01';
  nY+=1;
 }else{
  nM=(nM+1)<10?'0'+(nM+1):nM+1;
 }
// console.log(nY+'-'+nM);
 fillDivDateTime1(valueId,buttonId,divId,nY+'-'+nM,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit);
}
//=====================================================================================================================
function previousMonthDateTime1(valueId,buttonId,divId,nM,nY,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit){
 if(nM==1){
  nM='12';
  nY-=1;
 }else{
  nM=(nM-1)<10?'0'+(nM-1):nM-1;
 }
// console.log(nY+'-'+nM);
 fillDivDateTime1(valueId,buttonId,divId,nY+'-'+nM,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit);
}
//=====================================================================================================================
function putDateTime1(nH,nM,nS,valueId,buttonId,divId,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit){
 if(nH==-3&&nM==-3&&nS==-3){
  var theTime='';
  var theTimeTxt=txt2('time all_20_23');
 }else if(nH==-2&&nM==-2&&nS==-2){
  var theTime='NOT NULL';
  var theTimeTxt=txt2('time not null_23_23');
 }else if(nH==-1&&nM==-1&&nS==-1){
  var theTime='NULL';
  var theTimeTxt=txt2('time null_26_23');
 }else{
//  var theTime=(nH<10?'0'+nH:nH)+'-'+(nM<10?'0'+nM:nM)+'-'+(nS<10?'0'+nS:nS);
  var theTime=yearInit+'-'+(monthInit<10?'0'+monthInit:monthInit)+'-'+(dayInit<10?'0'+dayInit:dayInit)+' '+(hourInit<10?'0'+hourInit:hourInit)+':'+(minutInit<10?'0'+minutInit:minutInit)+':'+(secondInit<10?'0'+secondInit:secondInit);
  var theTimeTxt=theTime;
 }
 closeDate1(divId);
 document.getElementById(valueId).value=theTime;
 document.getElementById(buttonId).innerHTML=theTimeTxt;
}
//=====================================================================================================================
function fixDateTime1(nY,nM,nD,valueId,buttonId,divId,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit){
 var yearInit=nY;
 var monthInit=nM;
 var dayInit=nD;
 console.log(yearInit+'-'+monthInit+'-'+dayInit+' '+hourInit+':'+minutInit+':'+secondInit);
 fillDivDateTime1(valueId,buttonId,divId,nY+'-'+nM,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit);
}
//=====================================================================================================================
function changeDateTime1(valueId,buttonId,divId,withDateTimeNull,searchDateTimeMode,yearInit,monthInit,dayInit){
 var hourInit=parseInt(document.getElementById('hour_'+divId).value,10);
 var minutInit=parseInt(document.getElementById('minute_'+divId).value,10);
 var secondInit=parseInt(document.getElementById('second_'+divId).value,10);
 fillDivDateTime1(valueId,buttonId,divId,yearInit+'-'+monthInit,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit);
}
//=====================================================================================================================
function fillDivDateTime1(valueId,buttonId,divId,startDate,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit){
// console.log('startDate='+startDate);
 console.log(yearInit+'-'+monthInit+'-'+dayInit+' '+hourInit+':'+minutInit+':'+secondInit);
 var dateIsSet=false;
 if(startDate==''){
  var value=document.getElementById(valueId).value;
  if(value=='NULL' ||value=='NOT NULL' || value=='' || value=='1000-01-01' ){
//   console.log('ici')
   var dt1=new Date();
  }else{
   var dt1=new Date(value.substr(0,4),parseInt(value.substr(5,2),10)-1,value.substr(8,2)); // 2017-01-01
   dateIsSet=true;
   var dt0=dt1;
  }
 }else{
  var value=document.getElementById(valueId).value;
  var theDay=1;
  if(!(value=='NULL' ||value=='NOT NULL' || value=='' || value=='1000-01-01') ){
   var dt0=new Date(value.substr(0,4),parseInt(value.substr(5,2),10)-1,value.substr(8,2)); // 2017-01-01
   dateIsSet=true;
   theDay=parseInt(value.substr(8),10);
  }
  var dt1=new Date(startDate.substr(0,4),parseInt(startDate.substr(5,2),10)-1 , theDay ); // 2017-01-01
 }
 var nM=dt1.getMonth()+1;
 var nY=dt1.getFullYear();
 var nD=dt1.getDate();
 var cM=nM<10?'0'+nM:''+nM;
 var cD=nD<10?'0'+nD:''+nD;
// console.log(nY,nM,nD);
 var sty1='font-size:1em;display:block;width:100%;height:100%;padding:0!important;min-width:0px;min-height:0px;color:#444;';
 var o1='';
 o1+='<table style="border:0;width:100%;padding:0;margin:0;">';
 o1+='<tr>';
 o1+='<td style="text-align:center;width:14.2%;height:35px;">';
 o1+='<a style="'+sty1+'font-size:1.3em;" href="javascript:previousMonthDateTime1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+')">&lt;</a>';
 o1+='</td>';
 o1+='<td style="text-align:center;width:14.2%;height:35px;">';
 o1+='&nbsp;';
 o1+='</td>';
 o1+='<td colspan="3" style="text-align:center;width:42.8%;height:35px;">';
 o1+=''+nY + '-' + cM;
 o1+='</td>';
 o1+='<td style="text-align:center;width:14.2%;height:35px;">';
 o1+='<a style="'+sty1+'color:red;font-size:1.5em;" href="javascript:closeDate1(\''+divId+'\')" >&times;</a>';
 o1+='</td>';
 o1+='<td style="text-align:center;width:14.2%;height:35px;">';
 o1+='<a style="'+sty1+'font-size:1.3em;" href="javascript:nextMonthDateTime1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+')">&gt;</a>';
 o1+='</td>';
 o1+='</tr>';
 
 var dtFirstDay=new Date(nY,nM-1,1); // 2017-11-01 = mercredi
 var dayOfFirstDay=dtFirstDay.getDay();
 if(dayOfFirstDay==0){
  dayOfFirstDay=7;
 }
 var today=new Date();
// console.log('dayOfFirstDay='+dayOfFirstDay);
 o1+='<tr>';
 for(var i=0;i<dayOfFirstDay-1;i++){
  o1+='<td style="text-align:center;width:14.2%;height:35px;border:0;">&nbsp;</td>';
 }
 if(nM==2){
  if((nY%4==0 && !(nY%100==0)) || nY%400==0  ){
   var maxDay=29;
  }else{
   var maxDay=28;
  }
 }else if(nM==4||nM==6||nM==9||nM==11){
  var maxDay=30;
 }else{
  var maxDay=31;  
 }
 var fontWeight='';
 var borderSty1='';
 var lineNumber=1;
 for( var i=1;i<=maxDay;i++){
  fontWeight='';
  borderSty1='';
  if(i==today.getDate()&&nM==today.getMonth()+1 && nY==today.getFullYear()){
   fontWeight='font-weight:bold;color:blue;'
  }
  if(i==dayInit&&nM==monthInit && nY==yearInit){
   borderSty1='border:1px red solid;'
  }
  var bckgrdColor='background-color:#fff;';
  if((dayOfFirstDay+1)%7==0 || (dayOfFirstDay+7)%7==0 ){
   bckgrdColor='background-color:#eee;';
   o1+='<td style="text-align:center;width:14.2%;height:35px;background-color:#eee;">';
  }else{
   o1+='<td style="text-align:center;width:14.2%;height:35px;">';    
  }
  o1+='<a style="'+sty1+fontWeight+borderSty1+bckgrdColor+'" href="javascript:fixDateTime1('+nY+','+nM+','+i+',\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+')" >'+i+'</a>';
  o1+='</td>';       
  if(dayOfFirstDay%7==0){
   o1+='</tr>';
   o1+='<tr>';
   lineNumber++;
  }
  dayOfFirstDay++;
 }
 o1+='</tr>';
 o1+='<tr>';
 
 
 var hInit='00',mInit='00',sInit='00',initialValue=document.getElementById(valueId).value;
 if(initialValue.length==8 && initialValue!='NOT NULL'){ // 2017-11-07 00:00:00
  hInit=initialValue.substr(11,2);
  mInit=initialValue.substr(14,2);
  sInit=initialValue.substr(17,2);
 }
 
 o1+='<table style="border:0;width:100%;padding:0;margin:0;">';
 
 var val='',selected='';
 
 o1+='<tr>';
 
 o1+='<td colspan="6" style="text-align:center;width:87.5%;">';
 
 o1+='<select id="hour_'+divId+'" onchange="changeDateTime1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+yearInit+','+monthInit+','+dayInit+')" style="min-height:40px;">';
 for(var i=0;i<=23;i++){
  selected='';
  val=i<10?'0'+i:i;
  if(hourInit==i) selected=' selected="selected" ';
  o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
 }
 o1+='</select>';
 
 o1+=' : <select id="minute_'+divId+'" onchange="changeDateTime1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+yearInit+','+monthInit+','+dayInit+')"  style="min-height:40px;">';
 for(var i=0;i<=59;i++){
  selected='';
  val=i<10?'0'+i:i;
  if(minutInit==i) selected=' selected="selected" ';
  o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
 }
 o1+='</select>';
 
 o1+=' : <select id="second_'+divId+'" onchange="changeDateTime1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+yearInit+','+monthInit+','+dayInit+')" style="min-height:40px;">';
 for(var i=0;i<=59;i++){
  selected='';
  val=i<10?'0'+i:i;
  if(secondInit==i) selected=' selected="selected" ';
  o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
 }
 o1+='</select>';
 
 o1+='</td>';

 o1+='</tr>';

 if(searchDateTimeMode==1){
  var colspan=2;
 }else{
  var colspan=4;
 }
 
 o1+='<tr>'; 
 o1+='<td colspan="'+colspan+'" style="text-align:center;height:35px;">';
 o1+='<a style="'+sty1+'font-size:0.9em;line-height:2em;" href="javascript:putDateTime1(-1,-1,-1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+')">'+txt2('datetime null_231_281')+'</a>';
 o1+='</td>';
 if(searchDateTimeMode==1){
  o1+='<td colspan="2" style="text-align:center;height:35px;">';
  o1+='<a style="'+sty1+'font-size:0.9em;line-height:2em;" href="javascript:putDateTime1(-2,-2,-2,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+')">'+txt2('datetime not null_235_282')+'</a>';
  o1+='</td>';
  
  o1+='<td colspan="2" style="text-align:center;height:35px;">';
  o1+='<a style="'+sty1+'font-size:0.9em;line-height:2em;" href="javascript:putDateTime1(-3,-3,-3,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+')">'+txt2('datetime all_239_282')+'</a>';
  o1+='</td>';
 }else{
  o1+='<td colspan="2" style="text-align:center;height:35px;">';
  o1+='';
  o1+='</td>';
  
 }
 o1+='</tr>';
 
 
 o1+='<tr>';
 o1+='<td colspan="4" style="text-align:center;height:35px;">';
 o1+='<span id=__span_for_'+valueId+'">'+yearInit+'-'+(monthInit<10?'0'+monthInit:monthInit)+'-'+(dayInit<10?'0'+dayInit:dayInit)+' '+(hourInit<10?'0'+hourInit:hourInit)+':'+(minutInit<10?'0'+minutInit:minutInit)+':'+(secondInit<10?'0'+secondInit:secondInit)+'</span>';
 o1+='</td>';
 o1+='<td colspan="2" style="text-align:center;height:35px;">';
 o1+='<a style="'+sty1+'" href="javascript:putDateTime1(0,0,0,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+')" style="font-size:1.5em;display:block;width:100%;height:100%;">&#10003;</a>';
 o1+='</td>';
 o1+='</tr>';
  
 
 o1+='</table>';
 document.getElementById(divId).innerHTML=o1;
}
//=====================================================================================================================
function setDateTime1(valueId,buttonId,withDateTimeNull,searchDateTimeMode){ // 
// console.log(valueId,buttonId);
 var widthPop=280;
 var heightPop=400;
 try{
  var divId=document.getElementById('div_of_'+buttonId);
  if(null==divId){
//   console.log('ici');
   var divId=document.createElement('div');
   divId.id='div_of_'+buttonId;
   divId.style.width=widthPop+'px';
   divId.style.height=heightPop+'px';
   divId.style.position='absolute';
   divId.style.backgroundColor='white';
   divId.style.left='0px';
   divId.style.top='0px';
   divId.style.border='2px #eee outset';
   divId.style.border='2px #eee outset';
   divId.style.display='none';
   document.getElementsByTagName('body')[0].appendChild(divId);
//   console.log('ici 2');
  }
 }catch(e){
 }
 var pos1=document.getElementById(buttonId).getBoundingClientRect();
 divId.style.top=(parseInt(pos1.top,10)+getScrollTop1())+'px';
 if(parseInt(pos1.left,10)+widthPop>dkW){
  divId.style.left=(dkW-widthPop-30)+'px';
 }else{
  divId.style.left=parseInt(pos1.left,10)+'px';
 }
 divId.style.display='block';
 var hourInit=0,minutInit=0,secondInit=0;
 var yearInit=0,monthInit=0,dayInit=0;
 
 var value=document.getElementById(valueId).value;
 if(value=='NULL' ||value=='NOT NULL' || value==''){
  var dt1=new Date();
  hourInit   = dt1.getHours();
  minutInit  = dt1.getMinutes();
  secondInit = dt1.getSeconds();
 }else{
  var dt1=new Date(value.substr(0,4),parseInt(value.substr(5,2),10)-1,value.substr(8,2)); // 2017-01-01 01:02:03
  hourInit  = parseInt(value.substr(11,2),10);
  minutInit = parseInt(value.substr(14,2),10);
  hourInit  = parseInt(value.substr(17,2),10);
 }
 monthInit=dt1.getMonth()+1;
 yearInit=dt1.getFullYear();
 dayInit=dt1.getDate();
 console.log(yearInit,monthInit,dayInit,hourInit,minutInit,secondInit);
 
 fillDivDateTime1(valueId,buttonId,'div_of_'+buttonId,'',withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit);
}

//=====================================================================================================================
function putTime1(nH,nM,nS,valueId,buttonId,divId,withTimeNull,searchTimeMode){
 if(nH==-3&&nM==-3&&nS==-3){
  var theTime='';
  var theTimeTxt=txt2('time all_20_23');
 }else if(nH==-2&&nM==-2&&nS==-2){
  var theTime='NOT NULL';
  var theTimeTxt=txt2('time not null_23_23');
 }else if(nH==-1&&nM==-1&&nS==-1){
  var theTime='NULL';
  var theTimeTxt=txt2('time null_26_23');
 }else{
//  var theTime=(nH<10?'0'+nH:nH)+'-'+(nM<10?'0'+nM:nM)+'-'+(nS<10?'0'+nS:nS);
  var theTime=document.getElementById('hour_'+divId).value+':'+document.getElementById('minute_'+divId).value+':'+document.getElementById('second_'+divId).value;
  var theTimeTxt=theTime;
 }
 closeDate1(divId);
 document.getElementById(valueId).value=theTime;
 document.getElementById(buttonId).innerHTML=theTimeTxt;
}
//=====================================================================================================================
function closeTime1(divId){
 document.getElementById(divId).style.display='none';
}
//=====================================================================================================================
function changeTime1(divId){
 var newVal=document.getElementById('hour_'+divId).value+' : '+document.getElementById('minute_'+divId).value+' : '+document.getElementById('second_'+divId).value;
}
//=====================================================================================================================
function fillDivTime1(valueId,buttonId,divId,startTime,withTimeNull,searchTimeMode){
// console.log('startDate='+startDate);

 var hInit='00',mInit='00',sInit='00',initialValue=document.getElementById(valueId).value;
 if(initialValue.length==8 && initialValue!='NOT NULL'){ // 00:00:00
  hInit=initialValue.substr(0,2);
  mInit=initialValue.substr(3,2);
  sInit=initialValue.substr(6,2);
 }
 
 var sty1='font-size:1em;display:block;width:100%;height:100%;padding:0!important;min-width:0px;min-height:0px;color:#444;';
 var o1='';
 o1+='<table style="border:0;width:100%;padding:0;margin:0;">';
 o1+='<tr>';
 
 
 if(searchTimeMode!=1){ 
  o1+='<td colspan="4" style="text-align:center;height:35px;width:50%;">';
  o1+='<a style="'+sty1+'" href="javascript:putTime1(-1,-1,-1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withTimeNull+','+searchTimeMode+')" >'+txt2('time null_26_23')+'</a>';
  o1+='</td>';
 }else{
  o1+='<td colspan="4" style="text-align:center;height:35px;width:50%;">';
  o1+='<a style="'+sty1+'" href="javascript:putTime1(-3,-3,-3,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withTimeNull+','+searchTimeMode+')">'+txt2('time all_20_23')+'</a>';
  o1+='</td>';
 }
 
 o1+='<td colspan="4" style="text-align:center;height:35px;width:50%;">';
 o1+='<a style="'+sty1+'color:red;" href="javascript:closeTime1(\''+divId+'\')">&times;</a>';
 o1+='</td>';
 
 o1+='</tr>';
 
 
 var val='',selected='';
 
 o1+='<tr>';
 
 o1+='<td colspan="7" style="text-align:center;width:87.5%;">';
 
 o1+='<select id="hour_'+divId+'" onchange="changeTime1(\''+divId+'\')" style="min-height:40px;">';
 for(var i=0;i<=23;i++){
  selected='';
  val=i<10?'0'+i:i;
  if(hInit==val) selected=' selected="selected" ';
  o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
 }
 o1+='</select>';
 
 o1+=' : <select id="minute_'+divId+'" onchange="changeTime1(\''+divId+'\')"  style="min-height:40px;">';
 for(var i=0;i<=59;i++){
  selected='';
  val=i<10?'0'+i:i;
  if(mInit==val) selected=' selected="selected" ';
  o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
 }
 o1+='</select>';
 
 o1+=' : <select id="second_'+divId+'" onchange="changeTime1(\''+divId+'\')" style="min-height:40px;">';
 for(var i=0;i<=59;i++){
  selected='';
  val=i<10?'0'+i:i;
  if(sInit==val) selected=' selected="selected" ';
  o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
 }
 o1+='</select>';
 
 o1+='</td>';

 o1+='<td style="text-align:center;width:12.5%">';
 o1+='<a style="'+sty1+'" href="javascript:putTime1(0,0,0,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withTimeNull+','+searchTimeMode+')">&#10003;</a>';
 o1+='</td>';

 o1+='</tr>';

 if(searchTimeMode==1){
  o1+='<tr>';
  
  o1+='<td colspan="4" style="text-align:center;height:35px;width:50%;">';
  o1+='<a style="'+sty1+'" href="javascript:putTime1(-1,-1,-1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withTimeNull+','+searchTimeMode+')">'+txt2('time null_26_23')+'</a>';
  o1+='</td>';
  
  o1+='<td colspan="4" style="text-align:center;height:35px;width:50%;">';
  o1+='<a style="'+sty1+'" href="javascript:putTime1(-2,-2,-2,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withTimeNull+','+searchTimeMode+')">'+txt2('time not null_23_23')+'</a>';
  o1+='</td>';
  
  o1+='</tr>';
 }
 

 
 o1+='</table>';
 document.getElementById(divId).innerHTML=o1;
}
//=====================================================================================================================
function setTime1(valueId,buttonId,withTimeNull,searchTimeMode){ // 
// console.log(valueId,buttonId);
 var widthPop=300;
 var heightPop=130;
 try{
  var divId=document.getElementById('div_of_'+buttonId);
  if(null==divId){
//   console.log('ici');
   var divId=document.createElement('div');
   divId.id='div_of_'+buttonId;
   divId.style.width=widthPop+'px';
   divId.style.height=heightPop+'px';
   divId.style.position='absolute';
   divId.style.backgroundColor='white';
   divId.style.left='0px';
   divId.style.top='0px';
   divId.style.border='2px #eee outset';
   divId.style.display='none';
   document.getElementsByTagName('body')[0].appendChild(divId);
//   console.log('ici 2');
  }
 }catch(e){
 }
 var pos1=document.getElementById(buttonId).getBoundingClientRect();
 divId.style.top=(parseInt(pos1.top,10)+getScrollTop1())+'px';
 if(parseInt(pos1.left,10)+widthPop>dkW){
  divId.style.left=(dkW-widthPop-30)+'px';
 }else{
  divId.style.left=parseInt(pos1.left,10)+'px';
 }
 divId.style.display='block';
 fillDivTime1(valueId,buttonId,'div_of_'+buttonId,'',withTimeNull,searchTimeMode);
}
//=====================================================================================================================
function getScrollTop1(){
 var a=document.documentElement.scrollTop || window.pageYOffset || document.getElementsByTagName('body')[0].scrollTop || 0;
 a=parseInt(a,10);
 return a;
}
//=====================================================================================================================
function closeDate1(divId){
 document.getElementById(divId).style.display='none';
}

//=====================================================================================================================
function previousMonthDate1(valueId,buttonId,divId,nM,nY,withDateNull,searchDateMode){
 if(nM==1){
  nM='12';
  nY-=1;
 }else{
  nM=(nM-1)<10?'0'+(nM-1):nM-1;
 }
// console.log(nY+'-'+nM);
 fillDivDate1(valueId,buttonId,divId,nY+'-'+nM,withDateNull,searchDateMode);
}
//=====================================================================================================================
function nextMonthDate1(valueId,buttonId,divId,nM,nY,withDateNull,searchDateMode){
 if(nM==12){
  nM='01';
  nY+=1;
 }else{
  nM=(nM+1)<10?'0'+(nM+1):nM+1;
 }
// console.log(nY+'-'+nM);
 fillDivDate1(valueId,buttonId,divId,nY+'-'+nM,withDateNull,searchDateMode);
}
//=====================================================================================================================
function putDate1(nY,nM,nD,valueId,buttonId,divId,withDateNull,searchDateMode){
 if(nY==-2 && nM==-2 && nD==-2){
  var theDate='NOT NULL';
  var theDateTxt=txt2('not void_163_23');
 }else if(nY==-1 && nM==-1 && nD==-1){
  var theDate='NULL';
  var theDateTxt=txt2('void_166_23');
 }else if(nY==1000&&nM==1&&nD==1){
  var theDate='1000-01-01';
  if(searchDateMode==0){
   var theDateTxt=txt2('void_166_23');   
  }else{
   var theDateTxt=txt2('date all_169_23');
  }
 }else{
  var theDate=nY+'-'+(nM<10?'0'+nM:nM)+'-'+(nD<10?'0'+nD:nD);
  var theDateTxt=theDate;
 }
 closeDate1(divId);
 document.getElementById(valueId).value=theDate;
 document.getElementById(buttonId).innerHTML=theDateTxt;
}
//=====================================================================================================================
function previousYearDate1(valueId,buttonId,divId,nM,nY,withDateNull,searchDateMode){
 nY-=1;
 nM=(nM)<10?'0'+(nM):nM;
 fillDivDate1(valueId,buttonId,divId,nY+'-'+nM,withDateNull,searchDateMode);
}
//=====================================================================================================================
function nextYearDate1(valueId,buttonId,divId,nM,nY,withDateNull,searchDateMode){
 nY+=1;
 nM=(nM)<10?'0'+(nM):nM;
 fillDivDate1(valueId,buttonId,divId,nY+'-'+nM,withDateNull,searchDateMode);
}
//=====================================================================================================================
function fillDivDate1(valueId,buttonId,divId,startDate,withDateNull,searchDateMode){
 console.log('startDate='+startDate);
 var dateIsSet=false;
 if(startDate==''){
  var value=document.getElementById(valueId).value;
  if(value=='NULL' ||value=='NOT NULL' || value=='' || value=='1000-01-01' ){
//   console.log('ici')
   var dt1=new Date();
  }else{
   var dt1=new Date(value.substr(0,4),parseInt(value.substr(5,2),10)-1,value.substr(8,2)); // 2017-01-01
   var dt0=dt1;
   dateIsSet=true;
  }
 }else{
  var value=document.getElementById(valueId).value;
  var theDay=1;
  if(!(value=='NULL' ||value=='NOT NULL' || value=='' || value=='1000-01-01') ){
   var dt0=new Date(value.substr(0,4),parseInt(value.substr(5,2),10)-1,value.substr(8,2));
   dateIsSet=true;
   theDay=parseInt(value.substr(8),10);
  }
  var dt1=new Date(startDate.substr(0,4),parseInt(startDate.substr(5,2),10)-1 , theDay );
 }
 var nM=dt1.getMonth()+1;
 var nY=dt1.getFullYear();
 var nD=dt1.getDate();
 var cM=nM<10?'0'+nM:''+nM;
 var cD=nD<10?'0'+nD:''+nD;
// console.log(nY,nM,nD);
 var sty1='font-size:1em;display:block;width:100%;height:100%;padding:0!important;min-width:0px;min-height:0px;color:#444;';
 var sty2='text-align:center;width:14.2%;height:35px;border:1px #ccc solid;';
 var o1='';
 o1+='<table style="border:1px #eee solid;width:100%;padding:0;margin:0;border-collapse:collapse;">';
 o1+='<tr>';
 o1+='<td style="'+sty2+'">';
 o1+='<a style="'+sty1+'" href="javascript:previousYearDate1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateNull+','+searchDateMode+')">&lt;</a>';
 o1+='</td>';
 o1+='<td style="'+sty2+'">';
 o1+=nY;
 o1+='</td>';
 o1+='<td style="'+sty2+'">';
 o1+='<a style="'+sty1+'" href="javascript:nextYearDate1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateNull+','+searchDateMode+')">&gt;</a>';
 o1+='</td>';
 
 if(withDateNull==1 || searchDateMode==1){
  o1+='<td colspan="2"  style="'+sty2+'width:28.4%;">';    
  o1+='<a style="'+sty1+'font-size:0.8em;" href="javascript:putDate1(-1,-1,-1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateNull+','+searchDateMode+')">'+txt2('date null_281_216')+'</a>'; 
  o1+='</td>';
  if(searchDateMode!=0){
   o1+='<td colspan="2" style="'+sty2+'width:28.4%;">';    
   o1+='<a style="'+sty1+'font-size:0.8em;" href="javascript:putDate1(-2,-2,-2,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateNull+','+searchDateMode+')">'+txt2('date not null_284_216')+'</a>'; 
   o1+='</td>';    
  }
  o1+='</tr>';
 }
 
 
 
 o1+='</tr>';
 o1+='<tr>';
 o1+='<td style="'+sty2+'">';
 o1+='<a style="'+sty1+'" href="javascript:previousMonthDate1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateNull+','+searchDateMode+')">&lt;</a>';
 o1+='</td>';
 o1+='<td style="'+sty2+'">';
 o1+='<a style="'+sty1+'" href="javascript:putDate1(1000,1,1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateNull+','+searchDateMode+')">0</a>';
 o1+='</td>';
 o1+='<td colspan="3" style="'+sty2+'width:42.8%;">'; 
 o1+=''+nY + '-' + cM;
 o1+='</td>';
 o1+='<td  style="'+sty2+'">';
 o1+='<a style="'+sty1+'color:red;font-size:1.5em;" href="javascript:closeDate1(\''+divId+'\')">&times;</a>';
 o1+='</td>';
 o1+='<td  style="'+sty2+'">';
 o1+='<a style="'+sty1+'" href="javascript:nextMonthDate1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateNull+','+searchDateMode+')">&gt;</a>';
 o1+='</td>';
 o1+='</tr>';
 
 var dtFirstDay=new Date(nY,nM-1,1); // 2017-11-01 = mercredi
 var dayOfFirstDay=dtFirstDay.getDay();
 if(dayOfFirstDay==0){
  dayOfFirstDay=7;
 }
 var today=new Date();
// console.log('dayOfFirstDay='+dayOfFirstDay);
 o1+='<tr>';
 for(var i=0;i<dayOfFirstDay-1;i++){
  o1+='<td style="text-align:center;width:14.2%;height:35px;border:0;">&nbsp;</td>';
 }
 if(nM==2){
  if((nY%4==0 && !(nY%100==0)) || nY%400==0  ){
   var maxDay=29;
  }else{
   var maxDay=28;
  }
 }else if(nM==4||nM==6||nM==9||nM==11){
  var maxDay=30;
 }else{
  var maxDay=31;  
 }
 var fontWeight='';
 var borderSty1='';
 var lineNumber=1;
 for( var i=1;i<=maxDay;i++){
  fontWeight='';
  borderSty1='';
  if(i==today.getDate()&&nM==today.getMonth()+1 && nY==today.getFullYear()){
   fontWeight='font-weight:bold;color:blue;'
  }
  if(dateIsSet==true && i==nD&&nM==dt0.getMonth()+1 && nY==dt0.getFullYear()){
   borderSty1='border:1px red solid;'
  }
  var bckgrdColor='background-color:#fff;';
  if((dayOfFirstDay+1)%7==0 || (dayOfFirstDay+7)%7==0 ){
   o1+='<td style="'+sty2+'background-color:#eee;">';
   bckgrdColor='background-color:#eee;';
  }else{
   o1+='<td style="'+sty2+'">';    
  }
  o1+='<a style="'+sty1+fontWeight+borderSty1+bckgrdColor+'" href="javascript:putDate1('+nY+','+nM+','+i+',\''+valueId+'\',\''+buttonId+'\',\''+divId+'\')">'+i+'</a>';
  o1+='</td>';       
  if(dayOfFirstDay%7==0){
   o1+='</tr>';
   o1+='<tr>';
   lineNumber++;
  }
  dayOfFirstDay++;
 }
/* 
 if(withDateNull==1 || searchDateMode==1){
//  console.log(lineNumber);
  if(lineNumber<=5){
   o1+='</tr>';
   o1+='<tr>';
  }
  o1+='<td colspan="2"  style="'+sty2+'width:28.4%;">';    
  o1+='<a style="'+sty1+'font-size:0.8em;" href="javascript:putDate1(-1,-1,-1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateNull+','+searchDateMode+')">'+txt2('date null_281_216')+'</a>'; 
  o1+='</td>';
  console.log(searchDateMode);
  if(searchDateMode!=0){
   o1+='<td colspan="2" style="'+sty2+'width:28.4%;">';    
   o1+='<a style="'+sty1+'font-size:0.8em;" href="javascript:putDate1(-2,-2,-2,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateNull+','+searchDateMode+')">'+txt2('date not null_284_216')+'</a>'; 
   o1+='</td>';    
  }
  o1+='</tr>';
 }
*/ 
 
 o1+='</table>';
 document.getElementById(divId).innerHTML=o1;
}
//=====================================================================================================================
function setDate1(valueId,buttonId,withDateNull,searchDateMode){ // 
// console.log(valueId,buttonId);
 var widthPop=260;
 var heightPop=290;
 try{
  var divId=document.getElementById('div_of_'+buttonId);
  if(null==divId){
//   console.log('ici');
   var divId=document.createElement('div');
   divId.id='div_of_'+buttonId;
   divId.style.width=widthPop+'px';
   divId.style.height=heightPop+'px';
   divId.style.position='absolute';
   divId.style.backgroundColor='white';
   divId.style.left='0px';
   divId.style.top='0px';
   divId.style.border='2px #eee outset';
   divId.style.border='2px #eee outset';
   divId.style.display='none';
   document.getElementsByTagName('body')[0].appendChild(divId);
//   console.log('ici 2');
  }
 }catch(e){
 }
 var pos1=document.getElementById(buttonId).getBoundingClientRect();
 divId.style.top=(parseInt(pos1.top,10)+getScrollTop1())+'px';
 if(parseInt(pos1.left,10)+widthPop>dkW){
  divId.style.left=(dkW-widthPop-30)+'px';
 }else{
  divId.style.left=parseInt(pos1.left,10)+'px';
 }
 divId.style.display='block';
 fillDivDate1(valueId,buttonId,'div_of_'+buttonId,'',withDateNull,searchDateMode);
}
//=====================================================================================================================
function myConfirm1(thenGoTo){
 if(confirm(txt2('sure ?_18_18'))){
  document.location=thenGoTo;
 }
}
//=====================================================================================================================
function razDependant1(spanId,inputId){
 try{
  document.getElementById(spanId).innerHTML='';
 }catch(e){}
 try{
  document.getElementById(inputId).value='';
 }catch(e){}
 
}
//=====================================================================================================================
function updateParam1(buttonId,inputId){
 console.log('updateParam1='+inputId);
 var data={
  funct   : 'updateParam1',
  id      : document.getElementById(buttonId).getAttribute('data-id'),
  name    : document.getElementById(buttonId).getAttribute('data-name'),
  key     : document.getElementById(buttonId).getAttribute('data-key'),
  lang    : document.getElementById(buttonId).getAttribute('data-lang'),
  paramId : document.getElementById(buttonId).getAttribute('data-paramid'),
  value : document.getElementById(inputId).value
 };
 ajaxCall({
  data  : data,
  url   : 'updateParam1',
  retu  : afterUpdateParam1
 });
}
//=====================================================================================================================
function afterUpdateParam1(dataJson,objSend){
 console.log(dataJson,objSend);
}

//=====================================================================================================================
function menuDropBoot1(v){
 if(v.substr(0,7)=='jumpTo:'){
  document.location=v.substr(7);
 }else if(v.substr(0,15)=='setTranslation:'){
  translate1(v.substr(15));
 }else if(v.substr(0,8)=='setLang:'){
  setLanguage(v.substr(8));
 }else{
  console.log(v);
  document.location=String(document.location);
 }
 setTimeout(slowServer1,globalTimeoutSlowServer); 
}
//=====================================================================================================================
function setLanguage(k){
 var loc=String(document.location);
 if(loc.indexOf('&lang=')>=0){
  loc=loc.substr(0,loc.indexOf('&lang='))+loc.substr(loc.indexOf('&lang=')+8);
 }
 if(loc.indexOf('?lang=')>=0){
  if(loc.substr(loc.indexOf('?lang=')+8,1)=='&'){
   loc=loc.substr(0,loc.indexOf('?lang='))+'?'+loc.substr(loc.indexOf('?lang=')+9);
  }
 }
 if(loc.indexOf('?')>=0){
  loc+='&';
 }else{
  loc+='?';
 }
 loc+='lang='+k;
 document.location=loc;
}
//=====================================================================================================================
function translate1(page){
 var translate=getCookie('translate')
 if(translate==''||translate=='0'){
  setCookie('translate','1');
  document.location=String(document.location);
  return;
 }else{
  if(translate=='1'){
   setCookie('translate','0');
   document.location=String(document.location);
   return;
  }
 }
}
//=====================================================================================================================
function txt1(k){
 return k;
}
//=====================================================================================================================
function txt2(k){
 for(elem in globTablang){
  if(globTablang[elem].key===k){
   return globTablang[elem].value;
  }
 }
 return k;
}
//=====================================================================================================================
function onSortPagesOfGroups2(context,tree){
 console.log(context.action);
 switch(context.action){
  case 'afterReorganize' :
   console.log(tree);
   var listeDesElementsTries=[];
   for(var elem in tree){
    listeDesElementsTries.push(tree[elem].id);
   }
   var data={
    funct:'setSortPagesOfGroup1',
    sortListGroupId:document.getElementById('sortListGroupId').value,
    order:listeDesElementsTries,
   };
   ajaxCall({
    data  : data,
    url   : 'setSortPagesOfGroup1',
    retu  : afterSetSortPagesOfGroup2
   });
  break;
 }
}
//=====================================================================================================================
function afterSetSortPagesOfGroup2(dataJson,objSend){
 console.log(dataJson,objSend);
}
//=====================================================================================================================
function onSortParamWithLang2(context,tree){
 console.log(context,tree);
 var listeDesElementsTries=[]; 
 for(var elem in tree){
  listeDesElementsTries.push(tree[elem].id);
 }
 switch(context.action){
  case 'afterReorganize' :
  var data={
   funct   : 'setSortParamWithLang1',
   idParam : document.getElementById(context.divId).getAttribute('data-idlist'),
   lang    : document.getElementById(context.divId).getAttribute('data-lang'),
   order   : listeDesElementsTries,
  };
//  console.log(data);
  ajaxCall({
   data  : data,
   url   : 'setSortParamWithLang1',
   retu  : afterSetSortParamWithLang2
  });
  break;  
 }
}
//=====================================================================================================================
function afterSetSortParamWithLang2(dataJson,objSend){
 console.log(dataJson,objSend);
}
//=====================================================================================================================
function onSortParamWithoutLang2(context,tree){
 console.log(context,tree);
 var listeDesElementsTries=[]; 
 for(var elem in tree){
  listeDesElementsTries.push(tree[elem].id);
 }
 
 switch(context.action){
  case 'afterReorganize' :
  var data={
   funct   : 'setSortParamWithoutLang1',
   idParam : document.getElementById(context.divId).getAttribute('data-idlist'),
   order   : listeDesElementsTries,
  };
  console.log(data);

  ajaxCall({
   data  : data,
   url   : 'setSortParamWithoutLang1',
   retu  : afterSetSortParamWithoutLang2
  });

  break;
 }

}
//=====================================================================================================================
function afterSetSortParamWithoutLang2(dataJson,objSend){
 console.log(dataJson,objSend);
}
//=====================================================================================================================
function onSortParamWithoutLang(e){
 console.log('dans onSortParamWithoutLang, e=',e)
 var listName=e.target.id;
 var listeDesElementsTries=[];
 var lst=document.getElementById(listName).getElementsByTagName('li');
 for(var i=0;i<lst.length;i++){
  listeDesElementsTries.push(parseInt(lst[i].id.replace(/sort__p__/,''),10))
 }
 console.log('listName="'+listName+'" ',listeDesElementsTries,document.getElementById(listName).getAttribute('data-idlist'),document.getElementById(listName).getAttribute('data-paramname'));
 var data={
  funct:'setSortParamWithoutLang1',
  idParam:document.getElementById(listName).getAttribute('data-idlist'),
  paramName:document.getElementById(listName).getAttribute('data-paramname'),
  order:listeDesElementsTries,
 };
 ajaxCall({
  data  : data,
  url   : 'setSortParamWithoutLang1',
  retu  : afterSetSortParamWithoutLang1
 });
}
//=====================================================================================================================
function afterSetSortParamWithoutLang1(dataJson,objSend){
 console.log(dataJson,objSend);
}
//=====================================================================================================================
function modifierLeMotDePasse(divId,btnId,fieldName){
 var t='';
 if(document.getElementById(divId).innerHTML==''){
  document.getElementById(btnId).innerHTML=txt2('do not modify password_214_49');
  document.getElementById(divId).innerHTML=txt2('password_215_49')+' : <input type="password" value="" id="'+fieldName+'" name="'+fieldName+'" /><br />'+txt2('Confirmation_215_152')+' : <input type="password" value="" id="'+fieldName+'_confirm" name="'+fieldName+'_confirm" />';
 }else{
  document.getElementById(divId).innerHTML='';
  document.getElementById(btnId).innerHTML=txt2('Update the password_218_49');
 }
}
//=====================================================================================================================
function modifierLeMotDePasse2(divId,btnId,fieldName){
 var t='';
 if(document.getElementById(divId).innerHTML==''){
  document.getElementById(btnId).innerHTML=txt2('do not modify my password_225_49');
  var t1=txt2('my actual password_226_15')+' : <input type="password" value="" id="__actualpassword" name="__actualpassword" />';
  t1+='<br />'+txt2('my new password_227_21')+' : <input type="password" value="" id="'+fieldName+'" name="'+fieldName+'" />';
  t1+='<br />'+txt2('my new password confirm_228_21')+' : <input type="password" value="" id="'+fieldName+'_confirm" name="'+fieldName+'_confirm" />'
  document.getElementById(divId).innerHTML=t1;
 }else{
  document.getElementById(divId).innerHTML='';
  document.getElementById(btnId).innerHTML=txt2('Update my password_232_49');
 }
}
function mouseOverTranslate(s){
 document.getElementById(s).background='white'; 
}
function mouseOutTranslate(s){
 document.getElementById(s).background='red';
}
//=====================================================================================================================
function tanslateMenu2(fromId,id){
 ajaxCall({
  data  : {funct:'translateMenu2',value:document.getElementById(fromId).value,id:id,fromId:fromId},
  url   : 'translateMenu2',
  retu  : afterTanslateMenu2
 });
}
//=====================================================================================================================
function afterTanslateMenu2(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.fromId).style.background='lime';
}
//=====================================================================================================================
function tanslateMenu1(fromId,page,lang){
 ajaxCall({
  data  : {funct:'translateMenu1',value:document.getElementById(fromId).value,page:page,lang:lang,fromId:fromId},
  url   : 'translateMenu1',
  retu  : afterTanslateMenu1
 });
}
//=====================================================================================================================
function afterTanslateMenu1(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.fromId).style.background='lime';
}
//=====================================================================================================================
function launchTranslate(){
 ajaxCall({
  data  : {funct:'getPageToTranslate1',page:globBNF,page_id:zz_page_id},
  url   : 'getPageToTranslate1',
  retu  : afterTranslate1
 });
}
function getTranslateValueInit(key,lang){
 theValue='';
 theBackgroundColor='';
 if('the value must be numerical for the field'==key){
  if(lang=='fr'){
   theValue='la valeur doit être numérique pour le champ';
   theBackgroundColor='background-color:lightgreen;'
  }else if(lang=='en'){
   theValue='the value must be numerical for the field';
   theBackgroundColor='background-color:lightgreen;'
  }
 }
 else if('no_record_founded'==key){
  if(lang=='fr'){
   theValue='aucune valeur trouvée avec les critères indiqués';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='no values were founded with these criterias';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('page_title_list'==key){
  if(lang=='fr'){
   theValue='liste de';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='list of the ';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('add_a_new_record'==key){
  if(lang=='fr'){
   theValue='ajouter une nouvelle un nouveau ';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='add a new ';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('the new value has been inserted'==key){
  if(lang=='fr'){
   theValue='une nouvelle un nouveau xxx a été inséré';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='the new value has been inserted';
   theBackgroundColor='background-color:orange;'
  }
 } 
 else if('update a record'==key){
  if(lang=='fr'){
   theValue='modification d\'un d\'une xxx';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='modification of a xxx';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('Add a new record'==key){
  if(lang=='fr'){
   theValue='ajout d\'un d\'une xxx';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='add a new xxx';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if(key.indexOf('_id_')>=0){
  if(lang=='fr'){
   theValue='id';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='id';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if(key.indexOf('must not be empty')>=0){
  if(lang=='fr'){
   theValue='le la xxx ne doit pas être vide';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='the xxx must not be void';
   theBackgroundColor='background-color:orange;'
  }
 }
 
 return {theValue:theValue,theBackgroundColor:theBackgroundColor};
}
//=====================================================================================================================
function afterTranslate1(dataJson,objSend){
// console.log(dataJson,objSend);
 var bgColor='white';
 var out='';
 var theInitTranslatedValue={};
 if(dataJson.status=='OK'){
  var lstToTranslate='';
  lstToTranslate+='<tr><td colspan="5">'+globLang+'</td></tr>';
  var i=0;
//  console.log(dataJson.output);
  for(var elem in dataJson.output){
//   console.log(elem , dataJson.output[elem]);
   if(dataJson.output[elem].type=='txt1'){
    lstToTranslate+='<tr id="trjs__tr_'+i+'">';
    lstToTranslate+='<td style="width:35em;">';
    lstToTranslate+=''+globLang+'';
    theInitTranslatedValue=getTranslateValueInit(dataJson.output[elem].key,globLang);
    lstToTranslate+='<input type="text" value="'+ent1(theInitTranslatedValue.theValue)+'" id="trjs__va_'+i+'" style="width:30em;font-size:0.8em;'+theInitTranslatedValue.theBackgroundColor+'">';
    lstToTranslate+='<button onclick="translate2('+i+','+zz_page_id+','+dataJson.output[elem].lineNumber+','+dataJson.output[elem].colNumber+',\''+objSend.data.page+'\')" id="trjs__inp_'+i+'" style="min-width:15px;width:15px;padding:0;">T</button>';
    lstToTranslate+='</td>';
    lstToTranslate+='<td id="trjs__ke_'+i+'" style="background-color:'+bgColor+';">'+dataJson.output[elem].key+'</td>';
    lstToTranslate+='<td style="font-size:0.8em;">'+ent1(dataJson.output[elem].line)+'</td>';
    lstToTranslate+='</tr>';
   }
   i++;
  }
//  console.log('lstToTranslate=',lstToTranslate);
  if(lstToTranslate!=''){
   out+='<table border="1">'+lstToTranslate+'</table>';
  }
  var listeDesBoutonsTranslateAvecCles=[];
  var numberOfLanguages=0;
  for(var lang in globAvailableLanguages){
   numberOfLanguages++;
  }
  var elem2='';
  if(dataJson.translateValues!=null){
   var lstValTranslated='<table border="1" style="border-collapse:collapse;"><tr><th>key</th><th>lang</th><th>value</th></tr>';
   for(var elem in dataJson.translateValues){
    var countLanguage=0;
    for( var lang in globAvailableLanguages){
     countLanguage++;
     lstValTranslated+='<tr>';
     if(countLanguage==1){
      lstValTranslated+='<td rowspan="'+numberOfLanguages+'" style="white-space: pre-wrap;word-break: break-word;max-width: 301px;">'+elem+'</td>';
     }
     lstValTranslated+='<td>'+lang+'</td>';
     lstValTranslated+='<td>';
     if(dataJson.translateValues[elem][lang]){
      if(dataJson.translateValues[elem][lang].value != ''){
       lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem)+'" type="text" value="'+ent1(dataJson.translateValues[elem][lang].value)+'" style="width:30em;font-size:0.8em;" />';     
      }else{
       lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem)+'" type="text" value="'+ent1(dataJson.translateValues[elem][lang].value)+'" style="background-color:red;width:30em;font-size:0.8em;" />';     
      }
     }else{
      elem2=elem;
      if(elem.lastIndexOf('_')>=0){
       elem2=elem.substr(0,elem.lastIndexOf('_'));
       if(elem2.lastIndexOf('_')>=0){
        elem2=elem2.substr(0,elem2.lastIndexOf('_'));
       }
      }
      
      theInitTranslatedValue=getTranslateValueInit(elem2,lang);
      if(theInitTranslatedValue.theValue==''){
       lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem)+'" type="text" value="" style="background-color:red;width:30em;font-size:0.8em;" />';           
      }else{
       lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem)+'" type="text" value="'+ent1(theInitTranslatedValue.theValue)+'" style="width:30em;font-size:0.8em;'+theInitTranslatedValue.theBackgroundColor+'" />';           
      }
     }
     lstValTranslated+='<button ';
     lstValTranslated+=' type="button" ';
     lstValTranslated+=' id="'+lang+'__'+ent1(elem)+'" ';
     lstValTranslated+=' style="width:15px;height:35px;min-width:15px;min-height:35px;padding:0;border-radius:2px;"';
     lstValTranslated+=' data-pageid="'+zz_page_id+'"';
     lstValTranslated+=' data-fromValue="true"';
     lstValTranslated+=' data-otherSpan=""';
     lstValTranslated+=' data-idparent="translate__key_'+lang+'_'+ent1(elem)+'"';
     lstValTranslated+=' data-idtranslate="'+globBNF+'|'+ent1(elem)+'|'+lang+'"';
     lstValTranslated+='>T</button>';
     listeDesBoutonsTranslateAvecCles.push(lang+'__'+ent1(elem));
     lstValTranslated+='</td>';
    }
    lstValTranslated+='</tr>';
   }
   lstValTranslated+='</table>'
   out+=lstValTranslated;
  }
  
//  console.log('objSend=',objSend);
  out+='<button onclick="writeTranslationFiles1('+objSend.data.page_id+',\''+objSend.data.page+'\')">Générer les fichiers de traduction</button>';
  
  var lst=document.getElementsByTagName('span');
  var lstElements=[];
  for(var i=0;i<lst.length;i++){
   if(lst[i].className && lst[i].className=='forTranslation'){
    var parentIsAnchorOrButton=false;
    if(lst[i].parentNode.nodeName.toLowerCase()=='a' || lst[i].parentNode.nodeName.toLowerCase()=='button'){
     parentIsAnchorOrButton=true;
    }
    var newElement=document.createElement('button');
    newElement.innerHTML='T';
    newElement.type='button';
    newElement.style.width='15px';
    newElement.style.height='15px';
    newElement.style.minWidth='15px';
    newElement.style.minHeight='15px';
    newElement.style.padding='0';
    newElement.style.borderRadius='2px';
    newElement.setAttribute('data-idtranslate',lst[i].getAttribute('data-idtranslate'));
    newElement.setAttribute('data-idparent',lst[i].id);
    newElement.setAttribute('data-pageid',zz_page_id);
    if(parentIsAnchorOrButton){
     
     newElement.setAttribute('data-otherSpan','other__span__'+lst[i].id);
     var newSpan=document.createElement('span');
     newSpan.id='other__span__'+lst[i].id;
     newSpan.setAttribute('data-idtranslate',lst[i].getAttribute('data-idtranslate'));
     newSpan.setAttribute('data-idparent',lst[i].id);
     newSpan.contentEditable=true
     newSpan.contentEditable="true";
     newSpan.setAttribute("contenteditable", "true");
     newSpan.innerHTML=lst[i].innerHTML;
     newSpan.className='forTranslation2';
     lst[i].parentNode.parentNode.insertBefore(newElement, lst[i].parentNode.nextSibling);
     lst[i].parentNode.parentNode.insertBefore(newSpan, lst[i].parentNode.nextSibling);
    }else{
     newElement.setAttribute('data-otherSpan','');
     lst[i].parentNode.insertBefore(newElement, lst[i].nextSibling);
    }
    lstElements.push(newElement);
   }
  }
  
  
  document.getElementById('zztranslate').innerHTML=out;
  if(lstElements.length>0){
   for(var i=0;i<lstElements.length;i++){
    lstElements[i].addEventListener('click',addTranslation,false);
   }
  }
  
//  console.log('listeDesBoutonsTranslateAvecCles=' , listeDesBoutonsTranslateAvecCles );
  
  if(listeDesBoutonsTranslateAvecCles.length>0){
   for(var i=0;i<listeDesBoutonsTranslateAvecCles.length;i++){
    try{
     document.getElementById(listeDesBoutonsTranslateAvecCles[i]).addEventListener('click',addTranslation,false);
    }catch(e){
     console.log('e=',e,listeDesBoutonsTranslateAvecCles[i]);
    }
   }
   
  }
  
 }
}
//=====================================================================================================================
function translateJs1(i){
 var data={
  funct   : 'translateJs1',
  line    : document.getElementById('trjs__inp_'+i).getAttribute('data-line'),
  column  : document.getElementById('trjs__inp_'+i).getAttribute('data-col'),
  key     : document.getElementById('trjs__ke_'+i).innerHTML,
  value   : document.getElementById('trjs__va_'+i).value,
  page    : 'js/main.js',
  lang    : globLang ,
  elem    : 'trjs__va_'+i ,
  butt    : 'trjs__inp_'+i ,
  page_id : 0 ,
 }
 console.log(data);

 ajaxCall({
  data  : data,
  url   : 'translateJs1',
  retu  : afterTranslateJs1
 });

}
//=====================================================================================================================
function afterTranslateJs1(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.elem).style.background='lime';
 document.getElementById(objSend.data.butt).style.display='none';
}
//=====================================================================================================================
function translate2(i,page_id,lineNumber,columnNumber,pageName){
 var data={
  funct   : 'translatePage2',
  line    : lineNumber    ,
  column  : columnNumber  ,
  key     : document.getElementById('trjs__ke_'+i).innerHTML         ,
  value   : document.getElementById('trjs__va_'+i).value             ,
  page    : pageName ,
  lang    : globLang       ,
  elem    : 'trjs__va_'+i  ,
  butt    : 'trjs__inp_'+i ,
  page_id : page_id ,
 }
 ajaxCall({
  data  : data,
  url   : 'translatePage2',
  retu  : afterTranslate2
 });
 
}
//=====================================================================================================================
function afterTranslate2(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.elem).style.background='lime';
 document.getElementById(objSend.data.butt).style.display='none';
}
//=====================================================================================================================
function writeTranslationFiles1(pageId,pageName){
 var data={
  funct   : 'writeTranslationFiles1',
  page    : pageName ,
  page_id : pageId   ,
 }
 ajaxCall({
  data  : data,
  url   : 'writeTranslationFiles1',
  retu  : afterWriteTranslationFiles1
 });
}
//=====================================================================================================================
function afterWriteTranslationFiles1(dataJson,objSend){
 console.log(dataJson,objSend);
}
//=====================================================================================================================
function addTranslationJs1(e){
 var elem=e.srcElement?e.srcElement:e;
// console.log(elem);
 var targetText='';
 var srcZone='';
 srcZone=elem.getAttribute('data-idparent');
 targetText=document.getElementById(elem.getAttribute('data-idparent')).value;
 var targetTranslation=elem.getAttribute('data-idtranslate').split('|');
 var data={
  funct   : 'addTranslationJs1',
  key     : revent1(targetTranslation[1]),
  page    : targetTranslation[0],
  lang    : targetTranslation[2],
  value   : targetText,
  page_id : 0 ,
  srcZone : srcZone ,
 }
 ajaxCall({
  data  : data,
  url   : 'addTranslationJs1',
  retu  : afterAddTranslationJs1
 });
}
//=====================================================================================================================
function afterAddTranslationJs1(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.srcZone).style.background='lime';
}
//=====================================================================================================================
function addTranslation(e){
 var elem=e.srcElement?e.srcElement:e;
// console.log(elem);
 var targetText='';
 var srcZone='';
 if(elem.getAttribute('data-otherSpan')==''){
  srcZone=elem.getAttribute('data-idparent');
  if(elem.getAttribute('data-fromValue')=='true'){
   targetText=document.getElementById(elem.getAttribute('data-idparent')).value;
  }else{
   targetText=document.getElementById(elem.getAttribute('data-idparent')).innerHTML;
  }
  
 }else{
  srcZone=elem.getAttribute('data-otherSpan');
  if(elem.getAttribute('data-fromValue')=='true'){
   targetText=document.getElementById(elem.getAttribute('data-otherSpan')).value;
  }else{
   targetText=document.getElementById(elem.getAttribute('data-otherSpan')).innerHTML;
  }
 }
 var page_id=elem.getAttribute('data-pageid');
 var targetTranslation=elem.getAttribute('data-idtranslate').split('|');

 var data={
  funct   : 'translateText1',
  key     : revent1(targetTranslation[1]),
  page    : targetTranslation[0],
  lang    : targetTranslation[2],
  value   : targetText,
  page_id : page_id ,
  srcZone : srcZone ,
 }
 ajaxCall({
  data  : data,
  url   : 'translateText1',
  retu  : afterTranslateText1
 });
}
//=====================================================================================================================
function afterTranslateText1(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.srcZone).style.background='lime';
}
//=====================================================================================================================
function addTranslateSys1(i){
 var data={
  funct   : 'addTranslateSys1',
  key     : document.getElementById('trjs__ke_'+i).value,
  lang    : document.getElementById('trjs__la_'+i).value,
  value   : document.getElementById('trjs__va_'+i).value,
  i       : i
 }
 ajaxCall({
  data  : data,
  url   : 'addTranslateSys1',
  retu  : afterAddTranslateSys1
 });
}
//=====================================================================================================================
function afterAddTranslateSys1(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById('trjs__va_'+objSend.data.i).style.background='lime';
}
//====================================================================================================================
function getCookie(cn){
 var cookie=document.cookie;
 var cooKieValue='';
//    console.log(cookie,cn);
 var posStart=cookie.indexOf(cn+'=');
 if(posStart>=0){
  var pos2=cookie.indexOf(';',posStart+1);
  if(pos2===-1){
   pos2=cookie.length;
  }
  var cookieString=cookie.substr(posStart,pos2-posStart);
  cooKieValue=cookieString.substr(cn.length+1);
 }
 return cooKieValue;
}
//====================================================================================================================
function setCookie(cn,cv){
 var today=new Date();
 var expires_date=new Date(today.getTime()+(1000*60*60*24*365));
 document.cookie=encodeURI(cn)+'='+encodeURI(cv)+';expires='+expires_date.toGMTString();
} 
//=====================================================================================================================
function ent1(s){
 var x=s.replace(/</g,'&lt;');
 x=x.replace(/>/g,'&gt;');
 x=x.replace(/"/g,'&quot;');
 return x;
}
//=====================================================================================================================
function revent1(s){
 var x=s.replace(/&lt;/g,'<');
 x=x.replace(/&gt;/g,'>');
 x=x.replace(/&quote;/g,'"');
 return x;
}
//=====================================================================================================================
function ajaxCall(obj){
 var ajax=null;
 if(window.XMLHttpRequest){
  ajax=new XMLHttpRequest();
 }else if(window.ActiveXObject){
  ajax=new ActiveXObject("Microsoft.XMLHTTP");
 }
 if(ajax===null){
  alert('No ajax call on this browser');
  return;
 }
//  console.log(obj.url);
 ajax.open("POST",'za_ajax.php?'+obj.url,true);
 ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
 if(obj.timeout){
  ajax.timeout = obj.timeout;
 }else{
  ajax.timeout = 6000; // 6 secondes 
 }
 ajax.onreadystatechange=function anonymous(){
  if(ajax.readyState===4){
   var returnObject=null;
   if(ajax.status===200){
    try{
     returnObject=JSON.parse(ajax.responseText);
     probablementOffLine=false;
    }catch(e){
     console.log('Erreur probable dans le décodage après un appel ajax (vérifiez utf-8) %o',ajax,obj,e);
     return;
    }
    try{
     obj.retu(returnObject,obj);
    }catch(e){
     console.log('erreur de call %o',ajax,e);
     return;
    }
   }else{
    console.log('Erreur ajax 3 ',ajax);
    try{
     returnObject={status:'KO',message:'offline'};
     probablementOffLine=true;
     obj.retu(returnObject,obj);
    }catch(ec){
     console.log(ec,obj);
    }
    return;
   }
  }
 };
 try{
  ajax.send('data='+encodeURIComponent(JSON.stringify(obj.data)));
 }catch(er){
  console.log(er,obj);
  try{
   var returnObject={status:'KO',message:'offline'};
   obj.retu(returnObject,obj);
  }catch(ec){
   console.log(ec,obj);
  }
 }
}
//=====================================================================================================================
function displaySlowServer(){
 var opa=document.getElementById('sloserver1').style.opacity*100;
 if(opa<100){
  document.getElementById('sloserver1').style.opacity=opa/100+0.1;
  setTimeout(displaySlowServer,100);
 }
}
//=====================================================================================================================
function slowServer1(){
 var divId=document.createElement('div');
 divId.id='sloserver1';
 divId.style.top='55px';
 divId.style.left='0px';
 divId.style.position='fixed';
 divId.style.padding='8px';
 divId.style.zIndex=10000;
 divId.style.border='2px #eee outset';
 divId.style.border='2px #eee outset';
 divId.style.backgroundColor='yellow';
 divId.style.color='red';
 divId.style.textAlign='center';
 divId.style.fontSize='2em';
 divId.style.opacity=0.0;
 divId.innerHTML=txt2('Sorry, the server is very slow_1671_23');
 document.getElementsByTagName('body')[0].appendChild(divId);
 setTimeout(displaySlowServer,0);
}
//=====================================================================================================================
function clickLink1(e){
 console.log(e.target);
 try{
  e.target.className="unset";
 }catch(e1){
  console.log(e1);
 }
 setTimeout(slowServer1,globalTimeoutSlowServer);
}
//=====================================================================================================================
function clickButton1(e){
 try{
  e.target.style.visibility="hidden";
 }catch(e1){
  console.log(e1);
 }
 setTimeout(slowServer1,globalTimeoutSlowServer);
}
//=====================================================================================================================
function trySetMenuSelect(curUrl){
 var setUpSelectDone=0;
 try{
  var lst1=document.getElementById('menuDrop1').getElementsByTagName('option');
  for(var i=0;i<lst1.length;i++){
   if(lst1[i].value && lst1[i].value.indexOf('setTranslation')<0 && lst1[i].value.indexOf(curUrl)>=0){
    document.getElementById('menuDrop1').style.background='#'+globalCssSettings1['menu']['activeBackgroundColor']['hexValue'];
    lst1[i].selected="selected"; //document.getElementById('menuDrop1').selectedIndex=i; 
    setUpSelectDone=1;
    break;
   }
  }
  var lst2=document.getElementById('menuDrop2').getElementsByTagName('option');
  for(var i=0;i<lst2.length;i++){
   if(lst2[i].value && lst2[i].value.indexOf('setTranslation')<0 && lst2[i].value.indexOf(curUrl)>=0){
    document.getElementById('menuDrop2').style.background='#'+globalCssSettings1['menu']['activeBackgroundColor']['hexValue'];
    lst2[i].selected="selected"; //document.getElementById('menuDrop1').selectedIndex=i; 
    setUpSelectDone=2;
    break;
   }
  }
 }catch(e){}
 return setUpSelectDone;
}
//=====================================================================================================================
function fixMenu1(){
 var setUpSelectDone=-1,newUrl='',curUrl='';
 if('undefined' != typeof globalChooseUrlBack){ // is set in choose list
  curUrl=globalChooseUrlBack
 }else{
  curUrl=String(document.location);
 }
 curUrl=curUrl.substr(curUrl.lastIndexOf('/')+1);
 if(curUrl.indexOf('#')>0){
  curUrl=curUrl.substr(0,curUrl.indexOf('#'));
 }
 if(curUrl.indexOf('?')>0){
  curUrl=curUrl.substr(0,curUrl.indexOf('?'));
 }
 if(curUrl!=''){
  try{
   setUpSelectDone=trySetMenuSelect(curUrl);
   if(setUpSelectDone==0){
    if(globalPageList[curUrl] && globalPageList[curUrl].fld_isaction_pages=='1' && globalPageList[curUrl].fld_parentN_pages!='' ){
     if(globalPageList[curUrl])
     newUrl=globalPageList[globalPageList[curUrl].fld_parentN_pages].fld_name_pages;
     setUpSelectDone=trySetMenuSelect(newUrl);
     if(setUpSelectDone==0){
      var lst2=document.getElementById('menuScroller').getElementsByTagName('a');
      for(var i=0;i<lst2.length;i++){
       if(lst2[i].href && lst2[i].href.indexOf('setTranslation')<0 && lst2[i].href.indexOf(newUrl)>=0){
        lst2[i].style.background='#'+globalCssSettings1['menu']['activeBackgroundColor']['hexValue'];
        setUpSelectDone=3;
        break;
       }
      }
     }
    }
   }
  }catch(e){}
  if(setUpSelectDone==1 || setUpSelectDone==2){
   if(setUpSelectDone==1){
    var pos1=document.getElementById('menuDrop1').getBoundingClientRect();
    document.getElementById('menuScroller').scrollTo(pos1.left,0);
   }
   if(setUpSelectDone==2){
    var pos1=document.getElementById('menuDrop2').getBoundingClientRect();
    document.getElementById('menuScroller').scrollTo(pos1.left,0);
   }
  }
  if(setUpSelectDone==0){
   try{
    var lst1=document.getElementById('menuDrop1').getElementsByTagName('option');
    for(var i=0;i<lst1.length;i++){
     lst1[i].selected="";
    }
   }catch(e){}
   try{
    var lst2=document.getElementById('menuDrop2').getElementsByTagName('option');
    for(var i=0;i<lst2.length;i++){
     lst2[i].selected="";
    }
   }catch(e){}
  }
  var lst2=document.getElementById('menuScroller').getElementsByTagName('a');
  for(var i=0;i<lst2.length;i++){
   if(lst2[i].href && lst2[i].href.indexOf(curUrl)>=0){
    var pos=lst2[i].getBoundingClientRect();
    if(pos.left+pos.width>dkW){
     var qtScroll=parseInt((pos.left+pos.width)-dkW,10)
     document.getElementById('menuScroller').scrollTo(qtScroll+15,0);
     console.log(lst2[i].href , dkW , pos);    
    }
   }
  }
 }
} 
//=====================================================================================================================
window.onload=function(){ 
 fixMenu1();
 var lstb1=document.getElementsByTagName('body')[0].getElementsByTagName('button');
 for(var i=0;i<lstb1.length;i++){
  if(!(lstb1[i].onclick)){
   lstb1[i].addEventListener("click",clickButton1,false);
  }
 }
 var lsta1=document.getElementsByTagName('body')[0].getElementsByTagName('a');
 for(var i=0;i<lsta1.length;i++){
  if(lsta1[i].href && !(lsta1[i].href.indexOf('javascript')>=0)){
   lsta1[i].addEventListener("click",clickLink1,false);
  }
 }
}