

//=====================================================================================================================
function checkAll1(idGeneralCheck,baseElement,prefix){
// console.log(prefix,document.getElementById(idGeneralCheck).checked);
 var toCheck=document.getElementById(idGeneralCheck).checked;
 var lst=document.getElementById(baseElement).getElementsByTagName('input');
 for(var i=0;i<lst.length;i++){
  if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
   lst[i].checked=toCheck;
  }
 }
}
//=====================================================================================================================
function deleteFromSever1(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
   console.log(lstIds);
   var data={
    funct   : 'deleteFromServer1',
    lstIds  : lstIds,
   };
   ajaxCall({
    data    : data,
    url     : 'deleteFromServer1',
    retu    : afterDeleteFromServer1,
    timeout : 30000
   });
  }
 }
}
//=====================================================================================================================
function afterDeleteFromServer1(dataJson,objSend){
 if(dataJson.status && dataJson.status=='OK'){
  if(dataJson.data.keysOK){
   for(var elem in dataJson.data.keysOK){
    document.getElementById('checkDeleteFromServer_'+dataJson.data.keysOK[elem]).checked=false;
    document.getElementById(dataJson.data.keysOK[elem]).style.display='none';
   }
  }
 }else{
  console.log(dataJson,objSend);
 }
}
//=====================================================================================================================
function putToSever1(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
//   console.log(lstIds);
   var data={
    funct   : 'sendLocalFilesToServer1',
    lstIds  : lstIds,
   };
   console.log(data);
   
   ajaxCall({
    data    : data,
    url     : 'sendLocalFilesToServer1',
    retu    : afterSendLocalFilesToServer1,
    timeout : 30000
   });
   
  }
 }
}
//=====================================================================================================================
function afterSendLocalFilesToServer1(dataJson,objSend){
 if(dataJson.status && dataJson.status=='OK'){
  if(dataJson.data.keysOK){
   for(var elem in dataJson.data.keysOK){
    console.log(dataJson.data.keysOK[elem]);
    document.getElementById('checkPutToServer_'+dataJson.data.keysOK[elem]).checked=false;
    document.getElementById(dataJson.data.keysOK[elem]).style.display='none';
   }
  }
 }else{
  console.log(dataJson,objSend);
 }
}
//=====================================================================================================================
function putToSever2(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
   console.log(lstIds);
   var data={
    funct   : 'sendLocalFilesToServer2',
    lstIds  : lstIds,
   };
   ajaxCall({
    data    : data,
    url     : 'sendLocalFilesToServer2',
    retu    : afterSendLocalFilesToServer2,
    timeout : 30000
   });
  }
 }
}
//=====================================================================================================================
function afterSendLocalFilesToServer2(dataJson,objSend){
 if(dataJson.status && dataJson.status=='OK'){
  if(dataJson.data.keysOK){
   for(var elem in dataJson.data.keysOK){
    document.getElementById('checkPutToServer_'+dataJson.data.keysOK[elem]).checked=false;
    document.getElementById(dataJson.data.keysOK[elem]).style.display='none';
   }
  }else{
   console.log(dataJson,objSend);
  }
 }else{
  console.log(dataJson,objSend);
 }
}
//=====================================================================================================================
function putToSever3(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
   console.log(lstIds);
   var data={
    funct     : 'sendLocalFilesToServer2',
    require   : 'zzz_tmp_ftp_lstSpecialFiles.php',
    keyGlobal : '__ftp_lstSpecialFiles',
    lstIds    : lstIds,
   };
   ajaxCall({
    data    : data,
    url     : 'sendLocalFilesToServer2',
    retu    : afterSendLocalFilesToServer2,
    timeout : 30000
   });
  }
 }
}
//=====================================================================================================================