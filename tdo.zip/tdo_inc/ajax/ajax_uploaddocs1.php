<?php
//if($fd=fopen('toto.txt','a')){fwrite($fd,''.date('Y-m-d H:i:s')."\r\n".'$_FILES='.var_export($_FILES,true)."\r\n".'$_POST='.var_export($_POST,true)."\r\n".'$ret='.var_export($ret,true)."\r\n"); fclose($fd);}

$ret['status']='KO';
$ret['data']=array();

if(session_status()==PHP_SESSION_NONE){
 session_start();
}
$err=0;
if(true!==checkGroupAjaxPages()){
 $ret['message']='not authorized'; 
 $err=1;
}

if($err==0){
 if(!(isset($_FILES['afile']['error']) && $_FILES['afile']['error']==0)){
  $err=1;
  $ret['message']='transfer error'; 
 }
}

if($err==0){
 $isImage=false;
 if($_FILES['afile']['type']=='image/jpeg' ||
    $_FILES['afile']['type']=='image/jpg' ||
    $_FILES['afile']['type']=='image/gif' ||
    $_FILES['afile']['type']=='image/png' ||
    false
 ){
  $isImage=true;
  if($_FILES['afile']['type']=='image/jpeg' || $_FILES['afile']['type']=='image/jpg' ){
   $ext='jpg';
  }else if($_FILES['afile']['type']=='image/png' ){
   $ext='png';
  }else if($_FILES['afile']['type']=='image/gif' ){
   $ext='gif';
  }
 }else{
  $err=1;
  $ret['message']='file type not accepted : ' . $_FILES['afile']['type'];   
 }
}
$now=time();
$dir=$GLOBALS['glob_userPath1'].'/upload1/'.date('Y/m/d',$now);
//$realpath=realpath($GLOBALS['glob_userPath1']);
if(!is_dir($dir)){
 if(!mkdir($dir,0776,true)){
  $ret['message']='cannot create dir : ' . $dir;   
  $err=1;
 }
}
if($err==0){
 if(substr($_FILES['afile']['name'],-1*strlen($ext))==$ext){
  $fileName=date('Y-m-d-h-i-s',$now).'_'.rawurlencode($_FILES['afile']['name']);
 }else{
  $fileName=date('Y-m-d-h-i-s',$now).'_'.rawurlencode($_FILES['afile']['name']).'.'.$ext;
 }
 $path=$dir.'/'.$fileName;
 if(!move_uploaded_file($_FILES['afile']['tmp_name'],$path)){
  $ret['message']='cannot move file to path : ' . $path;   
  $err=1;
 }else{
  $width=0;
  $height=0;
  if($isImage==true){
   list($width, $height) = @getimagesize($path);
  }
  $ret['status']='OK';
  $ret['data']['path']=str_replace($GLOBALS['glob_userPath1'].'/','',$dir.'/'.$fileName);
  $ret['data']['isImage']=$isImage;
  $ret['data']['weight']=$_FILES['afile']['size'];
  $ret['data']['originalName']=rawurlencode($_FILES['afile']['name']);
  $ret['data']['width']=$width;
  $ret['data']['height']=$height;
  $ret['data']['type']=$_FILES['afile']['type'];
  
 }
}

if($err==0){
/*  
 if($fd=fopen('toto.txt','a')){
  fwrite($fd,''.date('Y-m-d H:i:s')."\r\n".'$_FILES='.var_export($_FILES,true)."\r\n".'$_POST='.var_export($_POST,true)."\r\n".'$ret='.var_export($ret,true)."\r\n");
  fclose($fd);
$_FILES=array (
  'afile' => 
  array (
    'name' => 'atlantis-2928-1920.jpg',
    'type' => 'image/jpeg',
    'tmp_name' => 'C:\\www\\php-7.0.11-Win32-VC14-x86\\tmp\\phpB72.tmp',
    'error' => 0,
    'size' => 2603359,
  ),
)
$_POST=array (
  'data' => '{"funct":"uploaddocs1"}',
)
$ret=array (
  'status' => 'KO',
  'message' => 
  array (
  ),
  'input' => 
  array (
    'funct' => 'uploaddocs1',
  ),
  'data' => 
  array (
  ),
)
 }
*/  
}
 
 //$dataUrl = 'data:' . $fileType . ';base64,' . base64_encode($fileContent);
