<?php // € utf8 check with euro sign
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
require_once($GLOBALS['glob_noVcPath1'].'/parameters/country.php');
checkGroupPages();
openDb1();
//========================================================================================================================
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 if(isset($_POST['buttonSort2']) && isset($_POST['sortedPages2']) && $_POST['sortedPages2']!=''){
  $sortedIds=explode('|',$_POST['sortedPages2']);
  $order=0;
  $newTab=array();
  foreach($sortedIds as $k1=>$v1){
   $values=explode(',',$v1);
   $newTab[]=array(
    'id'     => $values[0],
    'parent' => $values[1],
    'open'   => $values[2],
    'order'  => $order,
   );
   $order++;
  }
  if(count($newTab)>0){
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $newTab , true ) . '</pre>' ; exit(0);
   foreach($newTab as $k1 => $v1){
    $req6='
     UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` SET
        `fld_id_parent_zztests`       = ' . $v1['parent'] . '
      , `fld_order_in_parent_zztests` = ' . $v1['order']  . '
      , `fld_open_in_parent_zztests`  = ' . $v1['open']  . '
     WHERE `fld_id_zztests`    = '.$v1['id'].' 
    ';
    $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   }
   header('Location: zz_zztests1.php?m=1');
   exit();
  }
 }
 header('Location: '.BNF.'');
 exit();
}
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('sort zztests_49_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$req6='
 SELECT T0.`fld_id_zztests` , T0.`fld_yorno1_zztests` , T0.`fld_title32_zztests` , T0.`fld_id_parent_zztests` , T0.`fld_open_in_parent_zztests`
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` T0 ) 
 ORDER BY  T0.`fld_id_parent_zztests` , T0.`fld_order_in_parent_zztests`
';
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'id'       => (int)$mpsr6[0],
  'data'     => array( 'label' => ' ' .$mpsr6[2] . ' ' ), // displayParam1('yorno',$mpsr6[1],array('unsetPossible'=>true))
  'parentId' => (is_null($mpsr6[3])||$mpsr6[3]==''?0:(int)$mpsr6[3]),
  'isOpen'   => (int)$mpsr6[4],
  );
 }
 mysqli_free_result($result6);
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}

$o1.='<form method="post">';
$o1.=' <input type="text" id="sortedPages2" name="sortedPages2" value="" />';
$o1.=' <button type="submit" id="buttonSort2" name="buttonSort2" value="sortTodos" style="" >'.txt2('record_this_sort_order_76_101').'</button>';
$o1.='</form>';

$o1.='<div id="container2" style="max-width:80%;border:1px #f00 solid;overflow-y:scroll;max-height:500px;">';
$o1.='     <div id="myTreeId2"></div>';
$o1.='</div>';

$o1.='<br /><br /><br />';

$o1.='<script src="js/hdtree.js?v=20171122-1917"></script>';
$o1.='<script type="text/javascript">';
$o1.='var jsonTree2='.json_encode($data0).';';
$o1.='var param1={};'.CRLF;
$o1.='</script>';

$toFooterArray=array(
 'js' => array(
  array( 
   'jsName'                  => 'sortTest1'         ,
   'objectName'              => 'oMyTree2'        ,
   'elementToSort'           => 'myTreeId2'       ,
   'dataToSort'              => 'jsonTree2'       ,
   'options'                 => 'options2'        ,
   'callBack'                => 'afterSortTable1' ,
   'localhost'               => true
  ),
 ),
);
$o1.=htmlFoot0($toFooterArray);
dw1($o1);
cleanSession1();
