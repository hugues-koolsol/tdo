<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 openDb2();
 $req6="
  INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
    `fld_key_lngVals`     = '".addslashes1($ret['input']['page'])    ."'
  , `fld_lang_lngVals`    = '".addslashes1($ret['input']['lang'])    ."'
  , `fld_page_id_lngVals` = NULL
  , `fld_type_lngVals`    = 'menu'
  , `fld_value_lngVals`   = '".addslashes1($ret['input']['value'])   ."'
  , `fld_tsupd_lngVals`   = '".$GLOBALS['glob_setdate']                  ."'
  , `fld_tscrt_lngVals`   = '".$GLOBALS['glob_setdate']                  ."'
 " ;
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $ret['status']='OK';
 }else{
  echo 'mysqli_error() "'.mysqli_error($GLOBALS['glob_db'][0]['link']).'" , $req6='.$req6;
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}