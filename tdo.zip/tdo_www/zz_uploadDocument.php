<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();
if(!(isset($_GET['fld_id_uploadedDocs']) && is_numeric($_GET['fld_id_uploadedDocs']))){
 header('Location: index.php');
 exit(0);
}

$o1='';
$o1.=htmlHead1(array());


$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_uploadedDocs`            ,T0.`fld_name_uploadedDocs`          ,T0.`fld_originalName_uploadedDocs`  ,T0.`fld_isPicture_uploadedDocs`     ,T0.`fld_pictureWidth_uploadedDocs`  ,
   T0.`fld_pictureHeight_uploadedDocs` ,T0.`fld_documentType_uploadedDocs`  ,T0.`fld_weight_uploadedDocs` ,T0.`fld_path_uploadedDocs`          ,T0.`fld_userId_uploadedDocs`        
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__uploadeddocs` T0 ) 
 WHERE T0.`fld_id_uploadedDocs`='.$_GET['fld_id_uploadedDocs'].'
';
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0=array(
  'T0.fld_id_uploadedDocs'            =>$mpsr6[0], 
  'T0.fld_name_uploadedDocs'          =>$mpsr6[1], 
  'T0.fld_originalName_uploadedDocs'  =>$mpsr6[2], 
  'T0.fld_isPicture_uploadedDocs'     =>$mpsr6[3], 
  'T0.fld_pictureWidth_uploadedDocs'  =>$mpsr6[4], 
  'T0.fld_pictureHeight_uploadedDocs' =>$mpsr6[5], 
  'T0.fld_documentType_uploadedDocs'  =>$mpsr6[6], 
  'T0.fld_weight_uploadedDocs' =>$mpsr6[7], 
  'T0.fld_path_uploadedDocs'          =>$mpsr6[8], 
  'T0.fld_userId_uploadedDocs'        =>$mpsr6[9],
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}
if(count($data0)>0){
 $filePath=$GLOBALS['glob_userPath1'].DIRECTORY_SEPARATOR.$data0['T0.fld_path_uploadedDocs'];
// echo __FILE__ . ' ' . __LINE__ . ' $filePath.'.$filePath.' data0 = <pre>' . var_export( $data0 , true ) . '</pre>' ; exit(0);
 header('Content-Type: application/octet-stream');
 header("Content-Transfer-Encoding: Binary"); 
 header("Content-disposition: attachment; filename=\"" . $data0['T0.fld_originalName_uploadedDocs'] . "\""); 
 readfile($filePath);
 exit();
}

//========================================================================================================================
$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
