var globalCssSettings1={
    "main": {
        "mainBackgroundColor": {
            "hexValue": "ECEFF1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 50",
            "hsvValue": "2,2,94",
            "rgbValue": "236,239,241",
            "type": "color"
        },
        "mainBackgroundColEnd": {
            "hexValue": "DBDEE0",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "203,2,88",
            "rgbValue": "219,222,224"
        },
        "mainTextColor": {
            "hexValue": "263238",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 900",
            "hsvValue": "32,32,21",
            "rgbValue": "38,50,56",
            "type": "color"
        },
        "thinBorderColor": {
            "hexValue": "CFD8DC",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 100",
            "hsvValue": "5,5,86",
            "rgbValue": "207,216,220",
            "type": "color"
        },
        "linkStartBackgroundColor": {
            "hexValue": "ECEFF1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 50",
            "hsvValue": "2,2,94",
            "rgbValue": "236,239,241",
            "type": "color"
        },
        "linkEndBackground": {
            "hexValue": "CFD8DC",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 100",
            "hsvValue": "5,5,86",
            "rgbValue": "207,216,220",
            "type": "color"
        },
        "linkUnsetTextColor": {
            "hexValue": "CFD8DC",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 100",
            "hsvValue": "5,5,86",
            "rgbValue": "207,216,220",
            "type": "color"
        },
        "activeFilterBackground": {
            "hexValue": "ffff00",
            "type": "color"
        },
        "activeFilterColor": {
            "hexValue": "263238",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 900",
            "hsvValue": "32,32,21",
            "rgbValue": "38,50,56",
            "type": "color"
        },
        "inputBorderWidth": {
            "type": "SomeValues",
            "valueList": "1px,2px,3px",
            "value": "1px",
            "hr_after": false
        }
    },
    "menu": {
        "topColor": {
            "hexValue": "B0BEC5",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 200",
            "hsvValue": "10,10,77",
            "rgbValue": "176,190,197",
            "type": "color"
        },
        "bottomColor": {
            "hexValue": "607D8B",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 500",
            "hsvValue": "30,30,54",
            "rgbValue": "96,125,139",
            "type": "color"
        },
        "textColor": {
            "type": "color",
            "hexValue": "FFFFFF",
            "hr_after": true
        },
        "borderColor": {
            "hexValue": "90A4AE",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 300",
            "hsvValue": "17,17,68",
            "rgbValue": "144,164,174",
            "type": "color"
        },
        "activeBackgroundColor": {
            "hexValue": "455A64",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 700",
            "hsvValue": "31,31,39",
            "rgbValue": "69,90,100",
            "type": "color"
        }
    },
    "table": {
        "headerBackgroundColor": {
            "hexValue": "B0BEC5",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 200",
            "hsvValue": "10,10,77",
            "rgbValue": "176,190,197",
            "type": "color"
        },
        "headerTextColor": {
            "hexValue": "263238",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 900",
            "hsvValue": "32,32,21",
            "rgbValue": "38,50,56",
            "type": "color"
        },
        "linkTextColor": {
            "hexValue": "90A4AE",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 300",
            "hsvValue": "17,17,68",
            "rgbValue": "144,164,174",
            "type": "color"
        },
        "nthchildBackgroundColor": {
            "hexValue": "CFD8DC",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 100",
            "hsvValue": "5,5,86",
            "rgbValue": "207,216,220",
            "type": "color"
        }
    },
    "backgrounds": {
        "dangerBackground": {
            "type": "color",
            "hexValue": "FF0000"
        },
        "danger2Background": {
            "hexValue": "E50000",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,100,90",
            "rgbValue": "229,0,0"
        },
        "dangerText": {
            "hexValue": "ECEFF1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 50",
            "hsvValue": "2,2,94",
            "rgbValue": "236,239,241",
            "type": "color"
        },
        "editBackground": {
            "hexValue": "2196F3",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 500",
            "hsvValue": "86,86,95",
            "rgbValue": "33,150,243"
        },
        "edit2Background": {
            "hexValue": "1E87D8",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "206,86,85",
            "rgbValue": "30,135,216"
        },
        "editText": {
            "hexValue": "ECEFF1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 50",
            "hsvValue": "2,2,94",
            "rgbValue": "236,239,241",
            "type": "color"
        },
        "successBackground": {
            "hexValue": "7FFF00",
            "webValue": "7FFF00",
            "webName": "chartreuse",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "127,255,0"
        },
        "success2Background": {
            "hexValue": "72E500",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "90,100,90",
            "rgbValue": "114,229,0"
        },
        "successText": {
            "type": "color",
            "hexValue": "556B2F",
            "hr_after": true
        },
        "errorBackground": {
            "type": "color",
            "hexValue": "FD3131"
        },
        "error2Background": {
            "hexValue": "D32A2A",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,80,83",
            "rgbValue": "211,42,42"
        },
        "errorText": {
            "hexValue": "FFFF33",
            "webValue": "FFFF33",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "80,80,100",
            "rgbValue": "255,255,51"
        },
        "warningBackground": {
            "hexValue": "FFA500"
        },
        "warning2Background": {
            "hexValue": "E28F00",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "38,100,89",
            "rgbValue": "226,143,0"
        },
        "warningText": {
            "hexValue": "000000"
        }
    },
    "badge": {
        "badge0Background": {
            "hexValue": "D32F2F",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 700",
            "hsvValue": "77,77,82",
            "rgbValue": "211,47,47",
            "type": "color"
        },
        "badge0TextColor": {
            "hexValue": "ECEFF1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 50",
            "hsvValue": "2,2,94",
            "rgbValue": "236,239,241",
            "type": "color"
        },
        "badge1Background": {
            "hexValue": "26A69A",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Teal 400",
            "hsvValue": "77,77,65",
            "rgbValue": "38,166,154",
            "type": "color"
        },
        "badge1TextColor": {
            "hexValue": "ECEFF1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 50",
            "hsvValue": "2,2,94",
            "rgbValue": "236,239,241",
            "type": "color"
        },
        "badge2Background": {
            "type": "color",
            "hexValue": "FFFF00"
        },
        "badge2TextColor": {
            "type": "color",
            "hexValue": "0000FF",
            "hr_after": true
        },
        "badge3Background": {
            "type": "color",
            "hexValue": "FF00FF"
        },
        "badge3TextColor": {
            "type": "color",
            "hexValue": "FFFF00",
            "hr_after": true
        },
        "badge4Background": {
            "type": "color",
            "hexValue": "00FFFF"
        },
        "badge4TextColor": {
            "type": "color",
            "hexValue": "0000FF",
            "hr_after": true
        },
        "badge5Background": {
            "type": "color",
            "hexValue": "4CAF50"
        },
        "badge5TextColor": {
            "type": "color",
            "hexValue": "FFEB3B",
            "hr_after": true
        },
        "badge6Background": {
            "type": "color",
            "hexValue": "FFEBEE"
        },
        "badge6TextColor": {
            "type": "color",
            "hexValue": "C62828",
            "hr_after": true
        },
        "badge7Background": {
            "type": "color",
            "hexValue": "1E88E5"
        },
        "badge7TextColor": {
            "type": "color",
            "hexValue": "E3F2FD",
            "hr_after": true
        },
        "badge8Background": {
            "type": "color",
            "hexValue": "FFE082"
        },
        "badge8TextColor": {
            "type": "color",
            "hexValue": "F06292",
            "hr_after": true
        }
    },
    "other": {
        "autocompleteInput": {
            "type": "yorno",
            "value": "0"
        }
    },
    "sizes": {
        "menuHeight": 55,
        "footerHeight": 20
    }
};