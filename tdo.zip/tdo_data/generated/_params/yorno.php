<?php
$GLOBALS['param__yorno']=array (
  'param__Name__Display' => 'n',
  'param__Name__Sort' => 'n',
  'param__Name__key' => 'code',
  'param__Key__type' => 'int',
  '__values' => 
  array (
    'fr' => 
    array (
      1 => 
      array (
        'code' => '1',
        'n' => 'Oui',
        'badge' => 'badge1',
        'rule' => '0',
        'fld_id_parvals' => '29',
        '__order' => 0,
      ),
      0 => 
      array (
        'code' => '0',
        'n' => 'Non',
        'badge' => 'badge0',
        'rule' => '0',
        'fld_id_parvals' => '33',
        '__order' => 1,
      ),
    ),
    'en' => 
    array (
      1 => 
      array (
        'code' => '1',
        'n' => 'Yes',
        'badge' => 'badge1',
        'rule' => '0',
        'fld_id_parvals' => '29',
        '__order' => 0,
      ),
      0 => 
      array (
        'code' => '0',
        'n' => 'No',
        'badge' => 'badge0',
        'rule' => '0',
        'fld_id_parvals' => '33',
        '__order' => 1,
      ),
    ),
  ),
  'param__definition' => 
  array (
    'fields' => 
    array (
      0 => 
      array (
        'name' => 'code',
        'type' => 'int',
        'length' => 1,
        'comment' => '1:yes or 0:no',
      ),
      1 => 
      array (
        'name' => 'n',
        'type' => 'char',
        'length' => 16,
        'languageTranslation' => true,
      ),
    ),
    'key' => 'code',
    'id' => '2',
  ),
);