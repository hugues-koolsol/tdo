<?php
$GLOBALS['param__country']=array (
  'param__Name__Display' => 'n',
  'param__Name__Sort' => 'n',
  'param__Name__key' => 'country_code',
  'param__Key__type' => 'char',
  '__values' => 
  array (
    'fr' => 
    array (
      'BE' => 
      array (
        'country_code' => 'BE',
        'n' => 'Belgique',
        'badge' => 'badge0',
        'fld_id_parvals' => '43',
        '__order' => 0,
      ),
      'KO' => 
      array (
        'country_code' => 'KO',
        'n' => 'Corée du Sud',
        'badge' => 'badge4',
        'fld_id_parvals' => '46',
        '__order' => 1,
      ),
      'ES' => 
      array (
        'country_code' => 'ES',
        'n' => 'Espagne',
        'badge' => 'badge0',
        'fld_id_parvals' => '49',
        '__order' => 2,
      ),
      'US' => 
      array (
        'country_code' => 'US',
        'n' => 'Etats Unis d\'Amérique',
        'badge' => 'badge1',
        'fld_id_parvals' => '41',
        '__order' => 3,
      ),
      'FR' => 
      array (
        'country_code' => 'FR',
        'n' => 'France',
        'badge' => 'badge0',
        'fld_id_parvals' => '40',
        '__order' => 4,
      ),
      'GB' => 
      array (
        'country_code' => 'GB',
        'n' => 'Grande-Bretagne',
        'badge' => 'badge0',
        'fld_id_parvals' => '42',
        '__order' => 5,
      ),
    ),
    'en' => 
    array (
      'BE' => 
      array (
        'country_code' => 'BE',
        'n' => 'Belgium',
        'badge' => 'badge0',
        'fld_id_parvals' => '43',
        '__order' => 0,
      ),
      'FR' => 
      array (
        'country_code' => 'FR',
        'n' => 'France',
        'badge' => 'badge0',
        'fld_id_parvals' => '40',
        '__order' => 1,
      ),
      'GB' => 
      array (
        'country_code' => 'GB',
        'n' => 'Great-Britain',
        'badge' => 'badge0',
        'fld_id_parvals' => '42',
        '__order' => 2,
      ),
      'KO' => 
      array (
        'country_code' => 'KO',
        'n' => 'South Korea',
        'badge' => 'badge4',
        'fld_id_parvals' => '46',
        '__order' => 3,
      ),
      'ES' => 
      array (
        'country_code' => 'ES',
        'n' => 'Spain',
        'badge' => 'badge0',
        'fld_id_parvals' => '49',
        '__order' => 4,
      ),
      'US' => 
      array (
        'country_code' => 'US',
        'n' => 'USA',
        'badge' => 'badge1',
        'fld_id_parvals' => '41',
        '__order' => 5,
      ),
    ),
  ),
);