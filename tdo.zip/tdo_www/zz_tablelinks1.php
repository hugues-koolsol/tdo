<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();
//========================================================================================================================
$o1='';
$__nbMax=10;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_parent_table_pglnks
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_parent_field_pglnks
$xsrch_4=saveSessionSearch1('xsrch_4',BNF);// fld_child_table_pglnks
$xsrch_5=saveSessionSearch1('xsrch_5',BNF);// fld_child_field_pglnks
$xsrch_6=saveSessionSearch1('xsrch_6',BNF);// fld_link_mandatory_pglnks
$xsrch_7=saveSessionSearch1('xsrch_7',BNF);// fld_parent_field_display_pglnks
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_pglnks
if($xsrch_id!=''){
 if(!is_numeric($xsrch_id)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_28_92') . ' : ' . txt2('fld_id_pglnks_38_152');
 }
}
$autofocus='xsrch_1';
if($xsrch_1!=''){      $autofocus='xsrch_1'; } // fld_parent_table_pglnks
else if($xsrch_2!=''){ $autofocus='xsrch_2'; } // fld_parent_field_pglnks
else if($xsrch_4!=''){ $autofocus='xsrch_4'; } // fld_child_table_pglnks
else if($xsrch_5!=''){ $autofocus='xsrch_5'; } // fld_child_field_pglnks
else if($xsrch_6!=''){ $autofocus='xsrch_6'; } // fld_link_mandatory_pglnks
else if($xsrch_7!=''){ $autofocus='xsrch_7'; } // fld_parent_field_display_pglnks
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array());
$o1.='<h1>'.txt2('page_title_list_51_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="yyfilterForm">'.CRLF;



$o1.='   <div class="">'.CRLF;
$o1.='    <label class="" for="xsrch_1">'.txt2('fld_parent_table_pglnks_68_62').'</label>'.CRLF; // fld_parent_table_pglnks
$o1.='    <input class=" ';
if($xsrch_1!=''){$o1.=' yybackgroundYellow';}
$o1.=     '" type="text" name="xsrch_1"    id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div class="">'.CRLF;
$o1.='    <label class="" for="xsrch_2">'.txt2('fld_parent_field_pglnks_77_62').'</label>'.CRLF; // fld_parent_field_pglnks
$o1.='    <input class=" ';
if($xsrch_2!=''){$o1.=' yybackgroundYellow';}
$o1.=     '" type="text" name="xsrch_2"    id="xsrch_2"   value="'.enti1($xsrch_2).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_7">'.txt2('fld_parent_field_display_pglnks_64_39').'</label>'.CRLF; // fld_parent_field_display_pglnks
$o1.='    <input '.($xsrch_7!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_7" id="xsrch_7"   value="'.enti1($xsrch_7).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;



$o1.='   <div class="">'.CRLF;
$o1.='    <label class="" for="xsrch_4">'.txt2('fld_child_table_pglnks_64_62').'</label>'.CRLF; // fld_child_table_pglnks
$o1.='    <input class=" ';
if($xsrch_4!=''){$o1.=' yybackgroundYellow';}
$o1.=     '" type="text" name="xsrch_4"    id="xsrch_4"   value="'.enti1($xsrch_4).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_4'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div class="">'.CRLF;
$o1.='    <label class="" for="xsrch_5">'.txt2('fld_child_field_pglnks_104_62').'</label>'.CRLF; // fld_child_field_pglnks
$o1.='    <input class=" ';
if($xsrch_5!=''){$o1.=' yybackgroundYellow';}
$o1.=     '" type="text" name="xsrch_5"    id="xsrch_5"   value="'.enti1($xsrch_5).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_5'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
$o1.='   <div class="">'.CRLF;
$o1.='    <label class="" for="xsrch_6">'.txt2('fld_link_mandatory_pglnks_113_62').'</label>'.CRLF;
$o1.='    <select name="xsrch_6"  id="xsrch_6" class="';
if($xsrch_6!=''){$o1.=' yybackgroundYellow';}
$o1.='" '.($autofocus=='xsrch_6'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='<option value="" '.($xsrch_6==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_6){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;


$o1.='   <div class="">'.CRLF;
$o1.='    <label class="" for="xsrch_id">'.txt2('fld_id_pglnks_38_152').'</label>'.CRLF; // fld_id_pglnks
$o1.='    <input class=" ';
if($xsrch_id!=''){$o1.=' yybackgroundYellow';}
$o1.=     '" type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;


$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_pglnks`             ,0                              ,T1.`fld_name_tables`           ,T0.`fld_parent_field_pglnks`     ,0                                 ,
   T2.`fld_name_tables`           ,T0.`fld_child_field_pglnks`    ,T0.`fld_link_mandatory_pglnks` ,T0.`fld_parent_table_id_pglnks`  ,T0.`fld_children_table_id_pglnks` ,
   T1.`fld_name_tables`           ,T0.`fld_parent_field_display_pglnks`   
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tablelinks` T0 ,
      `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables`     T1 ,
      `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables`     T2 
 WHERE T1.`fld_id_tables` = T0.`fld_parent_table_id_pglnks` 
   AND T2.`fld_id_tables` = T0.`fld_children_table_id_pglnks` 
';
if($xsrch_1!='' ){
 $req6.='
  AND T1.`fld_name_tables` LIKE \'%'.$xsrch_1.'%\'
 '; 
}
if($xsrch_2!='' ){
 $req6.='
  AND T0.`fld_parent_field_pglnks` LIKE \'%'.$xsrch_2.'%\'
 '; 
}
if($xsrch_4!='' ){
 $req6.='
  AND T2.`fld_name_tables` LIKE \'%'.$xsrch_4.'%\'
 '; 
}
if($xsrch_5!='' ){
 $req6.='
  AND T0.`fld_child_field_pglnks` LIKE \'%'.$xsrch_5.'%\'
 '; 
}
if($xsrch_6!='' && is_numeric($xsrch_6)){
 $req6.='
  AND T0.`fld_link_mandatory_pglnks` = '.$xsrch_6.'
 '; 
}
if($xsrch_7!='' ){
 $req6.='
  AND T0.`fld_parent_field_display_pglnks` LIKE \'%'.$xsrch_7.'%\'
 '; 
}
if($xsrch_id!='' && is_numeric($xsrch_id)){
 $req6.='
  AND T0.`fld_id_pglnks` = '.$xsrch_id.'
 '; 
}
$req6.='
 ORDER BY T0.`fld_id_pglnks` DESC 
'; 
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 $reqCount6='SELECT FOUND_ROWS();';
 $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $mpsrcount6=mysqli_fetch_row($rescount6);
  $__count=$mpsrcount6[0];
 }
 $lsttbl='';
 if($__count==0){
  $lst.='<p>'.CRLF;
  $lst.=''.txt2('no_record_founded_212_17').''.CRLF;
  $lst.='<a href="zz_tablelinks_action1.php?a=c">'.txt2('add_a_new_record_213_98').'</a>'.CRLF;
  $lst.='</p>'.CRLF;
  $o1.=''.$lst.''.CRLF;  
 }else{
  $consUrlRedir=''.
                '&amp;xsrch_1='.rawurlencode($xsrch_1). // fld_parent_table_pglnks 
                '&amp;xsrch_2='.rawurlencode($xsrch_2). // fld_parent_field_pglnks 
                '&amp;xsrch_4='.rawurlencode($xsrch_4). // fld_child_table_pglnks 
                '&amp;xsrch_5='.rawurlencode($xsrch_5). // fld_child_field_pglnks 
                '&amp;xsrch_6='.rawurlencode($xsrch_6). // fld_link_mandatory_pglnks 
                '&amp;xsrch_7='.rawurlencode($xsrch_7). // fld_parent_field_display_pglnks 
                '&amp;xsrch_id='.rawurlencode($xsrch_id).
                '';
  $ri=' <span class="yybtn yyunset">&raquo;</span>';
  if($__start+$__nbMax<$__count){
   $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
  }
  $le=' <span class="yybtn yyunset">&laquo;</span>';
  if($__xpage>0){
   $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
  }
  
  
  $o1.='<div>';
  $o1.='<form method="post" class="yylistForm1">';
  $o1.=' <a href="zz_tablelinks_action1.php?a=c">'.txt2('add_a_new_record_213_98').'</a>'.CRLF;
  $o1.=' '.$le.''.$ri.''.CRLF;  
  $o1.=' <div style="display:inline-block;"> page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('records todos_390_80').' )</div>';
  $o1.='</form>';
  $o1.='</div>';
  
  $o1.=getCss1(890); // todo adjust size

  $lsttbl.='<thead><tr>';
  $lsttbl.='<th style="min-width:90px;">'.txtsys1('column_action').'</th>';
  $lsttbl.='<th>'.txt2('fld_id_pglnks_38_152').'</th>';
  $lsttbl.='<th>'.txt2('fld_parent_table_pglnks_68_62').'</th>';
  $lsttbl.='<th>'.txt2('fld_parent_field_pglnks_77_62').'</th>';
  $lsttbl.='<th>'.txt2('fld_parent_field_display_pglnks_64_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_child_table_pglnks_277_24').'</th>';
  $lsttbl.='<th>'.txt2('fld_child_field_pglnks_104_62').'</th>';
  $lsttbl.='<th>'.txt2('fld_link_mandatory_pglnks_113_62').'</th>';
  $lsttbl.='</tr></thead><tbody>';
  while($mpsr6=mysqli_fetch_row($result6)){
   
   $lsttbl.='<tr>';

   $lsttbl.='<td style="text-align:left!important;padding:0px;">';
   $lsttbl.='<div class="yyflex1">';
   $lsttbl.='<a class="yytxtSiz1 yydanger" href="zz_tablelinks_action1.php?a=d&amp;id='.$mpsr6[0].'" title="'.txtsys1('delete_button').'">&#10008;</a>';  // todo ajust
   $lsttbl.='<a class="yytxtSiz1 yyedit"   href="zz_tablelinks_action1.php?a=u&amp;id='.$mpsr6[0].'" title="'.txtsys1('edit_button').'">&#9998;</a>'; // todo ajust
   $lsttbl.='</div>';
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_id_pglnks_38_152').'">';
   $lsttbl.=''.enti1($mpsr6[0]).''; // fld_id_pglnks
   $lsttbl.='</td>';


   $lsttbl.='<td data-label="'.txt2('fld_parent_table_pglnks_68_62').'">';
   $lsttbl.=''.enti1($mpsr6[10]).''; // fld_parent_table_pglnks
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_parent_field_pglnks_77_62').'">';
   $lsttbl.=''.enti1($mpsr6[3]).''; // fld_parent_field_pglnks
   $lsttbl.='</td>';

   $class='';
   if($mpsr6[11]==''){
    $class='error';
   }
   $lsttbl.='<td class="'.$class.'" data-label="'.txt2('fld_parent_field_display_pglnks_305_37').'">';
   $lsttbl.=''.enti1($mpsr6[11]).''; // fld_parent_field_display_pglnks
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_child_table_pglnks_64_62').'">';
   $lsttbl.=''.enti1($mpsr6[5]).''; // fld_child_table_pglnks
   $lsttbl.='</td>';

   
   $lsttbl.='<td data-label="'.txt2('fld_child_field_pglnks_104_62').'">';
   $lsttbl.=''.enti1($mpsr6[6]).''; // fld_child_field_pglnks
   $lsttbl.='</td>';

   
   $lsttbl.='<td data-label="'.txt2('fld_link_mandatory_pglnks_113_62').'" style="text-align:center;">';
   require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
   $lsttbl.=displayParam1('yorno',$mpsr6[7]); // fld_link_mandatory_pglnks
   $lsttbl.='</td>';

   $lsttbl.='</tr>';
   
  }
  $o1.='<table class="yytableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;
   
  $o1.=' <div class="yylistForm1">'.CRLF;
  $o1.='  <a href="zz_tablelinks_action1.php?a=c">'.txt2('add_a_new_record_213_98').'</a>'.CRLF;
  $o1.='  '.$le.' '.$ri.'<div style="display:inline-block;"> page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_355_99').' )</div>'.CRLF;
  $o1.=' </div>'.CRLF;
   
 }
 mysqli_free_result($result6);
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
}

$req0='
 SELECT CONSTRAINT_NAME , REFERENCED_TABLE_NAME , REFERENCED_COLUMN_NAME , TABLE_NAME , COLUMN_NAME 
   FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
   WHERE REFERENCED_TABLE_SCHEMA = \''.$GLOBALS['glob_db'][0]['dbname'].'\'
';

$data0=array();
$result0=mysqli_query($GLOBALS['glob_db'][0]['link'],$req0);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr0=mysqli_fetch_row($result0)){
  $data0[]=array(
  'CONSTRAINT_NAME'         => $mpsr0[0],
  'TABLE_NAME'              => $mpsr0[3],
  'COLUMN_NAME'             => $mpsr0[4],
  'REFERENCED_TABLE_NAME'   => $mpsr0[1],
  'REFERENCED_COLUMN_NAME'  => $mpsr0[2],
  'founded'                 => false    ,
  'view'                    => ''
  );
 }
 mysqli_free_result($result0);
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $data0 , true ) . '</pre>' ; exit(0);
 if(sizeof($data0)>0){
  $req1='
   SELECT 
      T0.`fld_parent_field_pglnks` , T1.`fld_name_tables` ,
      T0.`fld_child_field_pglnks`  , T2.`fld_name_tables` ,              
      T3.`fld_name_tables`
   FROM ( `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tablelinks` T0
        , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T1
        , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T2
        )
   LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T3 ON T3.`fld_id_tables` = T1.`fld_id_reftbl_of_view_tables`
   WHERE T0.`fld_parent_table_id_pglnks`      =T1.`fld_id_tables`
     AND T0.`fld_children_table_id_pglnks`    =T2.`fld_id_tables`
  ';
  $data1=array();
  $result1=mysqli_query($GLOBALS['glob_db'][0]['link'],$req1);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($mpsr1=mysqli_fetch_row($result1)){
    $data1[]=array(
    'TABLE_NAME'              => $mpsr1[3],
    'COLUMN_NAME'             => $mpsr1[2],
    'REFERENCED_TABLE_NAME'   => $mpsr1[1],
    'REFERENCED_COLUMN_NAME'  => $mpsr1[0],
    'TABLE_REF_FOR_VIEW'      => $mpsr1[4],
    );
   }
   mysqli_free_result($result1);
   foreach($data0 as $k0=>$v0){
    foreach($data1 as $k1=>$v1){
     if(
         $v0['TABLE_NAME']             == $v1['TABLE_NAME']
      && $v0['COLUMN_NAME']            == $v1['COLUMN_NAME']
      && ( $v0['REFERENCED_TABLE_NAME']  == $v1['REFERENCED_TABLE_NAME'] || $v0['REFERENCED_TABLE_NAME'] == $v1['TABLE_REF_FOR_VIEW'] )
      && $v0['REFERENCED_COLUMN_NAME'] == $v1['REFERENCED_COLUMN_NAME']
     ){
      $data0[$k0]['founded']=true;
      if($v0['REFERENCED_TABLE_NAME'] == $v1['TABLE_REF_FOR_VIEW']){
       $data0[$k0]['view']=$v1['REFERENCED_TABLE_NAME']; 
      }
      
     }
    }
   }
  }else{
   // todo
  }
 }
}else{
 // todo
}
if(count($data0)>0){
 foreach($data0 as $k0=>$v0){
  if($v0['founded']==false){
   $o1.='<div class="yywarning">';
  }else{
   $o1.='<div class="yysuccess">';   
  }
  $o1.=' table/champ : ' . $v0['REFERENCED_TABLE_NAME'].'' .($v0['view']!=''?'('.$v0['view'].')/':'/') .''.$v0['REFERENCED_COLUMN_NAME'].'' . ' &nbsp; &nbsp; &nbsp; '.txt2('has a child_419_173').' : &nbsp; &nbsp; &nbsp; '.$v0['TABLE_NAME'].'/'.$v0['COLUMN_NAME'].''.'</div>';
 }
}




$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
