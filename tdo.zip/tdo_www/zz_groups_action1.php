<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
require_once($GLOBALS['glob_incPath1'].'/groups1.php');

openDb2();
//========================================================================================================================
function btl1(){
 return '&nbsp;<a class="btn btn-sm btn-primary buttonBack" href="zz_groups1.php">'.txtsys1('back_to_the_list').'</a>';
}
//========================================================================================================================
function test_input_groupsKO1(){
 $err=0;
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_name_groups']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_name_groups must not be empty_17_92');
  $err=1;
 }
 if($err==0){
  if($_SESSION[PGMK][NAV][BNF]['fld_parent_id_groups']==2){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the parent group cannot be anonymous(2)_22_93');
   $err=1;
  }
 }
 if($err==0&&$_POST['id1']==1){
  if($_SESSION[PGMK][NAV][BNF]['fld_parent_id_groups']!=1){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('Le groupe parent de root doit être root (1)_28_93');
   $err=1;
  }
  if($_SESSION[PGMK]['loginInit']!=1){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('Seul le groupe root(1) peut modifier root(1)_32_93');
   $err=1;
  }
 }
 if($_POST['id1']==0){ // création
  if($_SESSION[PGMK][NAV][BNF]['fld_parent_id_groups']==0 && $_SESSION[PGMK][NAV][BNF]['fld_name_groups'] != '_anonymous'){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('Le groupe parent doit être indiqué_38_93');
   $err=1;
  }
 }
 if($err==0&&$_POST['id1']==1){
  if($_SESSION[PGMK][NAV][BNF]['fld_isactive_groups']==0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('le groupe root doit être actif');
   $err=1;   
  }
 }
 
 return($err);
}
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= POST ACTIONS  =====================================================================
 //=================================================================================================================================
 //=================================================================================================================================
// echo __LINE__ . '$_POST=<pre>' . var_export($_POST,true) . '</pre>'; exit();

 $_SESSION[PGMK][NAV][BNF]['fld_name_groups']      =isset($_POST['fld_name_groups'])      ?$_POST['fld_name_groups']      : '';
 $_SESSION[PGMK][NAV][BNF]['fld_parent_id_groups'] =isset($_POST['fld_parent_id_groups']) ?$_POST['fld_parent_id_groups'] : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_isactive_groups']  =isset($_POST['fld_isactive_groups'])  ?$_POST['fld_isactive_groups']  : 0;

 // dependant field 
 if(!(isset($_POST['a'])&&($_POST['a']=='cd'||$_POST['a']=='cd'))){ // NOT confirm delete
  $_SESSION[PGMK][NAV][BNF]['choose__fld_parent_id_groups'] =isset($_POST['choose__fld_parent_id_groups'] )?$_POST['choose__fld_parent_id_groups']  :'';
  if($_SESSION[PGMK][NAV][BNF]['choose__fld_parent_id_groups']==txtsys1('text_for_the_select_button')){
   $_SESSION[PGMK]['choose']['urlBack']=$_SERVER['HTTP_ORIGIN'].$_SERVER['REQUEST_URI'];
   header("HTTP/1.1 303 See Other");header('Location: zz_groups_choose1.php');
   exit();
  }
 }

 //=================================================================================================================================
 //============================================= POST UPDATE =======================================================================
 //=================================================================================================================================
 if(isset($_POST['a'])&&$_POST['a']=='u'){ // update action
  if(test_input_groupsKO1()){
   if(isset($_POST['id1'])&&is_numeric($_POST['id1'])){
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }else{
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : POST id1 = ' . $_POST['id1'];
    header("HTTP/1.1 303 See Other");header('Location: index.php');
    exit();
   }
  }
  $req6="UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__groups` SET
      `fld_name_groups`      = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_name_groups'])      ."'
    , `fld_parent_id_groups` =  ".$_SESSION[PGMK][NAV][BNF]['fld_parent_id_groups']             ."
    , `fld_isactive_groups`  =  ".$_SESSION[PGMK][NAV][BNF]['fld_isactive_groups']              ."
    , `fld_tsupd_groups`     = '".addslashes($GLOBALS['glob_setdate'])                          ."'
    , `fld_cntupd_groups`    =  " . ((int)$_POST['fld_cntupd_groups']+1)                        ."
  ";
  $req6.="
   WHERE `fld_id_groups`=".$_POST['id1']."
     AND `fld_cntupd_groups` = ".$_POST['fld_cntupd_groups']."
  ";
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
     break;
    default   :
     $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 2 );
    break;
   }
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
  }else{
   if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])!=1){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('this_record_has_not_been_updated_because_of_an_other_user');
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('please_retry');
    unset($_SESSION[PGMK][NAV][BNF]['fld_name_groups']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_parent_id_groups']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_isactive_groups']);
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
   }
   
   sqllog1( $req6 , BNF , __LINE__ );
   $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('the_modification_has_been_recorded_at') . ' ' . substr($GLOBALS['glob_setdate'],11);
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CONFIRM DELETE ===============================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='cd'){
 
  if($_POST['id1']==='1' || $_POST['id1']==='2' ){
   $_SESSION[PGMK][NAV]['errormessage'][]=txt2('the root(1) or _anonymous(2) cannot be deleted_116_48');
   header("HTTP/1.1 303 See Other");header('Location: zz_groups1.php');
   exit();
  }
  require_once $GLOBALS['glob_dataPath1'].'/generated/__tableDependencies1.php';
  $retDependantTables=dependentValuesExist1(0,'tdo_tbl__groups','fld_id_groups',$_POST['id1'] );
  if(true === $retDependantTables['valuesExist']){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' . txtsys1('you_cannot_delete_because_some_values_are_still_present_in_dependant_table') . ' ' . var_export( $retDependantTables['tables'] , true ) . ' ';
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=d&id='.$_POST['id1']);   
  }

  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__groups` WHERE `fld_id_groups`=".$_POST['id1']." " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
   txtlog1($xtxterr , BNF , __LINE__ , 2 );
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=d&id='.$_POST['id1']);
   exit();
  }else{
   sqllog1( $req6 , BNF , __LINE__ );
   unset($_SESSION[PGMK][NAV][BNF]);
   $_SESSION[PGMK][NAV]['message'][]=txt2('the group has been deleted_154_43');
   header("HTTP/1.1 303 See Other");header('Location: zz_groups1.php');
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CREATE ACTION ================================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='c'){
  if(test_input_groupsKO1()){
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
   exit();
  }
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__groups` SET
      `fld_name_groups`      = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_name_groups'])      ."'
    , `fld_parent_id_groups` =  ".$_SESSION[PGMK][NAV][BNF]['fld_parent_id_groups']             ."
    , `fld_isactive_groups`  =  ".$_SESSION[PGMK][NAV][BNF]['fld_isactive_groups']              ."
    , `fld_tsupd_groups`     = '".addslashes($GLOBALS['glob_setdate'])                          ."'
    , `fld_tscrt_groups`     = '".addslashes($GLOBALS['glob_setdate'])                          ."'
  " ;
//  echo __FILE__ . ' ' . __LINE__ . ' $req6 =' . $req6 . '' ; exit();
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
    break;
    default;
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 2 );
    break;
   }
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
   exit();
  }else{
   sqllog1( $req6 , BNF , __LINE__ );
   $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 2 );
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
    exit();
   }else{
    $NewCode=mysqli_fetch_row($resIns);
    $NewCode=$NewCode[0];
    mysqli_free_result($resIns);
    SetSessionMessageAndLog1( txt2('the new value has been inserted_190_36') . ' ('.$NewCode.').' , BNF , __LINE__ , 3);
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=n&id='.$NewCode);
    exit();
   }
  }
 }
 
}else{ // get action

 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= GET ACTION ========================================================================
 //=================================================================================================================================
 //=================================================================================================================================
 $o1=htmlHead1(array());
 $js1=array();
// echo __LINE__ . '$_SESSION[PGMK]=<pre>' . var_export( $_SESSION[PGMK] , true ) . '</pre>'; exit();
 //=================================================================================================================================
 //============================================= GET DELETE ========================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='d'){ // delete action
  $id=(isset($_GET['id'])&&is_numeric($_GET['id']))?$_GET['id']:0;
  if($_GET['id']==='1' || $_GET['id']==='2' ){
   $_SESSION[PGMK][NAV]['errormessage'][]=txt2('the root(1) or _anonymous(2) cannot be deleted_116_48');
   header("HTTP/1.1 303 See Other");header('Location: zz_groups.php');
   exit();
  }
  
  if($id==0){
   header("HTTP/1.1 303 See Other");header('Location: zz_groups1.php');
   exit();
  }else{
   $xvalueName=getGroup1($_GET['id']);
//   echo __FILE__ . ' ' . __LINE__ . ' TODO at LINE = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0); 
   if($xvalueName['fld_name_groups']==''){
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_delete_this_value');
    header("HTTP/1.1 303 See Other");header('Location: zz_groups1.php');
    exit();
   }else{
    require_once $GLOBALS['glob_dataPath1'].'/generated/__tableDependencies1.php';
    $retDependantTables=dependentValuesExist1(0,'tdo_tbl__groups','fld_id_groups',$_GET['id'] );
    if(isset($retDependantTables['valuesExist']) && $retDependantTables['valuesExist']==true){
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <div>'.CRLF;
     $o1.=' '.txtsys1('dependent_values_exist').''.CRLF;
     $o1.=' <ul>'.CRLF;
     foreach( $retDependantTables['tables'] as $k1 => $v1){
      $o1.='  <li>'.$v1.'</li>'.CRLF;
     }
     $o1.=' </ul>'.CRLF;
     $o1.=' </div>'.CRLF;
     $o1.=btl1();
    }else{
     
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <form method="post" class="formDelete">'.CRLF;
     $o1.='   '.txtsys1('please_confirm_deletion_of').' : '.CRLF;
     $o1.='   <br /><br /><b>'.enti1($xvalueName['fld_name_groups']).'</b><br /><br />'.CRLF;
     $o1.='   <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
     $o1.='   <input type="hidden" value="cd" name="a" id="a" />'."\r\n";
     $o1.='   <button type="submit" class="">'.txtsys1('i_confirm_the_deletion_button').'</button>'.CRLF;
     $o1.=' </form>'."\r\n";
     $o1.=' <br /><br />'."\r\n";
     $o1.=btl1();
    }
   }
  }
 //=================================================================================================================================
 //============================================= GET UPDATE ========================================================================
 //=================================================================================================================================
 
 }else if(isset($_GET['a'])&&$_GET['a']=='u'){ // update action
  $xxxFldValues=array();
  $js1=array();
  $o1.='<h4>'.txt2('update a record_247_20').' ('.$_GET['id'].')'.btl1().'</h4>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $name2=getGroup1($_GET['id']);
  $xxxFldValues['fld_name_groups']      =isset( $_SESSION[PGMK][NAV][BNF]['fld_name_groups'] )      ? $_SESSION[PGMK][NAV][BNF]['fld_name_groups']      : $name2['fld_name_groups']      ;
  $xxxFldValues['fld_parent_id_groups'] =isset( $_SESSION[PGMK][NAV][BNF]['fld_parent_id_groups'] ) ? $_SESSION[PGMK][NAV][BNF]['fld_parent_id_groups'] : $name2['fld_parent_id_groups'] ;
  $xxxFldValues['fld_isactive_groups']  =isset( $_SESSION[PGMK][NAV][BNF]['fld_isactive_groups'] )  ? $_SESSION[PGMK][NAV][BNF]['fld_isactive_groups']  : $name2['fld_isactive_groups']  ;


  $o1.='<form method="post" >'.CRLF;

  $o1.=' <input type="hidden" value="u" name="a" id="a" />'.CRLF;
  $o1.=' <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_name_groups_260_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_name_groups']).'" name="fld_name_groups" id="fld_name_groups" maxlength="32" style="width:100%;max-width:34em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  if($_SESSION[PGMK]['group']!=1){
   $o1.='    <input type="hidden" value="'.$_SESSION[PGMK]['group'].'" name="fld_parent_id_groups" id="fld_parent_id_groups" />'.CRLF;
  }else{
   $xDisplayValueFetch = '' ;
   if(
    isset($_SESSION[PGMK][NAV][BNF]['choose__fld_parent_id_groups'])&&
    $_SESSION[PGMK][NAV][BNF]['choose__fld_parent_id_groups']==txtsys1('text_for_the_select_button')&&
    isset($_SESSION[PGMK]['choose']['valueBack'])&&
    $_SESSION[PGMK]['choose']['valueBack']!=0
   ){
    if($_SESSION[PGMK][NAV][BNF]['choose__fld_parent_id_groups']==txtsys1('text_for_the_select_button')){
     $xxxFldValues['fld_parent_id_groups']=$_SESSION[PGMK]['choose']['valueBack'];
    }
    unset($_SESSION[PGMK]['choose']);
   }
   $xGroupValues=getGroup1($xxxFldValues['fld_parent_id_groups']);
   $xDisplayValueFetch = '' . enti1( $xGroupValues['fld_name_groups'] ) . ' (' . $xGroupValues['fld_id_groups'] . ')' . '' ;
   $o1.='  <div class="fdiv1">'.CRLF;
   $o1.='   <div class="flab1"><div>'.txt2('parent_fld_parent_id_groups_281_43').'</div></div>'.CRLF;
   $o1.='   <div class="finp1"><div>'.CRLF;
   $o1.='    <input type="hidden" value="'.enti1($xxxFldValues['fld_parent_id_groups']).'" name="fld_parent_id_groups" id="fld_parent_id_groups" />'.CRLF;
   $o1.='     '.$xDisplayValueFetch.'';
   if($_SESSION[PGMK]['group']==1){  
    $o1.='    <button type="submit" name="choose__fld_parent_id_groups" class="btn" value="'. txtsys1('text_for_the_select_button') . '">';
    $o1.=''   . txtsys1('text_for_the_select_button') . '';
    $o1.=     '</button>'."\r\n";
   }
   $o1.='   </div></div>'.CRLF;
   $o1.='  </div>'.CRLF;
  }

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_isactive_groups_327_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
  $retParam=displayParam2('yorno',$xxxFldValues['fld_isactive_groups'],'fld_isactive_groups',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  

  $o1.='<div class="fdiv1">'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="hidden" name="fld_cntupd_groups" id="fld_cntupd_groups" value="'.$name2['fld_cntupd_groups'].'" />'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('save_the_modification').'</button>'.CRLF;
  $o1.='   <a href="zz_grpspgs.php?xsrch_idgr1='.$_GET['id'].'" >'.txt2('go to the page management_342_73').'</a>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.='</div>'.CRLF;

  $o1.='</form>'.CRLF;

 //=================================================================================================================================
 //============================================= GET VIEW ==========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='v'&&isset($_GET['id'])&&is_numeric($_GET['id'])){ // view action
  // if you vant to do something here, go !
 //=================================================================================================================================
 //============================================= GET CREATE ========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='c'){ // create action
 
  $o1.='<h2>'.txt2('Add a new record_311_20'). ' '.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $o1.='<form method="post" class="form1">'.CRLF;
 
  $o1.=' <table class="tableForm1">'.CRLF;

  $fld_name_groups =isset($_SESSION[PGMK][NAV][BNF]['fld_name_groups'] )?$_SESSION[PGMK][NAV][BNF]['fld_name_groups']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_name_groups_260_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_name_groups).'" name="fld_name_groups" id="fld_name_groups" maxlength="32" style="width:100%;max-width:34em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  
  if($_SESSION[PGMK]['group']!=1){
   $o1.='    <input type="hidden" value="'.$_SESSION[PGMK]['group'].'" name="fld_parent_id_groups" id="fld_parent_id_groups" />'.CRLF;
  }else{
   $fld_parent_id_groups=isset($_SESSION[PGMK][NAV][BNF]['fld_parent_id_groups'] )?$_SESSION[PGMK][NAV][BNF]['fld_parent_id_groups']:0;
   if(
    isset($_SESSION[PGMK][NAV][BNF]['choose__fld_parent_id_groups'])&&
    $_SESSION[PGMK][NAV][BNF]['choose__fld_parent_id_groups']==txtsys1('text_for_the_select_button')&&
    isset($_SESSION[PGMK]['choose']['valueBack'])&&
    $_SESSION[PGMK]['choose']['valueBack']!=0
   ){
    if($_SESSION[PGMK][NAV][BNF]['choose__fld_parent_id_groups']==txtsys1('text_for_the_select_button')){
     $fld_parent_id_groups=$_SESSION[PGMK]['choose']['valueBack'];
    }
    unset($_SESSION[PGMK]['choose']);
   }
   $xGroupValues=getGroup1($fld_parent_id_groups);
   $xDisplayValueFetch = '' . enti1( $xGroupValues['fld_name_groups'] ) . ' (' . $xGroupValues['fld_id_groups'] . ')' . '' ; // todo check among the fields of the parent table
   
   $o1.='  <div class="fdiv1">'.CRLF;
   $o1.='   <div class="flab1"><div>'.txt2('parent_fld_parent_id_groups_281_43').'</div></div>'.CRLF;
   $o1.='   <div class="finp1"><div>'.CRLF;
   $o1.='    <input type="hidden" value="'.enti1($fld_parent_id_groups).'" name="fld_parent_id_groups" id="fld_parent_id_groups" />'.CRLF;
   $o1.='     '.$xDisplayValueFetch.'';
   $o1.='    <button type="submit" name="choose__fld_parent_id_groups" class="btn" value="'. txtsys1('text_for_the_select_button') . '">';
   $o1.=''   . txtsys1('text_for_the_select_button') . '';
   $o1.=     '</button>'."\r\n";
   $o1.='   </div></div>'.CRLF;
   $o1.='  </div>'.CRLF;
   
   
  }  
  
  $fld_isactive_groups =isset($_SESSION[PGMK][NAV][BNF]['fld_isactive_groups'] )?$_SESSION[PGMK][NAV][BNF]['fld_isactive_groups']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_isactive_groups_327_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
  $retParam=displayParam2('yorno',$fld_isactive_groups,'fld_isactive_groups',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('record_the_element').'</button>'.CRLF;
  $o1.='   <input type="hidden" value="0" name="id1" id="id1" />'.CRLF;
  $o1.='   <input type="hidden" value="c" name="a" id="a" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

 }
 $o1.=htmlFoot0(array('js' => $js1));
 dw1($o1);
 if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);
}