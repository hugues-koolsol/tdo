<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();

if(isset($_GET['idchoose'])){
 $_SESSION[PGMK]['choose']['valueBack']=$_GET['idchoose'];
 header("HTTP/1.1 303 See Other");header('Location: '.$_SESSION[PGMK]['choose']['urlBack']); 
 exit();
}

openDb1();
if(!isset($_SESSION[PGMK]['choose']['urlBack'])){
 header("HTTP/1.1 303 See Other");header('Location: index.php'); 
 exit(0);
}

//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_name_groups
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_parent_id_groups
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_groups
if($xsrch_1!=''){
 if(!is_numeric($xsrch_1)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_35_92') . ' : ' . txt2('fld_parent_id_groups_35_152');
 }
}
if($xsrch_id!=''){
 if(!is_numeric($xsrch_id)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_35_92') . ' : ' . txt2('fld_id_groups_40_152');
 }
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; }
else if($xsrch_1!=''){ $autofocus='xsrch_1'; }
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_list_48_18');
$o1.='&nbsp;<a class="btn btn-sm btn-primary buttonBack" href="'.$_SESSION[PGMK]['choose']['urlBack'].'">Retour</a>'.CRLF;
$o1.='</h1>';

$o1.=' <form method="get" class="filterForm">'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label class="" for="xsrch_0">'.txt2('fld_name_groups_57_62').'</label>'.CRLF; // fld_name_groups
$o1.='    <input class=" ';
if($xsrch_0!=''){$o1.=' backgroundYellow';}
$o1.=     '" type="text" name="xsrch_0"    id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <label class="" for="xsrch_1">'.txt2('fld_parent_id_groups_35_152').'</label>'.CRLF; // fld_parent_id_groups
$o1.='    <input class=" ';
if($xsrch_1!=''){$o1.=' backgroundYellow';}
$o1.=     '" type="text" name="xsrch_1"    id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;



$o1.='  <div>'.CRLF;
$o1.='   <label class="" for="xsrch_id">'.txt2('fld_id_groups_40_152').'</label>'.CRLF; // fld_id_groups
$o1.='    <input class=" ';
if($xsrch_id!=''){$o1.=' backgroundYellow';}
$o1.=     '" type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <button class="" id="button_search" >&#128270;</button>'.CRLF;
$o1.='   </div>'.CRLF;
$o1.='   <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_groups`        ,T0.`fld_name_groups`      ,T0.`fld_parent_id_groups` 
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0 
 WHERE 1=1 
';
if($xsrch_0!='' ){
 $req6.='
  AND T0.`fld_name_groups` LIKE \'%'.$xsrch_0.'%\'
 '; 
}
if($xsrch_1!='' && is_numeric($xsrch_1)){
 $req6.='
  AND T0.`fld_parent_id_groups` = '.$xsrch_1.'
 '; 
}
if($_SESSION[PGMK]['group']!=1){
 $req6.='
  AND T0.`fld_parent_id_groups` = '.$_SESSION[PGMK]['group'].'
 ';  
//   AND T0.`fld_parent_id_groups` <> T0.`fld_id_groups`
 
}
if($xsrch_id!='' && is_numeric($xsrch_id)){
 $req6.='
  AND T0.`fld_id_groups` = '.$xsrch_id.'
 '; 
}
$req6.='
 ORDER BY T0.`fld_id_groups` DESC 
'; 
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 $reqCount6='SELECT FOUND_ROWS();';
 $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $mpsrcount6=mysqli_fetch_row($rescount6);
  $__count=$mpsrcount6[0];
 }
 $lsttbl='';
 if($__count==0){
  $lst.='<p>'.CRLF;
  $lst.=''.txt2('no_record_founded_133_17').''.CRLF;
  $lst.='</p>'.CRLF;
  $o1.=''.$lst.''.CRLF;  
 }else{
  $consUrlRedir=''.
                '&amp;xsrch_0='.rawurlencode($xsrch_0). // fld_name_groups 
                '&amp;xsrch_1='.rawurlencode($xsrch_1). // fld_parent_id_groups 
                '&amp;xsrch_id='.rawurlencode($xsrch_id).
                '';
  $ri=' <span class="nextPage linkDisabeled btn btn-sm btn-outline-light disabled">&raquo;</span>';
  if($__start+$__nbMax<$__count){
   $ri=' <a class="nextPage btn btn-sm btn-primary" href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
  }
  $le=' <span class="nextPage linkDisabeled btn btn-sm btn-outline-light disabled">&laquo;</span>';
  if($__xpage>0){
   $le=' <a class="nextPage btn btn-sm btn-primary" href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
  }
$css='<style type="text/css">
@media screen and (max-width: 890px){/* todo adjust size */
  table.tableResult1 {
    border: 0;
    width:100%;
  }
  table.tableResult1 thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  table.tableResult1 tr {
    border-bottom: 3px solid #eee;
    display: block;
    margin-bottom: 2.001em;
  }
  table.tableResult1 td {
    border-bottom: 1px solid #eee;
    display: block;
    text-align: right !important;
  }
  table.tableResult1 td:before {
    content: attr(data-label);
    float: left;
    font-weight:bold;
    margin-right:5px;
  }
  table.tableResult1 td:last-child {
    border-bottom: 0;
  }
  table.tableResult1 td.actionColumn div{
   display:contents;
  }
  table.tableResult1 td.actionColumn{
   height:auto;
  }
  .tableResult1 td {
   height:auto;
  }
}
</style>';
  $o1.=$css;

  $lsttbl.='<thead class="thead-inverse"><tr>';
  $lsttbl.='<th>'.txtsys1('column_action').'</th>';
  $lsttbl.='<th>'.txt2('fld_id_groups_40_152').'</th>';
  $lsttbl.='<th>'.txt2('fld_name_groups_57_62').'</th>';
  $lsttbl.='<th>'.txt2('fld_parent_id_groups_35_152').'</th>';
  $lsttbl.='</tr></thead><tbody>';
  while($mpsr6=mysqli_fetch_row($result6)){
   
   $lsttbl.='<tr>';
   
   $lsttbl.='<td class="actionColumn" data-label="'.txtsys1('column_action').'">';
   $lsttbl.='<div>';
   $lsttbl.='<a class="btn btn-primary" href="'.BNF.'?idchoose='.$mpsr6[0].'">'.txtsys1('text_for_the_select_button') . '</a>'; // todo ajust
   $lsttbl.='</div>';
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_id_groups_40_152').'">';
   $lsttbl.=''.enti1($mpsr6[0]).''; // fld_id_groups
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_name_groups_57_62').'">';
   $lsttbl.=''.enti1($mpsr6[1]).''; // fld_name_groups
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_parent_id_groups_35_152').'">';
   $lsttbl.=''.enti1($mpsr6[2]).''; // fld_parent_id_groups
   $lsttbl.='</td>';

   $lsttbl.='</tr>';
   
  }
  $o1.='<table class="table table-striped table-bordered table-hover table-sm tableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF; // table-condensed
   
  $o1.=' <div>'.CRLF;
  $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_232_99').' )'.CRLF;
  $o1.=' </div>'.CRLF;
   
 }
 mysqli_free_result($result6);
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
}
$o1.=htmlFoot0(array());
dw1($o1);
