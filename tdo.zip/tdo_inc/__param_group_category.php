<?php
$GLOBALS['param__group_category']=array (
  'param__Name__Display' => 'n',
  'param__Name__Sort' => 'n',
  'param__Name__key' => 'group_category',
  'param__Key__type' => 'char',
  '__values' => 
  array (
    'fr' => 
    array (
      'anonymous' => 
      array (
        'group_category' => 'anonymous',
        'n' => 'anonyme',
        'badge' => 'badge1',
        'rule' => 0,
        'fld_id_parvals' => '69',
        '__order' => 0,
      ),
      'root' => 
      array (
        'group_category' => 'root',
        'n' => 'développeur racine',
        'badge' => 'badge0',
        'rule' => 0,
        'fld_id_parvals' => '68',
        '__order' => 1,
      ),
      'local_admin' => 
      array (
        'group_category' => 'local_admin',
        'n' => 'administrateur local',
        'badge' => 'badge2',
        'rule' => 0,
        'fld_id_parvals' => '70',
        '__order' => 2,
      ),
      'user' => 
      array (
        'group_category' => 'user',
        'n' => 'profession 1',
        'badge' => 'badge3',
        'rule' => 0,
        'fld_id_parvals' => '71',
        '__order' => 3,
      ),
    ),
    'en' => 
    array (
      'anonymous' => 
      array (
        'group_category' => 'anonymous',
        'n' => 'anonymous',
        'badge' => 'badge1',
        'rule' => 0,
        'fld_id_parvals' => '69',
        '__order' => 0,
      ),
      'root' => 
      array (
        'group_category' => 'root',
        'n' => 'root developer',
        'badge' => 'badge0',
        'rule' => 0,
        'fld_id_parvals' => '68',
        '__order' => 1,
      ),
      'local_admin' => 
      array (
        'group_category' => 'local_admin',
        'n' => 'local administrator',
        'badge' => 'badge2',
        'rule' => 0,
        'fld_id_parvals' => '70',
        '__order' => 2,
      ),
      'user' => 
      array (
        'group_category' => 'user',
        'n' => 'profession 1',
        'badge' => 'badge3',
        'rule' => 0,
        'fld_id_parvals' => '71',
        '__order' => 3,
      ),
    ),
  ),
  'param__definition' => 
  array (
    'comment' => 'group categories for users',
    'key' => 'group_category',
    'fields' => 
    array (
      0 => 
      array (
        'name' => 'group_category',
        'type' => 'char',
        'length' => 32,
        'comment' => 'root,anonymous,local_admin,user',
      ),
      1 => 
      array (
        'name' => 'n',
        'type' => 'char',
        'length' => 64,
        'languageTranslation' => true,
        'comment1' => 'the transform name',
      ),
    ),
    'dependencies' => 
    array (
      0 => 
      array (
        'id_db' => 0,
        'table' => 'tdo_tbl__groups',
        'field' => 'fld_category_groups',
      ),
    ),
    'id' => '7',
  ),
);