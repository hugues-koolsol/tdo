<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();

if(isset($_GET['idchoose'])){
 $_SESSION[PGMK]['choose']['valueBack']=$_GET['idchoose'];
 header('Location: '.$_SESSION[PGMK]['choose']['urlBack']); 
 exit();
}

if(!isset($_SESSION[PGMK]['choose']['urlBack'])){
 header('Location: index.php?message='.urlencode(txtsys1('the_navigation_has_been_lost')));
 exit();
}
openDb2();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_name_tables
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_tables
if($xsrch_id!=''){
 if(!is_numeric($xsrch_id)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_36_92') . ' : ' . txt2('fld_id_tables_51_152');
 }
}
$autofocus='xsrch_2';
if($xsrch_2!=''){      $autofocus='xsrch_2'; } // fld_id_server_tables
else if($xsrch_2!=''){ $autofocus='xsrch_2'; } // fld_name_tables
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_list_61_18');
$o1.='&nbsp;<a class="buttonBack" href="'.$_SESSION[PGMK]['choose']['urlBack'].'">Retour</a>'.CRLF;
$o1.='</h1>';

$o1.=' <form method="get" class="filterForm">'.CRLF;





$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_2">'.txt2('fld_name_tables_82_39').'</label>'.CRLF; // fld_name_tables
$o1.='    <input '.($xsrch_2!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_2"    id="xsrch_2"   value="'.enti1($xsrch_2).'"  size="8" maxlength="32" '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_tables_51_152').'</label>'.CRLF; // fld_id_tables
$o1.='    <input '.($xsrch_id!=''?'class="backgroundYellow"':'').'  type="text" name="xsrch_id" id="xsrch_id" value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_tables`               ,T0.`fld_id_server_tables`  ,1,T0.`fld_name_tables`          
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T0 
 WHERE 1=1 
';
if($xsrch_2!='' ){
 $req6.='
  AND T0.`fld_name_tables` LIKE \'%'.$xsrch_2.'%\'
 '; 
}
if($xsrch_id!='' && is_numeric($xsrch_id)){
 $req6.='
  AND T0.`fld_id_tables` = '.$xsrch_id.'
 '; 
}
$req6.='
 ORDER BY T0.`fld_id_tables` DESC 
'; 
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 $reqCount6='SELECT FOUND_ROWS();';
 $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $mpsrcount6=mysqli_fetch_row($rescount6);
  $__count=$mpsrcount6[0];
 }
 $lsttbl='';
 if($__count==0){
  $lst.='<p>'.CRLF;
  $lst.=''.txt2('no_record_founded_166_17').''.CRLF;
  $lst.='</p>'.CRLF;
  $o1.=''.$lst.''.CRLF;  
 }else{
  $consUrlRedir=''.
                '&amp;xsrch_2='.rawurlencode($xsrch_2). // fld_name_tables 
                '&amp;xsrch_id='.rawurlencode($xsrch_id).
                '';
  $ri=' <span class="btn unset">&raquo;</span>';
  if($__start+$__nbMax<$__count){
   $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
  }
  $le=' <span class="btn unset">&laquo;</span>';
  if($__xpage>0){
   $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
  }
$css='<style type="text/css">
@media screen and (max-width: 890px){/* todo adjust size */
  table.tableResult1 {
    border: 0;
    width:100%;
    max-width:540px;
  }
  table.tableResult1 thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  table.tableResult1 tr {
    border-bottom: 3px solid #eee;
    display: block;
    margin-bottom: 2.001em;
  }
  table.tableResult1 td {
    border-bottom: 1px solid #eee;
    display: block;
    text-align: right!important;
    min-height:30px;
  }
  table.tableResult1 td:before {
    content: attr(data-label);
    float: left!important;
    font-weight:bold;
    margin-right:5px;
  }
  table.tableResult1 td:last-child{border-bottom: 0;}
  table.tableResult1 td.actionColumn div{display:contents;}
  table.tableResult1 td.actionColumn{height:auto;}
  .tableResult1 td {height:auto;word-break: break-all;}
  .tableResult1 td pre {word-break: break-all;white-space: pre-line;}
}
</style>';
  $o1.=$css;

  $lsttbl.='<thead><tr>';
  $lsttbl.='<th style="min-width:85px;">'.txtsys1('column_action').'</th>';
  $lsttbl.='<th>'.txt2('fld_id_tables_51_152').'</th>';
  $lsttbl.='<th>'.txt2('fld_name_tables_82_39').'</th>';
  $lsttbl.='</tr></thead><tbody>';
  while($mpsr6=mysqli_fetch_row($result6)){
   
   $lsttbl.='<tr>';
   
   $lsttbl.='<td data-label="'.txtsys1('column_action').'">';
   $lsttbl.='<div>';
   $lsttbl.='<a href="'.BNF.'?idchoose='.$mpsr6[0].'">'.txtsys1('text_for_the_select_button') . '</a>';
   $lsttbl.='</div>';
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_id_tables_51_152').'" style="text-align:right;">';
   $lsttbl.=''.enti1($mpsr6[0]).''; // fld_id_tables
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_name_tables_82_39').'">';
   $lsttbl.=''.enti1($mpsr6[3]).''; // fld_name_tables
   $lsttbl.='</td>';

   $lsttbl.='</tr>';
   
  }
  $o1.='<table class="tableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF; // table-condensed
   
  $o1.=' <div>'.CRLF;
  $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_273_99').' )'.CRLF;
  $o1.=' </div>'.CRLF;
   
 }
 mysqli_free_result($result6);
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
}

$o1.='<script type="text/javascript">var globalChooseUrlBack=\''.$_SESSION[PGMK]['choose']['urlBack'].'\';</script>';

$o1.=htmlFoot0(array());
dw1($o1);
