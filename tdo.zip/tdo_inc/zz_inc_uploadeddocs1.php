<?php
function getTdo_uploadeddocs1($id){
 $n=array();
 $n['T0_fld_id_uploadedDocs']            =0;
 $n['T0_fld_name_uploadedDocs']          ='';
 $n['T0_fld_originalName_uploadedDocs']  ='';
 $n['T0_fld_isPicture_uploadedDocs']     ='';
 $n['T0_fld_pictureWidth_uploadedDocs']  =0;
 $n['T0_fld_pictureHeight_uploadedDocs'] =0;
 $n['T0_fld_documentType_uploadedDocs']  ='';
 $n['T0_fld_weight_uploadedDocs']        =0;
 $n['T0_fld_path_uploadedDocs']          ='';
 $n['T0_fld_userId_uploadedDocs']        =0;
 $n['T0_fld_tsupd_uploadedDocs']         ='1000-01-01 00:00:00';
 $n['T0_fld_tscrt_uploadedDocs']         ='1000-01-01 00:00:00';
 $n['T0_fld_cntupd_uploadedDocs']        =0;
 $sql='
  SELECT 
   T0.`fld_id_uploadedDocs`            ,T0.`fld_name_uploadedDocs`          ,T0.`fld_originalName_uploadedDocs`  ,T0.`fld_isPicture_uploadedDocs`     ,T0.`fld_pictureWidth_uploadedDocs`  ,
   T0.`fld_pictureHeight_uploadedDocs` ,T0.`fld_documentType_uploadedDocs`  ,T0.`fld_weight_uploadedDocs`        ,T0.`fld_path_uploadedDocs`          ,T0.`fld_userId_uploadedDocs`        ,
   T0.`fld_tsupd_uploadedDocs`         ,T0.`fld_tscrt_uploadedDocs`         ,T0.`fld_cntupd_uploadedDocs`        
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__uploadeddocs` T0
  WHERE T0.`fld_id_uploadedDocs` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['T0_fld_id_uploadedDocs']            = $row[0];
   $n['T0_fld_name_uploadedDocs']          = $row[1];
   $n['T0_fld_originalName_uploadedDocs']  = $row[2];
   $n['T0_fld_isPicture_uploadedDocs']     = $row[3];
   $n['T0_fld_pictureWidth_uploadedDocs']  = $row[4];
   $n['T0_fld_pictureHeight_uploadedDocs'] = $row[5];
   $n['T0_fld_documentType_uploadedDocs']  = $row[6];
   $n['T0_fld_weight_uploadedDocs']        = $row[7];
   $n['T0_fld_path_uploadedDocs']          = $row[8];
   $n['T0_fld_userId_uploadedDocs']        = $row[9];
   $n['T0_fld_tsupd_uploadedDocs']         = $row[10];
   $n['T0_fld_tscrt_uploadedDocs']         = $row[11];
   $n['T0_fld_cntupd_uploadedDocs']        = $row[12];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
//======================================================================
function getinc_tdo_uploadeddocs_withParentFields1($id){
 $n=array();
 $n['T0_fld_id_uploadedDocs']            =0;
 $n['T0_fld_name_uploadedDocs']          ='';
 $n['T0_fld_originalName_uploadedDocs']  ='';
 $n['T0_fld_isPicture_uploadedDocs']     ='';
 $n['T0_fld_pictureWidth_uploadedDocs']  =0;
 $n['T0_fld_pictureHeight_uploadedDocs'] =0;
 $n['T0_fld_documentType_uploadedDocs']  ='';
 $n['T0_fld_weight_uploadedDocs']        =0;
 $n['T0_fld_path_uploadedDocs']          ='';
 $n['T0_fld_userId_uploadedDocs']        =0;
 $n['T0_fld_tsupd_uploadedDocs']         ='1000-01-01 00:00:00';
 $n['T0_fld_tscrt_uploadedDocs']         ='1000-01-01 00:00:00';
 $n['T0_fld_cntupd_uploadedDocs']        =0;
 $n['T1_fld_id_users']                   =0;
 $n['T1_fld_login_users']                ='';
 $n['T1_fld_email_users']                ='';
 $n['T1_fld_loginisemail_users']         =0;
 $n['T1_fld_password_users']             ='';
 $n['T1_fld_group_id_users']             =0;
 $n['T1_fld_active_users']               =0;
 $n['T1_fld_translate_users']            =0;
 $n['T1_fld_firstname_users']            ='';
 $n['T1_fld_lastname_users']             ='';
 $n['T1_fld_tsupd_users']                ='1000-01-01 00:00:00';
 $n['T1_fld_tscrt_users']                ='1000-01-01 00:00:00';
 $n['T1_fld_cntupd_users']               =0;
 $sql='
  SELECT 
   T0.`fld_id_uploadedDocs`            ,T0.`fld_name_uploadedDocs`          ,T0.`fld_originalName_uploadedDocs`  ,T0.`fld_isPicture_uploadedDocs`     ,T0.`fld_pictureWidth_uploadedDocs`  ,
   T0.`fld_pictureHeight_uploadedDocs` ,T0.`fld_documentType_uploadedDocs`  ,T0.`fld_weight_uploadedDocs`        ,T0.`fld_path_uploadedDocs`          ,T0.`fld_userId_uploadedDocs`        ,
   T0.`fld_tsupd_uploadedDocs`         ,T0.`fld_tscrt_uploadedDocs`         ,T0.`fld_cntupd_uploadedDocs`        ,T1.`fld_id_users`                   ,T1.`fld_login_users`                ,
   T1.`fld_email_users`                ,T1.`fld_loginisemail_users`         ,T1.`fld_password_users`             ,T1.`fld_group_id_users`             ,T1.`fld_active_users`               ,
   T1.`fld_translate_users`            ,T1.`fld_firstname_users`            ,T1.`fld_lastname_users`             ,T1.`fld_tsupd_users`                ,T1.`fld_tscrt_users`                ,
   T1.`fld_cntupd_users`               
  FROM ( `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__uploadeddocs` T0
       , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` T1
       )
  WHERE T0.`fld_id_uploadedDocs` = '.$id. '

    AND T0.`fld_userId_uploadedDocs`        =T1.`fld_id_users`
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['T0_fld_id_uploadedDocs']            = $row[0];
   $n['T0_fld_name_uploadedDocs']          = $row[1];
   $n['T0_fld_originalName_uploadedDocs']  = $row[2];
   $n['T0_fld_isPicture_uploadedDocs']     = $row[3];
   $n['T0_fld_pictureWidth_uploadedDocs']  = $row[4];
   $n['T0_fld_pictureHeight_uploadedDocs'] = $row[5];
   $n['T0_fld_documentType_uploadedDocs']  = $row[6];
   $n['T0_fld_weight_uploadedDocs']        = $row[7];
   $n['T0_fld_path_uploadedDocs']          = $row[8];
   $n['T0_fld_userId_uploadedDocs']        = $row[9];
   $n['T0_fld_tsupd_uploadedDocs']         = $row[10];
   $n['T0_fld_tscrt_uploadedDocs']         = $row[11];
   $n['T0_fld_cntupd_uploadedDocs']        = $row[12];
   $n['T1_fld_id_users']                   = $row[13];
   $n['T1_fld_login_users']                = $row[14];
   $n['T1_fld_email_users']                = $row[15];
   $n['T1_fld_loginisemail_users']         = $row[16];
   $n['T1_fld_password_users']             = $row[17];
   $n['T1_fld_group_id_users']             = $row[18];
   $n['T1_fld_active_users']               = $row[19];
   $n['T1_fld_translate_users']            = $row[20];
   $n['T1_fld_firstname_users']            = $row[21];
   $n['T1_fld_lastname_users']             = $row[22];
   $n['T1_fld_tsupd_users']                = $row[23];
   $n['T1_fld_tscrt_users']                = $row[24];
   $n['T1_fld_cntupd_users']               = $row[25];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
//======================================================================
function get_tdo_uploadeddocs_difference1($b,$a){ // before , after
 if(
     $b['T0_fld_name_uploadedDocs']==$a['T0_fld_name_uploadedDocs']
  && $b['T0_fld_originalName_uploadedDocs']==$a['T0_fld_originalName_uploadedDocs']
  && $b['T0_fld_isPicture_uploadedDocs']==$a['T0_fld_isPicture_uploadedDocs']
  && $b['T0_fld_pictureWidth_uploadedDocs']==$a['T0_fld_pictureWidth_uploadedDocs']
  && $b['T0_fld_pictureHeight_uploadedDocs']==$a['T0_fld_pictureHeight_uploadedDocs']
  && $b['T0_fld_documentType_uploadedDocs']==$a['T0_fld_documentType_uploadedDocs']
  && $b['T0_fld_weight_uploadedDocs']==$a['T0_fld_weight_uploadedDocs']
  && $b['T0_fld_path_uploadedDocs']==$a['T0_fld_path_uploadedDocs']
  && $b['T0_fld_userId_uploadedDocs']==$a['T0_fld_userId_uploadedDocs']
 ){
  return '// UPDATE no difference'.CRLF;
 }else{;
  $t1='';
  if($b['T0_fld_name_uploadedDocs']!=$a['T0_fld_name_uploadedDocs']){
   $t1.='fld_name_uploadedDocs from "'.$b['T0_fld_name_uploadedDocs'].'" to "'.$a['T0_fld_name_uploadedDocs'].'"'.CRLF;
  }
  if($b['T0_fld_originalName_uploadedDocs']!=$a['T0_fld_originalName_uploadedDocs']){
   $t1.='fld_originalName_uploadedDocs from "'.$b['T0_fld_originalName_uploadedDocs'].'" to "'.$a['T0_fld_originalName_uploadedDocs'].'"'.CRLF;
  }
  if($b['T0_fld_isPicture_uploadedDocs']!=$a['T0_fld_isPicture_uploadedDocs']){
   $t1.='fld_isPicture_uploadedDocs from "'.$b['T0_fld_isPicture_uploadedDocs'].'" to "'.$a['T0_fld_isPicture_uploadedDocs'].'"'.CRLF;
  }
  if($b['T0_fld_pictureWidth_uploadedDocs']!=$a['T0_fld_pictureWidth_uploadedDocs']){
   $t1.='fld_pictureWidth_uploadedDocs from "'.$b['T0_fld_pictureWidth_uploadedDocs'].'" to "'.$a['T0_fld_pictureWidth_uploadedDocs'].'"'.CRLF;
  }
  if($b['T0_fld_pictureHeight_uploadedDocs']!=$a['T0_fld_pictureHeight_uploadedDocs']){
   $t1.='fld_pictureHeight_uploadedDocs from "'.$b['T0_fld_pictureHeight_uploadedDocs'].'" to "'.$a['T0_fld_pictureHeight_uploadedDocs'].'"'.CRLF;
  }
  if($b['T0_fld_documentType_uploadedDocs']!=$a['T0_fld_documentType_uploadedDocs']){
   $t1.='fld_documentType_uploadedDocs from "'.$b['T0_fld_documentType_uploadedDocs'].'" to "'.$a['T0_fld_documentType_uploadedDocs'].'"'.CRLF;
  }
  if($b['T0_fld_weight_uploadedDocs']!=$a['T0_fld_weight_uploadedDocs']){
   $t1.='fld_weight_uploadedDocs from "'.$b['T0_fld_weight_uploadedDocs'].'" to "'.$a['T0_fld_weight_uploadedDocs'].'"'.CRLF;
  }
  if($b['T0_fld_path_uploadedDocs']!=$a['T0_fld_path_uploadedDocs']){
   $t1.='fld_path_uploadedDocs from "'.$b['T0_fld_path_uploadedDocs'].'" to "'.$a['T0_fld_path_uploadedDocs'].'"'.CRLF;
  }
  if($b['T0_fld_userId_uploadedDocs']!=$a['T0_fld_userId_uploadedDocs']){
   $t1.='fld_userId_uploadedDocs from "'.$b['T0_fld_userId_uploadedDocs'].'" to "'.$a['T0_fld_userId_uploadedDocs'].'"'.CRLF;
  }
  return '/*'.CRLF.'UPDATE list of differences'.CRLF.CRLF.$t1.CRLF.'*/'.CRLF;
 }
}
//======================================================================
function get_tdo_uploadeddocs_rebuild_insert1($f){
 $t1='// DELETE FROM `tdo_tbl__uploadeddocs` OK, the insert would be : '.CRLF;
 $t1.='$sql[]=<'.'<'.'<EOT'.CRLF;
 $t1.='INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__uploadeddocs` SET'.CRLF;
 $t1.='   `fld_id_uploadedDocs` = \''.addslashes($f['T0_fld_id_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_name_uploadedDocs` = \''.addslashes($f['T0_fld_name_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_originalName_uploadedDocs` = \''.addslashes($f['T0_fld_originalName_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_isPicture_uploadedDocs` = \''.addslashes($f['T0_fld_isPicture_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_pictureWidth_uploadedDocs` = \''.addslashes($f['T0_fld_pictureWidth_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_pictureHeight_uploadedDocs` = \''.addslashes($f['T0_fld_pictureHeight_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_documentType_uploadedDocs` = \''.addslashes($f['T0_fld_documentType_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_weight_uploadedDocs` = \''.addslashes($f['T0_fld_weight_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_path_uploadedDocs` = \''.addslashes($f['T0_fld_path_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_userId_uploadedDocs` = \''.addslashes($f['T0_fld_userId_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_tsupd_uploadedDocs` = \''.addslashes($f['T0_fld_tsupd_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_tscrt_uploadedDocs` = \''.addslashes($f['T0_fld_tscrt_uploadedDocs']) . '\' '.CRLF;
 $t1.=' , `fld_cntupd_uploadedDocs` = \''.addslashes($f['T0_fld_cntupd_uploadedDocs']) . '\' '.CRLF;
 $t1.='EOT;'.CRLF;
 return $t1;
}