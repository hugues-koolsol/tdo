<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 openDb1();
 if(isset($ret['input']['createOrUpdate']) && $ret['input']['createOrUpdate']===true){
  if($ret['input']['translated']==1){
   $req6="
    UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
      `fld_value_lngVals`       = '".addslashes1($ret['input']['value']) ."'
    WHERE `fld_key_lngVals`  = '".$ret['input']['key'] ."'
      AND `fld_type_lngVals` = 'table'
      AND `fld_lang_lngVals` = '".$ret['input']['lang'] ."'
   " ;
   $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    $ret['status']='OK';
    $ret['message'][]='updated';
   }else{
    $ret['message'][]= 'mysqli_error() "'.mysqli_error($GLOBALS['glob_db'][0]['link']).'" , $req6='.$req6;
   }
  }else{
   $req6="
    INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
       `fld_value_lngVals`       = '".addslashes1($ret['input']['value']) ."'
     , `fld_key_lngVals`  = '".$ret['input']['key'] ."'
     , `fld_type_lngVals`    = 'table'
     , `fld_lang_lngVals` = '".$ret['input']['lang'] ."'
   " ;
   $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    $ret['status']='OK';
    $ret['message'][]='inserted';
   }else{
    $ret['message'][]= 'mysqli_error() "'.mysqli_error($GLOBALS['glob_db'][0]['link']).'" , $req6='.$req6;
   }
  }
 }else{
  $ret['status']='OK';
 }
 if($ret['status']=='OK'){
  $content=array();
  foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang1){
   $sql='
    SELECT T0.`fld_key_lngVals`           ,T0.`fld_value_lngVals` 
    FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0
    WHERE T0.`fld_type_lngVals` = \'table\'
      AND T0.`fld_lang_lngVals` = \''.$klang.'\'
    ORDER BY T0.`fld_key_lngVals`
   ';
   $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    while($row=mysqli_fetch_row($req)){
     $content[$row[0]]=$row[1];
    }
    mysqli_free_result($req);
    file_put_contents($GLOBALS['glob_noVcPath1'].'/translation_for_pages/__'.$klang.'_tableNames.php','<'.'?php'.CRLF.'$__tableNames='.var_export($content,true).';');
   }else{
    $ret['message'][]=array(
     'sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),
     'reque' => $sql , 
     'file' => __FILE__ , 
     'line' => __LINE__ 
    );
   }
  }  
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}