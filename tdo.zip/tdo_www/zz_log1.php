<?php // € utf8 check with euro sign
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_incPath1'].'/__param_log.php');
checkGroupPages();
openDb1();


if(isset($_POST['bdateLimit1']) && isset($_POST['dateLimit0']) ){
 if($_POST['dateLimit0']!=''){
  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__log` WHERE `fld_timstp_log` <= '".addslashes($_POST['dateLimit0'])."' " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 }
 header('Location: '.BNF);
 exit();
}
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_timstp_log
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_text_log
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_bnf_log
$xsrch_3=saveSessionSearch1('xsrch_3',BNF);// fld_line_log
$xsrch_4=saveSessionSearch1('xsrch_4',BNF);// fld_user_id_log
$xsrch_5=saveSessionSearch1('xsrch_5',BNF);// fld_typ_log
$xsrch_6=saveSessionSearch1('xsrch_6',BNF);// fld_tag_log
$xsrch_7=saveSessionSearch1('xsrch_7',BNF);// fld_text_log
$xsrch_8=saveSessionSearch1('xsrch_8',BNF);// fld_text_log
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_log
$xsrch_sort=saveSessionSearch1('xsrch_sort',BNF);// fld_id_log
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if(!$listIdsOk){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_51_92') . ' : ' . txt2('fld_id_log_51_152');
 }
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; } // fld_timstp_log
else if($xsrch_1!=''){ $autofocus='xsrch_1'; } // fld_text_log
else if($xsrch_7!=''){ $autofocus='xsrch_7'; } // fld_text_log
else if($xsrch_8!=''){ $autofocus='xsrch_8'; } // fld_text_log
else if($xsrch_2!=''){ $autofocus='xsrch_2'; } // fld_bnf_log
else if($xsrch_3!=''){ $autofocus='xsrch_3'; } // fld_line_log
else if($xsrch_4!=''){ $autofocus='xsrch_4'; } // fld_user_id_log
else if($xsrch_5!=''){ $autofocus='xsrch_5'; } // fld_typ_log
else if($xsrch_6!=''){ $autofocus='xsrch_6'; } // fld_tag_log
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array());
$o1.='<h1>'.txt2('list of log_66_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="yyfilterForm">'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_timstp_log_72_39').'</label>'.CRLF; // fld_timstp_log
$o1.='    <input '.($xsrch_0!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_0" id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="0" maxlength="19"  '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_1">'.txt2('fld_text_log_77_39').'</label>'.CRLF; // fld_text_log
$o1.='    <input '.($xsrch_1!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_1" id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_7">'.txt2('and_text_log_82_39').'</label>'.CRLF; // fld_text_log
$o1.='    <input '.($xsrch_7!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_7" id="xsrch_7"   value="'.enti1($xsrch_7).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_7'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_8">'.txt2('and_not_text_log_87_39').'</label>'.CRLF; // fld_text_log
$o1.='    <input '.($xsrch_8!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_8" id="xsrch_8"   value="'.enti1($xsrch_8).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_8'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_2">'.txt2('fld_bnf_log_93_39').'</label>'.CRLF; // fld_bnf_log
$o1.='    <input '.($xsrch_2!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_2" id="xsrch_2"   value="'.enti1($xsrch_2).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_3">'.txt2('fld_line_log_99_39').'</label>'.CRLF; // fld_line_log
$o1.='    <input '.($xsrch_3!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_3" id="xsrch_3"   value="'.enti1($xsrch_3).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_3'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_4">'.txt2('fld_user_id_log_105_39').'</label>'.CRLF; // fld_user_id_log
$o1.='    <input '.($xsrch_4!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_4" id="xsrch_4"   value="'.enti1($xsrch_4).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_4'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_5">'.txt2('fld_typ_log_110_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_5!=''?'class="yybackgroundYellow"':'').' name="xsrch_5"  id="xsrch_5" '.($autofocus=='xsrch_5'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='<option value="" '.($xsrch_5==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__log']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_5){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__log']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__log']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_6">'.txt2('fld_tag_log_125_39').'</label>'.CRLF; // fld_tag_log
$o1.='    <input '.($xsrch_6!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_6" id="xsrch_6"   value="'.enti1($xsrch_6).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_6'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_log_51_152').'</label>'.CRLF; // fld_id_log
$o1.='    <input '.($xsrch_id!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="128" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_sort">'.txtsys1('sort_order').'</label>'.CRLF; // sort
$o1.='    <select '.($xsrch_sort!=''?'class="yybackgroundYellow"':'').' name="xsrch_sort"  id="xsrch_sort" '.($autofocus=='xsrch_sort'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='     <option value="" '.($xsrch_sort==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_timstp_log'.'"            '.($xsrch_sort=='T0.fld_timstp_log'            ?' selected="selected" ':'').'>'.txt2('fld_timstp_log_72_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_text_log'.'"              '.($xsrch_sort=='T0.fld_text_log'              ?' selected="selected" ':'').'>'.txt2('fld_text_log_77_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_bnf_log'.'"               '.($xsrch_sort=='T0.fld_bnf_log'               ?' selected="selected" ':'').'>'.txt2('fld_bnf_log_93_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_line_log'.'"              '.($xsrch_sort=='T0.fld_line_log'              ?' selected="selected" ':'').'>'.txt2('fld_line_log_99_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_user_id_log'.'"           '.($xsrch_sort=='T0.fld_user_id_log'           ?' selected="selected" ':'').'>'.txt2('fld_user_id_log_105_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_typ_log'.'"               '.($xsrch_sort=='T0.fld_typ_log'               ?' selected="selected" ':'').'>'.txt2('fld_typ_log_110_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_tag_log'.'"               '.($xsrch_sort=='T0.fld_tag_log'               ?' selected="selected" ':'').'>'.txt2('fld_tag_log_125_39').'</option>'.CRLF;
$o1.='    </select>';
$o1.='   </div>'.CRLF;
$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;// #128270
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
require_once($GLOBALS['glob_noVcPath1'].'/pages_of_groups/groups_of_group_'.$_SESSION[PGMK]['groupInit'].'.php');
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
// todo adjust the request
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_log`                ,T0.`fld_timstp_log`            ,T0.`fld_text_log`              ,T0.`fld_bnf_log`               ,T0.`fld_line_log`              ,
   T0.`fld_user_id_log`           ,T0.`fld_typ_log`               ,T0.`fld_tag_log`               
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__log` T0 ) 
 WHERE 1=1 
   AND T0.`fld_group_id_log` in('.$GLOBALS['glob_treegrp'].')
';

if(!($_SESSION[PGMK]['grpCatInit']=='root'||$_SESSION[PGMK]['grpCatInit']=='local_admin')){
 $req6.='
  AND T0.`fld_user_id_log` = '.$_SESSION[PGMK]['login'].'
 '; 
}
if($xsrch_0!='' ){
 $req6.='
  AND T0.`fld_timstp_log` LIKE \'%'.addslashes1($xsrch_0).'%\'
 '; 
}
if($xsrch_1!='' ){
 $req6.='
  AND T0.`fld_text_log` LIKE \'%'.addslashes1($xsrch_1).'%\'
 '; 
}
if($xsrch_7!='' ){
 $req6.='
  AND T0.`fld_text_log` LIKE \'%'.addslashes1($xsrch_7).'%\'
 '; 
}

if($xsrch_8!='' ){
 $req6.='
  AND T0.`fld_text_log` NOT LIKE \'%'.addslashes1($xsrch_8).'%\'
 '; 
}

if($xsrch_2!='' ){
 $req6.='
  AND T0.`fld_bnf_log` LIKE \'%'.addslashes1($xsrch_2).'%\'
 '; 
}
if($xsrch_3!='' && is_numeric($xsrch_3)){
 $req6.='
  AND T0.`fld_line_log` = '.$xsrch_3.'
 '; 
}
if($xsrch_4!='' && is_numeric($xsrch_4)){
 $req6.='
  AND T0.`fld_user_id_log` = '.$xsrch_4.'
 '; 
}
if($xsrch_5!='' ){
 $req6.='
  AND T0.`fld_typ_log` LIKE \'%'.addslashes1($xsrch_5).'%\'
 '; 
}
if($xsrch_6!='' ){
 $req6.='
  AND T0.`fld_tag_log` LIKE \'%'.addslashes1($xsrch_6).'%\'
 '; 
}
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if($listIdsOk){
  $req6.='
   AND T0.`fld_id_log` IN ('.implode(',',$xsrch_ids).') 
  '; 
 }
}
// adjust the order
if($xsrch_sort==''){ $req6.='ORDER BY T0.`fld_id_log` DESC ';}
if($xsrch_sort=='T0.fld_timstp_log'){             $req6.=' ORDER BY T0.`fld_timstp_log` ASC  '; }
if($xsrch_sort=='T0.fld_text_log'){               $req6.=' ORDER BY T0.`fld_text_log` ASC  '; }
if($xsrch_sort=='T0.fld_bnf_log'){                $req6.=' ORDER BY T0.`fld_bnf_log` ASC  '; }
if($xsrch_sort=='T0.fld_line_log'){               $req6.=' ORDER BY T0.`fld_line_log` ASC  '; }
if($xsrch_sort=='T0.fld_user_id_log'){            $req6.=' ORDER BY T0.`fld_user_id_log` ASC  '; }
if($xsrch_sort=='T0.fld_typ_log'){                $req6.=' ORDER BY T0.`fld_typ_log` ASC  '; }
if($xsrch_sort=='T0.fld_tag_log'){                $req6.=' ORDER BY T0.`fld_tag_log` ASC  '; }
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$__count=0;
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'T0.fld_id_log'                =>$mpsr6[0],
  'T0.fld_timstp_log'            =>$mpsr6[1],
  'T0.fld_text_log'              =>$mpsr6[2],
  'T0.fld_bnf_log'               =>$mpsr6[3],
  'T0.fld_line_log'              =>$mpsr6[4],
  'T0.fld_user_id_log'           =>$mpsr6[5],
  'T0.fld_typ_log'               =>$mpsr6[6],
  'T0.fld_tag_log'               =>$mpsr6[7],
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}
$lsttbl='';
if($__count==0){
 $lst.='<p>'.CRLF;
 $lst.=''.txt2('no_record_founded_271_16').''.CRLF;
 $lst.='</p>'.CRLF;
 $o1.=''.$lst.''.CRLF;  
}else{
 $consUrlRedir=''.
               ($xsrch_0!=''?'&amp;xsrch_0='.rawurlencode($xsrch_0):''). // fld_timstp_log 
               ($xsrch_1!=''?'&amp;xsrch_1='.rawurlencode($xsrch_1):''). // fld_text_log 
               ($xsrch_7!=''?'&amp;xsrch_7='.rawurlencode($xsrch_7):''). // fld_text_log 
               ($xsrch_8!=''?'&amp;xsrch_8='.rawurlencode($xsrch_8):''). // fld_text_log 
               ($xsrch_2!=''?'&amp;xsrch_2='.rawurlencode($xsrch_2):''). // fld_bnf_log 
               ($xsrch_3!=''?'&amp;xsrch_3='.rawurlencode($xsrch_3):''). // fld_line_log 
               ($xsrch_4!=''?'&amp;xsrch_4='.rawurlencode($xsrch_4):''). // fld_user_id_log 
               ($xsrch_5!=''?'&amp;xsrch_5='.rawurlencode($xsrch_5):''). // fld_typ_log 
               ($xsrch_6!=''?'&amp;xsrch_6='.rawurlencode($xsrch_6):''). // fld_tag_log 
               ($xsrch_id!=''?'&amp;xsrch_id='.rawurlencode($xsrch_id):'').
               ($xsrch_sort!=''?'&amp;xsrch_sort='.rawurlencode($xsrch_sort):'').
               '';
 $ri=' <span class="yybtn yyunset">&raquo;</span>';
 if($__start+$__nbMax<$__count){
  $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
 }
 $le=' <span class="yybtn yyunset">&laquo;</span>';
 if($__xpage>0){
  $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
 }

 $o1.='<div>';
 $o1.='<form method="post">';
 $o1.='&nbsp;'.$le.''.CRLF;  
 $o1.='&nbsp;'.$ri.''.CRLF;  
 $o1.=' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('records log_301_80').' )'.CRLF;
 if($_SESSION[PGMK]['login']==1){
  $o1.='<input type="text" name="dateLimit1" id="dateLimit1" disabled="disabled" size="19" maxlength="19" />'.CRLF;  
  $o1.='<input type="hidden" name="dateLimit0" id="dateLimit0" />'.CRLF;  
  $o1.='<button name="bdateLimit1">'.txt2('delete logs where date is lower equal this date_305_43').'</button>'.CRLF;  
 }

 $o1.='</form>';
 $o1.='</div>';

 $o1.=getCss1(890); // todo adjust size

 $lsttbl.='<thead><tr>';
 $lsttbl.='<th style="min-width:140px;">'.txtsys1('column_action').'</th>';
 $lsttbl.='<th style="min-width:85px;">'.txt2('fld_id_log_51_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_timstp_log_72_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_text_log_77_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_bnf_log_93_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_line_log_99_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_user_id_log_105_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_typ_log_110_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_tag_log_125_39').'</th>';
 $lsttbl.='</tr></thead><tbody>';

 foreach($data0 as $k0=>$v0){

  $lsttbl.='<tr>';

  $lsttbl.='<td data-label="" style="text-align:left!important;">';
  $lsttbl.='<div>';
  $lsttbl.='<a href="zz_log_action1.php?a=u&amp;id='.$v0['T0.fld_id_log'].'" title="'.txtsys1('edit_button').'">&#9998;</a>';//✎ #9998
  if($_SESSION[PGMK]['login']==1){
   $lsttbl.='<a href="zz_log_action1.php?a=d&amp;id='.$v0['T0.fld_id_log'].'" title="'.txtsys1('delete_button').'" class="yydanger" >&#10008;</a>';//✘ #10008
   $lsttbl.='<a href="javascript:fillValueField1(\'dateLimit1\',\''.$v0['T0.fld_timstp_log'].'\');fillValueField1(\'dateLimit0\',\''.$v0['T0.fld_timstp_log'].'\');" title="'.txt2('put_this_date to field dateLimit1_334_180').'"  >&#8679;</a>';//✘ #10008
  }
  $lsttbl.='</div>';
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_id_log_51_152').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_id_log'].''; // fld_id_log
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_timstp_log_72_39').'">';
  $lsttbl.=''.$v0['T0.fld_timstp_log'].''; // fld_timstp_log
  $lsttbl.='</td>';

  if($v0['T0.fld_text_log']==''||is_null($v0['T0.fld_text_log'])){
   $lsttbl.='<td data-label="'.txt2('fld_text_log_77_39').'"></td>';
  }else{
   $lsttbl.='<td data-label="'.txt2('fld_text_log_77_39').'"><pre>';
   $lsttbl.=''.mb_substr($v0['T0.fld_text_log'],0,100,'UTF-8').''; // fld_text_log
   $lsttbl.='</pre></td>';
  }

  $lsttbl.='<td data-label="'.txt2('fld_bnf_log_93_39').'">';
  $lsttbl.=''.$v0['T0.fld_bnf_log'].''; // fld_bnf_log
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_line_log_99_39').'" style="text-align:right;">';
  $lsttbl.=''.$v0['T0.fld_line_log'].''; // fld_line_log
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_user_id_log_105_39').'" style="text-align:right;">';
  $lsttbl.=''.$v0['T0.fld_user_id_log'].''; // fld_user_id_log
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_typ_log_110_39').'" style="text-align:center;">';
  $lsttbl.=displayParam1('log',$v0['T0.fld_typ_log'],array('unsetPossible'=>false)); // fld_typ_log
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_tag_log_125_39').'">';
  $lsttbl.=''.$v0['T0.fld_tag_log'].''; // fld_tag_log
  $lsttbl.='</td>';



  $lsttbl.='</tr>';

 }

 $o1.='<table class="yytableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;

 $o1.=' <div>'.CRLF;
 $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('records log_301_80').' )'.CRLF;
 $o1.=' </div>'.CRLF;

}

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
