<?php
// group  : 
$GLOBALS['glob_treegrp']='3';