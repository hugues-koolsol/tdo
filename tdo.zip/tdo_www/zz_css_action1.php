<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
require_once $GLOBALS['glob_incPath1'].'/zz_inc_css1.php';

$cssList= array(
 'main' => array(
  'mainBackgroundColor' => array(
   'type' => 'color',
   'hexValue' => 'FFEFD5',
   'webName'  => 'papayawhip'
  ),
  'mainTextColor' => array(
   'type' => 'color',
   'hexValue' => '444444',
   'hr_after' => true ,
  ),
  'thinBorderColor' => array(
   'type' => 'color',
   'hexValue' => 'EEEEEE',
   'hr_after' => true ,
  ),
  'linkStartBackgroundColor' => array(
   'type' => 'color',
   'hexValue' => 'FFFFFF',
  ),
  'linkEndBackground' => array(
   'type' => 'color',
   'hexValue' => 'FFFFFF',
   'hr_after' => true ,
  ),
  'linkUnsetTextColor' => array(
   'type' => 'color',
   'hexValue' => '444444',
   'hr_after' => true ,
  ),
 ),
 'table' => array(
  'headerBackgroundColor' => array(
   'type' => 'color',
   'hexValue' => 'EFEFEF',
  ),
  'headerTextColor' => array(
   'type' => 'color',
   'hexValue' => '666666',
  ),
  'linkTextColor' => array(
   'type' => 'color',
   'hexValue' => '0000FF',
   'hr_after' => true ,
  ),
  'nthchildBackgroundColor' => array(
   'type' => 'color',
   'hexValue' => 'FFEFD5',
   'hr_after' => true ,
  ),
 ),
 'backgrounds' => array(
  'dangerBackground'  => array( 'type' => 'color',  'hexValue' => 'FF0000',  ),'dangerText'  => array( 'type' => 'color',  'hexValue' => 'D87093', 'hr_after' => true , ),
  'editBackground'    => array( 'type' => 'color',  'hexValue' => 'FF0000',  ),'editText'    => array( 'type' => 'color',  'hexValue' => 'D87093', 'hr_after' => true , ),
  'successBackground' => array( 'type' => 'color',  'hexValue' => '8BC34A',  ),'successText' => array( 'type' => 'color',  'hexValue' => '556B2F', 'hr_after' => true , ),
  'errorBackground'   => array( 'type' => 'color',  'hexValue' => 'FD3131',  ),'errotText'   => array( 'type' => 'color',  'hexValue' => '540000', 'hr_after' => true , ),
 ),
 'menu' => array(
  'topColor' => array(
   'type' => 'color',
   'hexValue' => '0088cc',
  ),
  'bottomColor' => array(
   'type' => 'color',
   'hexValue' => '0044cc',
   'hr_after' => true ,
  ),
  'textColor' => array(
   'type' => 'color',
   'hexValue' => 'FFFFFF',
   'hr_after' => true ,
  ),
  'borderColor' => array(
   'type' => 'color',
   'hexValue' => '0072cc',
  ),
  'activeBackgroundColor' => array(
   'type' => 'color',
   'hexValue' => '0072cc',
  ),
 ),
 'badge' => array(
  'badge0Background' => array( 'type' => 'color',  'hexValue' => 'FF0000',  ),  'badge0TextColor' => array(  'type' => 'color',  'hexValue' => '000000',  'hr_after' => true ),
  'badge1Background' => array( 'type' => 'color',  'hexValue' => 'FF0000',  ),  'badge1TextColor' => array(  'type' => 'color',  'hexValue' => '000000',  'hr_after' => true ),
  'badge2Background' => array( 'type' => 'color',  'hexValue' => 'FFFF00',  ),  'badge2TextColor' => array(  'type' => 'color',  'hexValue' => '0000FF',  'hr_after' => true ),
  'badge3Background' => array( 'type' => 'color',  'hexValue' => 'FF00FF',  ),  'badge3TextColor' => array(  'type' => 'color',  'hexValue' => 'FFFF00',  'hr_after' => true ),
  'badge4Background' => array( 'type' => 'color',  'hexValue' => '00FFFF',  ),  'badge4TextColor' => array(  'type' => 'color',  'hexValue' => '0000FF',  'hr_after' => true ),
  'badge5Background' => array( 'type' => 'color',  'hexValue' => '4CAF50',  ),  'badge5TextColor' => array(  'type' => 'color',  'hexValue' => 'FFEB3B',  'hr_after' => true ),
  'badge6Background' => array( 'type' => 'color',  'hexValue' => 'FFEBEE',  ),  'badge6TextColor' => array(  'type' => 'color',  'hexValue' => 'C62828',  'hr_after' => true ),
  'badge7Background' => array( 'type' => 'color',  'hexValue' => '1E88E5',  ),  'badge7TextColor' => array(  'type' => 'color',  'hexValue' => 'E3F2FD',  'hr_after' => true ),
  'badge8Background' => array( 'type' => 'color',  'hexValue' => 'FFE082',  ),  'badge8TextColor' => array(  'type' => 'color',  'hexValue' => 'F06292',  'hr_after' => true ),
 ),
);

openDb2();
function setCssText($cssl1){
 $cssGenere1='';
 $cssGenere1.='@-ms-viewport {width: device-width;}html{box-sizing: border-box;}*,*::before,*::after {box-sizing: inherit;font-weight:500;}'.CRLF;
 $cssGenere1.='body{margin:0;border:0;padding:0;overflow-y:scroll;'.CRLF;
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $cssl1['main']['mainBackgroundColor']['hexValue'] , true ) . '</pre>' ; exit(0);
 $cssGenere1.=' background-color:#'.$cssl1['main']['mainBackgroundColor']['hexValue'].';'.CRLF;
 $cssGenere1.=' font-family:verdana;'.CRLF;
 $cssGenere1.=' font-size:14px;'.CRLF;
 $cssGenere1.=' color:#'.$cssl1['main']['mainTextColor']['hexValue'].';'.CRLF;
 $cssGenere1.=' padding-top:55px;'.CRLF;
 $cssGenere1.=' padding-bottom:20px; /* space for footer */'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='@media print {a[href]:after {content: none !important;}@page {size: auto;margin-bottom: 0;}}'.CRLF;
 $cssGenere1.='pre{overflow:scroll;word-break: break-all;white-space: pre-line;margin:0 0 0 0;}'.CRLF;
 $cssGenere1.='a{color:#'.$cssl1['main']['mainTextColor']['hexValue'].';}'.CRLF; // linkTextColor
 $cssGenere1.='#mainContent{margin-left:8px;margin-right:8px;width:auto;margin:0 auto;}'.CRLF; 
 $cssGenere1.='select{border:2px inset #'.$cssl1['main']['thinBorderColor']['hexValue'].';padding:4px;border-radius:3px;background-color:#'.$cssl1['main']['mainBackgroundColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.navbar{position:fixed;top:0;width:100%;z-index:1000;'.CRLF;
 $cssGenere1.=' height:55px; '.CRLF;
 $cssGenere1.=' background:#'.$cssl1['main']['mainBackgroundColor']['hexValue'].';'.CRLF;
 $cssGenere1.=' background-image: linear-gradient(to bottom, #'.$cssl1['menu']['topColor']['hexValue'].', #'.$cssl1['menu']['bottomColor']['hexValue'].');'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.=''.CRLF;
 $cssGenere1.='#menuScroller{ display:flex;overflow-x:scroll;overflow-y:hidden;'.CRLF;
 $cssGenere1.=' height:55px;'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='#menuScroller div{margin:3px auto auto auto;}'.CRLF;
 $cssGenere1.='#menuScroller li{display:flex;}'.CRLF;
 $cssGenere1.='.navbar ul{display:flex;list-style:none;padding:0;margin:0;}'.CRLF;
 $cssGenere1.='.navbar li{margin-left:10px;}'.CRLF;
 $cssGenere1.='#menuScroller select{max-width: 10em;color:#'.$cssl1['menu']['textColor']['hexValue'].';background:#'.$cssl1['menu']['bottomColor']['hexValue'].';';
 $cssGenere1.=' background-image: linear-gradient(to bottom, #'.$cssl1['menu']['topColor']['hexValue'].', #'.$cssl1['menu']['bottomColor']['hexValue'].');font-size:1.05em;'.CRLF;
 $cssGenere1.=' border: 1px #'.$cssl1['menu']['borderColor']['hexValue'].' solid;'.CRLF;
 $cssGenere1.=' max-height : 28px;'.CRLF;
 $cssGenere1.=' margin-right : 8px;'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='#menuScroller select option{font-size:1.1em;padding:8px 2px;}'.CRLF;
 $cssGenere1.='#menuScroller a{white-space: nowrap;'.CRLF;
 $cssGenere1.=' background:linear-gradient(to bottom, #'.$cssl1['menu']['topColor']['hexValue'].', #'.$cssl1['menu']['bottomColor']['hexValue'].');'.CRLF;
 $cssGenere1.=' color:#'.$cssl1['menu']['textColor']['hexValue'].';'.CRLF;
 $cssGenere1.=' padding:0px 3px 0px 3px;'.CRLF;
 $cssGenere1.=' min-height: 20px;'.CRLF;
 $cssGenere1.=' line-height: 20px;'.CRLF;
 $cssGenere1.=' border: 1px #'.$cssl1['menu']['borderColor']['hexValue'].' solid;'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.active{ border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' inset;background:#'.$cssl1['menu']['activeBackgroundColor']['hexValue'].'!important;}'.CRLF; 
 $cssGenere1.='form{border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;}'.CRLF;
 $cssGenere1.='.formDelete{text-align:center;padding:8px;margin:8px;line-height: 2em;}'.CRLF;
 $cssGenere1.='.filterForm{display:flex;flex-wrap:wrap;} .filterForm div{display:flex;flex-direction:column;flex-wrap:wrap;margin-right:5px;}.filterForm label{padding:3px;}'.CRLF;
 $cssGenere1.='button,.btn, a{display:inline-block;text-decoration:none;text-align:center;border-radius:5px; font-size:1em;font-family:inherit;color:inherit;cursor:pointer;'.CRLF;
 $cssGenere1.=' min-width: 40px;'.CRLF;
 $cssGenere1.=' min-height: 30px;'.CRLF;
 $cssGenere1.=' line-height: 30px;'.CRLF;
 $cssGenere1.=' padding: 3px!important;'.CRLF;
 $cssGenere1.=' background-color:#'.$cssl1['main']['mainBackgroundColor']['hexValue'].';'.CRLF;
 $cssGenere1.=' border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;'.CRLF; 
 $cssGenere1.=' background: linear-gradient(to bottom, #'.$cssl1['main']['linkStartBackgroundColor']['hexValue'].', #'.$cssl1['main']['linkEndBackground']['hexValue'].');'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='input {border:2px inset #'.$cssl1['main']['thinBorderColor']['hexValue'].';padding:5px;border-radius:4px;font-family:verdana;font-size:1em;background-color:#'.$cssl1['main']['mainBackgroundColor']['hexValue'].';color:#'.$cssl1['main']['mainTextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.tableResult1{border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;}'.CRLF;
 $cssGenere1.='.tableResult1 a{border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;color:#'.$cssl1['main']['mainTextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.button_search{flex-grow:1;}'.CRLF;
 $cssGenere1.='.unset{border:1px #'.$cssl1['main']['mainBackgroundColor']['hexValue'].' solid!important;user-select: none;color:#'.$cssl1['main']['linkUnsetTextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='thead tr{background-color:#'.$cssl1['table']['headerBackgroundColor']['hexValue'].';color:#'.$cssl1['table']['headerTextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='thead th{padding:8px 3px;}'.CRLF;
 $cssGenere1.='.notActive{pointer-events: none;cursor: default;}'.CRLF;
 $cssGenere1.='tbody tr:nth-child(2n){background-color:#'.$cssl1['table']['nthchildBackgroundColor']['hexValue'].';}'.CRLF; // 
 $cssGenere1.='.backgroundYellow{background-color:yellow;}'.CRLF;
 $cssGenere1.='.messageBox{padding:8px;border-radius:5px;}'.CRLF;
 $cssGenere1.='.normal{color:red!important;background-color:lightpink;}'.CRLF;
 $cssGenere1.='.edit{color:#'   .$cssl1['backgrounds']['editText']['hexValue']   .'!important;background:#'.$cssl1['backgrounds']['editBackground']['hexValue']   .'!important;}'.CRLF;
 $cssGenere1.='.danger{color:#' .$cssl1['backgrounds']['dangerText']['hexValue'] .'!important;background:#'.$cssl1['backgrounds']['dangerBackground']['hexValue'] .'!important;}'.CRLF;
 $cssGenere1.='.success{color:#'.$cssl1['backgrounds']['successText']['hexValue'].'!important;background:#'.$cssl1['backgrounds']['successBackground']['hexValue'].'!important;}'.CRLF;
 $cssGenere1.='.error{color:#'.$cssl1['backgrounds']['errorText']['hexValue'].'!important;background:#'.$cssl1['backgrounds']['errorBackground']['hexValue'].'!important;}'.CRLF;
 $cssGenere1.='.warning{color:#ad3204!important;background:orange!important;}'.CRLF;
 $cssGenere1.='.badge{border:2px #'.$cssl1['main']['thinBorderColor']['hexValue'].' groove;padding:3px;border-radius:6px;vertical-align: -webkit-baseline-middle;vertical-align: -moz-baseline-middle;vertical-align:baseline-middle;white-space:nowrap;display:inline-block;}'.CRLF;
 $cssGenere1.='.badge0{background-color:#'.$cssl1['badge']['badge0Background']['hexValue'].';color:#'.$cssl1['badge']['badge0TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.badge1{background-color:#'.$cssl1['badge']['badge1Background']['hexValue'].';color:#'.$cssl1['badge']['badge1TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.badge2{background-color:#'.$cssl1['badge']['badge2Background']['hexValue'].';color:#'.$cssl1['badge']['badge2TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.badge3{background-color:#'.$cssl1['badge']['badge3Background']['hexValue'].';color:#'.$cssl1['badge']['badge3TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.badge4{background-color:#'.$cssl1['badge']['badge4Background']['hexValue'].';color:#'.$cssl1['badge']['badge4TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.badge5{background-color:#'.$cssl1['badge']['badge5Background']['hexValue'].';color:#'.$cssl1['badge']['badge5TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.badge6{background-color:#'.$cssl1['badge']['badge6Background']['hexValue'].';color:#'.$cssl1['badge']['badge6TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.badge7{background-color:#'.$cssl1['badge']['badge7Background']['hexValue'].';color:#'.$cssl1['badge']['badge7TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.badge8{background-color:#'.$cssl1['badge']['badge8Background']['hexValue'].';color:#'.$cssl1['badge']['badge8TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='/* forms for create update */ '.CRLF;
 $cssGenere1.='.fdiv1{display: flex;flex-direction: row;flex-wrap: wrap;align-items: stretch;justify-content: flex-start;margin-bottom: 8px;}'.CRLF;
 $cssGenere1.='.flab1{border-bottom: 1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid;border-left: 1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid;border-top: 1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid;border-right: 0px red solid;flex-grow: 0;flex-shrink: 0;flex-basis: 120px;max-width: 120px;text-align: center;font-weight: bold;display: flex;flex-direction: column;align-items: stretch;}'.CRLF;
 $cssGenere1.='@media all and (min-width: 550px){'.CRLF;
 $cssGenere1.=' .flab1 {flex-grow: 0;flex-shrink: 0;flex-basis: 180px;max-width: 180px;}'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='@media all and (max-width: 384px) {'.CRLF;
 $cssGenere1.=' .flab1{flex-grow: 1;flex-shrink: 1;flex-basis: 100%;max-width: 100%;border-bottom-style: none;margin-top: 8px;border-right: 1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid;min-height:30px;}'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.flab1 div{margin: auto;font-weight:bold;}'.CRLF;
 $cssGenere1.='.finp1{border: 1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid;flex-grow: 1;flex-shrink: 0;flex-basis: 200px;padding: 3px;flex-direction: column;}'.CRLF;
 $cssGenere1.='.finp1 div{margin: auto 2px;}'.CRLF;
 $cssGenere1.='.finp1 textarea{width:100%;padding:5px;border-radius:4px;}'.CRLF;
 $cssGenere1.=''.CRLF;
 $cssGenere1.='.footer {position:fixed;bottom:0;height:20px;text-align:right;width:100%;background-image: linear-gradient(to bottom, #'.$cssl1['menu']['topColor']['hexValue'].', #'.$cssl1['menu']['bottomColor']['hexValue'].');}'.CRLF;
 $cssGenere1.='.footer a{padding: 0!important;line-height: 20px;border-radius: 0;font-family: inherit;color:#'.$cssl1['main']['mainTextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='/*======================================= tree =============================*/'.CRLF;
 $cssGenere1.='.class_treediv1{'.CRLF;
 $cssGenere1.=' border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset; /* see class_treediv1BorderTopHeight under */'.CRLF;
 $cssGenere1.=' height:40px;'.CRLF;
 $cssGenere1.=' overflow:hidden;'.CRLF;
 $cssGenere1.=' display : flex; '.CRLF;
 $cssGenere1.=' flex-direction: row;'.CRLF;
 $cssGenere1.=' justify-content: space-between; '.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.class_treeIntervalldiv2{'.CRLF;
 $cssGenere1.=' border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid; '.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.class_treeTextContentdiv3{'.CRLF;
 $cssGenere1.=' text-align:left;'.CRLF;
 $cssGenere1.=' flex-grow:1;'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.class_treedivFolder1{'.CRLF;
 $cssGenere1.=' border:0px lime solid;'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.class_treeFold1,.class_treeDelet1{'.CRLF;
 $cssGenere1.=' display:inline-block;'.CRLF;
 $cssGenere1.=' float:left;'.CRLF;
 $cssGenere1.=' height:30px;'.CRLF;
 $cssGenere1.=' width:30px;'.CRLF;
 $cssGenere1.=' min-width:30px;'.CRLF;
 $cssGenere1.=' border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;'.CRLF;
 $cssGenere1.=' text-align: center;'.CRLF;
 $cssGenere1.=' text-decoration: none;'.CRLF;
 $cssGenere1.=' font-size: 2em;'.CRLF;
 $cssGenere1.=' line-height: 1.1em;'.CRLF;
 $cssGenere1.=' border-radius:5px;'.CRLF;
 $cssGenere1.=' color:black;'.CRLF;
 $cssGenere1.=' font-weight:bold;'.CRLF;
 $cssGenere1.=' cursor:pointer;'.CRLF;
 $cssGenere1.=' font-family:monospace;'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.class_treeDelet1{'.CRLF;
 $cssGenere1.=' color:red;'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.class_treeHandle1{'.CRLF;
 $cssGenere1.=' border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;'.CRLF;
 $cssGenere1.=' display:inline-block;'.CRLF;
 $cssGenere1.=' float:right;'.CRLF;
 $cssGenere1.=' height:30px;'.CRLF;
 $cssGenere1.=' width:30px;'.CRLF;
 $cssGenere1.=' min-width:45px;'.CRLF;
 $cssGenere1.=' text-align: center;'.CRLF;
 $cssGenere1.=' text-decoration: none;'.CRLF;
 $cssGenere1.=' font-size: 1.5em;'.CRLF;
 $cssGenere1.=' line-height: 1.6em;'.CRLF;
 $cssGenere1.=' border-radius:5px;'.CRLF;
 $cssGenere1.=' font-family:monospace;'.CRLF;
 $cssGenere1.=' cursor:pointer;'.CRLF;
 $cssGenere1.='}'.CRLF;
 return $cssGenere1;
}
//========================================================================================================================
function btl1(){
 return '&nbsp;<a href="zz_css1.php" class="btn btn-sm btn-primary">'.txtsys1('back_to_the_list').'</a>';
}
//========================================================================================================================
function test_input_tdo_cssKO1(){
 $err=0;
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_name_css']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_name_css must not be empty_205_92');
  $err=1;
 }
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_color_back_css']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_color_back_css must not be empty_255_92');
  $err=1;
 }
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_color_text_css']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_color_text_css must not be empty_259_92');
  $err=1;
 }
 return($err);
}



if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= POST ACTIONS  =====================================================================
 //=================================================================================================================================
 //=================================================================================================================================
// echo __LINE__ . '$_POST=<pre>' . var_export($_POST,true) . '</pre>'; exit();
 $_SESSION[PGMK][NAV][BNF]['fld_name_css']       =isset($_POST['fld_name_css'])       ?$_POST['fld_name_css']       : '';
 $_SESSION[PGMK][NAV][BNF]['fld_color_back_css'] =isset($_POST['fld_color_back_css']) ?$_POST['fld_color_back_css'] : '';
 $_SESSION[PGMK][NAV][BNF]['fld_color_text_css'] =isset($_POST['fld_color_text_css']) ?$_POST['fld_color_text_css'] : '';
 $_SESSION[PGMK][NAV][BNF]['fld_active_css']     =isset($_POST['fld_active_css'])     ?$_POST['fld_active_css']     : 0;
 
 foreach($cssList as $k1 => $v1){
  foreach($v1 as $k2 => $v2){
   if(isset($_POST[$k2])){
    $cssList[$k1][$k2]=json_decode($_POST[$k2],true);
    $cssList[$k1][$k2]['type']='color';
   }
  }
 }
 
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $cssList , true ) . '</pre>' ; exit(0);
 
 $_SESSION[PGMK][NAV][BNF]['fld_json_css']       =json_encode($cssList);
 if($_SESSION[PGMK][NAV][BNF]['fld_color_back_css']==''){$_SESSION[PGMK][NAV][BNF]['fld_color_back_css']=NULL;} // fld_color_back_css can be NULL

 if($_SESSION[PGMK][NAV][BNF]['fld_color_text_css']==''){$_SESSION[PGMK][NAV][BNF]['fld_color_text_css']=NULL;} // fld_color_text_css can be NULL

 //=================================================================================================================================
 //============================================= POST UPDATE =======================================================================
 //=================================================================================================================================
 if(isset($_POST['a'])&&$_POST['a']=='u'){ // update action
  if(test_input_tdo_cssKO1()){
   if(isset($_POST['id1'])&&is_numeric($_POST['id1'])){
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }else{
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : POST id1 = ' . $_POST['id1'];
    header("HTTP/1.1 303 See Other");header('Location: index.php');
    exit();
   }
  }
  $req6="UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__css` SET
      `fld_name_css`       = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_name_css'])       ."'
    , `fld_active_css`     =  ".$_SESSION[PGMK][NAV][BNF]['fld_active_css']                 ."
    , `fld_color_back_css` =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_color_back_css'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_color_back_css'])."'")."
    , `fld_color_text_css` =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_color_text_css'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_color_text_css'])."'")."
    , `fld_json_css`       = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_json_css'])       ."'
    , `fld_tsupd_css`      = '".addslashes($GLOBALS['glob_setdate'])                            ."'
    , `fld_cntupd_css`     =  " . ((int)$_POST['fld_cntupd_css']+1)                         ."
  ";
  $req6.="
   WHERE `fld_id_css`=".$_POST['id1']."
     AND `fld_cntupd_css` = ".$_POST['fld_cntupd_css']."
  ";
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
     break;
    default   :
     $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    break;
   }
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
  }else{
   if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])!=1){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('this_record_has_not_been_updated_because_of_an_other_user');
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('please_retry');
    unset($_SESSION[PGMK][NAV][BNF]['fld_name_css']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_active_css']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_color_back_css']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_color_text_css']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_json_css']);
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
   }
   $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('the_modification_has_been_recorded_at') . ' ' . substr($GLOBALS['glob_setdate'],11);
   
   $cssTxt=setCssText($cssList);
   if($fd=fopen('css/'.$_POST['id1'].'.css','w')){
    fwrite($fd,$cssTxt);
    fclose($fd);
    if($fd=fopen('css/'.$_POST['id1'].'.js','w')){
     fwrite($fd,'var globalCssSettings1='.json_encode($cssList).';');
     fclose($fd);
    }
   }
   updateCssList();
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CONFIRM DELETE ===============================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='cd'){
 
  require_once $GLOBALS['glob_dataPath1'].'/generated/__tableDependencies1.php';
  $retDependantTables=dependentValuesExist1(0,'tdo_tbl__css','fld_id_css',$_POST['id1'] );
  if(true === $retDependantTables['valuesExist']){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' . txtsys1('you_cannot_delete_because_some_values_are_still_present_in_dependant_table') . ' ' . var_export( $retDependantTables['tables'] , true ) . ' ';
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=d&id='.$_POST['id1']);   
  }

//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__css` WHERE `fld_id_css`=".$_POST['id1']." " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
   txtlog1($xtxterr , BNF , __LINE__ , 'error' );
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=d&id='.$_POST['id1']);
   exit();
  }else{
   unset($_SESSION[PGMK][NAV][BNF]);
   header("HTTP/1.1 303 See Other");header('Location: zz_css1.php');
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CREATE ACTION ================================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='c'){
  if(test_input_tdo_cssKO1()){
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
   exit();
  }
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__css` SET
      `fld_name_css`       = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_name_css'])       ."'
    , `fld_active_css`     =  ".$_SESSION[PGMK][NAV][BNF]['fld_active_css']                 ."
    , `fld_color_back_css` =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_color_back_css'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_color_back_css'])."'")."
    , `fld_color_text_css` =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_color_text_css'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_color_text_css'])."'")."
    , `fld_json_css`       = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_json_css'])       ."'
    , `fld_tsupd_css`      = '".addslashes($GLOBALS['glob_setdate'])                           ."'
    , `fld_tscrt_css`      = '".addslashes($GLOBALS['glob_setdate'])                           ."'
  " ;
//  echo __FILE__ . ' ' . __LINE__ . ' $req6 =' . $req6 . '' ; exit();
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
    break;
    default;
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    break;
   }
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
   exit();
  }else{
   $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
    exit();
   }else{
    $NewCode=mysqli_fetch_row($resIns);
    $NewCode=$NewCode[0];
    mysqli_free_result($resIns);
    SetSessionMessageAndLog1( txt2('the new value has been inserted_439_36') . ' ('.$NewCode.').' , BNF , __LINE__ , 3);
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=n&id='.$NewCode);
    exit();
   }
  }
 }
 
}else{ // get action

 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= GET ACTION ========================================================================
 //=================================================================================================================================
 //=================================================================================================================================
 $o1=htmlHead1(array());
 $js1=array();
// echo __LINE__ . '$_SESSION[PGMK]=<pre>' . var_export( $_SESSION[PGMK] , true ) . '</pre>'; exit();
 //=================================================================================================================================
 //============================================= GET DELETE ========================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='d'){ // delete action
  $id=(isset($_GET['id'])&&is_numeric($_GET['id']))?$_GET['id']:0;
  if($id==0){
   header("HTTP/1.1 303 See Other");header('Location: zz_css1.php');
   exit();
  }else{
   $xvalueName=getTdo_css1($_GET['id']);
   if($xvalueName['fld_name_css']==''){
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_delete_this_value');
    header("HTTP/1.1 303 See Other");header('Location: zz_css1.php');
    exit();
   }else{
    require_once $GLOBALS['glob_dataPath1'].'/generated/__tableDependencies1.php';
    $retDependantTables=dependentValuesExist1(0,'tdo_tbl__css','fld_id_css',$_GET['id'] );
    if(isset($retDependantTables['valuesExist']) && $retDependantTables['valuesExist']==true){
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <div>'.CRLF;
     $o1.=' '.txtsys1('dependent_values_exist').''.CRLF;
     $o1.=' <ul>'.CRLF;
     foreach( $retDependantTables['tables'] as $k1 => $v1){
      $o1.='  <li>'.$v1.'</li>'.CRLF;
     }
     $o1.=' </ul>'.CRLF;
     $o1.=' </div>'.CRLF;
     $o1.=btl1();
    }else{
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <form method="post" class="formDelete">'.CRLF;
     $o1.='   '.txtsys1('please_confirm_deletion_of').' : '.CRLF;
     $o1.='   <br /><br /><b>'.enti1($xvalueName['fld_name_css']).'</b><br /><br />'.CRLF;
     $o1.='   <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
     $o1.='   <input type="hidden" value="cd" name="a" id="a" />'."\r\n";
     $o1.='   <button type="submit" class="danger">'.txtsys1('i_confirm_the_deletion_button').'</button>'.CRLF;
     $o1.=btl1();
     $o1.=' </form>'."\r\n";
    }
   }
  }
 //=================================================================================================================================
 //============================================= GET UPDATE ========================================================================
 //=================================================================================================================================
 
 }else if(isset($_GET['a'])&&$_GET['a']=='u'){ // update action
  $xxxFldValues=array();
  $js1=array();
  $o1.='<h4>'.txt2('update a record_504_20').' ('.$_GET['id'].')'.btl1().'</h4>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $name2=getTdo_css1($_GET['id']);
  $xxxFldValues['fld_name_css']       =isset( $_SESSION[PGMK][NAV][BNF]['fld_name_css'] )       ? $_SESSION[PGMK][NAV][BNF]['fld_name_css']       : $name2['fld_name_css']       ;
  $xxxFldValues['fld_active_css']     =isset( $_SESSION[PGMK][NAV][BNF]['fld_active_css'] )     ? $_SESSION[PGMK][NAV][BNF]['fld_active_css']     : $name2['fld_active_css']     ;
  $xxxFldValues['fld_color_back_css'] =isset( $_SESSION[PGMK][NAV][BNF]['fld_color_back_css'] ) ? $_SESSION[PGMK][NAV][BNF]['fld_color_back_css'] : $name2['fld_color_back_css'] ;
  $xxxFldValues['fld_color_text_css'] =isset( $_SESSION[PGMK][NAV][BNF]['fld_color_text_css'] ) ? $_SESSION[PGMK][NAV][BNF]['fld_color_text_css'] : $name2['fld_color_text_css'] ;
  $xxxFldValues['fld_json_css']       =isset( $_SESSION[PGMK][NAV][BNF]['fld_json_css'] )       ? $_SESSION[PGMK][NAV][BNF]['fld_json_css']       : $name2['fld_json_css']       ;


  $o1.='<form method="post" >'.CRLF;

  $o1.=' <input type="hidden" value="u" name="a" id="a" />'.CRLF;
  $o1.=' <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
  
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_name_css_472_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_name_css']).'" name="fld_name_css" id="fld_name_css" maxlength="32" style="width:100%;max-width:34em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_active_css_479_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
  $retParam=displayParam2('yorno',$xxxFldValues['fld_active_css'],'fld_active_css',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_color_back_css_488_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div style="display:flex;">'.CRLF;
  $o1.='   <input type="hidden" name="fld_color_back_css" id="fld_color_back_css"   value="'.enti1($xxxFldValues['fld_color_back_css']).'" />'.CRLF;
  $o1.='   <div id="div__display_color_fld_color_back_css" style="display:flex;">'.CRLF;
  if($xxxFldValues['fld_color_back_css']!=''){  // fld_color_back_css
   $val=json_decode($xxxFldValues['fld_color_back_css'],true);
   $o1.='    <div style="width:35px;height:35px;border:1px #eee inset;background-color:#'.$val['hexValue'].'"></div>';
   $o1.='    <div>'.enti1($val['hexValue']).'';
   if(isset($val['webName']) && $val['webName']!=''){
    $o1.=','.enti1($val['webName']).'';
   }
   if(isset($val['pantoneName']) && $val['pantoneName']!=''){
    $o1.=', pantone:'.enti1($val['pantoneName']).'';
   }
   $o1.='    </div>';
  }
  $o1.='   </div>';
  $o1.='   <div>';
  $o1.='    <button type="button" id="button_color_fld_color_back_css" onclick="javascript:setColor1(\'fld_color_back_css\',\'button_color_fld_color_back_css\',\'div__display_color_fld_color_back_css\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">';
  $o1.=txtsys1('update color');
  $o1.='</button>';
  $o1.='   </div>';
     
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_color_text_css_515_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div style="display:flex;">'.CRLF;
  $o1.='   <input type="hidden" name="fld_color_text_css" id="fld_color_text_css"   value="'.enti1($xxxFldValues['fld_color_text_css']).'" />'.CRLF;
  $o1.='   <div id="div__display_color_fld_color_text_css" style="display:flex;">'.CRLF;
  if($xxxFldValues['fld_color_text_css']!=''){
   $val=json_decode($xxxFldValues['fld_color_text_css'],true);
   $o1.='    <div style="width:35px;height:35px;border:1px #eee inset;background-color:#'.$val['hexValue'].'"></div>';
   $o1.='    <div>'.enti1($val['hexValue']).'';
   if(isset($val['webName']) && $val['webName']!=''){
    $o1.=','.enti1($val['webName']).'';
   }
   if(isset($val['pantoneName']) && $val['pantoneName']!=''){
    $o1.=', pantone:'.enti1($val['pantoneName']).'';
   }
   $o1.='    </div>';
  }
  $o1.='   </div>';
  $o1.='   <div>';
  $o1.='    <button type="button" id="button_color_fld_color_text_css" onclick="javascript:setColor1(\'fld_color_text_css\',\'button_color_fld_color_text_css\',\'div__display_color_fld_color_text_css\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">';
  $o1.=txtsys1('update color');
  $o1.='</button>';
  $o1.='   </div>';
     
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  
  $listeDesValeursCss=$xxxFldValues['fld_json_css'];
//  echo __FILE__ . ' ' . __LINE__ . ' $listeDesValeursCss = <pre>' . var_export( $listeDesValeursCss , true ) . '</pre>' ; exit(0);
  $tableauDesCss=array();
  if($listeDesValeursCss!=''){
    $jsonCss=json_decode($listeDesValeursCss,true);
//    echo __FILE__ . ' ' . __LINE__ . ' $jsonCss = <pre>' . var_export( $jsonCss , true ) . '</pre>' ; exit(0);
  }else{
   $jsonCss=array();
  }
  $colPrec='';
  $colCrt='';
  foreach($cssList as $k1 => $v1){
   $o1.=' <div class="fdiv1">'.CRLF;
   $o1.='  <div class="flab1"><div>'.$k1.'</div></div>'.CRLF;
   $o1.='  <div class="finp1"><div style="display:flex;flex-wrap:wrap;">'.CRLF;
   
   foreach($v1 as $k2 => $v2){
    $o1.='   <div style="display:flex;flex-wrap:wrap;border:1px white inset;">';
   
    $val=array('hexValue' => $v2['hexValue']);
    if(isset($jsonCss[$k1][$k2])){
     $val=$jsonCss[$k1][$k2];
//     echo __FILE__ . ' ' . __LINE__ . ' $val = <pre>' . var_export( $val , true ) . '</pre>' ; exit(0);
    }
    $o1.='    <div>';
    $o1.='     <div>'.$k2.'</div>'.CRLF;
    $o1.='    </div>';
    
    if($k1=='badge'){
     $o1.='    <div style="display:flex;width:320px;">';    
    }else{
     $o1.='    <div style="display:flex;">';    
    }
    $o1.='     <input type="hidden" name="'.$k2.'" id="'.$k2.'"   value="'.enti1(json_encode($val)).'" />'.CRLF;
    $o1.='     <div id="div__display_color_'.$k2.'" style="display:flex;">'.CRLF;
    if($val!=''){
     $o1.='      <div style="width:35px;height:35px;border:1px #eee inset;background-color:#'.$val['hexValue'].'"></div>';
     $o1.='      <div style="font-size:0.8em;">'.enti1($val['hexValue']).'';
     $colCrt=$val['hexValue'];
     if(isset($val['webName']) && $val['webName']!=''){
      $o1.=','.enti1($val['webName']).'';
     }
     if(isset($val['pantoneName']) && $val['pantoneName']!=''){
      $o1.=', pantone:'.enti1($val['pantoneName']).'';
     }
     if(isset($val['materialName']) && $val['materialName']!=''){
      $o1.=', material:'.enti1($val['materialName']).'';
     }
     $o1.='      </div>';
    }
    $o1.='     </div>';
    $o1.='     <div>';
    $o1.='      <button type="button" id="button_color_'.$k2.'" onclick="javascript:setColor1(\''.$k2.'\',\'button_color_'.$k2.'\',\'div__display_color_'.$k2.'\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">'.txtsys1('update color').'</button>';
    $o1.='     </div>';
    $o1.='    </div>';
    $o1.='   </div>';
    if($k1=='badge'){
//     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $v1 , true ) . '</pre>' ; exit(0);
     if(strpos($k2,'TextColor')!==false){
      $o1.='<div><span class="badge" style="color:#'.$colCrt.';background:#'.$colPrec.';">Badge</span></div>';
//      $o1.='<div style="flex-basis: 100%;"></div>';
     }
    }    
    $colPrec=$colCrt;
    if(isset($v2['hr_after']) ){
     $o1.='<div style="flex-basis: 100%;"></div>';
    }
   }
   
   $o1.='  </div></div>'.CRLF;
   $o1.=' </div>'.CRLF;
   
  }

  $o1.='<div class="fdiv1">'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="hidden" name="fld_cntupd_css" id="fld_cntupd_css" value="'.$name2['fld_cntupd_css'].'" />'.CRLF;
  $o1.='   <button type="submit" class="btn btn-primary">'.txtsys1('save_the_modification').'</button>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.='</div>'.CRLF;

  $o1.='</form>'.CRLF;

 //=================================================================================================================================
 //============================================= GET VIEW ==========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='v'&&isset($_GET['id'])&&is_numeric($_GET['id'])){ // view action
  // if you vant to do something here, go !
 //=================================================================================================================================
 //============================================= GET CREATE ========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='c'){ // create action
 
  $o1.='<h2>'.txt2('Add a new record_616_20'). ' '.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $o1.='<form method="post" class="form1">'.CRLF;
 

  $fld_name_css =isset($_SESSION[PGMK][NAV][BNF]['fld_name_css'] )?$_SESSION[PGMK][NAV][BNF]['fld_name_css']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_name_css_472_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_name_css).'" name="fld_name_css" id="fld_name_css" maxlength="32" style="width:100%;max-width:34em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $fld_color_back_css =isset($_SESSION[PGMK][NAV][BNF]['fld_color_back_css'] )?$_SESSION[PGMK][NAV][BNF]['fld_color_back_css']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_color_back_css_488_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div style="display:flex;">'.CRLF;
  $o1.='   <input type="hidden" name="fld_color_back_css" id="fld_color_back_css"   value="'.enti1($fld_color_back_css).'" />'.CRLF;
  $o1.='   <div id="div__display_color_fld_color_back_css" style="display:flex;">'.CRLF;
  if($fld_color_back_css!=''){  // fld_color_back_css
   $val=json_decode($fld_color_back_css,true);
   $o1.='    <div style="width:35px;height:35px;border:1px #eee inset;background-color:#'.$val['hexValue'].'"></div>'; // fld_color_back_css
   $o1.='    <div>'.enti1($val['hexValue']).'';
   if(isset($val['webName']) && $val['webName']!=''){
    $o1.=','.enti1($val['webName']).'';
   }
   if(isset($val['pantoneName']) && $val['pantoneName']!=''){
    $o1.=', pantone:'.enti1($val['pantoneName']).'';
   }
   $o1.='    </div>';
  }
  $o1.='   </div>';
  $o1.='   <div>';
  $o1.='    <button type="button" id="button_color_fld_color_back_css" onclick="javascript:setColor1(\'fld_color_back_css\',\'button_color_fld_color_back_css\',\'div__display_color_fld_color_back_css\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">';
  $o1.=txtsys1('update color');
  $o1.='</button>';
  $o1.='   </div>';
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $fld_color_text_css =isset($_SESSION[PGMK][NAV][BNF]['fld_color_text_css'] )?$_SESSION[PGMK][NAV][BNF]['fld_color_text_css']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_color_text_css_515_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div style="display:flex;">'.CRLF;
  $o1.='   <input type="hidden" name="fld_color_text_css" id="fld_color_text_css"   value="'.enti1($fld_color_text_css).'" />'.CRLF;
  $o1.='   <div id="div__display_color_fld_color_text_css" style="display:flex;">'.CRLF;
  if($fld_color_text_css!=''){  // fld_color_text_css
   $val=json_decode($fld_color_text_css,true);
   $o1.='    <div style="width:35px;height:35px;border:1px #eee inset;background-color:#'.$val['hexValue'].'"></div>'; // fld_color_text_css
   $o1.='    <div>'.enti1($val['hexValue']).'';
   if(isset($val['webName']) && $val['webName']!=''){
    $o1.=','.enti1($val['webName']).'';
   }
   if(isset($val['pantoneName']) && $val['pantoneName']!=''){
    $o1.=', pantone:'.enti1($val['pantoneName']).'';
   }
   $o1.='    </div>';
  }
  $o1.='   </div>';
  $o1.='   <div>';
  $o1.='    <button type="button" id="button_color_fld_color_text_css" onclick="javascript:setColor1(\'fld_color_text_css\',\'button_color_fld_color_text_css\',\'div__display_color_fld_color_text_css\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">';
  $o1.=txtsys1('update color');
  $o1.='</button>';
  $o1.='   </div>';
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  
  
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('record_the_element').'</button>'.CRLF;
  $o1.='   <input type="hidden" name="fld_json_css" id="fld_json_css"  value="" />'.CRLF;
  $o1.='   <input type="hidden" value="0" name="id1" id="id1" />'.CRLF;
  $o1.='   <input type="hidden" value="c" name="a" id="a" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.='</form>'.CRLF;

 }
 $o1.=htmlFoot0(array('js' => $js1));
 dw1($o1);
 if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);
}
