<?php
function getTdo_paramrules1($id){
 $nam=array();
 $n['fld_id_parrules']       =0;
 $n['fld_name_parrules']     ='';
 $n['fld_id_param_parrules'] =''; // null possible
 $n['fld_tsupd_parrules']    ='1000-01-01 00:00:00';
 $n['fld_tscrt_parrules']    ='1000-01-01 00:00:00';
 $n['fld_cntupd_parrules']   =0;
 $sql='
  SELECT 
   T0.`fld_id_parrules`       ,T0.`fld_name_parrules`     ,T0.`fld_id_param_parrules` ,T0.`fld_tsupd_parrules`    ,T0.`fld_tscrt_parrules`    ,
   T0.`fld_cntupd_parrules`   
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramrules` T0
  WHERE T0.`fld_id_parrules` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['fld_id_parrules']       = $row[0];
   $n['fld_name_parrules']     = $row[1];
   $n['fld_id_param_parrules'] = $row[2];
   $n['fld_tsupd_parrules']    = $row[3];
   $n['fld_tscrt_parrules']    = $row[4];
   $n['fld_cntupd_parrules']   = $row[5];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}