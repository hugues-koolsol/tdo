<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();

if(isset($_GET['m']) && $_GET['m']=='1' && PGMK!='td'.'o' ){
  header("HTTP/1.1 303 See Other");header('Location: zz_generateSources1.php?withoutPrefixTable1=on');
 exit(0);
}
//========================================================================================================================
function sortFieldsByOrderInOutput($a,$b){
 if ($a['__order_in_output'] == $b['__order_in_output']) {
  return 0;
 }
 return ($a['__order_in_output'] < $b['__order_in_output']) ? -1 : 1;
}
//========================================================================================================================
//========================================================================================================================
//========================================================================================================================
//========================================================================================================================
$toPrint='';
$sourceGenere='';
$warningText='';
//========================================================================================================================
//========================================================================================================================
require_once $GLOBALS['glob_incPath1'].'/zz_inc_tablelinks1.php';
$js1=array(
 'js' =>array(),
);
$GLOBALS['__table_avec_key_tbl']=false;
if(isset($_GET['table'])){
 getTableInfos($_GET);
 
 $listOfTheTablesToIgnore=array();
 
 foreach($_GET as $k1=>$v1){
  if($v1=='ign3'){
   $listOfTheTablesToIgnore[]=(int)substr($k1,16); // __table_option_T
  }
 }
 if(count($listOfTheTablesToIgnore)>0){
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listOfTheTablesToIgnore , true ) . '</pre> $GLOBALS[__listeDesChamps] = <pre>' . var_export( $GLOBALS['__listeDesChamps'] , true ) . '</pre>' ; exit(0);
  foreach($GLOBALS['__listeDesChamps'] as $k1=>$v1){
   foreach($listOfTheTablesToIgnore as $k2=>$v2){
    if(isset($v1['parentField']) && $v1['parentField']['numParent1']==$v2){
     unset($GLOBALS['__listeDesChamps'][$k1]['parentField']);
    }
   }
  }
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listOfTheTablesToIgnore , true ) . '</pre> $GLOBALS[__listeDesChamps] = <pre>' . var_export( $GLOBALS['__listeDesChamps'] , true ) . '</pre>' ; exit(0);
  
 }
 
 
 if(isset($_GET['fieldOrder']) && $_GET['fieldOrder']!=''){
  $arrayOrder=explode(',',$_GET['fieldOrder']);
  $newArrayOrder=array();
  $count=1;
  foreach($arrayOrder as $k1=>$v1){
   $newArrayOrder[$v1]=$count++;
  }
  foreach($GLOBALS['__listeDesChamps'] as $k1=>$v1){
   if($v1['extra']=='auto_increment'){
    $GLOBALS['__listeDesChamps'][$k1]['__order_in_output']=0;
   }else{
    $GLOBALS['__listeDesChamps'][$k1]['__order_in_output']=999;
   }
   foreach($newArrayOrder as $k2=>$v2){
    if('T0.'.$v1['nom_champ']==$k2){
     $GLOBALS['__listeDesChamps'][$k1]['__order_in_output']=$v2;
    }
   }
  }
  usort($GLOBALS['__listeDesChamps'] , 'sortFieldsByOrderInOutput' );
  $GLOBALS['__lstChampsTries']=array();
  foreach($GLOBALS['__listeDesChamps'] as $k1=>$v1){
   $v1['refTableNumber']=0;
   if(isset($v1['parentField'])){
    $v1['__hasParentField']=1;
   }else{
    $v1['__hasParentField']=0;
   }
   
   $GLOBALS['__lstChampsTries'][]=$v1;
   if(isset($v1['parentField'])){
    foreach($v1['parentField']['fieldList'] as $k2=>$v2){
     $v2['refTableNumber']=$v1['parentField']['numParent1'];
     $GLOBALS['__lstChampsTries'][]=$v2;
    }
   }
  }
  
  foreach($GLOBALS['__lstChampsTries'] as $k1=>$v1){
   if(isset($v1['parentField'])){
    unset($GLOBALS['__lstChampsTries'][$k1]['parentField']);
   }
   if(isset($_GET['a']) && $_GET['a']=='action1' && $v1['refTableNumber']>0){
    unset($GLOBALS['__lstChampsTries'][$k1]);
   }
  }
  
  foreach($GLOBALS['__lstChampsTries'] as $k1=>$v1){
   if(!isset($v1['__order_in_output'])){
    foreach($newArrayOrder as $k2=>$v2){
     if('T'.$v1['refTableNumber'].'.'.$v1['nom_champ']==$k2){
      $GLOBALS['__lstChampsTries'][$k1]['__order_in_output']=$v2;
     }
    }
   }
  }
  $count=998;
  foreach($GLOBALS['__lstChampsTries'] as $k1=>$v1){
   if(!isset($v1['__order_in_output'])){
    $GLOBALS['__lstChampsTries'][$k1]['__order_in_output']=$count--;
   }
  }
  usort($GLOBALS['__lstChampsTries'] , 'sortFieldsByOrderInOutput' );
    
 }else{
  
  $GLOBALS['__lstChampsTries']=array();
  foreach($GLOBALS['__listeDesChamps'] as $k1=>$v1){
   $v1['refTableNumber']=0;
   if(isset($v1['parentField'])){
    $v1['__hasParentField']=1;
   }else{
    $v1['__hasParentField']=0;
   }
   $GLOBALS['__lstChampsTries'][]=$v1;
   if(isset($v1['parentField'])){
    foreach($v1['parentField']['fieldList'] as $k2=>$v2){
     $v2['refTableNumber']=$v1['parentField']['numParent1'];
     $GLOBALS['__lstChampsTries'][]=$v2;
    }
   }
  }
  foreach($GLOBALS['__lstChampsTries'] as $k1=>$v1){
   if(isset($v1['parentField'])){
    unset($GLOBALS['__lstChampsTries'][$k1]['parentField']);
   }
  }
  $count=0;
  foreach($GLOBALS['__lstChampsTries'] as $k1=>$v1){
   $GLOBALS['__lstChampsTries'][$k1]['__order_in_output']=$count++;
  }
  
  usort($GLOBALS['__lstChampsTries'] , 'sortFieldsByOrderInOutput' );
 }

 if(substr($_GET['table'],0,8)==PGMK.'_tbl_'){
  $GLOBALS['__table_avec_key_tbl']=true;
 }
 if(substr($_GET['table'],0,9)==PGMK.'_tbl__'){
  $GLOBALS['tableShortName']=substr($_GET['table'],9);
 }else if(substr($_GET['table'],0,8)==PGMK.'_tbl_'){
  $GLOBALS['tableShortName']=substr($_GET['table'],8);
 }else{
  $GLOBALS['tableShortName']=$_GET['table'];
 }
 if(PGMK=='td'.'o'){
  $GLOBALS['file_action_to_call']='zz_'.$GLOBALS['tableShortName'].'_action1.php';
  $GLOBALS['file_list_to_call']  ='zz_'.$GLOBALS['tableShortName'].'1.php';
  $GLOBALS['file_inc_to_include']='zz_inc_'.$GLOBALS['tableShortName'].'1.php';
 }else{
  
  $GLOBALS['file_action_to_call']=''.$GLOBALS['tableShortName'].'_action1.php'; 
  if(substr($GLOBALS['file_action_to_call'],0,4)==PGMK.'_'){
   $GLOBALS['file_action_to_call']=substr($GLOBALS['file_action_to_call'],4);
  }

  $GLOBALS['file_inc_to_include']='_inc_'.$GLOBALS['tableShortName'].'1.php';
  
  $GLOBALS['file_list_to_call']  =''.$GLOBALS['tableShortName'].'1.php';
  if(substr($GLOBALS['file_list_to_call'],0,4)==PGMK.'_'){
   $GLOBALS['file_list_to_call']=substr($GLOBALS['file_list_to_call'],4);
  }

 }
 $GLOBALS['function_include_to_call']='getinc_'.PGMK.'_'.$GLOBALS['tableShortName'].'1';
 $GLOBALS['function_include_to_call_with_parent_field']='getinc_'.PGMK.'_'.$GLOBALS['tableShortName'].'_withParentFields1';
 $GLOBALS['function_difference_to_call']='get_'.PGMK.'_'.$GLOBALS['tableShortName'].'_difference1';
 $GLOBALS['function_rebuild_to_call']='get_'.PGMK.'_'.$GLOBALS['tableShortName'].'_rebuild_insert1';
 if(PGMK!='td'.'o' &&substr($GLOBALS['tableShortName'],0,4)==PGMK.'_'){
  $GLOBALS['function_include_to_call']                  ='getinc_'.$GLOBALS['tableShortName'].'1';
  $GLOBALS['function_include_to_call_with_parent_field']='getinc_'.$GLOBALS['tableShortName'].'_withParentFields1';
  $GLOBALS['function_difference_to_call']               ='get_'.$GLOBALS['tableShortName'].'_difference1';
  $GLOBALS['function_rebuild_to_call']                  ='get_'.$GLOBALS['tableShortName'].'_rebuild_insert1';
 } 
}


if(isset($_GET['a']) && $_GET['a']=='inc1'){
 $sourceGenere.='<'.'?php'.CRLF;
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='function '.$GLOBALS['function_include_to_call'].'($id){'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $sourceGenere.='function '.$GLOBALS['function_include_to_call'].'(';
   $listeChampsCles='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles.=',$'.$v1;
   }
   $sourceGenere.=substr($listeChampsCles,1);
   $sourceGenere.='){'.CRLF;
  }else{
   $sourceGenere.='//==================================================================================================='.CRLF;
   $sourceGenere.='// TODO no auto_increment field in this table => find the todo.s in this source to adjust it manually'.CRLF;
   $sourceGenere.='//==================================================================================================='.CRLF;
   $sourceGenere.='function '.$GLOBALS['function_include_to_call'].'($todo){'.CRLF;
  }
 }
 $sourceGenere.=' $n=array();'.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  $sourceGenere.=' $n[\'T0_'.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ) . '=';
  if(true===$v1['isNumericField']){
   if($v1['null_possible']=='YES'){
    $sourceGenere.='null; // null possible';
   }else{
    $sourceGenere.='0;';
   }
  }else if(strtolower($v1['type_champ'])=='datetime'){
   if($v1['null_possible']=='YES'){
    $sourceGenere.='null; // null possible';
   }else{
    $sourceGenere.='\'1000-01-01 00:00:00\';';
   }
  }else if(strtolower($v1['type_champ'])=='date'){
   if($v1['null_possible']=='YES'){
    $sourceGenere.='null; // null possible';
   }else{
    $sourceGenere.='\'1000-01-01\';';
   }
  }else if(strtolower($v1['type_champ'])=='time'){
   if($v1['null_possible']=='YES'){
    $sourceGenere.='null; // null possible';
   }else{
    $sourceGenere.='\'00:00:00\';';
   }
  }else{
   $sourceGenere.='\'\';';
  }
  $sourceGenere.=CRLF;
  if($v1['comment']!=''){
   $jsonComment=json_decode($v1['comment'],true);
   if(isset($jsonComment['param'])){
    if('yorno'!==$jsonComment['param']){
     if(!is_file($GLOBALS['glob_noVcPath1'].'/parameters/'.$jsonComment['param'].'.php')){
      header("HTTP/1.1 303 See Other");header('Location: '.BNF . '?m=1');
      exit();
     }
     include $GLOBALS['glob_noVcPath1'].'/parameters/'.$jsonComment['param'].'.php';
     if(!isset($GLOBALS['param__'.$jsonComment['param']]['param__definition']['dependencies'])){
      $warningText.='<div class="yywarning">Warning missing dependencies on this table in param '.$jsonComment['param'].'  </div>';
     }else{
      $dependenciesFounded=false;
      $tmp=is_array($GLOBALS['param__'.$jsonComment['param']]['param__definition']['dependencies'])?$GLOBALS['param__'.$jsonComment['param']]['param__definition']['dependencies']:array();
      foreach( $tmp as $kdp => $vdp){
       if($vdp['table']==$_GET['table'] && $vdp['field'] == $v1['nom_champ'] ){
        $dependenciesFounded=true;
       }
      }
      if($dependenciesFounded==false){
       $warningText.='<div class="yywarning">Warning missing dependencies on this table in param '.$jsonComment['param'].'  </div>';     
      }
     }
    }
   }
  }
 }
 $sourceGenere.=' $sql=\''.CRLF;
 $sourceGenere.='  SELECT ';
 $count=0;
 $listeChamps='';
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if($count%5==0){
   $listeChamps.=CRLF.'   ';
  }
  if($v1['type_champ']!='geometry'){
   $listeChamps.='T0.`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).',';
  }else{
   $listeChamps.='ST_AsText(T0.`'.$v1['nom_champ'].'`)'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])-11 ).',';
  }
  $count++;
 }
 $listeChamps=substr($listeChamps,0,-1);
 $sourceGenere.=$listeChamps.CRLF;
 $sourceGenere.='  FROM `\'.$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\'].\'`.`'.$_GET['table'].'` T0'.CRLF;
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='  WHERE T0.`'.$GLOBALS['__autoincrement'].'` = \'.$id. \''.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listewhere1='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    foreach($GLOBALS['__listeDesChamps'] as $k2 => $v2){
     if($v2['nom_champ']==$v1){
      if($v2['isNumericField']){
       $listewhere1.='AND T0.`'.$v1.'` = \'.$'.$v1.'.\' ';
      }else{
       $listewhere1.='AND T0.`'.$v1.'` = \\\'\'.addslashes($'.$v1.').\'\\\' ';
      }
     }
    }
   }
   $sourceGenere.='  WHERE '.substr($listewhere1,4);
  }else{
   $sourceGenere.='  WHERE T0.`todo` = \'.$id. \' -- todo no auto increment here'.CRLF;
  }
 }
 $sourceGenere.=' \';'.CRLF;
 $sourceGenere.=' $req=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$sql);'.CRLF;
 $sourceGenere.=' if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])==0){'.CRLF;
 $sourceGenere.='  while($row=mysqli_fetch_row($req)){'.CRLF;
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  $sourceGenere.='   $n[\'T0_'.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ) . '= $row['.$count.'];'.CRLF;
  $count++;
 }
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  mysqli_free_result($req);'.CRLF;
 $sourceGenere.=' }else{'.CRLF;
 $sourceGenere.='  debugSql2(array(\'sqler\' => \' in \'. __FUNCTION__ . \' \' . mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']),\'reque\' => $sql , \'file\' => __FILE__ , \'line\' => __LINE__ ));'.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' return($n);'.CRLF;
 $sourceGenere.='}'.CRLF;
 
 if(sizeof($GLOBALS['__parentTables'])>0){
  
  $sourceGenere.='//======================================================================'.CRLF;
  if($GLOBALS['__autoincrement']!=''|| sizeof($GLOBALS['__listeChampsCles'])>0){
   if($GLOBALS['__autoincrement']!=''){
    $sourceGenere.='function '.$GLOBALS['function_include_to_call_with_parent_field'].'($id){'.CRLF;
   }else{
    if(sizeof($GLOBALS['__listeChampsCles'])>0){
     $sourceGenere.='function '.$GLOBALS['function_include_to_call_with_parent_field'].'(';
     $listeChampsCles='';
     foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
      $listeChampsCles.=',$'.$v1;
     }
     $sourceGenere.=substr($listeChampsCles,1);
     $sourceGenere.='){'.CRLF;
    }else{
     $sourceGenere.='// TODO no auto_increment field in this table => find the todo.s in this source to adjust it manually'.CRLF;
     $sourceGenere.='function '.$GLOBALS['function_include_to_call_with_parent_field'].'($todo){'.CRLF;
    }
   }
   
   
   $sourceGenere.=' $n=array();'.CRLF;
   foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
    $sourceGenere.=' $n[\'T0_'.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ) . '='; 
    if(true===$v1['isNumericField']){
     if($v1['null_possible']=='YES'){
      $sourceGenere.='null; // null possible';
     }else{
      $sourceGenere.='0;';
     }
    }else if(strtolower($v1['type_champ'])=='datetime'){
     if($v1['null_possible']=='YES'){
      $sourceGenere.='null; // null possible';
     }else{
      $sourceGenere.='\'1000-01-01 00:00:00\';';
     }
    }else if(strtolower($v1['type_champ'])=='date'){
     if($v1['null_possible']=='YES'){
      $sourceGenere.='null; // null possible';
     }else{
      $sourceGenere.='\'1000-01-01\';';
     }
    }else if(strtolower($v1['type_champ'])=='time'){
     if($v1['null_possible']=='YES'){
      $sourceGenere.='null; // null possible';
     }else{
      $sourceGenere.='\'00:00:00\';';
     }
    }else{
     $sourceGenere.='\'\';';
    }
    $sourceGenere.=CRLF;
   }   
   foreach($GLOBALS['__parentTables'] as $k0 => $v0){
    foreach($v0['parent_fields'] as $k1 => $v1){
     $sourceGenere.=' $n[\'T'.$v0['numParent1'].'_'.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ) . '=';
     
     if(true===$v1['isNumericField']){
      if($v1['null_possible']=='YES'){
      $sourceGenere.='null; // null possible';
      }else{
       $sourceGenere.='0;';
      }
     }else if(strtolower($v1['type_champ'])=='datetime'){
      if($v1['null_possible']=='YES'){
      $sourceGenere.='null; // null possible';
      }else{
       $sourceGenere.='\'1000-01-01 00:00:00\';';
      }
     }else if(strtolower($v1['type_champ'])=='date'){
      if($v1['null_possible']=='YES'){
      $sourceGenere.='null; // null possible';
      }else{
       $sourceGenere.='\'1000-01-01\';';
      }
     }else if(strtolower($v1['type_champ'])=='time'){
      if($v1['null_possible']=='YES'){
      $sourceGenere.='null; // null possible';
      }else{
       $sourceGenere.='\'00:00:00\';';
      }
     }else{
      $sourceGenere.='\'\';';
     }
     $sourceGenere.=CRLF;
    }
   }
   $sourceGenere.=' $sql=\''.CRLF;
   $sourceGenere.='  SELECT ';
   $count=0;
   $listeChamps='';
   foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
    if($count%5==0){
     $listeChamps.=CRLF.'   ';
    }
    if($v1['type_champ']!='geometry'){
     $listeChamps.='T0.`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).',';
    }else{
     $listeChamps.='ST_AsText(T0.`'.$v1['nom_champ'].'`)'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])-11 ).',';     
    }
    $count++;
   }
   foreach($GLOBALS['__parentTables'] as $k0 => $v0){
    foreach($v0['parent_fields'] as $k1 => $v1){
     if($count%5==0){
      $listeChamps.=CRLF.'   ';
     }
     if($v1['type_champ']!='geometry'){
      $listeChamps.='T'.$v0['numParent1'].'.`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).',';
     }else{
      $listeChamps.='ST_AsText(T'.$v0['numParent1'].'.`'.$v1['nom_champ'].'`)'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])-11 ).',';
     }
     $count++;
    }
   }
   $listeChamps=substr($listeChamps,0,-1);
   $sourceGenere.=$listeChamps.CRLF;
   $sourceGenere.='  FROM ( `\'.$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\'].\'`.`'.$_GET['table'].'` T0'.CRLF;
   $listeDesTables='';
   foreach($GLOBALS['__parentTables'] as $k0 => $v0){
    if($v0['mandatory']==1){
     $listeDesTables.='       , `\'.$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\'].\'`.`'.$v0['parent_table_name'].'` T'.$v0['numParent1'].''.CRLF;
    }
   }
   $sourceGenere.=$listeDesTables;
   $sourceGenere.='       )'.CRLF;
   $listeDesJoins='';
   foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
    if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 && $v1['parentField']['fld_link_mandatory_pglnks']=='0' ){
     $listeDesJoins.=', LEFT JOIN `\'.$GLOBALS[\'glob_db\']['.$v1['parentField']['fld_parent_idbase_pglnks'].'][\'dbname\'].\'`';
     $listeDesJoins.='.`'.$v1['parentField']['fld_name_tables'].'` ';
     $listeDesJoins.=' T'.$v1['parentField']['numParent1'].' ON T0.`'.$v1['nom_champ'].'` '.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ) . '= ';
     $listeDesJoins.='T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_pglnks'].'` '.CRLF;
    }
   }
   if($listeDesJoins!=''){
    $listeDesJoins=substr($listeDesJoins,1);
    $sourceGenere.=$listeDesJoins;
   }
   if($GLOBALS['__autoincrement']!=''){
    $sourceGenere.='  WHERE T0.`'.$GLOBALS['__autoincrement'].'` = \'.$id. \''.CRLF;
   }else{
    if(sizeof($GLOBALS['__listeChampsCles'])>0){
     $listewhere1='';
     foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
      foreach($GLOBALS['__listeDesChamps'] as $k2 => $v2){
       if($v2['nom_champ']==$v1){
        if($v2['isNumericField']){
         $listewhere1.='AND T0.`'.$v1.'` = \'.$'.$v1.'.\' ';
        }else{
         $listewhere1.='AND T0.`'.$v1.'` = \\\'\'.addslashes($'.$v1.').\'\\\' ';
        }
       }
      }
     }
     $sourceGenere.='  WHERE '.substr($listewhere1,4);
    }else{
     $sourceGenere.='  WHERE T0.`todo` = \'.$id. \' -- todo no auto increment here'.CRLF;
    }
   }
   
   
   foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
    if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 ){
     if( $v1['parentField']['fld_link_mandatory_pglnks']=='1' ){
      $sourceGenere.=CRLF.'    AND T0.`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ) . '=T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_pglnks'].'`'.CRLF;
     }
    }
   }
   
   
   $sourceGenere.=' \';'.CRLF;
   $sourceGenere.=' $req=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$sql);'.CRLF;
   $sourceGenere.=' if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])==0){'.CRLF;
   $sourceGenere.='  while($row=mysqli_fetch_row($req)){'.CRLF;
   $count=0;
   foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
    $sourceGenere.='   $n[\'T0_'.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ) . '= $row['.$count.'];'.CRLF;
    $count++;
   }
   
   foreach($GLOBALS['__parentTables'] as $k0 => $v0){
    foreach($v0['parent_fields'] as $k1 => $v1){
     if($count%5==0){
      $listeChamps.=CRLF.'   ';
     }
     $sourceGenere.='   $n[\'T'.$v0['numParent1'].'_'.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ) . '= $row['.$count.'];'.CRLF;
     $count++;
    }
   }
   
   $sourceGenere.='  }'.CRLF;
   $sourceGenere.='  mysqli_free_result($req);'.CRLF;
   $sourceGenere.=' }else{'.CRLF;
   $sourceGenere.='  debugSql2(array(\'sqler\' => \' in \'. __FUNCTION__ . \' \' . mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']),\'reque\' => $sql , \'file\' => __FILE__ , \'line\' => __LINE__ ));'.CRLF;
   $sourceGenere.=' }'.CRLF;
   $sourceGenere.=' return($n);'.CRLF;
   
   
  }else{
   $sourceGenere.='// TODO no auto_increment field in this table => find the todo.s in this source to adjust it manually'.CRLF;
   $sourceGenere.='function '.$GLOBALS['function_include_to_call_with_parent_field'].'($todo){'.CRLF;
  }
  
  $sourceGenere.='}'.CRLF;
 }
 
 $listeDesTests1='';
 $listeDesTests2='';
 $listeDesInsert1='';
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'])){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    $listeDesTests1.='  && $b[\'T0_'.$v1['nom_champ'].'\']==$a[\'T0_'.$v1['nom_champ'].'\']'.CRLF;
    
    if($v1['null_possible']=='YES'){
     $listeDesTests2.='  if($b[\'T0_'.$v1['nom_champ'].'\']!=$a[\'T0_'.$v1['nom_champ'].'\']){'.CRLF;
     $listeDesTests2.='   $t1.=\''.$v1['nom_champ'].' from "\'.(is_null($b[\'T0_'.$v1['nom_champ'].'\'])?\'NULL\':$b[\'T0_'.$v1['nom_champ'].'\']).\'" to "\'.(is_null($a[\'T0_'.$v1['nom_champ'].'\'])?\'NULL\':$a[\'T0_'.$v1['nom_champ'].'\']).\'"\'.CRLF;'.CRLF;
     $listeDesTests2.='  }'.CRLF;
    }else{
     $listeDesTests2.='  if($b[\'T0_'.$v1['nom_champ'].'\']!=$a[\'T0_'.$v1['nom_champ'].'\']){'.CRLF;
     $listeDesTests2.='   $t1.=\''.$v1['nom_champ'].' from "\'.$b[\'T0_'.$v1['nom_champ'].'\'].\'" to "\'.$a[\'T0_'.$v1['nom_champ'].'\'].\'"\'.CRLF;'.CRLF;
     $listeDesTests2.='  }'.CRLF;
    }
   }
  }
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $v1 , true ) . '</pre>' ; exit(0);
  if($v1['null_possible']=='YES'){
   if($count==0){
    if($v1['type_champ']=='geometry'){
     $listeDesInsert1.=' $t1.=\'   `'.$v1['nom_champ'].'` = \'.(is_null($f[\'T0_'.$v1['nom_champ'].'\'])?\'NULL\':\'ST_GeomFromText(\\\'\'.addslashes($f[\'T0_'.$v1['nom_champ'].'\']).\'\\\')\') . \' \'.CRLF;'.CRLF;
    }else{
     $listeDesInsert1.=' $t1.=\'   `'.$v1['nom_champ'].'` = \'.(is_null($f[\'T0_'.$v1['nom_champ'].'\'])?\'NULL\':\'\\\'\'.addslashes($f[\'T0_'.$v1['nom_champ'].'\']).\'\\\'\') . \' \'.CRLF;'.CRLF;
    }
   }else{
    if($v1['type_champ']=='geometry'){
     $listeDesInsert1.=' $t1.=\' , `'.$v1['nom_champ'].'` = \'.(is_null($f[\'T0_'.$v1['nom_champ'].'\'])?\'NULL\':\'ST_GeomFromText(\\\'\'.addslashes($f[\'T0_'.$v1['nom_champ'].'\']).\'\\\')\') . \' \'.CRLF;'.CRLF;   
    }else{
     $listeDesInsert1.=' $t1.=\' , `'.$v1['nom_champ'].'` = \'.(is_null($f[\'T0_'.$v1['nom_champ'].'\'])?\'NULL\':\'\\\'\'.addslashes($f[\'T0_'.$v1['nom_champ'].'\']).\'\\\'\') . \' \'.CRLF;'.CRLF;   
    }     
   }
  }else{
   if($count==0){
    if($v1['type_champ']=='geometry'){
     $listeDesInsert1.=' $t1.=\'   `'.$v1['nom_champ'].'` = ST_GeomFromText(\\\'\'.addslashes($f[\'T0_'.$v1['nom_champ'].'\']) . \'\\\') \'.CRLF;'.CRLF;
    }else{
     $listeDesInsert1.=' $t1.=\'   `'.$v1['nom_champ'].'` = \\\'\'.addslashes($f[\'T0_'.$v1['nom_champ'].'\']) . \'\\\' \'.CRLF;'.CRLF;    
    }
   }else{
    if($v1['type_champ']=='geometry'){
     $listeDesInsert1.=' $t1.=\' , `'.$v1['nom_champ'].'` = ST_GeomFromText\\\'\'.addslashes($f[\'T0_'.$v1['nom_champ'].'\']) . \'\\\') \'.CRLF;'.CRLF;
    }else{
     $listeDesInsert1.=' $t1.=\' , `'.$v1['nom_champ'].'` = \\\'\'.addslashes($f[\'T0_'.$v1['nom_champ'].'\']) . \'\\\' \'.CRLF;'.CRLF;   
    }
   }
  }
  $count++;
 }
 if($listeDesTests1!='' && !(isset($_GET['type']) && $_GET['type']=='view')){  
  $sourceGenere.='//======================================================================'.CRLF;
  $sourceGenere.='function '.$GLOBALS['function_difference_to_call'].'($b,$a){ // before , after'.CRLF;
  $sourceGenere.=' if('.CRLF;
  $sourceGenere.='     '.substr($listeDesTests1,5);
  $sourceGenere.=' ){'.CRLF;
  $sourceGenere.='  return \'// UPDATE no difference\'.CRLF;'.CRLF;
  $sourceGenere.=' }else{;'.CRLF;
  $sourceGenere.='  $t1=\'\';'.CRLF;
  $sourceGenere.=$listeDesTests2;
  $sourceGenere.='  if($_SESSION[PGMK][\'login\'] != $_SESSION[PGMK][\'loginInit\']){'.CRLF;
  $sourceGenere.='   $t1.=CRLF.\'=========\'.CRLF.\'loginInit(\'.$_SESSION[PGMK][\'loginInit\'].\') != login(\'.$_SESSION[PGMK][\'login\'].\')\'.CRLF.\'=========\'.CRLF;'.CRLF;
  $sourceGenere.='  }'.CRLF;
  $sourceGenere.='  return \'/*\'.CRLF.\'UPDATE list of differences\'.CRLF.CRLF.$t1.CRLF.\'*/\'.CRLF;'.CRLF;
  $sourceGenere.=' }'.CRLF;
  $sourceGenere.='}'.CRLF;
  
  $sourceGenere.='//======================================================================'.CRLF;
  $sourceGenere.='function '.$GLOBALS['function_rebuild_to_call'].'($f){'.CRLF;
  $sourceGenere.=' $t1=\'// DELETE FROM `'.$_GET['table'].'` OK, the insert would be : \'.CRLF;'.CRLF;
  $sourceGenere.=' $t1.=\'$sql[]=<\'.\'<\'.\'<EOT\'.CRLF;'.CRLF;
  $sourceGenere.=' $t1.=\'INSERT INTO `\'.$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\'].\'`.`'.$_GET['table'].'` SET\'.CRLF;'.CRLF;
  $sourceGenere.=$listeDesInsert1;
  $sourceGenere.=' $t1.=\'EOT;\'.CRLF;'.CRLF;
  $sourceGenere.=' return $t1;'.CRLF;
  $sourceGenere.='}'.CRLF;
  
 }
 
}
//========================================================================================================================
//========================================================================================================================
//========================================================================================================================
if(isset($_GET['a']) && ( $_GET['a']=='list2' || $_GET['a']=='choose1' )){
 $modeChoose=false;
 if($_GET['a']=='choose1'){
  $modeChoose=true;
 }
 $sourceGenere.='<'.'?php // € utf8 check with euro sign'.CRLF;
 $sourceGenere.='define(\'BNF\',basename( __FILE__ ));'.CRLF;
 $sourceGenere.='require_once \'za_inc.php\';'.CRLF;
 $sourceGenere.='session_start();'.CRLF;
 $sourceGenere.='@include  $GLOBALS[\'glob_noVcPath1\'].\'/translation_for_pages/\'.$GLOBALS[\'glob_lang\'].\'_\'.BNF;'.CRLF;

// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['__listeDesChamps'] , true ) . '</pre>' ; exit(0);
 $listeDesParametres=array();
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField'])){
   foreach( $v1['parentField']['fieldList'] as $k0 => $v0){
    if(isset($v0['param_name'])){
     if(!in_array($v0['param_name'],$listeDesParametres)){
      $sourceGenere.='require_once($GLOBALS[\'glob_noVcPath1\'].\'/parameters/'.$v0['param_name'].'.php\');'.CRLF;
      $listeDesParametres[]=$v0['param_name'];
     }
    }
   }
  }else{
   if(isset($v1['param_name'])){
    if(!in_array($v1['param_name'],$listeDesParametres)){
     $sourceGenere.='require_once($GLOBALS[\'glob_noVcPath1\'].\'/parameters/'.$v1['param_name'].'.php\');'.CRLF;
     $listeDesParametres[]=$v1['param_name'];
    }
   }
  }
 }
 
 $sourceGenere.='checkGroupPages();'.CRLF;
 
 if($modeChoose==true){
  $sourceGenere.=CRLF;
  $sourceGenere.='if(isset($_GET[\'idchoose\'])){'.CRLF;
  $sourceGenere.=' $_SESSION[PGMK][\'choose\'][\'valueBack\']=$_GET[\'idchoose\'];'.CRLF;
  $sourceGenere.=' header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.$_SESSION[PGMK][\'choose\'][\'urlBack\']); '.CRLF;
  $sourceGenere.=' exit();'.CRLF;
  $sourceGenere.='}'.CRLF;
  $sourceGenere.=CRLF;

  $sourceGenere.='if(!isset($_SESSION[PGMK][\'choose\'][\'urlBack\'])){'.CRLF;
  $sourceGenere.=' header(\'HTTP/1.1 303 See Other\');header(\'Location: index.php?message=\'.urlencode(txtsys1(\'the_navigation_has_been_lost\')));'.CRLF;
  $sourceGenere.=' exit();'.CRLF;
  $sourceGenere.='}'.CRLF;
 } 
 $sourceGenere.='openDb1();'.CRLF;
 
 
 $sourceGenere.='//========================================================================================================================'.CRLF;
 $sourceGenere.='$o1=\'\';'.CRLF;
 $sourceGenere.='$__nbMax=20;'.CRLF;
 $sourceGenere.='$__start=0;'.CRLF;
 $sourceGenere.='$__count=0;'.CRLF;
 $sourceGenere.='$__xpage=0;'.CRLF;
 $sourceGenere.='if(isset($_GET[\'__xpage\'])&&is_numeric($_GET[\'__xpage\'])){'.CRLF;
 $sourceGenere.=' $__xpage=$_GET[\'__xpage\'];'.CRLF;
 $sourceGenere.='}else{'.CRLF;
 $sourceGenere.=' if(isset($_SESSION[PGMK][NAV][BNF][\'__xpage\'])) $__xpage=$_SESSION[PGMK][NAV][BNF][\'__xpage\'];'.CRLF;
 $sourceGenere.='}'.CRLF;
 $count=0;
 foreach($GLOBALS['__lstChampsTries'] as $k1=>$v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if($v1['__ignore_for_display']==false){
     $doit=true;
     if($v1['type_champ']=='geometry'){
      $doit=false;
     }
     if(isset($v1['subtype']) && $v1['subtype']=='password'){
      $doit=false;
     }
     if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb'){
      $doit=false;
     }
     if($doit){
      
      if($v1['null_possible']=='YES'){
       $sourceGenere.='$xsrch_'.$count.'=saveSessionSearch1(\'xsrch_'.$count.'\',BNF);// filter search for '.$v1['nom_champ'].' defined '.CRLF;       
       $GLOBALS['__lstChampsTries'][$k1]['xsearchnullsearch']='xsrch_'.$count;
       $count++;      
      }
      
      
      $sourceGenere.='$xsrch_'.$count.'=saveSessionSearch1(\'xsrch_'.$count.'\',BNF);// T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].''.CRLF;
      $GLOBALS['__lstChampsTries'][$k1]['xsearch']='xsrch_'.$count;
      $count++;
     }
    }
   }
  }
 }

 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='$xsrch_id=saveSessionSearch1(\'xsrch_id\',BNF);// '.$GLOBALS['__autoincrement'].''.CRLF;
 }
 $sourceGenere.='$xsrch_sort=saveSessionSearch1(\'xsrch_sort\',BNF);'.CRLF;
 $sourceGenere.=CRLF.'//=========== tests on inputs ==============='.CRLF;
 $count=0;
 foreach($GLOBALS['__lstChampsTries'] as $k1=>$v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']&&isset($v1['xsearch'])){
    if(isset($v1['param_name'])){
    }else if(false && isset($v1['parentField'])){
    }else{
     $doit=true;
     if($v1['type_champ']=='geometry'){
      $doit=false;
     }
     if(isset($v1['subtype']) && $v1['subtype']=='password'){
      $doit=false;
     }
     if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb'){
      $doit=false;
     }
     if($doit){
      if($v1['isNumericField'] && isset($v1['__hasParentField']) && $v1['__hasParentField']==1){
       $sourceGenere.='if($'.$v1['xsearch'].'!=\'\'){'.CRLF;
       $sourceGenere.=' $xsrch_ids=str_replace(\'.\',\',\',$'.$v1['xsearch'].');'.CRLF;
       $sourceGenere.=' $xsrch_ids=str_replace("\\t",\'\',str_replace(\' \',\'\',$xsrch_ids));'.CRLF;
       $sourceGenere.=' $xsrch_ids=explode(\',\',$xsrch_ids);'.CRLF;
       $sourceGenere.=' $listIdsOk=true;'.CRLF;
       $sourceGenere.=' foreach($xsrch_ids as $v1){'.CRLF;
       $sourceGenere.='  if(!is_numeric($v1)){'.CRLF;
       $sourceGenere.='   $listIdsOk=false;'.CRLF;
       $sourceGenere.='   break;'.CRLF;
       $sourceGenere.='  }'.CRLF;
       $sourceGenere.=' }'.CRLF;
       $sourceGenere.=' if(!$listIdsOk){'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_must_fill_a_numeric_value_for_the_field\') . \' : \' . txt1(\''.('T'.$v1['refTableNumber'].'.').''.$v1['nom_champ'].'\');'.CRLF;
       $sourceGenere.=' }'.CRLF;
       $sourceGenere.='}'.CRLF;
      }else if(substr($v1['type_champ'],0,4)=='set('){
       $sourceGenere.='if(is_array($'.$v1['xsearch'].') && sizeof($'.$v1['xsearch'].')==1 && $'.$v1['xsearch'].'[0]==\'\'){  // set : '.$v1['nom_champ'].''.CRLF;
       $sourceGenere.=' $'.$v1['xsearch'].'=\'\';'.CRLF;
       $sourceGenere.='}'.CRLF;
      }else if(true===$v1['isNumericField']){
       $sourceGenere.='$'.$v1['xsearch'].'=str_replace("\\t",\'\',str_replace(\' \',\'\',$'.$v1['xsearch'].'));'.CRLF;
       $sourceGenere.='if($'.$v1['xsearch'].'!=\'\'){'.CRLF;
       $sourceGenere.=' if(!is_numeric($'.$v1['xsearch'].')){'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_must_fill_a_numeric_value_for_the_field\') . \' : \' . txt1(\''.('T'.$v1['refTableNumber'].'.').''.$v1['nom_champ'].'\');'.CRLF;
       $sourceGenere.=' }'.CRLF;
       $sourceGenere.='}'.CRLF;
      }
     }
    }
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='if($xsrch_id!=\'\'){ // autoincrement'.CRLF;
  $sourceGenere.=' $xsrch_ids=str_replace(\'.\',\',\',$xsrch_id);'.CRLF;
  $sourceGenere.=' $xsrch_ids=str_replace("\\t",\'\',str_replace(\' \',\'\',$xsrch_ids));'.CRLF;
  $sourceGenere.=' $xsrch_ids=explode(\',\',$xsrch_ids);'.CRLF;
  $sourceGenere.=' $listIdsOk=true;'.CRLF;
  $sourceGenere.=' foreach($xsrch_ids as $v1){'.CRLF;
  $sourceGenere.='  if(!is_numeric($v1)){'.CRLF;
  $sourceGenere.='   $listIdsOk=false;'.CRLF;
  $sourceGenere.='   break;'.CRLF;
  $sourceGenere.='  }'.CRLF;
  $sourceGenere.=' }'.CRLF;
  $sourceGenere.=' if(!$listIdsOk){'.CRLF;
  $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_must_fill_a_numeric_value_for_the_field\') . \' : \' . txt1(\'T0.'.$GLOBALS['__autoincrement'].'\');'.CRLF;
  $sourceGenere.=' }'.CRLF;
  $sourceGenere.='}'.CRLF;
 }


 foreach($GLOBALS['__lstChampsTries'] as $k1 => $v1){
  if($v1['nom_champ']!=$GLOBALS['__autoincrement']&&isset($v1['xsearch'])){
   if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
    $sourceGenere.='if(is_array($'.$v1['xsearch'].') && sizeof($'.$v1['xsearch'].')==1 && $'.$v1['xsearch'].'[0]==\'\'){ // '.$v1['nom_champ'].''.CRLF;
    $sourceGenere.=' $'.$v1['xsearch'].'=\'\';'.CRLF;
    $sourceGenere.='}'.CRLF;
   }
  }
 }
 $sourceGenere.='//=========== /tests on inputs ==============='.CRLF.CRLF;

 $count=0;
 foreach($GLOBALS['__lstChampsTries'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']&&isset($v1['xsearch'])){
    if($count==0){
     $sourceGenere.='$autofocus=\''.$v1['xsearch'].'\';'.CRLF;
     $count++;
    }
   }
  }
 }
 $count=0;
 foreach($GLOBALS['__lstChampsTries'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']&&isset($v1['xsearch'])){
    if(isset($v1['xsearchnullsearch'])){
     if($count==0){
      $sourceGenere.='if($'.$v1['xsearchnullsearch'].'!=\'\'){      $autofocus=\''.$v1['xsearchnullsearch'].'\'; } // condition search for '.$v1['nom_champ'].' defined'.CRLF;
      $count++;
     }else{
      $sourceGenere.='else if($'.$v1['xsearchnullsearch'].'!=\'\'){ $autofocus=\''.$v1['xsearchnullsearch'].'\'; } // condition search for '.$v1['nom_champ'].' defined'.CRLF;
      $count++;
     }
    }
    if($count==0){
     $sourceGenere.='if($'.$v1['xsearch'].'!=\'\'){      $autofocus=\''.$v1['xsearch'].'\'; } // '.$v1['nom_champ'].''.CRLF;
     $count++;
    }else{
     $sourceGenere.='else if($'.$v1['xsearch'].'!=\'\'){ $autofocus=\''.$v1['xsearch'].'\'; } // '.$v1['nom_champ'].''.CRLF;
     $count++;
    }
   }
  }
 }
 
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='else if($xsrch_id!=\'\'){ $autofocus=\'xsrch_id\'; }'.CRLF;
 }

 $sourceGenere.='$o1.=htmlHead1(array(\'nomenu\'=>true));'.CRLF;
 
 if(!$modeChoose){
  $sourceGenere.='$o1.=\'<h1>\'.txt1(\'list of '.$GLOBALS['tableShortName'].'\').\'</h1>\';'.CRLF;
 }else{
  $sourceGenere.='$o1.=\'<h1>\'.txt1(\'select a '.$GLOBALS['tableShortName'].'\');'.CRLF;
  $sourceGenere.='$o1.=\'&nbsp;<a class="buttonBack" href="\'.$_SESSION[PGMK][\'choose\'][\'urlBack\'].\'">Retour</a>\'.CRLF;'.CRLF;
  $sourceGenere.='$o1.=\'</h1>\';'.CRLF.CRLF;
 }
  $sourceGenere.='$o1.=displaySessionMessage1(BNF);'.CRLF.CRLF;
  $sourceGenere.='$o1.=\' <form method="get" class="yyfilterForm">\'.CRLF;'.CRLF;

 //=================================================================================================================================
 //=================================================================================================================================
 function gererFiltre3($v1){
  $sourceGenere='';
  $prefix='T'.$v1['refTableNumber'].'.';
  if(isset($v1['param_name'])){
   $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
   $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF;'.CRLF;
   if(isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){

    $sourceGenere.='$o1.=\'    <select size="3" name="'.$v1['xsearch'].'[]"   multiple="multiple" style="max-width:10em;" id="'.$v1['xsearch'].'" \'.($autofocus==\''.$v1['xsearch'].'\'?\'autofocus="autofocus"\':\'\').\' \';'.CRLF;
    $sourceGenere.='if(is_array($'.$v1['xsearch'].')){'.CRLF;
    $sourceGenere.=' if($'.$v1['xsearch'].'[0]!=\'\'){'.CRLF;
    $sourceGenere.='  $o1.=\' class="yybackgroundYellow" \';'.CRLF;
    $sourceGenere.=' }'.CRLF;
    $sourceGenere.='}else{'.CRLF;
    $sourceGenere.=' if($'.$v1['xsearch'].'!=\'\'){$o1.=\' class="yybackgroundYellow" \';}'.CRLF;
    $sourceGenere.='}'.CRLF;
    $sourceGenere.='$o1.=\'  />\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'<option value="" \'.($'.$v1['xsearch'].'==\'\'?\'  selected="selected" \':\'\').\'>&nbsp;</option>\'.CRLF;'.CRLF;
    $sourceGenere.='if(!is_array($'.$v1['xsearch'].')) $'.$v1['xsearch'].'=array();'.CRLF;
    $sourceGenere.='if(is_array($'.$v1['xsearch'].') && in_array( \'__all_values_of_set__\' , $'.$v1['xsearch'].' )){'.CRLF;
    $sourceGenere.=' $o1.=\'<option value="__all_values_of_set__" selected="selected" >\'.txtsys1(\'all_values_of_set_list\').\'</option>\'.CRLF;'.CRLF;
    $sourceGenere.='}else{'.CRLF;
    $sourceGenere.=' $o1.=\'<option value="__all_values_of_set__">\'.txtsys1(\'all_values_of_set_list\').\'</option>\'.CRLF; '.CRLF;
    $sourceGenere.='}'.CRLF;
    $sourceGenere.='foreach($GLOBALS[\'param__'.$v1['param_name'].'\'][\'__values\'][$GLOBALS[\'glob_lang\']] as $kp => $vp){'.CRLF;
    $sourceGenere.=' if(in_array($kp,$'.$v1['xsearch'].')){'.CRLF;
    $sourceGenere.='  $o1.=\'<option value="\'.$kp.\'" selected="selected">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\'</option>\'.CRLF;'.CRLF;
    $sourceGenere.=' }else{'.CRLF;
    $sourceGenere.='  $o1.=\'<option value="\'.$kp.\'">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\' </option>\'.CRLF;  '.CRLF;
    $sourceGenere.=' }'.CRLF;
    $sourceGenere.='}'.CRLF;
    $sourceGenere.='$o1.=\'    </select>\';'.CRLF;

   }else{

    $sourceGenere.='$o1.=\'    <select \'.($'.$v1['xsearch'].'!=\'\'?\'class="yybackgroundYellow"\':\'\').\' name="'.$v1['xsearch'].'"  id="'.$v1['xsearch'].'" \'.($autofocus==\''.$v1['xsearch'].'\'?\'autofocus="autofocus"\':\'\').\' onchange="submitListFromSelect1(this)" >\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'<option value="" \'.($'.$v1['xsearch'].'==\'\'?\'  selected="selected" \':\'\').\'>&nbsp;</option>\'.CRLF;'.CRLF;
    if(isset($v1['unsetPossible']) && $v1['unsetPossible']==true){
     $sourceGenere.='if(\'NULL\'==(string)$'.$v1['xsearch'].'){'.CRLF;
     $sourceGenere.=' $o1.=\'<option value="NULL"  selected="selected">\'.txtsys1(\'undefined\').\'</option>\'.CRLF;  '.CRLF;
     $sourceGenere.='}else{'.CRLF;
     $sourceGenere.=' $o1.=\'<option value="NULL">\'.txtsys1(\'undefined\').\'</option>\'.CRLF;   '.CRLF;
     $sourceGenere.='}'.CRLF;
    }
    $sourceGenere.='foreach($GLOBALS[\'param__'.$v1['param_name'].'\'][\'__values\'][$GLOBALS[\'glob_lang\']] as $kp => $vp){'.CRLF;
    $sourceGenere.=' if((string)$kp==(string)$'.$v1['xsearch'].'){'.CRLF;
    $sourceGenere.='  $o1.=\'<option value="\'.$kp.\'" selected="selected">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\'</option>\'.CRLF;'.CRLF;
    $sourceGenere.=' }else{'.CRLF;
    $sourceGenere.='  $o1.=\'<option value="\'.$kp.\'">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\' </option>\'.CRLF;  '.CRLF;
    $sourceGenere.=' }'.CRLF;
    $sourceGenere.='}'.CRLF;
    $sourceGenere.='$o1.=\'    </select>\';'.CRLF;

   }
   $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF.CRLF;
  }else{
   if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){

    $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
    $sourceGenere.='$o1.=\'    <input type="hidden" name="'.$v1['xsearch'].'" id="'.$v1['xsearch'].'"   value="\'.enti1($'.$v1['xsearch'].').\'"  \'.($autofocus==\''.$v1['xsearch'].'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'    <button \'.($'.$v1['xsearch'].'!=\'\'?\'class="yybackgroundYellow"\':\'\').\' style="padding:0px!important;" type="button" id="button_color_'.$v1['xsearch'].'" onclick="javascript:setColor1(\\\''.$v1['xsearch'].'\\\',\\\'button_color_'.$v1['xsearch'].'\\\',\\\'\\\',1,1,\\\'onChangeDateListForm1\\\')" style="border-style:outset;font-size:0.8em;padding:5px;">\';'.CRLF;
    $sourceGenere.='$o1.=($'.$v1['xsearch'].'==\'\'?txtsys1(\'color all\'):($'.$v1['xsearch'].'==\'NULL\'?txtsys1(\'color null\'):($'.$v1['xsearch'].'==\'NOT NULL\'?txtsys1(\'color not null\'):$'.$v1['xsearch'].')));'.CRLF;
    $sourceGenere.='$o1.=\'</button>\';'.CRLF;
    $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
   }else if(isset($v1['__filter_is_date']) && $v1['__filter_is_date']==true && ($v1['type_champ']=='datetime' || $v1['type_champ']=='time' || $v1['type_champ']=='date' ) ){
    $sourceGenere.=''.CRLF;
    $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
    $sourceGenere.='$o1.=\'    <input \'.($'.$v1['xsearch'].'!=\'\'?\'class="yybackgroundYellow"\':\'\').\' type="text" name="'.$v1['xsearch'].'" id="'.$v1['xsearch'].'"   value="\'.enti1($'.$v1['xsearch'].').\'"  size="8" maxlength="19"  \'.($autofocus==\''.$v1['xsearch'].'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
    $sourceGenere.=''.CRLF;
   }else if($v1['type_champ']=='datetime'){

    $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
    $sourceGenere.='$o1.=\'    <input type="hidden" name="'.$v1['xsearch'].'"    id="'.$v1['xsearch'].'"   value="\'.enti1($'.$v1['xsearch'].').\'" />\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'    <button type="button" id="button_datetime_'.$v1['xsearch'].'" onclick="javascript:setDateTime1(\\\''.$v1['xsearch'].'\\\',\\\'button_datetime_'.$v1['xsearch'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',1,\\\'onChangeDtTimListForm1\\\')" style="padding:0px!important;border-style:outset;font-size:0.8em;\'.($'.$v1['xsearch'].'!=\'\'?\'background:yellow;\':\'\').\'">\';'.CRLF;
    $sourceGenere.='$o1.=($'.$v1['xsearch'].'==\'\'?txtsys1(\'datetime all\'):($'.$v1['xsearch'].'==\'NULL\'?txtsys1(\'datetime null\'):($'.$v1['xsearch'].'==\'NOT NULL\'?txtsys1(\'datetime not null\'):$'.$v1['xsearch'].')));'.CRLF;
    $sourceGenere.='$o1.=\'</button>\';'.CRLF;
    $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
    $sourceGenere.=''.CRLF;

   }else if($v1['type_champ']=='time'){

    $timeOption=0;
    if(isset($v1['timeOption']) &&  $v1['timeOption']!='' ){
     $timeOption=$v1['timeOption'];
    }
    $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
    $sourceGenere.='$o1.=\'    <input type="hidden" name="'.$v1['xsearch'].'"    id="'.$v1['xsearch'].'"   value="\'.enti1($'.$v1['xsearch'].').\'" />\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'    <button type="button" id="button_time_'.$v1['xsearch'].'" onclick="javascript:setTime1(\\\''.$v1['xsearch'].'\\\',\\\'button_time_'.$v1['xsearch'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',1,\\\'onChangeTimeListForm1\\\','.$timeOption.')" style="padding:0px!important;border-style:outset;font-size:0.8em;padding:5px;\'.($'.$v1['xsearch'].'!=\'\'?\'background:yellow;\':\'\').\'">\';'.CRLF;
    $sourceGenere.='$o1.=($'.$v1['xsearch'].'==\'\'?txtsys1(\'time all\'):($'.$v1['xsearch'].'==\'NULL\'?txtsys1(\'time null\'):($'.$v1['xsearch'].'==\'NOT NULL\'?txtsys1(\'time not null\'):';
    if(isset($v1['timeOption']) && ( $v1['timeOption']==1 || $v1['timeOption']==3 || $v1['timeOption']==5 || $v1['timeOption']==7)){
     $sourceGenere.='substr($'.$v1['xsearch'].',0,5)';
    }else{
     $sourceGenere.='$'.$v1['xsearch'].'';
    }
    $sourceGenere.=')));'.CRLF;
    $sourceGenere.='$o1.=\'</button>\';'.CRLF;
    $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
    $sourceGenere.=''.CRLF;

   }else if($v1['type_champ']=='date'){
    $sourceGenere.='if($'.$v1['xsearch'].'==\'1000-01-01\') $'.$v1['xsearch'].'=\'\';'.CRLF;
    $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
    $sourceGenere.='$o1.=\'    <input type="hidden" name="'.$v1['xsearch'].'"    id="'.$v1['xsearch'].'"   value="\'.enti1($'.$v1['xsearch'].').\'" />\'.CRLF;'.CRLF;
    $sourceGenere.='$o1.=\'    <button type="button" id="button_date_'.$v1['xsearch'].'" onclick="javascript:setDate1(\\\''.$v1['xsearch'].'\\\',\\\'button_date_'.$v1['xsearch'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',1,\\\'onChangeDateListForm1\\\')" style="padding:0px!important;font-size:0.8em;border-style:outset;\'.($'.$v1['xsearch'].'==\'\'?\'\':\'background:yellow;\').\'">\';'.CRLF;
    $sourceGenere.='$o1.=(($'.$v1['xsearch'].'==\'1000-01-01\' || $'.$v1['xsearch'].'==\'\' )?txtsys1(\'date all\'):($'.$v1['xsearch'].'==\'NULL\'?txtsys1(\'date null\'):($'.$v1['xsearch'].'==\'NOT NULL\'?txtsys1(\'date not null\'):$xsrch_4)));'.CRLF;
    $sourceGenere.='$o1.=\'</button>\';'.CRLF;
    $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
    $sourceGenere.=''.CRLF;
    
   }else{
    if(true===$v1['isNumericField']){
     $sourceGenere.=''.CRLF;
     $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
     $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='$o1.=\'    <input \'.($'.$v1['xsearch'].'!=\'\'?\'class="yybackgroundYellow"\':\'\').\' type="text" name="'.$v1['xsearch'].'" id="'.$v1['xsearch'].'"   value="\'.enti1($'.$v1['xsearch'].').\'"  size="8" maxlength="32"  \'.($autofocus==\''.$v1['xsearch'].'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
     $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
     $sourceGenere.=''.CRLF;
    }else{
     if(substr($v1['type_champ'],0,5)=='enum('){
      $lstEnum='$tempevalenum=array('.str_replace('\'\'','\\\'',substr($v1['type_champ'],5,-1).');');
      eval($lstEnum);
      if(true){
       $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
       $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
       $sourceGenere.='$o1.=\'    <select \'.($'.$v1['xsearch'].'!=\'\'?\'class="yybackgroundYellow"\':\'\').\' name="'.$v1['xsearch'].'"  id="'.$v1['xsearch'].'" \'.($autofocus==\''.$v1['xsearch'].'\'?\'autofocus="autofocus"\':\'\').\' onchange="submitListFromSelect1(this)" >\'.CRLF;'.CRLF;
       $sourceGenere.='$o1.=\'     <option value="" \'.($'.$v1['xsearch'].'==\'\'?\'  selected="selected" \':\'\').\'>&nbsp;</option>\'.CRLF;'.CRLF;
       foreach($tempevalenum as $keval1 => $veval1){
        $sourceGenere.='$o1.=\'     <option value="\'.'.htmlentities(var_export($veval1,true)).'.\'" \'.($'.$v1['xsearch'].'=='.var_export($veval1,true).'?\'  selected="selected" \':\'\').\'>\'.'.var_export($veval1,true).'.\'</option>\'.CRLF;'.CRLF;       
       }
       $sourceGenere.='$o1.=\'    </select>\';'.CRLF;
       $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF.CRLF;
      }else{
       $sourceGenere.='// todo for enum field'.CRLF;
      }
     }else if(substr($v1['type_champ'],0,4)=='set('){
      $lstEnum='$tempevalenum=array('.str_replace('\'\'','\\\'',substr($v1['type_champ'],4,-1).');');
      eval($lstEnum);
      if(true){
       $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
       $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
       $sourceGenere.='$setValuesFor'.$v1['xsearch'].'=' . var_export( $tempevalenum  , true ) . ';'.CRLF;
       $sourceGenere.='$o1.=\'    <select size="3" multiple="multiple" \'.($'.$v1['xsearch'].'!=\'\'?\'class="yybackgroundYellow"\':\'\').\' name="'.$v1['xsearch'].'[]"  id="'.$v1['xsearch'].'" \'.($autofocus==\''.$v1['xsearch'].'\'?\'autofocus="autofocus"\':\'\').\' \';'.CRLF;
       $sourceGenere.='if(is_array($'.$v1['xsearch'].')){'.CRLF;
       $sourceGenere.=' if($'.$v1['xsearch'].'[0]!=\'\'){'.CRLF;
       $sourceGenere.='  $o1.=\' class="yybackgroundYellow" \';'.CRLF;
       $sourceGenere.=' }'.CRLF;
       $sourceGenere.='}else{'.CRLF;
       $sourceGenere.=' if($'.$v1['xsearch'].'!=\'\'){$o1.=\' class="yybackgroundYellow" \';}'.CRLF;
       $sourceGenere.='}'.CRLF;
       $sourceGenere.='$o1.=\' >\'.CRLF;'.CRLF;
       $sourceGenere.='$o1.=\'     <option value="" \'.($'.$v1['xsearch'].'==\'\'?\'  selected="selected" \':\'\').\'>&nbsp;</option>\'.CRLF;'.CRLF;
       $sourceGenere.='if(!is_array($'.$v1['xsearch'].')) $'.$v1['xsearch'].'=array();'.CRLF;
       $sourceGenere.='if(is_array($'.$v1['xsearch'].') && in_array( \'__all_values_of_set__\' , $'.$v1['xsearch'].' )){'.CRLF;
       $sourceGenere.=' $o1.=\'<option value="__all_values_of_set__" selected="selected" >\'.txtsys1(\'all_values_of_set_list\').\'</option>\'.CRLF;'.CRLF;
       $sourceGenere.='}else{'.CRLF;
       $sourceGenere.=' $o1.=\'<option value="__all_values_of_set__">\'.txtsys1(\'all_values_of_set_list\').\'</option>\'.CRLF; '.CRLF;
       $sourceGenere.='}'.CRLF;
       foreach($tempevalenum as $keval1 => $veval1){
        $sourceGenere.='$o1.=\'     <option value="\'.'.htmlentities(var_export($veval1,true)).'.\'" \'.(in_array('.var_export($veval1,true).',$'.$v1['xsearch'].')?\'  selected="selected" \':\'\').\'>\'.'.var_export($veval1,true).'.\'</option>\'.CRLF;'.CRLF;       
       }
       $sourceGenere.='$o1.=\'    </select>\';'.CRLF;
       $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF.CRLF;
      }else{
       $sourceGenere.='// todo for enum field'.CRLF;
      }
//      echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $tempevalenum , true ) . '</pre>' ; exit(0);
     }else if($v1['type_champ']=='timestamp'){
      $sourceGenere.=''.CRLF;
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input \'.($'.$v1['xsearch'].'!=\'\'?\'class="yybackgroundYellow"\':\'\').\' type="text" name="'.$v1['xsearch'].'" id="'.$v1['xsearch'].'"   value="\'.enti1($'.$v1['xsearch'].').\'"  size="'.($v1['fieldSize']<8?$v1['fieldSize']:8).'" maxlength="19"  \'.($autofocus==\''.$v1['xsearch'].'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $sourceGenere.=''.CRLF;
     }else{
      if(strpos($v1['type_champ'],'text')!==false){
       $sourceGenere.=''.CRLF;
       $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
       $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
       $sourceGenere.='$o1.=\'    <input \'.($'.$v1['xsearch'].'!=\'\'?\'class="yybackgroundYellow"\':\'\').\' type="text" name="'.$v1['xsearch'].'" id="'.$v1['xsearch'].'"   value="\'.enti1($'.$v1['xsearch'].').\'"  size="8" maxlength="64"  \'.($autofocus==\''.$v1['xsearch'].'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
       $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
       $sourceGenere.=''.CRLF;
      }else{
       $sourceGenere.=''.CRLF;
       $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
       $sourceGenere.='$o1.=\'    <label for="'.$v1['xsearch'].'">\'.txt1(\''.$prefix.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
       $sourceGenere.='$o1.=\'    <input \'.($'.$v1['xsearch'].'!=\'\'?\'class="yybackgroundYellow"\':\'\').\' type="text" name="'.$v1['xsearch'].'" id="'.$v1['xsearch'].'"   value="\'.enti1($'.$v1['xsearch'].').\'"  size="'.($v1['fieldSize']<8?$v1['fieldSize']:8).'" maxlength="'.$v1['fieldSize'].'"  \'.($autofocus==\''.$v1['xsearch'].'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
       $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
       $sourceGenere.=''.CRLF;
      }
     }
    }
   }
  }  
  
  return $sourceGenere;
 }
 //=================================================================================================================================
 //=================================================================================================================================
 foreach($GLOBALS['__lstChampsTries'] as $k1=>$v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement'] && isset($v1['xsearch']) ){
    $sourceGenere.=gererFiltre3($v1);
   }
  }
 }
 
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.=''.CRLF;
  $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
  $sourceGenere.='$o1.=\'    <label for="xsrch_id">\'.txt1(\'T0.'.$GLOBALS['__autoincrement'].'\').\'</label>\'.CRLF; // '.$GLOBALS['__autoincrement'].''.CRLF;
  $sourceGenere.='$o1.=\'    <input \'.($xsrch_id!=\'\'?\'class="yybackgroundYellow"\':\'\').\' type="text" name="xsrch_id"    id="xsrch_id"   value="\'.enti1($xsrch_id).\'"  size="8" maxlength="32" \'.($autofocus==\'xsrch_id\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
  $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
  $sourceGenere.=''.CRLF;
 }
 
 
 $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
 $sourceGenere.='$o1.=\'    <label for="xsrch_sort">\'.txtsys1(\'sort_order\').\'</label>\'.CRLF; // sort'.CRLF;
 $sourceGenere.='$o1.=\'    <select \'.($xsrch_sort!=\'\'?\'class="yybackgroundYellow"\':\'\').\' name="xsrch_sort"  id="xsrch_sort" \'.($autofocus==\'xsrch_sort\'?\'autofocus="autofocus"\':\'\').\' onchange="submitListFromSelect1(this)" >\'.CRLF;'.CRLF;
 $sourceGenere.='$o1.=\'     <option value="" \'.($xsrch_sort==\'\'?\'  selected="selected" \':\'\').\'>&nbsp;</option>\'.CRLF;'.CRLF;

 foreach($GLOBALS['__lstChampsTries'] as $k1=>$v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] ) ){
   if(isset($v1['xsearch'])){
    if( (!isset($v1['unsetPossible']) || ( isset($v1['unsetPossible']) && $v1['unsetPossible']!=true )) && isset($v1['param']) && $v1['param']=='yorno' ){
     // nothing here
    }else{
     $sourceGenere.='$o1.=\'     <option value="T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].'_ASC" '.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).'\'.($xsrch_sort==\'T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].'_ASC\' '.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).'?\' selected="selected" \':\'\').\'>&#8599; \'.txt1(\'T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].'\').\'</option>\'.CRLF;'.CRLF; 
     $GLOBALS['__lstChampsTries'][$k1]['sort'][]=array(
      'sortName'  => 'T'.$v1['refTableNumber'].'.'.$v1['nom_champ']  . '_ASC'     ,
      'sortField' => 'T'.$v1['refTableNumber'].'.`'.$v1['nom_champ'] . '`' ,
      'sortOrder' => 'ASC' ,
     );
     $sourceGenere.='$o1.=\'     <option value="T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].'_DESC"'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).'\'.($xsrch_sort==\'T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].'_DESC\''.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).'?\' selected="selected" \':\'\').\'>&#8600; \'.txt1(\'T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].'\').\'</option>\'.CRLF;'.CRLF;
     $GLOBALS['__lstChampsTries'][$k1]['sort'][]=array(
      'sortName'  => 'T'.$v1['refTableNumber'].'.'.$v1['nom_champ']  . '_DESC'     ,
      'sortField' => 'T'.$v1['refTableNumber'].'.`'.$v1['nom_champ'] . '`' ,
      'sortOrder' => 'DESC' ,
     );
    }
   }
  }  
 }

 $sourceGenere.='$o1.=\'    </select>\';'.CRLF;
 $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF.CRLF.CRLF;
 

 $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
 $sourceGenere.='$o1.=\'    <button class="button_search">&#128270;</button>\'.CRLF;// #128270'.CRLF;
 $sourceGenere.='$o1.=\'    <input type="hidden" name="__xpage" id="__xpage" value="0" />\'.CRLF; // \'.$__xpage.\''.CRLF;
 $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF.CRLF;

 $sourceGenere.='$o1.=\' </form>\'.CRLF;'.CRLF;

 $sourceGenere.='//===================================================================================================='.CRLF;
 $sourceGenere.='$__start=$__xpage*$__nbMax;'.CRLF;
 $sourceGenere.='$_SESSION[PGMK][NAV][BNF][\'__xpage\']=$__xpage;'.CRLF;
 $sourceGenere.='$lst=\'\';'.CRLF;
 $sourceGenere.='// todo adjust the request'.CRLF;
 $sourceGenere.='$req6=\''.CRLF;
 $sourceGenere.=' SELECT  SQL_CALC_FOUND_ROWS';
 $listeChamps='';
 $count=0;
 foreach($GLOBALS['__lstChampsTries'] as $k1=>$v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if($count%5==0){
    $listeChamps.=CRLF.'   ';
   }
   if($v1['type_champ']=='geometry'){
    $listeChamps.='ST_AsText(T'.$v1['refTableNumber'].'.`'.$v1['nom_champ'].'`)'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])-11 ).',';
   }else{
    $listeChamps.='T'.$v1['refTableNumber'].'.`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).',';   
   }
   $GLOBALS['__lstChampsTries'][$k1]['numsqlselect']=$count++;
  }
 }
 
 $listeChamps=substr($listeChamps,0,-1);
 $sourceGenere.='   '.$listeChamps.CRLF;
 $sourceGenere.=' FROM (   `\'.$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\'].\'`.`'.$_GET['table'].'` T0';
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 && $v1['parentField']['fld_link_mandatory_pglnks']=='1' ){
   $sourceGenere.=CRLF.'        , ';
   $sourceGenere.='`\'.$GLOBALS[\'glob_db\']['.$v1['parentField']['fld_parent_idbase_pglnks'].'][\'dbname\'].\'`';
   $sourceGenere.='.`'.$v1['parentField']['fld_name_tables'].'` T'.$v1['parentField']['numParent1'].'';
  }
 }

 $sourceGenere.=' ) '.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 && $v1['parentField']['fld_link_mandatory_pglnks']=='0' ){
   $sourceGenere.=' LEFT JOIN `\'.$GLOBALS[\'glob_db\']['.$v1['parentField']['fld_parent_idbase_pglnks'].'][\'dbname\'].\'`';
   $sourceGenere.='.`'.$v1['parentField']['fld_name_tables'].'` ';
   $sourceGenere.=' T'.$v1['parentField']['numParent1'].' ON T0.`'.$v1['nom_champ'].'` = ';
   $sourceGenere.='T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_pglnks'].'`'.CRLF;
  }
 }

 $sourceGenere.=' WHERE 1=1 '.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 ){
   if( $v1['parentField']['fld_link_mandatory_pglnks']=='1' ){
    $sourceGenere.='   AND T0.`'.$v1['nom_champ'].'`=T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_pglnks'].'`'.CRLF;
   }
  }
 }
 $sourceGenere.='\';'.CRLF;
 
 //===========================================================================================================
 //===========================================================================================================
 function gererConditions3($v1){
  $sourceGenere='';
  
  $parentRef='T'.$v1['refTableNumber'];
  if($v1['type_champ']=='date' || $v1['type_champ']=='time' || $v1['type_champ']=='datetime' || ( isset($v1['subtype']) && $v1['subtype']=='webcolor' ) ){

   $sourceGenere.='if($'.$v1['xsearch'].'!=\'\' ){'.CRLF;
   $sourceGenere.=' if($'.$v1['xsearch'].'==\'NULL\'){'.CRLF;
   $sourceGenere.='  $req6.=\''.CRLF;
   $sourceGenere.='   AND '.$parentRef.'.`'.$v1['nom_champ'].'` IS NULL'.CRLF;
   $sourceGenere.='  \';   '.CRLF;
   $sourceGenere.=' }else if($'.$v1['xsearch'].'==\'NOT NULL\'){'.CRLF;
   $sourceGenere.='  $req6.=\''.CRLF;
   $sourceGenere.='   AND '.$parentRef.'.`'.$v1['nom_champ'].'` IS NOT NULL'.CRLF;
   $sourceGenere.='  \';   '.CRLF;
   $sourceGenere.=' }else{'.CRLF;
   $sourceGenere.='  $req6.=\''.CRLF;
   $sourceGenere.='   AND '.$parentRef.'.`'.$v1['nom_champ'].'` LIKE \\\'%\'.addslashes1($'.$v1['xsearch'].').\'%\\\''.CRLF;
   $sourceGenere.='  \'; '.CRLF;
   $sourceGenere.=' }'.CRLF;
   $sourceGenere.='}'.CRLF;

  }else if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){

   $sourceGenere.='if($'.$v1['xsearch'].'!=\'\' ){'.CRLF;
   $sourceGenere.=' $req6.=buildSetCondition($'.$v1['xsearch'].',\'param__'.$v1['param_name'].'\', \''.$parentRef.'.`'.$v1['nom_champ'].'`\' );'.CRLF;
   $sourceGenere.='}'.CRLF;

  }else if(isset($v1['param_name']) ){
   
   if(isset($v1['unsetPossible']) && $v1['unsetPossible']==true){
    $sourceGenere.='if($'.$v1['xsearch'].'!=\'\' ){'.CRLF;
    $sourceGenere.=' if($'.$v1['xsearch'].'==\'NULL\' ){'.CRLF;
    $sourceGenere.='  $req6.=\''.CRLF;
    $sourceGenere.='   AND '.$parentRef.'.`'.$v1['nom_champ'].'` IS NULL '.CRLF;
    $sourceGenere.='  \'; '.CRLF;
    $sourceGenere.=' }else{'.CRLF;
    $sourceGenere.='  $req6.=\''.CRLF;
    $sourceGenere.='   AND '.$parentRef.'.`'.$v1['nom_champ'].'` LIKE \\\'%\'.addslashes1($'.$v1['xsearch'].').\'%\\\''.CRLF;
    $sourceGenere.='  \'; '.CRLF;
    $sourceGenere.=' }'.CRLF;
    $sourceGenere.='}'.CRLF;
   }else{
    if($v1['isNumericField']==true){
     $sourceGenere.='if($'.$v1['xsearch'].'!=\'\' ){'.CRLF;
     $sourceGenere.=' $req6.=\''.CRLF;
     $sourceGenere.='  AND '.$parentRef.'.`'.$v1['nom_champ'].'` = \'.$'.$v1['xsearch'].'.\' '.CRLF;
     $sourceGenere.=' \'; '.CRLF;
     $sourceGenere.='}'.CRLF;
    }else{
     $sourceGenere.='if($'.$v1['xsearch'].'!=\'\' ){'.CRLF;
     $sourceGenere.=' $req6.=\''.CRLF;
     $sourceGenere.='  AND '.$parentRef.'.`'.$v1['nom_champ'].'` LIKE \\\'%\'.addslashes1($'.$v1['xsearch'].').\'%\\\''.CRLF;
     $sourceGenere.=' \'; '.CRLF;
     $sourceGenere.='}'.CRLF;     
    }
   }
   
  }else if(true===$v1['isNumericField']){

   if(isset($v1['__hasParentField']) && $v1['__hasParentField']==1){
    $sourceGenere.='if($'.$v1['xsearch'].'!=\'\'){'.CRLF;
    $sourceGenere.=' $xsrch_ids=str_replace(\'.\',\',\',$'.$v1['xsearch'].');'.CRLF;
    $sourceGenere.=' $xsrch_ids=str_replace("\\t",\'\',str_replace(\' \',\'\',$xsrch_ids));'.CRLF;
    $sourceGenere.=' $xsrch_ids=explode(\',\',$xsrch_ids);'.CRLF;
    $sourceGenere.=' $listIdsOk=true;'.CRLF;
    $sourceGenere.=' foreach($xsrch_ids as $v1){'.CRLF;
    $sourceGenere.='  if(!is_numeric($v1)){'.CRLF;
    $sourceGenere.='   $listIdsOk=false;'.CRLF;
    $sourceGenere.='   break;'.CRLF;
    $sourceGenere.='  }'.CRLF;
    $sourceGenere.=' }'.CRLF;
    $sourceGenere.=' if($listIdsOk){'.CRLF;
    $sourceGenere.='  $req6.=\''.CRLF;
    $sourceGenere.='   AND '.$parentRef.'.`'.$v1['nom_champ'].'` IN (\'.implode(\',\',$xsrch_ids).\') '.CRLF;
    $sourceGenere.='  \'; '.CRLF;
    $sourceGenere.=' }'.CRLF;
    $sourceGenere.='}'.CRLF;
   }else{
    $sourceGenere.='if($'.$v1['xsearch'].'!=\'\' && is_numeric(str_replace("\\t",\'\',str_replace(\' \',\'\',$'.$v1['xsearch'].')))){'.CRLF;
    $sourceGenere.=' $req6.=\''.CRLF;
    $sourceGenere.='  AND '.$parentRef.'.`'.$v1['nom_champ'].'` = \'.str_replace("\\t",\'\',str_replace(\' \',\'\',$'.$v1['xsearch'].')).\''.CRLF;
    $sourceGenere.=' \'; '.CRLF;
    $sourceGenere.='}'.CRLF;
   }

  }else{

   
   if(substr($v1['type_champ'],0,4)=='set('){
    $sourceGenere.='if($'.$v1['xsearch'].'!=\'\' ){'.CRLF;
    $sourceGenere.=' $req6.=buildSetDirectCondition($'.$v1['xsearch'].', $setValuesFor'.$v1['xsearch'].', \''.$parentRef.'.`'.$v1['nom_champ'].'`\');'.CRLF;
    $sourceGenere.='}'.CRLF;
   }else{
    $sourceGenere.='if($'.$v1['xsearch'].'!=\'\' ){'.CRLF;
    $sourceGenere.=' $req6.=\''.CRLF;
    $sourceGenere.='  AND '.$parentRef.'.`'.$v1['nom_champ'].'` LIKE \\\'%\'.addslashes1($'.$v1['xsearch'].').\'%\\\''.CRLF;
    $sourceGenere.=' \'; '.CRLF;
    $sourceGenere.='}'.CRLF;
   }
  }
  return $sourceGenere;
 }
 //===========================================================================================================
 //===========================================================================================================
 
 
 $sourceGenere.=CRLF;
 $sourceGenere.='//============================== filters ==========================='.CRLF;
 $count=0;
 foreach($GLOBALS['__lstChampsTries'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement'] && isset($v1['xsearch']) ){
    $sourceGenere.=gererConditions3($v1);
   }
  }
 }
 
 
 if($GLOBALS['__autoincrement']!=''){
  
  $sourceGenere.='if($xsrch_id!=\'\'){'.CRLF;
  $sourceGenere.=' $xsrch_ids=str_replace(\'.\',\',\',$xsrch_id);'.CRLF;
  $sourceGenere.=' $xsrch_ids=str_replace("\\t",\'\',str_replace(\' \',\'\',$xsrch_ids));'.CRLF;
  $sourceGenere.=' $xsrch_ids=explode(\',\',$xsrch_ids);'.CRLF;
  $sourceGenere.=' $listIdsOk=true;'.CRLF;
  $sourceGenere.=' foreach($xsrch_ids as $v1){'.CRLF;
  $sourceGenere.='  if(!is_numeric($v1)){'.CRLF;
  $sourceGenere.='   $listIdsOk=false;'.CRLF;
  $sourceGenere.='   break;'.CRLF;
  $sourceGenere.='  }'.CRLF;
  $sourceGenere.=' }'.CRLF;
  $sourceGenere.=' if($listIdsOk){'.CRLF;
  $sourceGenere.='  $req6.=\''.CRLF;
  $sourceGenere.='   AND T0.`'.$GLOBALS['__autoincrement'].'` IN (\'.implode(\',\',$xsrch_ids).\') '.CRLF;
  $sourceGenere.='  \'; '.CRLF;
  $sourceGenere.=' }'.CRLF;
  $sourceGenere.='}'.CRLF;
 }
 $sourceGenere.='//============================== /filters ==========================='.CRLF;
 $sourceGenere.=CRLF;
 $sourceGenere.='//============================== sorts ==========================='.CRLF;

 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='if($xsrch_sort==\'\'){ $req6.=\'ORDER BY T0.`'.$GLOBALS['__autoincrement'].'` DESC \';}'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles.=', T0.`'.$v1.'` ASC ';
   }
   $sourceGenere.='if($xsrch_sort==\'\'){ $req6.=\' ORDER BY '.substr($listeChampsCles,1).'\'; }'.CRLF;
  }else{
   $sourceGenere.='if($xsrch_sort==\'\'){ $req6.=\' ORDER BY T0.`todo` DESC \'; }'.CRLF;
  }
 }

 foreach($GLOBALS['__lstChampsTries'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] ) ){
   if(isset($v1['sort'])){
    foreach($v1['sort'] as $k2=>$v2){
     $sourceGenere.='if($xsrch_sort==\''.$v2['sortName'].'\'){'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).' $req6.=\' ORDER BY '.$v2['sortField'].' '.$v2['sortOrder'].'  \'; }'.CRLF;
    }
   }
  }  
 }
 $sourceGenere.=CRLF;
 $sourceGenere.='//============================== /sorts ==========================='.CRLF;
 
 
 $sourceGenere.='$req6.=\' LIMIT \'.$__start.\',\'.$__nbMax.\' \' ;'.CRLF;
 $sourceGenere.='//echo __FILE__ . \' \' . __LINE__ . \' $req6 = <pre>\' .$req6  . \'</pre>\' ; exit(0);'.CRLF;
 $sourceGenere.='$__count=0;'.CRLF;
 $sourceGenere.='$data0=array();'.CRLF;
 $sourceGenere.='$result6=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
 $sourceGenere.='if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])==0){'.CRLF;
 $sourceGenere.=' while($mpsr6=mysqli_fetch_row($result6)){'.CRLF;
 $sourceGenere.='  $data0[]=array('.CRLF;
 foreach($GLOBALS['__lstChampsTries'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] ) ){
   $sourceGenere.='  \'T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].'\''.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).'=>$mpsr6['.$v1['numsqlselect'].'],'.CRLF;
  }
 }
 
 $sourceGenere.='  );'.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' mysqli_free_result($result6);'.CRLF;
 $sourceGenere.=' if(sizeof($data0)>0){'.CRLF;
 $sourceGenere.='  $reqCount6=\'SELECT FOUND_ROWS();\';'.CRLF;
 $sourceGenere.='  $rescount6=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$reqCount6);'.CRLF;
 $sourceGenere.='  if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])==0){'.CRLF;
 $sourceGenere.='   $mpsrcount6=mysqli_fetch_row($rescount6);'.CRLF;
 $sourceGenere.='   $__count=$mpsrcount6[0];'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.='}else{'.CRLF;
 $sourceGenere.=' $o1.=debugSql1(array(\'sqler\' => mysqli_error($GLOBALS[\'glob_db\'][0][\'link\']),\'reque\' => $req6));  '.CRLF;
 $sourceGenere.='}'.CRLF;
 $sourceGenere.='$lsttbl=\'\';'.CRLF;
 $sourceGenere.='if($__count==0){'.CRLF;
 $sourceGenere.=' $lst.=\'<p>\'.CRLF;'.CRLF;
 $sourceGenere.=' $lst.=\'\'.txtsys1(\'no_records_found_with_these_search_criteria\').\'\'.CRLF;'.CRLF;
 if(!$modeChoose){
  $sourceGenere.=' $lst.=\'<a href="'.$GLOBALS['file_action_to_call'].'?a=c">\'.txt1(\'add_a_new_record\').\'</a>\'.CRLF;'.CRLF;
 }
 $sourceGenere.=' $lst.=\'</p>\'.CRLF;'.CRLF;
 $sourceGenere.=' $o1.=\'\'.$lst.\'\'.CRLF;  '.CRLF;
 $sourceGenere.='}else{'.CRLF;
 $sourceGenere.=' $consUrlRedir=\'\'.'.CRLF;

 
 $count=0;
 foreach($GLOBALS['__lstChampsTries'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']&&isset($v1['xsearch'])){
    if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
    }else{
     $doit=true;
     if(substr($v1['type_champ'],0,4)=='set('){
      $doit=false;       
     }
     if($doit){
      $sourceGenere.='               ($'.$v1['xsearch'].'!=\'\'?\'&amp;'.$v1['xsearch'].'=\'.rawurlencode($'.$v1['xsearch'].'):\'\'). // '.$v1['nom_champ'].' '.CRLF;
     }
    }
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='               ($xsrch_id!=\'\'?\'&amp;xsrch_id=\'.rawurlencode($xsrch_id):\'\').'.CRLF;
 }
 $sourceGenere.='               ($xsrch_sort!=\'\'?\'&amp;xsrch_sort=\'.rawurlencode($xsrch_sort):\'\').'.CRLF;
 $sourceGenere.='               \'\';'.CRLF;
 
 foreach($GLOBALS['__lstChampsTries'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){

     $sourceGenere.=' if(is_array($'.$v1['xsearch'].')){'.CRLF;
     $sourceGenere.='  foreach($'.$v1['xsearch'].' as $k1 => $v1){'.CRLF;
     $sourceGenere.='   $consUrlRedir.=\'&amp;'.$v1['xsearch'].'%5B%5D=\'.rawurlencode($v1);'.CRLF;
     $sourceGenere.='  }'.CRLF;
     $sourceGenere.=' }else{'.CRLF;
     $sourceGenere.='  $consUrlRedir.=\'&amp;'.$v1['xsearch'].'=\'.rawurlencode($'.$v1['xsearch'].'); // '.$v1['nom_champ'].CRLF;
     $sourceGenere.=' }'.CRLF;
    }else if(substr($v1['type_champ'],0,4)=='set('){
     $sourceGenere.=' if(is_array($'.$v1['xsearch'].')){'.CRLF;
     $sourceGenere.='  foreach($'.$v1['xsearch'].' as $k1 => $v1){'.CRLF;
     $sourceGenere.='   $consUrlRedir.=\'&amp;'.$v1['xsearch'].'%5B%5D=\'.rawurlencode($v1);'.CRLF;
     $sourceGenere.='  }'.CRLF;
     $sourceGenere.=' }else{'.CRLF;
     $sourceGenere.='  $consUrlRedir.=\'&amp;'.$v1['xsearch'].'=\'.rawurlencode($'.$v1['xsearch'].'); // '.$v1['nom_champ'].CRLF;
     $sourceGenere.=' }'.CRLF;
    }
   }
  }
 }
 $sourceGenere.=' $ri=\' <span class="yybtn yyunset">&raquo;</span>\';'.CRLF;
 $sourceGenere.=' if($__start+$__nbMax<$__count){'.CRLF;
 $sourceGenere.='  $ri=\'<a href="\'.BNF.\'?__xpage=\'.($__xpage+1).$consUrlRedir.\'">&raquo;</a>\';'.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' $le=\' <span class="yybtn yyunset">&laquo;</span>\';'.CRLF;
 $sourceGenere.=' if($__xpage>0){'.CRLF;
 $sourceGenere.='  $le=\'<a href="\'.BNF.\'?__xpage=\'.($__xpage-1).$consUrlRedir.\'">&laquo;</a>\';'.CRLF;
 $sourceGenere.=' }'.CRLF.CRLF;
 $sourceGenere.=' $o1.=\'<div><form method="post" class="yylistForm1" >\';'.CRLF;
 if(!$modeChoose){
 
  $sourceGenere.='// $o1.=\'  <button type="submit" name="action1">\'.txt0(\'action1\').\'</button>\';'.CRLF;
  $sourceGenere.='// $o1.=\'  <button type="submit" name="action2">\'.txt0(\'action2\').\'</button>\';'.CRLF;
  $sourceGenere.=' $o1.=\'  <a href="'.$GLOBALS['file_action_to_call'].'?a=c">\'.txt1(\'add_a_new_record\').\'</a>\'.CRLF;'.CRLF;
 }
 $sourceGenere.=' $o1.=\'  \'.$le.$ri.CRLF;'.CRLF;
 $sourceGenere.=' $o1.=\'  <div style="display:inline-block;"> page \'.number_format(($__xpage+1),0,\'.\',\' \').\'/\'.number_format(ceil($__count/$__nbMax),0,\'.\',\' \').\' (\'.number_format($__count,0,\'.\',\' \').\' \'.txt1(\'records '.$GLOBALS['tableShortName'].'\').\' )</div>\'.CRLF;'.CRLF;

 $sourceGenere.=' $o1.=\'</form></div>\';'.CRLF.CRLF;
 $sourceGenere.=' $o1.=getCss1(890); // todo adjust size'.CRLF.CRLF;


 $sourceGenere.=' $lsttbl.=\'<thead><tr>\';'.CRLF;
 if(!$modeChoose){
  $sourceGenere.=' $lsttbl.=\'<th style="min-width:125px;">\'.txtsys1(\'column_action\').\'</th>\';'.CRLF;
 }else{
  $sourceGenere.=' $lsttbl.=\'<th style="min-width:55px;">\'.txtsys1(\'column_action\').\'</th>\';'.CRLF;
 }
 foreach($GLOBALS['__lstChampsTries'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if( $v1['__ignore_for_display']==false){
    if($v1['nom_champ']==$GLOBALS['__autoincrement']){
     $sourceGenere.=' $lsttbl.=\'<th style="min-width:85px;">\'.txt1(\'T0.'.$GLOBALS['__autoincrement'].'\').\'</th>\';'.CRLF;
    }else if($v1['type_champ']=='date' || $v1['type_champ']=='datetime'){
     $sourceGenere.=' $lsttbl.=\'<th  style="min-width:95px;">\'.txt1(\'T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].'\').\'</th>\';'.CRLF;
    }else{
     if(isset($v1['subtype']) && $v1['subtype'] == 'password'){
      // nothing here
     }else{
      if(isset($v1['__ignore_for_display']) && $v1['__ignore_for_display']==true){
      }else{
       $sourceGenere.=' $lsttbl.=\'<th>\'.txt1(\'T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].'\').\'</th>\';'.CRLF;     
      }
     }
    }
   }
  }
 }
 $sourceGenere.=' $lsttbl.=\'</tr></thead><tbody>\';'.CRLF.CRLF;

 
 
 $sourceGenere.=' foreach($data0 as $k0=>$v0){'.CRLF.CRLF;

 $sourceGenere.='  $lsttbl.=\'<tr>\';'.CRLF.CRLF;
 $sourceGenere.='  $lsttbl.=\'<td data-label="" style="text-align:left!important;">\';'.CRLF;
 $sourceGenere.='  $lsttbl.=\'<div class="yyflex1">\';'.CRLF;
 
 if($GLOBALS['__autoincrement']!=''){
  if(!$modeChoose){
   $sourceGenere.='  $lsttbl.=\'<a class="yydanger yytxtSiz1" href="'.$GLOBALS['file_action_to_call'].'?a=d&amp;id=\'.$v0[\'T0.'.$GLOBALS['__autoincrement'].'\'].\'"  title="\'.txtsys1(\'delete_button\').\'" >&#10008;</a>\';//✘ #10008'.CRLF;
   $sourceGenere.='  $lsttbl.=\'<a class="yytxtSiz2"        href="'.$GLOBALS['file_action_to_call'].'?a=du&amp;id=\'.$v0[\'T0.'.$GLOBALS['__autoincrement'].'\'].\'" title="\'.txtsys1(\'duplicate_button\').\'">&#x2398;</a>\';//⎘:x2398 📋:#128203'.CRLF;
   $sourceGenere.='  $lsttbl.=\'<a class="yyedit yytxtSiz1"   href="'.$GLOBALS['file_action_to_call'].'?a=u&amp;id=\'.$v0[\'T0.'.$GLOBALS['__autoincrement'].'\'].\'"  title="\'.txtsys1(\'edit_button\').\'">&#9998;</a>\';//✎ #9998'.CRLF;
  }else{
   $sourceGenere.='   $lsttbl.=\'<a class="yysuccess" href="\'.BNF.\'?idchoose=\'.$v0[\'T0.'.$GLOBALS['__autoincrement'].'\'].\'">\'.txtsys1(\'text_for_the_select_button\') . \'</a>\';'.CRLF;
  }
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles='';
   $listeChampsCles2='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles.='&amp;'.$v1.'=\'.rawurlencode($v0[\'T0.'.$v1.'\']).\'';
    $listeChampsCles2=$v1;
   }
   if(!$modeChoose){
    $sourceGenere.='  $lsttbl.=\'<a class="yydanger yytxtSiz1" href="'.$GLOBALS['file_action_to_call'].'?a=d'.$listeChampsCles.'"  title="\'.txtsys1(\'delete_button\').\'" >&#10008;</a>\';//✘ #10008'.CRLF;
    $sourceGenere.='  $lsttbl.=\'<a class="yytxtSiz2"        href="'.$GLOBALS['file_action_to_call'].'?a=du'.$listeChampsCles.'" title="\'.txtsys1(\'duplicate_button\').\'">&#x2398;</a>\';//⎘:x2398 📋 #128203'.CRLF;
    $sourceGenere.='  $lsttbl.=\'<a class="yyedit yytxtSiz1"   href="'.$GLOBALS['file_action_to_call'].'?a=u'.$listeChampsCles.'"  title="\'.txtsys1(\'edit_button\').\'">&#9998;</a>\';//✎ #9998'.CRLF;
   }else{
    if(sizeof($GLOBALS['__listeChampsCles'])==1){
     $sourceGenere.='   $lsttbl.=\'<a class="yysuccess" href="\'.BNF.\'?idchoose=\'.urlencode($v0[\'T0.'.$listeChampsCles2.'\']).\'">\'.txtsys1(\'text_for_the_select_button\') . \'</a>\';'.CRLF;
    }else{
     $sourceGenere.='   $lsttbl.=\'todo multiple uniq<a class="yyedit yytxtSiz1" href="\'.BNF.\'?idchoose=\'.urlencode($v0[\'T0.'.$listeChampsCles2.'\']).\'">\'.txtsys1(\'text_for_the_select_button\') . \'</a>\';'.CRLF;     
    }
   }
  }else{
   $sourceGenere.='   $lsttbl.=TODO \'<a href="\'.BNF.\'?idchoose=\'.urlencode($v0[\'T0.todo\']).\'">\'.txtsys1(\'text_for_the_select_button\') . \'</a>\';'.CRLF;     
   $sourceGenere.='//  $lsttbl.=\'<a class="yydanger yytxtSiz1" href="'.$GLOBALS['file_action_to_call'].'?a=d"  title="\'.txtsys1(\'delete_button\').\'">&#10008;</a>\';//✘ #10008'.CRLF;
   $sourceGenere.='//  $lsttbl.=\'<a class="yytxtSiz2"        href="'.$GLOBALS['file_action_to_call'].'?a=du" title="\'.txtsys1(\'duplicate_button\').\'">&#x2398;</a>\';//⎘:x2398 📋:#128203'.CRLF;
   $sourceGenere.='//  $lsttbl.=\'<a class="yyedit yytxtSiz1"   href="'.$GLOBALS['file_action_to_call'].'?a=u"  title="\'.txtsys1(\'edit_button\').\'">&#9998;</a>\';//✎ #9998'.CRLF;
  }
 }

 $sourceGenere.='  $lsttbl.=\'</div>\';'.CRLF;
 $sourceGenere.='  $lsttbl.=\'</td>\';'.CRLF.CRLF;

 //==============================================================================================================
 //==============================================================================================================
 function genererTable3($v1){
  $sourceGenere='';

   $parentRef='T'.$v1['refTableNumber'];
   $prefix=$parentRef.'.';
   $before='';
   if($v1['refTableNumber']!=0){
    $before=' ';
   }
   $doit=true;
   if(isset($v1['subtype']) && $v1['subtype']=='password'){
    $doit=false;
   }
   if(isset($v1['__ignore_for_display']) && $v1['__ignore_for_display']==true){
    $doit=false;
   }
   
   if(!$doit){
   }else{
    
    if($v1['refTableNumber']!=0){
     $sourceGenere.=CRLF.CRLF;
     $sourceGenere.='  // field display of the parent table '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='  if($v0[\'T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].'\']===0||is_null($v0[\'T'.$v1['refTableNumber'].'.'.$v1['nom_champ'].'\'])){'.CRLF;
     $sourceGenere.='   $lsttbl.=\'<td class="yywarning" data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'"></td>\'; '.CRLF;
     $sourceGenere.='  }else{'.CRLF;
    }
    
    if($v1['type_champ']=='geometry'){
     $sourceGenere.=$before.'  if($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\']==\'\'||is_null($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'])){'.CRLF;
     $sourceGenere.=$before.'   $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'"></td>\';'.CRLF;
     $sourceGenere.=$before.'  }else{'.CRLF;
     $sourceGenere.=$before.'   $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'" style="font-family:monospace;white-space:pre-line;word-break:break-word;">\';'.CRLF;
     $sourceGenere.=$before.'   $lsttbl.=\'\'.enti1(mb_substr($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'],0,100,\'UTF-8\')).\'\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.=$before.'   $lsttbl.=\'</td>\';'.CRLF;
     $sourceGenere.=$before.'  }'.CRLF;
    }else if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb'){
     $sourceGenere.=$before.'  $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'">\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.=$before.'  $im = base64_encode($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\']);'.CRLF;
     $sourceGenere.=$before.'  if(strpos(substr($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'],0,12),\'PNG\')!==false){'.CRLF;
     $sourceGenere.=$before.'   $lsttbl.=\'<img src="data:image/png;base64, \'.$im.\'" style="max-width:100px;max-height:100px;"/>\'; // pictureInDb'.CRLF;
     $sourceGenere.=$before.'  }else if(strpos(substr($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'],0,12),\'JFIF\')!==false){'.CRLF;
     $sourceGenere.=$before.'   $lsttbl.=\'<img src="data:image/jpeg;base64, \'.$im.\'" style="max-width:100px;max-height:100px;"/>\'; // pictureInDb'.CRLF;
     $sourceGenere.=$before.'  }else if(strpos(substr($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'],0,12),\'GIF\')!==false){'.CRLF;
     $sourceGenere.=$before.'   $lsttbl.=\'<img src="data:image/gif;base64, \'.$im.\'" style="max-width:100px;max-height:100px;"/>\'; // pictureInDb'.CRLF;
     $sourceGenere.=$before.'  }'.CRLF;
     
     
     $sourceGenere.=$before.'  $lsttbl.=\'</td>\';'.CRLF;
    }else if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){

     $sourceGenere.=$before.'  $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'">\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.=$before.'  if($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\']==\'\'){'.CRLF;
     $sourceGenere.=$before.'   $lsttbl.=\'\'.$v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'].\'\'; '.CRLF;
     $sourceGenere.=$before.'  }else{'.CRLF;
     $sourceGenere.=$before.'   $val=json_decode($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'],true);'.CRLF;
     $sourceGenere.=$before.'   $lsttbl.=\'<div style="display:inline-block;width:35px;height:20px;border:1px #eee outset;background-color:#\'.$val[\'hexValue\'].\'"></div>\';'.CRLF;
     $sourceGenere.=$before.'   $lsttbl.=\'\'.$val[\'hexValue\'].\'\';'.CRLF;
     $sourceGenere.=$before.'   if(isset($val[\'webName\']) && $val[\'webName\']!=\'\'){'.CRLF;
     $sourceGenere.=$before.'    $lsttbl.=\'<br />\'.$val[\'webName\'].\'\';'.CRLF;
     $sourceGenere.=$before.'   }'.CRLF;
     $sourceGenere.=$before.'   if(isset($val[\'pantoneName\']) && $val[\'pantoneName\']!=\'\'){'.CRLF;
     $sourceGenere.=$before.'    $lsttbl.=\'<br /> pantone:\'.$val[\'pantoneName\'].\'\';'.CRLF;
     $sourceGenere.=$before.'   }'.CRLF;
     $sourceGenere.=$before.'  }'.CRLF;
     $sourceGenere.=$before.'  $lsttbl.=\'</td>\';'.CRLF;
    }else if(isset($v1['param_name'])){
     if(isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
      $sourceGenere.=$before.'  $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'">\';'.CRLF;
      $sourceGenere.=$before.'  $lsttbl.=displayParam1(\''.$v1['param_name'].'\',$v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'],array(\'set\'=>true)); // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.=$before.'  $lsttbl.=\'</td>\';'.CRLF;
     }else{
      $sourceGenere.=$before.'  $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'" style="text-align:center;">\';'.CRLF;
      $sourceGenere.=$before.'  $lsttbl.=displayParam1(\''.$v1['param_name'].'\',$v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'],array(\'unsetPossible\'=>'.(isset($v1['unsetPossible']) && $v1['unsetPossible']==true?'true':'false').')); // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.=$before.'  $lsttbl.=\'</td>\';'.CRLF;
     }
    }else{
     if($v1['type_champ']=='time' || $v1['type_champ']=='date' || $v1['type_champ']=='datetime'){
      $sourceGenere.=$before.'  $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'" style="text-align:center;">\';'.CRLF;
      $sourceGenere.=$before.'  $lsttbl.=\'\'.$v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'].\'\'; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.=$before.'  $lsttbl.=\'</td>\';'.CRLF;
     }else if(true===$v1['isNumericField']){
      if($GLOBALS['__autoincrement']==$v1['nom_champ']){
       $sourceGenere.=$before.'  $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'" style="text-align:center;">\';'.CRLF;
      }else{
       $sourceGenere.=$before.'  $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'" style="text-align:right;">\';'.CRLF;
      }
      $sourceGenere.=$before.'  $lsttbl.=\'\'.number_format( $v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'],'.$v1['decimals'].',\'.\',\' \').\'\'; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.=$before.'  $lsttbl.=\'</td>\';'.CRLF;
     }else if(strpos(strtolower($v1['type_champ']),'text')     !==false ){
      $sourceGenere.=$before.'  if($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\']==\'\'||is_null($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'])){'.CRLF;
      $sourceGenere.=$before.'   $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'"></td>\';'.CRLF;
      $sourceGenere.=$before.'  }else{'.CRLF;
      $sourceGenere.=$before.'   $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'" style="font-family: monospace;white-space: pre-line;">\';'.CRLF;
      $sourceGenere.=$before.'   $lsttbl.=\'\'.enti1(mb_substr($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\'],0,100,\'UTF-8\')).\'\'; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.=$before.'   $lsttbl.=\'</td>\';'.CRLF;
      $sourceGenere.=$before.'  }'.CRLF;
     }else{
      $sourceGenere.=$before.'  $lsttbl.=\'<td data-label="\'.txt4(\''.$prefix.$v1['nom_champ'].'\').\'">\';'.CRLF;
      $sourceGenere.=$before.'  $lsttbl.=\'\'.enti1($v0[\''.$parentRef.'.'.$v1['nom_champ'].'\']).\'\'; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.=$before.'  $lsttbl.=\'</td>\';'.CRLF;
     }
    }   
    if($v1['refTableNumber']!=0){
     $sourceGenere.='  }'.CRLF;
    }    
   }
   $sourceGenere.=CRLF;
  
  return $sourceGenere;
 }
 //==============================================================================================================
 //==============================================================================================================
 
 $count=0;
 foreach($GLOBALS['__lstChampsTries'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   $sourceGenere.=genererTable3($v1);
  }
 }

 $sourceGenere.=CRLF.CRLF;
 $sourceGenere.='  $lsttbl.=\'</tr>\';'.CRLF.CRLF;
 $sourceGenere.=' }'.CRLF.CRLF;

 $sourceGenere.=' $o1.=\'<div style="overflow-x:scroll;"><table class="yytableResult1">\'.CRLF.$lsttbl.\'</tbody></table></div>\'.CRLF;'.CRLF.CRLF;

 $sourceGenere.=' $o1.=\'<div class="yylistForm1"  style="padding-bottom:10px;">\';'.CRLF;
 if(!$modeChoose){
  $sourceGenere.=' $o1.=\' <a class="" href="'.$GLOBALS['file_action_to_call'].'?a=c">\'.txt1(\'add_a_new_record\').\'</a>\'.CRLF;'.CRLF;
 }
 $sourceGenere.=' $o1.=\'  \'.$le.\' \'.$ri.\'\';'.CRLF;
 $sourceGenere.=' $o1.=\' <div style="display:inline-block;"> page \'.number_format(($__xpage+1),0,\'.\',\' \').\'/\'.number_format(ceil($__count/$__nbMax),0,\'.\',\' \').\' (\'.number_format($__count,0,\'.\',\' \').\' \'.txt1(\'records '.$GLOBALS['tableShortName'].'\').\' )</div>\'.CRLF;'.CRLF;
 $sourceGenere.=' $o1.=\'</div>\'.CRLF;'.CRLF.CRLF;
 $sourceGenere.='}'.CRLF.CRLF;
 if($modeChoose){
  $sourceGenere.='$o1.=\'<script type="text/javascript">var globalChooseUrlBack=\\\'\'.$_SESSION[PGMK][\'choose\'][\'urlBack\'].\'\\\';</script>\';'.CRLF;
 }
 $sourceGenere.='$o1.=htmlFoot0(array());'.CRLF;
 $sourceGenere.='dw1($o1);'.CRLF;
 if(!$modeChoose){
  $sourceGenere.='cleanSession1();'.CRLF;
 }

}
//========================================================================================================================
//========================================================================================================================
if(isset($_GET['a']) && $_GET['a']=='action1'){
 
 $warningFlagOn1=isset($_GET['__option___with_warning'])?($_GET['__option___with_warning']=='with_warning'?true:false):false;
 
 $sourceGenere.='<'.'?php  // € utf8 check with euro sign'.CRLF;
 $sourceGenere.='define(\'BNF\',basename( __FILE__ ));'.CRLF;
 $sourceGenere.='require_once \'za_inc.php\';'.CRLF;
 $sourceGenere.='session_start();'.CRLF;
 $sourceGenere.='@include  $GLOBALS[\'glob_noVcPath1\'].\'/translation_for_pages/\'.$GLOBALS[\'glob_lang\'].\'_\'.BNF;'.CRLF;
 $listeDesParametres=array();
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField'])){
   foreach( $v1['parentField']['fieldList'] as $k0 => $v0){
    if(isset($v0['param_name'])){
     if(!in_array($v0['param_name'],$listeDesParametres)){
      $sourceGenere.='require_once($GLOBALS[\'glob_noVcPath1\'].\'/parameters/'.$v0['param_name'].'.php\');'.CRLF;
      $listeDesParametres[]=$v0['param_name'];
     }
    }
   }
  }else{
   if(isset($v1['param_name'])){
    if(!in_array($v1['param_name'],$listeDesParametres)){
     $sourceGenere.='require_once($GLOBALS[\'glob_noVcPath1\'].\'/parameters/'.$v1['param_name'].'.php\');'.CRLF;
     $listeDesParametres[]=$v1['param_name'];
    }
   }
  }
 }
 
 $sourceGenere.='checkGroupPages();'.CRLF;
 
 $sourceGenere.='require_once $GLOBALS[\'glob_incPath1\'].\'/'.$GLOBALS['file_inc_to_include'].'\';'.CRLF;
 $incAlreadyDone=array($GLOBALS['file_inc_to_include']);
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 ){
   if(substr($v1['parentField']['fld_name_tables'],0,9)==PGMK.'_tbl__'){
    $toInclude=(PGMK=='td'.'o'?'zz_':'_').'inc_'.substr($v1['parentField']['fld_name_tables'],9).'1.php';
   }else if(substr($v1['parentField']['fld_name_tables'],0,8)==PGMK.'_tbl_'){
    $toInclude=(PGMK=='td'.'o'?'zz_':'').'_inc_'.substr($v1['parentField']['fld_name_tables'],8).'1.php';
   }else{
    $toInclude=(PGMK=='td'.'o'?'zz_':'').'_inc_'.$v1['parentField']['fld_name_tables'].'1.php';    
   }
   if(!in_array($toInclude,$incAlreadyDone)){
    $sourceGenere.='require_once $GLOBALS[\'glob_incPath1\'].\'/'.$toInclude.'\';'.CRLF;
    $incAlreadyDone[]=$toInclude;
   }
  }
 }
 $sourceGenere.=''.CRLF;
 $sourceGenere.='openDb1();'.CRLF;
 $sourceGenere.='//========================================================================================================================'.CRLF;
 $sourceGenere.='function btl1(){'.CRLF;
 $sourceGenere.=' return \'&nbsp;<a href="'.$GLOBALS['file_list_to_call'].'" style="font-size:1rem;">\'.txtsys1(\'back_to_the_list\').\'</a>\';'.CRLF;
 $sourceGenere.='}'.CRLF;

 $sourceGenere.='//========================================================================================================================'.CRLF;
 $sourceGenere.='function test_input_'.$GLOBALS['tableShortName'].'_KO1(){'.CRLF;
 $sourceGenere.=' $err=0;'.CRLF;
 $GLOBALS['__hasCntUpdate']=false;
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if($v1['cntupd']){
    $GLOBALS['__hasCntUpdate']=true;
   }
  }else{
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    $dontMakeIt=false;
    if(isset($v1['param_name'])){
     $dontMakeIt=true;
     if( (isset($v1['unsetPossible']) && $v1['unsetPossible'] == true) || (isset($v1['set']) && $v1['set'] == true)  ){

     }else {
      $sourceGenere.=' // todo check if this condition is valid'.CRLF;
      $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'){'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_must_fill_a_value_for_the_field\') . txt1(\''.$v1['nom_champ'].'\');'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
      $sourceGenere.='  $err=1;'.CRLF;
      $sourceGenere.=' }'.CRLF;
     }
    }
    if($v1['type_champ']=='timestamp'){
     $dontMakeIt=true;
    }
    if( (isset($v1['isUser'])&& $v1['isUser']==true) || (isset($v1['isGroup'])&& $v1['isGroup']==true) ){
     $dontMakeIt=true;
    }
    if(false===$dontMakeIt){
     if(isset($v1['parentField'])){
      if($v1['null_possible']=='NO'){
       if($v1['isNumericField']){
        $sourceGenere.=' if($err==0&&!is_numeric($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])){'.CRLF;
       }else{
        $sourceGenere.=' if($err==0&&(is_null($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])||$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\')){'.CRLF;
       }
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_must_fill_a_value_for_the_field\') . \'"\' .txt1(\''.$v1['nom_champ'].'\') . \'"\'; // dependant field'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
       $sourceGenere.='  $err=1;'.CRLF;
       $sourceGenere.=' }'.CRLF;
       if($v1['parentField']['fld_link_mandatory_pglnks']==0){
        $sourceGenere.=' // todo warning : null possible = NO and not mandatory '.CRLF;
        $_SESSION[PGMK][NAV][BNF]['warningmessage'][]=txtsys1('warning').' '. __LINE__ .' : '.txt2('null possible = NO and not mandatory for the field_1778_100').' "'.$v1['nom_champ'].'" ';
       }
      }else{
       if($v1['parentField']['fld_link_mandatory_pglnks']==1){
        $sourceGenere.=' // todo warning : field mandatory but null possible = YES for '.$v1['nom_champ'].CRLF;
        $_SESSION[PGMK][NAV][BNF]['warningmessage'][]=txtsys1('warning').' '. __LINE__ .' : '.txt2('mandatory but null possible = YES for the field_1783_100').' "'.$v1['nom_champ'].'" ';
       }
      }
     }else if($v1['type_champ']=='date' || $v1['type_champ']=='time' || $v1['type_champ']=='datetime' ){
      $dontDoit=false;
      if( ( isset($v1['dtupd']) && $v1['dtupd']==true ) || ( isset($v1['dtcrt']) && $v1['dtcrt']==true ) ){
       $dontDoit=true;
      }
      if($dontDoit==false){
       if($v1['null_possible']=='NO'){
        $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'){'.CRLF;
        $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_must_fill_a_value_for_the_field\') .\'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
        $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
        $sourceGenere.='  $err=1;'.CRLF;
        $sourceGenere.=' }'.CRLF;
        if($v1['type_champ']=='date'){
         $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'){'.CRLF;
         $sourceGenere.='  if(checkmydate($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])!=true){'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_date_is_not_at_a_good_format_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
         $sourceGenere.='   $err=1;'.CRLF;
         $sourceGenere.='  }'.CRLF;
         $sourceGenere.=' }'.CRLF;
         if($warningFlagOn1){
          $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'){'.CRLF;
          $sourceGenere.='  if($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']<date(\'Y-m-d\')){'.CRLF;
          $sourceGenere.='   $_SESSION[PGMK][NAV][\'warningmessage\'][]=txtsys1(\'warning\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_date_cannot_be_lower_than_today_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
          $sourceGenere.='   $_SESSION[PGMK][NAV][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yywarning\');'.CRLF;
          $sourceGenere.='   $err=0;'.CRLF;
          $sourceGenere.='  }'.CRLF;
          $sourceGenere.=' }'.CRLF;
         }
        }
        if($v1['type_champ']=='time'){
         $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'){'.CRLF;
         $sourceGenere.='  if(checkmytime($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])!=true){'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_time_is_not_at_a_good_format_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
         $sourceGenere.='   $err=1;'.CRLF;
         $sourceGenere.='  }'.CRLF;
         $sourceGenere.=' }'.CRLF;
        }
        if($v1['type_champ']=='datetime'){
         $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'){'.CRLF;
         $sourceGenere.='  if(checkmydatetime($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])!=true){'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_date_or_the_time_is_not_at_a_good_format_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
         $sourceGenere.='   $err=1;'.CRLF;
         $sourceGenere.='  }'.CRLF;
         $sourceGenere.=' }'.CRLF;
         if($warningFlagOn1){
          $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'){'.CRLF;
          $sourceGenere.='  if($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']<date(\'Y-m-d H:i:s\')){'.CRLF;
          $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'warningmessage\'][]=txtsys1(\'warning\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_date_cannot_be_lower_than_today_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
          $sourceGenere.='   $_SESSION[PGMK][NAV][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yywarning\');'.CRLF;
          $sourceGenere.='   $err=0;'.CRLF;
          $sourceGenere.='  }'.CRLF;
          $sourceGenere.=' }'.CRLF;
         }
        }
       }else{
        if($v1['type_champ']=='date'){
         $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'){'.CRLF;
         $sourceGenere.='  if(checkmydate($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])!=true){'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_date_is_not_at_a_good_format_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
         $sourceGenere.='   $err=1;'.CRLF;
         $sourceGenere.='  }'.CRLF;
         $sourceGenere.=' }'.CRLF;
         if($warningFlagOn1){
          $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'){'.CRLF;
          $sourceGenere.='  if($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']<date(\'Y-m-d\')){'.CRLF;
          $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'warningmessage\'][]=txtsys1(\'warning\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_date_cannot_be_lower_than_today_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
          $sourceGenere.='   $_SESSION[PGMK][NAV][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yywarning\');'.CRLF;
          $sourceGenere.='   $err=0;'.CRLF;
          $sourceGenere.='  }'.CRLF;
          $sourceGenere.=' }'.CRLF;
         }
        }       
        if($v1['type_champ']=='time'){
         $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'){'.CRLF;
         $sourceGenere.='  if(checkmytime($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])!=true){'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_time_is_not_at_a_good_format_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
         $sourceGenere.='   $err=1;'.CRLF;
         $sourceGenere.='  }'.CRLF;
         $sourceGenere.=' }'.CRLF;
        }
        if($v1['type_champ']=='datetime'){
         $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'){'.CRLF;
         $sourceGenere.='  if(checkmydatetime($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])!=true){'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_date_or_the_time_is_not_at_a_good_format_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
         $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
         $sourceGenere.='   $err=1;'.CRLF;
         $sourceGenere.='  }'.CRLF;
         $sourceGenere.=' }'.CRLF;
         if($warningFlagOn1){
          $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'){'.CRLF;
          $sourceGenere.='  if($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']<date(\'Y-m-d H:i:s\')){'.CRLF;
          $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'warningmessage\'][]=txtsys1(\'warning\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_date_cannot_be_lower_than_today_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
          $sourceGenere.='   $_SESSION[PGMK][NAV][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yywarning\');'.CRLF;
          $sourceGenere.='   $err=0;'.CRLF;
          $sourceGenere.='  }'.CRLF;
          $sourceGenere.=' }'.CRLF;
         }
        }
       }
      }
     }else if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb' ){
      $maxsizeblob=255;
      if($v1['type_champ']=='blob'){
       $maxsizeblob=65535;
      }else if($v1['type_champ']=='mediumblob'){
       $maxsizeblob=16777215;
      }else if($v1['type_champ']=='longblob'){
       $maxsizeblob=4294967295;
      }
      $sourceGenere.=' if(isset($_POST[\'raz_'.$v1['nom_champ'].'\']) && $_POST[\'raz_'.$v1['nom_champ'].'\']==\'on\'){'.CRLF;
      $sourceGenere.=' }else{'.CRLF;
      $sourceGenere.='  if($err==0&&isset($_FILES[\''.$v1['nom_champ'].'\'])){'.CRLF;
      $sourceGenere.='   if($_FILES[\''.$v1['nom_champ'].'\'][\'error\']==4){'.CRLF;
      $sourceGenere.='    // no file uploaded   '.CRLF; 
      $sourceGenere.='  }else{'.CRLF;
      $sourceGenere.='    if(!(isset($_FILES[\''.$v1['nom_champ'].'\']) && $_FILES[\''.$v1['nom_champ'].'\'][\'error\']==0 && $_FILES[\''.$v1['nom_champ'].'\'][\'size\']<='.$maxsizeblob.') ){'.CRLF;
      $sourceGenere.='     $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\'the '.$v1['nom_champ'].' is not valid or too big\');'.CRLF;
      $sourceGenere.='     $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
      $sourceGenere.='    }'.CRLF;
      $sourceGenere.='   }'.CRLF;
      $sourceGenere.='  }'.CRLF;
      $sourceGenere.=' }'.CRLF;
     }else if(true===$v1['isNumericField']){
      if($v1['null_possible']=='YES'){
       $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'&&!is_numeric($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])){'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_must_fill_a_numeric_value_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
       $sourceGenere.='  $err=1;'.CRLF;
       $sourceGenere.=' }'.CRLF;
      }else{
       $sourceGenere.=' if($err==0&&!is_numeric($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])){'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_must_fill_a_numeric_value_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
       $sourceGenere.='  $err=1;'.CRLF;
       $sourceGenere.=' }'.CRLF;
      }
     }else{
      if($v1['comment']!==''){
       $jsonComment=json_decode($v1['comment'],true);
      }else{
       $jsonComment=array();
      }
      if($v1['null_possible']==='YES'){
      }else if($v1['null_possible']==='NO'){
      }
      if(isset($jsonComment['tests'])){
       foreach($jsonComment['tests'] as $kc => $vc){
        if($kc=='email' && $vc==true){
         if($v1['null_possible']==='YES'){
          $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']===\'\'){ // email can be void'.CRLF;
          $sourceGenere.=' }else{'.CRLF;          
          $sourceGenere.='  if(!filter_var($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'], FILTER_VALIDATE_EMAIL)){'.CRLF;
          $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_email_address_is_not_valid_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
          $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
          $sourceGenere.='   $err=1;'.CRLF;
          $sourceGenere.='  }'.CRLF;
          $sourceGenere.=' }'.CRLF;          
         }else if( $v1['null_possible']==='NO'){
          $sourceGenere.=' if(!filter_var($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'], FILTER_VALIDATE_EMAIL)){'.CRLF;
          $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'the_email_address_is_not_valid_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
          $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
          $sourceGenere.='  $err=1;'.CRLF;
          $sourceGenere.=' }'.CRLF;
         }
        }
       }
      }
     }
     if(isset($v1['tests']) && isset($v1['tests']['notVoid']) && $v1['tests']['notVoid']==true){
      $sourceGenere.=' // tests[notVoid] in the comment of the field in the database'.CRLF;
      $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'){'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_must_fill_a_value_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
      $sourceGenere.='  $err=1;'.CRLF;
      $sourceGenere.=' }'.CRLF;
     }
     
     if(isset($v1['tests']) && isset($v1['tests']['min']) && $v1['tests']['min']==true){
      $sourceGenere.=' // todo tests[min] in the comment of the field in the database'.CRLF;
      $sourceGenere.=' if($err==0 && is_numeric($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] <= 0 ){'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : todo \' . txt1(\'the_value_must_be_greater_than_xxx_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
      $sourceGenere.='  $err=1;'.CRLF;
      $sourceGenere.=' }'.CRLF;
     }
     
     
     if(isset($v1['tests']) && isset($v1['tests']['max']) && $v1['tests']['max']==true){
      $sourceGenere.=' // todo tests[max] in the comment of the field in the database'.CRLF;
      $sourceGenere.=' if($err==0 && is_numeric($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] >= 100 ){'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : todo \' . txt1(\'the_value_must_be_lower_than_xxx_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
      $sourceGenere.='  $err=1;'.CRLF;
      $sourceGenere.=' }'.CRLF;
     }
     
     if(false===$v1['isNumericField'] && isset($v1['tests']) && isset($v1['tests']['mustNumeric']) && $v1['tests']['mustNumeric']==true){
      $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'&&!is_numeric($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])){'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_must_fill_a_numeric_value_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
      $sourceGenere.='  $err=1;'.CRLF;
      $sourceGenere.=' }'.CRLF;
     }
     
     if(isset($v1['tests']) && isset($v1['tests']['mustPhone']) && $v1['tests']['mustPhone']==true){
      $sourceGenere.=' if($err==0 && $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\' ){'.CRLF;
      $sourceGenere.='  if(!phoneOk1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])){'.CRLF;
      $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : todo \' . txtsys1(\'you_must_fill_a_phone_number_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
      $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
      $sourceGenere.='   $err=1;'.CRLF;
      $sourceGenere.='  }'.CRLF;
      $sourceGenere.=' }'.CRLF;
     }
     
     if(isset($v1['tests']) && isset($v1['tests']['todo']) && $v1['tests']['todo']==true){
      $sourceGenere.=' // tests[todo] in the comment of the field in the database'.CRLF;
      $sourceGenere.=' if($err==0 && true ){ // todo $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'){'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : todo \' . txtsys1(\'you_must_fill_a_value_for_the_field\') . \'"\' . txt1(\''.$v1['nom_champ'].'\') . \'"\';'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']=array(\'highlight\'=>true,\'class\'=>\'yydanger\');'.CRLF;
      $sourceGenere.='  $err=1;'.CRLF;
      $sourceGenere.=' }'.CRLF;
     }
    }
   }
  }
 }
 if($warningFlagOn1){
  $sourceGenere.='// ==================================================================='.CRLF;
  $sourceGenere.='// ========================= warning example ========================='.CRLF;
  $sourceGenere.='// ==================================================================='.CRLF;
  $sourceGenere.='// if($err==0 && is_numeric($_SESSION[PGMK][NAV][BNF][\'todo\']) && $_SESSION[PGMK][NAV][BNF][\'todo\']==\'0\'){'.CRLF;
  $sourceGenere.='//  $_SESSION[PGMK][NAV][BNF][\'warningmessage\'][]=txtsys1(\'warning\').\' \'. __LINE__ .\' : \' . txt1(\'your_warning_message_for_the_field\') . \'"\' . txt1(\'todo\') . \'"\';'.CRLF;
  $sourceGenere.='//  $_SESSION[PGMK][NAV][BNF][\'highlight\'][\'todo\']=array(\'highlight\'=>true,\'class\'=>\'yywarning\');'.CRLF;
  $sourceGenere.='//  $err=0; // live this to 0 '.CRLF;
  $sourceGenere.='// }'.CRLF;
 }
 $sourceGenere.=' return($err);'.CRLF;
 $sourceGenere.='}'.CRLF;

 $sourceGenere.='if(isset($_POST)&&sizeof($_POST)>=1){ // post action'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= POST ACTIONS  ====================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.='// echo __LINE__ . \'$_POST=<pre>\' . var_export($_POST,true) . \'</pre>\'; exit();'.CRLF;

 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(true===$v1['isNumericField']){
     $sourceGenere.=' if(isset($_POST[\''.$v1['nom_champ'].'\'])){'.CRLF;
     $sourceGenere.='  $_POST[\''.$v1['nom_champ'].'\']=str_replace("\\t",\'\',str_replace(\' \',\'\',$_POST[\''.$v1['nom_champ'].'\']));'.CRLF;
     $sourceGenere.=' }'.CRLF;
    }
   }
  }
 }

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if($v1['type_champ']=='timestamp'){

    }else if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb' ){
     
    }else if(isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){

     $sourceGenere.=' if(isset($_POST[\''.$v1['nom_champ'].'\']) ){'.CRLF;
     $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']= implode(\',\',$_POST[\''.$v1['nom_champ'].'\']);'.CRLF;
     $sourceGenere.=' }else{'.CRLF;
     $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']=\'\';'.CRLF;
     $sourceGenere.=' }'.CRLF;
     
    }else if(substr($v1['type_champ'],0,4)=='set('){

     $sourceGenere.=' if(isset($_POST[\''.$v1['nom_champ'].'\']) ){'.CRLF;
     $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']= implode(\',\',$_POST[\''.$v1['nom_champ'].'\']);'.CRLF;
     $sourceGenere.=' }else{'.CRLF;
     $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']=\'\';'.CRLF;
     $sourceGenere.=' }'.CRLF;
    }else{
     $doIt=true;
     if( ( isset($v1['isUser']) && $v1['isUser']==true ) ||  ( isset($v1['isGroup']) && $v1['isGroup']==true ) ){
      $doIt=false;
     }
     if((isset($v1['dtcrt']) && $v1['dtcrt']==true) || (isset($v1['dtupd']) && $v1['dtupd']==true) ){
      $doIt=false;
     }
     if($doIt){
      if($v1['null_possible']=='YES'){
       if(true===$v1['isNumericField']){
        $sourceGenere.=' $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=isset($_POST[\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'?$_POST[\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).': \'\'; // null possible'.CRLF;
       }else{
        $sourceGenere.=' $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=isset($_POST[\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'?$_POST[\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).': \'\'; // null possible'.CRLF;
       }
      }else{
       if(true===$v1['isNumericField']){
        $sourceGenere.=' $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=isset($_POST[\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'?$_POST[\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).': 0;'.CRLF;
       }else{
        $sourceGenere.=' $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=isset($_POST[\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'?$_POST[\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).': \'\';'.CRLF;
       }
      }
     }
    }
   }
  }
 }

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){
    if($v1['null_possible']=='YES'){
     $sourceGenere.=' if($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'){$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']=NULL;} // '.$v1['nom_champ'].' can be NULL'.CRLF.CRLF;
    }
   }else if($v1['type_champ']=='date' || $v1['type_champ']=='time' || $v1['type_champ']=='datetime' ){
    if($v1['null_possible']=='YES'){
     $sourceGenere.=' if($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\' || $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'NULL\' ){$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']=NULL;} // '.$v1['nom_champ'].' can be NULL'.CRLF.CRLF;
    }
   }else if(isset($v1['parentField'])){
    $sourceGenere.=CRLF;
    $sourceGenere.=' // dependant field fetch choose '.CRLF;
    $sourceGenere.=' if(!(isset($_POST[\'a\'])&&($_POST[\'a\']==\'cd\'||$_POST[\'a\']==\'cd\'))){ // NOT confirm delete'.CRLF;
    $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\'] =isset($_POST[\'choose__'.$v1['nom_champ'].'\'] )?$_POST[\'choose__'.$v1['nom_champ'].'\']  :\'\';'.CRLF;
    $sourceGenere.='  if($_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\']==txtsys1(\'text_for_the_select_button\')){'.CRLF;
    $sourceGenere.='   $_SESSION[PGMK][\'choose\'][\'urlBack\']=str_replace(\'&scrollBack2=1\',\'\',$_SERVER[\'HTTP_ORIGIN\'].$_SERVER[\'REQUEST_URI\']).\'&scrollBack2=1\';'.CRLF;
    if( PGMK!='td'.'o' && ( $v1['parentField']['fld_name_tables']==PGMK.'_tbl__users' ||  $v1['parentField']['fld_name_tables']==PGMK.'_tbl__groups' ) ) {
     $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: '.substr($v1['parentField']['fld_name_tables'],9).'_choose1.php\'); // 1'.CRLF;
    }else if(substr($v1['parentField']['fld_name_tables'],0,9)==PGMK.'_tbl__'){
     $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: '.(PGMK=='td'.'o'?'zz_':'').substr($v1['parentField']['fld_name_tables'],9).'_choose1.php\');// 2'.CRLF;
     $GLOBALS['tableShortName']=substr($_GET['table'],9);
    }else if(substr($v1['parentField']['fld_name_tables'],0,8)==PGMK.'_tbl_'){
     $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: '.(PGMK=='td'.'o'?'zz_':'').substr($v1['parentField']['fld_name_tables'],8).'_choose1.php\');// 3'.CRLF;
    }else{
     if(PGMK=='td'.'o'){
      $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: zz_'.$v1['parentField']['fld_name_tables'].'_choose1.php\');// 4'.CRLF;     
     }else{
      if(substr($v1['parentField']['fld_name_tables'],0,4)==PGMK.'_'){
       $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: '.substr($v1['parentField']['fld_name_tables'],4).'_choose1.php\');// 4'.CRLF;     
      }else{
       $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: '.$v1['parentField']['fld_name_tables'].'_choose1.php\');// 4'.CRLF;     
      }
     }
    }
    $sourceGenere.='   exit();'.CRLF;
    $sourceGenere.='  }'.CRLF;
    $sourceGenere.=' }'.CRLF;
    $sourceGenere.=CRLF;
   }
  }
 }

 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= POST UPDATE ======================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' if(isset($_POST[\'a\'])&&$_POST[\'a\']==\'u\'){ // update action'.CRLF;
 if($warningFlagOn1){
  $sourceGenere.='  if(test_input_'.$GLOBALS['tableShortName'].'_KO1()||isset($_POST[\'correct_the_warning_values\'])){'.CRLF;
  $sourceGenere.='   $___warningExist=(isset($_SESSION[PGMK][NAV][BNF][\'warningmessage\']) && count($_SESSION[PGMK][NAV][BNF][\'warningmessage\'])>0)?true:false;'.CRLF;
  $sourceGenere.='   if($___warningExist){'.CRLF;
  $sourceGenere.='    unset($_SESSION[PGMK][NAV][BNF][\'warningmessage\']);'.CRLF;
  $sourceGenere.='    unset($_SESSION[PGMK][NAV][BNF][\'highlight\']);'.CRLF;
  $sourceGenere.='   }'.CRLF;
 }else{
  $sourceGenere.='  if(test_input_'.$GLOBALS['tableShortName'].'_KO1()){'.CRLF;
 }
 
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='   if(isset($_POST[\'id1\'])&&is_numeric($_POST[\'id1\'])){'.CRLF;
  $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&t=u&id=\'.$_POST[\'id1\']);'.CRLF;
  $sourceGenere.='    exit();'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   $listeChampsCles2='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles1.='&& isset($_POST[\''.$v1.'_origin1\']) ';
    $listeChampsCles2.='&'.$v1.'=\'.urlencode($_POST[\''.$v1.'\']).\'';
   }
   $sourceGenere.='   if('.substr($listeChampsCles1,2).'){'.CRLF;
   $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&t=u'.$listeChampsCles2.'\');'.CRLF;
   $sourceGenere.='    exit();'.CRLF;
  }else{
   $sourceGenere.='   if(isset($_POST[\'todo\'])){'.CRLF;
   $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&t=u&todo=\'.$_POST[\'todo\']);'.CRLF;
   $sourceGenere.='    exit();'.CRLF;
  }   
 }
 $sourceGenere.='   }else{'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='    $_SESSION[PGMK][NAV][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : POST id1 = \' . $_POST[\'id1\'];'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles1.='.\' . $_POST[\''.$v1.'\'] . \'';
   }
   $sourceGenere.='    $_SESSION[PGMK][NAV][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : POST = '.substr($listeChampsCles1,1).'\';'.CRLF;  
  }else{
   $sourceGenere.='    $_SESSION[PGMK][NAV][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : POST todo = \' . $_POST[\'todo\'];'.CRLF;  
  }
 }
 $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: index.php\');'.CRLF;
 $sourceGenere.='    exit();'.CRLF;
 $sourceGenere.='   }'.CRLF;
 $sourceGenere.='  }'.CRLF;
 
 
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb' ){
   $sourceGenere.='  if(isset($_POST[\'raz_'.$v1['nom_champ'].'\']) && $_POST[\'raz_'.$v1['nom_champ'].'\']==\'on\'){'.CRLF;
   $sourceGenere.='   $__image_'.$v1['nom_champ'].'=\'\';'.CRLF;
   $sourceGenere.='  }else{'.CRLF;
   $sourceGenere.='   if(isset($_FILES[\''.$v1['nom_champ'].'\']) && $_FILES[\''.$v1['nom_champ'].'\'][\'error\']==0){'.CRLF;
   $sourceGenere.='    $__image_'.$v1['nom_champ'].'=file_get_contents($_FILES[\''.$v1['nom_champ'].'\'][\'tmp_name\']);'.CRLF;
   $sourceGenere.='   }'.CRLF;
   $sourceGenere.='  }'.CRLF;
  }
 }

 if($warningFlagOn1){
  $sourceGenere.='  $___warningExist=(isset($_SESSION[PGMK][NAV][BNF][\'warningmessage\']) && count($_SESSION[PGMK][NAV][BNF][\'warningmessage\'])>0)?true:false;'.CRLF;
  $sourceGenere.='  if($___warningExist){'.CRLF;
  $sourceGenere.='   if(!isset($_POST[\'__bypass_warning\'])){'.CRLF;
  if($GLOBALS['__autoincrement'] != ''){
   $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&t=u&id=\'.$_POST[\'id1\']);'.CRLF;
  }else{
   if(sizeof($GLOBALS['__listeChampsCles'])>0){
    $listeChampsCles2='';
    foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
     $listeChampsCles2.='&'.$v1.'=\'.urlencode($_POST[\''.$v1.'\']).\'';
    }
    $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&t=u'.$listeChampsCles2.'\');'.CRLF;
   }else{
    $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?todo=todo\');'.CRLF;    
   }
  }
  $sourceGenere.='    exit();'.CRLF;
  $sourceGenere.='   }else{'.CRLF;
  $sourceGenere.='    $__valueToShaone=\'\';'.CRLF;
  $sourceGenere.='    $arrValues=array();'.CRLF;
  $sourceGenere.='    foreach($_SESSION[PGMK][\'check\'][\'__checkSumWarning\'][\'keys\'] as $k1=>$v1){'.CRLF;
  $sourceGenere.='     if(is_array($_POST[$v1])){// for sets'.CRLF;
  $sourceGenere.='      $__valueToShaone .=implode(\',\',$_POST[$v1]);'.CRLF;
  $sourceGenere.='      $arrValues[$v1]   =implode(\',\',$_POST[$v1]);'.CRLF;
  $sourceGenere.='     }else{'.CRLF;
  $sourceGenere.='      $__valueToShaone .=$_POST[$v1];'.CRLF;
  $sourceGenere.='      $arrValues[$v1]   =$_POST[$v1];'.CRLF;  
  $sourceGenere.='     }'.CRLF;
  $sourceGenere.='    }'.CRLF;
  $sourceGenere.='    if(sha1($__valueToShaone)==$_SESSION[PGMK][\'check\'][\'__checkSumWarning\'][\'sha1\']){'.CRLF;
  $sourceGenere.='     unset($_SESSION[PGMK][NAV][BNF][\'warningmessage\']);'.CRLF;
  $sourceGenere.='     unset($_SESSION[PGMK][NAV][BNF][\'highlight\']);'.CRLF;
  $sourceGenere.='    }else{'.CRLF;
  $sourceGenere.='     $xtxterr=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'an_error_occured_and_a_message_will_be_sent_to_the_administrator\');'.CRLF;
  $sourceGenere.='     $_SESSION[PGMK][NAV][\'errormessage\'][]=$xtxterr;'.CRLF;
  $sourceGenere.='     txtlog1($xtxterr.CRLF.\'============================\'.CRLF.var_export($arrValues,true) , BNF , __LINE__ , \'error\' );'.CRLF;
  $sourceGenere.='     header(\'HTTP/1.1 303 See Other\');header(\'Location: '.$GLOBALS['file_list_to_call'].'\');'.CRLF;
  $sourceGenere.='     exit();'.CRLF;
  $sourceGenere.='    }'.CRLF;
  $sourceGenere.='   }'.CRLF;
  $sourceGenere.='  }'.CRLF;
 }
 
 if($GLOBALS['__autoincrement'] != ''){
  if($GLOBALS['__logTables']){
   $sourceGenere.='  $__beforeUpdate='.$GLOBALS['function_include_to_call'].'($_GET[\'id\']);'.CRLF;
  }else{
   $sourceGenere.='//  $__beforeUpdate='.$GLOBALS['function_include_to_call'].'($_GET[\'id\']); // no log'.CRLF;   
  }
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   if($GLOBALS['__logTables']){
    $sourceGenere.='  $__beforeUpdate='.$GLOBALS['function_include_to_call'].'(';
   }else{
    $sourceGenere.='//  $__beforeUpdate='.$GLOBALS['function_include_to_call'].'(';
   }
   $listeChampsCles='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles.=',$_POST[\''.$v1.'_origin1\']';
   }
   if($GLOBALS['__logTables']){
    $sourceGenere.=substr($listeChampsCles,1).');'.CRLF;
   }else{
    $sourceGenere.=substr($listeChampsCles,1).'); // no log'.CRLF;    
   }
  }else{
   $sourceGenere.='// todo  !!! DANGER !!! no diff because there is no key on this table'.CRLF;
  }
 }
 $sourceGenere.='  $req6="UPDATE `".$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\']."`.`'.$_GET['table'].'` SET'.CRLF;
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){

    if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb' ){
    }else if($v1['type_champ']=='timestamp'){
    }else if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){
     if($count==0){
      $sourceGenere.='      ';
     }else{
      $sourceGenere.='    , ';
     }
     if($v1['null_possible']=='YES'){
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".(is_null($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])?\'NULL\':"\'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])."\'")."'.CRLF;
     }else{
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
     }
    }else if( 'date'===$v1['type_champ'] || 'time'===$v1['type_champ'] || 'datetime'===$v1['type_champ'] ){
     $doIt=true;
     if('date'===$v1['type_champ'] && ((isset($v1['dtupd']) && $v1['dtupd']==true)  )){
      $doIt=false;
      if($count==0){
       $sourceGenere.='      ';
      }else{
       $sourceGenere.='    , ';
      }
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($GLOBALS[\'glob_setdate\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
      $count++;
     }
     if('date'===$v1['type_champ'] && ((isset($v1['dtcrt']) && $v1['dtcrt']==true)  )){
      $doIt=false;
     }
     if($doIt==true){
      if($count==0){
       $sourceGenere.='      ';
      }else{
       $sourceGenere.='    , ';
      }
      if($v1['null_possible']!='YES'){
       $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
      }else{
       $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".(is_null($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])?\'NULL\':"\'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])."\'")."'.CRLF;
      }
      $count++;
     }
    }else if(true===$v1['isNumericField']){
     $doIt=true;
     if(isset($v1['isUser']) && $v1['isUser']==true){
      $doIt=false;
      if($count==0){
       $sourceGenere.='      ';
      }else{
       $sourceGenere.='    , ';
      }
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".$_SESSION[PGMK][\'login\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'            ."'.CRLF;
      $count++;
     }
     if(isset($v1['isGroup']) && $v1['isGroup']==true){
      $doIt=false;
      if($count==0){
       $sourceGenere.='      ';
      }else{
       $sourceGenere.='    , ';
      }
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".$_SESSION[PGMK][\'group\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'            ."'.CRLF;
      $count++;
     }
     if($doIt==true){
      if($count==0){
       $sourceGenere.='      ';
      }else{
       $sourceGenere.='    , ';
      }
      if($v1['null_possible']=='YES'){
       $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ".($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'?\'NULL\':addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']))."'.CRLF;
      }else{
       $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'            ."'.CRLF;
      }
      $count++;
     }
    }else{
     $doIt=true;
     if(isset($v1['isUser']) && $v1['isUser']==true){
      $doIt=false;
      if($count==0){
       $sourceGenere.='      ';
      }else{
       $sourceGenere.='    , ';
      }
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".$_SESSION[PGMK][\'login\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'            ."'.CRLF;
      $count++;
     }
     
     if(isset($v1['isGroup']) && $v1['isGroup']==true){
      $doIt=false;
      if($count==0){
       $sourceGenere.='      ';
      }else{
       $sourceGenere.='    , ';
      }
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".$_SESSION[PGMK][\'group\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'            ."'.CRLF;
      $count++;
     }
     
     if($doIt==true){
      if($count==0){
       $sourceGenere.='      ';
      }else{
       $sourceGenere.='    , ';
      }
      if($v1['null_possible']=='YES'){
       if($v1['type_champ']=='geometry'){
        $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ".($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'?\'NULL\':"ST_GeomFromText(\'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']) ."\')")."'.CRLF;
       }else{
        $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ".($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'?\'NULL\':"\'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']) ."\'")."'.CRLF;       
       }
       $count++;
      }else{
       if($v1['type_champ']=='geometry'){
        $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ST_GeomFromText(\'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])-11).'."\')'.CRLF;
       }else{
        $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;       
       }
       $count++;
      }
     }
    }
   }
  }else{
   if($v1['tsupd']){
    if($count==0){
     $sourceGenere.='      ';
    }else{
     $sourceGenere.='    , ';
    }
    $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($GLOBALS[\'glob_setdate\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'                      ."\''.CRLF;
    $count++;
   }else if($v1['cntupd']){
    if($count==0){
     $sourceGenere.='      ';
    }else{
     $sourceGenere.='    , ';
    }
    $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  " . ((int)$_POST[\''.$v1['nom_champ'].'\']+1)'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'                    ."'.CRLF;
    $count++;
   }
  }
 }
 $sourceGenere.='  ";'.CRLF;
 
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb' ){
   $sourceGenere.='  if(isset($__image_'.$v1['nom_champ'].')){'.CRLF;
   $sourceGenere.='   $req6.="'.CRLF;
   $sourceGenere.='    , `'.$v1['nom_champ'].'` = \'".addslashes1($__image_'.$v1['nom_champ'].')."\''.CRLF;
   $sourceGenere.='   ";'.CRLF;
   $sourceGenere.='  }'.CRLF;
  }
 }  
 
 $sourceGenere.='  $req6.="'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='   WHERE `'.$GLOBALS['__autoincrement'].'`=".$_POST[\'id1\']."'.CRLF;
  if($GLOBALS['__fld_cntupd']!=''){
   $sourceGenere.='     AND `'.$GLOBALS['__fld_cntupd'].'` = ".$_POST[\''.$GLOBALS['__fld_cntupd'].'\']."'.CRLF;
  }
  $sourceGenere.='  ";'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles.='AND `'.$v1.'` = \'".addslashes($_POST[\''.$v1.'_origin1\'])."\' ';
   }
   $sourceGenere.='   WHERE '.substr($listeChampsCles,3).''.CRLF;
   $sourceGenere.='  ";'.CRLF;
  }else{
   $sourceGenere.='   WHERE todo = todo '.CRLF;
   $sourceGenere.='  "; // todo here check the conditions !!! DANGER !!!'.CRLF;
  }
 }

 $sourceGenere.='  $res6=@mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
 $sourceGenere.='  if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=0){'.CRLF;
 $sourceGenere.='   switch(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])){'.CRLF;
 $sourceGenere.='    case 1062 :'.CRLF;
 $sourceGenere.='     $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'this_record_already_exist\');'.CRLF;
 $sourceGenere.='     break;'.CRLF;
 $sourceGenere.='    default   :'.CRLF;
 $sourceGenere.='     $xtxterr=txtsys1(\'error\').\' "\' . __LINE__ . \'" mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
 $sourceGenere.='     $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;
 
 
 if($GLOBALS['__logTables']){
  $sourceGenere.='     txtlog1($xtxterr , BNF , __LINE__ , \'error\' );'.CRLF;
 }else{
  $sourceGenere.='//     t_x_t_l_o_g_1($xtxterr , BNF , __LINE__ , \'error\' ); // no log , uncomment and remove _ in the function name to log'.CRLF;
 }
 $sourceGenere.='    break;'.CRLF;
 $sourceGenere.='   }'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&id=\'.$_POST[\'id1\']); exit();'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles.='&'.$v1.'=\'.urlencode($_POST[\''.$v1.'\']).\'';
   }
   $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u'.$listeChampsCles.'\'); exit();'.CRLF;
  }else{
   $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&todo=\'.$_POST[\'todo\']); exit();'.CRLF;
  }
  
 }
 $sourceGenere.='  }else{'.CRLF;
 if($GLOBALS['__hasCntUpdate']){
  $sourceGenere.='   // check the use of cntupd '.CRLF;
  $sourceGenere.='   if(mysqli_affected_rows($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=1){'.CRLF;
  $sourceGenere.='    $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'this_record_has_not_been_updated_because_of_an_other_user\');'.CRLF;
  $sourceGenere.='    $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'please_retry\');'.CRLF;
  $count=0;
  foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
   if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
    if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
     $sourceGenere.='    unset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']);'.CRLF;
    }
   }
  }
  if($GLOBALS['__autoincrement'] != ''){
   $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&id=\'.$_POST[\'id1\']); exit();'.CRLF;
  }else{
   if(sizeof($GLOBALS['__listeChampsCles'])>0){
    $listeChampsCles='';
    foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
     $listeChampsCles.='&'.$v1.'=\'.urlencode($_POST[\''.$v1.'\']).\'';
    }
    $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u'.$listeChampsCles.'\'); exit();'.CRLF;
   }else{
    $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&todo=\'.$_POST[\'todo\']); exit();'.CRLF;
   }
  }
  $sourceGenere.='   }'.CRLF;
 }
 $sourceGenere.='   '.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  if($GLOBALS['__logTables']){
   $sourceGenere.='   $__afterUpdate='.$GLOBALS['function_include_to_call'].'($_GET[\'id\']);'.CRLF;
   $sourceGenere.='   $txtDiff='.$GLOBALS['function_difference_to_call'].'($__beforeUpdate,$__afterUpdate);'.CRLF;
  }else{
   $sourceGenere.='//  $__afterUpdate='.$GLOBALS['function_include_to_call'].'($_GET[\'id\']); // no log'.CRLF;   
   $sourceGenere.='//   $txtDiff='.$GLOBALS['function_difference_to_call'].'($__beforeUpdate,$__afterUpdate); // no log'.CRLF;
   $sourceGenere.='   $txtDiff=\'\';'.CRLF;
  }
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   if($GLOBALS['__logTables']){
    $sourceGenere.='   $__afterUpdate='.$GLOBALS['function_include_to_call'].'(';
   }else{
    $sourceGenere.='//   $__afterUpdate='.$GLOBALS['function_include_to_call'].'(';
   }
   $listeChampsCles='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles.=',$_POST[\''.$v1.'_origin1\']';
   }
   if($GLOBALS['__logTables']){
    $sourceGenere.=substr($listeChampsCles,1).');'.CRLF;
    $sourceGenere.='   $txtDiff='.$GLOBALS['function_difference_to_call'].'($__beforeUpdate,$__afterUpdate);'.CRLF;
   }else{
    $sourceGenere.=substr($listeChampsCles,1).'); // no log'.CRLF;    
    $sourceGenere.='//   $txtDiff='.$GLOBALS['function_difference_to_call'].'($__beforeUpdate,$__afterUpdate);'.CRLF;
   }
  }else{
   $sourceGenere.='// todo  !!! DANGER !!! no diff because there is no key on this table'.CRLF;
  }
 }
 
 if($GLOBALS['__logTables']){
  $sourceGenere.='   sqllog1( \'\'.$txtDiff.CRLF.\'\'.CRLF.\'$sql[]=<\'.\'<<EOT\'.CRLF.$req6.CRLF.\'EOT\' , BNF , __LINE__ );'.CRLF;
 }else{
  $sourceGenere.='//   s_q_l_l_o_g_1( $txtDiff.$req6 , BNF , __LINE__ ); // no log, uncomment and remove _ in the function name to log'.CRLF;
 }
 $sourceGenere.='   if(isset($_POST[\'save_the_modification_and_back_to_list\'])){'.CRLF;
 $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: '.$GLOBALS['file_list_to_call'].'\');'.CRLF;
 $sourceGenere.='    exit();'.CRLF;
 $sourceGenere.='   }else{'.CRLF;
 $sourceGenere.='    $_SESSION[PGMK][NAV][BNF][\'message\'][]=txtsys1(\'the_modification_has_been_recorded_at\') . \' \' . substr($GLOBALS[\'glob_setdate\'],11);'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&t=u&id=\'.$_POST[\'id1\']);'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles.='&'.$v1.'=\'.urlencode($_POST[\''.$v1.'\']).\'';
   }
   $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u'.$listeChampsCles.'\'); exit();'.CRLF;
  }else{
   $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&todo=\'.$_POST[\'todo\']); exit();'.CRLF;
  }
 }
 $sourceGenere.='    exit();'.CRLF;
 $sourceGenere.='   }'.CRLF;
 $sourceGenere.='  }'.CRLF;

 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= POST CONFIRM DELETE ==============================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' }else if(isset($_POST[\'a\'])&&$_POST[\'a\']==\'cd\'){'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.=' '.CRLF;
  $sourceGenere.='  require_once $GLOBALS[\'glob_incPath1\'].\'/__tableDependencies1.php\';'.CRLF;
  $sourceGenere.='  $retDependantTables=dependentValuesExist1('.$_GET['idBase'].',\''.$_GET['table'].'\',$_POST[\'id1\'] );'.CRLF;
  
  $sourceGenere.='  $dependantViewExist=false;'.CRLF;
  foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
   if(isset($v1['view_key_for']) && count($v1['view_key_for'])>0){
    foreach($v1['view_key_for'] as $k2=>$v2){
     $sourceGenere.='  // look for dependant view confirm'.CRLF;
     $sourceGenere.='  $retDependantView=dependentValuesExist1('.$_GET['idBase'].',\''.$v2.'\',$_POST[\'id1\'] );'.CRLF;
     $sourceGenere.='  if(isset($retDependantView[\'valuesExist\']) && $retDependantView[\'valuesExist\']==true){'.CRLF;
     $sourceGenere.='   if($dependantViewExist===false){'.CRLF;
     $sourceGenere.='    $retDependantTables=$retDependantView;'.CRLF;
     $sourceGenere.='   }'.CRLF;
     $sourceGenere.='  }'.CRLF;
    }
   }
  }
  $sourceGenere.='  if(true === $retDependantTables[\'valuesExist\']){'.CRLF;
  $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\') . \' \' . __LINE__ . \' \' . txtsys1(\'you_cannot_delete_because_some_values_are_still_present_in_dependant_table\') . \' \' . var_export( $retDependantTables[\'tables\'] , true ) . \' \';'.CRLF;
  $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=d&id=\'.$_POST[\'id1\']);   '.CRLF;
  $sourceGenere.='  }'.CRLF;
  $sourceGenere.=''.CRLF;

  $sourceGenere.='//  echo __FILE__ . \' \' . __LINE__ . \' __LINE__ = <pre>\' . var_export( $_POST , true ) . \'</pre>\' ; exit(0);'.CRLF;
  
  
  if($GLOBALS['__logTables']){
   $sourceGenere.='  $__beforeDelete='.$GLOBALS['function_include_to_call'].'($_GET[\'id\']);'.CRLF;
  }else{
   $sourceGenere.='//  $__beforeDelete='.$GLOBALS['function_include_to_call'].'($_GET[\'id\']); // no log'.CRLF;   
  }
  
  $sourceGenere.='  $req6="DELETE FROM `".$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\']."`.`'.$_GET['table'].'` WHERE `'.$GLOBALS['__autoincrement'].'`=".$_POST[\'id1\']." " ;'.CRLF;
  $sourceGenere.='  $res6=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
  $sourceGenere.='  if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=0){'.CRLF;
  $sourceGenere.='   if(mysqli_errno($GLOBALS[\'glob_db\'][0][\'link\'])==1451){ // foreign key constraint'.CRLF;
  $sourceGenere.='    $xtxterr=txtsys1(\'error\').\' "\' . __LINE__ . \'" \' . txtsys1(\'constraint_fail\');'.CRLF;
  $sourceGenere.='   }else{'.CRLF;
  $sourceGenere.='    $xtxterr=txtsys1(\'error\').\' "\' . __LINE__ . \'" mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\'][0][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
  $sourceGenere.='   }'.CRLF;
  $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;

  if($GLOBALS['__logTables']){
   $sourceGenere.='   txtlog1($xtxterr , BNF , __LINE__ , \'error\' );'.CRLF;
  }else{
   $sourceGenere.='//   t_x_t_l_o_g_1( $req6 , BNF , __LINE__ ); // no log, uncomment and remove _ in the function name to log'.CRLF;
  }
  $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=d&id=\'.$_POST[\'id1\']);'.CRLF;
  $sourceGenere.='   exit();'.CRLF;
  
  $sourceGenere.='  }else{'.CRLF;


  if($GLOBALS['__logTables']){
   $sourceGenere.='   $txtInsert='.$GLOBALS['function_rebuild_to_call'].'($__beforeDelete);'.CRLF;
   $sourceGenere.='   sqllog1($txtInsert.\'/*\'.CRLF.$req6.CRLF.\'*/\' , BNF , __LINE__ , \'error\' );'.CRLF;
  }else{
   $sourceGenere.='//   $txtInsert='.$GLOBALS['function_rebuild_to_call'].'($__beforeDelete);'.CRLF;
   $sourceGenere.='   $txtInsert=\'\';'.CRLF;
   $sourceGenere.='//   s_q_l_l_o_g_1($txtInsert.\'/*\'.CRLF.$req6.CRLF.\'*/\' , BNF , __LINE__ , \'error\' ); // no log , uncomment and remove _ in the function name to log'.CRLF;
  }
  
  $sourceGenere.='   unset($_SESSION[PGMK][NAV][BNF]);'.CRLF;
  $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: '.$GLOBALS['file_list_to_call'].'\');'.CRLF;
  $sourceGenere.='   exit();'.CRLF;
  $sourceGenere.='  }'.CRLF;
 }else{
  
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles1=$v1.'_origin1';
    break;
   }
   $sourceGenere.='  require_once $GLOBALS[\'glob_incPath1\'].\'/__tableDependencies1.php\';'.CRLF;
   if(sizeof($GLOBALS['__listeChampsCles'])>=2){
    $_SESSION[PGMK][NAV][BNF]['warningmessage'][]=txtsys1('warning').' '. __LINE__ .' ckeck table dependencies ';
    $sourceGenere.='  // todo check this, some fields are missing !!!!'.CRLF;
    $sourceGenere.='  if(false){'.CRLF;    
    $sourceGenere.='   $retDependantTables=dependentValuesExist1('.$_GET['idBase'].',\''.$_GET['table'].'\',$_POST[\''.$listeChampsCles1.'\'] );'.CRLF;    
    // recherche des vues dépendantes
    $sourceGenere.='   $dependantViewExist=false;'.CRLF;
    foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
     if(isset($v1['view_key_for']) && count($v1['view_key_for'])>0){
      foreach($v1['view_key_for'] as $k2=>$v2){
       $sourceGenere.='   // look for dependant view'.CRLF;
       $sourceGenere.='   $retDependantView=dependentValuesExist1('.$_GET['idBase'].',\''.$v2.'\',$_GET[\''.$listeChampsCles1.'\'] );'.CRLF;
       $sourceGenere.='   if(isset($retDependantView[\'valuesExist\']) && $retDependantView[\'valuesExist\']==true){'.CRLF;
       $sourceGenere.='    if($dependantViewExist===false){'.CRLF;
       $sourceGenere.='     $retDependantTables=$retDependantView;'.CRLF;
       $sourceGenere.='    }'.CRLF;
       $sourceGenere.='   }'.CRLF;
      }
     }
    }
    $sourceGenere.='   if(isset($retDependantTables[\'valuesExist\']) && true === $retDependantTables[\'valuesExist\']){'.CRLF;
    $sourceGenere.='    $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\') . \' \' . __LINE__ . \' \' . txtsys1(\'you_cannot_delete_because_some_values_are_still_present_in_dependant_table\') . \' \' . var_export( $retDependantTables[\'tables\'] , true ) . \' \';'.CRLF;
    $listeChampsCles2='';
    $listeChampsCles3='';
    foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
     $listeChampsCles2.='&'.$v1.'=\'.urlencode($_POST[\''.$v1.'\']).\'';
     $listeChampsCles3.='AND `'.$v1.'`=\'".addslashes($_POST[\''.$v1.'_origin1\'])."\' ';
    }
    $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=d'.$listeChampsCles2.'\');   '.CRLF;
    $sourceGenere.='   }'.CRLF;
    $sourceGenere.='  }'.CRLF;
   }else{
    $sourceGenere.='  $retDependantTables=dependentValuesExist1('.$_GET['idBase'].',\''.$_GET['table'].'\',$_POST[\''.$listeChampsCles1.'\'] );'.CRLF;    
    $sourceGenere.='    $dependantViewExist=false;'.CRLF;
    foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
     if(isset($v1['view_key_for']) && count($v1['view_key_for'])>0){
      foreach($v1['view_key_for'] as $k2=>$v2){
       $sourceGenere.='  // look for dependant view'.CRLF;
       $sourceGenere.='  $retDependantView=dependentValuesExist1('.$_GET['idBase'].',\''.$v2.'\',$_GET[\''.$listeChampsCles1.'\'] );'.CRLF;
       $sourceGenere.='  if(isset($retDependantView[\'valuesExist\']) && $retDependantView[\'valuesExist\']==true){'.CRLF;
       $sourceGenere.='   if($dependantViewExist===false){'.CRLF;
       $sourceGenere.='    $retDependantTables=$retDependantView;'.CRLF;
       $sourceGenere.='   }'.CRLF;
       $sourceGenere.='  }'.CRLF;
      }
     }
    }
    $sourceGenere.='  if(isset($retDependantTables[\'valuesExist\']) && true === $retDependantTables[\'valuesExist\']){'.CRLF;
    $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\') . \' \' . __LINE__ . \' \' . txtsys1(\'you_cannot_delete_because_some_values_are_still_present_in_dependant_table\') . \' \' . var_export( $retDependantTables[\'tables\'] , true ) . \' \';'.CRLF;
    $listeChampsCles2='';
    $listeChampsCles3='';
    foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
     $listeChampsCles2.='&'.$v1.'=\'.urlencode($_POST[\''.$v1.'\']).\'';
     $listeChampsCles3.='AND `'.$v1.'`=\'".addslashes($_POST[\''.$v1.'_origin1\'])."\' ';
    }
    $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=d'.$listeChampsCles2.'\');   '.CRLF;
    $sourceGenere.='  }'.CRLF;
    $sourceGenere.=''.CRLF;
   }
   
   if(sizeof($GLOBALS['__listeChampsCles'])>0){
    if($GLOBALS['__logTables']){
     $sourceGenere.='  $__beforeDelete='.$GLOBALS['function_include_to_call'].'(';
    }else{
     $sourceGenere.='//  $__beforeDelete='.$GLOBALS['function_include_to_call'].'(';    
    }
    $listeChampsCles='';
    foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
     $listeChampsCles.=',$_POST[\''.$v1.'_origin1\']';
    }
    if($GLOBALS['__logTables']){
     $sourceGenere.=substr($listeChampsCles,1).');'.CRLF;
    }else{
     $sourceGenere.=substr($listeChampsCles,1).'); // no log'.CRLF;    
    }
    if($GLOBALS['__logTables']){
     $sourceGenere.='  $txtInsert='.$GLOBALS['function_rebuild_to_call'].'($__beforeDelete);'.CRLF;
     $sourceGenere.='  sqllog1($txtInsert.\'/*\'.CRLF.$req6.CRLF.\'*/\' , BNF , __LINE__ , \'error\' );'.CRLF;
    }else{
     $sourceGenere.='//  $txtInsert='.$GLOBALS['function_rebuild_to_call'].'($__beforeDelete);'.CRLF;
     $sourceGenere.='  $txtInsert=\'\';'.CRLF;
     $sourceGenere.='//  s_q_l_l_o_g_1($txtInsert.\'/*\'.CRLF.$req6.CRLF.\'*/\' , BNF , __LINE__ , \'error\' ); // no log , uncomment and remove _ in the function name to log'.CRLF;
    }
    
   }else{
    $sourceGenere.='// todo  !!! DANGER !!! no diff because there is no key on this table'.CRLF;
   }
   
   

   $sourceGenere.='//  echo __FILE__ . \' \' . __LINE__ . \' __LINE__ = <pre>\' . var_export( $_POST , true ) . \'</pre>\' ; exit(0);'.CRLF;
   $sourceGenere.='  $req6="DELETE FROM `".$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\']."`.`'.$_GET['table'].'` WHERE '.substr($listeChampsCles3,3).'" ;'.CRLF;
   $sourceGenere.='  $res6=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
   $sourceGenere.='  if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=0){'.CRLF;
   $sourceGenere.='   $xtxterr=txtsys1(\'error\').\' "\' . __LINE__ . \'" mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\'][0][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
   $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;
   if($GLOBALS['__logTables']){
    $sourceGenere.='   txtlog1($xtxterr , BNF , __LINE__ , \'error\' );'.CRLF;
   }else{
    $sourceGenere.='//   t_x_t_l_o_g_1($xtxterr , BNF , __LINE__ , \'error\' ); // no log , uncomment and remove _ in the function name to log'.CRLF;
   }
   $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=d'.$listeChampsCles2.'\');'.CRLF;
   $sourceGenere.='   exit();'.CRLF;
   $sourceGenere.='  }else{'.CRLF;
   if($GLOBALS['__logTables']){
    $sourceGenere.='   sqllog1( $req6 , BNF , __LINE__ );'.CRLF;
   }else{
    $sourceGenere.='//   s_q_l_l_o_g_1( $req6 , BNF , __LINE__ ); // no log, uncomment and remove _ in the function name to log'.CRLF;
   }
   $sourceGenere.='   unset($_SESSION[PGMK][NAV][BNF]);'.CRLF;
   $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: '.$GLOBALS['file_list_to_call'].'\');'.CRLF;
   $sourceGenere.='   exit();'.CRLF;
   $sourceGenere.='  }'.CRLF;
  }else{
   $sourceGenere.='  // todo no auto increment, check this'.CRLF;
   $sourceGenere.='  echo __FILE__ . \' \' . __LINE__ . \' TODO = <pre>\' . var_export( $_POST , true ) . \'</pre>\' ; exit(0);'.CRLF;
   $sourceGenere.='  $req6="DELETE FROM `".$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\']."`.`'.$_GET['table'].'` WHERE `zzzzzzzzzzzzzz`=".$_POST[\'id1\']." " ;'.CRLF;
   $sourceGenere.='  $res6=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
   $sourceGenere.='  if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=0){'.CRLF;
   $sourceGenere.='   $xtxterr=txtsys1(\'error\').\' "\' . __LINE__ . \'" mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\'][0][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
   $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;
   if($GLOBALS['__logTables']){
    $sourceGenere.='   txtlog1($xtxterr , BNF , __LINE__ , \'error\' );'.CRLF;
   }else{
    $sourceGenere.='//   t_x_t_l_o_g_1($xtxterr , BNF , __LINE__ , \'error\' ); // no log , uncomment and remove _ in the function name to log'.CRLF;
   }
   $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=d&id=\'.$_POST[\'id1\']);'.CRLF;
   $sourceGenere.='   exit();'.CRLF;
   $sourceGenere.='  }else{'.CRLF;
   if($GLOBALS['__logTables']){
    $sourceGenere.='   sqllog1( $req6 , BNF , __LINE__ );'.CRLF;
   }else{
    $sourceGenere.='//   s_q_l_l_o_g_1( $req6 , BNF , __LINE__ ); // no log, uncomment and remove _ in the function name to log'.CRLF;
   }
   $sourceGenere.='   unset($_SESSION[PGMK][NAV][BNF]);'.CRLF;
   $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: '.$GLOBALS['file_list_to_call'].'\');'.CRLF;
   $sourceGenere.='   exit();'.CRLF;
   $sourceGenere.='  }'.CRLF;
  }
  
 }
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= POST CREATE ACTION ================================================================'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' }else if(isset($_POST[\'a\'])&&$_POST[\'a\']==\'c\'){'.CRLF;
 
 if($warningFlagOn1){
  $sourceGenere.='  if(test_input_'.$GLOBALS['tableShortName'].'_KO1()||isset($_POST[\'correct_the_warning_values\'])){'.CRLF;
  $sourceGenere.='   $___warningExist=(isset($_SESSION[PGMK][NAV][BNF][\'warningmessage\']) && count($_SESSION[PGMK][NAV][BNF][\'warningmessage\'])>0)?true:false;'.CRLF;
  $sourceGenere.='   if($___warningExist){'.CRLF;
  $sourceGenere.='    unset($_SESSION[PGMK][NAV][BNF][\'warningmessage\']);'.CRLF;
  $sourceGenere.='    unset($_SESSION[PGMK][NAV][BNF][\'highlight\']);'.CRLF;
  $sourceGenere.='   }'.CRLF;
 }else{
  $sourceGenere.='  if(test_input_'.$GLOBALS['tableShortName'].'_KO1()){'.CRLF;
 }
 $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=c\');'.CRLF;
 $sourceGenere.='   exit();'.CRLF;
 $sourceGenere.='  }'.CRLF;
 
 

 
 
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb' ){
   $sourceGenere.='  if(isset($_FILES[\''.$v1['nom_champ'].'\']) && $_FILES[\''.$v1['nom_champ'].'\'][\'error\']==0){'.CRLF;
   $sourceGenere.='   $__image_'.$v1['nom_champ'].'=file_get_contents($_FILES[\''.$v1['nom_champ'].'\'][\'tmp_name\']);'.CRLF;
   $sourceGenere.='  }'.CRLF;
  }
 }

 if($warningFlagOn1){
  $sourceGenere.='  $___warningExist=(isset($_SESSION[PGMK][NAV][BNF][\'warningmessage\']) && count($_SESSION[PGMK][NAV][BNF][\'warningmessage\'])>0)?true:false;'.CRLF;
  $sourceGenere.='  if($___warningExist){'.CRLF;
  $sourceGenere.='   if(!isset($_POST[\'__bypass_warning\'])){'.CRLF;
  $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=c\');'.CRLF;
  $sourceGenere.='    exit();'.CRLF;
  $sourceGenere.='   }else{'.CRLF;
  $sourceGenere.='//    unset($_SESSION[PGMK][NAV][BNF][\'warningmessage\']);'.CRLF;
  $sourceGenere.='//    unset($_SESSION[PGMK][NAV][BNF][\'highlight\']);'.CRLF;
  $sourceGenere.='   }'.CRLF;
  $sourceGenere.='  }'.CRLF;
 }
 
 $sourceGenere.='  $req6="'.CRLF;
 $sourceGenere.='   INSERT INTO `".$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\']."`.`'.$_GET['table'].'` SET'.CRLF;

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){

    if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb' ){
    }else if($v1['type_champ']=='timestamp'){
    }else if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){
     if($count==0){
      $sourceGenere.='     ';
     }else{
      $sourceGenere.='    ,';
     }
     if($v1['null_possible']=='YES'){
      $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".(is_null($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])?\'NULL\':"\'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])."\'")."'.CRLF;
     }else{
      $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
     }
     $count++;
    }else if( 'date'===$v1['type_champ'] || 'time'===$v1['type_champ']  || 'datetime'===$v1['type_champ'] ){
     
     $doIt=true;
     if('date'===$v1['type_champ'] && ( (isset($v1['dtcrt']) && $v1['dtcrt']==true) || (isset($v1['dtupd']) && $v1['dtupd']==true)  )){
      $doIt=false;
      if($count==0){
       $sourceGenere.='     ';
      }else{
       $sourceGenere.='    ,';
      }
      $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($GLOBALS[\'glob_setdate\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
      $count++;
     }
     if($doIt){
      if($count==0){
       $sourceGenere.='     ';
      }else{
       $sourceGenere.='    ,';
      }
      if($v1['null_possible']!='YES'){
       $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
      }else{
       $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".(is_null($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])?\'NULL\':"\'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])."\'")."'.CRLF;
      }
      $count++;
     }
    }else if(true===$v1['isNumericField']){

     $doIt=true;
     if(isset($v1['isUser']) && $v1['isUser']==true){
      $doIt=false;
      if($count==0){
       $sourceGenere.='     ';
      }else{
       $sourceGenere.='    ,';
      }
      $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".$_SESSION[PGMK][\'login\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'            ."'.CRLF;
      $count++;
     }
     if(isset($v1['isGroup']) && $v1['isGroup']==true){
      $doIt=false;
      if($count==0){
       $sourceGenere.='     ';
      }else{
       $sourceGenere.='    ,';
      }
      $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".$_SESSION[PGMK][\'group\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'            ."'.CRLF;
      $count++;
     }
    
     if($doIt){
      if(0===$count){
       $sourceGenere.='     ';
      }else{
       $sourceGenere.='    ,';
      }
      if($v1['null_possible']=='YES'){
       $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ".($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'?\'NULL\':addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']))."'.CRLF;
      }else{
       $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'            ."'.CRLF;
      }
      $count++;
     }
    }else{
     $doIt=true;
     if(isset($v1['isUser']) && $v1['isUser']==true){
      $doIt=false;
      if($count==0){
       $sourceGenere.='     ';
      }else{
       $sourceGenere.='    ,';
      }
      $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($_SESSION[PGMK][\'login\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
      $count++;
     }
     if(isset($v1['isGroup']) && $v1['isGroup']==true){
      $doIt=false;
      if($count==0){
       $sourceGenere.='     ';
      }else{
       $sourceGenere.='    ,';
      }
      $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($_SESSION[PGMK][\'group\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
      $count++;
     }
    
     if($doIt){
      if(0===$count){
       $sourceGenere.='     ';
      }else{
       $sourceGenere.='    ,';
      }
      if($v1['null_possible']=='YES'){
       if($v1['type_champ']=='geometry'){
        $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ".($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'?\'NULL\':"ST_GeomFromText(\'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']) ."\')")."'.CRLF;
       }else{
        $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ".($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'?\'NULL\':"\'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']) ."\'")."'.CRLF;       
       }
       $count++;
      }else{
       if($v1['type_champ']=='geometry'){
        $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ST_GeomFromText(\'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])-11).'."\')'.CRLF;
       }else{
        $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
       }
       $count++;
      }
     }
    }
   }
  }else{
   if($v1['tsupd']||$v1['tscrt']){
    if($count==0){
     $sourceGenere.='     ';
    }else{
     $sourceGenere.='    ,';
    }
    $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes1($GLOBALS[\'glob_setdate\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'                     ."\''.CRLF;
    $count++;
   }
  }
 }
 $sourceGenere.='  " ;'.CRLF;
 
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb' ){
   $sourceGenere.='  if(isset($__image_'.$v1['nom_champ'].')){'.CRLF;
   $sourceGenere.='   $req6.="'.CRLF;
   $sourceGenere.='    , `'.$v1['nom_champ'].'` = \'".addslashes1($__image_'.$v1['nom_champ'].')."\''.CRLF;
   $sourceGenere.='   ";'.CRLF;
   $sourceGenere.='  }'.CRLF;
  }
 }  
 
 
 $sourceGenere.='//  echo __FILE__ . \' \' . __LINE__ . \' $req6 =\' . $req6 . \'\' ; exit();'.CRLF;
 $sourceGenere.='  $res6=@mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
 $sourceGenere.='  if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=0){'.CRLF;
 $sourceGenere.='   switch(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])){'.CRLF;
 $sourceGenere.='    case 1062 :'.CRLF;
 $sourceGenere.='     $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'this_record_already_exist\');'.CRLF;
 $sourceGenere.='    break;'.CRLF;
 $sourceGenere.='    default;'.CRLF;
 $sourceGenere.='    $xtxterr=txtsys1(\'error\').\' "\' . __LINE__ . \'" mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
 $sourceGenere.='    $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;
 if($GLOBALS['__logTables']){
  $sourceGenere.='    txtlog1($xtxterr , BNF , __LINE__ , \'error\' );'.CRLF;
 }else{
  $sourceGenere.='//    t_x_t_l_o_g_1($xtxterr , BNF , __LINE__ , \'error\' ); // no log , uncomment and remove _ in the function name to log'.CRLF;
 }
 $sourceGenere.='    break;'.CRLF;
 $sourceGenere.='   }'.CRLF;
 $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=c\');'.CRLF;
 $sourceGenere.='   exit();'.CRLF;
 $sourceGenere.='  }else{'.CRLF; // LAST_INSERT_ID
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='   $resIns=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],\'SELECT LAST_INSERT_ID()\');'.CRLF;
  $sourceGenere.='   if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=0){'.CRLF;
  $sourceGenere.='    $xtxterr=txtsys1(\'error\').\' "\' . __LINE__ . \'" mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
  $sourceGenere.='    $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;
  if($GLOBALS['__logTables']){
   $sourceGenere.='    txtlog1($xtxterr , BNF , __LINE__ , \'error\' );'.CRLF;
  }else{
   $sourceGenere.='//    t_x_t_l_o_g_1($xtxterr , BNF , __LINE__ , \'error\' ); // no log , uncomment and remove _ in the function name to log'.CRLF;
  }
  $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=c\');'.CRLF;
  $sourceGenere.='    exit();'.CRLF;
 }else{
  $sourceGenere.='   if(!$res6){'.CRLF;
  $sourceGenere.='    $xtxterr=txtsys1(\'error\').\' "\' . __LINE__ . \'" mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
  $sourceGenere.='    $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;
  if($GLOBALS['__logTables']){
   $sourceGenere.='    txtlog1($xtxterr , BNF , __LINE__ , \'error\' );'.CRLF;
  }else{
   $sourceGenere.='//    t_x_t_l_o_g_1($xtxterr , BNF , __LINE__ , \'error\' ); // no log , uncomment and remove _ in the function name to log'.CRLF;
  }
  $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=c\');'.CRLF;
  $sourceGenere.='    exit();'.CRLF;
 }
 $sourceGenere.='   }else{'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='    $NewCode=mysqli_fetch_row($resIns);'.CRLF;
  $sourceGenere.='    $NewCode=$NewCode[0];'.CRLF;
  $sourceGenere.='    mysqli_free_result($resIns);'.CRLF;
  if($GLOBALS['__logTables']){
   $sourceGenere.='    sqllog1(\'// INSERT INTO `'.$_GET['table'].'` OK with NewCode=\'.NewCode.\' \'.CRLF.\'$sql[]=<<<EOT\'.$req6.CRLF.\'EOT\' , BNF , __LINE__ );'.CRLF;
  }else{
   $sourceGenere.='//    s_q_l_l_o_g_1( \'INSERT INTO `'.$_GET['table'].'` OK with NewCode=\'.NewCode.\' \'.\'$sql[]=<<<EOT\'.$req6.CRLF.\'EOT\' , BNF , __LINE__ ); // no log, uncomment and remove _ in the function name to log'.CRLF;
  }
  
  $sourceGenere.='    SetSessionMessageAndLog1( txt1(\'the new value has been inserted\') . \' (\'.$NewCode.\').\' , BNF , __LINE__ , \'information\');'.CRLF;
  $sourceGenere.='    if(isset($_POST[\'record_the_element_and_back_to_list\'])){'.CRLF;
  $sourceGenere.='     header(\'HTTP/1.1 303 See Other\');header(\'Location: '.$GLOBALS['file_list_to_call'].'\');'.CRLF;
  $sourceGenere.='     exit();'.CRLF;
  $sourceGenere.='    }else{'.CRLF;
  $sourceGenere.='     header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&t=n&id=\'.$NewCode);'.CRLF;
  $sourceGenere.='     exit();'.CRLF;
  $sourceGenere.='    }'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   $listeChampsCles2='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles1.='.\'.$_POST[\''.$v1.'\'].\'';
    $listeChampsCles2.='&'.$v1.'=\'.urlencode($_POST[\''.$v1.'\']).\'';
   }
  }else{
   $listeChampsCles1='.\'.$_POST[\'todo\'].\'';
   $listeChampsCles2='&todo=\'.$todo.\'';
  }
  
  if($GLOBALS['__logTables']){
   $sourceGenere.='    sqllog1(\'// INSERT INTO `'.$_GET['table'].'` OK  \'.CRLF.\'$sql[]=<<<EOT\'.$req6.CRLF.\'EOT\' , BNF , __LINE__ );'.CRLF;
  }else{
   $sourceGenere.='//    s_q_l_l_o_g_1( \'INSERT INTO `'.$_GET['table'].'` OK \'.\'$sql[]=<<<EOT\'.$req6.CRLF.\'EOT\' , BNF , __LINE__ ); // no log, uncomment and remove _ in the function name to log'.CRLF;
  }

  $sourceGenere.='    SetSessionMessageAndLog1( txt1(\'the new value has been inserted\') . \' ('.substr( $listeChampsCles1 , 1).').\' , BNF , __LINE__ , \'information\');'.CRLF;
  $sourceGenere.='    if(isset($_POST[\'record_the_element_and_back_to_list\'])){'.CRLF;
  $sourceGenere.='     header(\'HTTP/1.1 303 See Other\');header(\'Location: '.$GLOBALS['file_list_to_call'].'\');'.CRLF;
  $sourceGenere.='     exit();'.CRLF;
  $sourceGenere.='    }else{'.CRLF;
  $sourceGenere.='     header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=u&t=n'.$listeChampsCles2.'\');'.CRLF;
  $sourceGenere.='     exit();'.CRLF;
  $sourceGenere.='    }'.CRLF;  
 }
 $sourceGenere.='   }'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' '.CRLF;

 $sourceGenere.='}else{ // get action'.CRLF;
 $sourceGenere.=''.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= GET ACTION ========================================================================'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;


 $sourceGenere.=' if(isset($_GET[\'a\'])&&$_GET[\'a\']==\'du\'){ // duplicate action'.CRLF;
 $sourceGenere.='  $xxxFldValues=array();'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='  $name2='.$GLOBALS['function_include_to_call'].'($_GET[\'id\']);'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles1.=',$_GET[\''.$v1.'\']';
   }
   if(isset($GLOBALS['__listeDesChampsParents']) && sizeof($GLOBALS['__listeDesChampsParents'])>0){
    $hasParentFields=true;
    $sourceGenere.='  $name2='.$GLOBALS['function_include_to_call_with_parent_field'].'('.substr($listeChampsCles1,1).');'.CRLF;
   }else{
    $sourceGenere.='  $name2='.$GLOBALS['function_include_to_call'].'('.substr($listeChampsCles1,1).');'.CRLF;
   }
   
  }else{
   $sourceGenere.='  $name2='.$GLOBALS['function_include_to_call'].'($_GET[\'todo\']); // 2'.CRLF;
  }
 }
 if(isset($GLOBALS['__showDeleteFieldName']) && $GLOBALS['__showDeleteFieldName']!=''){
  $tab__showDeleteFieldName=explode(',',$GLOBALS['__showDeleteFieldName']);
  $sourceGenere.='  if($name2[\'T0_'.$tab__showDeleteFieldName[0].'\']==\'\'){'.CRLF;
 }else{
  
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles1.='||$name2[\'T0_'.$v1.'\']==\'\'';
   }
   $sourceGenere.='  if('.substr($listeChampsCles1,2).'){'.CRLF;
  }else{
   $sourceGenere.='  if($name2[\'todo_no_delete_fields_defined\']==\'\'){'.CRLF;
  }
 }
 $sourceGenere.='   $_SESSION[PGMK][NAV][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_cannot_duplicate_this_value\');'.CRLF;
 $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: '.$GLOBALS['file_list_to_call'].'\');'.CRLF;
 $sourceGenere.='   exit();'.CRLF;
 $sourceGenere.='  }else{'.CRLF;
 $sourceGenere.='   // todo set fields for duplicate'.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb' ){
    }else if($v1['type_champ']=='timestamp'){
    }else{
     $doIt=true;
     if( ( isset($v1['isUser']) && $v1['isUser']==true ) || (  isset($v1['isGroup']) && $v1['isGroup']==true ) ){
      $doIt=false;
     }
     if( (isset($v1['dtupd']) && $v1['dtupd']==true) || (isset($v1['dtcrt']) && $v1['dtcrt']==true) ){
      $doIt=false;
     }
     if($doIt){
      $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=$name2[\'T0_'.$v1['nom_champ'].'\'];'.CRLF;
     }
    }
   }
  }
 }
 $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: \'.BNF.\'?a=c\' );'.CRLF;
 $sourceGenere.='   exit();'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' '.CRLF;

 $sourceGenere.=' $o1=htmlHead1(array());'.CRLF;
 $sourceGenere.=' $js1=array();'.CRLF;
 $sourceGenere.='// echo __LINE__ . \'$_SESSION[PGMK]=<pre>\' . var_export( $_SESSION[PGMK] , true ) . \'</pre>\'; exit();'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= GET DELETE ========================================================================'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' if(isset($_GET[\'a\'])&&$_GET[\'a\']==\'d\'){ // delete action'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='  $id=(isset($_GET[\'id\'])&&is_numeric($_GET[\'id\']))?$_GET[\'id\']:0;'.CRLF;
  $sourceGenere.='  if($id==0){'.CRLF;
 }else{
  
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   $listeChampsCles2='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles1.='&&isset($_GET[\''.$v1.'\'])';
    $listeChampsCles2=$v1;
   }
   $sourceGenere.='  $id=('.substr($listeChampsCles1,2).')?$_GET[\''.$listeChampsCles2.'\']:null;'.CRLF;
   $sourceGenere.='  if($id===null){'.CRLF;  
  }else{
   $sourceGenere.='  $id=(isset($_GET[\'todo\'])&&is_numeric($_GET[\'todo\']))?$_GET[\'todo\']:0;'.CRLF;
   $sourceGenere.='  if($id==0){'.CRLF;  
  }
 }
 $sourceGenere.='   header(\'HTTP/1.1 303 See Other\');header(\'Location: '.$GLOBALS['file_list_to_call'].'\');'.CRLF;
 $sourceGenere.='   exit();'.CRLF;
 $sourceGenere.='  }else{'.CRLF;
 $hasParentFields=false;
 if($GLOBALS['__autoincrement'] != ''){
  $listeChampsCles1=',$_GET[\'id\']';
 }else{  
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles1.=',$_GET[\''.$v1.'\']';
   }
  }else{
   $listeChampsCles1.=',$_GET[\'todo\']';
  }
 }
 if(isset($GLOBALS['__listeDesChampsParents']) && sizeof($GLOBALS['__listeDesChampsParents'])>0){
  $hasParentFields=true;
  $sourceGenere.='   $xvalueName='.$GLOBALS['function_include_to_call_with_parent_field'].'('.substr($listeChampsCles1,1).');'.CRLF;
 }else{
  $sourceGenere.='   $xvalueName='.$GLOBALS['function_include_to_call'].'('.substr($listeChampsCles1,1).');'.CRLF;
 }
 if(isset($GLOBALS['__showDeleteFieldName']) && $GLOBALS['__showDeleteFieldName']!=''){
  $tab__showDeleteFieldName=explode(',',$GLOBALS['__showDeleteFieldName']);
  $sourceGenere.='   if($xvalueName[\'T0_'.$tab__showDeleteFieldName[0].'\']==\'\'){'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles1.='||$_GET[\''.$v1.'\']==\'\'';
   }
   $sourceGenere.='   if('.substr($listeChampsCles1,2).'){'.CRLF;
  }else{
   $sourceGenere.='   if($xvalueName[\'todo\']==\'\'){'.CRLF;
  }
 }
 $sourceGenere.='    $_SESSION[PGMK][NAV][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_cannot_delete_this_value\');'.CRLF;
 $sourceGenere.='    header(\'HTTP/1.1 303 See Other\');header(\'Location: '.$GLOBALS['file_list_to_call'].'\');'.CRLF;
 $sourceGenere.='    exit();'.CRLF;
 $sourceGenere.='   }else{'.CRLF;
 $sourceGenere.='    // use if($xvalueName[\'field_linked_to_user\']!=$_SESSION[PGMK][\'login\']){ // if the current record you want to update is not yours'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='    require_once $GLOBALS[\'glob_incPath1\'].\'/__tableDependencies1.php\';'.CRLF;
  $sourceGenere.='    $retDependantTables=dependentValuesExist1('.$_GET['idBase'].',\''.$_GET['table'].'\',$_GET[\'id\'] );'.CRLF;
  // recherche des vues dépendantes
  $sourceGenere.='    $dependantViewExist=false;'.CRLF;
  foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
   if(isset($v1['view_key_for']) && count($v1['view_key_for'])>0){
    foreach($v1['view_key_for'] as $k2=>$v2){
     $sourceGenere.='    // look for dependant view'.CRLF;
     $sourceGenere.='    $retDependantView=dependentValuesExist1('.$_GET['idBase'].',\''.$v2.'\',$_GET[\'id\'] );'.CRLF;
     $sourceGenere.='    if(isset($retDependantView[\'valuesExist\']) && $retDependantView[\'valuesExist\']==true){'.CRLF;
     $sourceGenere.='     if($dependantViewExist===false){'.CRLF;
     $sourceGenere.='      $retDependantTables=$retDependantView;'.CRLF;
     $sourceGenere.='     }'.CRLF;
     $sourceGenere.='    }'.CRLF;
    }
   }
  }
  $sourceGenere.='    if(isset($retDependantTables[\'valuesExist\']) && $retDependantTables[\'valuesExist\']==true){'.CRLF;
  $sourceGenere.='     $o1.=displaySessionMessage1(BNF);'.CRLF;
  $sourceGenere.='     $o1.=\'<div style="text-align:center;">\'.CRLF;'.CRLF;
  $sourceGenere.='     $o1.=\' <div class="yyerror yymessageBox" >\'.txtsys1(\'error\') . \' \' . __LINE__ . \' \'.txtsys1(\'dependent_values_exist\').\'</div>\'.CRLF;'.CRLF;
  $sourceGenere.='     $o1.=\' <ul style="list-style:none;padding:0;">\';'.CRLF;
  $sourceGenere.='     foreach( $retDependantTables[\'tables\'] as $k1 => $v1){'.CRLF;
  $sourceGenere.='      $o1.=\'  <li>\'.$v1.\'</li>\'.CRLF;'.CRLF;
  $sourceGenere.='     }'.CRLF;
  $sourceGenere.='     $o1.=\' </ul>\'.CRLF;'.CRLF;
  $sourceGenere.='     $o1.=btl1();'.CRLF;
  $sourceGenere.='     $o1.=\'</div>\'.CRLF;'.CRLF;
 }else{
  
  if(sizeof($GLOBALS['__listeChampsCles'])==1){
   $listeChampsCles1='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles1=$v1;
   }
   $sourceGenere.='    require_once $GLOBALS[\'glob_incPath1\'].\'/__tableDependencies1.php\';'.CRLF;
   $sourceGenere.='    $retDependantTables=dependentValuesExist1('.$_GET['idBase'].',\''.$_GET['table'].'\',$_GET[\''.$listeChampsCles1.'\'] );'.CRLF;
   // recherche des vues dépendantes
   $sourceGenere.='    $dependantViewExist=false;'.CRLF;
   foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
    if(isset($v1['view_key_for']) && count($v1['view_key_for'])>0){
     foreach($v1['view_key_for'] as $k2=>$v2){
      $sourceGenere.='    // look for dependant view'.CRLF;
      $sourceGenere.='    $retDependantView=dependentValuesExist1('.$_GET['idBase'].',\''.$v2.'\',$_GET[\''.$listeChampsCles1.'\'] );'.CRLF;
      $sourceGenere.='    if(isset($retDependantView[\'valuesExist\']) && $retDependantView[\'valuesExist\']==true){'.CRLF;
      $sourceGenere.='     if($dependantViewExist===false){'.CRLF;
      $sourceGenere.='      $retDependantTables=$retDependantView;'.CRLF;
      $sourceGenere.='     }'.CRLF;
      $sourceGenere.='    }'.CRLF;
     }
    }
   }
   $sourceGenere.='    if(isset($retDependantTables[\'valuesExist\']) && $retDependantTables[\'valuesExist\']==true){'.CRLF;
   $sourceGenere.='     $o1.=displaySessionMessage1(BNF);'.CRLF;
   $sourceGenere.='     $o1.=\'<div style="text-align:center;">\'.CRLF;'.CRLF;
   $sourceGenere.='     $o1.=\' <div class="yyerror yymessageBox" >\'.txtsys1(\'error\') . \' \' . __LINE__ . \' \'.txtsys1(\'dependent_values_exist\').\'</div>\'.CRLF;'.CRLF;
   $sourceGenere.='     $o1.=\' <ul>\'.CRLF;'.CRLF;
   $sourceGenere.='     $o1.=\' <ul style="list-style:none;padding:0;">\';'.CRLF;
   $sourceGenere.='     foreach( $retDependantTables[\'tables\'] as $k1 => $v1){'.CRLF;
   $sourceGenere.='      $o1.=\'  <li>\'.$v1.\'</li>\'.CRLF;'.CRLF;
   $sourceGenere.='     }'.CRLF;
   $sourceGenere.='     $o1.=\' </ul>\'.CRLF;'.CRLF;
   $sourceGenere.='     $o1.=btl1();'.CRLF;
   $sourceGenere.='     $o1.=\'</div>\'.CRLF;'.CRLF;
  }else{
   $sourceGenere.='     '.CRLF;
   $_SESSION[PGMK][NAV][BNF]['warningmessage'][]=txtsys1('warning').' '. __LINE__ .' ckeck table dependencies ';
   $sourceGenere.='    if(false){ // todo check table dependancies if necessary'.CRLF;
   $sourceGenere.='//   $retDependantTables=dependentValuesExist1('.$_GET['idBase'].',\''.$_GET['table'].'\',$_GET[\''.$listeChampsCles1.'\'] );'.CRLF;
   // recherche des vues dépendantes
   $sourceGenere.='     $dependantViewExist=false;'.CRLF;
   foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
    if(isset($v1['view_key_for']) && count($v1['view_key_for'])>0){
     foreach($v1['view_key_for'] as $k2=>$v2){
      $sourceGenere.='    // look for dependant view'.CRLF;
      $sourceGenere.='    $retDependantView=dependentValuesExist1('.$_GET['idBase'].',\''.$v2.'\',$_GET[\''.$listeChampsCles1.'\'] );'.CRLF;
      $sourceGenere.='    if(isset($retDependantView[\'valuesExist\']) && $retDependantView[\'valuesExist\']==true){'.CRLF;
      $sourceGenere.='     if($dependantViewExist===false){'.CRLF;
      $sourceGenere.='      $retDependantTables=$retDependantView;'.CRLF;
      $sourceGenere.='     }'.CRLF;
      $sourceGenere.='    }'.CRLF;
     }
    }
   }
   $sourceGenere.='     $o1.=displaySessionMessage1(BNF);'.CRLF;
   $sourceGenere.='     $o1.=\'<div style="text-align:center;">\'.CRLF;'.CRLF;
   $sourceGenere.='     $o1.=\' <div class="yyerror yymessageBox" >\'.txtsys1(\'error\') . \' \' . __LINE__ . \' \'.txtsys1(\'dependent_values_exist\').\'</div>\'.CRLF;'.CRLF;
   $sourceGenere.='     $o1.=btl1();'.CRLF;
   $sourceGenere.='     $o1.=\'</div>\'.CRLF;'.CRLF;
  }
 }
 $sourceGenere.='    }else{'.CRLF;
 $sourceGenere.='     $o1.=displaySessionMessage1(BNF);'.CRLF;
 $sourceGenere.='     $o1.=\' <form method="post" class="yyformDelete">\'.CRLF;'.CRLF;
 $sourceGenere.='     $o1.=\'   \'.txtsys1(\'please_confirm_deletion_of\').\' : \'.CRLF;'.CRLF;
 if(isset($GLOBALS['__showDeleteFieldName']) && $GLOBALS['__showDeleteFieldName']!=''){
  $tab__showDeleteFieldName=explode(',',$GLOBALS['__showDeleteFieldName']);
  $sourceGenere.='     $o1.=\'   <br /><br /><b>\'';
  foreach( $tab__showDeleteFieldName as $dk0 => $vk0){
   if($vk0==$GLOBALS['__autoincrement']){
    $sourceGenere.='.'.CRLF.'           \'(\'.$xvalueName[\'T0_'.$vk0.'\'].\') \'';
   }else{
    foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
     if($vk0==$v1['nom_champ']){
      $indVal1='T0_'.$vk0;
      if(isset($v1['param'])){
       if(isset($v1['unsetPossible']) && $v1['unsetPossible']===true){
        $sourceGenere.='.'.CRLF.'           txt1(\''.$vk0.'\')'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($vk0)).' . \' : \' .($xvalueName[\''.$indVal1.'\']==null?\'\':displayParam1(\''.$v1['param'].'\',$xvalueName[\''.$indVal1.'\'],array(\'unsetPossible\'=>true))).\' <br /> \'';
       }else{
        $sourceGenere.='.'.CRLF.'           txt1(\''.$vk0.'\')'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($vk0)).' . \' : \' .($xvalueName[\''.$indVal1.'\']==null?\'\':displayParam1(\''.$v1['param'].'\',$xvalueName[\''.$indVal1.'\'],array(\'unsetPossible\'=>false))).\' <br /> \'';
       }
      }else{
       $sourceGenere.='.'.CRLF.'           txt1(\''.$vk0.'\')'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($vk0)).' . \' : \' .$xvalueName[\''.$indVal1.'\'].\' <br /> \'';
      }
     }
    }
   }
  }
  foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
   if(isset($v1['parentField'])){
    foreach( $v1['parentField']['fieldList'] as $k0 => $v0){
     if($v0['comment']!=''){
      $jsonComment=json_decode($v0['comment'],true);
      if($jsonComment && isset($jsonComment['showDeleteField']) && $jsonComment['showDeleteField']==true){
       if(isset($v0['param_name'])){
        if(!in_array($v0['param_name'],$listeDesParametres)){
         $sourceGenere.='require_once($GLOBALS[\'glob_noVcPath1\'].\'/parameters/'.$v0['param_name'].'.php\');'.CRLF;
        }
        if(isset($v0['unsetPossible']) && $v0['unsetPossible']===true){
         $sourceGenere.='.'.CRLF.'           txt1(\''.$v0['nom_champ'].'\')'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v0['nom_champ'])).' . \' : \' .($xvalueName[\'T'.$v1['parentField']['numParent1'].'_'.$v0['nom_champ'].'\']==null?\'\':displayParam1(\''.$v0['param_name'].'\',$xvalueName[\'T'.$v1['parentField']['numParent1'].'_'.$v0['nom_champ'].'\'],array(\'unsetPossible\'=>true))).\' <br /> \'';
        }else{
         $sourceGenere.='.'.CRLF.'           txt1(\''.$v0['nom_champ'].'\')'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v0['nom_champ'])).' . \' : \' .($xvalueName[\'T'.$v1['parentField']['numParent1'].'_'.$v0['nom_champ'].'\']==null?\'\':displayParam1(\''.$v0['param_name'].'\',$xvalueName[\'T'.$v1['parentField']['numParent1'].'_'.$v0['nom_champ'].'\'],array(\'unsetPossible\'=>false))).\' <br /> \'';
        }
        }else{
        $sourceGenere.='.'.CRLF.'           txt1(\''.$v0['nom_champ'].'\')'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v0['nom_champ'])).' . \' : \' .$xvalueName[\'T'.$v1['parentField']['numParent1'].'_'.$v0['nom_champ'].'\'].\' <br /> \'';
       }
      }
     }
    }
   }
  }
  $sourceGenere.='.'.CRLF.'           \'</b><br />\'.CRLF;'.CRLF;
 }else{
  $listeChampsDep1='';
  foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
   if(isset($v1['parentField'])){
    foreach($v1['parentField']['fieldList'] as $k2=>$v2){
     if($v2['nom_champ']!=$v1['nom_champ']){
      if($v2['comment']!=''){
       $jsonComment=json_decode($v2['comment'],true);
       if($jsonComment && isset($jsonComment['showDeleteField']) && $jsonComment['showDeleteField']==true){
        $listeChampsDep1.=CRLF.'             txt1(\'T'.$v1['parentField']['numParent1'].'_'.$v2['nom_champ'].'\').\' : \'.$xvalueName[\'T'.$v1['parentField']['numParent1'].'_'.$v2['nom_champ'].'\'].\'<br />\'.';    
       }
      }
     }
    }
   }
  }
  if($listeChampsDep1!=''){
   $sourceGenere.='      // no showDeleteField defined'.CRLF;
   $sourceGenere.='     $o1.=\'   <br /><br />\'.'.substr($listeChampsDep1,0).'\'<br /><br />\'.CRLF;'.CRLF;
  }else{
   $sourceGenere.='      // no showDeleteField defined'.CRLF;
   $sourceGenere.='     $o1.=\'   <br /><br /><b>\'.$xvalueName[\'todo\'].\'</b><br /><br />\'.CRLF;'.CRLF;
   
  }
 }
 
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='     $o1.=\'   <input type="hidden" value="\'.$_GET[\'id\'].\'" name="id1" id="id1" />\'.CRLF;'.CRLF;
 }else{
  
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   $listeChampsCles2='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $sourceGenere.='     $o1.=\'   <input type="hidden" value="\'.$_GET[\''.$v1.'\'].\'" name="'.$v1.'_origin1" id="'.$v1.'_origin1" />\'.CRLF;'.CRLF;
   }
  }else{
   $sourceGenere.='     $o1.=\'   <input type="hidden" value="\'todo\'" name="todo" id="todo" />\'.CRLF;'.CRLF;
  }
 }
 $sourceGenere.='     $o1.=\'   <input type="hidden" value="cd" name="a" id="a" />\'."\r\n";'.CRLF;
 $sourceGenere.='     $o1.=\'   <button type="submit" class="yydanger">\'.txtsys1(\'i_confirm_the_deletion_button\').\'</button>\'.CRLF;'.CRLF;
 $sourceGenere.='     $o1.=btl1();'.CRLF;
 $sourceGenere.='     $o1.=\' </form>\'."\r\n";'.CRLF;
 $sourceGenere.='      '.CRLF;
 $sourceGenere.='    }'.CRLF;
 $sourceGenere.='   }'.CRLF;
 $sourceGenere.='  }'.CRLF;

 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= GET UPDATE ========================================================================'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' '.CRLF;
 $sourceGenere.=' }else if(isset($_GET[\'a\'])&&$_GET[\'a\']==\'u\'){ // update action'.CRLF;
 $sourceGenere.='  $xxxFldValues=array();'.CRLF;
 $sourceGenere.='  $js1=array();'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='  $o1.=\'<h2>\'.txt1(\'update a '.$GLOBALS['tableShortName'].'\').\' (\'.$_GET[\'id\'].\')\'.btl1().\'</h2>\'.CRLF;'.CRLF;
 }else{
  $sourceGenere.='  $o1.=\'<h2>\'.txt1(\'update a '.$GLOBALS['tableShortName'].'\').\' \'.btl1().\'</h2>\'.CRLF;'.CRLF;
 }
 if($warningFlagOn1){
  $sourceGenere.='  $___warningExist=(isset($_SESSION[PGMK][NAV][BNF][\'warningmessage\']) && count($_SESSION[PGMK][NAV][BNF][\'warningmessage\'])>0)?true:false;'.CRLF;
 }
 $sourceGenere.='  $o1.=displaySessionMessage1(BNF);'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='  $name2='.$GLOBALS['function_include_to_call'].'($_GET[\'id\']);'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $listeChampsCles1.=',$_GET[\''.$v1.'\']';
   }
   $sourceGenere.='  $name2='.$GLOBALS['function_include_to_call'].'('.substr($listeChampsCles1,1).');'.CRLF;
  }else{
   $sourceGenere.='  $name2='.$GLOBALS['function_include_to_call'].'($todo);'.CRLF;
  }
  
 }

 $listeDesChamps1='';
 $listeDesChamps2='';
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    $sourceGenere.='  $xxxFldValues[\'T0_'.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=isset( $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'? $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).': $name2[\'T0_'.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).';'.CRLF;
    $listeDesChamps1.='.(is_null($xxxFldValues[\'T0_'.$v1['nom_champ'].'\'])?\'\':$xxxFldValues[\'T0_'.$v1['nom_champ'].'\'])';
    $listeDesChamps2.=',\''.$v1['nom_champ'].'\'';
   }
  }
 }

 if($warningFlagOn1){
  if($listeDesChamps1!=''){
   $sourceGenere.='  if($___warningExist){'.CRLF;
   $sourceGenere.='   $__valueToShaone='.substr($listeDesChamps1,1).';'.CRLF;
   $sourceGenere.='   $_SESSION[PGMK][\'check\'][\'__checkSumWarning\']=array(\'sha1\'=>sha1($__valueToShaone),\'keys\'=>array('.substr($listeDesChamps2,1).'));'.CRLF;
   $sourceGenere.='  }'.CRLF;
  }
 }

 $autofocus=' autofocus="autofocus" ';
 $sourceGenere.=''.CRLF.CRLF;
 $sourceGenere.='  $o1.=\'<form method="post" enctype="multipart/form-data">\'.CRLF;'.CRLF;
 $sourceGenere.=''.CRLF;
 $sourceGenere.='  $o1.=\' <input type="hidden" value="u" name="a" id="a" />\'.CRLF;'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='  $o1.=\' <input type="hidden" value="\'.$_GET[\'id\'].\'" name="id1" id="id1" />\'.CRLF;'.CRLF;
 }else{
  if(sizeof($GLOBALS['__listeChampsCles'])>0){
   $listeChampsCles1='';
   foreach($GLOBALS['__listeChampsCles'] as $k1=>$v1){
    $sourceGenere.='  $o1.=\' <input type="hidden" value="\'.htmlentities($_GET[\''.$v1.'\'],ENT_COMPAT).\'" name="'.$v1.'_origin1" id="'.$v1.'_origin1" />\'.CRLF;'.CRLF;
   }
  }else{
   $sourceGenere.='  $o1.=\' <input type="hidden" value="\'.$_GET[\'todo\'].\'" name="id1" id="id1" />\'.CRLF;'.CRLF;
  }
  
 }
 $sourceGenere.=CRLF.CRLF;
 
 if($warningFlagOn1){
  $warningForDisplayParams = ',\'readonly\'=> $___warningExist';
  $warningForInput         = '\'.($___warningExist?\' readonly="readonly" \':\'\').\'';
  $warningForButton        = '\'.($___warningExist?\' disabled="disabled" \':\'\').\'';
 }else{
  $warningForDisplayParams='';  
  $warningForInput='';
  $warningForButton='';
 }

 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['parentField'])){
     $sourceGenere.=CRLF;
     $sourceGenere.='  $xDisplayValueFetch = \'\' ;'.CRLF;
     $sourceGenere.='  if('.CRLF;
     $sourceGenere.='   isset($_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\'])&&'.CRLF;
     $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\']==txtsys1(\'text_for_the_select_button\')&&'.CRLF;
     $sourceGenere.='   isset($_SESSION[PGMK][\'choose\'][\'valueBack\'])'.CRLF;
     $sourceGenere.='  ){'.CRLF;
     $sourceGenere.='   if($_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\']==txtsys1(\'text_for_the_select_button\')){'.CRLF;
     $sourceGenere.='    $xxxFldValues[\'T0_'.$v1['nom_champ'].'\']=$_SESSION[PGMK][\'choose\'][\'valueBack\'];'.CRLF;
     $sourceGenere.='   }'.CRLF;
     $sourceGenere.='   unset($_SESSION[PGMK][\'choose\']);'.CRLF;
     $sourceGenere.='  }'.CRLF;
     if($v1['null_possible']=='YES'){ // todo ne pas dupliquer le code dans le cas du null_possible = yes ou no 
      $sourceGenere.='  if($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']!=null){'.CRLF;
      if(substr($v1['parentField']['fld_name_tables'],0,9)==PGMK.'_tbl__'){
       if(PGMK!='td'.'o' && substr(substr($v1['parentField']['fld_name_tables'],9),0,4)==PGMK.'_'){
        $sourceGenere.='   $data_'.$v1['nom_champ'].'=getinc_'.substr($v1['parentField']['fld_name_tables'],9).'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
       }else{
        $sourceGenere.='   $data_'.$v1['nom_champ'].'=getinc_'.PGMK.'_'.substr($v1['parentField']['fld_name_tables'],9).'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;        
       }
      }else if(substr($v1['parentField']['fld_name_tables'],0,8)==PGMK.'_tbl_'){
       if(PGMK!='td'.'o' && substr(substr($v1['parentField']['fld_name_tables'],8),0,4)==PGMK.'_'){
        $sourceGenere.='   $data_'.$v1['nom_champ'].'=getinc_'.substr($v1['parentField']['fld_name_tables'],8).'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
       }else{
        $sourceGenere.='   $data_'.$v1['nom_champ'].'=getinc_'.PGMK.'_'.substr($v1['parentField']['fld_name_tables'],8).'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
       }
      }else{
       if(PGMK!='td'.'o' && substr($v1['parentField']['fld_name_tables'],0,4)==PGMK.'_'){
        $sourceGenere.='   $data_'.$v1['nom_champ'].'=getinc_'.$v1['parentField']['fld_name_tables'].'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
       }else{
        $sourceGenere.='   $data_'.$v1['nom_champ'].'=getinc_'.PGMK.'_'.$v1['parentField']['fld_name_tables'].'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
       }
      }
      foreach($v1['parentField']['fieldList'] as $kpf1 => $vpf1){
       if(isset($vpf1['subtype']) && $vpf1['subtype']=='pictureInDb'){
        $sourceGenere.='  if(strpos(substr($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],0,12),\'PNG\')!==false){'.CRLF;
        $sourceGenere.='   $type_im_'.$vpf1['nom_champ'].'=\'image/png;base64\';'.CRLF;
        $sourceGenere.='  }else if(strpos(substr($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],0,12),\'JFIF\')!==false){'.CRLF;
        $sourceGenere.='   $type_im_'.$vpf1['nom_champ'].'=\'image/jpeg;base64\';'.CRLF;
        $sourceGenere.='  }else if(strpos(substr($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],0,12),\'GIF\')!==false){'.CRLF;
        $sourceGenere.='   $type_im_'.$vpf1['nom_champ'].'=\'image/gif;base64\';'.CRLF;
        $sourceGenere.='  }'.CRLF;
        $sourceGenere.='  $base64_im'.$vpf1['nom_champ'].' = base64_encode($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\']);'.CRLF;
       }
      }
      $sourceGenere.='   $xDisplayValueFetch = \' \' .'.CRLF;
      foreach($v1['parentField']['fieldList'] as $kpf1 => $vpf1){
       if(isset($vpf1['subtype']) && $vpf1['subtype']=='pictureInDb'){
        $sourceGenere.='                         ($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\']!==\'\'?\'<img src="data:\'.$type_im_'.$vpf1['nom_champ'].'.\', \'.$base64_im'.$vpf1['nom_champ'].'.\'" style="max-width:100px;max-height:100px;"/>\':\'\') . \' , \' .'.CRLF;        
       }else if(isset($vpf1['param_name'])){
        if(isset($vpf1['unsetPossible']) && $vpf1['unsetPossible']===true){
         $sourceGenere.='                         displayParam1(\''.$vpf1['param_name'].'\',$data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],array(\'unsetPossible\'=>true)) . \' , \' .'.CRLF;
        }else{
         $sourceGenere.='                         displayParam1(\''.$vpf1['param_name'].'\',$data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],array(\'unsetPossible\'=>false)) . \' , \' .'.CRLF;
        }
       }else{
        $sourceGenere.='                         $data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'] . \' , \' .'.CRLF;
       }
      }
      $sourceGenere.='                         \' (\' . $data_'.$v1['nom_champ'].'[\'T0_'.$v1['parentField']['fld_parent_field_pglnks'].'\'] . \')\' . \'\' ;'.CRLF;
      $sourceGenere.='  }else{'.CRLF;
      $sourceGenere.='   $xDisplayValueFetch = \'\';    '.CRLF;
      $sourceGenere.='  }'.CRLF;
     }else{
      if(substr($v1['parentField']['fld_name_tables'],0,9)==PGMK.'_tbl__'){
       if(PGMK!='td'.'o' && substr(substr($v1['parentField']['fld_name_tables'],9),0,4)==PGMK.'_'){
        $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.substr($v1['parentField']['fld_name_tables'],9).'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
       }else{
        $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.PGMK.'_'.substr($v1['parentField']['fld_name_tables'],9).'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
       }
      }else if(substr($v1['parentField']['fld_name_tables'],0,8)==PGMK.'_tbl_'){
       if(PGMK!='td'.'o' && substr(substr($v1['parentField']['fld_name_tables'],8),0,4)==PGMK.'_'){
        $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.substr($v1['parentField']['fld_name_tables'],8).'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
       }else{
        $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.PGMK.'_'.substr($v1['parentField']['fld_name_tables'],8).'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
       }
      }else{
       if(PGMK!='td'.'o' && substr($v1['parentField']['fld_name_tables'],0,4)==PGMK.'_'){
        $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.$v1['parentField']['fld_name_tables'].'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
       }else{
        $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.PGMK.'_'.$v1['parentField']['fld_name_tables'].'1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
       }
      }
      
      foreach($v1['parentField']['fieldList'] as $kpf1 => $vpf1){
       if(isset($vpf1['subtype']) && $vpf1['subtype']=='pictureInDb'){
        $sourceGenere.='  if(strpos(substr($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],0,12),\'PNG\')!==false){'.CRLF;
        $sourceGenere.='   $type_im_'.$vpf1['nom_champ'].'=\'image/png;base64\';'.CRLF;
        $sourceGenere.='  }else if(strpos(substr($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],0,12),\'JFIF\')!==false){'.CRLF;
        $sourceGenere.='   $type_im_'.$vpf1['nom_champ'].'=\'image/jpeg;base64\';'.CRLF;
        $sourceGenere.='  }else if(strpos(substr($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],0,12),\'GIF\')!==false){'.CRLF;
        $sourceGenere.='   $type_im_'.$vpf1['nom_champ'].'=\'image/gif;base64\';'.CRLF;
        $sourceGenere.='  }'.CRLF;
        $sourceGenere.='  $base64_im'.$vpf1['nom_champ'].' = base64_encode($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\']);'.CRLF;
       }
      }
      
      $sourceGenere.='  $xDisplayValueFetch = \' \' .'.CRLF;
      foreach($v1['parentField']['fieldList'] as $kpf1 => $vpf1){
       if(isset($vpf1['subtype']) && $vpf1['subtype']=='pictureInDb'){
        $sourceGenere.='                         ($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\']!==\'\'?\'<img src="data:\'.$type_im_'.$vpf1['nom_champ'].'.\', \'.$base64_im'.$vpf1['nom_champ'].'.\'" style="max-width:100px;max-height:100px;"/>\':\'\') . \' , \' .'.CRLF;        
       }else if(isset($vpf1['param_name'])){
        if(isset($vpf1['unsetPossible']) && $vpf1['unsetPossible']===true){
         $sourceGenere.='                         displayParam1(\''.$vpf1['param_name'].'\',$data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],array(\'unsetPossible\'=>true)) . \' , \' .'.CRLF;
        }else{
         $sourceGenere.='                         displayParam1(\''.$vpf1['param_name'].'\',$data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],array(\'unsetPossible\'=>false)) . \' , \' .'.CRLF;
        }
       }else{
        $sourceGenere.='                         $data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'] . \' , \' .'.CRLF;
       }
      }
      $sourceGenere.='                        \' (\' . $data_'.$v1['nom_champ'].'[\'T0_'.$v1['parentField']['fld_parent_field_pglnks'].'\'] . \')\' . \'\' ; // todo choose among parent fields '.CRLF;
     }
     $sourceGenere.='   '.CRLF;
     $sourceGenere.='  $classError1=\'\';'.CRLF;
     $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
     $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
     $sourceGenere.='  }'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="yyfdiv1">\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'   <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\'parent_'.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'   <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'    <input type="hidden" value="\'.enti1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']).\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" />\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'     <span id="span__dep_'.$v1['nom_champ'].'" contenteditable="true">\'.$xDisplayValueFetch.\'</span>\';'.CRLF;
     $sourceGenere.='  $o1.=\'    <button '.$warningForButton.' type="button"  onclick="setScrollBackValue1(this)" class=""  name="choose__'.$v1['nom_champ'].'" value="\'. txtsys1(\'text_for_the_select_button\') . \'">\';'.CRLF;
     $sourceGenere.='  $o1.=\'\'   . txtsys1(\'text_for_the_select_button\') . \'\';'.CRLF;
     $sourceGenere.='  $o1.=     \'</button>\'."\r\n";'.CRLF;
     if($v1['parentField']['fld_link_mandatory_pglnks']=='0'){
      $sourceGenere.='  $o1.=\'    <button '.$warningForButton.' type="button" class="yywarning" onclick="razDependant1(\\\'span__dep_'.$v1['nom_champ'].'\\\',\\\''.$v1['nom_champ'].'\\\')">\';'.CRLF;
      $sourceGenere.='  $o1.=\'\'   . txtsys1(\'raz_button\') . \'\';'.CRLF;
      $sourceGenere.='  $o1.=     \'</button>\'."\r\n";'.CRLF;
     }

     $sourceGenere.='  $o1.=\'   </div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  </div>\'.CRLF;'.CRLF.CRLF;
     $count++;
    }else if(isset($v1['param_name'])){
     $sourceGenere.=''.CRLF;
     $sourceGenere.='  $classError1=\'\';'.CRLF;
     $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
     $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
     $sourceGenere.='  }'.CRLF;
     $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
     if(isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
      $sourceGenere.='  $retParam=displayParam2(\''.$v1['param_name'].'\',$xxxFldValues[\'T0_'.$v1['nom_champ'].'\'],\''.$v1['nom_champ'].'\',array(\'set\'=>true'.$warningForDisplayParams.'));'.CRLF;
     }else{
      $sourceGenere.='  $retParam=displayParam2(\''.$v1['param_name'].'\',$xxxFldValues[\'T0_'.$v1['nom_champ'].'\'],\''.$v1['nom_champ'].'\',array(';
      $sourceGenere.='\'unsetPossible\'=>'.(isset($v1['unsetPossible']) && $v1['unsetPossible']==true?'true':'false').',\'dropDown\'=>'.(isset($v1['dropDown']) && $v1['dropDown']==true?'true':'false').''.$warningForDisplayParams.'));'.CRLF;
     }
     $sourceGenere.='  $o1.=$retParam[\'html\'];'.CRLF;
     $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
     $count++;
    }else{

     if(isset($v1['subtype']) && $v1['subtype']=='password'){
      $sourceGenere.='  $classError1=\'\';'.CRLF;
      $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
      $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
      $sourceGenere.='  }'.CRLF;
      $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'   <input '.$warningForInput.' '.$autofocus.' type="password" value="\'.enti1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']).\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" maxlength="'.$v1['fieldSize'].'" style="width:100%;max-width:'.($v1['fieldSize']+2).'em;" />\'.CRLF;'.CRLF;
      $autofocus='';
      $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
     }else if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb'){
      $sourceGenere.='  $classError1=\'\';'.CRLF;
      $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
      $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
      $sourceGenere.='  }'.CRLF;
      $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div style="display:flex;">\'.CRLF;'.CRLF;
      $sourceGenere.='  $im = base64_encode($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']);'.CRLF;
      $sourceGenere.='  if(strpos(substr($xxxFldValues[\'T0_'.$v1['nom_champ'].'\'],0,12),\'PNG\')!==false){'.CRLF;
      $sourceGenere.='   $o1.=\'<img src="data:image/png;base64, \'.$im.\'" style="max-width:100px;max-height:100px;"/>\'; // pictureInDb   '.CRLF;
      $sourceGenere.='   $o1.=txt1(\'reset picture ?\').\' <input '.$warningForInput.' type="checkbox" name="raz_'.$v1['nom_champ'].'" />\';'.CRLF;
      $sourceGenere.='  }else if(strpos(substr($xxxFldValues[\'T0_'.$v1['nom_champ'].'\'],0,12),\'JFIF\')!==false){'.CRLF;
      $sourceGenere.='   $o1.=\'<img src="data:image/jpeg;base64, \'.$im.\'" style="max-width:100px;max-height:100px;"/>\'; // pictureInDb   '.CRLF;
      $sourceGenere.='   $o1.=txt1(\'reset picture ?\').\' <input '.$warningForInput.' type="checkbox" name="raz_'.$v1['nom_champ'].'" />\';'.CRLF;
      $sourceGenere.='  }else if(strpos(substr($xxxFldValues[\'T0_'.$v1['nom_champ'].'\'],0,12),\'GIF\')!==false){'.CRLF;
      $sourceGenere.='   $o1.=\'<img src="data:image/gif;base64, \'.$im.\'" style="max-width:100px;max-height:100px;"/>\'; // pictureInDb   '.CRLF;
      $sourceGenere.='   $o1.=txt1(\'reset picture ?\').\' <input '.$warningForInput.' type="checkbox" name="raz_'.$v1['nom_champ'].'" />\';'.CRLF;
      $sourceGenere.='  }'.CRLF;
      $sourceGenere.='  $o1.=\'  <input '.$warningForInput.' type="file" id="'.$v1['nom_champ'].'" name="'.$v1['nom_champ'].'">\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
      
     }else if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){
      $sourceGenere.='  $classError1=\'\';'.CRLF;
      $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
      $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
      $sourceGenere.='  }'.CRLF;
      $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div style="display:flex;">\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'   <input type="hidden" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'"   value="\'.enti1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']).\'" />\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'   <div id="div__display_color_'.$v1['nom_champ'].'" style="display:flex;">\'.CRLF;'.CRLF;
      $sourceGenere.='  if($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']!=\'\'){  // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='   $val=json_decode($xxxFldValues[\'T0_'.$v1['nom_champ'].'\'],true);'.CRLF;
      $sourceGenere.='   $o1.=\'    <div style="width:35px;height:35px;border:1px #eee inset;background-color:#\'.$val[\'hexValue\'].\'"></div>\';'.CRLF;
      $sourceGenere.='   $o1.=\'    <div>\'.$val[\'hexValue\'].\'\';'.CRLF;
      $sourceGenere.='   if(isset($val[\'webName\']) && $val[\'webName\']!=\'\'){'.CRLF;
      $sourceGenere.='    $o1.=\',\'.$val[\'webName\'].\'\';'.CRLF;
      $sourceGenere.='   }'.CRLF;
      $sourceGenere.='   if(isset($val[\'pantoneName\']) && $val[\'pantoneName\']!=\'\'){'.CRLF;
      $sourceGenere.='    $o1.=\', pantone:\'.$val[\'pantoneName\'].\'\';'.CRLF;
      $sourceGenere.='   }'.CRLF;
      $sourceGenere.='   $o1.=\'    </div>\';'.CRLF;
      $sourceGenere.='  }'.CRLF;
      $sourceGenere.='  $o1.=\'   </div>\';'.CRLF;
      $sourceGenere.='  $o1.=\'   <div>\';'.CRLF;
      $sourceGenere.='  $o1.=\'    <button '.$warningForButton.' type="button" id="button_color_'.$v1['nom_champ'].'" onclick="javascript:setColor1(\\\''.$v1['nom_champ'].'\\\',\\\'button_color_'.$v1['nom_champ'].'\\\',\\\'div__display_color_'.$v1['nom_champ'].'\\\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">\';'.CRLF;
      $sourceGenere.='  $o1.=txtsys1(\'update color\');'.CRLF;
      $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
      $sourceGenere.='  $o1.=\'   </div>\';'.CRLF;
      $sourceGenere.='     '.CRLF;
      $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;

     }else if(strpos(strtolower($v1['type_champ']),'text')     !==false || $v1['type_champ']=='geometry' ){
      $sourceGenere.='  $classError1=\'\';'.CRLF;
      $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
      $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
      $sourceGenere.='  }'.CRLF;
      $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'   <textarea '.$warningForInput.' '.$autofocus.' name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'"  rows="5" >\'.htmlentities($xxxFldValues[\'T0_'.$v1['nom_champ'].'\'],ENT_COMPAT).\'</textarea>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
      $autofocus='';
     }else{
      if($v1['type_champ']=='datetime'){

       $sourceGenere.='  $classError1=\'\';'.CRLF;
       $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
       $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
       $sourceGenere.='  }'.CRLF;
       $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
       if(isset($v1['__filter_is_date']) && $v1['__filter_is_date']==true){
        $sourceGenere.='  $o1.=\'    <input '.$warningForInput.' type="text" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']).\'" size="19" maxlength="19" />\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
       }else{
        $sourceGenere.='  $o1.=\'    <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']).\'" />\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'    <button '.$warningForButton.' type="button" style="padding:0px!important;font-size:0.8em;" id="button_datetime_'.$v1['nom_champ'].'" onclick="javascript:setDateTime1(\\\''.$v1['nom_champ'].'\\\',\\\'button_datetime_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0,\\\'\\\')" >\';'.CRLF;
        $sourceGenere.='  $o1.=($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'\'?txtsys1(\'datetime null\'):($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'NULL\'?txtsys1(\'datetime null\'):($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'NOT NULL\'?txtsys1(\'datetime not null\'):$xxxFldValues[\'T0_'.$v1['nom_champ'].'\'])));'.CRLF;
        $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
        $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
       }


      }else if($v1['type_champ']=='time'){

       $sourceGenere.='  $classError1=\'\';'.CRLF;
       $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
       $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
       $sourceGenere.='  }'.CRLF;
       $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
       $timeOption=0;
       if(isset($v1['timeOption']) &&  $v1['timeOption']!='' ){
        $timeOption=$v1['timeOption'];
       }
       if(isset($v1['__filter_is_date']) && $v1['__filter_is_date']==true){
        $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'    <input '.$warningForInput.' type="text" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']).\'" size="8" maxlength="8" />\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
       }else{
        $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'    <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']).\'" />\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'    <button '.$warningForButton.' type="button" id="button_time_'.$v1['nom_champ'].'" style="border-style:outset;font-size:0.8em;padding:5px;width:auto;"  \'.($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'00:00:00\'?\' class="yysuccess" \':($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']!=\'\'?\' class="yyedit" \':\'\')).\' \';'.CRLF;
        $sourceGenere.='  $o1.=\' onclick="javascript:setTime1(\\\''.$v1['nom_champ'].'\\\',\\\'button_time_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0,\\\'\\\','.$timeOption.')">\';'.CRLF;
        $sourceGenere.='  $o1.=($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'\'?txtsys1(\'time null\'):($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'NULL\'?txtsys1(\'time null\'):($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'NOT NULL\'?txtsys1(\'time not null\'):';
        if(isset($v1['timeOption']) && ( $v1['timeOption']==1 || $v1['timeOption']==3 || $v1['timeOption']==5 || $v1['timeOption']==7)){
         $sourceGenere.='substr($xxxFldValues[\'T0_'.$v1['nom_champ'].'\'],0,5)';
        }else{
         $sourceGenere.='$xxxFldValues[\'T0_'.$v1['nom_champ'].'\']';
        }
        $sourceGenere.=')));'.CRLF;
        $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
        $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
       }

      }else if($v1['type_champ']=='date'){
       if(!((isset($v1['dtupd']) && $v1['dtupd']==true) || (isset($v1['dtcrt']) && $v1['dtcrt']==true))){
       
        $sourceGenere.='  $classError1=\'\';'.CRLF;
        $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
        $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
        $sourceGenere.='  }'.CRLF;
        $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
        if(isset($v1['__filter_is_date']) && $v1['__filter_is_date']==true){
         $sourceGenere.='  if($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'1000-01-01\') $xxxFldValues[\'T0_'.$v1['nom_champ'].'\']=\'\';'.CRLF;
         $sourceGenere.='  $o1.=\'    <input '.$warningForInput.' type="text" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']).\'" size="10" max-length="10" />\'.CRLF;'.CRLF;
         $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
         $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
        }else{
         $sourceGenere.='  if($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'1000-01-01\') $xxxFldValues[\'T0_'.$v1['nom_champ'].'\']=\'\';'.CRLF;
         $sourceGenere.='  $o1.=\'    <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']).\'" />\'.CRLF;'.CRLF;
         $sourceGenere.='  $o1.=\'    <button '.$warningForButton.' type="button" style="padding:0px!important;font-size:0.8em;" id="button_date_'.$v1['nom_champ'].'" onclick="javascript:setDate1(\\\''.$v1['nom_champ'].'\\\',\\\'button_date_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0)">\';'.CRLF;
         $sourceGenere.='  $o1.=(($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'1000-01-01\' || $xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'\' )?txtsys1(\'date null\'):($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'NULL\'?txtsys1(\'date null\'):($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'NOT NULL\'?txtsys1(\'date not null\'):$xxxFldValues[\'T0_'.$v1['nom_champ'].'\'])));'.CRLF;
         $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
         $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
         $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
        }
       }


      }else if(true===$v1['isNumericField']){
       
       if( !( ( isset($v1['isUser']) && $v1['isUser']==true ) || ( isset($v1['isGroup']) && $v1['isGroup']==true )  )){
        $sourceGenere.='  $classError1=\'\';'.CRLF;
        $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
        $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
        $sourceGenere.='  }'.CRLF;
        $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'   <input '.$warningForInput.' '.$autofocus.' type="text" value="\'.(is_numeric($xxxFldValues[\'T0_'.$v1['nom_champ'].'\'])?number_format($xxxFldValues[\'T0_'.$v1['nom_champ'].'\'],'.$v1['decimals'].',\'.\',\' \'):enti1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\'])).\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" maxlength="12" style="width:100;max-width:12em;" />\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
        $autofocus='';
       }
      }else{
       if(substr($v1['type_champ'],0,5)=='enum('){
        $sourceGenere.='  $classError1=\'\';'.CRLF;
        $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
        $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
        $sourceGenere.='  }'.CRLF;
        $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
        $lstEnum='$tempevalenum=array('.str_replace('\'\'','\\\'',substr($v1['type_champ'],5,-1).');');
        eval($lstEnum);
        if(true){
         $sourceGenere.='  $o1.=\'    <select name="'.$v1['nom_champ'].'"  id="'.$v1['nom_champ'].'" >\'.CRLF;'.CRLF;
         $countenum1=0;
         foreach($tempevalenum as $keval1 => $veval1){
          if($countenum1==0){
           $sourceGenere.='  $o1.=\'     <option value="\'.'.htmlentities(var_export($veval1,true)).'.\'"  '.($countenum1==0?'        \'.($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']==\'\'||$xxxFldValues[\'T0_'.$v1['nom_champ'].'\']=='.var_export($veval1,true).'?\' selected="selected" \':\'\').\'       ':'').' >\'.'.var_export($veval1,true).'.\'</option>\'.CRLF;'.CRLF;       
          }else{
           $sourceGenere.='  $o1.=\'     <option value="\'.'.htmlentities(var_export($veval1,true)).'.\'"  '.('        \'.($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']=='.var_export($veval1,true).'?\' selected="selected" \':\'\').\'       ').' >\'.'.var_export($veval1,true).'.\'</option>\'.CRLF;'.CRLF;       
          }
          $countenum1++;
         }
         $sourceGenere.='  $o1.=\'    </select>\';'.CRLF;
        }else{
         $sourceGenere.='// todo for enum field'.CRLF;
        }
        $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
        
       }else if($v1['type_champ']=='timestamp'){
       }else if(substr($v1['type_champ'],0,4)=='set('){
        $lstEnum='$tempevalenum=array('.str_replace('\'\'','\\\'',substr($v1['type_champ'],4,-1).');');
        eval($lstEnum);
        $sourceGenere.='  $classError1=\'\';'.CRLF;
        $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
        $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
        $sourceGenere.='  }'.CRLF;
        $sourceGenere.='  $setValuesFor'.$v1['nom_champ'].'=' . var_export( $tempevalenum  , true ) . ';'.CRLF;
        $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $retParam=displaySet1($setValuesFor'.$v1['nom_champ'].',$xxxFldValues[\'T0_'.$v1['nom_champ'].'\'],\''.$v1['nom_champ'].'\');'.CRLF;
        $sourceGenere.='  $o1.=$retParam[\'html\'];'.CRLF;
        $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
       }else{       
        if(!( ( isset($v1['isUser']) && $v1['isUser']==true ) || (isset($v1['isGroup']) && $v1['isGroup']==true) ) ){
         $sourceGenere.='  $classError1=\'\';'.CRLF;
         $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
         $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
         $sourceGenere.='  }'.CRLF;
         $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
         $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
         $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
         $sourceGenere.='  $o1.=\'   <input '.$warningForInput.' '.$autofocus.' type="text" value="\'.enti1($xxxFldValues[\'T0_'.$v1['nom_champ'].'\']).\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" maxlength="'.$v1['fieldSize'].'" style="width:100%;max-width:'.($v1['fieldSize']>10?round($v1['fieldSize']/2,0):($v1['fieldSize']<=3?3:$v1['fieldSize'])).'em;" />\'.CRLF;'.CRLF;
         $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
         $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
         $autofocus='';
        }
       }
      }
     }
     $count++;
    }
   }
  }
 }

 $sourceGenere.=''.CRLF;
 $sourceGenere.='  $o1.=\'<div class="yyfdiv1">\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'  <div class="yyfinp1"><div>\'.CRLF;'.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if($v1['cntupd']){
   $sourceGenere.='  $o1.=\'   <input type="hidden" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" value="\'.$name2[\'T0_'.$v1['nom_champ'].'\'].\'" />\'.CRLF;'.CRLF;
  }
 }
 if($warningFlagOn1){
  $sourceGenere.='  if($___warningExist){'.CRLF;
  $sourceGenere.='   $o1.=\'   <input type="hidden" name="__bypass_warning" id="__bypass_warning" value="1" />\'.CRLF;'.CRLF;
  $sourceGenere.='   $o1.=\'   <button type="submit" class="yyedit" name="correct_the_warning_values">\'.txtsys1(\'correct_the_warning_values\').\'</button>\'.CRLF;'.CRLF; 
  $sourceGenere.='   $o1.=\'   <button type="submit" class="yywarning">\'.txtsys1(\'save_the_modification\').\'</button>\'.CRLF;'.CRLF;
  $sourceGenere.='   $o1.=\'   <button type="submit" class="yywarning" name="save_the_modification_and_back_to_list">\'.txtsys1(\'save_the_modification_and_back_to_list\').\'</button>\'.CRLF;'.CRLF;
  $sourceGenere.='  }else{'.CRLF;
  $sourceGenere.='   $o1.=\'   <button type="submit" class="">\'.txtsys1(\'save_the_modification\').\'</button>\'.CRLF;'.CRLF;
  $sourceGenere.='   $o1.=\'   <button type="submit" class="" name="save_the_modification_and_back_to_list">\'.txtsys1(\'save_the_modification_and_back_to_list\').\'</button>\'.CRLF;'.CRLF;
  $sourceGenere.='  }'.CRLF;
 }else{
  $sourceGenere.='  $o1.=\'   <button type="submit" class="">\'.txtsys1(\'save_the_modification\').\'</button>\'.CRLF;'.CRLF;
  $sourceGenere.='  $o1.=\'   <button type="submit" class="" name="save_the_modification_and_back_to_list">\'.txtsys1(\'save_the_modification_and_back_to_list\').\'</button>\'.CRLF;'.CRLF;
 }
 $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'</div>\'.CRLF;'.CRLF;
 $sourceGenere.=''.CRLF;
 $sourceGenere.='  $o1.=\'</form>\'.CRLF;'.CRLF;
 $sourceGenere.=''.CRLF;

 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= GET VIEW =========================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' }else if(isset($_GET[\'a\'])&&$_GET[\'a\']==\'v\'&&isset($_GET[\'id\'])&&is_numeric($_GET[\'id\'])){ // view action'.CRLF;
 $sourceGenere.='  // if you vant to do something here, go !'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= GET CREATE ========================================================================'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' }else if(isset($_GET[\'a\'])&&$_GET[\'a\']==\'c\'){ // create action'.CRLF;
 $sourceGenere.=' '.CRLF;
 $sourceGenere.='  $o1.=\'<h2>\'.txt1(\'Add a new '.$GLOBALS['tableShortName'].'\'). \' \'.btl1().\'</h2>\'.CRLF;'.CRLF;
 if($warningFlagOn1){
  $sourceGenere.='  $___warningExist=(isset($_SESSION[PGMK][NAV][BNF][\'warningmessage\']) && count($_SESSION[PGMK][NAV][BNF][\'warningmessage\'])>0)?true:false;'.CRLF;
 }
 
 
 $sourceGenere.='  $o1.=displaySessionMessage1(BNF);'.CRLF;
 $sourceGenere.='  $o1.=\'<form method="post"  enctype="multipart/form-data" class="form1">\'.CRLF;'.CRLF;
 $sourceGenere.=' '.CRLF;
 $autofocus=' autofocus="autofocus" ';
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!($v1['tsupd']||$v1['tscrt']||$v1['cntupd'] )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){

    if(isset($v1['parentField'])){

     $sourceGenere.='  $'.$v1['nom_champ'].'=isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:null;'.CRLF;
     $sourceGenere.='  if('.CRLF;
     $sourceGenere.='   isset($_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\'])&&'.CRLF;
     $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\']==txtsys1(\'text_for_the_select_button\')&&'.CRLF;
     $sourceGenere.='   isset($_SESSION[PGMK][\'choose\'][\'valueBack\'])'.CRLF;
     $sourceGenere.='  ){'.CRLF;
     $sourceGenere.='   if($_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\']==txtsys1(\'text_for_the_select_button\')){'.CRLF;
     $sourceGenere.='    $'.$v1['nom_champ'].'=$_SESSION[PGMK][\'choose\'][\'valueBack\'];'.CRLF;
     $sourceGenere.='   }'.CRLF;
     $sourceGenere.='   unset($_SESSION[PGMK][\'choose\']);'.CRLF;
     $sourceGenere.='  }'.CRLF;
     $sourceGenere.='  if($'.$v1['nom_champ'].'!=null){'.CRLF;
     if(substr($v1['parentField']['fld_name_tables'],0,9)==PGMK.'_tbl__'){
      if(PGMK!='td'.'o' && substr(substr($v1['parentField']['fld_name_tables'],9),0,4)==PGMK.'_'){
       $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.substr($v1['parentField']['fld_name_tables'],9).'1($'.$v1['nom_champ'].');'.CRLF;
      }else{
       $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.PGMK.'_'.substr($v1['parentField']['fld_name_tables'],9).'1($'.$v1['nom_champ'].');'.CRLF;
      }
     }else if(substr($v1['parentField']['fld_name_tables'],0,8)==PGMK.'_tbl_'){
      if(PGMK!='td'.'o' && substr(substr($v1['parentField']['fld_name_tables'],8),0,4)==PGMK.'_'){
       $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.substr($v1['parentField']['fld_name_tables'],8).'1($'.$v1['nom_champ'].');'.CRLF;
      }else{
       $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.PGMK.'_'.substr($v1['parentField']['fld_name_tables'],8).'1($'.$v1['nom_champ'].');'.CRLF;
      }
     }else{
      if(PGMK!='td'.'o' && substr($v1['parentField']['fld_name_tables'],0,4)==PGMK.'_'){
       $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.$v1['parentField']['fld_name_tables'].'1($'.$v1['nom_champ'].');'.CRLF;
      }else{
       $sourceGenere.='  $data_'.$v1['nom_champ'].'=getinc_'.PGMK.'_'.$v1['parentField']['fld_name_tables'].'1($'.$v1['nom_champ'].');'.CRLF;
      }
     }
     
     foreach($v1['parentField']['fieldList'] as $kpf1 => $vpf1){
      if(isset($vpf1['subtype']) && $vpf1['subtype']=='pictureInDb'){
       $sourceGenere.='  if(strpos(substr($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],0,12),\'PNG\')!==false){'.CRLF;
       $sourceGenere.='   $type_im_'.$vpf1['nom_champ'].'=\'image/png;base64\';'.CRLF;
       $sourceGenere.='  }else if(strpos(substr($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],0,12),\'JFIF\')!==false){'.CRLF;
       $sourceGenere.='   $type_im_'.$vpf1['nom_champ'].'=\'image/jpeg;base64\';'.CRLF;
       $sourceGenere.='  }else if(strpos(substr($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],0,12),\'GIF\')!==false){'.CRLF;
       $sourceGenere.='   $type_im_'.$vpf1['nom_champ'].'=\'image/gif;base64\';'.CRLF;
       $sourceGenere.='  }'.CRLF;
       $sourceGenere.='  $base64_im'.$vpf1['nom_champ'].' = base64_encode($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\']);'.CRLF;
      }
     }
     $sourceGenere.='   $xDisplayValueFetch = \' \' .'.CRLF;
     foreach($v1['parentField']['fieldList'] as $kpf1 => $vpf1){
      if(isset($vpf1['subtype']) && $vpf1['subtype']=='pictureInDb'){
       $sourceGenere.='                         ($data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\']!==\'\'?\'<img src="data:\'.$type_im_'.$vpf1['nom_champ'].'.\', \'.$base64_im'.$vpf1['nom_champ'].'.\'" style="max-width:100px;max-height:100px;"/>\':\'\') . \' , \' .'.CRLF;        
      }else if(isset($vpf1['param_name'])){
       if(isset($vpf1['unsetPossible']) && $vpf1['unsetPossible']===true){
        $sourceGenere.='                         displayParam1(\''.$vpf1['param_name'].'\',$data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],array(\'unsetPossible\'=>true)) . \' , \' .'.CRLF;
       }else{
        $sourceGenere.='                         displayParam1(\''.$vpf1['param_name'].'\',$data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'],array(\'unsetPossible\'=>false)) . \' , \' .'.CRLF;
       }
      }else{
       $sourceGenere.='                         $data_'.$v1['nom_champ'].'[\'T0_'.$vpf1['nom_champ'].'\'] . \' , \' .'.CRLF;      
      }
     }
     $sourceGenere.='                         \' (\' . $data_'.$v1['nom_champ'].'[\'T0_'.$v1['parentField']['fld_parent_field_pglnks'].'\'] . \')\' . \'\' ;'.CRLF;
     $sourceGenere.='  }else{'.CRLF;
     $sourceGenere.='   $xDisplayValueFetch = \'\';    '.CRLF;
     $sourceGenere.='  }'.CRLF;
     $sourceGenere.='  $classError1=\'\';'.CRLF;
     $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
     $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
     $sourceGenere.='  }'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="yyfdiv1">\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'   <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\'parent_'.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'   <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'    <input type="hidden" value="\'.enti1($'.$v1['nom_champ'].').\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" />\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'     <span id="span__dep_'.$v1['nom_champ'].'" contenteditable="true">\'.$xDisplayValueFetch.\'</span>\';'.CRLF;
     $sourceGenere.='  $o1.=\'    <button type="button" name="choose__'.$v1['nom_champ'].'" onclick="setScrollBackValue1(this)" class="" value="\'. txtsys1(\'text_for_the_select_button\') . \'">\';'.CRLF;
     $sourceGenere.='  $o1.=\'\'   . txtsys1(\'text_for_the_select_button\') . \'\';'.CRLF;
     $sourceGenere.='  $o1.=     \'</button>\'."\r\n";'.CRLF;
     if($v1['parentField']['fld_link_mandatory_pglnks']=='0'){
      $sourceGenere.='  $o1.=\'    <button type="button" class="yywarning" onclick="razDependant1(\\\'span__dep_'.$v1['nom_champ'].'\\\',\\\''.$v1['nom_champ'].'\\\')">\';'.CRLF;
      $sourceGenere.='  $o1.=\'\'   . txtsys1(\'raz_button\') . \'\';'.CRLF;
      $sourceGenere.='  $o1.=     \'</button>\'."\r\n";'.CRLF;
     }
     $sourceGenere.='  $o1.=\'   </div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  </div>\'.CRLF;'.CRLF.CRLF;
    }else if(isset($v1['param_name'])){
     $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
     $sourceGenere.='  $classError1=\'\';'.CRLF;
     $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
     $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
     $sourceGenere.='  }'.CRLF;
     $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
     if(isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
      $sourceGenere.='  $retParam=displayParam2(\''.$v1['param_name'].'\',$'.$v1['nom_champ'].',\''.$v1['nom_champ'].'\',array(\'set\'=>true));'.CRLF;
     }else{
      $sourceGenere.='  $retParam=displayParam2(\''.$v1['param_name'].'\',$'.$v1['nom_champ'].',\''.$v1['nom_champ'].'\',';
      $sourceGenere.='array(\'unsetPossible\'=>'.(isset($v1['unsetPossible']) && $v1['unsetPossible']==true?'true':'false').',';
      $sourceGenere.='\'dropDown\'=>'.(isset($v1['dropDown']) && $v1['dropDown']==true?'true':'false').'));'.CRLF;
     }
     $sourceGenere.='  $o1.=$retParam[\'html\'];'.CRLF;
     $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
     $count++;
    }else{
     $sourceGenere.=''.CRLF;
     if(isset($v1['subtype']) && $v1['subtype']=='pictureInDb'){
      $count++;
     }else if(strpos(strtolower($v1['type_champ']),'text')     !==false  || $v1['type_champ']=='geometry' ){
      $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
      $sourceGenere.='  $classError1=\'\';'.CRLF;
      $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
      $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
      $sourceGenere.='  }'.CRLF;
      $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'   <textarea '.$autofocus.' name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'"  rows="5" >\'.htmlentities($'.$v1['nom_champ'].',ENT_COMPAT).\'</textarea>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
      $autofocus='';

      $count++;
     }else{
      if($v1['type_champ']=='datetime'){
       if($v1['null_possible']=='YES'){
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
       }else{
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:date(\'Y-m-d H:i:s\');'.CRLF;
       }
      }else if($v1['type_champ']=='time'){
       if($v1['null_possible']=='YES'){
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
       }else{
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:date(\'H:i:s\');'.CRLF;
       }
      }else if($v1['type_champ']=='date'){
       if(!((isset($v1['dtupd']) && $v1['dtupd']==true) || (isset($v1['dtcrt']) && $v1['dtcrt']==true))){
        if($v1['null_possible']=='YES'){
         $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
        }else{
         $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:date(\'Y-m-d\');'.CRLF;
        }
       }
      }else if(true===$v1['isNumericField']){
       if(!( (isset($v1['isUser']) && $v1['isUser']==true) || ( isset($v1['isGroup']) && $v1['isGroup']==true ) )){
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:0;'.CRLF;
       }
      }else{
       if($v1['type_champ']!=='timestamp'){
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
       }
      }
      if(isset($v1['subtype']) && $v1['subtype']=='password'){
       $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:date(\'Y-m-d H:i:s\');'.CRLF;
       $sourceGenere.='  $classError1=\'\';'.CRLF;
       $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
       $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
       $sourceGenere.='  }'.CRLF;
       $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'   <input '.$autofocus.' type="password" value="\'.enti1($'.$v1['nom_champ'].').\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" maxlength="'.$v1['fieldSize'].'" style="width:100%;max-width:'.($v1['fieldSize']+2).'em;" />\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
       $autofocus='';

      }else if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){

       $sourceGenere.='  $classError1=\'\';'.CRLF;
       $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
       $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
       $sourceGenere.='  }'.CRLF;
       $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div style="display:flex;">\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'   <input type="hidden" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'"   value="\'.enti1($'.$v1['nom_champ'].').\'" />\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'   <div id="div__display_color_'.$v1['nom_champ'].'" style="display:flex;">\'.CRLF;'.CRLF;
       $sourceGenere.='  if($'.$v1['nom_champ'].'!=\'\'){  // '.$v1['nom_champ'].''.CRLF;
       $sourceGenere.='   $val=json_decode($'.$v1['nom_champ'].',true);'.CRLF;
       $sourceGenere.='   $o1.=\'    <div style="width:35px;height:35px;border:1px #eee inset;background-color:#\'.$val[\'hexValue\'].\'"></div>\'; // '.$v1['nom_champ'].''.CRLF;
       $sourceGenere.='   $o1.=\'    <div>\'.$val[\'hexValue\'].\'\';'.CRLF;
       $sourceGenere.='   if(isset($val[\'webName\']) && $val[\'webName\']!=\'\'){'.CRLF;
       $sourceGenere.='    $o1.=\',\'.$val[\'webName\'].\'\';'.CRLF;
       $sourceGenere.='   }'.CRLF;
       $sourceGenere.='   if(isset($val[\'pantoneName\']) && $val[\'pantoneName\']!=\'\'){'.CRLF;
       $sourceGenere.='    $o1.=\', pantone:\'.$val[\'pantoneName\'].\'\';'.CRLF;
       $sourceGenere.='   }'.CRLF;
       $sourceGenere.='   $o1.=\'    </div>\';'.CRLF;
       $sourceGenere.='  }'.CRLF;
       $sourceGenere.='  $o1.=\'   </div>\';'.CRLF;
       $sourceGenere.='  $o1.=\'   <div>\';'.CRLF;
       $sourceGenere.='  $o1.=\'    <button type="button" id="button_color_'.$v1['nom_champ'].'" onclick="javascript:setColor1(\\\''.$v1['nom_champ'].'\\\',\\\'button_color_'.$v1['nom_champ'].'\\\',\\\'div__display_color_'.$v1['nom_champ'].'\\\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">\';'.CRLF;
       $sourceGenere.='  $o1.=txtsys1(\'update color\');'.CRLF;
       $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
       $sourceGenere.='  $o1.=\'   </div>\';'.CRLF;
       $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;


      }else if($v1['type_champ']=='datetime'){
       $sourceGenere.='  $classError1=\'\';'.CRLF;
       $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
       $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
       $sourceGenere.='  }'.CRLF;
       $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'   <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($'.$v1['nom_champ'].').\'" />\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'   <button type="button" style="padding:0px!important;font-size:0.8em;"  id="button_datetime_'.$v1['nom_champ'].'" onclick="javascript:setDateTime1(\\\''.$v1['nom_champ'].'\\\',\\\'button_datetime_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0,0,\\\'\\\')" >\';'.CRLF;
       $sourceGenere.='  $o1.=($'.$v1['nom_champ'].'==\'\'?txtsys1(\'datetime null\'):($'.$v1['nom_champ'].'==\'NULL\'?txtsys1(\'datetime null\'):($'.$v1['nom_champ'].'==\'NOT NULL\'?txtsys1(\'datetime not null\'):$'.$v1['nom_champ'].')));'.CRLF;
       $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
       $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
      }else if($v1['type_champ']=='time'){
       $timeOption=0;
       if(isset($v1['timeOption']) &&  $v1['timeOption']!='' ){
        $timeOption=$v1['timeOption'];
       }
       $sourceGenere.='  $classError1=\'\';'.CRLF;
       $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
       $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
       $sourceGenere.='  }'.CRLF;
       $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'    <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($'.$v1['nom_champ'].').\'" />\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'    <button type="button" style="padding:0px!important;font-size:0.8em;" id="button_time_'.$v1['nom_champ'].'" \';'.CRLF;
       $sourceGenere.='  $o1.=\' onclick="javascript:setTime1(\\\''.$v1['nom_champ'].'\\\',\\\'button_time_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0,\\\'\\\','.$timeOption.')" >\';'.CRLF;
       $sourceGenere.='  $o1.=($'.$v1['nom_champ'].'==\'\'?txtsys1(\'time null\'):($'.$v1['nom_champ'].'==\'NULL\'?txtsys1(\'time null\'):($'.$v1['nom_champ'].'==\'NOT NULL\'?txtsys1(\'time not null\'):';
       if(isset($v1['timeOption']) && ( $v1['timeOption']==1 || $v1['timeOption']==3 || $v1['timeOption']==5 || $v1['timeOption']==7)){
        $sourceGenere.='substr($'.$v1['nom_champ'].',0,5)';
       }else{
        $sourceGenere.='$'.$v1['nom_champ'].'';
       }
       $sourceGenere.=')));'.CRLF;
       $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
       $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
      }else if($v1['type_champ']=='date'){
       if(!((isset($v1['dtupd']) && $v1['dtupd']==true) || (isset($v1['dtcrt']) && $v1['dtcrt']==true))){
        $sourceGenere.='  $classError1=\'\';'.CRLF;
        $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
        $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
        $sourceGenere.='  }'.CRLF;
        $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
        $sourceGenere.='  if($'.$v1['nom_champ'].'==\'1000-01-01\') $'.$v1['nom_champ'].'=\'\';'.CRLF;
        $sourceGenere.='  $o1.=\'    <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($'.$v1['nom_champ'].').\'" />\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'    <button type="button" style="padding:0px!important;font-size:0.8em;" id="button_date_'.$v1['nom_champ'].'" onclick="javascript:setDate1(\\\''.$v1['nom_champ'].'\\\',\\\'button_date_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0)" >\';'.CRLF;
        $sourceGenere.='  $o1.=(($'.$v1['nom_champ'].'==\'1000-01-01\' || $'.$v1['nom_champ'].'==\'\' )?txtsys1(\'date null\'):($'.$v1['nom_champ'].'==\'NULL\'?txtsys1(\'date null\'):($'.$v1['nom_champ'].'==\'NOT NULL\'?txtsys1(\'date not null\'):$'.$v1['nom_champ'].')));'.CRLF;
        $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
        $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
       }
      }else if(true===$v1['isNumericField']){
       if(!( (isset($v1['isUser']) && $v1['isUser']==true) | ( isset($v1['isGroup']) && $v1['isGroup']==true ) ) ){
        $sourceGenere.='  $classError1=\'\';'.CRLF;
        $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
        $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
        $sourceGenere.='  }'.CRLF;
        $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'   <input '.$autofocus.' type="text" value="\'.(is_numeric($'.$v1['nom_champ'].')?number_format($'.$v1['nom_champ'].','.$v1['decimals'].',\'.\',\' \'):enti1($'.$v1['nom_champ'].')).\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" maxlength="12" />\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
        $autofocus='';
       }
      }else{
       
       if(substr($v1['type_champ'],0,5)=='enum('){
        $sourceGenere.='  $classError1=\'\';'.CRLF;
        $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
        $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
        $sourceGenere.='  }'.CRLF;
        $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
        $lstEnum='$tempevalenum=array('.str_replace('\'\'','\\\'',substr($v1['type_champ'],5,-1).');');
        eval($lstEnum);
        if(true){
         $sourceGenere.='  $o1.=\'    <select name="'.$v1['nom_champ'].'"  id="'.$v1['nom_champ'].'" >\'.CRLF;'.CRLF;
         $countenum1=0;
         foreach($tempevalenum as $keval1 => $veval1){
          if($countenum1==0){
           $sourceGenere.='  $o1.=\'     <option value="\'.'.htmlentities(var_export($veval1,true)).'.\'"  '.('        \'.($'.$v1['nom_champ'].'==\'\'||$'.$v1['nom_champ'].'=='.var_export($veval1,true).'?\' selected="selected" \':\'\').\'       ').' >\'.'.var_export($veval1,true).'.\'</option>\'.CRLF;'.CRLF;       
          }else{
           $sourceGenere.='  $o1.=\'     <option value="\'.'.htmlentities(var_export($veval1,true)).'.\'"  '.('        \'.($'.$v1['nom_champ'].'=='.var_export($veval1,true).'?\' selected="selected" \':\'\').\'       ').' >\'.'.var_export($veval1,true).'.\'</option>\'.CRLF;'.CRLF;       
          }
          $countenum1++;
         }
         $sourceGenere.='  $o1.=\'    </select>\';'.CRLF;
        }else{
         $sourceGenere.='// todo for enum field'.CRLF;
        }
        $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
       }else if($v1['type_champ']=='timestamp'){
       }else{
        $sourceGenere.='  $classError1=\'\';'.CRLF;
        $sourceGenere.='  if(isset($_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\']) && $_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'highlight\']==true){'.CRLF;
        $sourceGenere.='   $classError1=$_SESSION[PGMK][NAV][BNF][\'highlight\'][\''.$v1['nom_champ'].'\'][\'class\'];'.CRLF;
        $sourceGenere.='  }'.CRLF;
        $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyflab1 \'.$classError1.\'"><div style="word-break:break-word;">\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  <div class="yyfinp1 \'.$classError1.\'"><div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'   <input '.$autofocus.' type="text" value="\'.enti1($'.$v1['nom_champ'].').\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" maxlength="'.$v1['fieldSize'].'" style="width:100%;max-width:'.($v1['fieldSize']>10?round($v1['fieldSize']/2,0):($v1['fieldSize']<=3?3:$v1['fieldSize'])).'em;" />\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
        $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
        $autofocus='';
       }
      }
      $count++;
     }
    }
   }
  }
 }
 
 $sourceGenere.='  $o1.=\' <div class="yyfdiv1">\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'  <div class="yyfinp1"><div>\'.CRLF;'.CRLF;
 if($warningFlagOn1){
  $sourceGenere.='  if($___warningExist){'.CRLF;
  $sourceGenere.='   $o1.=\'   <input type="hidden" name="__bypass_warning" id="__bypass_warning" value="1" />\'.CRLF;'.CRLF;
  $sourceGenere.='   $o1.=\'   <button type="submit" class="yyedit" name="correct_the_warning_values">\'.txtsys1(\'correct_the_warning_values\').\'</button>\'.CRLF;'.CRLF; 
  $sourceGenere.='   $o1.=\'   <button type="submit" class="yywarning">\'.txtsys1(\'record_the_element\').\'</button>\'.CRLF;'.CRLF;
  $sourceGenere.='   $o1.=\'   <button type="submit" class="yywarning" name="record_the_element_and_back_to_list">\'.txtsys1(\'record_the_element_and_back_to_list\').\'</button>\'.CRLF;'.CRLF;
  $sourceGenere.='  }else{'.CRLF;
  $sourceGenere.='   $o1.=\'   <button type="submit">\'.txtsys1(\'record_the_element\').\'</button>\'.CRLF;'.CRLF;
  $sourceGenere.='   $o1.=\'   <button type="submit" class="" name="record_the_element_and_back_to_list">\'.txtsys1(\'record_the_element_and_back_to_list\').\'</button>\'.CRLF;'.CRLF;
  $sourceGenere.='  }'.CRLF;
 }else{
  $sourceGenere.='  $o1.=\'   <button type="submit">\'.txtsys1(\'record_the_element\').\'</button>\'.CRLF;'.CRLF;
  $sourceGenere.='  $o1.=\'   <button type="submit" class="" name="record_the_element_and_back_to_list">\'.txtsys1(\'record_the_element_and_back_to_list\').\'</button>\'.CRLF;'.CRLF;  
 }
 $sourceGenere.='  $o1.=\'   <input type="hidden" value="0" name="id1" id="id1" />\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'   <input type="hidden" value="c" name="a" id="a" />\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF;
 $sourceGenere.=''.CRLF.CRLF;
 $sourceGenere.='  $o1.=\'</form>\'.CRLF;'.CRLF.CRLF;
 $sourceGenere.=' }'.CRLF;

 $sourceGenere.=' if(isset($_GET[\'scrollBack2\'])){'.CRLF;
 $sourceGenere.='  $js1[]=array(\'jsName\'=>\'scrollBack2\',\'value\'=>$_GET[\'scrollBack2\']);'.CRLF;
 $sourceGenere.=' }'.CRLF;
 
 
 $sourceGenere.=' $o1.=htmlFoot0(array(\'js\' => $js1));'.CRLF;
 $sourceGenere.=' dw1($o1);'.CRLF;
 $sourceGenere.=' if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);'.CRLF;
 $sourceGenere.='}'.CRLF;

}

//========================================================================================================================
//========================================================================================================================
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_SESSION , true ) . '</pre>' ; exit(0);
$o1='';
$o1.=htmlHead1(array());
$o1.='<h1>'.txt2('generate the sources_10_18').'</h1>';
$o1.=displaySessionMessage1(BNF);
$withoutPrefixTable1=isset($_GET['withoutPrefixTable1'])?$_GET['withoutPrefixTable1']:'off';
$systemtable1=isset($_GET['systemtable1'])?$_GET['systemtable1']:'off';
if(isset($_GET['m']) && $_GET['m']=='1' && PGMK=='td'.'o'){
 $systemtable1='on';
}

$o1.='<div>'.$warningText.'</div>';

if(isset($_GET['table'])){
 if(substr($_GET['table'],0,9)==PGMK.'_tbl__'){
  $debutFichier=substr($_GET['table'],9);
 }else if(substr($_GET['table'],0,8)==PGMK.'_tbl_'){
  $debutFichier=substr($_GET['table'],8);
 }else{
  $debutFichier=$_GET['table']; 
 }
 $o1.='<div>';
 //echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $o1 , true ) . '</pre>' ; exit(0);
 $pageName='';
 if(isset($_GET['a']) && $_GET['a']=='inc1'){
  $pageName=(PGMK=='td'.'o'?'zz':'').'_inc_'.$debutFichier.'1.php';
  $o1.='file <input type="text" id="file_name" data-type="inc" value="'.$pageName.'" />';
 }
 // elem.bind("propertychange change click keyup input paste"
 if(isset($_GET['a']) && $_GET['a']=='list2'){
  $pageName=(PGMK=='td'.'o'?'zz_':'').''.$debutFichier.'1.php';
  if(PGMK!='td'.'o'){
   if(substr($pageName,0,4)==PGMK.'_'){
    $pageName=substr($pageName,4);
   }
  }
  $o1.='file <input type="text"  id="file_name" data-type="list" value="'.$pageName.'" onchange="fileNameChangeInGen1()" />';
 }
 if(isset($_GET['a']) && $_GET['a']=='action1'){
  $pageName=(PGMK=='td'.'o'?'zz_':'').''.$debutFichier.'_action1.php';
  if(PGMK!='td'.'o'){
   if(substr($pageName,0,4)==PGMK.'_'){
    $pageName=substr($pageName,4);
   }
  }
  $o1.='file <input type="text"  id="file_name"  data-type="action" value="'.$pageName.'" onchange="fileNameChangeInGen1()" />';
 }
 if(isset($_GET['a']) && $_GET['a']=='choose1'){
  $pageName=(PGMK=='td'.'o'?'zz_':'').$debutFichier.'_choose1.php';
  if(PGMK!='td'.'o'){
   if(substr($pageName,0,4)==PGMK.'_'){
    $pageName=substr($pageName,4);
   }
  }
  $o1.='file <input type="text"  id="file_name" data-type="choose" value="'.$pageName.'" onchange="fileNameChangeInGen1()" />';
 }
 if(isset($_GET['a']) && $_GET['a']!=''){
  $o1.='<button onclick="writeGeneratedFile1(\''.$_GET['a'].'\')">'.txt2('enregistrer ce fichier_3600_56').'</button>';
 }
 $o1.='<span id="insertThisPageInPagesAndGroup1"></span>'; // href="zz_pages_action1.php?a=c&newPage='.urlencode($pageName).'">'.txt2('insérer dans la liste des pages_3602_135').'</button>';
 
 if(isset($_GET['a']) && $_GET['a']!='inc1'){
//  $o1.='<a href="zz_pages_action1.php?a=c&newPage='.urlencode($pageName).'">'.txt2('insérer dans la liste des pages_3602_135').'</button>';
 }
 $o1.='</div>';
 
}




if($sourceGenere!=''){
 
 // ====================================================================================================================
 // ========================================= textarea source ==========================================================
 // ====================================================================================================================
 $o1.='<div style="display:flex;width:100%;border:1px red solid;flex-direction: row;justify-content: flex-start;align-items:flex-start; ">';
 $o1.='<div style="border:1px blue solid;width:70%;">';
 $o1.='<textarea id="file_source" style="font-family:monospace;font-size:8px;width:100%;height:636px;">'.htmlentities($sourceGenere,ENT_COMPAT,'utf-8').'</textarea>';
 $o1.='</div>';
 
 // ====================================================================================================================
 // =============================================== champs =============================================================
 // ====================================================================================================================
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['__listeDesChamps'] , true ) . '</pre>' ; exit(0);
 if(isset($_GET['a']) && ( $_GET['a']=='list2' || $_GET['a']=='choose1'  || $_GET['a']=='action1' )){
  
  
  $o1.='<div style="width:30%;border:1px green solid;">';
  $o1.='<form>';
  $o1.='<input type="hidden" name="a" value="'.$_GET['a'].'" />';
  $o1.=isset($_GET['fld_id_tables'])?'<input type="hidden" name="fld_id_tables" value="'.$_GET['fld_id_tables'].'" />':'';
  $o1.=isset($_GET['table'])?'<input type="hidden" name="table" value="'.$_GET['table'].'" />':'';
  $o1.=isset($_GET['type'])?'<input type="hidden" name="type" value="'.$_GET['type'].'" />':'';
  $o1.=isset($_GET['idBase'])?'<input type="hidden" name="idBase" value="'.$_GET['idBase'].'" />':'';
  $o1.=isset($_GET['withoutPrefixTable1'])&&$_GET['withoutPrefixTable1']=='on'?'<input type="hidden" name="withoutPrefixTable1" value="'.$_GET['withoutPrefixTable1'].'" />':'';
  $o1.=isset($_GET['systemtable1'])&&$_GET['systemtable1']=='on'?'<input type="hidden" name="systemtable1" value="'.$_GET['systemtable1'].'" />':'';
  $o1.='<input type="hidden" id="fieldOrder" name="fieldOrder" value="" />';
  
  $arr=$GLOBALS['__listeDesChamps'];
  $arr=$GLOBALS['__lstChampsTries'];
  foreach($GLOBALS['unsetted_fields']as$k1=>$v2){
   $arr[]=$v2;
  }
  if($_GET['a']=='action1'){
   $o1.='<div class="yythinBorder" style="">';
   $o1.='warning<br />';
   $o1.='<select name="__option___with_warning">';
   $warningFlagOn1=isset($_GET['__option___with_warning'])?($_GET['__option___with_warning']=='with_warning'?true:false):false;
   $o1.=' <option value="without_warning" '.($warningFlagOn1==false?' selected="selected" ':'' ).'>'.txt2('without_warning_4491_107').'</option>';
   $o1.=' <option value="with_warning" '.($warningFlagOn1==true?' selected="selected" ':'' ).'>'.txt2('with_warning_4492_103').'</option>';
   $o1.='</select>';
   $o1.='</div>';
  }
  $lstElements=array();
  $lstTablesHors0=array();
  foreach($arr as $k1 => $v1){
   $doIt=true;
   if($GLOBALS['__autoincrement']!='' && $v1['nom_champ']==$GLOBALS['__autoincrement']){
    $doIt=false;
   }
   if(in_array($v1['nom_champ'],$GLOBALS['__listeChampsCles']) && $GLOBALS['__autoincrement']!=''){
    $doIt=false;    
   }
   if($_GET['a']=='action1' && ($v1['tsupd']||$v1['tscrt']||$v1['cntupd']) ){
    $doIt=false;
   }
   if($doIt){
    $NumTbl1=isset($v1['refTableNumber'])?$v1['refTableNumber']:0;
    if(isset($v1['unsetted_fields_tableNumber']) && $v1['unsetted_fields_tableNumber']!=0){
     $NumTbl1=$v1['unsetted_fields_tableNumber'];
    }
    if($_GET['a']=='action1' && $NumTbl1>0 ){
    }else{
     
     if($NumTbl1>0){
      if(!isset($lstTablesHors0['T'.$NumTbl1])){
       $lstTablesHors0['T'.$NumTbl1]='T'.$NumTbl1;
      }
     }
    
     $element1='';
     $element1.='<div data-cas="1" id="T'.$NumTbl1.'_'.$v1['nom_champ'].'" style="">';
     $element1.='T'.$NumTbl1.'.'.$v1['nom_champ'].'<br />';
     $element1.='<select name="__option_T'.$NumTbl1.'_'.$v1['nom_champ'].'">';
     $element1.=' <option value=""></option>';
     $element1.=' <option value="ign1" '.(isset($_GET['__option_T'.$NumTbl1.'_'.$v1['nom_champ']]) && $_GET['__option_T'.$NumTbl1.'_'.$v1['nom_champ']]=='ign1'?' selected="selected" ':'' ).'>'.txt2('Ignore field for output_4026_164').'</option>';
     $element1.=' <option value="ign2" '.(isset($_GET['__option_T'.$NumTbl1.'_'.$v1['nom_champ']]) && $_GET['__option_T'.$NumTbl1.'_'.$v1['nom_champ']]=='ign2'?' selected="selected" ':'' ).'>'.txt2('Ignore field for display_4027_164').'</option>';
     if($v1['type_champ']=='date' || $v1['type_champ']=='time' || $v1['type_champ']=='datetime' || $v1['type_champ']=='timestamp' ){
      if(!isset($_GET['fieldOrder']) && ( $_GET['a']=='list2' ||  $_GET['a']=='choose1' )){
       $_GET['__option_T'.$NumTbl1.'_'.$v1['nom_champ']]='dttxt1';
      }
      $element1.=' <option value="dttxt1" '.(isset($_GET['__option_T'.$NumTbl1.'_'.$v1['nom_champ']]) && $_GET['__option_T'.$NumTbl1.'_'.$v1['nom_champ']]=='dttxt1'?' selected="selected" ':'' ).'>'.txt2('filter is text_4029_169').'</option>';
     }
     $element1.='</select>';
     $element1.='</div>';
     
     
     $lstElements[]=array(
      'id'       => 'T'.$NumTbl1.'.'.$v1['nom_champ'],
      'data'     => array( 'label' => $element1 ),
      'parentId' => 0,
     );
    }
   }
  }
  if(isset($listOfTheTablesToIgnore) && count($listOfTheTablesToIgnore)>0){
   foreach($listOfTheTablesToIgnore as $k1=>$v1){
    $element1='';
    $element1.='<div data-cas="3" id="table_T'.$v1.'" style="">';
    $element1.='table T'.$v1.'<br />';
    $element1.='<select name="__table_option_T'.$v1.'">';
    $element1.=' <option value="">'.txt2('Use_4513_42').'</option>';
    $element1.=' <option value="ign3" selected="selected">'.txt2('ignore_4514_66').'</option>';
    $element1.='</select>';
    $element1.='</div>';
    $lstElements[]=array(
     'id'       => 'table_'.$k1                  ,
     'data'     => array( 'label' => $element1 ) ,
     'parentId' => 0                             ,
    );
   }
  }
  
  
  if(count($lstTablesHors0)>0){
   foreach($lstTablesHors0 as $k1=>$v1){
    $element1='';
    $element1.='<div data-cas="3" id="table_'.$k1.'" style="">';
    $element1.='table '.$k1.'<br />';
    $element1.='<select name="__table_option_'.$k1.'">';
    $element1.=' <option value="">'.txt2('Use_4513_42').'</option>';
    $element1.=' <option value="ign3">'.txt2('ignore_4514_66').'</option>';
    $element1.='</select>';
    $element1.='</div>';
    $lstElements[]=array(
     'id'       => 'table_'.$k1                  ,
     'data'     => array( 'label' => $element1 ) ,
     'parentId' => 0                             ,
    );
   }
  }
//  echo __FILE__ . ' ' . __LINE__ . ' $lstElements = <pre>' . htmlentities( var_export( $lstElements , true )) . '</pre>' ; exit(0);
  $o1.='<div id="container2" style="max-width:95%;border:1px #f00 solid;overflow-y:scroll;max-height:600px;">';
  $o1.='     <div id="myTreeId2"></div>';
  $o1.='</div>';
  $o1.='<script src="js/hdtree.js?v='.$GLOBALS['vrsi'].'"></script>';
  $o1.='<script type="text/javascript">';
  $o1.='var jsonTree2='.json_encode($lstElements).';';
  $o1.='var optionsSortFields1={';
  $o1.=' sortOnly : true  ,';
  $o1.=' noIdPrintAfterLabel : true  ,';
  
  $o1.=' design   : {';
  $o1.='  elementHeightInPx : 55 ,';
  $o1.=' }';
  $o1.='}';
  $o1.='</script>';
  
  $js1['js'][]=array( 
   'jsName'                  => 'sortGenerateFields1'      ,
   'objectName'              => 'oMyTree2'                 ,
   'elementToSort'           => 'myTreeId2'                ,
   'dataToSort'              => 'jsonTree2'                ,
   'options'                 => 'optionsSortFields1'       ,
   'callBack'                => 'aftersortGenerateFields1' ,
   'localhost'               => true
  );
  
  
  
  
  
  $o1.='<button type="submit">'.txt2('Regenerate with options_4054_37').'</button>';
  $o1.='</div>'; 
 }
 // ====================================================================================================================
 // =============================================== /champs =============================================================
 // ====================================================================================================================
 $o1.='</form>';
 $o1.='</div>';
}


$tableList=array();

//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $withoutPrefixTable1 , true ) . '</pre>' ; exit(0);

$o1.='<form>';
$o1.=' '.txt2(' Display also the tables without prefix_3622_15').' "'.$GLOBALS['__table_prefix'].'"  ? <input type="checkbox" '.($withoutPrefixTable1=='on'?' checked="checked" ':'').' id="withoutPrefixTable1" name="withoutPrefixTable1" />';
$o1.=' Show system tables  also ? <input type="checkbox" '.($systemtable1=='on'?' checked="checked" ':'').' id="systemtable1" name="systemtable1" />';
$o1.='<button>GO</button>';
$o1.='</form>';


foreach($GLOBALS['glob_db'] as $k1 => $v1){
 $toPrint.='<h4>' .txt2('List of the tables for the database_14_20'). ' : ' . $v1['server'] . '/' . $v1['dbname'] . '</h4>';
 $tableList[$k1]['server']=$v1['server'];
 $tableList[$k1]['dbname']=$v1['dbname'];
 $tableList[$k1]['tables']=array();

// $req6='SHOW TABLES FROM `'.$v1['dbname'].'` LIKE \''.$GLOBALS['__table_prefix'].'%\'';
 $tableList1=array();

 $req6=getRequestTable($withoutPrefixTable1,$v1['dbname']);
 $result6=mysqli_query($v1['link'],$req6);
 if(mysqli_errno($v1['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $tableList1[]=array(
    'table_name'           => $mpsr6[0],
    'system_table'         => $mpsr6[1],
    'fld_id_tables'        => $mpsr6[2],
    'fld_id_server_tables' => $mpsr6[3],
    'type'                 => 'table'  ,
    'log_table'            => $mpsr6[4],
   );
  }
  mysqli_free_result($result6);
 }else{
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=':-( '. __LINE__ .' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
 }
 
 $req6=getRequestView($withoutPrefixTable1,$v1['dbname']);
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . $req6 . '</pre>' ; exit(0);
 $result6=mysqli_query($v1['link'],$req6);
 if(mysqli_errno($v1['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $tableList1[]=array(
    'table_name'           => $mpsr6[0],
    'system_table'         => $mpsr6[1],
    'fld_id_tables'        => $mpsr6[2],
    'fld_id_server_tables' => $mpsr6[3],
    'type'                 => 'view',
    'log_table'            => 0 ,
   );
  }
  mysqli_free_result($result6);
 }else{
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=':-( '. __LINE__ .' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
 }
 
 
 
 if($systemtable1=='off'){
  foreach($tableList1 as $k0 => $v0){
   if(substr($v0['table_name'],0,9)==PGMK.'_tbl__'){
    unset($tableList1[$k0]);
   }
  }
 }
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $tableList1 , true ) . '</pre>' ; exit(0);
 if(PGMK!='td'.'o'){
  foreach($tableList1 as $k0 => $v0){
   if($v0['system_table']==1 && !( $v0['table_name']==PGMK.'_tbl__users' || $v0['table_name']==PGMK.'_tbl__groups' )){
    unset($tableList1[$k0]);
   }
  }
 }

 
 
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $tableList1 , true ) . '</pre>' ; exit(0);
 
 $toPrint.='<table class="yytableResult1">'.CRLF;
 $toPrint.='<thead><tr>'.CRLF;
 $toPrint.='<th>'.txtsys1('action').'</th>'.CRLF;
 $toPrint.='<th>'.txt2('table name_19_29').'</th>'.CRLF;
 $toPrint.='<th>'.txt2('log_table_4141_24').'</th>'.CRLF;
 $toPrint.='<th>'.txt2('system_table_3686_102').'</th>'.CRLF;
 $toPrint.='</tr></thead><tbody>'.CRLF;
 
 foreach($tableList1 as $k2 => $v2){
  if(isset($_GET['table']) && $_GET['table']==$v2['table_name']){
   $toPrint.='<tr class="yysuccess">';
  }else{
   $toPrint.='<tr>';
  }
  $auth_inc_and_choose_for_user_table=true;
  if(PGMK=='t'.'do'){
  }else{
   if($v2['table_name']==PGMK.'_tbl__users'||$v2['table_name']==PGMK.'_tbl__groups'){
    $auth_inc_and_choose_for_user_table=false;
   }
  }
  
  
  $toPrint.=' <td>'.CRLF;
  if(!is_null($v2['system_table'])){
   $toPrint.='  <a href="?a=inc1&amp;fld_id_tables='.$v2['fld_id_tables'].'&amp;table='.urlencode($v2['table_name']).'&amp;type='.$v2['type'].'&amp;idBase='.$k1.''.($withoutPrefixTable1=='on'?'&amp;withoutPrefixTable1=on':'').''.($systemtable1=='on'?'&amp;systemtable1=on':'').'" title="'.txt2('inc_1205_103').'">';
   $toPrint.=''.txt2('inc_2281_129').'';
   $toPrint.=  '</a>';
  }
  if($v2['type']!='view'){
   if(!is_null($v2['system_table'])&&$auth_inc_and_choose_for_user_table==true){
    $toPrint.='  <a href="?a=list2&amp;fld_id_tables='.$v2['fld_id_tables'].'&amp;table='.urlencode($v2['table_name']).'&amp;idBase='.$k1.''.($withoutPrefixTable1=='on'?'&amp;withoutPrefixTable1=on':'').''.($systemtable1=='on'?'&amp;systemtable1=on':'').'" title="'.txt2('list_1206_104').'">';
    $toPrint.=''.txt2('list_2282_131').'2';
    $toPrint.='</a>';
    $toPrint.='  <a href="?a=action1&amp;fld_id_tables='.$v2['fld_id_tables'].'&amp;table='.urlencode($v2['table_name']).'&amp;idBase='.$k1.''.($withoutPrefixTable1=='on'?'&amp;withoutPrefixTable1=on':'').''.($systemtable1=='on'?'&amp;systemtable1=on':'').'" title="'.txt2('action_1207_106').'">';
    $toPrint.=''.txt2('action_2283_135').'';
    $toPrint.='</a>';
   }
  }
  if(!is_null($v2['system_table'])){
   $toPrint.='  <a href="?a=choose1&amp;fld_id_tables='.$v2['fld_id_tables'].'&amp;table='.urlencode($v2['table_name']).'&amp;type='.$v2['type'].'&amp;idBase='.$k1.''.($withoutPrefixTable1=='on'?'&amp;withoutPrefixTable1=on':'').''.($systemtable1=='on'?'&amp;systemtable1=on':'').'" title="'.txt2('action_1207_106').'">';
   $toPrint.=''.txt2('choose_1208_126').'';
   $toPrint.='</a>';
  }
  $toPrint.=' </td>'.CRLF;
  
  
  $toPrint.=' <td>';
  $toPrint.='  '.$v2['table_name'].($v2['type']=='view'?'(v)':'').'';
  $toPrint.=' </td>'.CRLF;


  
  if(is_null($v2['log_table'])){
   $toPrint.=' <td style=""></td>';
  }else{
   $toPrint.=' <td style="text-align:center;">';
   $toPrint.='  '.displayParam1('yorno',$v2['log_table'],array()).'';   
  }
  $toPrint.=' </td>'.CRLF;
  
  
  
  if(is_null($v2['system_table'])){
   $toPrint.=' <td style="">';
   $toPrint.=txt2(' This table is not in the table list_3722_19') . ' <a href="zz_tables_action1.php?a=c&amp;new='.urlencode($v2['table_name']).''.($v2['type']=='view'?'&amp;view=true':'').'" '.
             '>'.txt2('add this table to tha table list_3723_23').'</a>';
  }else{
   $toPrint.=' <td style="text-align:center;">';
   $toPrint.='  '.displayParam1('yorno',$v2['system_table'],array('unsetPossible'=>true)).'';
  }
  $toPrint.=' </td>'.CRLF;
  
  
  
  
  $toPrint.='</tr>';
  
 }
 $toPrint.='</tbody></table>'.CRLF;
}
$o1.=$toPrint;
//$o1.='<script type="text/javascript">setTimeout(fileNameChangeInGen1(),500);</script>'.CRLF;
if(isset($_GET['a']) && $_GET['a']=='inc1'){
 $js1=array();
}else{
 $js1['js'][]=array('jsName' => 'fileNameChangeInGen1' , 'localhost' => true );
}

$o1.=htmlFoot0($js1);
dw1($o1);
cleanSession1();