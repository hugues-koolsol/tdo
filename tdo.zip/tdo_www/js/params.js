//=====================================================================================================================
function sortParamWithoutLang1(args){
 var o1='';
 o1+='var oMyTree_1=new cMyTree1(';
 o1+=' \'oMyTree_1\' ,';           // this object name
 o1+=' \'lang_1\' ,';              // the id of the html < div > you want to fill
 o1+=' jsonTree1 ,';               // the data
 o1+=' param_1 ,';                 // the parameters
 o1+=' onSortParamWithoutLang2 '; // the callback
 o1+=');';
// console.log('"'+o1+'"');
 eval(o1);
}
//=====================================================================================================================
function sortParamWithLang1(args){
// console.log(args);
 var o1='';
 o1+='var oMyTree_'+args['params']['lang']+'_1=new cMyTree1(';
 o1+=' \'oMyTree_'+args['params']['lang']+'_1\','; // this object name
 o1+=' \'lang_'+args['params']['lang']+'_1\',';    // the id of the html < div > you want to fill
 o1+=' '+args.params.dataRef+',';                  // the data
 o1+=' param_'+args['params']['lang']+'_1,';       // the parameters
 o1+=' onSortParamWithLang2';            // the callback
 o1+=');';
 eval(o1);
}
//=====================================================================================================================
function updateParam1(buttonId,inputId){
 var data={
  funct   : 'updateParam1',
  id      : document.getElementById(buttonId).getAttribute('data-id'),
  name    : document.getElementById(buttonId).getAttribute('data-name'),
  key     : document.getElementById(buttonId).getAttribute('data-key'),
  lang    : document.getElementById(buttonId).getAttribute('data-lang'),
  paramId : document.getElementById(buttonId).getAttribute('data-paramid'),
  value : document.getElementById(inputId).value
 };
 ajaxCall({
  data  : data,
  url   : 'updateParam1',
  retu  : afterUpdateParam1
 });
}
//=====================================================================================================================
function afterUpdateParam1(dataJson,objSend){
}
//=====================================================================================================================
function onSortParamWithoutLang(e){
// console.log('dans onSortParamWithoutLang, e=',e)
 var listName=e.target.id;
 var listeDesElementsTries=[];
 var lst=document.getElementById(listName).getElementsByTagName('li');
 for(var i=0;i<lst.length;i++){
  listeDesElementsTries.push(parseInt(lst[i].id.replace(/sort__p__/,''),10))
 }
 var data={
  funct:'setSortParamWithoutLang1',
  idParam:document.getElementById(listName).getAttribute('data-idlist'),
  paramName:document.getElementById(listName).getAttribute('data-paramname'),
  order:listeDesElementsTries,
 };
 ajaxCall({
  data  : data,
  url   : 'setSortParamWithoutLang1',
  retu  : afterSetSortParamWithoutLang1
 });
}
//=====================================================================================================================
function afterSetSortParamWithoutLang1(dataJson,objSend){
}
//=====================================================================================================================
function onSortParamWithLang2(context,tree){
 var listeDesElementsTries=[]; 
 for(var elem in tree){
  listeDesElementsTries.push(tree[elem].id);
 }
 switch(context.action){
  case 'afterReorganize' :
  var data={
   funct   : 'setSortParamWithLang1',
   idParam : document.getElementById(context.divId).getAttribute('data-idlist'),
   lang    : document.getElementById(context.divId).getAttribute('data-lang'),
   order   : listeDesElementsTries,
  };
  ajaxCall({
   data  : data,
   url   : 'setSortParamWithLang1',
   retu  : afterSetSortParamWithLang2
  });
  break;  
 }
}
//=====================================================================================================================
function afterSetSortParamWithLang2(dataJson,objSend){
}
//=====================================================================================================================
function onSortParamWithoutLang2(context,tree){
 var listeDesElementsTries=[]; 
 for(var elem in tree){
  listeDesElementsTries.push(tree[elem].id);
 }
 
 switch(context.action){
  case 'afterReorganize' :
  var data={
   funct   : 'setSortParamWithoutLang1',
   idParam : document.getElementById(context.divId).getAttribute('data-idlist'),
   order   : listeDesElementsTries,
  };
  ajaxCall({
   data  : data,
   url   : 'setSortParamWithoutLang1',
   retu  : afterSetSortParamWithoutLang2
  });
  break;
 }
}
//=====================================================================================================================
function afterSetSortParamWithoutLang2(dataJson,objSend){
}