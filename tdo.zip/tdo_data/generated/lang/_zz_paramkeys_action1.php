<?php
$GLOBALS['glob_lv']['the ']='the name badge is reserved';
