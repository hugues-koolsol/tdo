<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages() || $_SESSION[PGMK]['translate']==1){
 if(is_file($ret['input']['page'])){ 
  openDb2();
  $ret['message'][]='Founded "'.$ret['input']['page'].'"';
  $output=array();
  $arrFile=file ( $ret['input']['page'] );
  $clesDejaTraitees=array();
 // echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $arrFile , true ) . '</pre>' ; exit(0);
  $listOfTypes=array('txt1','txt2');
  foreach($listOfTypes as $k0 => $v0){
   foreach($arrFile as $k1 => $v1){
    $start=0;
    $buff='';
    $countWhile=100;
    $pos=strpos($v1,$v0.'(\'',$start);
    while($pos!==false && $countWhile>0){
     for($i=$pos+6;$i<strlen($v1);$i++){
      $c=substr($v1,$i,1);
  //    echo  __LINE__ . ' $c = ' .htmlentities($c,ENT_COMPAT,'utf-8') .'<br/>' ; 
      $key=str_replace('\\\'','\'',$buff);
      if($c=='\'' && !( substr($v1,$i-1,1)=='\\' && substr($v1,$i-2,1)!='\\') ){
       if(!in_array( $key , $clesDejaTraitees ) ){
        $output[]=array(
         'lineNumber' => $k1,
         'colNumber'  => $col,
         'line'       => $v1,
         'key'        => $key,
         'type'       => $v0,
        );
       }
       $pos=strpos($v1,$v0.'(\'',$i);
       $buff='';
       array_push( $clesDejaTraitees , $key );
       break;
      }else{
       if($buff==''){
        $col=$i;
       }
       $buff.=$c;
      }
     }
     $countWhile--;
    }
   }
  }
  $listeDesCles='';
  foreach($output as $k1 => $v1){
   if($v1['type']=='txt2'){
    $listeDesCles.=''.var_export($v1['key'],true).',';
   }
  }
  //echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listeDesCles , true ) . '</pre>' ; exit(0);
  $ret['translateValues']=array();
  if($listeDesCles!=''){
   $listeDesCles=substr($listeDesCles,0,-1);
   if(isset($ret['input']['typeJs']) && $ret['input']['typeJs'] == true ){
    $req6='
     SELECT T0.`fld_lang_lngVals`  , T0.`fld_value_lngVals` , T0.`fld_key_lngVals`
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0 
     WHERE T0.`fld_type_lngVals` = \'javascript\'
       AND T0.`fld_key_lngVals` IN ('.$listeDesCles.')
    ';
   }else{
    $req6='
     SELECT T0.`fld_lang_lngVals`  , T0.`fld_value_lngVals` , T0.`fld_key_lngVals`
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0 
     WHERE T0.`fld_page_id_lngVals` = ' . $ret['input']['page_id'] . '
       AND T0.`fld_key_lngVals` IN ('.$listeDesCles.')
    ';
   }
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . $req6 . '</pre>' ; exit(0);
   $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    while($mpsr6=mysqli_fetch_row($result6)){
     $ret['translateValues'][$mpsr6[2]][$mpsr6[0]]=array(
      'lang'  => $mpsr6[0],
      'value' => $mpsr6[1],
      'key'   => $mpsr6[2],
     );
    }
    mysqli_free_result($result6);
   }else{
    $ret['message']='mysqli_error() "'.mysqli_error($GLOBALS['glob_db'][0]['link']).'" , $req6='.$req6;
   }
   
  }
  if(sizeof($ret['translateValues'])==0){
   $ret['translateValues']=null;
  }
  $ret['output']=$output;
  $ret['status']='OK';
 }else{
  $ret['message']='Cannot find "'.$ret['input']['page'].'"';
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}