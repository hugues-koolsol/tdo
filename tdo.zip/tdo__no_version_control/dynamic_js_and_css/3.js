var globalCssSettings1={
    "main": {
        "mainBackgroundColor": {
            "hexValue": "D3ECFF",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "205,17,100",
            "rgbValue": "211,236,255"
        },
        "mainBackgroundColEnd": {
            "hexValue": "BAE2FF",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "205,27,100",
            "rgbValue": "186,226,255"
        },
        "mainTextColor": {
            "hexValue": "0D47A1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 900",
            "hsvValue": "91,91,63",
            "rgbValue": "13,71,161",
            "type": "color"
        },
        "thinBorderColor": {
            "hexValue": "90CAF9",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 200",
            "hsvValue": "42,42,97",
            "rgbValue": "144,202,249",
            "type": "color"
        },
        "linkStartBackgroundColor": {
            "hexValue": "CFE9FC",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "205,17,98",
            "rgbValue": "207,233,252",
            "type": "color"
        },
        "linkEndBackground": {
            "hexValue": "B3DCF9",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "205,28,98",
            "rgbValue": "179,220,249",
            "type": "color"
        },
        "linkUnsetTextColor": {
            "hexValue": "A3D5F7",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "204,34,97",
            "rgbValue": "163,213,247",
            "type": "color"
        },
        "activeFilterBackground": {
            "hexValue": "ffff00",
            "type": "color"
        },
        "activeFilterColor": {
            "hexValue": "0D47A1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 900",
            "hsvValue": "91,91,63",
            "rgbValue": "13,71,161",
            "type": "color"
        },
        "inputBorderWidth": {
            "type": "SomeValues",
            "valueList": "1px,2px,3px",
            "value": "2px",
            "hr_after": false
        }
    },
    "menu": {
        "topColor": {
            "hexValue": "1E88E5",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 600",
            "hsvValue": "86,86,89",
            "rgbValue": "30,136,229",
            "type": "color"
        },
        "bottomColor": {
            "hexValue": "1565C0",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 800",
            "hsvValue": "89,89,75",
            "rgbValue": "21,101,192",
            "type": "color"
        },
        "textColor": {
            "hexValue": "E3F2FD",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 50",
            "hsvValue": "10,10,99",
            "rgbValue": "227,242,253",
            "type": "color"
        },
        "borderColor": {
            "hexValue": "1683E2",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "208,90,89",
            "rgbValue": "22,131,226",
            "type": "color"
        },
        "activeBackgroundColor": {
            "hexValue": "0D47A1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 900",
            "hsvValue": "91,91,63",
            "rgbValue": "13,71,161",
            "type": "color"
        }
    },
    "table": {
        "headerBackgroundColor": {
            "hexValue": "BBDEFB",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 100",
            "hsvValue": "25,25,98",
            "rgbValue": "187,222,251",
            "type": "color"
        },
        "headerTextColor": {
            "hexValue": "666666",
            "type": "color"
        },
        "linkTextColor": {
            "hexValue": "666666",
            "webValue": "666666",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "0,0,40",
            "rgbValue": "102,102,102",
            "type": "color"
        },
        "nthchildBackgroundColor": {
            "hexValue": "CFE9FC",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "205,18,99",
            "rgbValue": "207,233,252",
            "type": "color"
        }
    },
    "backgrounds": {
        "dangerBackground": {
            "hexValue": "FF0000",
            "webValue": "FF0000",
            "webName": "red",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,0,0",
            "type": "color"
        },
        "danger2Background": {
            "hexValue": "D60000",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,100,84",
            "rgbValue": "214,0,0"
        },
        "dangerText": {
            "hexValue": "FFFFFF",
            "webValue": "FFFFFF",
            "webName": "white",
            "pantoneName": "",
            "hsvValue": "0,0,100",
            "rgbValue": "255,255,255",
            "type": "color"
        },
        "editBackground": {
            "hexValue": "87CEFA",
            "webValue": "87CEFA",
            "webName": "lightskyblue",
            "pantoneName": "",
            "hsvValue": "46,46,98",
            "rgbValue": "135,206,250",
            "type": "color"
        },
        "edit2Background": {
            "hexValue": "73B2D6",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "202,46,84",
            "rgbValue": "115,178,214"
        },
        "editText": {
            "hexValue": "0000FF",
            "webValue": "0000FF",
            "webName": "blue",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "0,0,255",
            "type": "color"
        },
        "successBackground": {
            "hexValue": "C8E6C9",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 100",
            "hsvValue": "13,13,90",
            "rgbValue": "200,230,201",
            "type": "color"
        },
        "success2Background": {
            "hexValue": "B5D1B6",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "122,13,82",
            "rgbValue": "181,209,182"
        },
        "successText": {
            "hexValue": "2E7D32",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 800",
            "hsvValue": "63,63,49",
            "rgbValue": "46,125,50",
            "type": "color"
        },
        "errorBackground": {
            "hexValue": "FD3131",
            "type": "color"
        },
        "error2Background": {
            "hexValue": "C92828",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,80,79",
            "rgbValue": "201,40,40"
        },
        "errorText": {
            "hexValue": "FFFF33",
            "webValue": "FFFF33",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "80,80,100",
            "rgbValue": "255,255,51"
        },
        "warningBackground": {
            "hexValue": "FFA500"
        },
        "warning2Background": {
            "hexValue": "D68700",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "38,100,84",
            "rgbValue": "214,135,0"
        },
        "warningText": {
            "hexValue": "000000"
        }
    },
    "badge": {
        "badge0Background": {
            "hexValue": "FF0000",
            "webValue": "FF0000",
            "webName": "red",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,0,0",
            "type": "color"
        },
        "badge0TextColor": {
            "hexValue": "FFFFFF",
            "webValue": "FFFFFF",
            "webName": "white",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,100",
            "rgbValue": "255,255,255",
            "type": "color"
        },
        "badge1Background": {
            "hexValue": "00FF00",
            "webValue": "00FF00",
            "webName": "lime",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "0,255,0",
            "type": "color"
        },
        "badge1TextColor": {
            "hexValue": "008000",
            "webValue": "008000",
            "webName": "green",
            "pantoneName": "",
            "hsvValue": "100,100,50",
            "rgbValue": "0,128,0",
            "type": "color"
        },
        "badge2Background": {
            "hexValue": "FFFF00",
            "webValue": "FFFF00",
            "webName": "yellow",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,255,0",
            "type": "color"
        },
        "badge2TextColor": {
            "hexValue": "0000FF",
            "webValue": "0000FF",
            "webName": "blue",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "240,100,100",
            "rgbValue": "0,0,255",
            "type": "color"
        },
        "badge3Background": {
            "hexValue": "FF00FF",
            "webValue": "FF00FF",
            "webName": "fuchsia",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "300,100,100",
            "rgbValue": "255,0,255",
            "type": "color"
        },
        "badge3TextColor": {
            "hexValue": "FFFF00",
            "webValue": "FFFF00",
            "webName": "yellow",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,255,0",
            "type": "color"
        },
        "badge4Background": {
            "hexValue": "00FFFF",
            "webValue": "00FFFF",
            "webName": "aqua",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "180,100,100",
            "rgbValue": "0,255,255",
            "type": "color"
        },
        "badge4TextColor": {
            "hexValue": "0000FF",
            "webValue": "0000FF",
            "webName": "blue",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "240,100,100",
            "rgbValue": "0,0,255",
            "type": "color"
        },
        "badge5Background": {
            "hexValue": "4CAF50",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 500",
            "hsvValue": "122,56,68",
            "rgbValue": "76,175,80",
            "type": "color"
        },
        "badge5TextColor": {
            "hexValue": "FFEB3B",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Yellow 500",
            "hsvValue": "53,76,100",
            "rgbValue": "255,235,59",
            "type": "color"
        },
        "badge6Background": {
            "hexValue": "FFEBEE",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 50",
            "hsvValue": "7,7,100",
            "rgbValue": "255,235,238",
            "type": "color"
        },
        "badge6TextColor": {
            "hexValue": "C62828",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 800",
            "hsvValue": "0,79,77",
            "rgbValue": "198,40,40",
            "type": "color"
        },
        "badge7Background": {
            "hexValue": "1E88E5",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 600",
            "hsvValue": "208,86,89",
            "rgbValue": "30,136,229",
            "type": "color"
        },
        "badge7TextColor": {
            "hexValue": "E3F2FD",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 50",
            "hsvValue": "205,10,99",
            "rgbValue": "227,242,253",
            "type": "color"
        },
        "badge8Background": {
            "hexValue": "FFE082",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Amber 200",
            "hsvValue": "45,49,100",
            "rgbValue": "255,224,130",
            "type": "color"
        },
        "badge8TextColor": {
            "hexValue": "F06292",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Pink 300",
            "hsvValue": "340,59,94",
            "rgbValue": "240,98,146",
            "type": "color"
        }
    },
    "other": {
        "autocompleteInput": {
            "type": "yorno",
            "value": "0"
        }
    },
    "sizes": {
        "menuHeight": 55,
        "footerHeight": 20
    }
};