var globalCssSettings1={
    "main": {
        "mainBackgroundColor": {
            "hexValue": "FFFDE7",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "55,9,100",
            "rgbValue": "255,253,231",
            "type": "color"
        },
        "mainBackgroundColEnd": {
            "hexValue": "FFF59D",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Yellow 200",
            "hsvValue": "38,38,100",
            "rgbValue": "255,245,157"
        },
        "mainTextColor": {
            "hexValue": "8E1818",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "0,83,56",
            "rgbValue": "142,24,24",
            "type": "color"
        },
        "thinBorderColor": {
            "hexValue": "F7F3CA",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "55,18,97",
            "rgbValue": "247,243,202"
        },
        "linkStartBackgroundColor": {
            "hexValue": "FFFDE7",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "55,9,100",
            "rgbValue": "255,253,231",
            "type": "color"
        },
        "linkEndBackground": {
            "hexValue": "EFE9B8",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "53,23,94",
            "rgbValue": "239,233,184"
        },
        "linkUnsetTextColor": {
            "hexValue": "FFF9C4",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Yellow 100",
            "hsvValue": "53,23,100",
            "rgbValue": "255,249,196",
            "type": "color"
        },
        "activeFilterBackground": {
            "hexValue": "ffff00",
            "type": "color"
        },
        "activeFilterColor": {
            "hexValue": "8E1818",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,83,55",
            "rgbValue": "142,24,24",
            "type": "color"
        },
        "inputBorderWidth": {
            "type": "SomeValues",
            "valueList": "1px,2px,3px",
            "value": "2px",
            "hr_after": false
        }
    },
    "menu": {
        "topColor": {
            "hexValue": "F57F17",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "28,90,96",
            "rgbValue": "245,127,23",
            "type": "color"
        },
        "bottomColor": {
            "hexValue": "FBC02D",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "42,82,98",
            "rgbValue": "251,192,45",
            "type": "color"
        },
        "textColor": {
            "hexValue": "B22222",
            "webValue": "B22222",
            "webName": "firebrick",
            "pantoneName": "",
            "hsvValue": "80,80,69",
            "rgbValue": "178,34,34",
            "type": "color"
        },
        "borderColor": {
            "hexValue": "F57F17",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "28,90,96",
            "rgbValue": "245,127,23",
            "type": "color"
        },
        "activeBackgroundColor": {
            "hexValue": "FFEB3B",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "53,76,100",
            "rgbValue": "255,235,59",
            "type": "color"
        }
    },
    "table": {
        "headerBackgroundColor": {
            "hexValue": "FFF59D",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "53,38,100",
            "rgbValue": "255,245,157",
            "type": "color"
        },
        "headerTextColor": {
            "hexValue": "F57F17",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "28,90,96",
            "rgbValue": "245,127,23",
            "type": "color"
        },
        "linkTextColor": {
            "hexValue": "666666",
            "webValue": "666666",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "0,0,40",
            "rgbValue": "102,102,102",
            "type": "color"
        },
        "nthchildBackgroundColor": {
            "hexValue": "FDFAD5",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "55,15,99",
            "rgbValue": "253,250,213",
            "type": "color"
        }
    },
    "backgrounds": {
        "dangerBackground": {
            "hexValue": "FF0000",
            "webValue": "FF0000",
            "webName": "red",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,0,0",
            "type": "color"
        },
        "danger2Background": {
            "hexValue": "D30000",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,100,83",
            "rgbValue": "211,0,0"
        },
        "dangerText": {
            "hexValue": "FFFFFF",
            "webValue": "FFFFFF",
            "webName": "white",
            "pantoneName": "",
            "hsvValue": "0,0,100",
            "rgbValue": "255,255,255",
            "type": "color"
        },
        "editBackground": {
            "hexValue": "87CEFA",
            "webValue": "87CEFA",
            "webName": "lightskyblue",
            "pantoneName": "",
            "hsvValue": "46,46,98",
            "rgbValue": "135,206,250",
            "type": "color"
        },
        "edit2Background": {
            "hexValue": "6FABCE",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "202,46,81",
            "rgbValue": "111,171,206"
        },
        "editText": {
            "hexValue": "0000FF",
            "webValue": "0000FF",
            "webName": "blue",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "0,0,255",
            "type": "color"
        },
        "successBackground": {
            "hexValue": "ABDB72",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "87,48,86",
            "rgbValue": "171,219,114"
        },
        "success2Background": {
            "hexValue": "8ABC47",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "86,62,74",
            "rgbValue": "138,188,71"
        },
        "successText": {
            "hexValue": "485E21",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "82,64,37",
            "rgbValue": "72,94,33",
            "type": "color"
        },
        "errorBackground": {
            "hexValue": "FD3131",
            "type": "color"
        },
        "error2Background": {
            "hexValue": "C92828",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,80,79",
            "rgbValue": "201,40,40"
        },
        "errorText": {
            "hexValue": "F9F900",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "60,100,98",
            "rgbValue": "249,249,0"
        },
        "warningBackground": {
            "hexValue": "FFC563",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "38,61,100",
            "rgbValue": "255,197,99"
        },
        "warning2Background": {
            "hexValue": "DB8700",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "37,100,86",
            "rgbValue": "219,135,0"
        },
        "warningText": {
            "hexValue": "704500",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "37,100,44",
            "rgbValue": "112,69,0"
        }
    },
    "badge": {
        "badge0Background": {
            "hexValue": "FF0000",
            "webValue": "FF0000",
            "webName": "red",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,0,0",
            "type": "color"
        },
        "badge0TextColor": {
            "hexValue": "FFFFFF",
            "webValue": "FFFFFF",
            "webName": "white",
            "pantoneName": "",
            "hsvValue": "0,0,100",
            "rgbValue": "255,255,255",
            "type": "color"
        },
        "badge1Background": {
            "hexValue": "00FF00",
            "webValue": "00FF00",
            "webName": "lime",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "0,255,0",
            "type": "color"
        },
        "badge1TextColor": {
            "hexValue": "008000",
            "webValue": "008000",
            "webName": "green",
            "pantoneName": "",
            "hsvValue": "100,100,50",
            "rgbValue": "0,128,0",
            "type": "color"
        },
        "badge2Background": {
            "hexValue": "FFFF00",
            "webValue": "FFFF00",
            "webName": "yellow",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,255,0",
            "type": "color"
        },
        "badge2TextColor": {
            "hexValue": "0000FF",
            "type": "color"
        },
        "badge3Background": {
            "hexValue": "FF00FF",
            "type": "color"
        },
        "badge3TextColor": {
            "hexValue": "FFFF00",
            "webValue": "FFFF00",
            "webName": "yellow",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,255,0",
            "type": "color"
        },
        "badge4Background": {
            "hexValue": "00FFFF",
            "type": "color"
        },
        "badge4TextColor": {
            "hexValue": "0000FF",
            "type": "color"
        },
        "badge5Background": {
            "hexValue": "4CAF50",
            "type": "color"
        },
        "badge5TextColor": {
            "hexValue": "FFEB3B",
            "type": "color"
        },
        "badge6Background": {
            "hexValue": "FFEBEE",
            "type": "color"
        },
        "badge6TextColor": {
            "hexValue": "C62828",
            "type": "color"
        },
        "badge7Background": {
            "hexValue": "1E88E5",
            "type": "color"
        },
        "badge7TextColor": {
            "hexValue": "E3F2FD",
            "type": "color"
        },
        "badge8Background": {
            "hexValue": "FFE082",
            "type": "color"
        },
        "badge8TextColor": {
            "hexValue": "F06292",
            "type": "color"
        }
    },
    "other": {
        "autocompleteInput": {
            "type": "yorno",
            "value": "0"
        }
    },
    "sizes": {
        "menuHeight": 55,
        "footerHeight": 20
    }
};