<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 openDb2();
 $oneError=true;
 // if($fdtoto=fopen('toto.txt','a+')){ fwrite($fdtoto, var_export( $ret , true ) ); fclose($fdtoto); } 
 foreach( $ret['input']['order'] as $k1 => $v1 ){
  $req8='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET fld_menu_order_grpspgs = '.$k1.'
   WHERE fld_group_id_grpspgs = '.$ret['input']['sortListGroupId'].' AND fld_page_id_grpspgs = '.$v1.'
  ' ;
  $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $ret['message']=':-( ' . __FILE__ . ' ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req8='.$req8.'';
  }else{
   require_once($GLOBALS['glob_incPath1'].'/zz_inc_grpspgs1.php');
   $oneError=false;
   updateGrpPgsFiles1();
  }
 }

 if(false===$oneError){
  $ret['status']='OK';
 }else{
  $ret['message']=$someErrors;
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF; 
}