<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();
//========================================================================================================================
if(isset($_GET['setCss']) && is_numeric($_GET['setCss'])){
 include($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/__css.php');
 if(!isset($__css[$_GET['setCss']])){
  $_COOKIE[PGMK.'cssvalue']=1;
  setcookie ( PGMK.'cssvalue' , $_COOKIE[PGMK.'cssvalue'] , time()+3600*24*365);
 }else{
  $_COOKIE[PGMK.'cssvalue']=$_GET['setCss'];
  setcookie ( PGMK.'cssvalue' , $_GET['setCss'] , time()+3600*24*365 );  
 }
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( '?a=b'.urldecode($_GET['redir']) , true ) . '</pre>' ; exit(0);
 header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=b'.str_replace('&amp;','&',urldecode($_GET['redir'])));
 exit(); 
 
}
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_name_css
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_active_css
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_css
if($xsrch_id!=''){
 if(!is_numeric($xsrch_id)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_25_92') . ' : ' . txt2('fld_id_css_25_152');
 }
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; } // fld_name_css
else if($xsrch_1!=''){ $autofocus='xsrch_1'; } // fld_active_css
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_list_35_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="yyfilterForm">'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_name_css_41_39').'</label>'.CRLF; // fld_name_css
$o1.='    <input '.($xsrch_0!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_0" id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_1">'.txt2('fld_active_css_47_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_1!=''?'class="yybackgroundYellow"':'').' name="xsrch_1"  id="xsrch_1" '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='<option value="" '.($xsrch_1==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_1){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_css_25_152').'</label>'.CRLF; // fld_id_css
$o1.='    <input '.($xsrch_id!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_css`         ,T0.`fld_name_css`       ,T0.`fld_active_css`     ,T0.`fld_json_css`       
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__css` T0 
 WHERE 1=1 
';
if($xsrch_0!='' ){
 $req6.='
  AND T0.`fld_name_css` LIKE \'%'.$xsrch_0.'%\'
 '; 
}
if($xsrch_1!='' && is_numeric($xsrch_1)){
 $req6.='
  AND T0.`fld_active_css` = '.$xsrch_1.'
 '; 
}
if($xsrch_id!='' && is_numeric($xsrch_id)){
 $req6.='
  AND T0.`fld_id_css` = '.$xsrch_id.'
 '; 
}
$req6.='
 ORDER BY T0.`fld_id_css` DESC 
'; 
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 $reqCount6='SELECT FOUND_ROWS();';
 $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $mpsrcount6=mysqli_fetch_row($rescount6);
  $__count=$mpsrcount6[0];
 }
 $lsttbl='';
 if($__count==0){
  $lst.='<p>'.CRLF;
  $lst.=''.txt2('no_record_founded_159_17').''.CRLF;
  $lst.='<a href="zz_css_action1.php?a=c">'.txt2('add_a_new_record_160_50').'</a>'.CRLF;
  $lst.='</p>'.CRLF;
  $o1.=''.$lst.''.CRLF;  
 }else{
  $consUrlRedir=''.
                '&amp;xsrch_0='.rawurlencode($xsrch_0). // fld_name_css 
                '&amp;xsrch_1='.rawurlencode($xsrch_1). // fld_active_css 
                '&amp;xsrch_id='.rawurlencode($xsrch_id).
                '';
  $ri=' <span class="yybtn yyunset">&raquo;</span>';
  if($__start+$__nbMax<$__count){
   $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
  }
  $le=' <span class="yybtn yyunset">&laquo;</span>';
  if($__xpage>0){
   $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
  }
  $o1.='<div>';
  $o1.='<form method="post">';
//  $o1.='<button type="submit" name="action1">'.txt0('action1').'</button>';
//  $o1.='<button type="submit" name="action2">'.txt0('action2').'</button>';
  $o1.='<a href="zz_css_action1.php?a=c">'.txt2('add_a_new_record_160_50').'</a>'.CRLF;
  $o1.='&nbsp;'.$le.''.CRLF;  
  $o1.='&nbsp;'.$ri.''.CRLF;  
  $o1.='</form>';
  $o1.='</div>';

  $o1.=getCss1(700); // todo adjust size

//  $o1.=$css;

  $lsttbl.='<thead><tr>';
  $lsttbl.='<th style="min-width:85px;">'.txtsys1('column_action').'</th>';
  $lsttbl.='<th style="min-width:85px;">'.txt2('fld_id_css_25_152').'</th>';
  $lsttbl.='<th>'.txt2('fld_name_css_41_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_active_css_47_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_json_css_239_24').'</th>';
  $lsttbl.='</tr></thead><tbody>';
  while($mpsr6=mysqli_fetch_row($result6)){
   
   $lsttbl.='<tr><td class="fictif"></td>';

   $phpJson=json_decode($mpsr6[3],true);
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $phpJson , true ) . '</pre>' ; exit(0);
   
   $colBack1=$phpJson['main']['mainBackgroundColor']['hexValue'];
   $colBack2=$phpJson['main']['mainBackgroundColEnd']['hexValue'];
   $colText1=$phpJson['main']['mainTextColor']['hexValue'];
   
   $style1=' background-color:#'.$colBack1.';color:#'.$colText1.';text-align:center;';
   
   $lsttbl.='<td data-label="">';
   $lsttbl.='<div class="yyflex1">';
   if($mpsr6[0]>4){
    $lsttbl.='<a class="yydanger yytxtSiz1" href="zz_css_action1.php?a=d&amp;id='.$mpsr6[0].'" title="'.txtsys1('delete_button').'">&#10008;</a>';
   }else{
    $lsttbl.='<span class="yydanger yytxtSiz1 yybtn yyunset" title="'.txtsys1('delete_button').'">&#10008;</span>';    
   }
   $lsttbl.='<a class="yyedit yytxtSiz1" href="zz_css_action1.php?a=u&amp;id='.$mpsr6[0].'" title="'.txtsys1('edit_button').'">&#9998;</a>';
   $lsttbl.='</div>';
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_id_css_25_152').'" style="'.$style1.'">';
   $lsttbl.=''.enti1($mpsr6[0]).''; // fld_id_css
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_name_css_41_39').'" style="'.$style1.'">';
   $lsttbl.='<div style="display:flex;justify-content: space-between;">';
   $lsttbl.='<a class="yysuccess yytxtSiz1" style="border:0;" href="?setCss='.$mpsr6[0].'&amp;redir='.urlencode($consUrlRedir).'" title="'.txt2('use_this_theme_button_193_145').'">⇒</a>';
   $lsttbl.='<span>'.enti1($mpsr6[1]).'</span>'; // fld_name_css
   $lsttbl.='</div>';
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_active_css_47_39').'" style="'.$style1.'">';
   require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
   $lsttbl.=displayParam1('yorno',$mpsr6[2]); // fld_active_css
   $lsttbl.='</td>';


   $lsttbl.='<td data-label="'.txt2('fld_json_css_239_24').'" style="'.$style1.'word-break:break-all;">';
   $lsttbl.=''.enti1(substr($mpsr6[3],0,100)).''; // fld_json_css
   $lsttbl.='</td>';

   $lsttbl.='<td class="fictif"></td></tr>';
   
  }
  $o1.='<table class="yytableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF; // table-condensed
   
  $o1.=' <div>'.CRLF;
  $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_307_99').' )'.CRLF;
  $o1.='   &nbsp;<a href="zz_css_action1.php?a=c">'.txt2('add_a_new_record_160_50').'</a>'.CRLF;
  $o1.=' </div>'.CRLF;
   
 }
 mysqli_free_result($result6);
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
}
$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
