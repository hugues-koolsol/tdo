<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_name_uploadedDocs
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_originalName_uploadedDocs
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_isPicture_uploadedDocs
$xsrch_3=saveSessionSearch1('xsrch_3',BNF);// fld_pictureWidth_uploadedDocs
$xsrch_4=saveSessionSearch1('xsrch_4',BNF);// fld_pictureHeight_uploadedDocs
$xsrch_5=saveSessionSearch1('xsrch_5',BNF);// fld_documentType_uploadedDocs
$xsrch_6=saveSessionSearch1('xsrch_6',BNF);// fld_weight_uploadedDocs
$xsrch_7=saveSessionSearch1('xsrch_7',BNF);// fld_path_uploadedDocs
$xsrch_8=saveSessionSearch1('xsrch_8',BNF);// fld_userId_uploadedDocs
$xsrch_9=saveSessionSearch1('xsrch_9',BNF);// fld_firstname_users of parent table
$xsrch_10=saveSessionSearch1('xsrch_10',BNF);// fld_lastname_users of parent table
$xsrch_sort=saveSessionSearch1('xsrch_sort',BNF);
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_uploadedDocs
if($xsrch_8!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_8);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if(!$listIdsOk){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_42_92') . ' : ' . txt2('fld_userId_uploadedDocs_42_152');
 }
}
if($xsrch_3!=''){
 if(!is_numeric($xsrch_3)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_29_92') . ' : ' . txt2('fld_pictureWidth_uploadedDocs_29_152');
 }
}
if($xsrch_4!=''){
 if(!is_numeric($xsrch_4)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_29_92') . ' : ' . txt2('fld_pictureHeight_uploadedDocs_34_152');
 }
}
if($xsrch_6!=''){
 if(!is_numeric($xsrch_6)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_29_92') . ' : ' . txt2('fld_weight_uploadedDocs_39_152');
 }
}
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if(!$listIdsOk){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_42_92') . ' : ' . txt2('fld_id_uploadedDocs_71_152');
 }
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; } // fld_name_uploadedDocs
else if($xsrch_1!=''){ $autofocus='xsrch_1'; } // fld_originalName_uploadedDocs
else if($xsrch_2!=''){ $autofocus='xsrch_2'; } // fld_isPicture_uploadedDocs
else if($xsrch_3!=''){ $autofocus='xsrch_3'; } // fld_pictureWidth_uploadedDocs
else if($xsrch_4!=''){ $autofocus='xsrch_4'; } // fld_pictureHeight_uploadedDocs
else if($xsrch_5!=''){ $autofocus='xsrch_5'; } // fld_documentType_uploadedDocs
else if($xsrch_6!=''){ $autofocus='xsrch_6'; } // fld_weight_uploadedDocs
else if($xsrch_7!=''){ $autofocus='xsrch_7'; } // fld_path_uploadedDocs
else if($xsrch_8!=''){ $autofocus='xsrch_8'; } // fld_userId_uploadedDocs link to parent table
else if($xsrch_9!=''){ $autofocus='xsrch_9'; } // fld_firstname_users of parent table
else if($xsrch_10!=''){ $autofocus='xsrch_10'; } // fld_lastname_users of parent table
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array());
$o1.='<h1>'.txt2('page_title_list_58_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="yyfilterForm">'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_name_uploadedDocs_64_39').'</label>'.CRLF; // fld_name_uploadedDocs
$o1.='    <input '.($xsrch_0!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_0" id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_1">'.txt2('fld_originalName_uploadedDocs_70_39').'</label>'.CRLF; // fld_originalName_uploadedDocs
$o1.='    <input '.($xsrch_1!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_1" id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_2">'.txt2('fld_isPicture_uploadedDocs_76_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_2!=''?'class="yybackgroundYellow"':'').' name="xsrch_2"  id="xsrch_2" '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" />'.CRLF;
$o1.='<option value="" '.($xsrch_2==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_2){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_3">'.txt2('fld_pictureWidth_uploadedDocs_29_152').'</label>'.CRLF; // fld_pictureWidth_uploadedDocs
$o1.='    <input '.($xsrch_3!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_3" id="xsrch_3"   value="'.enti1($xsrch_3).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_3'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_4">'.txt2('fld_pictureHeight_uploadedDocs_34_152').'</label>'.CRLF; // fld_pictureHeight_uploadedDocs
$o1.='    <input '.($xsrch_4!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_4" id="xsrch_4"   value="'.enti1($xsrch_4).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_4'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_5">'.txt2('fld_documentType_uploadedDocs_103_39').'</label>'.CRLF; // fld_documentType_uploadedDocs
$o1.='    <input '.($xsrch_5!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_5" id="xsrch_5"   value="'.enti1($xsrch_5).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_5'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_6">'.txt2('fld_weight_uploadedDocs_39_152').'</label>'.CRLF; // fld_weight_uploadedDocs
$o1.='    <input '.($xsrch_6!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_6" id="xsrch_6"   value="'.enti1($xsrch_6).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_6'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_7">'.txt2('fld_path_uploadedDocs_115_39').'</label>'.CRLF; // fld_path_uploadedDocs
$o1.='    <input '.($xsrch_7!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_7" id="xsrch_7"   value="'.enti1($xsrch_7).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_7'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_uploadedDocs_44_152').'</label>'.CRLF; // fld_id_uploadedDocs
$o1.='    <input '.($xsrch_id!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_8">'.txt2('fld_userId_uploadedDocs_42_152').'</label>'.CRLF; // fld_userId_uploadedDocs
$o1.='    <input '.($xsrch_8!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_8" id="xsrch_8"   value="'.enti1($xsrch_8).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_8'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

// field fld_firstname_users of parent table

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_9">'.txt2('T1.fld_firstname_users_164_39').'</label>'.CRLF; // fld_firstname_users
$o1.='    <input '.($xsrch_9!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_9" id="xsrch_9"   value="'.enti1($xsrch_9).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_9'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

// field fld_lastname_users of parent table

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_10">'.txt2('T1.fld_lastname_users_171_40').'</label>'.CRLF; // fld_lastname_users
$o1.='    <input '.($xsrch_10!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_10" id="xsrch_10"   value="'.enti1($xsrch_10).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_10'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_sort">'.txtsys1('sort_order').'</label>'.CRLF; // sort
$o1.='    <select '.($xsrch_sort!=''?'class="yybackgroundYellow"':'').' name="xsrch_sort"  id="xsrch_sort" '.($autofocus=='xsrch_sort'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='     <option value="" '.($xsrch_sort==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_name_uploadedDocs_ASC'.'"          '.($xsrch_sort=='T0.fld_name_uploadedDocs_ASC'          ?' selected="selected" ':'').'>&#8599; '.txt2('fld_name_uploadedDocs_179_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_name_uploadedDocs_DESC'.'"          '.($xsrch_sort=='T0.fld_name_uploadedDocs_DESC'          ?' selected="selected" ':'').'>&#8600; '.txt2('fld_name_uploadedDocs_179_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_originalName_uploadedDocs_ASC'.'"  '.($xsrch_sort=='T0.fld_originalName_uploadedDocs_ASC'  ?' selected="selected" ':'').'>&#8599; '.txt2('fld_originalName_uploadedDocs_181_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_originalName_uploadedDocs_DESC'.'"  '.($xsrch_sort=='T0.fld_originalName_uploadedDocs_DESC'  ?' selected="selected" ':'').'>&#8600; '.txt2('fld_originalName_uploadedDocs_181_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_pictureWidth_uploadedDocs_ASC'.'"  '.($xsrch_sort=='T0.fld_pictureWidth_uploadedDocs_ASC'  ?' selected="selected" ':'').'>&#8599; '.txt2('fld_pictureWidth_uploadedDocs_183_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_pictureWidth_uploadedDocs_DESC'.'"  '.($xsrch_sort=='T0.fld_pictureWidth_uploadedDocs_DESC'  ?' selected="selected" ':'').'>&#8600; '.txt2('fld_pictureWidth_uploadedDocs_183_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_pictureHeight_uploadedDocs_ASC'.'" '.($xsrch_sort=='T0.fld_pictureHeight_uploadedDocs_ASC' ?' selected="selected" ':'').'>&#8599; '.txt2('fld_pictureHeight_uploadedDocs_185_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_pictureHeight_uploadedDocs_DESC'.'" '.($xsrch_sort=='T0.fld_pictureHeight_uploadedDocs_DESC' ?' selected="selected" ':'').'>&#8600; '.txt2('fld_pictureHeight_uploadedDocs_185_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_documentType_uploadedDocs_ASC'.'"  '.($xsrch_sort=='T0.fld_documentType_uploadedDocs_ASC'  ?' selected="selected" ':'').'>&#8599; '.txt2('fld_documentType_uploadedDocs_187_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_documentType_uploadedDocs_DESC'.'"  '.($xsrch_sort=='T0.fld_documentType_uploadedDocs_DESC'  ?' selected="selected" ':'').'>&#8600; '.txt2('fld_documentType_uploadedDocs_187_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_weight_uploadedDocs_ASC'.'" '.($xsrch_sort=='T0.fld_weight_uploadedDocs_ASC' ?' selected="selected" ':'').'>&#8599; '.txt2('fld_weight_uploadedDocs_189_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_weight_uploadedDocs_DESC'.'" '.($xsrch_sort=='T0.fld_weight_uploadedDocs_DESC' ?' selected="selected" ':'').'>&#8600; '.txt2('fld_weight_uploadedDocs_189_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_path_uploadedDocs_ASC'.'"          '.($xsrch_sort=='T0.fld_path_uploadedDocs_ASC'          ?' selected="selected" ':'').'>&#8599; '.txt2('fld_path_uploadedDocs_191_174').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_path_uploadedDocs_DESC'.'"          '.($xsrch_sort=='T0.fld_path_uploadedDocs_DESC'          ?' selected="selected" ':'').'>&#8600; '.txt2('fld_path_uploadedDocs_191_174').'</option>'.CRLF;
if($_SESSION[PGMK]['login']==1){
 $o1.='     <option value="'.'T0.fld_userId_uploadedDocs_ASC'.'"        '.($xsrch_sort=='T0.fld_userId_uploadedDocs_ASC'        ?' selected="selected" ':'').'>&#8599; '.txt2('fld_userId_uploadedDocs_42_152').'</option>'.CRLF;
 $o1.='     <option value="'.'T0.fld_userId_uploadedDocs_DESC'.'"        '.($xsrch_sort=='T0.fld_userId_uploadedDocs_DESC'        ?' selected="selected" ':'').'>&#8600; '.txt2('fld_userId_uploadedDocs_42_152').'</option>'.CRLF;
 $o1.='     <option value="'.'T1.fld_firstname_users'.'"            '.($xsrch_sort=='T1.fld_firstname_users_ASC'            ?' selected="selected" ':'').'>&#8599; '.txt2('T1.fld_firstname_users_164_39').'</option>'.CRLF;
 $o1.='     <option value="'.'T1.fld_firstname_users'.'"            '.($xsrch_sort=='T1.fld_firstname_users_DESC'            ?' selected="selected" ':'').'>&#8600; '.txt2('T1.fld_firstname_users_164_39').'</option>'.CRLF;
 $o1.='     <option value="'.'T1.fld_lastname_users'.'"             '.($xsrch_sort=='T1.fld_lastname_users_ASC'             ?' selected="selected" ':'').'>&#8599; '.txt2('T1.fld_lastname_users_171_40').'</option>'.CRLF;
 $o1.='     <option value="'.'T1.fld_lastname_users'.'"             '.($xsrch_sort=='T1.fld_lastname_users_DESC'             ?' selected="selected" ':'').'>&#8600; '.txt2('T1.fld_lastname_users_171_40').'</option>'.CRLF;
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_uploadedDocs`            ,T0.`fld_name_uploadedDocs`          ,T0.`fld_originalName_uploadedDocs`  ,T0.`fld_isPicture_uploadedDocs`     ,T0.`fld_pictureWidth_uploadedDocs`  ,
   T0.`fld_pictureHeight_uploadedDocs` ,T0.`fld_documentType_uploadedDocs`  ,T0.`fld_weight_uploadedDocs` ,T0.`fld_path_uploadedDocs`          ,T0.`fld_userId_uploadedDocs`        ,
   T1.`fld_firstname_users`            ,T1.`fld_lastname_users` 
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__uploadeddocs` T0 
        , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` T1 ) 
 WHERE 1=1 
   AND T0.`fld_userId_uploadedDocs`=T1.`fld_id_users`
';
if($_SESSION[PGMK]['login']!=1){
 $req6.='
  AND T0.`fld_userId_uploadedDocs` = '.$_SESSION[PGMK]['login'].'
 '; 
}
if($xsrch_0!='' ){
 $req6.='
  AND T0.`fld_name_uploadedDocs` LIKE \'%'.addslashes1($xsrch_0).'%\'
 '; 
}
if($xsrch_1!='' ){
 $req6.='
  AND T0.`fld_originalName_uploadedDocs` LIKE \'%'.addslashes1($xsrch_1).'%\'
 '; 
}
if($xsrch_2!='' ){
 $req6.='
  AND T0.`fld_isPicture_uploadedDocs` LIKE \'%'.addslashes1($xsrch_2).'%\'
 '; 
}
if($xsrch_3!='' && is_numeric($xsrch_3)){
 $req6.='
  AND T0.`fld_pictureWidth_uploadedDocs` = '.$xsrch_3.'
 '; 
}
if($xsrch_4!='' && is_numeric($xsrch_4)){
 $req6.='
  AND T0.`fld_pictureHeight_uploadedDocs` = '.$xsrch_4.'
 '; 
}
if($xsrch_5!='' ){
 $req6.='
  AND T0.`fld_documentType_uploadedDocs` LIKE \'%'.addslashes1($xsrch_5).'%\'
 '; 
}
if($xsrch_6!='' && is_numeric($xsrch_6)){
 $req6.='
  AND T0.`fld_weight_uploadedDocs` = '.$xsrch_6.'
 '; 
}
if($xsrch_7!='' ){
 $req6.='
  AND T0.`fld_path_uploadedDocs` LIKE \'%'.addslashes1($xsrch_7).'%\'
 '; 
}

if($_SESSION[PGMK]['login']==1){
 if($xsrch_8!=''){
  $xsrch_ids=str_replace('.',',',$xsrch_8);
  $xsrch_ids=explode(',',$xsrch_ids);
  $listIdsOk=true;
  foreach($xsrch_ids as $v1){
   if(!is_numeric($v1)){
    $listIdsOk=false;
    break;
   }
  }
  if($listIdsOk){
   $req6.='
    AND T0.`fld_userId_uploadedDocs` IN ('.implode(',',$xsrch_ids).') 
   '; 
  }
 }
 // field fld_firstname_users of parent table
 if($xsrch_9!='' ){
  $req6.='
   AND T1.`fld_firstname_users` LIKE \'%'.addslashes1($xsrch_9).'%\'
  '; 
 }
 // field fld_lastname_users of parent table
 if($xsrch_10!='' ){
  $req6.='
   AND T1.`fld_lastname_users` LIKE \'%'.addslashes1($xsrch_10).'%\'
  '; 
 }
}

if($xsrch_id!='' && is_numeric($xsrch_id)){
 $req6.='
  AND T0.`fld_id_uploadedDocs` = '.$xsrch_id.'
 '; 
}
// adjust the order
if($xsrch_sort==''){ $req6.='ORDER BY T0.`fld_id_uploadedDocs` DESC ';}
if($xsrch_sort=='T0.fld_name_uploadedDocs_ASC'){           $req6.=' ORDER BY T0.`fld_name_uploadedDocs` ASC  '; }
if($xsrch_sort=='T0.fld_name_uploadedDocs_DESC'){           $req6.=' ORDER BY T0.`fld_name_uploadedDocs` DESC  '; }
if($xsrch_sort=='T0.fld_originalName_uploadedDocs_ASC'){   $req6.=' ORDER BY T0.`fld_originalName_uploadedDocs` ASC  '; }
if($xsrch_sort=='T0.fld_originalName_uploadedDocs_DESC'){   $req6.=' ORDER BY T0.`fld_originalName_uploadedDocs` DESC  '; }
if($xsrch_sort=='T0.fld_pictureWidth_uploadedDocs_ASC'){   $req6.=' ORDER BY T0.`fld_pictureWidth_uploadedDocs` ASC  '; }
if($xsrch_sort=='T0.fld_pictureWidth_uploadedDocs_DESC'){   $req6.=' ORDER BY T0.`fld_pictureWidth_uploadedDocs` DESC  '; }
if($xsrch_sort=='T0.fld_pictureHeight_uploadedDocs_ASC'){  $req6.=' ORDER BY T0.`fld_pictureHeight_uploadedDocs` ASC  '; }
if($xsrch_sort=='T0.fld_pictureHeight_uploadedDocs_DESC'){  $req6.=' ORDER BY T0.`fld_pictureHeight_uploadedDocs` DESC  '; }
if($xsrch_sort=='T0.fld_documentType_uploadedDocs_ASC'){   $req6.=' ORDER BY T0.`fld_documentType_uploadedDocs` ASC  '; }
if($xsrch_sort=='T0.fld_documentType_uploadedDocs_DESC'){   $req6.=' ORDER BY T0.`fld_documentType_uploadedDocs` DESC  '; }
if($xsrch_sort=='T0.fld_weight_uploadedDocs_ASC'){  $req6.=' ORDER BY T0.`fld_weight_uploadedDocs` ASC  '; }
if($xsrch_sort=='T0.fld_weight_uploadedDocs_DESC'){  $req6.=' ORDER BY T0.`fld_weight_uploadedDocs` DESC  '; }
if($xsrch_sort=='T0.fld_path_uploadedDocs_ASC'){           $req6.=' ORDER BY T0.`fld_path_uploadedDocs` ASC  '; }
if($xsrch_sort=='T0.fld_path_uploadedDocs_DESC'){           $req6.=' ORDER BY T0.`fld_path_uploadedDocs` DESC  '; }
if($xsrch_sort=='T0.fld_userId_uploadedDocs_ASC'){         $req6.=' ORDER BY T0.`fld_userId_uploadedDocs` ASC  '; }
if($xsrch_sort=='T0.fld_userId_uploadedDocs_DESC'){         $req6.=' ORDER BY T0.`fld_userId_uploadedDocs` DESC  '; }
if($xsrch_sort=='T1.fld_firstname_users_ASC'){             $req6.=' ORDER BY T1.`fld_firstname_users` ASC ';}
if($xsrch_sort=='T1.fld_firstname_users_DESC'){             $req6.=' ORDER BY T1.`fld_firstname_users` DESC ';}
if($xsrch_sort=='T1.fld_lastname_users_ASC'){              $req6.=' ORDER BY T1.`fld_lastname_users` ASC ';}
if($xsrch_sort=='T1.fld_lastname_users_DESC'){              $req6.=' ORDER BY T1.`fld_lastname_users` DESC ';}

$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$__count=0;
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'T0.fld_id_uploadedDocs'            =>$mpsr6[0], 
  'T0.fld_name_uploadedDocs'          =>$mpsr6[1], 
  'T0.fld_originalName_uploadedDocs'  =>$mpsr6[2], 
  'T0.fld_isPicture_uploadedDocs'     =>$mpsr6[3], 
  'T0.fld_pictureWidth_uploadedDocs'  =>$mpsr6[4], 
  'T0.fld_pictureHeight_uploadedDocs' =>$mpsr6[5], 
  'T0.fld_documentType_uploadedDocs'  =>$mpsr6[6], 
  'T0.fld_weight_uploadedDocs' =>$mpsr6[7], 
  'T0.fld_path_uploadedDocs'          =>$mpsr6[8], 
  'T0.fld_userId_uploadedDocs'        =>$mpsr6[9],
  'T1.fld_firstname_users'            =>$mpsr6[10],
  'T1.fld_lastname_users'             =>$mpsr6[11],
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}
$lsttbl='';
if($__count==0){
 $lst.='<p>'.CRLF;
 $lst.=''.txt2('no_record_founded_224_16').''.CRLF;
 $lst.='<a href="uploadeddocs_action1.php?a=c">'.txt2('add_a_new_record_225_55').'</a>'.CRLF;
 $lst.='</p>'.CRLF;
 $o1.=''.$lst.''.CRLF;  
}else{
 $consUrlRedir=''.
               '&xsrch_0='.rawurlencode($xsrch_0). // fld_name_uploadedDocs 
               '&xsrch_1='.rawurlencode($xsrch_1). // fld_originalName_uploadedDocs 
               '&xsrch_2='.rawurlencode($xsrch_2). // fld_isPicture_uploadedDocs 
               '&xsrch_3='.rawurlencode($xsrch_3). // fld_pictureWidth_uploadedDocs 
               '&xsrch_4='.rawurlencode($xsrch_4). // fld_pictureHeight_uploadedDocs 
               '&xsrch_5='.rawurlencode($xsrch_5). // fld_documentType_uploadedDocs 
               '&xsrch_6='.rawurlencode($xsrch_6). // fld_weight_uploadedDocs 
               '&xsrch_7='.rawurlencode($xsrch_7). // fld_path_uploadedDocs 
               '&xsrch_id='.rawurlencode($xsrch_id).
               '';
 if($_SESSION[PGMK]['login']==1){
  $consUrlRedir.=''.               
               ($xsrch_8!=''?'&amp;xsrch_8='.rawurlencode($xsrch_8):''). // fld_userId_uploadedDocs 
                ($xsrch_9!=''?'&amp;xsrch_9='.rawurlencode($xsrch_9):''). // fld_firstname_users of parent
                ($xsrch_10!=''?'&amp;xsrch_10='.rawurlencode($xsrch_10):''). // fld_lastname_users of parent
               '';
 }
               
 $ri=' <span class="yybtn yyunset">&raquo;</span>';
 if($__start+$__nbMax<$__count){
  $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
 }
 $le=' <span class="yybtn yyunset">&laquo;</span>';
 if($__xpage>0){
  $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
 }

 $o1.='<div>';
 $o1.='<form method="post" class="yylistForm1">';
 $o1.=' <a href="uploadeddocs_action1.php?a=c">'.txt2('add_a_new_record_225_55').'</a>'.CRLF;
 $o1.='  '.$le.' '.$ri.' <div style="display:inline-block;">page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_330_98').' )</div>'.CRLF;
 $o1.='</form>';
 $o1.='</div>';

 $o1.=getCss1(890);

 $lsttbl.='<thead><tr>';
 $lsttbl.='<th style="min-width:125px;">'.txtsys1('column_action').'</th>';
 $lsttbl.='<th style="min-width:85px;">'.txt2('fld_id_uploadedDocs_44_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_name_uploadedDocs_64_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_originalName_uploadedDocs_70_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_isPicture_uploadedDocs_76_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_pictureWidth_uploadedDocs_29_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_pictureHeight_uploadedDocs_34_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_documentType_uploadedDocs_103_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_weight_uploadedDocs_39_152').'</th>';
// $lsttbl.='<th>'.txt2('fld_path_uploadedDocs_115_39').'</th>';
 if($_SESSION[PGMK]['login']==1){
  $lsttbl.='<th>'.txt2('fld_userId_uploadedDocs_42_152').'</th>';
  $lsttbl.='<th>'.txt2('T1.fld_firstname_users_164_39').'</th>'; // ======== parent field of fld_userId_uploadedDocs
  $lsttbl.='<th>'.txt2('T1.fld_lastname_users_171_40').'</th>'; // ======== parent field of fld_userId_uploadedDocs
 }
 
 $lsttbl.='</tr></thead><tbody>';

 foreach($data0 as $k0=>$v0){

  $lsttbl.='<tr><td class="yyfictif"></td>';

  $lsttbl.='<td data-label="'.txtsys1('column_action').'">';
  $lsttbl.='<div class="yyflex1">';
  $lsttbl.='<a class="yytxtSiz1 yydanger" href="uploadeddocs_action1.php?a=d&id='.$v0['T0.fld_id_uploadedDocs'].'"  title="'.txtsys1('delete_button').'">✘</a>';//✘ #10008
  $lsttbl.='<a class="yytxtSiz2"        href="uploadeddocs_action1.php?a=du&id='.$v0['T0.fld_id_uploadedDocs'].'" title="'.txtsys1('duplicate_button').'">&#x2398;</a>';// ⎘:x2398 📋:#128203
  $lsttbl.='<a class="yytxtSiz1 yyedit"   href="uploadeddocs_action1.php?a=u&id='.$v0['T0.fld_id_uploadedDocs'].'"  title="'.txtsys1('edit_button').'">&#9998;</a>';//✎ #9998
  $lsttbl.='</div>';
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_id_uploadedDocs_44_152').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_id_uploadedDocs'].''; // fld_id_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_name_uploadedDocs_64_39').'">';
  $lsttbl.=''.$v0['T0.fld_name_uploadedDocs'].''; // fld_name_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_originalName_uploadedDocs_70_39').'">';
  $lsttbl.=' <a class="noHide yysuccess" href="zz_uploadDocument.php?fld_id_uploadedDocs='.$v0['T0.fld_id_uploadedDocs'].'">upload</a>';
  $lsttbl.=' '.$v0['T0.fld_originalName_uploadedDocs'].''; // fld_originalName_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_isPicture_uploadedDocs_76_39').'" style="text-align:center;">';
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $lsttbl.=displayParam1('yorno',$v0['T0.fld_isPicture_uploadedDocs'],array('unsetPossible'=>false)); // fld_isPicture_uploadedDocs

  
  
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_pictureWidth_uploadedDocs_29_152').'" style="text-align:right;">';
  $lsttbl.=''.$v0['T0.fld_pictureWidth_uploadedDocs'].''; // fld_pictureWidth_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_pictureHeight_uploadedDocs_34_152').'" style="text-align:right;">';
  $lsttbl.=''.$v0['T0.fld_pictureHeight_uploadedDocs'].''; // fld_pictureHeight_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_documentType_uploadedDocs_103_39').'">';
  $lsttbl.=''.$v0['T0.fld_documentType_uploadedDocs'].''; // fld_documentType_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_weight_uploadedDocs_39_152').'" style="text-align:right;">';
  $lsttbl.=''.$v0['T0.fld_weight_uploadedDocs'].''; // fld_weight_uploadedDocs
  $lsttbl.='</td>';
/*
  $lsttbl.='<td data-label="'.txt2('fld_path_uploadedDocs_115_39').'">';
  $lsttbl.=''.$v0['T0.fld_path_uploadedDocs'].''; // fld_path_uploadedDocs
  $lsttbl.='</td>';
*/  
  if($_SESSION[PGMK]['login']==1){

   $lsttbl.='<td data-label="'.txt2('fld_userId_uploadedDocs_42_152').'" style="text-align:center;">';
   $lsttbl.=''.enti1($v0['T0.fld_userId_uploadedDocs']).''; // fld_userId_uploadedDocs
   $lsttbl.='</td>';


 // field display of the parent table fld_firstname_users
   if($v0['T1.fld_firstname_users']===0||is_null($v0['T1.fld_firstname_users'])){
    $lsttbl.='<td data-label="'.txt2('T1.fld_firstname_users_164_39').'"></td>'; 
   }else{
    $lsttbl.='<td data-label="'.txt2('T1.fld_firstname_users_164_39').'">';
    $lsttbl.=''.enti1($v0['T1.fld_firstname_users']).''; // fld_firstname_users
    $lsttbl.='</td>';
   }



 // field display of the parent table fld_lastname_users
   if($v0['T1.fld_lastname_users']===0||is_null($v0['T1.fld_lastname_users'])){
    $lsttbl.='<td data-label="'.txt2('T1.fld_lastname_users_171_40').'"></td>'; 
   }else{
    $lsttbl.='<td data-label="'.txt2('T1.fld_lastname_users_171_40').'">';
    $lsttbl.=''.enti1($v0['T1.fld_lastname_users']).''; // fld_lastname_users
    $lsttbl.='</td>';
   }

  }  
  
  $lsttbl.='<td class="yyfictif"></td></tr>';

 }

 $o1.='<table class="yytableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;

 $o1.=' <div class="yylistForm1">'.CRLF;
 $o1.='   <a class="" href="uploadeddocs_action1.php?a=c">'.txt2('add_a_new_record_225_55').'</a>'.CRLF;
 $o1.='   '.$le.' '.$ri.' <div style="display:inline-block;">page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_330_98').' )</div>'.CRLF;
 $o1.=' </div>'.CRLF;

}

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
