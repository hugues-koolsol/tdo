<?php
// setup for databases
if($GLOBALS['glob_isLocalHost']){
 $GLOBALS['glob_db'][0]['server']   ='localhost:3306';
 $GLOBALS['glob_db'][0]['user']     ='admin';
 $GLOBALS['glob_db'][0]['password'] ='admin';
 $GLOBALS['glob_db'][0]['dbname']   ='tdo';
 $GLOBALS['glob_db'][0]['setname']  ='utf8mb4';
 $GLOBALS['glob_db'][0]['link']     =null;
}else{
 $GLOBALS['glob_db'][0]['server']   ='mmmmmmmmmccc1.sql-pro.oooooo.nnn';
 $GLOBALS['glob_db'][0]['user']     ='mmmmmmmmmccc1';
 $GLOBALS['glob_db'][0]['password'] ='zzzzzzzzzzzzz';
 $GLOBALS['glob_db'][0]['dbname']   ='mmmmmmmmmccc1';
 $GLOBALS['glob_db'][0]['setname']  ='utf8';
 $GLOBALS['glob_db'][0]['link']     =null; 
}

