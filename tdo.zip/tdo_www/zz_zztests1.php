<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
require_once($GLOBALS['glob_dataPath1'].'/generated/_params/country.php');
checkGroupPages();
openDb2();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_yorno1_zztests
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_visited_countries_zztests
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_country1_zztests
$xsrch_3=saveSessionSearch1('xsrch_3',BNF);// fld_title32_zztests
$xsrch_4=saveSessionSearch1('xsrch_4',BNF);// fld_id_parent_zztests
$xsrch_5=saveSessionSearch1('xsrch_5',BNF);// fld_title32_zztests of parent table
$xsrch_6=saveSessionSearch1('xsrch_6',BNF);// fld_yorno1_zztests of parent table
$xsrch_7=saveSessionSearch1('xsrch_7',BNF);// fld_zipnum1_zztests of parent table
$xsrch_8=saveSessionSearch1('xsrch_8',BNF);// fld_date1_zztests
$xsrch_9=saveSessionSearch1('xsrch_9',BNF);// fld_time1_zztests
$xsrch_10=saveSessionSearch1('xsrch_10',BNF);// fld_dttim1_zztests
$xsrch_11=saveSessionSearch1('xsrch_11',BNF);// fld_color1_zztests
$xsrch_12=saveSessionSearch1('xsrch_12',BNF);// fld_email1_zztests
$xsrch_13=saveSessionSearch1('xsrch_13',BNF);// fld_zipnum1_zztests
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_zztests
if($xsrch_4!=''){
 if(!is_numeric($xsrch_4)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_37_92') . ' : ' . txt2('fld_id_parent_zztests_37_152');
 }
}
if($xsrch_7!=''){
 if(!is_numeric($xsrch_7)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_37_92') . ' : ' . txt2('fld_zipnum1_zztests_42_152');
 }
}
if($xsrch_13!=''){
 if(!is_numeric($xsrch_13)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_37_92') . ' : ' . txt2('fld_zipnum1_zztests_42_152');
 }
}
if($xsrch_id!=''){
 if(!is_numeric($xsrch_id)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_37_92') . ' : ' . txt2('fld_id_zztests_52_152');
 }
}
if(is_array($xsrch_1) && sizeof($xsrch_1)==1 && $xsrch_1[0]==''){ // fld_visited_countries_zztests
 $xsrch_1='';
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; } // fld_yorno1_zztests
else if($xsrch_1!=''){ $autofocus='xsrch_1'; } // fld_visited_countries_zztests
else if($xsrch_2!=''){ $autofocus='xsrch_2'; } // fld_country1_zztests
else if($xsrch_3!=''){ $autofocus='xsrch_3'; } // fld_title32_zztests
else if($xsrch_4!=''){ $autofocus='xsrch_4'; } // fld_id_parent_zztests link to parent table
else if($xsrch_5!=''){ $autofocus='xsrch_5'; } // fld_title32_zztests of parent table
else if($xsrch_6!=''){ $autofocus='xsrch_6'; } // fld_yorno1_zztests of parent table
else if($xsrch_7!=''){ $autofocus='xsrch_7'; } // fld_zipnum1_zztests of parent table
else if($xsrch_8!=''){ $autofocus='xsrch_8'; } // fld_date1_zztests
else if($xsrch_9!=''){ $autofocus='xsrch_9'; } // fld_time1_zztests
else if($xsrch_10!=''){ $autofocus='xsrch_10'; } // fld_dttim1_zztests
else if($xsrch_11!=''){ $autofocus='xsrch_11'; } // fld_color1_zztests
else if($xsrch_12!=''){ $autofocus='xsrch_12'; } // fld_email1_zztests
else if($xsrch_13!=''){ $autofocus='xsrch_13'; } // fld_zipnum1_zztests
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_list_75_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="filterForm">'.CRLF;
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_yorno1_zztests_80_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_0!=''?'class="backgroundYellow"':'').' name="xsrch_0"  id="xsrch_0" '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" />'.CRLF;
$o1.='<option value="" '.($xsrch_0==''?'  selected="selected" ':'').'> </option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_0){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
if('NULL'==(string)$xsrch_0){
 $o1.='<option value="NULL"  selected="selected">'.txtsys1('undefined').'</option>'.CRLF;  
}else{
 $o1.='<option value="NULL">'.txtsys1('undefined').'</option>'.CRLF;   
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_1">'.txt2('fld_visited_countries_zztests_99_39').'</label>'.CRLF;
$o1.='    <select size="3" name="xsrch_1[]"   multiple="multiple" style="max-width:10em;" id="xsrch_1" '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' ';
if(is_array($xsrch_1)){
 if($xsrch_1[0]!=''){
  $o1.=' class="backgroundYellow" ';
 }
}else{
 if($xsrch_1!=''){$o1.=' class="backgroundYellow" ';}
}
$o1.='  >'.CRLF;
$o1.='<option value="" '.($xsrch_1==''?'  selected="selected" ':'').'> </option>'.CRLF;
if(!is_array($xsrch_1)) $xsrch_1=array();
if(is_array($xsrch_1) && in_array( '__all_values_of_set__' , $xsrch_1 )){
 $o1.='<option value="__all_values_of_set__" selected="selected" >'.txtsys1('all_values_of_set_list').'</option>'.CRLF;
}else{
 $o1.='<option value="__all_values_of_set__">'.txtsys1('all_values_of_set_list').'</option>'.CRLF; 
}
foreach($GLOBALS['param__country']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if(in_array($kp,$xsrch_1)){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__country']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__country']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_2">'.txt2('fld_country1_zztests_127_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_2!=''?'class="backgroundYellow"':'').' name="xsrch_2"  id="xsrch_2" '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" />'.CRLF;
$o1.='<option value="" '.($xsrch_2==''?'  selected="selected" ':'').'> </option>'.CRLF;
foreach($GLOBALS['param__country']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_2){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__country']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__country']['param__Name__Display']].' </option>'.CRLF;  
 }
}
if('NULL'==(string)$xsrch_2){
 $o1.='<option value="NULL"  selected="selected">'.txtsys1('undefined').'</option>'.CRLF;  
}else{
 $o1.='<option value="NULL">'.txtsys1('undefined').'</option>'.CRLF;   
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_3">'.txt2('fld_title32_zztests_147_39').'</label>'.CRLF; // fld_title32_zztests
$o1.='    <input '.($xsrch_3!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_3" id="xsrch_3"   value="'.enti1($xsrch_3).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_3'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_4">'.txt2('fld_id_parent_zztests_37_152').'</label>'.CRLF; // fld_id_parent_zztests
$o1.='    <input '.($xsrch_4!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_4" id="xsrch_4"   value="'.enti1($xsrch_4).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_4'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

// field fld_title32_zztests of parent table

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_5">'.txt2('T1.fld_title32_zztests_161_39').'</label>'.CRLF; // fld_title32_zztests
$o1.='    <input '.($xsrch_5!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_5" id="xsrch_5"   value="'.enti1($xsrch_5).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_5'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $xsrch_6 , true ) . '</pre>' ; exit(0);
// field fld_yorno1_zztests of parent table
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_6">'.txt2('T1.fld_yorno1_zztests_167_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_6!=''?'class="backgroundYellow"':'').' name="xsrch_6"  id="xsrch_6" '.($autofocus=='xsrch_6'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" />'.CRLF;
$o1.='<option value="" '.($xsrch_6==''?'  selected="selected" ':'').'> </option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_6){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
if('NULL'==(string)$xsrch_6){
 $o1.='<option value="NULL"  selected="selected">'.txtsys1('undefined').'</option>'.CRLF;  
}else{
 $o1.='<option value="NULL">'.txtsys1('undefined').'</option>'.CRLF;   
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;

// field fld_zipnum1_zztests of parent table

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_7">'.txt2('T1.fld_zipnum1_zztests_188_39').'</label>'.CRLF; // fld_zipnum1_zztests
$o1.='    <input '.($xsrch_7!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_7" id="xsrch_7"   value="'.enti1($xsrch_7).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_7'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

if($xsrch_8=='1000-01-01') $xsrch_8='';
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_8">'.txt2('fld_date1_zztests_194_39').'</label>'.CRLF; // fld_date1_zztests
$o1.='    <input type="hidden" name="xsrch_8"    id="xsrch_8"   value="'.enti1($xsrch_8).'" />'.CRLF;
$o1.='    <button type="button" id="button_date_xsrch_8" onclick="javascript:setDate1(\'xsrch_8\',\'button_date_xsrch_8\',1,1,\'onChangeDateListForm1\')" style="padding:0px!important;font-size:0.8em;border-style:outset;'.($xsrch_8==''?'':'background:yellow;').'">';
$o1.=(($xsrch_8=='1000-01-01' || $xsrch_8=='' )?txtsys1('date all'):($xsrch_8=='NULL'?txtsys1('date null'):($xsrch_8=='NOT NULL'?txtsys1('date not null'):$xsrch_4)));
$o1.='</button>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_9">'.txt2('fld_time1_zztests_202_39').'</label>'.CRLF; // fld_time1_zztests
$o1.='    <input type="hidden" name="xsrch_9"    id="xsrch_9"   value="'.enti1($xsrch_9).'" />'.CRLF;
$o1.='    <button type="button" id="button_time_xsrch_9" onclick="javascript:setTime1(\'xsrch_9\',\'button_time_xsrch_9\',1,1,\'onChangeTimeListForm1\',0)" style="padding:0px!important;border-style:outset;font-size:0.8em;padding:5px;'.($xsrch_9!=''?'background:yellow;':'').'">';
$o1.=($xsrch_9==''?txtsys1('time all'):($xsrch_9=='NULL'?txtsys1('time null'):($xsrch_9=='NOT NULL'?txtsys1('time not null'):$xsrch_9)));
$o1.='</button>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_10">'.txt2('fld_dttim1_zztests_210_40').'</label>'.CRLF; // fld_dttim1_zztests
$o1.='    <input type="hidden" name="xsrch_10"    id="xsrch_10"   value="'.enti1($xsrch_10).'" />'.CRLF;
$o1.='    <button type="button" id="button_datetime_xsrch_10" onclick="javascript:setDateTime1(\'xsrch_10\',\'button_datetime_xsrch_10\',1,1,\'onChangeDtTimListForm1\')" style="padding:0px!important;border-style:outset;font-size:0.8em;'.($xsrch_10!=''?'background:yellow;':'').'">';
$o1.=($xsrch_10==''?txtsys1('datetime all'):($xsrch_10=='NULL'?txtsys1('datetime null'):($xsrch_10=='NOT NULL'?txtsys1('datetime not null'):$xsrch_10)));
$o1.='</button>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_11">'.txt2('fld_color1_zztests_218_40').'</label>'.CRLF; // fld_color1_zztests
$o1.='    <input type="hidden" name="xsrch_11" id="xsrch_11"   value="'.enti1($xsrch_11).'"  '.($autofocus=='xsrch_11'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='    <button '.($xsrch_11!=''?'class="backgroundYellow"':'').' style="padding:0px!important;" type="button" id="button_color_xsrch_11" onclick="javascript:setColor1(\'xsrch_11\',\'button_color_xsrch_11\',\'\',1,1,\'onChangeDateListForm1\')" style="border-style:outset;font-size:0.8em;padding:5px;">';
$o1.=($xsrch_11==''?txtsys1('color all'):($xsrch_11=='NULL'?txtsys1('color null'):($xsrch_11=='NOT NULL'?txtsys1('color not null'):$xsrch_11)));
$o1.='</button>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_12">'.txt2('fld_email1_zztests_226_40').'</label>'.CRLF; // fld_email1_zztests
$o1.='    <input '.($xsrch_12!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_12" id="xsrch_12"   value="'.enti1($xsrch_12).'"  size="8" maxlength="128"  '.($autofocus=='xsrch_12'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_13">'.txt2('fld_zipnum1_zztests_42_152').'</label>'.CRLF; // fld_zipnum1_zztests
$o1.='    <input '.($xsrch_13!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_13" id="xsrch_13"   value="'.enti1($xsrch_13).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_13'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_zztests_52_152').'</label>'.CRLF; // fld_id_zztests
$o1.='    <input '.($xsrch_id!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">🔎</button>'.CRLF;// #128270
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
// todo adjust the request
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_zztests`                ,T0.`fld_yorno1_zztests`            ,T0.`fld_visited_countries_zztests` ,T0.`fld_country1_zztests`          ,T0.`fld_title32_zztests`           ,
   T0.`fld_id_parent_zztests`         ,T1.`fld_title32_zztests`           ,T1.`fld_yorno1_zztests`            ,T1.`fld_zipnum1_zztests`           ,T0.`fld_date1_zztests`             ,
   T0.`fld_time1_zztests`             ,T0.`fld_dttim1_zztests`            ,T0.`fld_color1_zztests`            ,T0.`fld_email1_zztests`            ,T0.`fld_zipnum1_zztests`           
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` T0 ) 
 LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests`  T1 ON T0.`fld_id_parent_zztests` = T1.`fld_id_zztests`
 WHERE 1=1 
';
if($xsrch_0!='' ){
 if($xsrch_0=='NULL' ){
  $req6.='
   AND T0.`fld_yorno1_zztests` = \'\'
  '; 
 }else{
  $req6.='
   AND T0.`fld_yorno1_zztests` LIKE \'%'.addslashes1($xsrch_0).'%\'
  '; 
 }
}
if($xsrch_1!='' ){
 $req6.=buildSetCondition($xsrch_1,'param__country', 'T0.`fld_visited_countries_zztests`' );
}
if($xsrch_2!='' ){
 if($xsrch_2=='NULL' ){
  $req6.='
   AND T0.`fld_country1_zztests` = \'\'
  '; 
 }else{
  $req6.='
   AND T0.`fld_country1_zztests` LIKE \'%'.addslashes1($xsrch_2).'%\'
  '; 
 }
}
if($xsrch_3!='' ){
 $req6.='
  AND T0.`fld_title32_zztests` LIKE \'%'.addslashes1($xsrch_3).'%\'
 '; 
}
if($xsrch_4!='' && is_numeric($xsrch_4)){
 $req6.='
  AND T0.`fld_id_parent_zztests` = '.$xsrch_4.'
 '; 
}
// field fld_title32_zztests of parent table
if($xsrch_5!='' ){
 $req6.='
  AND T1.`fld_title32_zztests` LIKE \'%'.addslashes1($xsrch_5).'%\'
 '; 
}
// field fld_yorno1_zztests of parent table
if($xsrch_6!='' ){
 if($xsrch_6=='NULL' ){
  $req6.='
   AND T1.`fld_yorno1_zztests` = \'\'
  '; 
 }else{
  $req6.='
   AND T1.`fld_yorno1_zztests` LIKE \'%'.addslashes1($xsrch_6).'%\'
  '; 
 }
}
// field fld_zipnum1_zztests of parent table
if($xsrch_7!='' && is_numeric($xsrch_7)){
 $req6.='
  AND T1.`fld_zipnum1_zztests` = '.$xsrch_7.'
 '; 
}
if($xsrch_8!='' ){
 if($xsrch_8=='NULL'){
  $req6.='
   AND T0.`fld_date1_zztests` IS NULL
  ';   
 }else if($xsrch_8=='NOT NULL'){
  $req6.='
   AND T0.`fld_date1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_date1_zztests` LIKE \'%'.addslashes1($xsrch_8).'%\'
  '; 
 }
}
if($xsrch_9!='' ){
 if($xsrch_9=='NULL'){
  $req6.='
   AND T0.`fld_time1_zztests` IS NULL
  ';   
 }else if($xsrch_9=='NOT NULL'){
  $req6.='
   AND T0.`fld_time1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_time1_zztests` LIKE \'%'.addslashes1($xsrch_9).'%\'
  '; 
 }
}
if($xsrch_10!='' ){
 if($xsrch_10=='NULL'){
  $req6.='
   AND T0.`fld_dttim1_zztests` IS NULL
  ';   
 }else if($xsrch_10=='NOT NULL'){
  $req6.='
   AND T0.`fld_dttim1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_dttim1_zztests` LIKE \'%'.addslashes1($xsrch_10).'%\'
  '; 
 }
}
if($xsrch_11!='' ){
 if($xsrch_11=='NULL'){
  $req6.='
   AND T0.`fld_color1_zztests` IS NULL
  ';   
 }else if($xsrch_11=='NOT NULL'){
  $req6.='
   AND T0.`fld_color1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_color1_zztests` LIKE \'%'.addslashes1($xsrch_11).'%\'
  '; 
 }
}
if($xsrch_12!='' ){
 $req6.='
  AND T0.`fld_email1_zztests` LIKE \'%'.addslashes1($xsrch_12).'%\'
 '; 
}
if($xsrch_13!='' && is_numeric($xsrch_13)){
 $req6.='
  AND T0.`fld_zipnum1_zztests` = '.$xsrch_13.'
 '; 
}
if($xsrch_id!='' && is_numeric($xsrch_id)){
 $req6.='
  AND T0.`fld_id_zztests` = '.$xsrch_id.'
 '; 
}
// todo adjust the order
$req6.='
 ORDER BY T0.`fld_id_zztests` DESC 
'; 
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$__count=0;
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'T0.fld_id_zztests'                =>$mpsr6[0],
  'T0.fld_yorno1_zztests'            =>$mpsr6[1],
  'T0.fld_visited_countries_zztests' =>$mpsr6[2],
  'T0.fld_country1_zztests'          =>$mpsr6[3],
  'T0.fld_title32_zztests'           =>$mpsr6[4],
  'T0.fld_id_parent_zztests'         =>$mpsr6[5],
  'T1.fld_title32_zztests'           =>$mpsr6[6],
  'T1.fld_yorno1_zztests'            =>$mpsr6[7],
  'T1.fld_zipnum1_zztests'           =>$mpsr6[8],
  'T0.fld_date1_zztests'             =>$mpsr6[9],
  'T0.fld_time1_zztests'             =>$mpsr6[10],
  'T0.fld_dttim1_zztests'            =>$mpsr6[11],
  'T0.fld_color1_zztests'            =>$mpsr6[12],
  'T0.fld_email1_zztests'            =>$mpsr6[13],
  'T0.fld_zipnum1_zztests'           =>$mpsr6[14],
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}
$lsttbl='';
if($__count==0){
 $lst.='<p>'.CRLF;
 $lst.=''.txt2('no_record_founded_440_16').''.CRLF;
 $lst.='<a href="zz_zztests_action1.php?a=c">'.txt2('add_a_new_record_441_53').'</a>'.CRLF;
 $lst.='</p>'.CRLF;
 $o1.=''.$lst.''.CRLF;  
}else{
 $consUrlRedir=''.
               '&xsrch_0='.rawurlencode($xsrch_0). // fld_yorno1_zztests 
               '&xsrch_2='.rawurlencode($xsrch_2). // fld_country1_zztests 
               '&xsrch_3='.rawurlencode($xsrch_3). // fld_title32_zztests 
               '&xsrch_4='.rawurlencode($xsrch_4). // fld_id_parent_zztests 
                '&xsrch_5='.rawurlencode($xsrch_5). // fld_title32_zztests of parent
                '&xsrch_6='.rawurlencode($xsrch_6). // fld_yorno1_zztests of parent
                '&xsrch_7='.rawurlencode($xsrch_7). // fld_zipnum1_zztests of parent
               '&xsrch_8='.rawurlencode($xsrch_8). // fld_date1_zztests 
               '&xsrch_9='.rawurlencode($xsrch_9). // fld_time1_zztests 
               '&xsrch_10='.rawurlencode($xsrch_10). // fld_dttim1_zztests 
               '&xsrch_11='.rawurlencode($xsrch_11). // fld_color1_zztests 
               '&xsrch_12='.rawurlencode($xsrch_12). // fld_email1_zztests 
               '&xsrch_13='.rawurlencode($xsrch_13). // fld_zipnum1_zztests 
               '&xsrch_id='.rawurlencode($xsrch_id).
               '';
 if(is_array($xsrch_1)){
  foreach($xsrch_1 as $k1 => $v1){
   $consUrlRedir.='&xsrch_1%5B%5D='.rawurlencode($v1);
  }
 }else{
  $consUrlRedir.='&xsrch_1='.rawurlencode($xsrch_1); // fld_visited_countries_zztests
 }
 $ri=' <span class="btn unset">»</span>';
 if($__start+$__nbMax<$__count){
  $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">»</a>';
 }
 $le=' <span class="btn unset">«</span>';
 if($__xpage>0){
  $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">«</a>';
 }

 $o1.='<div>';
 $o1.='<form method="post">';
// $o1.='<button type="submit" name="action1">'.txt0('action1').'</button>';
// $o1.='<button type="submit" name="action2">'.txt0('action2').'</button>';
 $o1.='<a href="zz_zztests_action1.php?a=c">'.txt2('add_a_new_record_441_53').'</a>'.CRLF;
 $o1.=' '.$le.''.CRLF;  
 $o1.=' '.$ri.''.CRLF;  
 $o1.='</form>';
 $o1.='</div>';

 $o1.=getCss1(890); // todo adjust size

 $lsttbl.='<thead><tr>';
 $lsttbl.='<th style="min-width:125px;">'.txtsys1('column_action').'</th>';
 $lsttbl.='<th style="min-width:85px;">'.txt2('fld_id_zztests_52_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_yorno1_zztests_80_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_visited_countries_zztests_99_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_country1_zztests_127_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_title32_zztests_147_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_id_parent_zztests_37_152').'</th>';
 $lsttbl.='<th>'.txt2('T1.fld_title32_zztests_161_39').'</th>'; // ======== parent field of fld_id_parent_zztests
 $lsttbl.='<th>'.txt2('T1.fld_yorno1_zztests_167_39').'</th>'; // ======== parent field of fld_id_parent_zztests
 $lsttbl.='<th>'.txt2('T1.fld_zipnum1_zztests_188_39').'</th>'; // ======== parent field of fld_id_parent_zztests
 $lsttbl.='<th  style="min-width:95px;">'.txt2('fld_date1_zztests_194_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_time1_zztests_202_39').'</th>';
 $lsttbl.='<th  style="min-width:95px;">'.txt2('fld_dttim1_zztests_210_40').'</th>';
 $lsttbl.='<th>'.txt2('fld_color1_zztests_218_40').'</th>';
 $lsttbl.='<th>'.txt2('fld_email1_zztests_226_40').'</th>';
 $lsttbl.='<th>'.txt2('fld_zipnum1_zztests_42_152').'</th>';
 $lsttbl.='</tr></thead><tbody>';

 foreach($data0 as $k0=>$v0){

  $lsttbl.='<tr>';

  $lsttbl.='<td data-label="'.txtsys1('column_action').'">';
  $lsttbl.='<div>';
  $lsttbl.='<a href="zz_zztests_action1.php?a=u&id='.$v0['T0.fld_id_zztests'].'" title="'.txtsys1('edit_button').'">✎</a>';//✎ #9998
  $lsttbl.='<a class="danger" href="zz_zztests_action1.php?a=d&id='.$v0['T0.fld_id_zztests'].'" title="'.txtsys1('delete_button').'">✘</a>';//✘ #10008
  $lsttbl.='<a href="zz_zztests_action1.php?a=du&id='.$v0['T0.fld_id_zztests'].'" title="'.txtsys1('duplicate_button').'">📋</a>';//📋 #128203
  $lsttbl.='</div>';
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_id_zztests_52_152').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_id_zztests'].''; // fld_id_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_yorno1_zztests_80_39').'" style="text-align:center;">';
  $lsttbl.=displayParam1('yorno',$v0['T0.fld_yorno1_zztests'],array('unsetPossible'=>true)); // fld_yorno1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_visited_countries_zztests_99_39').'">';
  $lsttbl.=displayParam1('country',$v0['T0.fld_visited_countries_zztests'],array('set'=>true)); // fld_visited_countries_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_country1_zztests_127_39').'" style="text-align:center;">';
  $lsttbl.=displayParam1('country',$v0['T0.fld_country1_zztests'],array('unsetPossible'=>true)); // fld_country1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_title32_zztests_147_39').'">';
  $lsttbl.=''.$v0['T0.fld_title32_zztests'].''; // fld_title32_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_id_parent_zztests_37_152').'">';
  $lsttbl.=''.$v0['T0.fld_id_parent_zztests'].''; // fld_id_parent_zztests
  $lsttbl.='</td>';
// field fld_title32_zztests of parent table
  if($v0['T0.fld_id_parent_zztests']==0||is_null($v0['T0.fld_id_parent_zztests'])){
   $lsttbl.='<td data-label="'.txt2('T1.fld_title32_zztests_161_39').'"></td>'; 
  }else{
   $lsttbl.='<td data-label="'.txt2('T1.fld_title32_zztests_161_39').'">';
   $lsttbl.=''.$v0['T1.fld_title32_zztests'].''; // fld_title32_zztests
   $lsttbl.='</td>';
  }

// field fld_yorno1_zztests of parent table
  if($v0['T0.fld_id_parent_zztests']==0||is_null($v0['T0.fld_id_parent_zztests'])){
   $lsttbl.='<td data-label="'.txt2('T1.fld_yorno1_zztests_167_39').'"></td>'; 
  }else{
   $lsttbl.='<td data-label="'.txt2('T1.fld_yorno1_zztests_167_39').'" style="text-align:center;">';
   $lsttbl.=displayParam1('yorno',$v0['T1.fld_yorno1_zztests'],array('unsetPossible'=>true)); // fld_yorno1_zztests
   $lsttbl.='</td>';
  }

// field fld_zipnum1_zztests of parent table
  if($v0['T0.fld_id_parent_zztests']==0||is_null($v0['T0.fld_id_parent_zztests'])){
   $lsttbl.='<td data-label="'.txt2('T1.fld_zipnum1_zztests_188_39').'"></td>'; 
  }else{
   $lsttbl.='<td data-label="'.txt2('T1.fld_zipnum1_zztests_188_39').'" style="text-align:right;">';
   $lsttbl.=''.$v0['T1.fld_zipnum1_zztests'].''; // fld_zipnum1_zztests
   $lsttbl.='</td>';
  }


  $lsttbl.='<td data-label="'.txt2('fld_date1_zztests_194_39').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_date1_zztests'].''; // fld_date1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_time1_zztests_202_39').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_time1_zztests'].''; // fld_time1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_dttim1_zztests_210_40').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_dttim1_zztests'].''; // fld_dttim1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_color1_zztests_218_40').'">'; // fld_color1_zztests
  if($v0['T0.fld_color1_zztests']==''){
   $lsttbl.=''.$v0['T0.fld_color1_zztests'].''; 
  }else{
   $val=json_decode($v0['T0.fld_color1_zztests'],true);
   $lsttbl.='<div style="display:inline-block;width:35px;height:20px;border:1px #eee outset;background-color:#'.$val['hexValue'].'"></div>';
   $lsttbl.=''.$val['hexValue'].'';
   if(isset($val['webName']) && $val['webName']!=''){
    $lsttbl.='<br />'.$val['webName'].'';
   }
   if(isset($val['pantoneName']) && $val['pantoneName']!=''){
    $lsttbl.='<br /> pantone:'.$val['pantoneName'].'';
   }
  }
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_email1_zztests_226_40').'">';
  $lsttbl.=''.$v0['T0.fld_email1_zztests'].''; // fld_email1_zztests
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_zipnum1_zztests_42_152').'" style="text-align:right;">';
  $lsttbl.=''.$v0['T0.fld_zipnum1_zztests'].''; // fld_zipnum1_zztests
  $lsttbl.='</td>';

  $lsttbl.='</tr>';

 }

 $o1.='<table class="tableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;

 $o1.=' <div>'.CRLF;
 $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_614_98').' )'.CRLF;
 $o1.='    <a class="buttonAdd" href="zz_zztests_action1.php?a=c">'.txt2('add_a_new_record_441_53').'</a>'.CRLF;
 $o1.=' </div>'.CRLF;

}

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
