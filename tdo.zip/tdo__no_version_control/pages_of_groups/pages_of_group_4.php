<?php
// group 4 : i18n,m:menu,o:order,aj:ajax
$GLOBALS['glob_grpspgs']=array (
  'ajax_getJavascriptToTranslate1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 96,
    'remote' => 1,
  ),
  'ajax_addTranslateSys1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 33,
    'remote' => 1,
  ),
  'ajax_translateTables1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 95,
    'remote' => 1,
  ),
  'ajax_translatePageElement1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 89,
    'remote' => 1,
  ),
  'ajax_translateText1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 37,
    'remote' => 1,
  ),
  'ajax_translateMenu2.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 36,
    'remote' => 1,
  ),
  'ajax_translateMenu1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 35,
    'remote' => 1,
  ),
  'ajax_updTranslateSys1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 34,
    'remote' => 1,
  ),
  'ajax_translateJs1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 32,
    'remote' => 1,
  ),
  'ajax_addTranslationJs1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 31,
    'remote' => 1,
  ),
  'ajax_getPageToTranslate1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 30,
    'remote' => 1,
  ),
  'ajax_writeTranslationFiles1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 28,
    'remote' => 1,
  ),
  'ajax_translatePage2.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 25,
    'remote' => 1,
  ),
  'zz_translate.php' => 
  array (
    'm' => 1,
    'o' => 0,
    'aj' => 0,
    'id' => 16,
    'remote' => 1,
  ),
  'profile.php' => 
  array (
    'm' => 1,
    'o' => 0,
    'aj' => 0,
    'id' => 41,
    'remote' => 1,
  ),
  'index.php' => 
  array (
    'm' => 1,
    'o' => 996,
    'aj' => 0,
    'id' => 1,
    'remote' => 1,
  ),
  'login.php' => 
  array (
    'm' => 1,
    'o' => 997,
    'aj' => 0,
    'id' => 2,
    'remote' => 1,
  ),
  'logout.php' => 
  array (
    'm' => 0,
    'o' => 998,
    'aj' => 0,
    'id' => 3,
    'remote' => 1,
  ),
);