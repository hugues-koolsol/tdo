<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();
require_once $GLOBALS['glob_incPath1'].'/zz_inc_grpspgs1.php';

$js1=array();

//========================================================================================================================
function trierLesPagesNonMenu($a,$b){
 if($a['orderNonMenu']==$b['orderNonMenu']) return 0;
 if($a['orderNonMenu']>=$b['orderNonMenu']) return -1;
 return 1;
}
//========================================================================================================================
function trierLesPagesMenu($a,$b){
 if($a['order']==9999){
  if($a['fld_id_pages']==$b['fld_id_pages']) return 0;
  if($a['fld_id_pages']<=$b['fld_id_pages']) return 1;
 }
 if($a['order']==$b['order']) return 0;
 if($a['order']<=$b['order']) return -1;
 return 1;
}
//============================================================================================================================================

if(isset($_POST) && sizeof($_POST)>0){
  require_once($GLOBALS['glob_incPath1'].'/zz_inc_grpspgs1.php');
  if(isset($_POST['action']) && $_POST['action']=='updateMenuFlag' ){
   updateMenus();
   updateGrpPgsFiles1();
  }else if(isset($_POST['action']) && $_POST['action']=='updateMenuListForGroup' ){
   updatePagesOfGroups(); // mise à jour des pages en BDD
   updateMenus();
   updateGrpPgsFiles1(); // mise à jour des fichiers
  }
  header("HTTP/1.1 303 See Other");header('Location: zz_grpspgs.php');
  exit();
}

//========================================================================================================================
$o1='';
$nbMax=15;
$start=0;
$count=0;
$xpage=0;
if(isset($_GET['xpage'])&&is_numeric($_GET['xpage'])){
 $xpage=$_GET['xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['xpage'])) $xpage=$_SESSION[PGMK][NAV][BNF]['xpage'];
}
//echo __LINE__ ; exit();
$xsrch_idgr1  =saveSessionSearch1( 'xsrch_idgr1'    , BNF );


if($xsrch_idgr1!=''){
 if(!is_numeric($xsrch_idgr1)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=enti1('erreur ' . __LINE__ . ', l\'id doit être numérique.').'<br />';;
 }
}

$autofocus='xsrch_idgr1';


$o1.=htmlHead1(array('nomenu'=>true));

$o1.='<h1>'.txt2('Pages des groupes_243_18').'</h1>';
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_SESSION , true ) . '</pre>' ; exit(0);
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="filterForm">'.CRLF;



$o1.='   <div class="">'.CRLF;
$o1.='    <label class="" for="xsrch_idgr1"   class="">id groupe</label>'.CRLF;
$o1.='    <input class="';
if($xsrch_idgr1!=''){$o1.='backgroundYellow ';}
$o1.=    '" type="text" name="xsrch_idgr1"    id="xsrch_idgr1"   value="'.enti1($xsrch_idgr1).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_idgr1'?' autofocus="autofocus" ':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;


$o1.=' </form>'.CRLF;

//===================
$start=$xpage*$nbMax;
$_SESSION[PGMK][NAV][BNF]['xpage']=$xpage;
$lst='';

// cas 1 , rien de spécifié
if(($xsrch_idgr1=='' || !is_numeric($xsrch_idgr1))){

 $o1.='<p>'.txt2('Select a group_318_18').'</p>'.CRLF;

  
 $req6='
  SELECT  SQL_CALC_FOUND_ROWS
   T0.`fld_id_groups`   , T0.`fld_name_groups` 
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0 
  WHERE 1=1
 ';
 if($_SESSION[PGMK]['group']!=1){
  $req6.='
   AND ( T0.`fld_parent_id_groups` = '.$_SESSION[PGMK]['group'].' OR T0.`fld_root_group_id_groups` = '.$_SESSION[PGMK]['group'].' )
   AND ( T0.`fld_id_groups`        <> '.$_SESSION[PGMK]['group'].' )
  ' ;
//   AND T0.`fld_parent_id_groups` <> T0.`fld_id_groups`
 }
 $req6.='
  ORDER BY T0.`fld_id_groups` ASC 
 ' ;
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $count=$mpsrcount6[0];
 //  echo __LINE__ . '<pre>' . var_export( $mpsrcount6 , true ) . '</pre>' ;
  }
  $lsttbl='';
  if($count==0){
   $lsttbl.='<p>Il n\'y a pas de groupe avec les critères indiqués</p>'.CRLF;
  }else{
   $lsttbl.='<div class="divTextCentered">';
   while($mpsr6=mysqli_fetch_row($result6)){
    $lsttbl.='<a href="zz_grpspgs.php?xsrch_idgr1='.$mpsr6[0].'" class="pageListAuth">'.enti1($mpsr6[1]).' ('.$mpsr6[0].')</a>&nbsp;';
   }
   $lsttbl.='</div>';
  }
  $o1.=$lsttbl;
  mysqli_free_result($result6);
 }else{
  $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));
 }

}else{
 
 if($xsrch_idgr1!='' || is_numeric($xsrch_idgr1)){
  $xsrch_idgr1=(int)$xsrch_idgr1;
  $req7='
   SELECT  SQL_CALC_FOUND_ROWS
    T0.`fld_id_groups`   , T0.`fld_name_groups` 
   FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0 
   WHERE T0.`fld_id_groups`        = '.$xsrch_idgr1.'
  ' ;
  if($_SESSION[PGMK]['group']!=1){
   $req7.='
    AND ( T0.`fld_parent_id_groups` = '.$_SESSION[PGMK]['group'].' OR T0.`fld_root_group_id_groups` = '.$_SESSION[PGMK]['group'].' )
    AND ( T0.`fld_id_groups`        <> '.$_SESSION[PGMK]['group'].' )
   ' ;
//    AND T0.`fld_parent_id_groups` <> T0.`fld_id_groups`
   
  }
  $req7.='
   ORDER BY T0.`fld_id_groups` ASC 
  ' ;
  
  $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $reqCount7='SELECT FOUND_ROWS();';
   $rescount7=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount7);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    $mpsrcount7=mysqli_fetch_row($rescount7);
    $count=$mpsrcount7[0];
   }
   $lsttbl='';
   if($count==0){
    $o1.='<p>Il n\'y a pas de groupe avec les critères indiqués</p>'.CRLF;
   }else{
    while($mpsr7=mysqli_fetch_row($result7)){
     $fld_group_id_grpspgs=$mpsr7[0];
    }    
    mysqli_free_result($result7);
    
    require_once($GLOBALS['glob_incPath1'].'/__pageList.php');
    $listeDesPages=array();
    $testLocalAdminPage=false;
    $testUserPage=false;
    if($xsrch_idgr1!=1){
     require_once($GLOBALS['glob_incPath1'].'/zz_inc_groups1.php');
     $dataGroup=getGroup1($xsrch_idgr1);
     if($dataGroup['fld_id_groups']==$dataGroup['fld_parent_id_groups']){
      $testLocalAdminPage=true;
     }else{
      $testUserPage=true;
     }
    }
    
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['__pageList'] , true ) . '</pre>' ; exit(0);
    
    foreach($GLOBALS['__pageList'] as $k1 => $v1){
     $putPage=true;
     if($v1['fld_isajax_pages']==1){
      if(!is_file($GLOBALS['glob_incPath1'].'/ajax/'.$v1['fld_name_pages'])){
       $putPage=false;
      }
     }else{
      if(!is_file($v1['fld_name_pages'])){
       $putPage=false;
      }
     }
     if($testLocalAdminPage && $v1['fld_localadmin_pages'] != '1'){
      $putPage=false;
     }
     if($testUserPage && $v1['fld_isuser_pages'] != '1'){
      $putPage=false;
     }
     if($putPage==true){
      $isset=false;
      if($xsrch_idgr1==2 && ($v1['fld_id_pages'] == 1 || $v1['fld_id_pages'] == 2 || $v1['fld_id_pages'] == 3)){
       echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
       $isset=true;
      }else if($xsrch_idgr1!=2 && ($v1['fld_id_pages'] == 1 || $v1['fld_id_pages'] == 2 || $v1['fld_id_pages'] == 3 || $v1['fld_id_pages'] == 41)){
       $isset=true;
      }
      
      $listeDesPages['fld_id_pages_'.$v1['fld_id_pages']]=array(
       'fld_id_pages'         => $v1['fld_id_pages'],
       'fld_name_pages'       => $v1['fld_name_pages'],
       'fld_menu_pages'       => $v1['fld_menu_pages'],
       'fld_isajax_pages'     => $v1['fld_isajax_pages'],
       'fld_localadmin_pages' => $v1['fld_localadmin_pages'],
       'fld_isuser_pages'     => $v1['fld_isuser_pages'],
       'fld_isaction_pages'   => $v1['fld_isaction_pages'],
       'fld_order_all_pages'  => $v1['fld_order_all_pages'],
       'isset'                => $isset,
       'menu'                 => false,
       'order'                => 9999,
       'orderNonMenu'         => $v1['fld_order_all_pages'],
      );
     }
    }
    
    // en prod, il n'y a pas la table des pages
    $req7='
     SELECT  SQL_CALC_FOUND_ROWS
       T0.`fld_page_id_grpspgs` , T0.`fld_group_id_grpspgs` , T0.`fld_is_menu_grpspgs` , T0.`fld_menu_order_grpspgs`
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` T0 
     WHERE T0.fld_group_id_grpspgs = '.$fld_group_id_grpspgs.'
    ' ;
    $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
     $count=0;
     while($mpsr7=mysqli_fetch_row($result7)){
      if(isset($listeDesPages['fld_id_pages_'.$mpsr7[0]])){
       $listeDesPages['fld_id_pages_'.$mpsr7[0]]['isset'] = true;
       $listeDesPages['fld_id_pages_'.$mpsr7[0]]['menu']  = ($mpsr7[2]=='1'?true:false);
       $order=$mpsr7[3];
       if($listeDesPages['fld_id_pages_'.$mpsr7[0]]['menu']===false){
        $order=9999;
       }
       $listeDesPages['fld_id_pages_'.$mpsr7[0]]['order']        = $order;
       $listeDesPages['fld_id_pages_'.$mpsr7[0]]['orderNonMenu'] = $listeDesPages['fld_id_pages_'.$mpsr7[0]]['fld_order_all_pages'];
      }
      $count++;
     }
     mysqli_free_result($result7);
    }else{
     $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req7));
    }

    if($fld_group_id_grpspgs>3){
//     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listeDesPages , true ) . '</pre>' ; exit(0);
     $listeDesPages['fld_id_pages_41']['menu']=true;
    }
    
    if(sizeof($listeDesPages)>0){
     uasort($listeDesPages,'trierLesPagesMenu');
    }

    $tabForSort1=array();
    
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listeDesPages , true ) . '</pre>' ; exit(0);
    
    foreach( $listeDesPages as $k1 => $v1){
     $label='';
     if(($v1['isset'] && $v1['menu']==true && $v1['order']>=0) ){
//        $o1.=' {id :  2 , data:{label:\'a\'}   , parentId : 0 , isOpen : 1 },'.CRLF;

      
      $label.='<div style="display:inline-block;border:1px #eee solid;">';
//      $label.=txt2('has access_448_93') . ' ' ;
      if($fld_group_id_grpspgs==1 || $v1['fld_id_pages'] == 1 || $v1['fld_id_pages'] == 2 || $v1['fld_id_pages'] == 3){
       $label.='<input type="checkbox" data-line="'.__LINE__.'" style="display:none;" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" checked="checked" disabled="disabled" />';
       $lsttbl.='<input type="hidden" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']"  />';
      }else{
       if($v1['isset']==false){
        $label.='<input type="checkbox" data-line="'.__LINE__.'" style="display:none;" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" />';
       }else{
        $label.='<input type="checkbox" data-line="'.__LINE__.'" style="display:none;" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" checked="checked" />';
       }
      }
      $label.='</div>';
      
      
      
      $label.='<div class="thinBorder" style="display:inline-block;">';
//      $label.='&nbsp; '.txt2('In menu_467_23') . ' ';
      if($v1['menu']==false){
       $label.='1<input type="checkbox" style="" value="'.$v1['fld_id_pages'].'" name="menu['.$v1['fld_id_pages'].']" />';
      }else{
       if($v1['fld_id_pages']==41){ // profile ...
        if($xsrch_idgr1==2){        // ... not for group 2 anonymous
        }else{                      // and always for others
         $label.='<input type="hidden" style="" value="'.$v1['fld_id_pages'].'" name="menu['.$v1['fld_id_pages'].']"  />';
         $label.='<input type="checkbox" style="" checked="checked" disabled="disabled" />';
        }
       }else{
        if($xsrch_idgr1==2){
         $label.='<input type="hidden" style="" value="'.$v1['fld_id_pages'].'" name="menu['.$v1['fld_id_pages'].']"  />';
         $label.='<input type="checkbox" style="" checked="checked" disabled="disabled" />';
        }else{
         if($xsrch_idgr1==1){
          $label.='<input type="hidden" style="" value="'.$v1['fld_id_pages'].'" name="menu['.$v1['fld_id_pages'].']"  />';
          $label.='<input type="checkbox" style="" checked="checked" disabled="disabled" />';
         }else{
          $label.='<input type="checkbox" style="" value="'.$v1['fld_id_pages'].'" name="menu['.$v1['fld_id_pages'].']" checked="checked" />';
         }
         
        }
       }
      }
      $label.='</div>';

      $label.='<div class="thinBorder" style="display:inline-block;">&nbsp;';
      $label.=''.txt3('menu__'.$v1['fld_name_pages']).'  ('.enti1($v1['fld_id_pages']).')'; // '.enti1($v1['fld_name_pages']).'
      $label.='</div>';

      $tabForSort1[]=array(
       'id'   => $v1['fld_id_pages'] ,
       'data' => array(
        'label'  =>  $label  ,
       ),
       'parentId' => 0,
       'isOpen'   => 1,
      );
      
      
     }
    }
    require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
    
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listeDesPages , true ) . '</pre>' ; exit(0);
    if(sizeof($listeDesPages)>0){
     uasort($listeDesPages,'trierLesPagesNonMenu');
    }
    
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listeDesPages , true ) . '</pre>' ; exit(0);
    
    foreach( $listeDesPages as $k1 => $v1){
     if(!($v1['isset'] && $v1['menu']==true && $v1['order']>=0) ){
      
      $displayLine=true;
      if($fld_group_id_grpspgs==2 && $v1['fld_id_pages'] == 41 ){ // profile toujours sauf pour le groupe anonyme
       $displayLine=false;
      }
      if($v1['fld_id_pages'] == 1 || $v1['fld_id_pages'] == 2 || $v1['fld_id_pages'] == 3 ){ // index, login,logout toujours dans les menus
       $displayLine=false;
      }
      if($displayLine){
       
       $lsttbl.='<tr><td class="fictif"></td>';
      
       $lsttbl.='<td class="actionColumn" data-label="'.txtsys1('column_action').'">';
       if($fld_group_id_grpspgs==1 || $v1['fld_id_pages'] == 1 || $v1['fld_id_pages'] == 2 || $v1['fld_id_pages'] == 3|| $v1['fld_id_pages'] == 41){
        $lsttbl.='<input type="checkbox" data-line="'.__LINE__.'" style="" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" checked="checked" disabled="disabled" />';
        $lsttbl.='<input type="hidden" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']"  />';
       }else{
        if($v1['isset']==false){
         $lsttbl.='<input type="checkbox" data-line="'.__LINE__.'" style="" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" />';
        }else{
         $lsttbl.='<input type="checkbox" data-line="'.__LINE__.'" style="" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" checked="checked" />';
        }
        
       }
       $lsttbl.='</td>';
       

       $lsttbl.='<td data-label="'.txt2('page (id)_433_66').'">';
       $lsttbl.=''.enti1($v1['fld_name_pages']).' ('.$v1['fld_id_pages'].') '; 
       $lsttbl.='</td>';
 /*
       $lsttbl.='<td data-label="'.txt2('actif_433_96').'">';
       $lsttbl.=displayParam1('yorno',$v1['fld_menu_pages']);
       $lsttbl.='</td>';
 */
       $lsttbl.='<td data-label="'.txt2('fld_isajax_pages_530_143').'" style="text-align:center;">';
        $lsttbl.=displayParam1('yorno',$v1['fld_isajax_pages']);
       $lsttbl.='</td>';
       
       $lsttbl.='<td data-label="'.txt2('menu_433_122').'" style="text-align:center;">'; // menu
       if($v1['fld_menu_pages']==1){
        if($v1['menu']==false){
         $lsttbl.='<input type="checkbox" style="" value="'.$v1['fld_id_pages'].'" name="menu['.$v1['fld_id_pages'].']" />';
        }else{
         $lsttbl.='<input type="checkbox" style="" value="'.$v1['fld_id_pages'].'" name="menu['.$v1['fld_id_pages'].']" checked="checked" />';
        }
       }
       $lsttbl.='</td>';
       
       $lsttbl.='<td data-label="'.txt2('fld_localadmin_pages_510_40').'" style="text-align:center;">';
        $lsttbl.=displayParam1('yorno',$v1['fld_localadmin_pages']);
       $lsttbl.='</td>';
       
       $lsttbl.='<td data-label="'.txt2('fld_isuser_pages_514_40').'" style="text-align:center;">';
        $lsttbl.=displayParam1('yorno',$v1['fld_isuser_pages']);
       $lsttbl.='</td>';

       
       
       $lsttbl.='</tr>';       
      }
     }
    }
     
    $o1.='<form method="post">'.CRLF;
    if(sizeof($tabForSort1)>0){
     
     $o1.='<input type="hidden" id="sortListGroupId" value="' . $fld_group_id_grpspgs . '" />'.CRLF;
     $data0=array();
     foreach($tabForSort1 as $k1 => $v1){
      $data0[]=array(
      'id'       => $v1['id'],
      'data'     => array( 'label' => $v1['data']['label'] ), // displayParam1('yorno',$mpsr6[1],array('unsetPossible'=>true))
      'parentId' => 0,
      'isOpen'   => 1,
      );
     }
     $o1.=' <input type="hidden" id="sortedMenus1" name="sortedMenus1" value="" />';
     $o1.='<div id="container2" style="max-width:450px;border:1px #f00 solid;overflow-y:scroll;max-height:450px;">';
     $o1.='     <div id="myTreeId2"></div>';
     $o1.='</div>';

     $o1.='<script src="js/hdtree.js?v=20171122-1917"></script>';
     $o1.='<script type="text/javascript">';
     $o1.='var jsonTree2='.json_encode($data0).';';
     $o1.='var options2={sortOnly:true};'.CRLF; // sortOnly
     $o1.='</script>';
     $js1[]=array(
       'jsName'                  => 'onSortPagesOfGroups2' ,
       'objectName'              => 'oMyTree2'        ,
       'elementToSort'           => 'myTreeId2'       ,
       'dataToSort'              => 'jsonTree2'       ,
       'options'                 => 'options2'        ,
       'callBack'                => 'afterSortGrpPgs2' ,
     );
    }
    
    if($lsttbl!=''){

     $o1.=getCss1(890); // todo adjust size    
     
     
     $lsttbl1='<thead><tr>';
     $lsttbl1.='<th>'.txt2('action_433_39').'</th>';
     $lsttbl1.='<th>'.txt2('page (id)_433_66').'</th>';
//     $lsttbl1.='<th>'.txt2('actif_433_96').'</th>';
     $lsttbl1.='<th>'.txt2('fld_isajax_pages_530_143').'</th>';
     $lsttbl1.='<th>'.txt2('menu_433_122').'</th>';
     $lsttbl1.='<th>'.txt2('fld_localadmin_pages_510_40').'</th>';
     $lsttbl1.='<th>'.txt2('fld_isuser_pages_514_40').'</th>';
     $lsttbl1.='</tr></thead>'.$lsttbl;
     $o1.=' <table class="tableResult1" >'.CRLF;
     $o1.=''.$lsttbl1.'<tbody>'.CRLF;
     if($fld_group_id_grpspgs!=1){
      $o1.='  <tr>'.CRLF;
      $o1.='   <td colspan="3">'.CRLF;
      $o1.='    <input type="hidden" name="fld_group_id_grpspgs" value="'.$fld_group_id_grpspgs.'" />'.CRLF;
      $o1.='    <button type="input" name="action" value="updateMenuListForGroup">'.txt2('Mettre à jour les pages du groupe_502_91').'</button>'.CRLF;
      $o1.='   </td>'.CRLF;
      $o1.='   <td colspan="2">'.CRLF;
      $o1.='    <input type="hidden" name="fld_group_id_grpspgs" value="'.$fld_group_id_grpspgs.'" />'.CRLF;
      $o1.='    <button type="input" name="action" value="updateMenuFlag">'.txt2('update the order_502_83').'</button>'.CRLF;
      $o1.='   </td>'.CRLF;
      $o1.='  </tr>'.CRLF;
     }else{
      $o1.='  <tr>'.CRLF;
      $o1.='   <td colspan="3">'.CRLF;
      $o1.='   </td>'.CRLF;
      $o1.='   <td colspan="2">'.CRLF;
      $o1.='    <input type="hidden" name="fld_group_id_grpspgs" value="'.$fld_group_id_grpspgs.'" />'.CRLF;
      $o1.='    <button type="input" name="action" value="updateMenuFlag">'.txt2('update the order_502_83').'</button>'.CRLF;
      $o1.='   </td>'.CRLF;
      $o1.='  </tr>'.CRLF;       
     }
     $o1.='</tbody></table>'.CRLF;
     $o1.='</form>'.CRLF;
    }
   }
  }else{
   $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req7));
  }
 }
}
$o1.=CRLF.'<script src="js/grpspgs.js" type="text/javascript"></script>'.CRLF;
$o1.=htmlFoot0(array('js' => $js1));
dw1($o1);
cleanSession1();