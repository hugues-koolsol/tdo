<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb2();
//========================================================================================================================
//========================================================================================================================
//========================================================================================================================
//========================================================================================================================
$toPrint='';
$sourceGenere='';
//========================================================================================================================
//========================================================================================================================
require_once $GLOBALS['glob_incPath1'].'/tablelinks1.php';

if(isset($_GET['a']) && $_GET['a']=='inc1'){
 getTableInfos($_GET);
 $sourceGenere.='<'.'?php'.CRLF;
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='function get'.$GLOBALS['funcname'].'1($id){'.CRLF;
 }else{
  $sourceGenere.='// TODO no auto_increment field in this table => find the todo.s in this source to adjust it manually'.CRLF;
  $sourceGenere.='function get'.$GLOBALS['funcname'].'1($todo){'.CRLF;
 }
 $sourceGenere.=' $nam=array();'.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  $sourceGenere.=' $n[\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ) . '=';
  if(true===$v1['isNumericField']){
   if($v1['null_possible']=='YES'){
    $sourceGenere.='\'\'; // null possible';
   }else{
    $sourceGenere.='0;';    
   }   
  }else if(strtolower($v1['type_champ'])=='datetime'){
   if($v1['null_possible']=='YES'){
    $sourceGenere.='\'\'; // null possible';
   }else{
    $sourceGenere.='\'1000-01-01 00:00:00\';';  
   }
  }else if(strtolower($v1['type_champ'])=='date'){
   if($v1['null_possible']=='YES'){
    $sourceGenere.='\'\'; // null possible' ;  
   }else{
    $sourceGenere.='\'1000-01-01\';';
   }
  }else if(strtolower($v1['type_champ'])=='time'){
   if($v1['null_possible']=='YES'){
    $sourceGenere.='\'\'; // null possible'; 
   }else{
    $sourceGenere.='\'00:00:00\';';
   }
  }else{
   $sourceGenere.='\'\';';
  }
  $sourceGenere.=CRLF;
 }
 $sourceGenere.=' $sql=\''.CRLF;
 $sourceGenere.='  SELECT ';
 $count=0;
 $listeChamps='';
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if($count%5==0){
   $listeChamps.=CRLF.'   ';
  }
  $listeChamps.='T0.`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).',';
  $count++;
 }
 $listeChamps=substr($listeChamps,0,-1);
 $sourceGenere.=$listeChamps.CRLF;
 $sourceGenere.='  FROM `\'.$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\'].\'`.`'.$_GET['table'].'` T0'.CRLF;
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='  WHERE T0.`'.$GLOBALS['__autoincrement'].'` = \'.$id. \''.CRLF;
 }else{
  $sourceGenere.='  WHERE T0.`todo` = \'.$id. \' -- todo no auto increment here'.CRLF;
 }
 $sourceGenere.=' \';'.CRLF;
 $sourceGenere.=' $req=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$sql);'.CRLF;
 $sourceGenere.=' if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])==0){'.CRLF;
 $sourceGenere.='  while($row=mysqli_fetch_row($req)){'.CRLF;
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  $sourceGenere.='   $n[\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ) . '= $row['.$count.'];'.CRLF;
  $count++;
 }
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  mysqli_free_result($req);'.CRLF;
 $sourceGenere.=' }else{'.CRLF;
 $sourceGenere.='  debugSql2(array(\'sqler\' => \' in \'. __FUNCTION__ . \' \' . mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']),\'reque\' => $sql , \'file\' => __FILE__ , \'line\' => __LINE__ ));'.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' return($n);'.CRLF;
 $sourceGenere.='}'.CRLF;
}
//========================================================================================================================
//========================================================================================================================
if(isset($_GET['a']) && $_GET['a']=='choose1'){
 getTableInfos($_GET);
 $sourceGenere.='<'.'?php'.CRLF;
 if($GLOBALS['__autoincrement']==''){
  $sourceGenere.='// warning, there is no auto increment field in this table "'.get['table'].'"'.CRLF;
  
 }
 $sourceGenere.='define(\'BNF\',basename( __FILE__ ));'.CRLF;
 $sourceGenere.='require_once \'za_inc.php\';'.CRLF;
 $sourceGenere.='session_start();'.CRLF;
 $sourceGenere.='@include  $GLOBALS[\'glob_dataPath1\'].\'/generated/lang/\'.$GLOBALS[\'glob_lang\'].\'_\'.BNF;'.CRLF;
 $sourceGenere.='checkGroupPages();'.CRLF;
 $sourceGenere.=CRLF;
 $sourceGenere.='if(isset($_GET[\'idchoose\'])){'.CRLF;
 $sourceGenere.=' $_SESSION[PGMK][\'choose\'][\'valueBack\']=$_GET[\'idchoose\'];'.CRLF;
 $sourceGenere.=' header(\'Location: \'.$_SESSION[PGMK][\'choose\'][\'urlBack\']); '.CRLF;
 $sourceGenere.=' exit();'.CRLF;
 $sourceGenere.='}'.CRLF;
 $sourceGenere.=CRLF;

 $sourceGenere.='if(!isset($_SESSION[PGMK][\'choose\'][\'urlBack\'])){'.CRLF;
 $sourceGenere.=' header(\'Location: index.php?message=\'.urlencode(txtsys1(\'the_navigation_has_been_lost\')));'.CRLF;
 $sourceGenere.=' exit();'.CRLF;
 $sourceGenere.='}'.CRLF;

 
 $sourceGenere.='openDb2();'.CRLF;
 $sourceGenere.='//========================================================================================================================'.CRLF;
 $sourceGenere.='$o1=\'\';'.CRLF;
 $sourceGenere.='$__nbMax=20;'.CRLF;
 $sourceGenere.='$__start=0;'.CRLF;
 $sourceGenere.='$__count=0;'.CRLF;
 $sourceGenere.='$__xpage=0;'.CRLF;
 $sourceGenere.='if(isset($_GET[\'__xpage\'])&&is_numeric($_GET[\'__xpage\'])){'.CRLF;
 $sourceGenere.=' $__xpage=$_GET[\'__xpage\'];'.CRLF;
 $sourceGenere.='}else{'.CRLF;
 $sourceGenere.=' if(isset($_SESSION[PGMK][NAV][BNF][\'__xpage\'])) $__xpage=$_SESSION[PGMK][NAV][BNF][\'__xpage\'];'.CRLF;
 $sourceGenere.='}'.CRLF;
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    $sourceGenere.='$xsrch_'.$count.'=saveSessionSearch1(\'xsrch_'.$count.'\',BNF);// '.$v1['nom_champ'].''.CRLF;
    $count++;
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='$xsrch_id=saveSessionSearch1(\'xsrch_id\',BNF);// '.$GLOBALS['__autoincrement'].''.CRLF;
 }

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){

   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['parentField'])){
    }else if(isset($v1['param_name'])){
    }else if(true===$v1['isNumericField']){
     $sourceGenere.='if($xsrch_'.$count.'!=\'\'){'.CRLF;
     $sourceGenere.=' if(!is_numeric($xsrch_'.$count.')){'.CRLF;
     $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\'the value must be numerical for the field\') . \' : \' . txt1(\''.$v1['nom_champ'].'\');'.CRLF;
     $sourceGenere.=' }'.CRLF;
     $sourceGenere.='}'.CRLF;
    }
    $count++;
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='if($xsrch_id!=\'\'){'.CRLF;
  $sourceGenere.=' if(!is_numeric($xsrch_id)){'.CRLF;
  $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\'the value must be numerical for the field\') . \' : \' . txt1(\''.$GLOBALS['__autoincrement'].'\');'.CRLF;
  $sourceGenere.=' }'.CRLF;
  $sourceGenere.='}'.CRLF;
 }
 
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
   if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
    $sourceGenere.='if(is_array($xsrch_'.$count.') && sizeof($xsrch_'.$count.')==1 && $xsrch_'.$count.'[0]==\'\'){ // '.$v1['nom_champ'].''.CRLF;
    $sourceGenere.=' $xsrch_'.$count.'=\'\';'.CRLF;
    $sourceGenere.='}'.CRLF;
   }
   $count++;
  }
 } 
 
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if($count==0){
     $sourceGenere.='$autofocus=\'xsrch_'.$count.'\';'.CRLF;
     $count++;
    }
   }
  }
 }

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if($count==0){
     $sourceGenere.='if($xsrch_'.$count.'!=\'\'){      $autofocus=\'xsrch_'.$count.'\'; } // '.$v1['nom_champ'].''.CRLF;
    }else{
     $sourceGenere.='else if($xsrch_'.$count.'!=\'\'){ $autofocus=\'xsrch_'.$count.'\'; } // '.$v1['nom_champ'].''.CRLF;
    }
    $count++;
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='else if($xsrch_id!=\'\'){ $autofocus=\'xsrch_id\'; }'.CRLF;
 }

 $sourceGenere.='$o1.=htmlHead1(array(\'nomenu\'=>true));'.CRLF;
 $sourceGenere.='$o1.=\'<h1>\'.txt1(\'page_title_list\');'.CRLF;
 $sourceGenere.='$o1.=\'&nbsp;<a class="buttonBack" href="\'.$_SESSION[PGMK][\'choose\'][\'urlBack\'].\'">Retour</a>\'.CRLF;'.CRLF;
 $sourceGenere.='$o1.=\'</h1>\';'.CRLF.CRLF;
 $sourceGenere.='$o1.=\' <form method="get" class="filterForm">\'.CRLF;'.CRLF;

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['param_name'])){
     $sourceGenere.='require_once($GLOBALS[\'glob_dataPath1\'].\'/generated/_params/'.$v1['param_name'].'.php\');'.CRLF;
     $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
     $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF;'.CRLF;
     
     if(isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){

      $sourceGenere.='$o1.=\'    <select size="3" name="xsrch_'.$count.'[]"   multiple="multiple" style="max-width:10em;" id="xsrch_'.$count.'" ;'.CRLF;
      $sourceGenere.='if(is_array($xsrch_'.$count.')){'.CRLF;
      $sourceGenere.=' if($xsrch_'.$count.'[0]!=\'\'){'.CRLF;
      $sourceGenere.='  $o1.=\' class="backgroundYellow"\';'.CRLF;
      $sourceGenere.=' }'.CRLF;
      $sourceGenere.='}else{'.CRLF;
      $sourceGenere.=' if($xsrch_'.$count.'!=\'\'){$o1.=\' class="backgroundYellow"\';}'.CRLF;
      $sourceGenere.='}'.CRLF;
      $sourceGenere.='$o1.=\' \'.($autofocus==\'xsrch_'.$count.'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'<option value="" \'.($xsrch_'.$count.'==\'\'?\'  selected="selected" \':\'\').\'>&nbsp;</option>\'.CRLF;'.CRLF;
      $sourceGenere.='if(!is_array($xsrch_'.$count.')) $xsrch_'.$count.'=array();'.CRLF;
      $sourceGenere.='if(is_array($xsrch_'.$count.') && in_array( \'__all_values_of_set__\' , $xsrch_'.$count.' )){'.CRLF;
      $sourceGenere.=' $o1.=\'<option value="__all_values_of_set__" selected="selected" >\'.txtsys1(\'all_values_of_set_list\').\'</option>\'.CRLF;'.CRLF;
      $sourceGenere.='}else{'.CRLF;
      $sourceGenere.=' $o1.=\'<option value="__all_values_of_set__">\'.txtsys1(\'all_values_of_set_list\').\'</option>\'.CRLF; '.CRLF;
      $sourceGenere.='}'.CRLF;
      $sourceGenere.='foreach($GLOBALS[\'param__'.$v1['param_name'].'\'][\'__values\'][$GLOBALS[\'glob_lang\']] as $kp => $vp){'.CRLF;
      $sourceGenere.=' if(in_array($kp,$xsrch_'.$count.')){'.CRLF;
      $sourceGenere.='  $o1.=\'<option value="\'.$kp.\'" selected="selected">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\'</option>\'.CRLF;'.CRLF;
      $sourceGenere.=' }else{'.CRLF;
      $sourceGenere.='  $o1.=\'<option value="\'.$kp.\'">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\' </option>\'.CRLF;  '.CRLF;
     }else{
      $sourceGenere.='$o1.=\'    <select \'.($xsrch_'.$count.'!=\'\'?\'class="backgroundYellow"\':\'\').\' name="xsrch_'.$count.'"  id="xsrch_'.$count.'" \'.($autofocus==\'xsrch_'.$count.'\'?\'autofocus="autofocus"\':\'\').\' onchange="submitListFromSelect1(this)" />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'     <option value="" \'.($xsrch_'.$count.'==\'\'?\'  selected="selected" \':\'\').\'>&nbsp;</option>\'.CRLF;'.CRLF;
      $sourceGenere.='foreach($GLOBALS[\'param__'.$v1['param_name'].'\'][\'__values\'][$GLOBALS[\'glob_lang\']] as $kp => $vp){'.CRLF;
      $sourceGenere.=' if((string)$kp==(string)$xsrch_'.$count.'){'.CRLF;
      $sourceGenere.='  $o1.=\'     <option value="\'.$kp.\'" selected="selected">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\'</option>\'.CRLF;'.CRLF;
      $sourceGenere.=' }else{'.CRLF;
      $sourceGenere.='  $o1.=\'     <option value="\'.$kp.\'">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\' </option>\'.CRLF;  '.CRLF;
     }     
     $sourceGenere.=' }'.CRLF;
     $sourceGenere.='}'.CRLF;
     $sourceGenere.='$o1.=\'    </select>\';'.CRLF;
     $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
     $sourceGenere.=CRLF.CRLF;
     $count++;
    }else{
     
     if(isset($v1['parentField'])){
      $sourceGenere.=''.CRLF;
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['parentField']['fld_parent_field_display_pglnks'].'\').\'</label>\'.CRLF; // ========== parent of '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input \'.($xsrch_'.$count.'!=\'\'?\'class="backgroundYellow"\':\'\').\' type="text" name="xsrch_'.$count.'" id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'"  size="8" maxlength="32"  \'.($autofocus==\'xsrch_'.$count.'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $sourceGenere.=''.CRLF;
      $count++;
     }else if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){
      
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input type="hidden" name="xsrch_'.$count.'" id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'"  \'.($autofocus==\'xsrch_'.$count.'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <button \'.($xsrch_'.$count.'!=\'\'?\'class="backgroundYellow"\':\'\').\' style="padding:0px!important;" type="button" id="button_color_xsrch_'.$count.'" onclick="javascript:setColor1(\\\'xsrch_'.$count.'\\\',\\\'button_color_xsrch_'.$count.'\\\',\\\'\\\',1,1)" style="border-style:outset;font-size:0.8em;padding:5px;">\';'.CRLF;
      $sourceGenere.='$o1.=($xsrch_'.$count.'==\'\'?txtsys1(\'color all\'):($xsrch_'.$count.'==\'NULL\'?txtsys1(\'color null\'):($xsrch_'.$count.'==\'NOT NULL\'?txtsys1(\'color not null\'):$xsrch_'.$count.')));'.CRLF;
      $sourceGenere.='$o1.=\'</button>\';'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $sourceGenere.=''.CRLF;
      $count++;
      
     }else if($v1['type_champ']=='datetime'){

      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input type="hidden" name="xsrch_'.$count.'"    id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'" />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <button style="padding:0px!important;font-size:0.8em;\'.($xsrch_'.$count.'!=\'\'?\'background:yellow;\':\'\').\'" type="button" id="button_datetime_xsrch_'.$count.'" onclick="javascript:setDateTime1(\\\'xsrch_'.$count.'\\\',\\\'button_datetime_xsrch_'.$count.'\\\','.($v1['null_possible']!='YES'?'0':'1').',1,\\\'onChangeDtTimListForm1\\\')">\';'.CRLF;
      $sourceGenere.='$o1.=($xsrch_'.$count.'==\'\'?txtsys1(\'datetime all\'):($xsrch_'.$count.'==\'NULL\'?txtsys1(\'datetime null\'):($xsrch_'.$count.'==\'NOT NULL\'?txtsys1(\'datetime not null\'):$xsrch_'.$count.')));'.CRLF;
      $sourceGenere.='$o1.=\'</button>\';'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $sourceGenere.=''.CRLF;
      $count++;

     }else if($v1['type_champ']=='time'){

      $timeOption=0;
      if(isset($v1['timeOption']) &&  $v1['timeOption']!='' ){
       $timeOption=$v1['timeOption'];
      }
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input type="hidden" name="xsrch_'.$count.'"    id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'" />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <button style="padding:0px!important;font-size:0.8em;\'.($xsrch_'.$count.'!=\'\'?\'background:yellow;\':\'\').\'" type="button" id="button_time_xsrch_'.$count.'" onclick="javascript:setTime1(\\\'xsrch_'.$count.'\\\',\\\'button_time_xsrch_'.$count.'\\\','.($v1['null_possible']!='YES'?'0':'1').',1,\\\'onChangeTimeListForm1\\\','.$timeOption.')">\';'.CRLF;
      $sourceGenere.='$o1.=($xsrch_'.$count.'==\'\'?txtsys1(\'time all\'):($xsrch_'.$count.'==\'NULL\'?txtsys1(\'time null\'):($xsrch_'.$count.'==\'NOT NULL\'?txtsys1(\'time not null\'):';
      if(isset($v1['timeOption']) && ( $v1['timeOption']==1 || $v1['timeOption']==3 || $v1['timeOption']==5 || $v1['timeOption']==7)){
       $sourceGenere.='substr($xsrch_'.$count.',0,5)';
      }else{
       $sourceGenere.='$xsrch_'.$count.'';       
      }
      $sourceGenere.=')));'.CRLF;
      $sourceGenere.='$o1.=\'</button>\';'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $sourceGenere.=''.CRLF;
      $count++;
      
     }else if($v1['type_champ']=='date'){
      
      $sourceGenere.='if($xsrch_'.$count.'==\'1000-01-01\') $xsrch_'.$count.'=\'\';'.CRLF;
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input type="hidden" name="xsrch_'.$count.'"    id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'" />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <button style="padding:0px!important;font-size:0.8em;\'.($xsrch_'.$count.'==\'\'?\'\':\'background:yellow;\').\'" type="button" id="button_date_xsrch_'.$count.'" onclick="javascript:setDate1(\\\'xsrch_'.$count.'\\\',\\\'button_date_xsrch_'.$count.'\\\','.($v1['null_possible']!='YES'?'0':'1').',1,\\\'onChangeDateListForm1\\\')">\';'.CRLF;
      $sourceGenere.='$o1.=(($xsrch_'.$count.'==\'1000-01-01\' || $xsrch_'.$count.'==\'\' )?txtsys1(\'date all\'):($xsrch_'.$count.'==\'NULL\'?txtsys1(\'date null\'):($xsrch_'.$count.'==\'NOT NULL\'?txtsys1(\'date not null\'):$xsrch_4)));'.CRLF;
      $sourceGenere.='$o1.=\'</button>\';'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $count++;
      
     }else{
      
      $sourceGenere.=''.CRLF;
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input \'.($xsrch_'.$count.'!=\'\'?\'class="backgroundYellow"\':\'\').\' type="text" name="xsrch_'.$count.'"    id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'"  size="8" maxlength="32" \'.($autofocus==\'xsrch_'.$count.'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $sourceGenere.=CRLF.CRLF;
      $count++;
      
     }
    }
   }
  }
 }

 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.=''.CRLF;
  $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
  $sourceGenere.='$o1.=\'    <label for="xsrch_id">\'.txt1(\''.$GLOBALS['__autoincrement'].'\').\'</label>\'.CRLF; // '.$GLOBALS['__autoincrement'].''.CRLF;
  $sourceGenere.='$o1.=\'    <input \'.($xsrch_id!=\'\'?\'class="backgroundYellow"\':\'\').\'  type="text" name="xsrch_id" id="xsrch_id" value="\'.enti1($xsrch_id).\'"  size="8" maxlength="32" \'.($autofocus==\'xsrch_id\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
  $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
  $sourceGenere.=''.CRLF;
 }

 $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
 $sourceGenere.='$o1.=\'    <button class="button_search">&#128270;</button>\'.CRLF;'.CRLF;
 $sourceGenere.='$o1.=\'    <input type="hidden" name="__xpage" id="__xpage" value="0" />\'.CRLF; // \'.$__xpage.\''.CRLF;
 $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF.CRLF;
 
 $sourceGenere.='$o1.=\' </form>\'.CRLF;'.CRLF;

 $sourceGenere.='//===================================================================================================='.CRLF;
 $sourceGenere.='$__start=$__xpage*$__nbMax;'.CRLF;
 $sourceGenere.='$_SESSION[PGMK][NAV][BNF][\'__xpage\']=$__xpage;'.CRLF;
 $sourceGenere.='$lst=\'\';'.CRLF;
 $sourceGenere.='// todo adjust the request'.CRLF;
 $sourceGenere.='$req6=\''.CRLF;
 $sourceGenere.=' SELECT  SQL_CALC_FOUND_ROWS';
 $listeChamps='';
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if($count%5==0){
    $listeChamps.=CRLF.'   ';
   }
   $listeChamps.='T0.`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).',';
   $count++;
  }
 }
 if($GLOBALS['__hasParentFields']==true){
  foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
   if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
    if(isset($v1['parentField'])){
     if($count%5==0){
      $listeChamps.=CRLF.'   ';
     }
     $GLOBALS['__listeDesChamps'][$k1]['parentField']['numSqlField']=$count;
     $listeChamps.='T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_display_pglnks'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).',';
     $count++;
    }
   }
  }
 } 
 $listeChamps=substr($listeChamps,0,-1);
 $sourceGenere.='   '.$listeChamps.CRLF;
 $sourceGenere.=' FROM (   `\'.$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\'].\'`.`'.$_GET['table'].'` T0';
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 && $v1['parentField']['fld_link_mandatory_pglnks']=='1' ){
   $sourceGenere.=CRLF.'        , ';
   $sourceGenere.='`\'.$GLOBALS[\'glob_db\']['.$v1['parentField']['fld_parent_idbase_pglnks'].'][\'dbname\'].\'`';
   $sourceGenere.='.`'.$v1['parentField']['fld_name_tables'].'` T'.$v1['parentField']['numParent1'].'';
  }
 }
 
 $sourceGenere.=' ) '.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 && $v1['parentField']['fld_link_mandatory_pglnks']=='0' ){
   $sourceGenere.=' LEFT JOIN `\'.$GLOBALS[\'glob_db\']['.$v1['parentField']['fld_parent_idbase_pglnks'].'][\'dbname\'].\'`';
   $sourceGenere.='.`'.$v1['parentField']['fld_name_tables'].'` ';
   $sourceGenere.=' T'.$v1['parentField']['numParent1'].' ON T0.`'.$v1['nom_champ'].'` = ';
   $sourceGenere.='T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_pglnks'].'` -- todo put the field name to display '.CRLF;
  }
 }
 $sourceGenere.=' WHERE 1=1 '.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 ){
   if( $v1['parentField']['fld_link_mandatory_pglnks']=='1' ){
    $sourceGenere.='   AND T0.`'.$v1['nom_champ'].'`=T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_pglnks'].'`'.CRLF;
   }
  }
 }
 $sourceGenere.='\';'.CRLF;
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){

    if(isset($v1['parentField'])){
     $sourceGenere.='if($xsrch_'.$count.'!=\'\' ){ // =========== parent field of '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.=' $req6.=\''.CRLF;
     $sourceGenere.='  AND T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_display_pglnks'].'` LIKE \\\'%\'.$xsrch_'.$count.'.\'%\\\''.CRLF;
     $sourceGenere.=' \'; '.CRLF;
     $sourceGenere.='}'.CRLF;
    }else if($v1['type_champ']=='time' || $v1['type_champ']=='date' || $v1['type_champ']=='datetime' || ( isset($v1['subtype']) && $v1['subtype']=='webcolor' ) ){
     
     $sourceGenere.='if($xsrch_'.$count.'!=\'\' ){'.CRLF;
     $sourceGenere.=' if($xsrch_'.$count.'==\'NULL\'){'.CRLF;
     $sourceGenere.='  $req6.=\''.CRLF;
     $sourceGenere.='   AND T0.`'.$v1['nom_champ'].'` IS NULL'.CRLF;
     $sourceGenere.='  \';   '.CRLF;
     $sourceGenere.=' }else if($xsrch_'.$count.'==\'NOT NULL\'){'.CRLF;
     $sourceGenere.='  $req6.=\''.CRLF;
     $sourceGenere.='   AND T0.`'.$v1['nom_champ'].'` IS NOT NULL'.CRLF;
     $sourceGenere.='  \';   '.CRLF;
     $sourceGenere.=' }else{'.CRLF;
     $sourceGenere.='  $req6.=\''.CRLF;
     $sourceGenere.='   AND T0.`'.$v1['nom_champ'].'` LIKE \\\'%\'.$xsrch_'.$count.'.\'%\\\''.CRLF;
     $sourceGenere.='  \'; '.CRLF;
     $sourceGenere.=' }'.CRLF;
     $sourceGenere.='}'.CRLF;
     
    }else if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
     
     $sourceGenere.='if($xsrch_'.$count.'!=\'\' ){'.CRLF;
     $sourceGenere.=' $req6.=buildSetCondition($xsrch_'.$count.',\'param__'.$v1['param_name'].'\', \'T0.`'.$v1['nom_champ'].'`\' );'.CRLF;
     $sourceGenere.='}'.CRLF;
     
    }else if(true===$v1['isNumericField']){
     
     $sourceGenere.='if($xsrch_'.$count.'!=\'\' && is_numeric($xsrch_'.$count.')){'.CRLF;
     $sourceGenere.=' $req6.=\''.CRLF;
     $sourceGenere.='  AND T0.`'.$v1['nom_champ'].'` = \'.$xsrch_'.$count.'.\''.CRLF;
     $sourceGenere.=' \'; '.CRLF;
     $sourceGenere.='}'.CRLF;
     
    }else{
     
     $sourceGenere.='if($xsrch_'.$count.'!=\'\' ){'.CRLF;
     $sourceGenere.=' $req6.=\''.CRLF;
     $sourceGenere.='  AND T0.`'.$v1['nom_champ'].'` LIKE \\\'%\'.$xsrch_'.$count.'.\'%\\\''.CRLF;
     $sourceGenere.=' \'; '.CRLF;
     $sourceGenere.='}'.CRLF;

    }
    $count++;
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='if($xsrch_id!=\'\' && is_numeric($xsrch_id)){'.CRLF;
  $sourceGenere.=' $req6.=\''.CRLF;
  $sourceGenere.='  AND T0.`'.$GLOBALS['__autoincrement'].'` = \'.$xsrch_id.\''.CRLF;
  $sourceGenere.=' \'; '.CRLF;
  $sourceGenere.='}'.CRLF;
 }
 $sourceGenere.='// todo adjust the order'.CRLF;
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='$req6.=\''.CRLF;
  $sourceGenere.=' ORDER BY T0.`'.$GLOBALS['__autoincrement'].'` DESC '.CRLF;
  $sourceGenere.='\'; '.CRLF;  
 }else{
  $sourceGenere.='$req6.=\''.CRLF;
  $sourceGenere.=' ORDER BY T0.`todo` DESC '.CRLF;
  $sourceGenere.='\'; '.CRLF;
 }

 $sourceGenere.='$req6.=\' LIMIT \'.$__start.\',\'.$__nbMax.\' \' ;'.CRLF;
 $sourceGenere.='//echo __FILE__ . \' \' . __LINE__ . \' $req6 = <pre>\' .$req6  . \'</pre>\' ; exit(0);'.CRLF;
 $sourceGenere.='$result6=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
 $sourceGenere.='if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])==0){'.CRLF;
 $sourceGenere.=' $reqCount6=\'SELECT FOUND_ROWS();\';'.CRLF;
 $sourceGenere.=' $rescount6=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$reqCount6);'.CRLF;
 $sourceGenere.=' if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])==0){'.CRLF;
 $sourceGenere.='  $mpsrcount6=mysqli_fetch_row($rescount6);'.CRLF;
 $sourceGenere.='  $__count=$mpsrcount6[0];'.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' $lsttbl=\'\';'.CRLF;
 $sourceGenere.=' if($__count==0){'.CRLF;
 $sourceGenere.='  $lst.=\'<p>\'.CRLF;'.CRLF;
 $sourceGenere.='  $lst.=\'\'.txt1(\'no_record_founded\').\'\'.CRLF;'.CRLF;
 $sourceGenere.='  $lst.=\'</p>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'\'.$lst.\'\'.CRLF;  '.CRLF;
 $sourceGenere.=' }else{'.CRLF;


 $sourceGenere.='  $consUrlRedir=\'\'.'.CRLF;

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
    }else{
     $sourceGenere.='                \'&amp;xsrch_'.$count.'=\'.rawurlencode($xsrch_'.$count.'). // '.$v1['nom_champ'].' '.CRLF;    
    }
    $count++;
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='                \'&amp;xsrch_id=\'.rawurlencode($xsrch_id).'.CRLF;
 }
 $sourceGenere.='                \'\';'.CRLF;
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){

     $sourceGenere.='  if(is_array($xsrch_'.$count.')){'.CRLF;
     $sourceGenere.='   foreach($xsrch_'.$count.' as $k1 => $v1){'.CRLF;
     $sourceGenere.='    $consUrlRedir.=\'&amp;xsrch_'.$count.'%5B%5D=\'.rawurlencode($v1);'.CRLF;
     $sourceGenere.='   }'.CRLF;
     $sourceGenere.='  }else{'.CRLF;
     $sourceGenere.='   $consUrlRedir.=\'&amp;xsrch_'.$count.'=\'.rawurlencode($xsrch_'.$count.'); // '.$v1['nom_champ'].CRLF;
     $sourceGenere.='  }'.CRLF;
     
    }
    $count++;
   }
  }
 }
 
 $sourceGenere.='  $ri=\' <span class="btn unset">&raquo;</span>\';'.CRLF;
 $sourceGenere.='  if($__start+$__nbMax<$__count){'.CRLF;
 $sourceGenere.='   $ri=\' <a href="\'.BNF.\'?__xpage=\'.($__xpage+1).$consUrlRedir.\'">&raquo;</a>\';'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  $le=\' <span class="btn unset">&laquo;</span>\';'.CRLF;
 $sourceGenere.='  if($__xpage>0){'.CRLF;
 $sourceGenere.='   $le=\' <a href="\'.BNF.\'?__xpage=\'.($__xpage-1).$consUrlRedir.\'">&laquo;</a>\';'.CRLF;
 $sourceGenere.='  }'.CRLF;
 
 
 $sourceGenere.='$css=\'<style type="text/css">'.CRLF;
 $sourceGenere.='@media screen and (max-width: 890px){/* todo adjust size */'.CRLF;
 $sourceGenere.='  table.tableResult1 {'.CRLF;
 $sourceGenere.='    border: 0;'.CRLF;
 $sourceGenere.='    width:100%;'.CRLF;
 $sourceGenere.='    max-width:540px;'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  table.tableResult1 thead {'.CRLF;
 $sourceGenere.='    border: none;'.CRLF;
 $sourceGenere.='    clip: rect(0 0 0 0);'.CRLF;
 $sourceGenere.='    height: 1px;'.CRLF;
 $sourceGenere.='    margin: -1px;'.CRLF;
 $sourceGenere.='    overflow: hidden;'.CRLF;
 $sourceGenere.='    padding: 0;'.CRLF;
 $sourceGenere.='    position: absolute;'.CRLF;
 $sourceGenere.='    width: 1px;'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  table.tableResult1 tr {'.CRLF;
 $sourceGenere.='    border-bottom: 3px solid #eee;'.CRLF;
 $sourceGenere.='    display: block;'.CRLF;
 $sourceGenere.='    margin-bottom: 2.001em;'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  table.tableResult1 td {'.CRLF;
 $sourceGenere.='    border-bottom: 1px solid #eee;'.CRLF;
 $sourceGenere.='    display: block;'.CRLF;
 $sourceGenere.='    text-align: right!important;'.CRLF;
 $sourceGenere.='    min-height:30px;'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  table.tableResult1 td:before {'.CRLF;
 $sourceGenere.='    content: attr(data-label);'.CRLF;
 $sourceGenere.='    float: left!important;'.CRLF;
 $sourceGenere.='    font-weight:bold;'.CRLF;
 $sourceGenere.='    margin-right:5px;'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  table.tableResult1 td:last-child{border-bottom: 0;}'.CRLF;
 $sourceGenere.='  table.tableResult1 td.actionColumn div{display:contents;}'.CRLF;
 $sourceGenere.='  table.tableResult1 td.actionColumn{height:auto;}'.CRLF;
 $sourceGenere.='  .tableResult1 td {height:auto;word-break: break-all;}'.CRLF;
 $sourceGenere.='  .tableResult1 td pre {word-break: break-all;white-space: pre-line;}'.CRLF;
 $sourceGenere.='}'.CRLF;
 $sourceGenere.='</style>\';'.CRLF;
 $sourceGenere.='  $o1.=$css;'.CRLF.CRLF;
 $sourceGenere.='  $lsttbl.=\'<thead><tr>\';'.CRLF;
 $sourceGenere.='  $lsttbl.=\'<th style="min-width:85px;">\'.txtsys1(\'column_action\').\'</th>\';'.CRLF;

 $count=0;
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='  $lsttbl.=\'<th>\'.txt1(\''.$GLOBALS['__autoincrement'].'\').\'</th>\';'.CRLF;
 }
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if(isset($v1['parentField'])){
    $sourceGenere.='  $lsttbl.=\'<th>\'.txt1(\''.$v1['parentField']['fld_parent_field_display_pglnks'].'\').\'</th>\'; // ======== parent field of '.$v1['nom_champ'].''.CRLF;
   }else if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    $sourceGenere.='  $lsttbl.=\'<th>\'.txt1(\''.$v1['nom_champ'].'\').\'</th>\';'.CRLF;
   }
  }
 }


 $sourceGenere.='  $lsttbl.=\'</tr></thead><tbody>\';'.CRLF;
 $sourceGenere.='  while($mpsr6=mysqli_fetch_row($result6)){'.CRLF;
 $sourceGenere.='   '.CRLF;
 $sourceGenere.='   $lsttbl.=\'<tr>\';'.CRLF;
 $sourceGenere.='   '.CRLF;
 $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txtsys1(\'column_action\').\'">\';'.CRLF;
 $sourceGenere.='   $lsttbl.=\'<div>\';'.CRLF;
 $sourceGenere.='   $lsttbl.=\'<a href="\'.BNF.\'?idchoose=\'.$mpsr6[0].\'">\'.txtsys1(\'text_for_the_select_button\') . \'</a>\';'.CRLF;
 $sourceGenere.='   $lsttbl.=\'</div>\';'.CRLF;
 $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
 
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){

    $sourceGenere.='    $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'">\'; // '.$v1['nom_champ'].''.CRLF;
    $sourceGenere.='    if($mpsr6['.$count.']==\'\'){'.CRLF;
    $sourceGenere.='     $lsttbl.=\'\'.enti1($mpsr6['.$count.']).\'\'; '.CRLF;
    $sourceGenere.='    }else{'.CRLF;
    $sourceGenere.='     $val=json_decode($mpsr6['.$count.'],true);'.CRLF;
    $sourceGenere.='     $lsttbl.=\'<div style="display:inline-block;width:35px;height:20px;border:1px #eee outset;background-color:#\'.$val[\'hexValue\'].\'"></div>\';'.CRLF;
    $sourceGenere.='     $lsttbl.=\'\'.enti1($val[\'hexValue\']).\'\';'.CRLF;
    $sourceGenere.='     if(isset($val[\'webName\']) && $val[\'webName\']!=\'\'){'.CRLF;
    $sourceGenere.='      $lsttbl.=\'<br />\'.enti1($val[\'webName\']).\'\';'.CRLF;
    $sourceGenere.='     }'.CRLF;
    $sourceGenere.='     if(isset($val[\'pantoneName\']) && $val[\'pantoneName\']!=\'\'){'.CRLF;
    $sourceGenere.='      $lsttbl.=\'<br /> pantone:\'.enti1($val[\'pantoneName\']).\'\';'.CRLF;
    $sourceGenere.='     }'.CRLF;
    $sourceGenere.='    }'.CRLF;
    $sourceGenere.='    $lsttbl.=\'</td>\';'.CRLF.CRLF;
    $count++;

   }else if(isset($v1['param_name'])){
    $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'">\';'.CRLF;
    $sourceGenere.='   require_once($GLOBALS[\'glob_dataPath1\'].\'/generated/_params/'.$v1['param_name'].'.php\');'.CRLF;
    $sourceGenere.='   $lsttbl.=displayParam1(\''.$v1['param_name'].'\',$mpsr6['.$count.'],array(\'unsetPossible\'=>'.(isset($v1['unsetPossible']) && $v1['unsetPossible']==true?'true':'false').')); // '.$v1['nom_champ'].''.CRLF;
    $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
    $count++;
   }else{
    if(isset($v1['parentField'])){
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['parentField']['fld_parent_field_display_pglnks'].'\').\'">\'; // ====== parent field of '.$v1['nom_champ'].''.CRLF;    
     $sourceGenere.='   $lsttbl.=\'\'.enti1($mpsr6['.$v1['parentField']['numSqlField'].']).\'\'; // '.$v1['nom_champ'].' parent of $mpsr6['.$count.']'.CRLF;
     $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
    }else if($v1['type_champ']===$GLOBALS['__autoincrement']){
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'" style="text-align:center;">\';'.CRLF;    
     $sourceGenere.='   $lsttbl.=\'\'.enti1($mpsr6['.$count.']).\'\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
    }else if($v1['type_champ']=='time' || $v1['type_champ']=='date' || $v1['type_champ']=='datetime'){
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'" style="text-align:center;">\';'.CRLF;    
     $sourceGenere.='   $lsttbl.=\'\'.enti1($mpsr6['.$count.']).\'\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
    }else if(true===$v1['isNumericField']){
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'" style="text-align:right;">\';'.CRLF;    
     $sourceGenere.='   $lsttbl.=\'\'.enti1($mpsr6['.$count.']).\'\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
    }else if(strpos(strtolower($v1['type_champ']),'text')     !==false ){
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'"><pre>\';'.CRLF;    
     $sourceGenere.='   $lsttbl.=\'\'.enti1(mb_substr($mpsr6['.$count.'],0,100,\'UTF-8\')).\'\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='   $lsttbl.=\'</pre></td>\';'.CRLF.CRLF;
    }else{
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'">\';'.CRLF;    
     $sourceGenere.='   $lsttbl.=\'\'.enti1($mpsr6['.$count.']).\'\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
    }
    $count++;
   }
  }
 }


 $sourceGenere.='   $lsttbl.=\'</tr>\';'.CRLF;
 $sourceGenere.='   '.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  $o1.=\'<table class="tableResult1">\'.CRLF.$lsttbl.\'</tbody></table>\'.CRLF;'.CRLF;
 $sourceGenere.='   '.CRLF;
 $sourceGenere.='  $o1.=\' <div>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'   \'.$le.\' \'.$ri.\' page \'.($__xpage+1).\'/\'.ceil($__count/$__nbMax).\' (\'.$__count.\' \'.txt1(\'number_of_records\').\' )\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF;
 $sourceGenere.='   '.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' mysqli_free_result($result6);'.CRLF;
 $sourceGenere.='}else{'.CRLF;
 $sourceGenere.=' $o1.=debugSql1(array(\'sqler\' => mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']),\'reque\' => $req6)); '.CRLF;
 $sourceGenere.='}'.CRLF;
 $sourceGenere.='$o1.=\'<script type="text/javascript">var globalChooseUrlBack=\\\'\'.$_SESSION[PGMK][\'choose\'][\'urlBack\'].\'\\\';</script>\';'.CRLF;
 $sourceGenere.='$o1.=htmlFoot0(array());'.CRLF;
 $sourceGenere.='dw1($o1);'.CRLF;
}
//========================================================================================================================
//========================================================================================================================
//========================================================================================================================
if(isset($_GET['a']) && $_GET['a']=='list1'){
 getTableInfos($_GET);
 $sourceGenere.='<'.'?php'.CRLF;
 $sourceGenere.='define(\'BNF\',basename( __FILE__ ));'.CRLF;
 $sourceGenere.='require_once \'za_inc.php\';'.CRLF;
 $sourceGenere.='session_start();'.CRLF;
 $sourceGenere.='@include  $GLOBALS[\'glob_dataPath1\'].\'/generated/lang/\'.$GLOBALS[\'glob_lang\'].\'_\'.BNF;'.CRLF;
 $sourceGenere.='checkGroupPages();'.CRLF;
 $sourceGenere.='openDb2();'.CRLF;
 $sourceGenere.='//========================================================================================================================'.CRLF;
 $sourceGenere.='$o1=\'\';'.CRLF;
 $sourceGenere.='$__nbMax=20;'.CRLF;
 $sourceGenere.='$__start=0;'.CRLF;
 $sourceGenere.='$__count=0;'.CRLF;
 $sourceGenere.='$__xpage=0;'.CRLF;
 $sourceGenere.='if(isset($_GET[\'__xpage\'])&&is_numeric($_GET[\'__xpage\'])){'.CRLF;
 $sourceGenere.=' $__xpage=$_GET[\'__xpage\'];'.CRLF;
 $sourceGenere.='}else{'.CRLF;
 $sourceGenere.=' if(isset($_SESSION[PGMK][NAV][BNF][\'__xpage\'])) $__xpage=$_SESSION[PGMK][NAV][BNF][\'__xpage\'];'.CRLF;
 $sourceGenere.='}'.CRLF;
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    $sourceGenere.='$xsrch_'.$count.'=saveSessionSearch1(\'xsrch_'.$count.'\',BNF);// '.$v1['nom_champ'].''.CRLF;
    $count++;
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='$xsrch_id=saveSessionSearch1(\'xsrch_id\',BNF);// '.$GLOBALS['__autoincrement'].''.CRLF;
 }

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['param_name'])){
    }else if(isset($v1['parentField'])){
    }else{
     if(true===$v1['isNumericField']){
      $sourceGenere.='if($xsrch_'.$count.'!=\'\'){'.CRLF;
      $sourceGenere.=' if(!is_numeric($xsrch_'.$count.')){'.CRLF;
      $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\'the value must be numerical for the field\') . \' : \' . txt1(\''.$v1['nom_champ'].'\');'.CRLF;
      $sourceGenere.=' }'.CRLF;
      $sourceGenere.='}'.CRLF;
     }
    }
    $count++;
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='if($xsrch_id!=\'\'){'.CRLF;
  $sourceGenere.=' if(!is_numeric($xsrch_id)){'.CRLF;
  $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\'the value must be numerical for the field\') . \' : \' . txt1(\''.$GLOBALS['__autoincrement'].'\');'.CRLF;
  $sourceGenere.=' }'.CRLF;
  $sourceGenere.='}'.CRLF;
 }

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
   if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
    $sourceGenere.='if(is_array($xsrch_'.$count.') && sizeof($xsrch_'.$count.')==1 && $xsrch_'.$count.'[0]==\'\'){ // '.$v1['nom_champ'].''.CRLF;
    $sourceGenere.=' $xsrch_'.$count.'=\'\';'.CRLF;
    $sourceGenere.='}'.CRLF;
   }
   $count++;
  }
 } 

 
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if($count==0){
     $sourceGenere.='$autofocus=\'xsrch_'.$count.'\';'.CRLF;
     $count++;
    }
   }
  }
 }

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if($count==0){
     $sourceGenere.='if($xsrch_'.$count.'!=\'\'){      $autofocus=\'xsrch_'.$count.'\'; } // '.$v1['nom_champ'].''.CRLF;
    }else{
     $sourceGenere.='else if($xsrch_'.$count.'!=\'\'){ $autofocus=\'xsrch_'.$count.'\'; } // '.$v1['nom_champ'].''.CRLF;
    }
    $count++;
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='else if($xsrch_id!=\'\'){ $autofocus=\'xsrch_id\'; }'.CRLF;
 }

 $sourceGenere.='$o1.=htmlHead1(array(\'nomenu\'=>true));'.CRLF;
 $sourceGenere.='$o1.=\'<h1>\'.txt1(\'page_title_list\').\'</h1>\';'.CRLF;
 $sourceGenere.='$o1.=displaySessionMessage1(BNF);'.CRLF.CRLF;
 $sourceGenere.='$o1.=\' <form method="get" class="filterForm">\'.CRLF;'.CRLF;

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
//    echo __FILE__ . ' ' . __LINE__ . ' $v1 = <pre>' . var_export( $v1 , true ) . '</pre>' ; 
    if(isset($v1['param_name'])){
     $sourceGenere.='require_once($GLOBALS[\'glob_dataPath1\'].\'/generated/_params/'.$v1['param_name'].'.php\');'.CRLF;
     $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
     $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF;'.CRLF;
     if(isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){

      $sourceGenere.='$o1.=\'    <select size="3" name="xsrch_'.$count.'[]"   multiple="multiple" style="max-width:10em;" id="xsrch_'.$count.'" \'.($autofocus==\'xsrch_'.$count.'\'?\'autofocus="autofocus"\':\'\').\' \';'.CRLF;
      $sourceGenere.='if(is_array($xsrch_'.$count.')){'.CRLF;
      $sourceGenere.=' if($xsrch_'.$count.'[0]!=\'\'){'.CRLF;
      $sourceGenere.='  $o1.=\' class="backgroundYellow" \';'.CRLF;
      $sourceGenere.=' }'.CRLF;
      $sourceGenere.='}else{'.CRLF;
      $sourceGenere.=' if($xsrch_'.$count.'!=\'\'){$o1.=\' class="backgroundYellow" \';}'.CRLF;
      $sourceGenere.='}'.CRLF;
      $sourceGenere.='$o1.=\'  />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'<option value="" \'.($xsrch_'.$count.'==\'\'?\'  selected="selected" \':\'\').\'>&nbsp;</option>\'.CRLF;'.CRLF;
      $sourceGenere.='if(!is_array($xsrch_'.$count.')) $xsrch_'.$count.'=array();'.CRLF;
      $sourceGenere.='if(is_array($xsrch_'.$count.') && in_array( \'__all_values_of_set__\' , $xsrch_'.$count.' )){'.CRLF;
      $sourceGenere.=' $o1.=\'<option value="__all_values_of_set__" selected="selected" >\'.txtsys1(\'all_values_of_set_list\').\'</option>\'.CRLF;'.CRLF;
      $sourceGenere.='}else{'.CRLF;
      $sourceGenere.=' $o1.=\'<option value="__all_values_of_set__">\'.txtsys1(\'all_values_of_set_list\').\'</option>\'.CRLF; '.CRLF;
      $sourceGenere.='}'.CRLF;
      $sourceGenere.='foreach($GLOBALS[\'param__'.$v1['param_name'].'\'][\'__values\'][$GLOBALS[\'glob_lang\']] as $kp => $vp){'.CRLF;
      $sourceGenere.=' if(in_array($kp,$xsrch_'.$count.')){'.CRLF;
      $sourceGenere.='  $o1.=\'<option value="\'.$kp.\'" selected="selected">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\'</option>\'.CRLF;'.CRLF;
      $sourceGenere.=' }else{'.CRLF;
      $sourceGenere.='  $o1.=\'<option value="\'.$kp.\'">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\' </option>\'.CRLF;  '.CRLF;
      $sourceGenere.=' }'.CRLF;
      $sourceGenere.='}'.CRLF;
      $sourceGenere.='$o1.=\'    </select>\';'.CRLF;
     
     }else{
      
      $sourceGenere.='$o1.=\'    <select \'.($xsrch_'.$count.'!=\'\'?\'class="backgroundYellow"\':\'\').\' name="xsrch_'.$count.'"  id="xsrch_'.$count.'" \'.($autofocus==\'xsrch_'.$count.'\'?\'autofocus="autofocus"\':\'\').\' onchange="submitListFromSelect1(this)" />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'<option value="" \'.($xsrch_'.$count.'==\'\'?\'  selected="selected" \':\'\').\'>&nbsp;</option>\'.CRLF;'.CRLF;
      $sourceGenere.='foreach($GLOBALS[\'param__'.$v1['param_name'].'\'][\'__values\'][$GLOBALS[\'glob_lang\']] as $kp => $vp){'.CRLF;
      $sourceGenere.=' if((string)$kp==(string)$xsrch_'.$count.'){'.CRLF;
      $sourceGenere.='  $o1.=\'<option value="\'.$kp.\'" selected="selected">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\'</option>\'.CRLF;'.CRLF;
      $sourceGenere.=' }else{'.CRLF;
      $sourceGenere.='  $o1.=\'<option value="\'.$kp.\'">\'.$vp[$GLOBALS[\'param__'.$v1['param_name'].'\'][\'param__Name__Display\']].\' </option>\'.CRLF;  '.CRLF;
      $sourceGenere.=' }'.CRLF;
      $sourceGenere.='}'.CRLF;
      $sourceGenere.='$o1.=\'    </select>\';'.CRLF;
      
     }
     $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF.CRLF;
     $count++;
    }else{
     if(isset($v1['parentField'])){
      $sourceGenere.=''.CRLF;
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['parentField']['fld_parent_field_display_pglnks'].'\').\'</label>\'.CRLF; // ========== parent of '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input \'.($xsrch_'.$count.'!=\'\'?\'class="backgroundYellow"\':\'\').\' type="text" name="xsrch_'.$count.'" id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'"  size="8" maxlength="32"  \'.($autofocus==\'xsrch_'.$count.'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $sourceGenere.=''.CRLF;
      $count++;
     }else if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){
      
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input type="hidden" name="xsrch_'.$count.'" id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'"  \'.($autofocus==\'xsrch_'.$count.'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <button \'.($xsrch_'.$count.'!=\'\'?\'class="backgroundYellow"\':\'\').\' style="padding:0px!important;" type="button" id="button_color_xsrch_'.$count.'" onclick="javascript:setColor1(\\\'xsrch_'.$count.'\\\',\\\'button_color_xsrch_'.$count.'\\\',\\\'\\\',1,1)" style="border-style:outset;font-size:0.8em;padding:5px;">\';'.CRLF;
      $sourceGenere.='$o1.=($xsrch_'.$count.'==\'\'?txtsys1(\'color all\'):($xsrch_'.$count.'==\'NULL\'?txtsys1(\'color null\'):($xsrch_'.$count.'==\'NOT NULL\'?txtsys1(\'color not null\'):$xsrch_'.$count.')));'.CRLF;
      $sourceGenere.='$o1.=\'</button>\';'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      
      $count++;
      
     }else if($v1['type_champ']=='datetime'){
      
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input type="hidden" name="xsrch_'.$count.'"    id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'" />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <button type="button" id="button_datetime_xsrch_'.$count.'" onclick="javascript:setDateTime1(\\\'xsrch_'.$count.'\\\',\\\'button_datetime_xsrch_'.$count.'\\\','.($v1['null_possible']!='YES'?'0':'1').',1,\\\'onChangeDtTimListForm1\\\')" style="padding:0px!important;border-style:outset;font-size:0.8em;\'.($xsrch_'.$count.'!=\'\'?\'background:yellow;\':\'\').\'">\';'.CRLF;
      $sourceGenere.='$o1.=($xsrch_'.$count.'==\'\'?txtsys1(\'datetime all\'):($xsrch_'.$count.'==\'NULL\'?txtsys1(\'datetime null\'):($xsrch_'.$count.'==\'NOT NULL\'?txtsys1(\'datetime not null\'):$xsrch_'.$count.')));'.CRLF;
      $sourceGenere.='$o1.=\'</button>\';'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $sourceGenere.=''.CRLF;
      $count++;
      
     }else if($v1['type_champ']=='time'){
      
      $timeOption=0;
      if(isset($v1['timeOption']) &&  $v1['timeOption']!='' ){
       $timeOption=$v1['timeOption'];
      }
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input type="hidden" name="xsrch_'.$count.'"    id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'" />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <button type="button" id="button_time_xsrch_'.$count.'" onclick="javascript:setTime1(\\\'xsrch_'.$count.'\\\',\\\'button_time_xsrch_'.$count.'\\\','.($v1['null_possible']!='YES'?'0':'1').',1,\\\'onChangeTimeListForm1\\\','.$timeOption.')" style="padding:0px!important;border-style:outset;font-size:0.8em;padding:5px;\'.($xsrch_'.$count.'!=\'\'?\'background:yellow;\':\'\').\'">\';'.CRLF;
      $sourceGenere.='$o1.=($xsrch_'.$count.'==\'\'?txtsys1(\'time all\'):($xsrch_'.$count.'==\'NULL\'?txtsys1(\'time null\'):($xsrch_'.$count.'==\'NOT NULL\'?txtsys1(\'time not null\'):';
      if(isset($v1['timeOption']) && ( $v1['timeOption']==1 || $v1['timeOption']==3 || $v1['timeOption']==5 || $v1['timeOption']==7)){
       $sourceGenere.='substr($xsrch_'.$count.',0,5)';       
      }else{
       $sourceGenere.='$xsrch_'.$count.'';
      }
      $sourceGenere.=')));'.CRLF;
      $sourceGenere.='$o1.=\'</button>\';'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $sourceGenere.=''.CRLF;
      $count++;

      
     }else if($v1['type_champ']=='date'){
      $sourceGenere.='if($xsrch_'.$count.'==\'1000-01-01\') $xsrch_'.$count.'=\'\';'.CRLF;
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input type="hidden" name="xsrch_'.$count.'"    id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'" />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <button type="button" id="button_date_xsrch_'.$count.'" onclick="javascript:setDate1(\\\'xsrch_'.$count.'\\\',\\\'button_date_xsrch_'.$count.'\\\','.($v1['null_possible']!='YES'?'0':'1').',1,\\\'onChangeDateListForm1\\\')" style="padding:0px!important;font-size:0.8em;border-style:outset;\'.($xsrch_'.$count.'==\'\'?\'\':\'background:yellow;\').\'">\';'.CRLF;
      $sourceGenere.='$o1.=(($xsrch_'.$count.'==\'1000-01-01\' || $xsrch_'.$count.'==\'\' )?txtsys1(\'date all\'):($xsrch_'.$count.'==\'NULL\'?txtsys1(\'date null\'):($xsrch_'.$count.'==\'NOT NULL\'?txtsys1(\'date not null\'):$xsrch_4)));'.CRLF;
      $sourceGenere.='$o1.=\'</button>\';'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $sourceGenere.=''.CRLF;
      $count++;
     }else{
      $sourceGenere.=''.CRLF;
      $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'    <label for="xsrch_'.$count.'">\'.txt1(\''.$v1['nom_champ'].'\').\'</label>\'.CRLF; // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='$o1.=\'    <input \'.($xsrch_'.$count.'!=\'\'?\'class="backgroundYellow"\':\'\').\' type="text" name="xsrch_'.$count.'" id="xsrch_'.$count.'"   value="\'.enti1($xsrch_'.$count.').\'"  size="8" maxlength="32"  \'.($autofocus==\'xsrch_'.$count.'\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
      $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
      $sourceGenere.=''.CRLF;
      $count++;
     }
    }
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.=''.CRLF;
  $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
  $sourceGenere.='$o1.=\'    <label for="xsrch_id">\'.txt1(\''.$GLOBALS['__autoincrement'].'\').\'</label>\'.CRLF; // '.$GLOBALS['__autoincrement'].''.CRLF;
  $sourceGenere.='$o1.=\'    <input \'.($xsrch_id!=\'\'?\'class="backgroundYellow"\':\'\').\' type="text" name="xsrch_id"    id="xsrch_id"   value="\'.enti1($xsrch_id).\'"  size="8" maxlength="32" \'.($autofocus==\'xsrch_id\'?\'autofocus="autofocus"\':\'\').\' />\'.CRLF;'.CRLF;
  $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF;
  $sourceGenere.=''.CRLF;
 }

 $sourceGenere.='$o1.=\'   <div>\'.CRLF;'.CRLF;
 $sourceGenere.='$o1.=\'    <button class="button_search">&#128270;</button>\'.CRLF;'.CRLF;
 $sourceGenere.='$o1.=\'    <input type="hidden" name="__xpage" id="__xpage" value="0" />\'.CRLF; // \'.$__xpage.\''.CRLF;
 $sourceGenere.='$o1.=\'   </div>\'.CRLF;'.CRLF.CRLF;

 $sourceGenere.='$o1.=\' </form>\'.CRLF;'.CRLF;

 $sourceGenere.='//===================================================================================================='.CRLF;
 $sourceGenere.='$__start=$__xpage*$__nbMax;'.CRLF;
 $sourceGenere.='$_SESSION[PGMK][NAV][BNF][\'__xpage\']=$__xpage;'.CRLF;
 $sourceGenere.='$lst=\'\';'.CRLF;
 $sourceGenere.='// todo adjust the request'.CRLF;
 $sourceGenere.='$req6=\''.CRLF;
 $sourceGenere.=' SELECT  SQL_CALC_FOUND_ROWS';
 $listeChamps='';
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if($count%5==0){
    $listeChamps.=CRLF.'   ';
   }
   $listeChamps.='T0.`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).',';
   $count++;
  }
 }
 if($GLOBALS['__hasParentFields']==true){
  foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
   if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
    if(isset($v1['parentField'])){
     if($count%5==0){
      $listeChamps.=CRLF.'   ';
     }
     $GLOBALS['__listeDesChamps'][$k1]['parentField']['numSqlField']=$count;
     $listeChamps.='T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_display_pglnks'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ']) ).',';
     $count++;
    }
   }
  }
 } 
 $listeChamps=substr($listeChamps,0,-1);
 $sourceGenere.='   '.$listeChamps.CRLF;
 $sourceGenere.=' FROM (   `\'.$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\'].\'`.`'.$_GET['table'].'` T0';
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 && $v1['parentField']['fld_link_mandatory_pglnks']=='1' ){
   $sourceGenere.=CRLF.'        , ';
   $sourceGenere.='`\'.$GLOBALS[\'glob_db\']['.$v1['parentField']['fld_parent_idbase_pglnks'].'][\'dbname\'].\'`';
   $sourceGenere.='.`'.$v1['parentField']['fld_name_tables'].'` T'.$v1['parentField']['numParent1'].'';
  }
 }
 
 $sourceGenere.=' ) '.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 && $v1['parentField']['fld_link_mandatory_pglnks']=='0' ){
   $sourceGenere.=' LEFT JOIN `\'.$GLOBALS[\'glob_db\']['.$v1['parentField']['fld_parent_idbase_pglnks'].'][\'dbname\'].\'`';
   $sourceGenere.='.`'.$v1['parentField']['fld_name_tables'].'` ';
   $sourceGenere.=' T'.$v1['parentField']['numParent1'].' ON T0.`'.$v1['nom_champ'].'` = ';
   $sourceGenere.='T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_pglnks'].'`'.CRLF;
  }
 }

 $sourceGenere.=' WHERE 1=1 '.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 ){
   if( $v1['parentField']['fld_link_mandatory_pglnks']=='1' ){
    $sourceGenere.='   AND T0.`'.$v1['nom_champ'].'`=T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_pglnks'].'`'.CRLF;
   }
  }
 }
 $sourceGenere.='\';'.CRLF;
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    
    if(isset($v1['parentField'])){
     $sourceGenere.='if($xsrch_'.$count.'!=\'\' ){ // =========== parent field of '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.=' $req6.=\''.CRLF;
     $sourceGenere.='  AND T'.$v1['parentField']['numParent1'].'.`'.$v1['parentField']['fld_parent_field_display_pglnks'].'` LIKE \\\'%\'.$xsrch_'.$count.'.\'%\\\''.CRLF;
     $sourceGenere.=' \'; '.CRLF;
     $sourceGenere.='}'.CRLF;
    }else if($v1['type_champ']=='date' || $v1['type_champ']=='time' || $v1['type_champ']=='datetime' || ( isset($v1['subtype']) && $v1['subtype']=='webcolor' ) ){
     
     $sourceGenere.='if($xsrch_'.$count.'!=\'\' ){'.CRLF;
     $sourceGenere.=' if($xsrch_'.$count.'==\'NULL\'){'.CRLF;
     $sourceGenere.='  $req6.=\''.CRLF;
     $sourceGenere.='   AND T0.`'.$v1['nom_champ'].'` IS NULL'.CRLF;
     $sourceGenere.='  \';   '.CRLF;
     $sourceGenere.=' }else if($xsrch_'.$count.'==\'NOT NULL\'){'.CRLF;
     $sourceGenere.='  $req6.=\''.CRLF;
     $sourceGenere.='   AND T0.`'.$v1['nom_champ'].'` IS NOT NULL'.CRLF;
     $sourceGenere.='  \';   '.CRLF;
     $sourceGenere.=' }else{'.CRLF;
     $sourceGenere.='  $req6.=\''.CRLF;
     $sourceGenere.='   AND T0.`'.$v1['nom_champ'].'` LIKE \\\'%\'.$xsrch_'.$count.'.\'%\\\''.CRLF;
     $sourceGenere.='  \'; '.CRLF;
     $sourceGenere.=' }'.CRLF;
     $sourceGenere.='}'.CRLF;
     
    }else if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){

     $sourceGenere.='if($xsrch_'.$count.'!=\'\' ){'.CRLF;
     $sourceGenere.=' $req6.=buildSetCondition($xsrch_'.$count.',\'param__'.$v1['param_name'].'\', \'T0.`'.$v1['nom_champ'].'`\' );'.CRLF;
     $sourceGenere.='}'.CRLF;
    
    }else if(true===$v1['isNumericField']){
     
     $sourceGenere.='if($xsrch_'.$count.'!=\'\' && is_numeric($xsrch_'.$count.')){'.CRLF;
     $sourceGenere.=' $req6.=\''.CRLF;
     $sourceGenere.='  AND T0.`'.$v1['nom_champ'].'` = \'.$xsrch_'.$count.'.\''.CRLF;
     $sourceGenere.=' \'; '.CRLF;
     $sourceGenere.='}'.CRLF;
     
    }else{
     
     $sourceGenere.='if($xsrch_'.$count.'!=\'\' ){'.CRLF;
     $sourceGenere.=' $req6.=\''.CRLF;
     $sourceGenere.='  AND T0.`'.$v1['nom_champ'].'` LIKE \\\'%\'.$xsrch_'.$count.'.\'%\\\''.CRLF;
     $sourceGenere.=' \'; '.CRLF;
     $sourceGenere.='}'.CRLF;
     
    }
    $count++;
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='if($xsrch_id!=\'\' && is_numeric($xsrch_id)){'.CRLF;
  $sourceGenere.=' $req6.=\''.CRLF;
  $sourceGenere.='  AND T0.`'.$GLOBALS['__autoincrement'].'` = \'.$xsrch_id.\''.CRLF;
  $sourceGenere.=' \'; '.CRLF;
  $sourceGenere.='}'.CRLF;
 }
 $sourceGenere.='// todo adjust the order'.CRLF;
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='$req6.=\''.CRLF;
  $sourceGenere.=' ORDER BY T0.`'.$GLOBALS['__autoincrement'].'` DESC '.CRLF;
  $sourceGenere.='\'; '.CRLF;
 }else{
  $sourceGenere.='$req6.=\''.CRLF;
  $sourceGenere.=' ORDER BY T0.`todo` DESC '.CRLF;
  $sourceGenere.='\'; '.CRLF;
 }

 $sourceGenere.='$req6.=\' LIMIT \'.$__start.\',\'.$__nbMax.\' \' ;'.CRLF;
 $sourceGenere.='//echo __FILE__ . \' \' . __LINE__ . \' $req6 = <pre>\' .$req6  . \'</pre>\' ; exit(0);'.CRLF;
 $sourceGenere.='$result6=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
 $sourceGenere.='if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])==0){'.CRLF;
 $sourceGenere.=' $reqCount6=\'SELECT FOUND_ROWS();\';'.CRLF;
 $sourceGenere.=' $rescount6=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$reqCount6);'.CRLF;
 $sourceGenere.=' if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])==0){'.CRLF;
 $sourceGenere.='  $mpsrcount6=mysqli_fetch_row($rescount6);'.CRLF;
 $sourceGenere.='  $__count=$mpsrcount6[0];'.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' $lsttbl=\'\';'.CRLF;
 $sourceGenere.=' if($__count==0){'.CRLF;
 $sourceGenere.='  $lst.=\'<p>\'.CRLF;'.CRLF;
 $sourceGenere.='  $lst.=\'\'.txt1(\'no_record_founded\').\'\'.CRLF;'.CRLF;
 $sourceGenere.='  $lst.=\'<a href="'.substr(strtolower($GLOBALS['funcname']),4).'_action1.php?a=c">\'.txt1(\'add_a_new_record\').\'</a>\'.CRLF; // todo adjust '.CRLF;
 $sourceGenere.='  $lst.=\'</p>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'\'.$lst.\'\'.CRLF;  '.CRLF;
 $sourceGenere.=' }else{'.CRLF;


 $sourceGenere.='  $consUrlRedir=\'\'.'.CRLF;

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
    }else{
     $sourceGenere.='                \'&amp;xsrch_'.$count.'=\'.rawurlencode($xsrch_'.$count.'). // '.$v1['nom_champ'].' '.CRLF;
     
    }    
    $count++;
   }
  }
 }
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='                \'&amp;xsrch_id=\'.rawurlencode($xsrch_id).'.CRLF;
 }
 $sourceGenere.='                \'\';'.CRLF;

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'tsupd')!==false || strpos($v1['nom_champ'],'tscrt')!==false || strpos($v1['nom_champ'],'cntupd')!==false ) ){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['param_name']) && isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){

     $sourceGenere.='  if(is_array($xsrch_'.$count.')){'.CRLF;
     $sourceGenere.='   foreach($xsrch_'.$count.' as $k1 => $v1){'.CRLF;
     $sourceGenere.='    $consUrlRedir.=\'&amp;xsrch_'.$count.'%5B%5D=\'.rawurlencode($v1);'.CRLF;
     $sourceGenere.='   }'.CRLF;
     $sourceGenere.='  }else{'.CRLF;
     $sourceGenere.='   $consUrlRedir.=\'&amp;xsrch_'.$count.'=\'.rawurlencode($xsrch_'.$count.'); // '.$v1['nom_champ'].CRLF;
     $sourceGenere.='  }'.CRLF;
     
    }
    $count++;
   }
  }
 }
 
 
 $sourceGenere.='  $ri=\' <span class="btn unset">&raquo;</span>\';'.CRLF;
 $sourceGenere.='  if($__start+$__nbMax<$__count){'.CRLF;
 $sourceGenere.='   $ri=\' <a href="\'.BNF.\'?__xpage=\'.($__xpage+1).$consUrlRedir.\'">&raquo;</a>\';'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  $le=\' <span class="btn unset">&laquo;</span>\';'.CRLF;
 $sourceGenere.='  if($__xpage>0){'.CRLF;
 $sourceGenere.='   $le=\' <a href="\'.BNF.\'?__xpage=\'.($__xpage-1).$consUrlRedir.\'">&laquo;</a>\';'.CRLF;
 $sourceGenere.='  }'.CRLF;

 $sourceGenere.='  $o1.=\'<div>\';'.CRLF;
 $sourceGenere.='  $o1.=\'<form method="post">\';'.CRLF;
 $sourceGenere.='//  $o1.=\'<button type="submit" name="action1">\'.txt0(\'action1\').\'</button>\';'.CRLF;
 $sourceGenere.='//  $o1.=\'<button type="submit" name="action2">\'.txt0(\'action2\').\'</button>\';'.CRLF;
 $sourceGenere.='  $o1.=\'<a href="'.substr(strtolower($GLOBALS['funcname']),4).'_action1.php?a=c">\'.txt1(\'add_a_new_record\').\'</a>\'.CRLF; // todo adjust '.CRLF;
 $sourceGenere.='  $o1.=\'&nbsp;\'.$le.\'\'.CRLF;  '.CRLF;
 $sourceGenere.='  $o1.=\'&nbsp;\'.$ri.\'\'.CRLF;  '.CRLF;

 $sourceGenere.='  $o1.=\'</form>\';'.CRLF;
 $sourceGenere.='  $o1.=\'</div>\';'.CRLF.CRLF;
 $sourceGenere.='$css=\'<style type="text/css">'.CRLF;
 $sourceGenere.='@media screen and (max-width: 890px){/* todo adjust size */'.CRLF;
 $sourceGenere.='  table.tableResult1 {'.CRLF;
 $sourceGenere.='    border: 0;'.CRLF;
 $sourceGenere.='    width:100%;'.CRLF;
 $sourceGenere.='    max-width:540px;'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  table.tableResult1 thead {'.CRLF;
 $sourceGenere.='    border: none;'.CRLF;
 $sourceGenere.='    clip: rect(0 0 0 0);'.CRLF;
 $sourceGenere.='    height: 1px;'.CRLF;
 $sourceGenere.='    margin: -1px;'.CRLF;
 $sourceGenere.='    overflow: hidden;'.CRLF;
 $sourceGenere.='    padding: 0;'.CRLF;
 $sourceGenere.='    position: absolute;'.CRLF;
 $sourceGenere.='    width: 1px;'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  table.tableResult1 tr {'.CRLF;
 $sourceGenere.='    border-bottom: 3px solid #eee;'.CRLF;
 $sourceGenere.='    display: block;'.CRLF;
 $sourceGenere.='    margin-bottom: 2.001em;'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  table.tableResult1 td {'.CRLF;
 $sourceGenere.='    border-bottom: 1px solid #eee;'.CRLF;
 $sourceGenere.='    display: block;'.CRLF;
 $sourceGenere.='    text-align: right!important;'.CRLF;
 $sourceGenere.='    min-height:30px;'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  table.tableResult1 td:before {'.CRLF;
 $sourceGenere.='    content: attr(data-label);'.CRLF;
 $sourceGenere.='    float: left!important;'.CRLF;
 $sourceGenere.='    font-weight:bold;'.CRLF;
 $sourceGenere.='    margin-right:5px;'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  table.tableResult1 td:last-child{border-bottom: 0;}'.CRLF;
 $sourceGenere.='  table.tableResult1 td.actionColumn div{display:contents;}'.CRLF;
 $sourceGenere.='  table.tableResult1 td.actionColumn{height:auto;}'.CRLF;
 $sourceGenere.='  .tableResult1 td {height:auto;word-break: break-all;}'.CRLF;
 $sourceGenere.='  .tableResult1 td pre {word-break: break-all;white-space: pre-line;}'.CRLF;
 $sourceGenere.='}'.CRLF;
 $sourceGenere.='</style>\';'.CRLF;
 $sourceGenere.='  $o1.=$css;'.CRLF.CRLF;
 $sourceGenere.='  $lsttbl.=\'<thead><tr>\';'.CRLF;
 $sourceGenere.='  $lsttbl.=\'<th style="min-width:85px;">\'.txtsys1(\'column_action\').\'</th>\';'.CRLF;

 $count=0;
 if($GLOBALS['__autoincrement']!=''){
  $sourceGenere.='  $lsttbl.=\'<th style="min-width:85px;">\'.txt1(\''.$GLOBALS['__autoincrement'].'\').\'</th>\';'.CRLF;
 }
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['parentField'])){
     $sourceGenere.='  $lsttbl.=\'<th>\'.txt1(\''.$v1['parentField']['fld_parent_field_display_pglnks'].'\').\'</th>\'; // ======== parent field of '.$v1['nom_champ'].''.CRLF;
    }else if($v1['type_champ']=='date' || $v1['type_champ']=='datetime'){
     $sourceGenere.='  $lsttbl.=\'<th  style="min-width:95px;">\'.txt1(\''.$v1['nom_champ'].'\').\'</th>\';'.CRLF;
    }else{
     $sourceGenere.='  $lsttbl.=\'<th>\'.txt1(\''.$v1['nom_champ'].'\').\'</th>\';'.CRLF;
    }
   }
  }
 }


 $sourceGenere.='  $lsttbl.=\'</tr></thead><tbody>\';'.CRLF;
 $sourceGenere.='  while($mpsr6=mysqli_fetch_row($result6)){'.CRLF;
 $sourceGenere.='   '.CRLF;
 $sourceGenere.='   $lsttbl.=\'<tr>\';'.CRLF.CRLF;
 $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txtsys1(\'column_action\').\'">\';'.CRLF;
 $sourceGenere.='   $lsttbl.=\'<div>\';'.CRLF;
 $sourceGenere.='   $lsttbl.=\'<a href="'.substr(strtolower($GLOBALS['funcname']),4).'_action1.php?a=u&amp;id=\'.$mpsr6[0].\'" title="\'.txtsys1(\'edit_button\').\'">&#9998;</a>\';// ✎ // todo ajust'.CRLF;
 $sourceGenere.='   $lsttbl.=\'<a class="danger" href="'.substr(strtolower($GLOBALS['funcname']),4).'_action1.php?a=d&amp;id=\'.$mpsr6[0].\'" title="\'.txtsys1(\'delete_button\').\'">&#10008;</a>\';// ✘ // todo ajust'.CRLF;
 $sourceGenere.='   $lsttbl.=\'<a href="'.substr(strtolower($GLOBALS['funcname']),4).'_action1.php?a=du&amp;id=\'.$mpsr6[0].\'" title="\'.txtsys1(\'duplicate_button\').\'">&#128203;</a>\';// 📋 // todo ajust'.CRLF;
 
 $sourceGenere.='   $lsttbl.=\'</div>\';'.CRLF;
 $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;


 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){

    $sourceGenere.='    $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'">\'; // '.$v1['nom_champ'].''.CRLF;
    $sourceGenere.='    if($mpsr6['.$count.']==\'\'){'.CRLF;
    $sourceGenere.='     $lsttbl.=\'\'.enti1($mpsr6['.$count.']).\'\'; '.CRLF;
    $sourceGenere.='    }else{'.CRLF;
    $sourceGenere.='     $val=json_decode($mpsr6['.$count.'],true);'.CRLF;
    $sourceGenere.='     $lsttbl.=\'<div style="display:inline-block;width:35px;height:20px;border:1px #eee outset;background-color:#\'.$val[\'hexValue\'].\'"></div>\';'.CRLF;
    $sourceGenere.='     $lsttbl.=\'\'.enti1($val[\'hexValue\']).\'\';'.CRLF;
    $sourceGenere.='     if(isset($val[\'webName\']) && $val[\'webName\']!=\'\'){'.CRLF;
    $sourceGenere.='      $lsttbl.=\'<br />\'.enti1($val[\'webName\']).\'\';'.CRLF;
    $sourceGenere.='     }'.CRLF;
    $sourceGenere.='     if(isset($val[\'pantoneName\']) && $val[\'pantoneName\']!=\'\'){'.CRLF;
    $sourceGenere.='      $lsttbl.=\'<br /> pantone:\'.enti1($val[\'pantoneName\']).\'\';'.CRLF;
    $sourceGenere.='     }'.CRLF;
    $sourceGenere.='    }'.CRLF;
    $sourceGenere.='    $lsttbl.=\'</td>\';'.CRLF.CRLF;
    $count++;
   }else if(isset($v1['param_name'])){
    if(isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'">\';'.CRLF;
     $sourceGenere.='   require_once($GLOBALS[\'glob_dataPath1\'].\'/generated/_params/'.$v1['param_name'].'.php\');'.CRLF;
     $sourceGenere.='   $lsttbl.=displayParam1(\''.$v1['param_name'].'\',$mpsr6['.$count.'],array(\'set\'=>true)); // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
     $count++;
    }else{
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'" style="text-align:center;">\';'.CRLF;
     $sourceGenere.='   require_once($GLOBALS[\'glob_dataPath1\'].\'/generated/_params/'.$v1['param_name'].'.php\');'.CRLF;
     $sourceGenere.='   $lsttbl.=displayParam1(\''.$v1['param_name'].'\',$mpsr6['.$count.'],array(\'unsetPossible\'=>'.(isset($v1['unsetPossible']) && $v1['unsetPossible']==true?'true':'false').')); // '.$v1['nom_champ'].''.CRLF;    
     $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
     $count++;
    }
   }else{
    if(isset($v1['parentField'])){
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['parentField']['fld_parent_field_display_pglnks'].'\').\'">\'; // ====== parent field of '.$v1['nom_champ'].''.CRLF;    
     $sourceGenere.='   $lsttbl.=\'\'.enti1($mpsr6['.$v1['parentField']['numSqlField'].']).\'\'; // '.$v1['nom_champ'].' parent of $mpsr6['.$count.']'.CRLF;
     $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
    }else if($v1['type_champ']=='time' || $v1['type_champ']=='date' || $v1['type_champ']=='datetime'){
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'" style="text-align:center;">\';'.CRLF;    
     $sourceGenere.='   $lsttbl.=\'\'.enti1($mpsr6['.$count.']).\'\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
    }else if(true===$v1['isNumericField']){
     if($GLOBALS['__autoincrement']==$v1['nom_champ']){
      $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'" style="text-align:center;">\';'.CRLF;    
     }else{
      $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'" style="text-align:right;">\';'.CRLF;    
     }
     $sourceGenere.='   $lsttbl.=\'\'.enti1($mpsr6['.$count.']).\'\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
    }else if(strpos(strtolower($v1['type_champ']),'text')     !==false ){
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'"><pre>\';'.CRLF;    
     $sourceGenere.='   $lsttbl.=\'\'.enti1(mb_substr($mpsr6['.$count.'],0,100,\'UTF-8\')).\'\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='   $lsttbl.=\'</pre></td>\';'.CRLF.CRLF;
    }else{
     $sourceGenere.='   $lsttbl.=\'<td data-label="\'.txt1(\''.$v1['nom_champ'].'\').\'">\';'.CRLF;    
     $sourceGenere.='   $lsttbl.=\'\'.enti1($mpsr6['.$count.']).\'\'; // '.$v1['nom_champ'].''.CRLF;
     $sourceGenere.='   $lsttbl.=\'</td>\';'.CRLF.CRLF;
    }
    $count++;
   }
  }
 }


 $sourceGenere.='   $lsttbl.=\'</tr>\';'.CRLF;
 $sourceGenere.='   '.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  $o1.=\'<table class="tableResult1">\'.CRLF.$lsttbl.\'</tbody></table>\'.CRLF;'.CRLF;
 $sourceGenere.='   '.CRLF;
 $sourceGenere.='  $o1.=\' <div>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'   \'.$le.\' \'.$ri.\' page \'.($__xpage+1).\'/\'.ceil($__count/$__nbMax).\' (\'.$__count.\' \'.txt1(\'number_of_records\').\' )\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'   &nbsp;<a class="buttonAdd" href="'.substr(strtolower($GLOBALS['funcname']),4).'_action1.php?a=c">\'.txt1(\'add_a_new_record\').\'</a>\'.CRLF; // todo adjust '.CRLF;
 $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF;
 $sourceGenere.='   '.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' mysqli_free_result($result6);'.CRLF;
 $sourceGenere.='}else{'.CRLF;
 $sourceGenere.=' $o1.=debugSql1(array(\'sqler\' => mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']),\'reque\' => $req6)); '.CRLF;
 $sourceGenere.='}'.CRLF;
 $sourceGenere.='$o1.=htmlFoot0(array());'.CRLF;
 $sourceGenere.='dw1($o1);'.CRLF;
 $sourceGenere.='cleanSession1();'.CRLF;

}
//========================================================================================================================
//========================================================================================================================
if(isset($_GET['a']) && $_GET['a']=='action1'){
 getTableInfos($_GET);
 $sourceGenere.='<'.'?php'.CRLF;
 $sourceGenere.='define(\'BNF\',basename( __FILE__ ));'.CRLF;
 $sourceGenere.='require_once \'za_inc.php\';'.CRLF;
 $sourceGenere.='session_start();'.CRLF;
 $sourceGenere.='@include  $GLOBALS[\'glob_dataPath1\'].\'/generated/lang/\'.$GLOBALS[\'glob_lang\'].\'_\'.BNF;'.CRLF;
 $sourceGenere.='checkGroupPages();'.CRLF;
 $sourceGenere.='require_once $GLOBALS[\'glob_incPath1\'].\'/_inc_'.substr(strtolower($GLOBALS['funcname']),4).'1.php\'; // todo check this'.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(isset($v1['parentField']) && sizeof($v1['parentField'])>0 ){
   $sourceGenere.='require_once $GLOBALS[\'glob_incPath1\'].\'/_inc_'.substr($v1['parentField']['fld_name_tables'],8).'1.php\'; // todo check this'.CRLF;
  }
 } 
 $sourceGenere.=''.CRLF;
 $sourceGenere.='openDb2();'.CRLF;
 $sourceGenere.='//========================================================================================================================'.CRLF;
 $sourceGenere.='function btl1(){'.CRLF;
 $sourceGenere.=' return \'&nbsp;<a href="'.substr(strtolower($GLOBALS['funcname']),4).'1.php" class="">\'.txtsys1(\'back_to_the_list\').\'</a>\'; // todo check'.CRLF;
 $sourceGenere.='}'.CRLF;

 $sourceGenere.='//========================================================================================================================'.CRLF;
 $sourceGenere.='function test_input_'.strtolower($GLOBALS['funcname']).'KO1(){'.CRLF;
 $sourceGenere.=' $err=0;'.CRLF;
 $GLOBALS['__hasCntUpdate']=false;
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if((strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if(strpos($v1['nom_champ'],'fld_cntupd_')!==false){
    $GLOBALS['__hasCntUpdate']=true;
   }
  }else{
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    $dontDoIt=false;
    if(isset($v1['param_name'])){
     $dontDoIt=true;
     $sourceGenere.=' // todo check if this condition is valid'.CRLF;
     $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'){'.CRLF;
     $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\''.$v1['nom_champ'].' must not be empty\');'.CRLF;
     $sourceGenere.='  $err=1;'.CRLF;
     $sourceGenere.=' }'.CRLF;
    }
    if(false===$dontDoIt){
     if(isset($v1['parentField'])){
      if($v1['null_possible']=='NO'){
       $sourceGenere.=' if($err==0&&!is_numeric($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])){'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\''.$v1['nom_champ'].' must be given\'); // dependant field'.CRLF;
       $sourceGenere.='  $err=1;'.CRLF;
       $sourceGenere.=' }'.CRLF;
       
       $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==0){'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\''.$v1['nom_champ'].' must be given\'); // dependant field'.CRLF;
       $sourceGenere.='  $err=1;'.CRLF;
       $sourceGenere.=' }'.CRLF;
       if($v1['parentField']['fld_link_mandatory_pglnks']==0){
        $sourceGenere.=' // todo warning : null possible = NO and not mandatory '.CRLF;       
        $_SESSION[PGMK][NAV][BNF]['warningmessage'][]=txtsys1('warning').' '. __LINE__ .' : Danger field "'.$v1['nom_champ'].'" null possible = NO and not mandatory ';
       }
      }else{
       if($v1['parentField']['fld_link_mandatory_pglnks']==1){
        $sourceGenere.=' // todo warning : field mandatory but null possible = YES'.CRLF;       
        $_SESSION[PGMK][NAV][BNF]['warningmessage'][]=txtsys1('warning').' '. __LINE__ .' : Danger field "'.$v1['nom_champ'].'" field mandatory but null possible = YES ';
       }       
      }
     }else if($v1['type_champ']=='date' || $v1['type_champ']=='time' || $v1['type_champ']=='datetime' ){
      if($v1['null_possible']!='YES'){
       $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'){'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\''.$v1['nom_champ'].' must not be empty\');'.CRLF;
       $sourceGenere.='  $err=1;'.CRLF;
       $sourceGenere.=' }'.CRLF;
      }
      
     }else if(true===$v1['isNumericField']){
      if($v1['null_possible']=='YES'){
       $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']!=\'\'&&!is_numeric($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])){'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\''.$v1['nom_champ'].' must be numerical\');'.CRLF;
       $sourceGenere.='  $err=1;'.CRLF;
       $sourceGenere.=' }'.CRLF;
      }else{
       $sourceGenere.=' if($err==0&&!is_numeric($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])){'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\''.$v1['nom_champ'].' must be numerical\');'.CRLF;
       $sourceGenere.='  $err=1;'.CRLF;
       $sourceGenere.=' }'.CRLF;
      }
     }else{
      if($v1['null_possible']!='YES'){
       $sourceGenere.=' if($err==0&&$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'){'.CRLF;
       $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txt1(\''.$v1['nom_champ'].' must not be empty\');'.CRLF;
       $sourceGenere.='  $err=1;'.CRLF;
       $sourceGenere.=' }'.CRLF;
      }
     }
    }
   }
  }
 }
 $sourceGenere.=' return($err);'.CRLF;
 $sourceGenere.='}'.CRLF;

 $sourceGenere.='if(isset($_POST)&&sizeof($_POST)>=1){ // post action'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= POST ACTIONS  ====================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.='// echo __LINE__ . \'$_POST=<pre>\' . var_export($_POST,true) . \'</pre>\'; exit();'.CRLF;
 
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){

     $sourceGenere.=' if(isset($_POST[\''.$v1['nom_champ'].'\']) ){'.CRLF;
     $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']= implode(\',\',$_POST[\''.$v1['nom_champ'].'\']);'.CRLF;
     $sourceGenere.=' }else{'.CRLF;
     $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']=\'\';'.CRLF;
     $sourceGenere.=' }'.CRLF;
    }else{     
     if($v1['null_possible']=='YES'){
      $sourceGenere.=' $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=isset($_POST[\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'?$_POST[\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).': \'\'; // null possible'.CRLF;
     }else{
      if(true===$v1['isNumericField']){
       $sourceGenere.=' $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=isset($_POST[\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'?$_POST[\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).': 0;'.CRLF;
      }else{
       $sourceGenere.=' $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=isset($_POST[\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'?$_POST[\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).': \'\';'.CRLF;
      }
     }    
    }
   }
  }
 }

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){
    if($v1['null_possible']=='YES'){
     $sourceGenere.=' if($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'){$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']=NULL;} // '.$v1['nom_champ'].' can be NULL'.CRLF.CRLF;
    }
   }else if($v1['type_champ']=='date' || $v1['type_champ']=='time' || $v1['type_champ']=='datetime' ){
    if($v1['null_possible']=='YES'){
     $sourceGenere.=' if($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\' || $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'NULL\' ){$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']=NULL;} // '.$v1['nom_champ'].' can be NULL'.CRLF.CRLF;
    }
   }else if(isset($v1['parentField'])){
    $sourceGenere.=CRLF;
    $sourceGenere.=' // dependant field '.CRLF;
    $sourceGenere.=' if(!(isset($_POST[\'a\'])&&($_POST[\'a\']==\'cd\'||$_POST[\'a\']==\'cd\'))){ // NOT confirm delete'.CRLF;
    $sourceGenere.='  $_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\'] =isset($_POST[\'choose__'.$v1['nom_champ'].'\'] )?$_POST[\'choose__'.$v1['nom_champ'].'\']  :\'\';'.CRLF;
    $sourceGenere.='  if($_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\']==txtsys1(\'text_for_the_select_button\')){'.CRLF;
    $sourceGenere.='   $_SESSION[PGMK][\'choose\'][\'urlBack\']=$_SERVER[\'HTTP_ORIGIN\'].$_SERVER[\'REQUEST_URI\'];'.CRLF;
    $sourceGenere.='   header(\'Location: '.substr($v1['parentField']['fld_name_tables'],8).'_choose1.php\'); // todo check '.CRLF;
    $sourceGenere.='   exit();'.CRLF;
    $sourceGenere.='  }'.CRLF;
    $sourceGenere.=' }'.CRLF;
    $sourceGenere.=CRLF;
   }
  }
 }
 
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= POST UPDATE ======================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' if(isset($_POST[\'a\'])&&$_POST[\'a\']==\'u\'){ // update action'.CRLF;
 $sourceGenere.='  if(test_input_'.strtolower($GLOBALS['funcname']).'KO1()){'.CRLF;
 $sourceGenere.='   if(isset($_POST[\'id1\'])&&is_numeric($_POST[\'id1\'])){'.CRLF;
 $sourceGenere.='    header(\'Location: \'.BNF.\'?a=u&t=u&id=\'.$_POST[\'id1\']);'.CRLF;
 $sourceGenere.='    exit();'.CRLF;
 $sourceGenere.='   }else{'.CRLF;
 $sourceGenere.='    $_SESSION[PGMK][NAV][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : POST id1 = \' . $_POST[\'id1\'];'.CRLF;
 $sourceGenere.='    header(\'Location: index.php\');'.CRLF;
 $sourceGenere.='    exit();'.CRLF;
 $sourceGenere.='   }'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  $req6="UPDATE `".$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\']."`.`'.$_GET['table'].'` SET'.CRLF;
 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){

    if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){
     if($count==0){
      $sourceGenere.='      ';
     }else{
      $sourceGenere.='    , ';
     }
//     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $v1['null_possible'] , true ) . '</pre>' ; exit(0);
     if($v1['null_possible']=='YES'){
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".(is_null($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])?\'NULL\':"\'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])."\'")."'.CRLF;
     }else{
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
     }
    }else if( 'date'===$v1['type_champ'] || 'time'===$v1['type_champ'] || 'datetime'===$v1['type_champ'] ){
     if($count==0){
      $sourceGenere.='      ';
     }else{
      $sourceGenere.='    , ';
     }
     if($v1['null_possible']!='YES'){
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
     }else{
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".(is_null($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])?\'NULL\':"\'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])."\'")."'.CRLF;
     }
    }else if(true===$v1['isNumericField']){
     if($count==0){
      $sourceGenere.='      ';
     }else{
      $sourceGenere.='    , ';
     }
     if($v1['null_possible']=='YES'){      
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ".($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'?\'NULL\':addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']))."'.CRLF;      
     }else{
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'            ."'.CRLF;
     }
     $count++;
    }else{
     if($count==0){
      $sourceGenere.='      ';
     }else{
      $sourceGenere.='    , ';
     }
     if($v1['null_possible']=='YES'){
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ".($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'?\'NULL\':"\'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']) ."\'")."'.CRLF;
     }else{
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
     }
     $count++;
    }
   }
  }else{
   if(strpos($v1['nom_champ'],'fld_tsupd_')!==false ){
    if($count==0){
     $sourceGenere.='      ';
    }else{
     $sourceGenere.='    , ';
    }
    
    $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes($GLOBALS[\'glob_setdate\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'                      ."\''.CRLF;
   }else if(strpos($v1['nom_champ'],'fld_cntupd_')!==false ){
    if($count==0){
     $sourceGenere.='      ';
    }else{
     $sourceGenere.='    , ';
    }
    $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  " . ((int)$_POST[\''.$v1['nom_champ'].'\']+1)'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'                    ."'.CRLF;
   }
  }
 }
 $sourceGenere.='  ";'.CRLF;
 $sourceGenere.='  $req6.="'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.='   WHERE `'.$GLOBALS['__autoincrement'].'`=".$_POST[\'id1\']."'.CRLF;
  if($GLOBALS['__fld_cntupd']!=''){
   $sourceGenere.='     AND `'.$GLOBALS['__fld_cntupd'].'` = ".$_POST[\''.$GLOBALS['__fld_cntupd'].'\']."'.CRLF;
  }
  $sourceGenere.='  ";'.CRLF;
 }else{
  $sourceGenere.='   WHERE todo = todo '.CRLF;
  $sourceGenere.='  "; // todo here check the conditions !!! DANGER !!!'.CRLF;
  $sourceGenere.='  ";'.CRLF;
 }

 $sourceGenere.='  $res6=@mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
 $sourceGenere.='  if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=0){'.CRLF;
 $sourceGenere.='   switch(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])){'.CRLF;
 $sourceGenere.='    case 1062 :'.CRLF;
 $sourceGenere.='     $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'this_record_already_exist\');'.CRLF;
 $sourceGenere.='     break;'.CRLF;
 $sourceGenere.='    default   :'.CRLF;
 $sourceGenere.='     $xtxterr=txtsys1(\'error\').\' \' . __LINE__ . \'mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
 $sourceGenere.='     $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;
 $sourceGenere.='     txtlog1($xtxterr , BNF , __LINE__ , 2 );'.CRLF;
 $sourceGenere.='    break;'.CRLF;
 $sourceGenere.='   }'.CRLF;
 $sourceGenere.='   header(\'Location: \'.BNF.\'?a=u&id=\'.$_POST[\'id1\']); exit();'.CRLF;
 $sourceGenere.='  }else{'.CRLF;
 if($GLOBALS['__hasCntUpdate']){
  $sourceGenere.='   if(mysqli_affected_rows($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=1){'.CRLF;
  $sourceGenere.='    $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'this_record_has_not_been_updated_because_of_an_other_user\');'.CRLF;
  $sourceGenere.='    $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'please_retry\');'.CRLF;
  $count=0;
  foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
   if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
    if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
     $sourceGenere.='    unset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']);'.CRLF;
    }
   }
  }
  $sourceGenere.='    header(\'Location: \'.BNF.\'?a=u&id=\'.$_POST[\'id1\']); exit();'.CRLF;
  $sourceGenere.='   }'.CRLF;
 }
 $sourceGenere.='   '.CRLF;
 $sourceGenere.='   sqllog1( $req6 , BNF , __LINE__ );'.CRLF;
 $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'message\'][]=txtsys1(\'the_modification_has_been_recorded_at\') . \' \' . substr($GLOBALS[\'glob_setdate\'],11);'.CRLF;
 $sourceGenere.='   header(\'Location: \'.BNF.\'?a=u&t=u&id=\'.$_POST[\'id1\']);'.CRLF;
 $sourceGenere.='   exit();'.CRLF;
 $sourceGenere.='  }'.CRLF;

 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= POST CONFIRM DELETE ==============================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' }else if(isset($_POST[\'a\'])&&$_POST[\'a\']==\'cd\'){'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){
  $sourceGenere.=' '.CRLF;
  $sourceGenere.='  require_once $GLOBALS[\'glob_dataPath1\'].\'/generated/__tableDependencies1.php\';'.CRLF;
  $sourceGenere.='  $retDependantTables=dependentValuesExist1('.$_GET['idBase'].',\''.$_GET['table'].'\',\''.$GLOBALS['__autoincrement'].'\',$_POST[\'id1\'] );'.CRLF;
  $sourceGenere.='  if(true === $retDependantTables[\'valuesExist\']){'.CRLF;
  $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\') . \' \' . __LINE__ . \' \' . txtsys1(\'you_cannot_delete_because_some_values_are_still_present_in_dependant_table\') . \' \' . var_export( $retDependantTables[\'tables\'] , true ) . \' \';'.CRLF;
  $sourceGenere.='   header(\'Location: \'.BNF.\'?a=d&id=\'.$_POST[\'id1\']);   '.CRLF;
  $sourceGenere.='  }'.CRLF;
  $sourceGenere.=''.CRLF;

  $sourceGenere.='//  echo __FILE__ . \' \' . __LINE__ . \' __LINE__ = <pre>\' . var_export( $_POST , true ) . \'</pre>\' ; exit(0);'.CRLF;
  $sourceGenere.='  $req6="DELETE FROM `".$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\']."`.`'.$_GET['table'].'` WHERE `'.$GLOBALS['__autoincrement'].'`=".$_POST[\'id1\']." " ;'.CRLF;
  $sourceGenere.='  $res6=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
  $sourceGenere.='  if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=0){'.CRLF;
  $sourceGenere.='   $xtxterr=txtsys1(\'error\').\' \' . __LINE__ . \'mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\'][0][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
  $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;
  $sourceGenere.='   txtlog1($xtxterr , BNF , __LINE__ , 2 );'.CRLF;
  $sourceGenere.='   header(\'Location: \'.BNF.\'?a=d&id=\'.$_POST[\'id1\']);'.CRLF;
  $sourceGenere.='   exit();'.CRLF;
  $sourceGenere.='  }else{'.CRLF;
  $sourceGenere.='   sqllog1( $req6 , BNF , __LINE__ );'.CRLF;
  $sourceGenere.='   unset($_SESSION[PGMK][NAV][BNF]);'.CRLF;
  $sourceGenere.='   header(\'Location: '.substr(strtolower($GLOBALS['funcname']),4).'1.php\'); // todo check this'.CRLF;
  $sourceGenere.='   exit();'.CRLF;
  $sourceGenere.='  }'.CRLF;
 }else{
  $sourceGenere.='  // todo no auto increment, check this'.CRLF;
  $sourceGenere.='  echo __FILE__ . \' \' . __LINE__ . \' __LINE__ = <pre>\' . var_export( $_POST , true ) . \'</pre>\' ; exit(0);'.CRLF;
  $sourceGenere.='  $req6="DELETE FROM `".$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\']."`.`'.$_GET['table'].'` WHERE `zzzzzzzzzzzzzz`=".$_POST[\'id1\']." " ;'.CRLF;
  $sourceGenere.='  $res6=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
  $sourceGenere.='  if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=0){'.CRLF;
  $sourceGenere.='   $xtxterr=txtsys1(\'error\').\' \' . __LINE__ . \'mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\'][0][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
  $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;
  $sourceGenere.='   txtlog1($xtxterr , BNF , __LINE__ , 2 );'.CRLF;
  $sourceGenere.='   header(\'Location: \'.BNF.\'?a=d&id=\'.$_POST[\'id1\']);'.CRLF;
  $sourceGenere.='   exit();'.CRLF;
  $sourceGenere.='  }else{'.CRLF;
  $sourceGenere.='   sqllog1( $req6 , BNF , __LINE__ );'.CRLF;
  $sourceGenere.='   unset($_SESSION[PGMK][NAV][BNF]);'.CRLF;
  $sourceGenere.='   header(\'Location: '.substr(strtolower($GLOBALS['funcname']),4).'1.php\'); // todo check this'.CRLF;
  $sourceGenere.='   exit();'.CRLF;
  $sourceGenere.='  }'.CRLF;
 }
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= POST CREATE ACTION ================================================================'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' }else if(isset($_POST[\'a\'])&&$_POST[\'a\']==\'c\'){'.CRLF;
 $sourceGenere.='  if(test_input_'.strtolower($GLOBALS['funcname']).'KO1()){'.CRLF;
 $sourceGenere.='   header(\'Location: \'.BNF.\'?a=c\');'.CRLF;
 $sourceGenere.='   exit();'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.='  $req6="'.CRLF;
 $sourceGenere.='   INSERT INTO `".$GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'dbname\']."`.`'.$_GET['table'].'` SET'.CRLF;

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
   
    if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){
     if($count==0){
      $sourceGenere.='     ';
     }else{
      $sourceGenere.='    ,';
     }
     if($v1['null_possible']=='YES'){
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".(is_null($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])?\'NULL\':"\'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])."\'")."'.CRLF;
     }else{
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
     }
   
    }else if( 'date'===$v1['type_champ'] || 'time'===$v1['type_champ']  || 'datetime'===$v1['type_champ'] ){
     if($count==0){
      $sourceGenere.='     ';
     }else{
      $sourceGenere.='    ,';
     }
     if($v1['null_possible']!='YES'){
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
     }else{
      $sourceGenere.='`'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".(is_null($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])?\'NULL\':"\'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])."\'")."'.CRLF;
     }
    }else if(true===$v1['isNumericField']){
     if(0===$count){
      $sourceGenere.='     ';
     }else{
      $sourceGenere.='    ,';
     }
     if($v1['null_possible']=='YES'){      
      $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ".($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'?\'NULL\':addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']))."'.CRLF;      
     }else{
      $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=  ".$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'            ."'.CRLF;
     }
     $count++;
    }else{
     if(0===$count){
      $sourceGenere.='     ';
     }else{
      $sourceGenere.='    ,';
     }
     if($v1['null_possible']=='YES'){      
      $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= ".($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']==\'\'?\'NULL\':"\'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']) ."\'")."'.CRLF;      
     }else{
      $sourceGenere.=' `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'."\''.CRLF;
     }
     $count++;
    }
   }
  }else{
   if(strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false ){
    $sourceGenere.='    , `'.$v1['nom_champ'].'`'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'= \'".addslashes($GLOBALS[\'glob_setdate\'])'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'                     ."\''.CRLF;
   }
  }
 }
 $sourceGenere.='  " ;'.CRLF;
 $sourceGenere.='//  echo __FILE__ . \' \' . __LINE__ . \' $req6 =\' . $req6 . \'\' ; exit();'.CRLF;
 $sourceGenere.='  $res6=@mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],$req6);'.CRLF;
 $sourceGenere.='  if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=0){'.CRLF;
 $sourceGenere.='   switch(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])){'.CRLF;
 $sourceGenere.='    case 1062 :'.CRLF;
 $sourceGenere.='     $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'this_record_already_exist\');'.CRLF;
 $sourceGenere.='    break;'.CRLF;
 $sourceGenere.='    default;'.CRLF;
 $sourceGenere.='    $xtxterr=txtsys1(\'error\').\' \' . __LINE__ . \'mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
 $sourceGenere.='    $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;
 $sourceGenere.='    txtlog1($xtxterr , BNF , __LINE__ , 2 );'.CRLF;
 $sourceGenere.='    break;'.CRLF;
 $sourceGenere.='   }'.CRLF;
 $sourceGenere.='   header(\'Location: \'.BNF.\'?a=c\');'.CRLF;
 $sourceGenere.='   exit();'.CRLF;
 $sourceGenere.='  }else{'.CRLF;
 $sourceGenere.='   sqllog1( $req6 , BNF , __LINE__ );'.CRLF;
 $sourceGenere.='   $resIns=mysqli_query($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'],\'SELECT LAST_INSERT_ID()\');'.CRLF;
 $sourceGenere.='   if(mysqli_errno($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\'])!=0){'.CRLF;
 $sourceGenere.='    $xtxterr=txtsys1(\'error\').\' \' . __LINE__ . \'mysqli_error=\'. mysqli_error($GLOBALS[\'glob_db\']['.$_GET['idBase'].'][\'link\']) . \'req=\' . $req6 . txtsys1(\'please_retry\') ;'.CRLF;
 $sourceGenere.='    $_SESSION[PGMK][NAV][BNF][\'errormessage\'][]=$xtxterr;'.CRLF;
 $sourceGenere.='    txtlog1($xtxterr , BNF , __LINE__ , 2 );'.CRLF;
 $sourceGenere.='    header(\'Location: \'.BNF.\'?a=c\');'.CRLF;
 $sourceGenere.='    exit();'.CRLF;
 $sourceGenere.='   }else{'.CRLF;
 $sourceGenere.='    $NewCode=mysqli_fetch_row($resIns);'.CRLF;
 $sourceGenere.='    $NewCode=$NewCode[0];'.CRLF;
 $sourceGenere.='    mysqli_free_result($resIns);'.CRLF;
 $sourceGenere.='    SetSessionMessageAndLog1( txt1(\'the new value has been inserted\') . \' (\'.$NewCode.\').\' , BNF , __LINE__ , 3);'.CRLF;
 $sourceGenere.='    header(\'Location: \'.BNF.\'?a=u&t=n&id=\'.$NewCode);'.CRLF;
 $sourceGenere.='    exit();'.CRLF;
 $sourceGenere.='   }'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' '.CRLF;

 $sourceGenere.='}else{ // get action'.CRLF;
 $sourceGenere.=''.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= GET ACTION ========================================================================'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 
 
 $sourceGenere.=' if(isset($_GET[\'a\'])&&$_GET[\'a\']==\'du\'){ // duplicate action'.CRLF;
 $sourceGenere.='  $xxxFldValues=array();'.CRLF;
 $sourceGenere.='  $name2=get'.$GLOBALS['funcname'].'1($_GET[\'id\']);'.CRLF;
 if(isset($GLOBALS['__showDeleteFieldName']) && $GLOBALS['__showDeleteFieldName']!=''){
  $sourceGenere.='  if($name2[\''.$GLOBALS['__showDeleteFieldName'].'\']==\'\'){'.CRLF;
 }else{
  $sourceGenere.='  if($name2[\'todo\']==\'\'){'.CRLF;   
 }
 $sourceGenere.='   $_SESSION[PGMK][NAV][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_cannot_duplicate_this_value\');'.CRLF;
 $sourceGenere.='   header(\'Location: '.substr(strtolower($GLOBALS['funcname']),4).'1.php\'); // todo check'.CRLF;
 $sourceGenere.='   exit();'.CRLF;
 $sourceGenere.='  }else{'.CRLF;
 $sourceGenere.='   // todo set fields for duplicate'.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=$name2[\''.$v1['nom_champ'].'\'];'.CRLF;
   }
  }
 }
 $sourceGenere.='   header(\'Location: \'.BNF.\'?a=c\' );'.CRLF;
 $sourceGenere.='   exit();'.CRLF;
 $sourceGenere.='  }'.CRLF;
 $sourceGenere.=' }'.CRLF;
 $sourceGenere.=' '.CRLF;
 
 
 $sourceGenere.=' $o1=htmlHead1(array());'.CRLF;
 $sourceGenere.=' $js1=array();'.CRLF;
 $sourceGenere.='// echo __LINE__ . \'$_SESSION[PGMK]=<pre>\' . var_export( $_SESSION[PGMK] , true ) . \'</pre>\'; exit();'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= GET DELETE ========================================================================'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' if(isset($_GET[\'a\'])&&$_GET[\'a\']==\'d\'){ // delete action'.CRLF;
 $sourceGenere.='  $id=(isset($_GET[\'id\'])&&is_numeric($_GET[\'id\']))?$_GET[\'id\']:0;'.CRLF;
 $sourceGenere.='  if($id==0){'.CRLF;
 $sourceGenere.='   header(\'Location: '.substr(strtolower($GLOBALS['funcname']),4).'1.php\'); // todo check'.CRLF;
 $sourceGenere.='   exit();'.CRLF;
 $sourceGenere.='  }else{'.CRLF;
 $sourceGenere.='   $xvalueName=get'.$GLOBALS['funcname'].'1($_GET[\'id\']); // todo check this function name'.CRLF;
 $sourceGenere.='   echo __FILE__ . \' \' . __LINE__ . \' TODO at LINE = <pre>\' . var_export( __LINE__ , true ) . \'</pre>\' ; exit(0); '.CRLF;
 if(isset($GLOBALS['__showDeleteFieldName']) && $GLOBALS['__showDeleteFieldName']!=''){
  $sourceGenere.='   if($xvalueName[\''.$GLOBALS['__showDeleteFieldName'].'\']==\'\'){'.CRLF;   
 }else{
  $sourceGenere.='   if($xvalueName[\'todo\']==\'\'){'.CRLF; 
 }
 $sourceGenere.='    $_SESSION[PGMK][NAV][\'errormessage\'][]=txtsys1(\'error\').\' \'. __LINE__ .\' : \' . txtsys1(\'you_cannot_delete_this_value\');'.CRLF;
 $sourceGenere.='    header(\'Location: '.substr(strtolower($GLOBALS['funcname']),4).'1.php\'); // todo check'.CRLF;
 $sourceGenere.='    exit();'.CRLF;
 $sourceGenere.='   }else{'.CRLF;
 $sourceGenere.='    if($xvalueName[\'todo\']!=$_SESSION[PGMK][\'login\']){ // if the current record you want to update is not yours'.CRLF;
 $sourceGenere.='     header(\'Location: '.substr(strtolower($GLOBALS['funcname']),4).'1.php\'); // todo check'.CRLF;
 $sourceGenere.='     exit();'.CRLF;
 $sourceGenere.='    }else{'.CRLF;
 if($GLOBALS['__autoincrement'] != ''){ 
  $sourceGenere.='      require_once $GLOBALS[\'glob_dataPath1\'].\'/generated/__tableDependencies1.php\';'.CRLF;
  $sourceGenere.='      $retDependantTables=dependentValuesExist1('.$_GET['idBase'].',\''.$_GET['table'].'\',\''.$GLOBALS['__autoincrement'].'\',$_GET[\'id\'] );'.CRLF;
  $sourceGenere.='      if(isset($retDependantTables[\'valuesExist\']) && $retDependantTables[\'valuesExist\']==true){'.CRLF;
  $sourceGenere.='       $o1.=displaySessionMessage1(BNF);'.CRLF;
  $sourceGenere.='       $o1.=\' <div>\'.CRLF;'.CRLF;
  $sourceGenere.='       $o1.=\' \'.txtsys1(\'dependent_values_exist\').\'\'.CRLF;'.CRLF;
  $sourceGenere.='       $o1.=\' <ul>\'.CRLF;'.CRLF;
  $sourceGenere.='       foreach( $retDependantTables[\'tables\'] as $k1 => $v1){'.CRLF;
  $sourceGenere.='        $o1.=\'  <li>\'.$v1.\'</li>\'.CRLF;'.CRLF;
  $sourceGenere.='       }'.CRLF;
  $sourceGenere.='       $o1.=\' </ul>\'.CRLF;'.CRLF;
  $sourceGenere.='       $o1.=\' </div>\'.CRLF;'.CRLF;
  $sourceGenere.='       $o1.=btl1();'.CRLF;
 }else{
  $sourceGenere.='     '.CRLF;
  $sourceGenere.='      if(true){ // todo check table dependancies if necessary'.CRLF;
  $sourceGenere.='       $o1.=displaySessionMessage1(BNF);'.CRLF;
  $sourceGenere.='       $o1.=\' <div>\'.CRLF;'.CRLF;
  $sourceGenere.='       $o1.=\' \'.txtsys1(\'dependent_values_exist\').\'\'.CRLF;'.CRLF;
  $sourceGenere.='       $o1.=\' </div>\'.CRLF;'.CRLF;
  $sourceGenere.='       $o1.=btl1();'.CRLF;
 }
 $sourceGenere.='      }else{'.CRLF;
 $sourceGenere.='       $o1.=displaySessionMessage1(BNF);'.CRLF;
 $sourceGenere.='       $o1.=\' <form method="post" class="formDelete">\'.CRLF;'.CRLF;
 $sourceGenere.='       $o1.=\'   \'.txtsys1(\'please_confirm_deletion_of\').\' : \'.CRLF;'.CRLF;
 if(isset($GLOBALS['__showDeleteFieldName']) && $GLOBALS['__showDeleteFieldName']!=''){
  $sourceGenere.='       $o1.=\'   <br /><br /><b>\'.enti1($xvalueName[\''.$GLOBALS['__showDeleteFieldName'].'\']).\'</b><br /><br />\'.CRLF;'.CRLF;
 }else{
  $sourceGenere.='       $o1.=\'   <br /><br /><b>\'.enti1($xvalueName[\'todo\']).\'</b><br /><br />\'.CRLF;'.CRLF;
 }
 $sourceGenere.='       $o1.=\'   <input type="hidden" value="\'.$_GET[\'id\'].\'" name="id1" id="id1" />\'.CRLF;'.CRLF;
 $sourceGenere.='       $o1.=\'   <input type="hidden" value="cd" name="a" id="a" />\'."\r\n";'.CRLF;
 $sourceGenere.='       $o1.=\'   <button type="submit" class="danger">\'.txtsys1(\'i_confirm_the_deletion_button\').\'</button>\'.CRLF;'.CRLF;
 $sourceGenere.='       $o1.=btl1();'.CRLF;
 $sourceGenere.='       $o1.=\' </form>\'."\r\n";'.CRLF;
 $sourceGenere.='      }'.CRLF; 
 $sourceGenere.='     }'.CRLF; 
 $sourceGenere.='    }'.CRLF;
 $sourceGenere.='   }'.CRLF;
 $sourceGenere.='  }'.CRLF;

 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= GET UPDATE ========================================================================'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' '.CRLF;
 $sourceGenere.=' }else if(isset($_GET[\'a\'])&&$_GET[\'a\']==\'u\'){ // update action'.CRLF;
 $sourceGenere.='  $xxxFldValues=array();'.CRLF;
 $sourceGenere.='  $js1=array();'.CRLF;
 $sourceGenere.='  $o1.=\'<h4>\'.txt1(\'update a record\').\' (\'.$_GET[\'id\'].\')\'.btl1().\'</h4>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=displaySessionMessage1(BNF);'.CRLF;
 $sourceGenere.='  $name2=get'.$GLOBALS['funcname'].'1($_GET[\'id\']); // todo check this function name'.CRLF;

 $count=0;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    $sourceGenere.='  $xxxFldValues[\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'=isset( $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).'? $_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).': $name2[\''.$v1['nom_champ'].'\']'.str_repeat( ' ' , $GLOBALS['__longueurMax']-strlen($v1['nom_champ'])).';'.CRLF;
   }
  }
 }



 $sourceGenere.=''.CRLF.CRLF;
 $sourceGenere.='  $o1.=\'<form method="post" >\'.CRLF;'.CRLF;
 $sourceGenere.=''.CRLF;
 $sourceGenere.='  $o1.=\' <input type="hidden" value="u" name="a" id="a" />\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\' <input type="hidden" value="\'.$_GET[\'id\'].\'" name="id1" id="id1" />\'.CRLF;'.CRLF;

 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){
    if(isset($v1['parentField'])){
     

     $sourceGenere.=CRLF;
     $sourceGenere.='  $xDisplayValueFetch = \'\' ;'.CRLF;
     $sourceGenere.='  if('.CRLF;
     $sourceGenere.='   isset($_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\'])&&'.CRLF;
     $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\']==txtsys1(\'text_for_the_select_button\')&&'.CRLF;
     $sourceGenere.='   isset($_SESSION[PGMK][\'choose\'][\'valueBack\'])&&'.CRLF;
     $sourceGenere.='   $_SESSION[PGMK][\'choose\'][\'valueBack\']!=0'.CRLF;
     $sourceGenere.='  ){'.CRLF;
     $sourceGenere.='   if($_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\']==txtsys1(\'text_for_the_select_button\')){'.CRLF;
     $sourceGenere.='    $xxxFldValues[\''.$v1['nom_champ'].'\']=$_SESSION[PGMK][\'choose\'][\'valueBack\'];'.CRLF;
     $sourceGenere.='   }'.CRLF;
     $sourceGenere.='   unset($_SESSION[PGMK][\'choose\']);'.CRLF;
     $sourceGenere.='  }'.CRLF;
     if($v1['null_possible']=='YES'){
      $sourceGenere.='  if($xxxFldValues[\''.$v1['nom_champ'].'\']!=\'\'){'.CRLF;
      $sourceGenere.='   $xGroupValues=get'.ucfirst(PGMK).'_'.substr($v1['parentField']['fld_name_tables'],8).'1($xxxFldValues[\''.$v1['nom_champ'].'\']);'.CRLF;
      $sourceGenere.='   $xDisplayValueFetch = \'\' . enti1( $xGroupValues[\''.$v1['parentField']['fld_parent_field_display_pglnks'].'\'] ) . \' (\' . $xGroupValues[\''.$v1['parentField']['fld_parent_field_pglnks'].'\'] . \')\' . \'\' ;'.CRLF;
      $sourceGenere.='  }else{'.CRLF;
      $sourceGenere.='   $xDisplayValueFetch = \'\';    '.CRLF;
      $sourceGenere.='  }'.CRLF;
     }else{
      $sourceGenere.='  $xGroupValues=get'.ucfirst(PGMK).'_'.substr($v1['parentField']['fld_name_tables'],8).'1( $xxxFldValues[\''.$v1['nom_champ'].'\']); // todo check this function'.CRLF;
      $sourceGenere.='  $xDisplayValueFetch = \'\' . enti1( $xGroupValues[\''.$v1['parentField']['fld_parent_field_display_pglnks'].'\'] ) . \' (\' . $xGroupValues[\''.$v1['parentField']['fld_parent_field_pglnks'].'\'] . \')\' . \'\' ; // todo choose among parent fields '.CRLF;
     }
     $sourceGenere.='   '.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="fdiv1">\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'   <div class="flab1"><div>\'.txt1(\'parent_'.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'   <div class="finp1"><div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'    <input type="hidden" value="\'.enti1($xxxFldValues[\''.$v1['nom_champ'].'\']).\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" />\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'     <span id="span__dep_'.$v1['nom_champ'].'">\'.$xDisplayValueFetch.\'</span>\';'.CRLF;
     $sourceGenere.='  $o1.=\'    <button type="submit" name="choose__'.$v1['nom_champ'].'" class="" value="\'. txtsys1(\'text_for_the_select_button\') . \'">\';'.CRLF;
     $sourceGenere.='  $o1.=\'\'   . txtsys1(\'text_for_the_select_button\') . \'\';'.CRLF;
     $sourceGenere.='  $o1.=     \'</button>\'."\r\n";'.CRLF;
     if($v1['parentField']['fld_link_mandatory_pglnks']=='0'){
      $sourceGenere.='  $o1.=\'    <button type="button" class="warning" onclick="razDependant1(\\\'span__dep_'.$v1['nom_champ'].'\\\',\\\''.$v1['nom_champ'].'\\\')">\';'.CRLF;
      $sourceGenere.='  $o1.=\'\'   . txtsys1(\'raz_button\') . \'\';'.CRLF;
      $sourceGenere.='  $o1.=     \'</button>\'."\r\n";'.CRLF;
     }
     
     $sourceGenere.='  $o1.=\'   </div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  </div>\'.CRLF;'.CRLF.CRLF;
     $count++;
    }else if(isset($v1['param_name'])){
     $sourceGenere.=''.CRLF;
     $sourceGenere.='  $o1.=\' <div class="fdiv1">\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="flab1"><div>\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;
     $sourceGenere.='  require_once($GLOBALS[\'glob_dataPath1\'].\'/generated/_params/'.$v1['param_name'].'.php\');'.CRLF;
     if(isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
      $sourceGenere.='  $retParam=displayParam2(\''.$v1['param_name'].'\',$xxxFldValues[\''.$v1['nom_champ'].'\'],\''.$v1['nom_champ'].'\',array(\'set\'=>true));'.CRLF;
     }else{
      $sourceGenere.='  $retParam=displayParam2(\''.$v1['param_name'].'\',$xxxFldValues[\''.$v1['nom_champ'].'\'],\''.$v1['nom_champ'].'\',array(';
      $sourceGenere.='\'unsetPossible\'=>'.(isset($v1['unsetPossible']) && $v1['unsetPossible']==true?'true':'false').',\'dropDown\'=>'.(isset($v1['dropDown']) && $v1['dropDown']==true?'true':'false').'));'.CRLF;    
     }
     $sourceGenere.='  $o1.=$retParam[\'html\'];'.CRLF;
     $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
     $count++;
    }else{
     
     $sourceGenere.='  $o1.=\' <div class="fdiv1">\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="flab1"><div>\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
     
     if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){
      $sourceGenere.='  $o1.=\'  <div class="finp1"><div style="display:flex;">\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'   <input type="hidden" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'"   value="\'.enti1($xxxFldValues[\''.$v1['nom_champ'].'\']).\'" />\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'   <div id="div__display_color_'.$v1['nom_champ'].'" style="display:flex;">\'.CRLF;'.CRLF;
      $sourceGenere.='  if($xxxFldValues[\''.$v1['nom_champ'].'\']!=\'\'){  // '.$v1['nom_champ'].''.CRLF;
      $sourceGenere.='   $val=json_decode($xxxFldValues[\''.$v1['nom_champ'].'\'],true);'.CRLF;
      $sourceGenere.='   $o1.=\'    <div style="width:35px;height:35px;border:1px #eee inset;background-color:#\'.$val[\'hexValue\'].\'"></div>\';'.CRLF;
      $sourceGenere.='   $o1.=\'    <div>\'.enti1($val[\'hexValue\']).\'\';'.CRLF;
      $sourceGenere.='   if(isset($val[\'webName\']) && $val[\'webName\']!=\'\'){'.CRLF;
      $sourceGenere.='    $o1.=\',\'.enti1($val[\'webName\']).\'\';'.CRLF;
      $sourceGenere.='   }'.CRLF;
      $sourceGenere.='   if(isset($val[\'pantoneName\']) && $val[\'pantoneName\']!=\'\'){'.CRLF;
      $sourceGenere.='    $o1.=\', pantone:\'.enti1($val[\'pantoneName\']).\'\';'.CRLF;
      $sourceGenere.='   }'.CRLF;
      $sourceGenere.='   $o1.=\'    </div>\';'.CRLF;
      $sourceGenere.='  }'.CRLF;
      $sourceGenere.='  $o1.=\'   </div>\';'.CRLF;
      $sourceGenere.='  $o1.=\'   <div>\';'.CRLF;
      $sourceGenere.='  $o1.=\'    <button type="button" id="button_color_'.$v1['nom_champ'].'" onclick="javascript:setColor1(\\\''.$v1['nom_champ'].'\\\',\\\'button_color_'.$v1['nom_champ'].'\\\',\\\'div__display_color_'.$v1['nom_champ'].'\\\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">\';'.CRLF;
      $sourceGenere.='  $o1.=txtsys1(\'update color\');'.CRLF;
      $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
      $sourceGenere.='  $o1.=\'   </div>\';'.CRLF;
      $sourceGenere.='     '.CRLF;
     
     }else if(strpos(strtolower($v1['type_champ']),'text')     !==false ){
      $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'   <textarea  name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'"  rows="15" >\'.enti1($xxxFldValues[\''.$v1['nom_champ'].'\']).\'</textarea>\'.CRLF;'.CRLF;
     }else{
      if($v1['type_champ']=='datetime'){

       $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'    <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($xxxFldValues[\''.$v1['nom_champ'].'\']).\'" />\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'    <button type="button" style="padding:0px!important;font-size:0.8em;" id="button_datetime_'.$v1['nom_champ'].'" onclick="javascript:setDateTime1(\\\''.$v1['nom_champ'].'\\\',\\\'button_datetime_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0,\\\'\\\')" >\';'.CRLF;
       $sourceGenere.='  $o1.=($xxxFldValues[\''.$v1['nom_champ'].'\']==\'\'?txtsys1(\'datetime null\'):($xxxFldValues[\''.$v1['nom_champ'].'\']==\'NULL\'?txtsys1(\'datetime null\'):($xxxFldValues[\''.$v1['nom_champ'].'\']==\'NOT NULL\'?txtsys1(\'datetime not null\'):$xxxFldValues[\''.$v1['nom_champ'].'\'])));'.CRLF;
       $sourceGenere.='  $o1.=\'</button>\';'.CRLF;

       
      }else if($v1['type_champ']=='time'){

       $timeOption=0;
       if(isset($v1['timeOption']) &&  $v1['timeOption']!='' ){
        $timeOption=$v1['timeOption'];
       }
       $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'    <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($xxxFldValues[\''.$v1['nom_champ'].'\']).\'" />\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'    <button type="button" id="button_time_'.$v1['nom_champ'].'" style="border-style:outset;font-size:0.8em;padding:5px;width:auto;"  \'.($xxxFldValues[\''.$v1['nom_champ'].'\']==\'00:00:00\'?\' class="success" \':($xxxFldValues[\''.$v1['nom_champ'].'\']!=\'\'?\' class="edit" \':\'\')).\' \';'.CRLF;
       $sourceGenere.='  $o1.=\' onclick="javascript:setTime1(\\\''.$v1['nom_champ'].'\\\',\\\'button_time_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0,\\\'\\\','.$timeOption.')">\';'.CRLF;
       $sourceGenere.='  $o1.=($xxxFldValues[\''.$v1['nom_champ'].'\']==\'\'?txtsys1(\'time null\'):($xxxFldValues[\''.$v1['nom_champ'].'\']==\'NULL\'?txtsys1(\'time null\'):($xxxFldValues[\''.$v1['nom_champ'].'\']==\'NOT NULL\'?txtsys1(\'time not null\'):';
       if(isset($v1['timeOption']) && ( $v1['timeOption']==1 || $v1['timeOption']==3 || $v1['timeOption']==5 || $v1['timeOption']==7)){
        $sourceGenere.='substr($xxxFldValues[\''.$v1['nom_champ'].',0,5)';
       }else{
        $sourceGenere.='$xxxFldValues[\''.$v1['nom_champ'].'';
       }
       $sourceGenere.=')));'.CRLF;
       $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
       
      }else if($v1['type_champ']=='date'){
       
       $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;
       $sourceGenere.='  if($xxxFldValues[\''.$v1['nom_champ'].'\']==\'1000-01-01\') $xxxFldValues[\''.$v1['nom_champ'].'\']=\'\';'.CRLF;
       $sourceGenere.='  $o1.=\'    <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($xxxFldValues[\''.$v1['nom_champ'].'\']).\'" />\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'    <button type="button" style="padding:0px!important;font-size:0.8em;" id="button_date_'.$v1['nom_champ'].'" onclick="javascript:setDate1(\\\''.$v1['nom_champ'].'\\\',\\\'button_date_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0)">\';'.CRLF;
       $sourceGenere.='  $o1.=(($xxxFldValues[\''.$v1['nom_champ'].'\']==\'1000-01-01\' || $xxxFldValues[\''.$v1['nom_champ'].'\']==\'\' )?txtsys1(\'date null\'):($xxxFldValues[\''.$v1['nom_champ'].'\']==\'NULL\'?txtsys1(\'date null\'):($xxxFldValues[\''.$v1['nom_champ'].'\']==\'NOT NULL\'?txtsys1(\'date not null\'):$xxxFldValues[\''.$v1['nom_champ'].'\'])));'.CRLF;
       $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
       
      }else if(true===$v1['isNumericField']){
       $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'   <input type="text" value="\'.enti1($xxxFldValues[\''.$v1['nom_champ'].'\']).\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" maxlength="12" style="width:100;max-width:12em;" />\'.CRLF;'.CRLF;
      }else{
       $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'   <input type="text" value="\'.enti1($xxxFldValues[\''.$v1['nom_champ'].'\']).\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" maxlength="'.$v1['fieldSize'].'" style="width:100%;max-width:'.($v1['fieldSize']+2).'em;" />\'.CRLF;'.CRLF;
      }
     }
     $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
     $count++;
    }
   }
  }
 }

 $sourceGenere.=''.CRLF;
 $sourceGenere.='  $o1.=\'<div class="fdiv1">\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;
 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(strpos($v1['nom_champ'],'fld_cntupd_')!==false){
   $sourceGenere.='  $o1.=\'   <input type="hidden" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" value="\'.$name2[\''.$v1['nom_champ'].'\'].\'" />\'.CRLF;'.CRLF;
  }
 }

 $sourceGenere.='  $o1.=\'   <button type="submit" class="">\'.txtsys1(\'save_the_modification\').\'</button>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'</div>\'.CRLF;'.CRLF;
 $sourceGenere.=''.CRLF;
 $sourceGenere.='  $o1.=\'</form>\'.CRLF;'.CRLF;
 $sourceGenere.=''.CRLF;

 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= GET VIEW =========================================================================='.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' }else if(isset($_GET[\'a\'])&&$_GET[\'a\']==\'v\'&&isset($_GET[\'id\'])&&is_numeric($_GET[\'id\'])){ // view action'.CRLF;
 $sourceGenere.='  // if you vant to do something here, go !'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' //============================================= GET CREATE ========================================================================'.CRLF;
 $sourceGenere.=' //================================================================================================================================='.CRLF;
 $sourceGenere.=' }else if(isset($_GET[\'a\'])&&$_GET[\'a\']==\'c\'){ // create action'.CRLF;
 $sourceGenere.=' '.CRLF;
 $sourceGenere.='  $o1.=\'<h2>\'.txt1(\'Add a new record\'). \' \'.btl1().\'</h2>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=displaySessionMessage1(BNF);'.CRLF;
 $sourceGenere.='  $o1.=\'<form method="post" class="form1">\'.CRLF;'.CRLF;
 $sourceGenere.=' '.CRLF;

 foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if(!(strpos($v1['nom_champ'],'fld_cntupd_')!==false || strpos($v1['nom_champ'],'fld_tscrt_')!==false || strpos($v1['nom_champ'],'fld_tsupd_')!==false )){
   if($v1['nom_champ']!=$GLOBALS['__autoincrement']){

    if(isset($v1['parentField'])){

     if($v1['parentField']['fld_link_mandatory_pglnks']=='0'){
      $sourceGenere.='  $'.$v1['nom_champ'].'=isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
     }else{
      $sourceGenere.='  $'.$v1['nom_champ'].'=isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:0;'.CRLF;
     }
     $sourceGenere.='  if('.CRLF;
     $sourceGenere.='   isset($_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\'])&&'.CRLF;
     $sourceGenere.='   $_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\']==txtsys1(\'text_for_the_select_button\')&&'.CRLF;
     $sourceGenere.='   isset($_SESSION[PGMK][\'choose\'][\'valueBack\'])&&'.CRLF;
     $sourceGenere.='   $_SESSION[PGMK][\'choose\'][\'valueBack\']!=0'.CRLF;
     $sourceGenere.='  ){'.CRLF;
     $sourceGenere.='   if($_SESSION[PGMK][NAV][BNF][\'choose__'.$v1['nom_champ'].'\']==txtsys1(\'text_for_the_select_button\')){'.CRLF;
     $sourceGenere.='    $'.$v1['nom_champ'].'=$_SESSION[PGMK][\'choose\'][\'valueBack\'];'.CRLF;
     $sourceGenere.='   }'.CRLF;
     $sourceGenere.='   unset($_SESSION[PGMK][\'choose\']);'.CRLF;
     $sourceGenere.='  }'.CRLF;
     $sourceGenere.='  if($'.$v1['nom_champ'].'!=\'\'){'.CRLF;
     $sourceGenere.='   $xGroupValues=get'.ucfirst(PGMK).'_'.substr($v1['parentField']['fld_name_tables'],8).'1($'.$v1['nom_champ'].'); // todo check this function'.CRLF;
     $sourceGenere.='   $xDisplayValueFetch = \'\' . enti1( $xGroupValues[\''.$v1['parentField']['fld_parent_field_display_pglnks'].'\'] ) . \' (\' . $xGroupValues[\''.$v1['parentField']['fld_parent_field_pglnks'].'\'] . \')\' . \'\' ; // todo check among the fields of the parent table'.CRLF;
     $sourceGenere.='  }else{'.CRLF;
     $sourceGenere.='   $xDisplayValueFetch =\'\';'.CRLF;
     $sourceGenere.='  }'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="fdiv1">\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'   <div class="flab1"><div>\'.txt1(\'parent_'.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'   <div class="finp1"><div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'    <input type="hidden" value="\'.enti1($'.$v1['nom_champ'].').\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" />\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'     <span id="span__dep_'.$v1['nom_champ'].'">\'.$xDisplayValueFetch.\'</span>\';'.CRLF;
     $sourceGenere.='  $o1.=\'    <button type="submit" name="choose__'.$v1['nom_champ'].'" class="btn" value="\'. txtsys1(\'text_for_the_select_button\') . \'">\';'.CRLF;
     $sourceGenere.='  $o1.=\'\'   . txtsys1(\'text_for_the_select_button\') . \'\';'.CRLF;
     $sourceGenere.='  $o1.=     \'</button>\'."\r\n";'.CRLF;
     if($v1['parentField']['fld_link_mandatory_pglnks']=='0'){
      $sourceGenere.='  $o1.=\'    <button type="button" class="warning" onclick="razDependant1(\\\'span__dep_'.$v1['nom_champ'].'\\\',\\\''.$v1['nom_champ'].'\\\')">\';'.CRLF;
      $sourceGenere.='  $o1.=\'\'   . txtsys1(\'raz_button\') . \'\';'.CRLF;
      $sourceGenere.='  $o1.=     \'</button>\'."\r\n";'.CRLF;
     }
     
     $sourceGenere.='  $o1.=\'   </div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  </div>\'.CRLF;'.CRLF.CRLF;
     
     
    }else if(isset($v1['param_name'])){
//     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $v1 , true ) . '</pre>' ; exit(0);
     $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
     $sourceGenere.='  $o1.=\' <div class="fdiv1">\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="flab1"><div>\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;
     $sourceGenere.='  require_once($GLOBALS[\'glob_dataPath1\'].\'/generated/_params/'.$v1['param_name'].'.php\');'.CRLF;
     if(isset($v1['param_isSetOfValues']) && $v1['param_isSetOfValues'] == true ){
      $sourceGenere.='  $retParam=displayParam2(\''.$v1['param_name'].'\',$'.$v1['nom_champ'].',\''.$v1['nom_champ'].'\',array(\'set\'=>true));'.CRLF;
     }else{
      $sourceGenere.='  $retParam=displayParam2(\''.$v1['param_name'].'\',$'.$v1['nom_champ'].',\''.$v1['nom_champ'].'\',';
      $sourceGenere.='array(\'unsetPossible\'=>'.(isset($v1['unsetPossible']) && $v1['unsetPossible']==true?'true':'false').',';
      $sourceGenere.='\'dropDown\'=>'.(isset($v1['dropDown']) && $v1['dropDown']==true?'true':'false').'));'.CRLF;
     }
     $sourceGenere.='  $o1.=$retParam[\'html\'];'.CRLF;
     $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
     $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
     $count++;
    }else{
     $sourceGenere.=''.CRLF;
     if(strpos(strtolower($v1['type_champ']),'text')     !==false ){
      $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
      $sourceGenere.='  $o1.=\' <div class="fdiv1">\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="flab1"><div>\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'   <textarea  name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'"  rows="15" >\'.enti1($'.$v1['nom_champ'].').\'</textarea>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
      $count++;
     }else{
      if($v1['type_champ']=='datetime'){
       if($v1['null_possible']=='YES'){
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;       
       }else{
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:date(\'Y-m-d H:i:s\');'.CRLF;               
       }
      }else if($v1['type_champ']=='time'){
       if($v1['null_possible']=='YES'){
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
       }else{
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:date(\'H:i:s\');'.CRLF;        
       }
      }else if($v1['type_champ']=='date'){
       if($v1['null_possible']=='YES'){
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
       }else{
        $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:date(\'Y-m-d\');'.CRLF;        
       }
      }else if(true===$v1['isNumericField']){
       $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:0;'.CRLF;
      }else{
       $sourceGenere.='  $'.$v1['nom_champ'].' =isset($_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\'] )?$_SESSION[PGMK][NAV][BNF][\''.$v1['nom_champ'].'\']:\'\';'.CRLF;
      }
      $sourceGenere.='  $o1.=\' <div class="fdiv1">\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\'  <div class="flab1"><div>\'.txt1(\''.$v1['nom_champ'].'\').\'</div></div>\'.CRLF;'.CRLF;
      if(isset($v1['subtype']) && $v1['subtype']=='webcolor'){

       $sourceGenere.='  $o1.=\'  <div class="finp1"><div style="display:flex;">\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'   <input type="hidden" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'"   value="\'.enti1($'.$v1['nom_champ'].').\'" />\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'   <div id="div__display_color_'.$v1['nom_champ'].'" style="display:flex;">\'.CRLF;'.CRLF;
       $sourceGenere.='  if($'.$v1['nom_champ'].'!=\'\'){  // '.$v1['nom_champ'].''.CRLF;
       $sourceGenere.='   $val=json_decode($'.$v1['nom_champ'].',true);'.CRLF;
       $sourceGenere.='   $o1.=\'    <div style="width:35px;height:35px;border:1px #eee inset;background-color:#\'.$val[\'hexValue\'].\'"></div>\'; // '.$v1['nom_champ'].''.CRLF;
       $sourceGenere.='   $o1.=\'    <div>\'.enti1($val[\'hexValue\']).\'\';'.CRLF;
       $sourceGenere.='   if(isset($val[\'webName\']) && $val[\'webName\']!=\'\'){'.CRLF;
       $sourceGenere.='    $o1.=\',\'.enti1($val[\'webName\']).\'\';'.CRLF;
       $sourceGenere.='   }'.CRLF;
       $sourceGenere.='   if(isset($val[\'pantoneName\']) && $val[\'pantoneName\']!=\'\'){'.CRLF;
       $sourceGenere.='    $o1.=\', pantone:\'.enti1($val[\'pantoneName\']).\'\';'.CRLF;
       $sourceGenere.='   }'.CRLF;
       $sourceGenere.='   $o1.=\'    </div>\';'.CRLF;
       $sourceGenere.='  }'.CRLF;
       $sourceGenere.='  $o1.=\'   </div>\';'.CRLF;
       $sourceGenere.='  $o1.=\'   <div>\';'.CRLF;
       $sourceGenere.='  $o1.=\'    <button type="button" id="button_color_'.$v1['nom_champ'].'" onclick="javascript:setColor1(\\\''.$v1['nom_champ'].'\\\',\\\'button_color_'.$v1['nom_champ'].'\\\',\\\'div__display_color_'.$v1['nom_champ'].'\\\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">\';'.CRLF;
       $sourceGenere.='  $o1.=txtsys1(\'update color\');'.CRLF;
       $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
       $sourceGenere.='  $o1.=\'   </div>\';'.CRLF;

      
      }else if($v1['type_champ']=='datetime'){
       $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;      
       $sourceGenere.='  $o1.=\'   <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($'.$v1['nom_champ'].').\'" />\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'   <button type="button" style="padding:0px!important;font-size:0.8em;"  id="button_datetime_'.$v1['nom_champ'].'" onclick="javascript:setDateTime1(\\\''.$v1['nom_champ'].'\\\',\\\'button_datetime_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0,0,\\\'\\\')" >\';'.CRLF;
       $sourceGenere.='  $o1.=($'.$v1['nom_champ'].'==\'\'?txtsys1(\'datetime null\'):($'.$v1['nom_champ'].'==\'NULL\'?txtsys1(\'datetime null\'):($'.$v1['nom_champ'].'==\'NOT NULL\'?txtsys1(\'datetime not null\'):$'.$v1['nom_champ'].')));'.CRLF;
       $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
      }else if($v1['type_champ']=='time'){
       $timeOption=0;
       if(isset($v1['timeOption']) &&  $v1['timeOption']!='' ){
        $timeOption=$v1['timeOption'];
       }
       $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;      
       $sourceGenere.='  $o1.=\'    <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($'.$v1['nom_champ'].').\'" />\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'    <button type="button" style="padding:0px!important;font-size:0.8em;" id="button_time_'.$v1['nom_champ'].'" \';'.CRLF;
       $sourceGenere.='  $o1.=\' onclick="javascript:setTime1(\\\''.$v1['nom_champ'].'\\\',\\\'button_time_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0,\\\'\\\','.$timeOption.')" >\';'.CRLF;
       $sourceGenere.='  $o1.=($'.$v1['nom_champ'].'==\'\'?txtsys1(\'time null\'):($'.$v1['nom_champ'].'==\'NULL\'?txtsys1(\'time null\'):($'.$v1['nom_champ'].'==\'NOT NULL\'?txtsys1(\'time not null\'):';
       if(isset($v1['timeOption']) && ( $v1['timeOption']==1 || $v1['timeOption']==3 || $v1['timeOption']==5 || $v1['timeOption']==7)){
        $sourceGenere.='substr($'.$v1['nom_champ'].',0,5)';
       }else{
        $sourceGenere.='$'.$v1['nom_champ'].'';
       }
       $sourceGenere.=')));'.CRLF;
       $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
      }else if($v1['type_champ']=='date'){
       $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;      
       $sourceGenere.='  if($'.$v1['nom_champ'].'==\'1000-01-01\') $'.$v1['nom_champ'].'=\'\';'.CRLF;
       $sourceGenere.='  $o1.=\'    <input type="hidden" name="'.$v1['nom_champ'].'"    id="'.$v1['nom_champ'].'"   value="\'.enti1($'.$v1['nom_champ'].').\'" />\'.CRLF;'.CRLF;
       $sourceGenere.='  $o1.=\'    <button type="button" style="padding:0px!important;font-size:0.8em;" id="button_date_'.$v1['nom_champ'].'" onclick="javascript:setDate1(\\\''.$v1['nom_champ'].'\\\',\\\'button_date_'.$v1['nom_champ'].'\\\','.($v1['null_possible']!='YES'?'0':'1').',0)" >\';'.CRLF;
       $sourceGenere.='  $o1.=(($'.$v1['nom_champ'].'==\'1000-01-01\' || $'.$v1['nom_champ'].'==\'\' )?txtsys1(\'date null\'):($'.$v1['nom_champ'].'==\'NULL\'?txtsys1(\'date null\'):($'.$v1['nom_champ'].'==\'NOT NULL\'?txtsys1(\'date not null\'):$'.$v1['nom_champ'].')));'.CRLF;
       $sourceGenere.='  $o1.=\'</button>\';'.CRLF;
      }else if(true===$v1['isNumericField']){
       $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;      
       $sourceGenere.='  $o1.=\'   <input type="text" value="\'.enti1($'.$v1['nom_champ'].').\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" maxlength="12" />\'.CRLF;'.CRLF;
      }else{
       $sourceGenere.='  $o1.=\'  <div class="finp1"><div>\'.CRLF;'.CRLF;      
       $sourceGenere.='  $o1.=\'   <input type="text" value="\'.enti1($'.$v1['nom_champ'].').\'" name="'.$v1['nom_champ'].'" id="'.$v1['nom_champ'].'" maxlength="'.$v1['fieldSize'].'" style="width:100%;max-width:'.($v1['fieldSize']+2).'em;" />\'.CRLF;'.CRLF;       
      }
      $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
      $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF.CRLF;
      $count++;
     }
    }
   }
  }
 }
 $sourceGenere.='  $o1.=\' <div class="fdiv1">\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'  <div class="flab1"><div>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'   <button type="submit">\'.txtsys1(\'record_the_element\').\'</button>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'   <input type="hidden" value="0" name="id1" id="id1" />\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'   <input type="hidden" value="c" name="a" id="a" />\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\'  </div></div>\'.CRLF;'.CRLF;
 $sourceGenere.='  $o1.=\' </div>\'.CRLF;'.CRLF;
 $sourceGenere.=''.CRLF.CRLF;
 $sourceGenere.='  $o1.=\'</form>\'.CRLF;'.CRLF.CRLF;
 $sourceGenere.=' }'.CRLF;

 $sourceGenere.=' $o1.=htmlFoot0(array(\'js\' => $js1));'.CRLF;
 $sourceGenere.=' dw1($o1);'.CRLF;
 $sourceGenere.=' if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);'.CRLF;
 $sourceGenere.='}'.CRLF;

}

//========================================================================================================================
//========================================================================================================================
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_SESSION , true ) . '</pre>' ; exit(0);
$o1='';
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('generate the sources_10_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $o1 , true ) . '</pre>' ; exit(0);
if(isset($_GET['a']) && $_GET['a']=='inc1'){
 $o1.='<div>file <input type="text" value="_inc_'.substr($_GET['table'],8).'1.php" /></div>'; 
}
if(isset($_GET['a']) && $_GET['a']=='list1'){
 $o1.='<div>file <input type="text" value="'.substr($_GET['table'],8).'1.php" /></div>'; 
}
if(isset($_GET['a']) && $_GET['a']=='action1'){
 $o1.='<div>file <input type="text" value="'.substr($_GET['table'],8).'_action1.php" /></div>'; 
}
if(isset($_GET['a']) && $_GET['a']=='choose1'){
 $o1.='<div>file <input type="text" value="'.substr($_GET['table'],8).'_choose1.php" /></div>'; 
}
if($sourceGenere!=''){
 $o1.='<textarea rows="100" style="font-family:monospace;font-size:8px;width:95%;">'.enti1($sourceGenere).'</textarea>';
}
$tableList=array();
foreach($GLOBALS['glob_db'] as $k1 => $v1){
 $toPrint.='<h4>' .txt2('List of the tables for the database_14_20'). ' : ' . $v1['server'] . '/' . $v1['dbname'] . '</h4>';
 $tableList[$k1]['server']=$v1['server'];
 $tableList[$k1]['dbname']=$v1['dbname'];
 $tableList[$k1]['tables']=array();

 $req6='SHOW TABLES FROM `'.$v1['dbname'].'` LIKE \''.$GLOBALS['__table_prefix'].'%\'';
 
 $result6=mysqli_query($v1['link'],$req6);
 if(mysqli_errno($v1['link'])==0){
  $toPrint.='<table class="tableResult1">'.CRLF;
  $toPrint.='<thead><tr><th>'.txtsys1('action').'</th><th>'.txt2('table name_19_29').'</th></tr></thead><tbody>'.CRLF;
  while($mpsr6=mysqli_fetch_row($result6)){
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $mpsr6 , true ) . '</pre>' ; exit(0);
   if(isset($_GET['table']) && $_GET['table']==$mpsr6[0]){
    $toPrint.='<tr class="success">';    
   }else{
    $toPrint.='<tr>';
   }
   $toPrint.=' <td>'.CRLF;
   $toPrint.='  <a href="?a=inc1&amp;table='.urlencode($mpsr6[0]).'&amp;idBase='.$k1.'" title="'.txt2('inc_1205_103').'">';
   $toPrint.=''.txt2('inc_2281_129').'';
   $toPrint.='</a>';
   $toPrint.='  <a href="?a=list1&amp;table='.urlencode($mpsr6[0]).'&amp;idBase='.$k1.'" title="'.txt2('list_1206_104').'">';
   $toPrint.=''.txt2('list_2282_131').'';
   $toPrint.='</a>';
   $toPrint.='  <a href="?a=action1&amp;table='.urlencode($mpsr6[0]).'&amp;idBase='.$k1.'" title="'.txt2('action_1207_106').'">';
   $toPrint.=''.txt2('action_2283_135').'';
   $toPrint.='</a>';
   $toPrint.='  <a href="?a=choose1&amp;table='.urlencode($mpsr6[0]).'&amp;idBase='.$k1.'" title="'.txt2('action_1207_106').'">';
   $toPrint.=''.txt2('choose_1208_126').'';
   $toPrint.='</a>';
   $toPrint.=' </td>'.CRLF;
   $toPrint.=' <td>';
   $toPrint.='  '.$mpsr6[0].'';
   $toPrint.=' </td>'.CRLF;
   $toPrint.='</tr>';
   $tableList[$k1]['tables'][$mpsr6[0]]['fields']=array();
  }
  $toPrint.='</tbody></table>'.CRLF;
  mysqli_free_result($result6);
 }else{
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=':-( '. __LINE__ .' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
 }
}


$o1.=$toPrint;
//echo __FILE__ . ' ' . __LINE__ . ' $tableList = <pre>' . var_export( $tableList , true ) . '</pre>' ; exit(0);
/*
foreach( $tableList as $k1 => $v1){
 foreach( $v1['tables'] as $k2 => $v2){
  $tableName=$k2;
  unset($GLOBALS['__listeDesChamps']);//=array();
  $par1=array('table' => $tableName , 'idBase' => $k1);
  getTableInfos($par1);
  $tableList[$k1]['tables'][$k2]['fields']=$GLOBALS['__listeDesChamps'];
 }
}

$o1.='<pre>' . enti1(var_export( $tableList , true )) . '</pre>' ;
*/

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();