<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages() || $_SESSION[PGMK]['translate']==1){
 openDb1();
 $err=0;
 if(isset($ret['input']['type']) && $ret['input']['type']=='javascript'){
  if(!is_dir($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css')){
   if(!mkdir($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css',0777,true)){
    $err=1;
   }
  }
  if($err==0){
   $req6='
    SELECT  
     T0.`fld_key_lngVals`   , T0.`fld_lang_lngVals`  , T0.`fld_value_lngVals` 
    FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0 
    WHERE T0.`fld_type_lngVals`        = \'javascript\'
   ';
   $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    while($mpsr6=mysqli_fetch_row($result6)){
     $fileContent[$mpsr6[1]][]='globTablang.push({key:'.var_export($mpsr6[0],true).',value:'.var_export($mpsr6[2],true).'});'.CRLF; //$GLOBALS[\'glob_lv\'][\''.$mpsr6[0].'\']='.var_export($mpsr6[2],true).';'.CRLF;
    }
    mysqli_free_result($result6);
    foreach($fileContent as $k1 => $v1){
     $listeDesTextes='';
     foreach($v1 as $k2 => $v2){
      $listeDesTextes.=$v2;
     }
     $listeDesTextes=''.$listeDesTextes.'';
     file_put_contents($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/'.$k1.'_main.js',$listeDesTextes);   
    }
    $ret['status']='OK';
   }else{
    $ret['message'][]='mysqli_error() "'.mysqli_error($GLOBALS['glob_db'][0]['link']).'"';
   }   
  }else{
   $ret['message'][]=__FILE__ . ' ' . __LINE__ . ' ' . 'cannot create '.$GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css';
  }
 }else if(is_file($ret['input']['page'])){
  if(!is_dir($GLOBALS['glob_noVcPath1'].'/translation_for_pages')){
   if(!mkdir($GLOBALS['glob_noVcPath1'].'/translation_for_pages',0777,true)){
    $err=1;
   }
  }
  if($err==0){
   $fileContent=array();
   $req6='
    SELECT  
     T0.`fld_key_lngVals`   , T0.`fld_lang_lngVals`  , T0.`fld_value_lngVals` 
    FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0 
    WHERE T0.`fld_page_id_lngVals`        = ' . $ret['input']['page_id'] . '
   ';
//   if($fdtoto=fopen('toto.txt','a+')){ fwrite($fdtoto, $req6 ); fclose($fdtoto); }
   $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    while($mpsr6=mysqli_fetch_row($result6)){
     $fileContent[$mpsr6[1]][]='$GLOBALS[\'glob_lv\']['.var_export($mpsr6[0],true).']='.var_export($mpsr6[2],true).';'.CRLF;
    }
    mysqli_free_result($result6);
   }else{
    $ret['message']='mysqli_error() "'.mysqli_error($GLOBALS['glob_db'][0]['link']).'"';
   }
   $tabSpecial=array('menu','system');
   foreach($tabSpecial as $k1 => $v1){
    $req6='
     SELECT  
      T0.`fld_key_lngVals`   , T0.`fld_lang_lngVals`  , T0.`fld_value_lngVals` 
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0 
     WHERE T0.`fld_type_lngVals`   = \''.$v1.'\'
    ';
    $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
     while($mpsr6=mysqli_fetch_row($result6)){
      $key=$v1.'__'.$mpsr6[0];
      $fileContent[$mpsr6[1]][]='$GLOBALS[\'glob_lv\']['.var_export($key,true).']='.var_export($mpsr6[2],true).';'.CRLF;
     }
     mysqli_free_result($result6);
    }else{
     $ret['message']='mysqli_error() "'.mysqli_error($GLOBALS['glob_db'][0]['link']).'"';
    }
   }
   foreach($fileContent as $k1 => $v1){
    $listeDesTextes='';
    foreach($v1 as $k2 => $v2){
     $listeDesTextes.=$v2;
    }
    $listeDesTextes='<'.'?php'.CRLF.$listeDesTextes.'';
    file_put_contents($GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$k1.'_'.$ret['input']['page'],$listeDesTextes);   
   }
   $ret['status']='OK';
  }
 }else{
  $ret['message']='Cannot find "'.$ret['input']['page'].'"';
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
} 