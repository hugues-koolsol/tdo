<?php
// group 1:root
$GLOBALS['glob_treegrp']='4';