<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 $fileOutput='';
 $someErrors=array();
 openDb1();
 $oneError=false;
 $conn_id=ftp_connect($_SESSION[PGMK]['ftp__server'],21,3);
 if($conn_id==false){
  $ret['message'][]= __LINE__ .' : connexion KO to ' . $_SESSION[PGMK]['ftp__server'];
  $oneError=true;
 }else{
  if(ftp_login($conn_id, $_SESSION[PGMK]['ftp__user'], $_SESSION[PGMK]['ftp__password'])){ // Tentative d'identification
   if(isset($ret['input']['directDelete']) && $ret['input']['directDelete']==true){
    $toDelete='/'.$_SESSION[PGMK]['ftp__path'].'/'.$ret['input']['pathToDelete'];
    $retDel=ftp_delete( $conn_id , $toDelete );
    if(true!==$retDel){
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('warning').' '. __LINE__ .' : ftp_pasv ' . $_SESSION[PGMK]['ftp__server'];
     $oneError=true;
    }
   }else{
    if(ftp_pasv($conn_id, true)){
     $ret['message'][]= __LINE__ .' : ftp_pasv OK ' . $_SESSION[PGMK]['ftp__server'];
    }else{
     $ret['message'][]= __LINE__ .' : ftp_pasv KO ' . $_SESSION[PGMK]['ftp__server'] . '' ;
    }
    require_once 'zzz_tmp_ftp_filesRemoteButShouldNotBe.php';
    foreach($ret['input']['lstIds'] as $k1 => $v1){
     if(false===$oneError){
      $theFile=$GLOBALS['__ftp_filesRemoteButShouldNotBe']['data'][$v1];
      $retDel=@ftp_delete( 
       $conn_id , 
       '/'.$_SESSION[PGMK]['ftp__path'].'/'.$theFile['remote_path']  
      );
      if(true!==$retDel){
       $ret['message'][]= __LINE__ .' : delete file ' . '/'.$_SESSION[PGMK]['ftp__path'].'/'.$theFile['remote_path'] .' KO for ' . var_export( $theFile , true );
       $oneError=true;
      }else{
       $ret['data']['keysOK'][]=$v1;
      }
     }
    }
   }
  }else{
   $ret['message'][]= __LINE__ .' : login ftp KO ';
   $err=1;
  }
  ftp_close($conn_id); // Fermeture de la connexion
 }
 if(false===$oneError){
  $ret['status']='OK';
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}