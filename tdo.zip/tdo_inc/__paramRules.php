<?php
$GLOBALS['__paramRules']=array (
  0 => 
  array (
    'T0.fld_id_parrules' => '1',
    'T0.fld_name_parrules' => 'Europe',
    'T0.fld_id_param_parrules' => '5',
    'T1.fld_label_parnams' => 'country',
  ),
  1 => 
  array (
    'T0.fld_id_parrules' => '2',
    'T0.fld_name_parrules' => 'America',
    'T0.fld_id_param_parrules' => '5',
    'T1.fld_label_parnams' => 'country',
  ),
  2 => 
  array (
    'T0.fld_id_parrules' => '3',
    'T0.fld_name_parrules' => 'Asia',
    'T0.fld_id_param_parrules' => '5',
    'T1.fld_label_parnams' => 'country',
  ),
);