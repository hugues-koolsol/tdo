var globalCssSettings1={
    "main": {
        "mainBackgroundColor": {
            "hexValue": "ECEFF1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 50",
            "hsvValue": "2,2,94",
            "rgbValue": "236,239,241",
            "type": "color"
        },
        "mainBackgroundColEnd": {
            "hexValue": "DBDBDB",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,86",
            "rgbValue": "219,219,219"
        },
        "mainTextColor": {
            "hexValue": "555555",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,33",
            "rgbValue": "85,85,85",
            "type": "color"
        },
        "thinBorderColor": {
            "hexValue": "D8D8D8",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "71,0,85",
            "rgbValue": "216,216,216",
            "type": "color"
        },
        "linkStartBackgroundColor": {
            "hexValue": "FFFFFF",
            "webValue": "FFFFFF",
            "webName": "white",
            "pantoneName": "",
            "hsvValue": "0,0,100",
            "rgbValue": "255,255,255",
            "type": "color"
        },
        "linkEndBackground": {
            "hexValue": "D6D6D6",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,84",
            "rgbValue": "214,214,214"
        },
        "linkUnsetTextColor": {
            "hexValue": "EFEFEF",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,93",
            "rgbValue": "239,239,239",
            "type": "color"
        },
        "activeFilterBackground": {
            "hexValue": "FCFC00",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "60,100,99",
            "rgbValue": "252,252,0"
        },
        "activeFilterColor": {
            "hexValue": "555555",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,33",
            "rgbValue": "85,85,85",
            "type": "color"
        },
        "inputBorderWidth": {
            "type": "SomeValues",
            "valueList": "1px,2px,3px",
            "value": "1px",
            "hr_after": false
        }
    },
    "menu": {
        "topColor": {
            "hexValue": "78909C",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 400",
            "hsvValue": "23,23,61",
            "rgbValue": "120,144,156",
            "type": "color"
        },
        "bottomColor": {
            "hexValue": "455A64",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 700",
            "hsvValue": "31,31,39",
            "rgbValue": "69,90,100",
            "type": "color"
        },
        "textColor": {
            "hexValue": "EEEEEE",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "0,0,93",
            "rgbValue": "238,238,238",
            "type": "color"
        },
        "borderColor": {
            "hexValue": "868D97",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "215,11,59",
            "rgbValue": "134,141,151",
            "type": "color"
        },
        "activeBackgroundColor": {
            "hexValue": "455A64",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 700",
            "hsvValue": "31,31,39",
            "rgbValue": "69,90,100",
            "type": "color"
        }
    },
    "table": {
        "headerBackgroundColor": {
            "hexValue": "CFD8DC",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 100",
            "hsvValue": "5,5,86",
            "rgbValue": "207,216,220",
            "type": "color"
        },
        "headerTextColor": {
            "hexValue": "666666",
            "type": "color"
        },
        "linkTextColor": {
            "hexValue": "666666",
            "webValue": "666666",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "0,0,40",
            "rgbValue": "102,102,102",
            "type": "color"
        },
        "nthchildBackgroundColor": {
            "hexValue": "E3EAEF",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "204,5,94",
            "rgbValue": "227,234,239",
            "type": "color"
        }
    },
    "backgrounds": {
        "dangerBackground": {
            "hexValue": "FF0000",
            "webValue": "FF0000",
            "webName": "red",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,0,0",
            "type": "color"
        },
        "danger2Background": {
            "hexValue": "D10000",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,100,82",
            "rgbValue": "209,0,0"
        },
        "dangerText": {
            "hexValue": "FFFFFF",
            "webValue": "FFFFFF",
            "webName": "white",
            "pantoneName": "",
            "hsvValue": "0,0,100",
            "rgbValue": "255,255,255",
            "type": "color"
        },
        "editBackground": {
            "hexValue": "2196F3",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 500",
            "hsvValue": "86,86,95",
            "rgbValue": "33,150,243"
        },
        "edit2Background": {
            "hexValue": "1D83D1",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "206,86,82",
            "rgbValue": "29,131,209"
        },
        "editText": {
            "hexValue": "F7F7F7",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,97",
            "rgbValue": "247,247,247"
        },
        "successBackground": {
            "hexValue": "A8E067",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "87,54,87",
            "rgbValue": "168,224,103"
        },
        "success2Background": {
            "hexValue": "7AAB3F",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "87,63,67",
            "rgbValue": "122,171,63"
        },
        "successText": {
            "hexValue": "485E21",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "hsvValue": "82,64,37",
            "rgbValue": "72,94,33",
            "type": "color"
        },
        "errorBackground": {
            "hexValue": "FD3131",
            "type": "color"
        },
        "error2Background": {
            "hexValue": "DB2B2B",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,80,86",
            "rgbValue": "219,43,43"
        },
        "errorText": {
            "hexValue": "FFFF33",
            "webValue": "FFFF33",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "80,80,100",
            "rgbValue": "255,255,51"
        },
        "warningBackground": {
            "type": "color",
            "hexValue": "FFA500"
        },
        "warning2Background": {
            "hexValue": "E08E00",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "38,100,88",
            "rgbValue": "224,142,0"
        },
        "warningText": {
            "hexValue": "754800",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "37,100,46",
            "rgbValue": "117,72,0"
        }
    },
    "badge": {
        "badge0Background": {
            "hexValue": "FF0000",
            "webValue": "FF0000",
            "webName": "red",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,0,0",
            "type": "color"
        },
        "badge0TextColor": {
            "hexValue": "FFFFFF",
            "webValue": "FFFFFF",
            "webName": "white",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,100",
            "rgbValue": "255,255,255",
            "type": "color"
        },
        "badge1Background": {
            "hexValue": "00FF00",
            "webValue": "00FF00",
            "webName": "lime",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "0,255,0",
            "type": "color"
        },
        "badge1TextColor": {
            "hexValue": "008000",
            "webValue": "008000",
            "webName": "green",
            "pantoneName": "",
            "hsvValue": "100,100,50",
            "rgbValue": "0,128,0",
            "type": "color"
        },
        "badge2Background": {
            "hexValue": "FFFF00",
            "webValue": "FFFF00",
            "webName": "yellow",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,255,0",
            "type": "color"
        },
        "badge2TextColor": {
            "hexValue": "0000FF",
            "webValue": "0000FF",
            "webName": "blue",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "240,100,100",
            "rgbValue": "0,0,255",
            "type": "color"
        },
        "badge3Background": {
            "hexValue": "FF00FF",
            "webValue": "FF00FF",
            "webName": "fuchsia",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "300,100,100",
            "rgbValue": "255,0,255",
            "type": "color"
        },
        "badge3TextColor": {
            "hexValue": "FFFF00",
            "webValue": "FFFF00",
            "webName": "yellow",
            "pantoneName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "255,255,0",
            "type": "color"
        },
        "badge4Background": {
            "hexValue": "00FFFF",
            "webValue": "00FFFF",
            "webName": "aqua",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "180,100,100",
            "rgbValue": "0,255,255",
            "type": "color"
        },
        "badge4TextColor": {
            "hexValue": "0000FF",
            "webValue": "0000FF",
            "webName": "blue",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "240,100,100",
            "rgbValue": "0,0,255",
            "type": "color"
        },
        "badge5Background": {
            "hexValue": "4CAF50",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Green 500",
            "hsvValue": "122,56,68",
            "rgbValue": "76,175,80",
            "type": "color"
        },
        "badge5TextColor": {
            "hexValue": "FFEB3B",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Yellow 500",
            "hsvValue": "53,76,100",
            "rgbValue": "255,235,59",
            "type": "color"
        },
        "badge6Background": {
            "hexValue": "FFEBEE",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 50",
            "hsvValue": "7,7,100",
            "rgbValue": "255,235,238",
            "type": "color"
        },
        "badge6TextColor": {
            "hexValue": "C62828",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 800",
            "hsvValue": "0,79,77",
            "rgbValue": "198,40,40",
            "type": "color"
        },
        "badge7Background": {
            "hexValue": "1E88E5",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 600",
            "hsvValue": "208,86,89",
            "rgbValue": "30,136,229",
            "type": "color"
        },
        "badge7TextColor": {
            "hexValue": "E3F2FD",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 50",
            "hsvValue": "205,10,99",
            "rgbValue": "227,242,253",
            "type": "color"
        },
        "badge8Background": {
            "hexValue": "FFE082",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Amber 200",
            "hsvValue": "45,49,100",
            "rgbValue": "255,224,130",
            "type": "color"
        },
        "badge8TextColor": {
            "hexValue": "F06292",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Pink 300",
            "hsvValue": "340,59,94",
            "rgbValue": "240,98,146",
            "type": "color"
        }
    },
    "other": {
        "autocompleteInput": {
            "type": "yorno",
            "value": "0"
        }
    },
    "sizes": {
        "menuHeight": 55,
        "footerHeight": 20
    }
};