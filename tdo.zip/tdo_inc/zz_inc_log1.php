<?php
function getinc_tdo_log1($id){
 $n=array();
 $n['T0_fld_id_log']                =0;
 $n['T0_fld_timstp_log']            ='';
 $n['T0_fld_text_log']              ='';
 $n['T0_fld_bnf_log']               ='';
 $n['T0_fld_line_log']              =0;
 $n['T0_fld_user_id_log']           =0;
 $n['T0_fld_typ_log']               ='';
 $n['T0_fld_tag_log']               ='';
 $n['T0_fld_group_id_log']          =0;
 $sql='
  SELECT 
   T0.`fld_id_log`                ,T0.`fld_timstp_log`            ,T0.`fld_text_log`              ,T0.`fld_bnf_log`               ,T0.`fld_line_log`              ,
   T0.`fld_user_id_log`           ,T0.`fld_typ_log`               ,T0.`fld_tag_log`               ,T0.`fld_group_id_log`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__log` T0
  WHERE T0.`fld_id_log` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['T0_fld_id_log']                = $row[0];
   $n['T0_fld_timstp_log']            = $row[1];
   $n['T0_fld_text_log']              = $row[2];
   $n['T0_fld_bnf_log']               = $row[3];
   $n['T0_fld_line_log']              = $row[4];
   $n['T0_fld_user_id_log']           = $row[5];
   $n['T0_fld_typ_log']               = $row[6];
   $n['T0_fld_tag_log']               = $row[7];
   $n['T0_fld_group_id_log']          = $row[8];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
