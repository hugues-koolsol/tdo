<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 if(is_file($ret['input']['page'])){
  $ret['message'][]='Founded "'.$ret['input']['page'].'"';
  $fileOutput='';
  $arrFile=file($ret['input']['page']);
  $count=0;
  $someErrors=array();
  openDb1();
  $oneError=false;
  $fld_id_lngVals=0;
  $req6="
   SELECT  `fld_id_lngVals` 
     FROM`".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues`
   WHERE
       `fld_key_lngVals`     = '".addslashes($ret['input']['key'])     ."'
   AND `fld_lang_lngVals`    = '".addslashes($ret['input']['lang'])    ."'
   AND `fld_type_lngVals`    = 'javascript'
  " ;
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($mpsr6=mysqli_fetch_row($res6)){
    $fld_id_lngVals=$mpsr6[0];
   }
   mysqli_free_result($res6);
  }else{
   $oneError=true;
   $someErrors[]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']) . ' req6=' . $req6;
  }
  if(0===$fld_id_lngVals){
   $req6="
    INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
      `fld_key_lngVals`     = '".addslashes1($ret['input']['key'])    ."'
    , `fld_lang_lngVals`    = '".addslashes1($ret['input']['lang'])   ."'
    , `fld_type_lngVals`    = 'javascript'
    , `fld_value_lngVals`   = '".addslashes1($ret['input']['value'])  ."'
    , `fld_tsupd_lngVals`   = '".$GLOBALS['glob_setdate']            ."'
    , `fld_tscrt_lngVals`   = '".$GLOBALS['glob_setdate']            ."'
   " ;
   $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $oneError=true;
    $someErrors[]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']) . ' req6=' . $req6;
   }
  }else{
   $req6="
    UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
      `fld_value_lngVals`   = '".addslashes1($ret['input']['value'])   ."'
    , `fld_tsupd_lngVals`   = '".$GLOBALS['glob_setdate']                  ."'
    WHERE
        `fld_key_lngVals`     = '".addslashes($ret['input']['key'])     ."'
    AND `fld_lang_lngVals`    = '".addslashes($ret['input']['lang'])    ."'
    AND `fld_type_lngVals`    = 'javascript'
   " ;
   $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $oneError=true;
    $someErrors[]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']) . ' req6=' . $req6;
   }  
  }
  if(false===$oneError){
   $ret['status']='OK';
   $ret['input']['type']='javascript';
   include 'ajax_writeTranslationFiles1.php';
  }
 }else{
  $ret['message']='Cannot find "'.$ret['input']['page'].'"';
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}