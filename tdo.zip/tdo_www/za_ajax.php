<?php //PLEASE, keep this comment with the EURO sign, this source MUST be in utf-8 ---- € déjà

function myErrorHandler($errno, $errstr, $errfile, $errline){
 if (!(error_reporting() & $errno)) {
  // Ce code d'erreur n'est pas inclus dans error_reporting(), donc il continue jusqu'au gestionaire d'erreur standard de PHP
  return;
 }
 $ret=array(
  'status'  => 'KO' ,
  'message' => array()
 );
 $message=array();
 switch ($errno) {
  case E_USER_ERROR:   $ret['message'][]="E_USER_ERROR [$errno] PHP " . PHP_VERSION . " (" . PHP_OS . ")";      break;
  case E_USER_WARNING: $ret['message'][]="E_USER_WARNING [$errno] PHP " . PHP_VERSION . " (" . PHP_OS . ")";    break;
  case E_USER_NOTICE:  $ret['message'][]="E_USER_NOTICE [$errno] PHP " . PHP_VERSION . " (" . PHP_OS . ")";     break;
  default:             $ret['message'][]="ERROR [$errno] PHP " . PHP_VERSION . " (" . PHP_OS . ")";             break;
 }
 
 $ret['message'][]="FILE $errfile";
 $ret['message'][]="\nError line $errline of ".basename($errfile)."\n";
 $ret['message'][]="$errstr\n";
 echo json_encode($ret);
 error_log(var_export($ret,true));
 exit(1);
 return true; /* Ne pas exécuter le gestionnaire interne de PHP */
}
$old_error_handler = set_error_handler("myErrorHandler");


//if($fd=fopen('toto.txt','a')){fwrite($fd,''.date('Y-m-d H:i:s'). ' ' . __LINE__ ."\r\n".'$_FILES='.var_export($_FILES,true)."\r\n".'$_POST='.var_export($_POST,true)."\r\n"); fclose($fd);}
if(isset($_POST)&&sizeof($_POST)>0&&isset($_POST['data'])){
 $ret=array('status' => 'KO','message' => array() );
 $ret['input']=json_decode($_POST['data'],true);
 if(isset($ret['input']['funct'])&&$ret['input']['funct']!=''){
  define('BNF' , 'ajax_'.$ret['input']['funct'].'.php' );
  require_once('za_inc.php');
  if(!is_file($GLOBALS['glob_incPath1'].'/ajax/ajax_'.$ret['input']['funct'].'.php')){
   $ret['status']='KO';
   $ret['message'][]='Ajax file not founded : "' . $GLOBALS['glob_incPath1'].'/ajax/ajax_'.$ret['input']['funct'].'.php"';
  }else{
   require_once $GLOBALS['glob_incPath1'].'/ajax/ajax_'.$ret['input']['funct'].'.php';
  }
 }else{
  $ret['status']='KO';
  $ret['message'][]='funct is not defined in the input parameters : "'.var_export($ret['input'],true).'"';
 }
}else{
 $ret['status']='KO';
 $ret['message'][]='post data is not defined : "'.var_export($_POST,true).'"'; 
}
header('Content-Type: application/json');
echo json_encode($ret,JSON_FORCE_OBJECT);
exit(0);
