<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
// if($fd=fopen('toto.txt','a')){fwrite($fd,''.date('Y-m-d H:i:s'). ' '.__FILE__.' ' . __LINE__ ."\r\n".'$ret='.var_export($ret,true)."\r\n"); fclose($fd);}
/*
$ret=array (
  'status' => 'KO',
  'message' => 
  array (
  ),
  'input' => 
  array (
    'funct' => 'fileNameChangeInGen1',
    'file_name' => 'actor2.php',
  ),
)
*/
 openDb1();
 $ret['message']=array();
 $forbidden='';
 
 require_once($GLOBALS['glob_incPath1'].'/__param_group_role.php');
 
 foreach($GLOBALS['param__group_role']['__values'] as $k1=>$v1){
   foreach($v1 as $k2=>$v2){
     if(!($v2['group_role']=='local_admin' || $v2['group_role']=='root' )){
       if($forbidden!='') $forbidden.=',';
       $forbidden.=$v2['group_role'];
     }
   }
   break; // une langue suffit
 }
 
 $ret['fld_id_pages']=0;
 $ret['fld_id_grpspgs']=0;
 $_POST['fld_group_id_grpspgs']=1;
 $isAction=0;
 $isMenu=0;
 if(strpos($ret['input']['file_name'],'_action')!==false){
  $isAction=1; 
 }else if(strpos($ret['input']['file_name'],'_choose')!==false){
 }else{
  $isMenu=1;  
 }
 if($ret['input']['fld_id_pages']==0){
  $ret['message'][]='input.fld_id_pages=0';
  $req9='UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` SET `fld_order_all_pages` = `fld_order_all_pages` + 1 ';
  $result9=mysqli_query($GLOBALS['glob_db'][0]['link'],$req9);
  $parentPageId=null;
  if($isAction){
   $fileNameList=substr($ret['input']['file_name'],0,-12).'1.php'; // xyz_action1.php
   $sql='SELECT T0.`fld_id_pages` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` T0     WHERE T0.`fld_name_pages` LIKE \'%'.addslashes($fileNameList).'%\'';
   $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    while($row=mysqli_fetch_row($req)){
     $parentPageId= $row[0];
    }
    mysqli_free_result($req);
   }
  }
  $req6='
   INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` SET
      `fld_name_pages`            = \''.addslashes($ret['input']['file_name']).'\'
    , `fld_menu_pages`            =   '.$isMenu .'
    , `fld_isajax_pages`          = 0
    , `fld_isremote_pages`        = 1
    , `fld_isuser_pages`          = 1
    , `fld_localadmin_pages`      = 1
    , `fld_isaction_pages`        =   '.$isAction .'
    , `fld_parent_pages`          = '.(is_null($parentPageId)?'NULL':$parentPageId).'
    , `fld_order_all_pages`       = 0
    , `fld_tsupd_pages`           = \''.$GLOBALS['glob_setdate'].'\'
    , `fld_tscrt_pages`           = \''.$GLOBALS['glob_setdate'].'\'
    , `fld_cntupd_pages`          = 0
    , `fld_forbidden_role_pages`  = \''.addslashes($forbidden).'\'
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    $NewCode=mysqli_fetch_row($resIns);
    $ret['fld_id_pages']=(int)$NewCode[0];
    mysqli_free_result($resIns);
   }
  }else{
   $ret['message'][]='insert KO $req6='.$req6;
  }
 }else{
  $ret['fld_id_pages']=$ret['input']['fld_id_pages'];
 }

 if($ret['fld_id_pages']>0){
  require_once $GLOBALS['glob_incPath1'].'/zz_inc_pages1.php';
  writePageList();
 }

 if($ret['fld_id_pages']>0 && $ret['input']['fld_id_grpspgs']==0){
  $req9='
   UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET `fld_menu_order_grpspgs` = `fld_menu_order_grpspgs` + 1 WHERE `fld_group_id_grpspgs` = 1
  ';
  $result9=mysqli_query($GLOBALS['glob_db'][0]['link'],$req9);
  $req8='
   INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET 
      `fld_is_menu_grpspgs`    = \''.$isMenu.'\' 
    , `fld_group_id_grpspgs`   = 1 
    , `fld_page_id_grpspgs`    = '.$ret['fld_id_pages'].'
    , `fld_menu_order_grpspgs` = 0
    , `fld_tscrt_grpspgs`   = \''.$GLOBALS['glob_setdate'].'\'
    , `fld_tsupd_grpspgs`   = \''.$GLOBALS['glob_setdate'].'\'
  ' ;
  $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    $NewCode=mysqli_fetch_row($resIns);
    $ret['fld_id_grpspgs']=(int)$NewCode[0];
    mysqli_free_result($resIns);
    $ret['status']='OK';
   }
  }
 }else{
  $ret['fld_id_grpspgs']=$ret['input']['fld_id_grpspgs'];
 }
 
 if($ret['fld_id_grpspgs']>0){
  include $GLOBALS['glob_incPath1'].'/zz_inc_grpspgs1.php';
  updateGrpPgsFiles1();
  sleep(1);
 }
 
 if($ret['fld_id_grpspgs']>0){
  if($isMenu==1){
   $menuName=str_replace('.php','',$ret['input']['file_name']);
   $req6="
    INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
      `fld_key_lngVals`     = '".addslashes1($ret['input']['file_name']) ."'
    , `fld_lang_lngVals`    = '".addslashes1($ret['input']['lang'])      ."'
    , `fld_page_id_lngVals` = NULL
    , `fld_type_lngVals`    = 'menu'
    , `fld_value_lngVals`   = '".addslashes1($menuName)                  ."'
    , `fld_tsupd_lngVals`   = '".$GLOBALS['glob_setdate']                ."'
    , `fld_tscrt_lngVals`   = '".$GLOBALS['glob_setdate']                ."'
   " ;
   $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  }
  foreach($GLOBALS['__pageList'] as $k1 => $v1){
   if($v1['fld_isajax_pages']!='1'){
    $ret['input']['page_id']=$v1['fld_id_pages'];
    $ret['input']['page']   =$v1['fld_name_pages'];
    $ret['input']['page_id']=$v1['fld_id_pages'];
    $ret['input']['page']=$v1['fld_name_pages'];
    include $GLOBALS['glob_incPath1'].'/ajax/ajax_writeTranslationFiles1.php';
   }
  } 
 }
 if($ret['fld_id_pages']>0){
  $ret['status']='OK';
 }else{
  $ret['status']='KO';
 }
 
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;   
}