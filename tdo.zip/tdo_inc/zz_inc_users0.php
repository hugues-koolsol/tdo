<?php
function getuser1($id){
 $nam=array();
 $n['fld_id_users']           =0;
 $n['fld_login_users']        ='';
 $n['fld_email_users']        ='';
 $n['fld_loginisemail_users'] =0;
 $n['fld_password_users']     ='';
 $n['fld_group_id_users']     =0;
 $n['fld_active_users']       =0;
 $n['fld_translate_users']    =0;
 $n['fld_firstname_users']    ='';
 $n['fld_lastname_users']     ='';
 $n['fld_comment_users']      =null;
 $n['fld_tsupd_users']        ='1000-01-01 00:00:00';
 $n['fld_tscrt_users']        ='1000-01-01 00:00:00';
 $n['fld_cntupd_users']       =0;
 $sql='
  SELECT 
   T0.`fld_id_users`           ,T0.`fld_login_users`        ,T0.`fld_email_users`        ,T0.`fld_loginisemail_users` ,T0.`fld_password_users`     ,
   T0.`fld_group_id_users`     ,T0.`fld_active_users`       ,T0.`fld_translate_users`    ,T0.`fld_firstname_users`    ,T0.`fld_lastname_users`     ,
   T0.`fld_comment_users`      ,T0.`fld_tsupd_users`        ,T0.`fld_tscrt_users`        ,T0.`fld_cntupd_users`       
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` T0
  WHERE T0.`fld_id_users` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['fld_id_users']           = $row[0];
   $n['fld_login_users']        = $row[1];
   $n['fld_email_users']        = $row[2];
   $n['fld_loginisemail_users'] = $row[3];
   $n['fld_password_users']     = $row[4];
   $n['fld_group_id_users']     = $row[5];
   $n['fld_active_users']       = $row[6];
   $n['fld_translate_users']    = $row[7];
   $n['fld_firstname_users']    = $row[8];
   $n['fld_lastname_users']     = $row[9];
   $n['fld_comment_users']      = $row[10];
   $n['fld_tsupd_users']        = $row[11];
   $n['fld_tscrt_users']        = $row[12];
   $n['fld_cntupd_users']       = $row[13];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
