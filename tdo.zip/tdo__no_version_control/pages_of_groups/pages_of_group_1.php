<?php
// group 1 : root,m:menu,o:order,aj:ajax
$GLOBALS['glob_grpspgs']=array (
  'zz_todos1.php' => 
  array (
    'm' => 1,
    'o' => 0,
    'aj' => 0,
    'id' => 13,
    'remote' => 1,
  ),
  'zz_zztests_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 83,
    'remote' => 0,
  ),
  'zz_tables1.php' => 
  array (
    'm' => 1,
    'o' => 1,
    'aj' => 0,
    'id' => 47,
    'remote' => 0,
  ),
  'zz_log_action1.php' => 
  array (
    'm' => 0,
    'o' => 1,
    'aj' => 0,
    'id' => 82,
    'remote' => 1,
  ),
  'zz_tablelinks1.php' => 
  array (
    'm' => 1,
    'o' => 2,
    'aj' => 0,
    'id' => 20,
    'remote' => 0,
  ),
  'zz_tables_choose1.php' => 
  array (
    'm' => 0,
    'o' => 3,
    'aj' => 0,
    'id' => 80,
    'remote' => 0,
  ),
  'zz_generateSources1.php' => 
  array (
    'm' => 1,
    'o' => 3,
    'aj' => 0,
    'id' => 21,
    'remote' => 0,
  ),
  'logout.php' => 
  array (
    'm' => 0,
    'o' => 4,
    'aj' => 0,
    'id' => 3,
    'remote' => 1,
  ),
  'zz_users_choose1.php' => 
  array (
    'm' => 0,
    'o' => 4,
    'aj' => 0,
    'id' => 79,
    'remote' => 1,
  ),
  'zz_pages.php' => 
  array (
    'm' => 1,
    'o' => 4,
    'aj' => 0,
    'id' => 9,
    'remote' => 0,
  ),
  'zz_groups1.php' => 
  array (
    'm' => 1,
    'o' => 5,
    'aj' => 0,
    'id' => 4,
    'remote' => 1,
  ),
  'zz_todos_action1.php' => 
  array (
    'm' => 0,
    'o' => 6,
    'aj' => 0,
    'id' => 14,
    'remote' => 1,
  ),
  'zz_grpspgs.php' => 
  array (
    'm' => 1,
    'o' => 6,
    'aj' => 0,
    'id' => 10,
    'remote' => 1,
  ),
  'zz_paramkeys.php' => 
  array (
    'm' => 1,
    'o' => 7,
    'aj' => 0,
    'id' => 17,
    'remote' => 1,
  ),
  'zz_translate.php' => 
  array (
    'm' => 1,
    'o' => 8,
    'aj' => 0,
    'id' => 16,
    'remote' => 1,
  ),
  'zz_users.php' => 
  array (
    'm' => 1,
    'o' => 9,
    'aj' => 0,
    'id' => 12,
    'remote' => 1,
  ),
  'zz_paramrules1.php' => 
  array (
    'm' => 1,
    'o' => 10,
    'aj' => 0,
    'id' => 68,
    'remote' => 0,
  ),
  'profile.php' => 
  array (
    'm' => 1,
    'o' => 11,
    'aj' => 0,
    'id' => 41,
    'remote' => 1,
  ),
  'zz_log1.php' => 
  array (
    'm' => 1,
    'o' => 12,
    'aj' => 0,
    'id' => 81,
    'remote' => 1,
  ),
  'zz_css1.php' => 
  array (
    'm' => 1,
    'o' => 13,
    'aj' => 0,
    'id' => 49,
    'remote' => 1,
  ),
  'uploadeddocs1.php' => 
  array (
    'm' => 1,
    'o' => 14,
    'aj' => 0,
    'id' => 65,
    'remote' => 1,
  ),
  'zz_zztests1.php' => 
  array (
    'm' => 1,
    'o' => 15,
    'aj' => 0,
    'id' => 23,
    'remote' => 0,
  ),
  'login.php' => 
  array (
    'm' => '1',
    'o' => '16',
    'aj' => '0',
    'id' => 2,
    'remote' => 1,
  ),
  'index.php' => 
  array (
    'm' => '1',
    'o' => '17',
    'aj' => '0',
    'id' => 1,
    'remote' => 1,
  ),
  'zz_synchro1.php' => 
  array (
    'm' => 1,
    'o' => 18,
    'aj' => 0,
    'id' => 43,
    'remote' => 0,
  ),
  'zz_restore1.php' => 
  array (
    'm' => 1,
    'o' => 19,
    'aj' => 0,
    'id' => 86,
    'remote' => 0,
  ),
);