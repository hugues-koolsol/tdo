<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
// if($fd=fopen('toto.txt','a')){fwrite($fd,''.date('Y-m-d H:i:s'). ' ' . __LINE__ ."\r\n".'$ret='.var_export($ret,true)."\r\n"); fclose($fd);}
/*
$ret=array (
  'status' => 'KO',
  'message' => 
  array (
  ),
  'input' => 
  array (
    'funct' => 'writeGeneratedFile1',
    'type' => 'inc',
    'file_name' => '_inc__tablelinks1.php',
    'file_source' => 'bla bla',
  ),
)
*/
// openDb2();
 $err=0;
 if($ret['input']['type']=='inc'){
  $path=$GLOBALS['glob_incPath1'].'/'.$ret['input']['file_name'];
  $pathTo=$GLOBALS['glob_incPath1'].'/'.'zzz_'.uniqid().'_'.$ret['input']['file_name'];
 }else{
  $path=$ret['input']['file_name'];  
  $pathTo='zzz_'.uniqid().'_'.$ret['input']['file_name'];  
 }
 @copy($path,$pathTo); // a little backup never hurt
 if($fd=fopen($path,'w')){
  fwrite($fd,$ret['input']['file_source']);
  fclose($fd);
  $ret['status']='OK';
  $ret['message']='file written '.$path;   
 }else{
  $ret['status']='KO';
  $ret['message']='Cannot open '.$path;   
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;   
}