<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 $fileOutput='';
 $someErrors=array();
 openDb2();
 $oneError=false;
 $ret['data']['keysOK']=array();
 $conn_id=ftp_connect($_SESSION[PGMK]['ftp__server'],21,3);
 if($conn_id==false){
  $ret['message'][]= __LINE__ .' : connexion KO to ' . $_SESSION[PGMK]['ftp__server'];
  $oneError=true;
 }else{
  if(ftp_login($conn_id, $_SESSION[PGMK]['ftp__user'], $_SESSION[PGMK]['ftp__password'])){ // Tentative d'identification
   if(ftp_pasv($conn_id, true)){
    $ret['message'][]= __LINE__ .' : ftp_pasv OK ' . $_SESSION[PGMK]['ftp__server'];
   }else{
    $ret['message'][]= __LINE__ .' : ftp_pasv KO ' . $_SESSION[PGMK]['ftp__server'] . '' ;
   }
   if(isset($ret['input']['directPut']) && $ret['input']['directPut']==true){
    

    $target_path='/'.$_SESSION[PGMK]['ftp__path'].'/'.$ret['input']['targetFile'];
    $local_path=$ret['input']['pathToPut'];
    
    
    if(strpos($ret['input']['targetFile'],'/')!==false){
     $remote_backup_fileName=substr($ret['input']['targetFile'],strrpos($ret['input']['targetFile'],'/')+1);
    }else{
     $remote_backup_fileName=$ret['input']['targetFile'];
    }
    $remote_backup_fileName='old-'.date('Y-m-d-H-i-s-').$remote_backup_fileName;
    $remote_backup_path='/'.$_SESSION[PGMK]['ftp__path'].'/tdo__no_version_control/zz_old_files/'.$remote_backup_fileName;
    
    
    // put a copy of the existing file in the xxx__no_version_control/zz_old_files
    $retRename=ftp_rename( 
     $conn_id            , 
     $target_path        , // distant existing
     $remote_backup_path   // new name
    );
    
    $retPut=@ftp_put( 
     $conn_id , 
     $target_path ,  // distant
     $local_path  ,  // local
     FTP_BINARY 
    );
    if(true!==$retPut){
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('warning').' '. __LINE__ .' : erreur de transfert ' . $_SESSION[PGMK]['ftp__server'];
     $oneError=true;
    }
    
   }else{
    require_once 'zzz_tmp_ftp_lstDifferentFileSize.php';
    foreach($ret['input']['lstIds'] as $k1 => $v1){
     if(false===$oneError){
      
      $theFile=$GLOBALS['__ftp_lstDifferentFileSize']['data'][$v1];
      
      $target_path='/'.$_SESSION[PGMK]['ftp__path'].'/'.$theFile['remote_path'];
      $local_path=$theFile['remote_path'];

      if(strpos($theFile['remote_path'],'/')!==false){
       $remote_backup_fileName=substr($theFile['remote_path'],strrpos($ret['input']['targetFile'],'/')+1);
      }else{
       $remote_backup_fileName=$theFile['remote_path'];
      }
      $remote_backup_fileName='old-'.date('Y-m-d-H-i-s-').$remote_backup_fileName;
      $remote_backup_path='/'.$_SESSION[PGMK]['ftp__path'].'/tdo__no_version_control/zz_old_files/'.$remote_backup_fileName;
      
      
      // put a copy of the existing file in the xxx__no_version_control/zz_old_files
      $retRename=ftp_rename( 
       $conn_id            , 
       $target_path        , // distant existing
       $remote_backup_path   // newName
      );
      
      
      
      $retPut=@ftp_put( 
       $conn_id , 
       $target_path , // distant
       $local_path  , // local 
       FTP_BINARY 
      );
      if(true!==$retPut){
       $ret['message'][]= __LINE__ .' : send file KO to ' . var_export( $theFile , true );
       $oneError=true;
      }else{
       $ret['data']['keysOK'][]=$v1;
      }
     }
    }    
   }
  }else{
   $ret['message'][]= __LINE__ .' : login ftp KO ';
   $err=1;
  }
  ftp_close($conn_id); // Fermeture de la connexion
 }
 
 

 if(false===$oneError){
  $ret['status']='OK';
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}