//=====================================================================================================================
function checkNullFieldInLinksBetweenTables1(par){
 console.log(par);
 if(par.tableId==0) return;
 document.getElementById(par.htmlfield).addEventListener('change' , 
  function(){   
   console.log(par);
   var r = new XMLHttpRequest();
   r.open("POST",'za_ajax.php?checkNullFieldInLinksBetweenTables1',true); // ajax_writeGeneratedFile2.php
   r.timeout=6000;
   r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
   r.onreadystatechange = function () {
    if (r.readyState != 4 || r.status != 200) return;
    try{
     var jsonRet=JSON.parse(r.responseText);
     if(jsonRet.status=='OK'){
      if(jsonRet.data.nullPossible=='YES'){
       document.getElementById('fld_link_mandatory_pglnks_1').checked=true;
      }else{
       document.getElementById('fld_link_mandatory_pglnks_0').checked=true;       
      }
      return;
     }else{
      console.log(r.responseText);
     }
    }catch(e){
     console.log(e);
    }
   };
   r.onerror=function(e){
    console.log('e=',e);
   }
   var data={
    funct          : 'checkNullFieldInLinksBetweenTables1',
    htmlfield      : par.htmlfield ,
    dbfield        : document.getElementById(par.htmlfield).value ,
    tableId        : par.tableId   ,
   }
   r.send('data='+encodeURIComponent(JSON.stringify(data)));
  }  
 );
}
//=====================================================================================================================
function fillLinkField1(optionadd,fieldName,inputId){
 var oldValue=document.getElementById(inputId).value;
 var element=document.getElementById(inputId);
 if(optionadd==0){
  element.value=fieldName
 }else{
  if(oldValue==''){
   element.value=fieldName
  }else{
   var newValue=oldValue+','+fieldName;
   element.value=newValue;
  }
 }
 if("createEvent" in document) {
  var evt = document.createEvent("HTMLEvents");
  evt.initEvent("change", false, true);
  element.dispatchEvent(evt);
 }else{
  element.fireEvent("onchange"); 
 }
}
//=====================================================================================================================
function insertThisPageInPagesAndGroup1(file_name,fld_id_pages,fld_id_grpspgs){
// console.log('in insertThisPageInPagesAndGroup1 pageName="' + file_name + ' ' + fld_id_pages + ' ' + fld_id_grpspgs ); 
 var r = new XMLHttpRequest();
 r.open("POST",'za_ajax.php?insertThisPageInPagesAndGroup1',true); // ajax_writeGeneratedFile2.php
 r.timeout=6000;
 r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
 r.onreadystatechange = function () {
  if (r.readyState != 4 || r.status != 200) return;
  try{
   var jsonRet=JSON.parse(r.responseText);
   if(jsonRet.status=='OK'){
    if((jsonRet.fld_id_pages!=0 &&jsonRet.fld_id_grpspgs!=0)){
     document.getElementById('insertThisPageInPagesAndGroup1').innerHTML='Good job !';
    }else{
     document.getElementById('insertThisPageInPagesAndGroup1').innerHTML='Bad job !';     
    }
    return;
   }else{
    console.log(r.responseText);
   }
  }catch(e){
   console.log(e);
  }
 };
 r.onerror=function(e){
  console.log('e=',e);
 }
 var data={
  funct          : 'insertThisPageInPagesAndGroup1',
  file_name      : file_name                   ,
  fld_id_pages   : parseInt(fld_id_pages,10)   ,
  fld_id_grpspgs : parseInt(fld_id_grpspgs,10) ,
  lang           : globLang                    ,
 }
 r.send('data='+encodeURIComponent(JSON.stringify(data)));
}
//=====================================================================================================================
function fileNameChangeInGen1(){
 if(document.getElementById('file_name')){
  var r = new XMLHttpRequest();
  r.open("POST",'za_ajax.php?fileNameChangeInGen1',true); // ajax_writeGeneratedFile2.php
  r.timeout=6000;
  r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
  r.onreadystatechange = function () {
   if (r.readyState != 4 || r.status != 200) return;
   try{
    var jsonRet=JSON.parse(r.responseText);
    if(jsonRet.status=='OK'){
     if(false || (jsonRet.fld_id_pages==0||jsonRet.fld_id_grpspgs==0)){
      document.getElementById('insertThisPageInPagesAndGroup1').innerHTML='<a href="javascript:insertThisPageInPagesAndGroup1(\''+document.getElementById('file_name').value+'\','+jsonRet.fld_id_pages+','+jsonRet.fld_id_grpspgs+')">Record this page</a>';
     }
     return;
    }else{
     console.log(r.responseText);
    }
   }catch(e){
    console.log(r.responseText,e);
   }
  };
  r.onerror=function(e){
   console.log('e=',e);
  }
  var data={
   funct        : 'fileNameChangeInGen1',
   file_name    : document.getElementById('file_name').value,
  }
  r.send('data='+encodeURIComponent(JSON.stringify(data)));
 }
 
}
//=====================================================================================================================
function writeGeneratedFile2(button){
 var r = new XMLHttpRequest();
 r.open("POST",'za_ajax.php?writeGeneratedFile2',true); // ajax_writeGeneratedFile2.php
 r.timeout=6000;
 r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
 r.onreadystatechange = function () {
  if (r.readyState != 4 || r.status != 200) return;
  try{
   var jsonRet=JSON.parse(r.responseText);
//    console.log(jsonRet);
   if(jsonRet.status=='OK'){
    setTimeout(fileNameChangeInGen1,100);
    alert('Done !');
    return;
   }else{
    console.log(r.responseText);
   }
  }catch(e){
   console.log(r.responseText);
  }
 };
 r.onerror=function(e){
  console.log('e=',e);
 }
 var data={
  funct        : 'writeGeneratedFile2',
  type         : document.getElementById('file_name').getAttribute('data-type'),
  file_name    : document.getElementById('file_name').value,
  file_source  : document.getElementById('file_source').value,
 }
 r.send('data='+encodeURIComponent(JSON.stringify(data)));
}
//=====================================================================================================================
function writeGeneratedFile1(button){
 var r = new XMLHttpRequest();
 r.open("POST",'za_ajax.php?writeGeneratedFile1',true); // ajax_writeGeneratedFile1.php
 r.timeout=6000;
 r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
 r.onreadystatechange = function () {
  if (r.readyState != 4 || r.status != 200) return;
  try{
   var jsonRet=JSON.parse(r.responseText);
   if(jsonRet.status=='OK'){
//     console.log(jsonRet);
    if(jsonRet.alreadyExist===true &&!confirm(txt1('Generated file already exists on disk\nClick ok to rewrite it.'))){
     return;
    }
    writeGeneratedFile2();
    return;
   }else{
    console.log(r.responseText);
   }
  }catch(e){
   console.log(r.responseText);
  }
 };
 r.onerror=function(e){
  console.log('e=',e);
 }
 var data={
  funct     : 'writeGeneratedFile1',
  type      : document.getElementById('file_name').getAttribute('data-type'),
  file_name : document.getElementById('file_name').value,
 }
 r.send('data='+encodeURIComponent(JSON.stringify(data)));
}
//=====================================================================================================================
function checkAll1(idGeneralCheck,baseElement,prefix){
// console.log(prefix,document.getElementById(idGeneralCheck).checked);
 var toCheck=document.getElementById(idGeneralCheck).checked;
 var lst=document.getElementById(baseElement).getElementsByTagName('input');
 for(var i=0;i<lst.length;i++){
  if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
   lst[i].checked=toCheck;
  }
 }
}
//=====================================================================================================================
function deleteFromSever1(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
   console.log(lstIds);
   var data={
    funct   : 'deleteFromServer1',
    lstIds  : lstIds,
   };
   ajaxCall({
    data    : data,
    url     : 'deleteFromServer1',
    retu    : afterDeleteFromServer1,
    timeout : 30000
   });
  }
 }
}
//=====================================================================================================================
function afterDeleteFromServer1(dataJson,objSend){
 if(dataJson.status && dataJson.status=='OK'){
  if(dataJson.data.keysOK){
   for(var elem in dataJson.data.keysOK){
    document.getElementById('checkDeleteFromServer_'+dataJson.data.keysOK[elem]).checked=false;
    document.getElementById(dataJson.data.keysOK[elem]).style.display='none';
   }
  }
 }else{
  console.log(dataJson,objSend);
 }
}
//=====================================================================================================================
function putToSever1(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
//   console.log(lstIds);
   var data={
    funct   : 'sendLocalFilesToServer1',
    lstIds  : lstIds,
   };
   console.log(data);
   
   ajaxCall({
    data    : data,
    url     : 'sendLocalFilesToServer1',
    retu    : afterSendLocalFilesToServer1,
    timeout : 30000
   });
   
  }
 }
}
//=====================================================================================================================
function afterSendLocalFilesToServer1(dataJson,objSend){
 if(dataJson.status && dataJson.status=='OK'){
  if(dataJson.data.keysOK){
   for(var elem in dataJson.data.keysOK){
    console.log(dataJson.data.keysOK[elem]);
    document.getElementById('checkPutToServer_'+dataJson.data.keysOK[elem]).checked=false;
    document.getElementById(dataJson.data.keysOK[elem]).style.display='none';
   }
  }
 }else{
  console.log(dataJson,objSend);
 }
}
//=====================================================================================================================
function putToSever2(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
   console.log(lstIds);
   var data={
    funct   : 'sendLocalFilesToServer2',
    lstIds  : lstIds,
   };
   ajaxCall({
    data    : data,
    url     : 'sendLocalFilesToServer2',
    retu    : afterSendLocalFilesToServer2,
    timeout : 30000
   });
  }
 }
}
//=====================================================================================================================
function afterSendLocalFilesToServer2(dataJson,objSend){
 if(dataJson.status && dataJson.status=='OK'){
  if(dataJson.data.keysOK){
   for(var elem in dataJson.data.keysOK){
    document.getElementById('checkPutToServer_'+dataJson.data.keysOK[elem]).checked=false;
    document.getElementById(dataJson.data.keysOK[elem]).style.display='none';
   }
  }else{
   console.log(dataJson,objSend);
  }
 }else{
  console.log(dataJson,objSend);
 }
}
//=====================================================================================================================
function putToSever3(baseElement,prefix){
 if(confirm('OK ?')){
  var lstIds=[];
  var lst=document.getElementById(baseElement).getElementsByTagName('input');
  for(var i=0;i<lst.length;i++){
   if(lst[i].type && lst[i].type.toLowerCase()=='checkbox' && lst[i].id && lst[i].id.substr(0,prefix.length)==prefix ){
    if(lst[i].checked){
     lstIds.push(lst[i].id.substr(prefix.length));
    }
   }
  }
  if(lstIds.length>0){
   console.log(lstIds);
   var data={
    funct     : 'sendLocalFilesToServer2',
    require   : 'zzz_tmp_ftp_lstSpecialFiles.php',
    keyGlobal : '__ftp_lstSpecialFiles',
    lstIds    : lstIds,
   };
   ajaxCall({
    data    : data,
    url     : 'sendLocalFilesToServer2',
    retu    : afterSendLocalFilesToServer2,
    timeout : 30000
   });
  }
 }
}
//=====================================================================================================================
//=====================================================================================================================
function localhostDoLocalPage(par){
// console.log('localhostDoLocalPage',par);
 for( var i=0;i<par.length;i++){
  if(par[i].localhost && par[i].localhost===true ){
   switch(par[i].jsName){

    case 'fileNameChangeInGen1'                : fileNameChangeInGen1()                      ; break;
    case 'checkNullFieldInLinksBetweenTables1' : checkNullFieldInLinksBetweenTables1(par[i]) ; break;
    
    default:
     console.log(par[i].jsName + ' not treated in localhostDoLocalPage' )
     break;
   }
  }
 }
}
//=====================================================================================================================