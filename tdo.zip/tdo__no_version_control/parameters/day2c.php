<?php
$GLOBALS['param__day2c']=array (
  'param__Name__Display' => 'n',
  'param__Name__Sort' => 'n',
  'param__Name__key' => 'day_code',
  'param__Key__type' => 'char',
  '__values' => 
  array (
    'fr' => 
    array (
      1 => 
      array (
        'day_code' => '1',
        'n' => 'Lu',
        'badge' => 'yybadge0',
        'rule' => '0',
        'fld_id_parvals' => '50',
        '__order' => 0,
      ),
      2 => 
      array (
        'day_code' => '2',
        'n' => 'Ma',
        'badge' => 'yybadge1',
        'rule' => '0',
        'fld_id_parvals' => '51',
        '__order' => 1,
      ),
      3 => 
      array (
        'day_code' => '3',
        'n' => 'Me',
        'badge' => 'yybadge2',
        'rule' => '0',
        'fld_id_parvals' => '52',
        '__order' => 2,
      ),
      4 => 
      array (
        'day_code' => '4',
        'n' => 'Je',
        'badge' => 'yybadge3',
        'rule' => '0',
        'fld_id_parvals' => '53',
        '__order' => 3,
      ),
      5 => 
      array (
        'day_code' => '5',
        'n' => 'Ve',
        'badge' => 'yybadge4',
        'rule' => '0',
        'fld_id_parvals' => '54',
        '__order' => 4,
      ),
      6 => 
      array (
        'day_code' => '6',
        'n' => 'Sa',
        'badge' => 'yybadge5',
        'rule' => '0',
        'fld_id_parvals' => '55',
        '__order' => 5,
      ),
      7 => 
      array (
        'day_code' => '7',
        'n' => 'Di',
        'badge' => 'yybadge6',
        'rule' => '0',
        'fld_id_parvals' => '56',
        '__order' => 6,
      ),
    ),
    'en' => 
    array (
      1 => 
      array (
        'day_code' => '1',
        'n' => 'Mo',
        'badge' => 'yybadge0',
        'rule' => '0',
        'fld_id_parvals' => '50',
        '__order' => 0,
      ),
      2 => 
      array (
        'day_code' => '2',
        'n' => 'Tu',
        'badge' => 'yybadge1',
        'rule' => '0',
        'fld_id_parvals' => '51',
        '__order' => 1,
      ),
      3 => 
      array (
        'day_code' => '3',
        'n' => 'We',
        'badge' => 'yybadge2',
        'rule' => '0',
        'fld_id_parvals' => '52',
        '__order' => 2,
      ),
      4 => 
      array (
        'day_code' => '4',
        'n' => 'Th',
        'badge' => 'yybadge3',
        'rule' => '0',
        'fld_id_parvals' => '53',
        '__order' => 3,
      ),
      5 => 
      array (
        'day_code' => '5',
        'n' => 'Fr',
        'badge' => 'yybadge4',
        'rule' => '0',
        'fld_id_parvals' => '54',
        '__order' => 4,
      ),
      6 => 
      array (
        'day_code' => '6',
        'n' => 'Sa',
        'badge' => 'yybadge5',
        'rule' => '0',
        'fld_id_parvals' => '55',
        '__order' => 5,
      ),
      7 => 
      array (
        'day_code' => '7',
        'n' => 'Su',
        'badge' => 'yybadge6',
        'rule' => '0',
        'fld_id_parvals' => '56',
        '__order' => 6,
      ),
    ),
  ),
  'param__definition' => 
  array (
    'comment' => 'Iso day number: 1,2,3,4,5,6,7',
    'key' => 'day_code',
    'fields' => 
    array (
      0 => 
      array (
        'name' => 'day_code',
        'type' => 'char',
        'length' => 1,
        'comment' => '1,2,3,4,5,6,7',
      ),
      1 => 
      array (
        'name' => 'n',
        'type' => 'char',
        'length' => 2,
        'languageTranslation' => true,
        'comment1' => 'the language name',
      ),
    ),
    'id' => '3',
  ),
);