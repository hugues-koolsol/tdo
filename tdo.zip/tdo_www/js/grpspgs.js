//=====================================================================================================================
function onSortPagesOfGroups0(par){
// console.log('in sortable1 par=',par);
 var lstb1=document.getElementsByTagName('body')[0].getElementsByTagName('script');
 var founded=false;
 for(var i=0;i<lstb1.length;i++){
  if(lstb1[i].src && lstb1[i].src=='Sortable.min.js'){
   founded=true;
   break;
  }
 }
 if(founded){
  Sortable.create(document.getElementById(par.data.id),{onSort:function(e){onSortPagesOfGroups1();}});
 }else{
  var scriptId=document.createElement('script');
  scriptId.id='Sortable';
  scriptId.src='js/Sortable.min.js';
  scriptId.type='text/javascript';
  scriptId.onload=function(){
   Sortable.create(document.getElementById(par.data.id),{onSort:function(e){onSortPagesOfGroups1();}});
  }
  document.getElementsByTagName('body')[0].appendChild(scriptId);
 }
 
}
//=====================================================================================================================
function onSortPagesOfGroups1(){
// console.log('onSortPagesOfGroups1');
 var listeDesElementsTries=[];
 var list=document.getElementById('MyList1').getElementsByTagName('li');
 for(var i=0;i<list.length;i++){
  if(list[i].className.indexOf('sortable')>=0){
   listeDesElementsTries.push(list[i].id);
  }
 }
 if(listeDesElementsTries.length>1){
  var data={
   funct:'setSortPagesOfGroup1',
   sortListGroupId:document.getElementById('sortListGroupId').value,
   order:listeDesElementsTries,
  };
  ajaxCall({
   data  : data,
   url   : 'setSortPagesOfGroup1',
   retu  : afterSetSortPagesOfGroup2
  });
 }
}
//=====================================================================================================================
function afterSetSortPagesOfGroup2(dataJson,objSend){
 if(dataJson.status && dataJson.status=='OK'){
  document.location=String(document.location);
 }
}