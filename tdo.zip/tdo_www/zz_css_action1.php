<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
require_once $GLOBALS['glob_incPath1'].'/zz_inc_css1.php';

//========================================================================================================================
if(isset($_GET['setCss']) && is_numeric($_GET['setCss'])){
 include($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/__css.php');
 if(!isset($__css[$_GET['setCss']])){
  $_COOKIE[PGMK.'cssvalue']=1;
  setcookie ( PGMK.'cssvalue' , $_COOKIE[PGMK.'cssvalue'] , time()+3600*24*365);
 }else{
  $_COOKIE[PGMK.'cssvalue']=$_GET['setCss'];
  setcookie ( PGMK.'cssvalue' , $_GET['setCss'] , time()+3600*24*365 );  
 }
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( '?a=b'.urldecode($_GET['redir']) , true ) . '</pre>' ; exit(0);
 header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_GET['setCss']);
 exit(); 
}


$cssList= array(
 'main' => array(
  'mainBackgroundColor' => array(
   'type' => 'color',
   'hexValue' => 'FFEFD5',
   'webName'  => 'papayawhip'
  ),
  'mainBackgroundColEnd' => array(
   'type' => 'color',
   'hexValue' => 'FFEFD5',
   'webName'  => 'papayawhip',
   'hr_after' => true ,
  ),
  'mainTextColor' => array(
   'type' => 'color',
   'hexValue' => '444444',
   'hr_after' => false ,
  ),
  'thinBorderColor' => array(
   'type' => 'color',
   'hexValue' => 'EEEEEE',
   'hr_after' => true ,
  ),
  'linkStartBackgroundColor' => array(
   'type' => 'color',
   'hexValue' => 'FFFFFF',
  ),
  'linkEndBackground' => array(
   'type' => 'color',
   'hexValue' => 'FFFFFF',
   'hr_after' => true ,
  ),
  'linkUnsetTextColor' => array(
   'type' => 'color',
   'hexValue' => '444444',
   'hr_after' => true ,
  ),
  'activeFilterBackground' => array(
   'type' => 'color',
   'hexValue' => 'ffff00', // yellow
   'hr_after' => false ,
  ),
  'activeFilterColor' => array(
   'type' => 'color',
   'hexValue' => '444444',
   'hr_after' => true ,
  ),
  'inputBorderWidth' => array(
   'type' => 'SomeValues',
   'valueList' => '1px,2px,3px',
   'value'     => '2px',
   'hr_after' => false ,
  ),
 ),
 'menu' => array(
  'topColor' => array(
   'type' => 'color',
   'hexValue' => '0088cc',
  ),
  'bottomColor' => array(
   'type' => 'color',
   'hexValue' => '0044cc',
   'hr_after' => true ,
  ),
  'textColor' => array(
   'type' => 'color',
   'hexValue' => 'FFFFFF',
   'hr_after' => true ,
  ),
  'borderColor' => array(
   'type' => 'color',
   'hexValue' => '0072cc',
  ),
  'activeBackgroundColor' => array(
   'type' => 'color',
   'hexValue' => '0072cc',
  ),
 ),
 'table' => array(
  'headerBackgroundColor' => array(
   'type' => 'color',
   'hexValue' => 'EFEFEF',
  ),
  'headerTextColor' => array(
   'type' => 'color',
   'hexValue' => '666666',
  ),
  'linkTextColor' => array(
   'type' => 'color',
   'hexValue' => '0000FF',
   'hr_after' => true ,
  ),
  'nthchildBackgroundColor' => array(
   'type' => 'color',
   'hexValue' => 'FFEFD5',
   'hr_after' => true ,
  ),
 ),
 'backgrounds' => array(
  'dangerBackground'  => array( 'type' => 'color',  'hexValue' => 'FF0000',  ),'danger2Background'  => array( 'type' => 'color',  'hexValue' => 'FF0000',  ),'dangerText'  => array( 'type' => 'color',  'hexValue' => 'D87093', 'hr_after' => true , ),
  'editBackground'    => array( 'type' => 'color',  'hexValue' => '0000FF',  ),'edit2Background'    => array( 'type' => 'color',  'hexValue' => '0000FF',  ),'editText'    => array( 'type' => 'color',  'hexValue' => 'FFFFFF', 'hr_after' => true , ),
  'successBackground' => array( 'type' => 'color',  'hexValue' => '8BC34A',  ),'success2Background' => array( 'type' => 'color',  'hexValue' => '8BC34A',  ),'successText' => array( 'type' => 'color',  'hexValue' => '556B2F', 'hr_after' => true , ),
  'errorBackground'   => array( 'type' => 'color',  'hexValue' => 'FD3131',  ),'error2Background'   => array( 'type' => 'color',  'hexValue' => 'FD3131',  ),'errorText'   => array( 'type' => 'color',  'hexValue' => '540000', 'hr_after' => true , ),
  'warningBackground' => array( 'type' => 'color',  'hexValue' => 'FFA500',  ),'warning2Background' => array( 'type' => 'color',  'hexValue' => 'FFA500',  ),'warningText' => array( 'type' => 'color',  'hexValue' => '000000', 'hr_after' => true , ),
 ),
 'badge' => array(
  'badge0Background' => array( 'type' => 'color',  'hexValue' => 'FF0000',  ),  'badge0TextColor' => array(  'type' => 'color',  'hexValue' => '000000',  'hr_after' => true ),
  'badge1Background' => array( 'type' => 'color',  'hexValue' => 'FF0000',  ),  'badge1TextColor' => array(  'type' => 'color',  'hexValue' => '000000',  'hr_after' => true ),
  'badge2Background' => array( 'type' => 'color',  'hexValue' => 'FFFF00',  ),  'badge2TextColor' => array(  'type' => 'color',  'hexValue' => '0000FF',  'hr_after' => true ),
  'badge3Background' => array( 'type' => 'color',  'hexValue' => 'FF00FF',  ),  'badge3TextColor' => array(  'type' => 'color',  'hexValue' => 'FFFF00',  'hr_after' => true ),
  'badge4Background' => array( 'type' => 'color',  'hexValue' => '00FFFF',  ),  'badge4TextColor' => array(  'type' => 'color',  'hexValue' => '0000FF',  'hr_after' => true ),
  'badge5Background' => array( 'type' => 'color',  'hexValue' => '4CAF50',  ),  'badge5TextColor' => array(  'type' => 'color',  'hexValue' => 'FFEB3B',  'hr_after' => true ),
  'badge6Background' => array( 'type' => 'color',  'hexValue' => 'FFEBEE',  ),  'badge6TextColor' => array(  'type' => 'color',  'hexValue' => 'C62828',  'hr_after' => true ),
  'badge7Background' => array( 'type' => 'color',  'hexValue' => '1E88E5',  ),  'badge7TextColor' => array(  'type' => 'color',  'hexValue' => 'E3F2FD',  'hr_after' => true ),
  'badge8Background' => array( 'type' => 'color',  'hexValue' => 'FFE082',  ),  'badge8TextColor' => array(  'type' => 'color',  'hexValue' => 'F06292',  'hr_after' => true ),
 ),
 'other' => array(
  'autocompleteInput' => array(
   'type'  => 'yorno',
   'value' => '0',
  ),
 ),
);
$GLOBALS['bodyPaddingTop']=55; // px
$GLOBALS['footerHeight']=20; // px
openDb1();
function setCssText($cssl1){
 
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $cssl1 , true ) . '</pre>' ; exit(0); // inputBorderWidth
 
 $cssGenere1='';
 $cssGenere1.='@-ms-viewport {width: device-width;}html{box-sizing: border-box;background:linear-gradient(to bottom, #'.$cssl1['main']['mainBackgroundColor']['hexValue'].' 0%, #'.$cssl1['main']['mainBackgroundColEnd']['hexValue'].' 100%);min-height:100%;}*,*::before,*::after {box-sizing: inherit;font-weight:500;}'.CRLF;
 $cssGenere1.='body{margin:0;border:0;padding:0;overflow-y:scroll;'.CRLF;
 $cssGenere1.=' font-family:verdana;'.CRLF;
 $cssGenere1.=' font-size:14px;'.CRLF;
 $cssGenere1.=' color:#'.$cssl1['main']['mainTextColor']['hexValue'].';'.CRLF;
 $cssGenere1.=' padding-top:'.$GLOBALS['bodyPaddingTop'].'px;'.CRLF;
 $cssGenere1.=' padding-bottom:'.$GLOBALS['footerHeight'].'px; /* space for footer */'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='*{scrollbar-color: #'.$cssl1['menu']['topColor']['hexValue'].' #'.$cssl1['menu']['bottomColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='*::-webkit-scrollbar {width: 1.2em;background:#'.$cssl1['menu']['bottomColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='*::-webkit-scrollbar-thumb {background-color: #'.$cssl1['menu']['topColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='*::-webkit-scrollbar-corner{background-color: #'.$cssl1['main']['mainBackgroundColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='*::-webkit-resizer{background-color: #'.$cssl1['main']['mainBackgroundColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='@media print {a[href]:after {content: none !important;}@page {size: auto;margin-bottom: 0;}}'.CRLF;
 $cssGenere1.='h1,h2,h3,h4,h5,h6{margin-left:5px;}'.CRLF;
 $cssGenere1.='pre{overflow:scroll;word-break: break-all;white-space: pre-line;margin:0 0 0 0;}'.CRLF;
 $cssGenere1.='a{color:#'.$cssl1['main']['mainTextColor']['hexValue'].';}'.CRLF; // linkTextColor
 $cssGenere1.='#mainContent{margin-left:8px;margin-right:8px;width:auto;margin:0 auto;}'.CRLF; 
 
 $cssGenere1.='select{border:'.$cssl1['main']['inputBorderWidth']['value'].' inset #'.$cssl1['main']['thinBorderColor']['hexValue'].';padding:4px;border-radius:3px;background-color:#'.$cssl1['main']['mainBackgroundColor']['hexValue'].';color:#'.$cssl1['main']['mainTextColor']['hexValue'].'}'.CRLF;
 $cssGenere1.='input{border:'.$cssl1['main']['inputBorderWidth']['value'].' inset #'.$cssl1['main']['thinBorderColor']['hexValue'].';padding:5px;border-radius:4px;font-family:verdana;font-size:1em;background-color:#'.$cssl1['main']['mainBackgroundColor']['hexValue'].';color:#'.$cssl1['main']['mainTextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='textarea{width:100%;padding:5px;border-radius:4px;border:'.$cssl1['main']['inputBorderWidth']['value'].' inset #'.$cssl1['main']['thinBorderColor']['hexValue'].';background-color:#'.$cssl1['main']['mainBackgroundColor']['hexValue'].';color:#'.$cssl1['main']['mainTextColor']['hexValue'].';font-size:1em;font-family:verdana;line-height:1.5em;}'.CRLF;
 $cssGenere1.='input[type="radio"],input[type="checkbox"]{zoom:1.3;}'.CRLF; // 2px
 
 $cssGenere1.='.yynavbar{position:fixed;top:0;width:100%;z-index:1000;'.CRLF;
 $cssGenere1.=' height:'.$GLOBALS['bodyPaddingTop'].'px; '.CRLF;
 $cssGenere1.=' background:#'.$cssl1['main']['mainBackgroundColor']['hexValue'].';'.CRLF;
 $cssGenere1.=' background-image: linear-gradient(to bottom, #'.$cssl1['menu']['topColor']['hexValue'].', #'.$cssl1['menu']['bottomColor']['hexValue'].');'.CRLF;
 $cssGenere1.=' box-shadow: 0px 2px 5px #'.$cssl1['menu']['topColor']['hexValue'].';'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='#menuScroller{ display:flex;overflow-x:scroll;overflow-y:hidden;height:'.$GLOBALS['bodyPaddingTop'].'px;}'.CRLF;
 $cssGenere1.='#menuScroller div{margin:3px auto auto auto;}'.CRLF;
 $cssGenere1.='#menuScroller li{display:flex;}'.CRLF;
 $cssGenere1.='.yynavbar ul{display:flex;list-style:none;padding:0;margin:0;}'.CRLF;
 $cssGenere1.='.yynavbar li{margin-left:10px;}'.CRLF;
 $cssGenere1.='#menuScroller select{max-width: 10em;color:#'.$cssl1['menu']['textColor']['hexValue'].';background:#'.$cssl1['menu']['bottomColor']['hexValue'].';';
 $cssGenere1.=' background-image: linear-gradient(to bottom, #'.$cssl1['menu']['topColor']['hexValue'].', #'.$cssl1['menu']['bottomColor']['hexValue'].');font-size:1.05em;'.CRLF;
 $cssGenere1.=' border: 1px #'.$cssl1['menu']['borderColor']['hexValue'].' solid;'.CRLF;
 $cssGenere1.=' max-height : 28px;'.CRLF;
 $cssGenere1.=' margin-right : 8px;'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='#menuScroller select option{font-size:1.1em;padding:8px 2px;}'.CRLF;
 $cssGenere1.='#menuScroller a{white-space: nowrap;'.CRLF;
 $cssGenere1.=' background:linear-gradient(to bottom, #'.$cssl1['menu']['topColor']['hexValue'].', #'.$cssl1['menu']['bottomColor']['hexValue'].');'.CRLF;
 $cssGenere1.=' color:#'.$cssl1['menu']['textColor']['hexValue'].';'.CRLF;
 $cssGenere1.=' padding:0px 3px 0px 3px;min-height: 20px;line-height: 20px;border: 1px #'.$cssl1['menu']['borderColor']['hexValue'].' solid;'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.yymenusel1{ border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' inset;background:#'.$cssl1['menu']['activeBackgroundColor']['hexValue'].'!important;}'.CRLF; 
 $cssGenere1.='form{border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;}'.CRLF;
 $cssGenere1.='.yythinBorder{border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;}'.CRLF;
 $cssGenere1.='.yyformDelete{text-align:center;padding:8px;margin:8px;line-height: 2em;}'.CRLF;
 $cssGenere1.='.yyfilterForm{display:flex;flex-wrap:wrap;} .yyfilterForm div{display:flex;flex-direction:column;flex-wrap:wrap;margin-right:5px;}.yyfilterForm label{padding:3px;}'.CRLF;
 $cssGenere1.='button,.yybtn, a{display:inline-block;text-decoration:none;text-align:center;border-radius:5px; font-size:1em;font-family:inherit;color:inherit;cursor:pointer;'.CRLF;
 $cssGenere1.=' min-width: 40px;'.CRLF;
 $cssGenere1.=' min-height: 30px;'.CRLF;
 $cssGenere1.=' line-height: 30px;'.CRLF;
 $cssGenere1.=' padding: 3px!important;'.CRLF;
 $cssGenere1.=' background-color:#'.$cssl1['main']['mainBackgroundColor']['hexValue'].';'.CRLF;
 $cssGenere1.=' border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;'.CRLF; 
 $cssGenere1.=' background: linear-gradient(to bottom, #'.$cssl1['main']['linkStartBackgroundColor']['hexValue'].', #'.$cssl1['main']['linkEndBackground']['hexValue'].');'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.yytxtSiz1{font-size:1.5em;}.yytxtSiz2{font-size:2.5em;line-height:0.75em;}.yyflex1{display:flex;}.yyright1{float:right;}'.CRLF;
 $cssGenere1.='.yyminHeight1{min-height:36px;}'.CRLF; // 30px of btn + 3*3px of padding
 
 $cssGenere1.='.yytableResult1{border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;}'.CRLF;
 $cssGenere1.='.yytableResult1 a{border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;color:#'.$cssl1['main']['mainTextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.button_search{flex-grow:1;}'.CRLF;
 $cssGenere1.='.yyunset{border:1px #'.$cssl1['main']['mainBackgroundColor']['hexValue'].' solid!important;user-select: none;color:#'.$cssl1['main']['linkUnsetTextColor']['hexValue'].';opacity:0.5;}'.CRLF;
 $cssGenere1.='thead tr{background-color:#'.$cssl1['table']['headerBackgroundColor']['hexValue'].';color:#'.$cssl1['table']['headerTextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='thead th{padding:8px 3px;}'.CRLF;
// $cssGenere1.='.yynotActive{pointer-events: none;cursor: default;}'.CRLF;
 $cssGenere1.='tbody tr:nth-child(2n){background-color:#'.$cssl1['table']['nthchildBackgroundColor']['hexValue'].';}'.CRLF;
 
 $cssGenere1.='.yybackgroundYellow{background-color:#'.$cssl1['main']['activeFilterBackground']['hexValue'].';color:#'.$cssl1['main']['activeFilterColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.yymessageBox{padding:10px;border-radius:5px;}'.CRLF.CRLF;
 
 $cssGenere1.='.yynormal {background-color:background: linear-gradient(to bottom, #'.$cssl1['main']['linkStartBackgroundColor']['hexValue'].', #'.$cssl1['main']['linkEndBackground']['hexValue'].');}'.CRLF;
 $cssGenere1.='.yysuccess{color:#'.$cssl1['backgrounds']['successText']['hexValue'] .'!important;background:linear-gradient(to bottom, #'.$cssl1['backgrounds']['successBackground']['hexValue']  .', #'.$cssl1['backgrounds']['success2Background']['hexValue'] .')!important;}'.CRLF;
 $cssGenere1.='.yyedit   {color:#'.$cssl1['backgrounds']['editText']['hexValue']    .'!important;background:linear-gradient(to bottom, #'.$cssl1['backgrounds']['editBackground']['hexValue']     .', #'.$cssl1['backgrounds']['edit2Background']['hexValue']    .')!important;}'.CRLF;
 $cssGenere1.='.yywarning{color:#'.$cssl1['backgrounds']['warningText']['hexValue'] .'!important;background:linear-gradient(to bottom, #'.$cssl1['backgrounds']['warningBackground']['hexValue']  .', #'.$cssl1['backgrounds']['warning2Background']['hexValue'] .')!important;}'.CRLF;
 $cssGenere1.='.yydanger {color:#'.$cssl1['backgrounds']['dangerText']['hexValue']  .'!important;background:linear-gradient(to bottom, #'.$cssl1['backgrounds']['dangerBackground']['hexValue']   .', #'.$cssl1['backgrounds']['danger2Background']['hexValue']  .')!important;}'.CRLF;
 $cssGenere1.='.yyerror  {color:#'.$cssl1['backgrounds']['errorText']['hexValue']   .'!important;background:linear-gradient(to bottom, #'.$cssl1['backgrounds']['errorBackground']['hexValue']    .', #'.$cssl1['backgrounds']['error2Background']['hexValue']   .')!important;}'.CRLF;
 
 
 $cssGenere1.='.yybadge{border:1px outset;padding:3px;border-radius:6px;vertical-align: -webkit-baseline-middle;vertical-align: -moz-baseline-middle;vertical-align:baseline-middle;white-space:nowrap;display:inline-block;}'.CRLF;
 $cssGenere1.='.yybadge0{background-color:#'.$cssl1['badge']['badge0Background']['hexValue'].';color:#'.$cssl1['badge']['badge0TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.yybadge1{background-color:#'.$cssl1['badge']['badge1Background']['hexValue'].';color:#'.$cssl1['badge']['badge1TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.yybadge2{background-color:#'.$cssl1['badge']['badge2Background']['hexValue'].';color:#'.$cssl1['badge']['badge2TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.yybadge3{background-color:#'.$cssl1['badge']['badge3Background']['hexValue'].';color:#'.$cssl1['badge']['badge3TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.yybadge4{background-color:#'.$cssl1['badge']['badge4Background']['hexValue'].';color:#'.$cssl1['badge']['badge4TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.yybadge5{background-color:#'.$cssl1['badge']['badge5Background']['hexValue'].';color:#'.$cssl1['badge']['badge5TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.yybadge6{background-color:#'.$cssl1['badge']['badge6Background']['hexValue'].';color:#'.$cssl1['badge']['badge6TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.yybadge7{background-color:#'.$cssl1['badge']['badge7Background']['hexValue'].';color:#'.$cssl1['badge']['badge7TextColor']['hexValue'].';}'.CRLF;
 $cssGenere1.='.yybadge8{background-color:#'.$cssl1['badge']['badge8Background']['hexValue'].';color:#'.$cssl1['badge']['badge8TextColor']['hexValue'].';}'.CRLF;
 
 $cssGenere1.='/* forms for create update */ '.CRLF;
 $cssGenere1.='.yyfdiv1{display: flex;flex-direction: row;flex-wrap: wrap;align-items: stretch;justify-content: flex-start;margin-bottom: 8px;}'.CRLF;
 $cssGenere1.='.yyflab1{border-bottom: 1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid;border-left: 1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid;border-top: 1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid;border-right: 0px red solid;flex-grow: 0;flex-shrink: 0;flex-basis: 120px;max-width: 120px;text-align: center;font-weight: bold;display: flex;flex-direction: column;align-items: stretch;}'.CRLF;
 $cssGenere1.='@media all and (min-width: 550px){'.CRLF;
 $cssGenere1.=' .yyflab1 {flex-grow: 0;flex-shrink: 0;flex-basis: 180px;max-width: 180px;}'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='@media all and (max-width: 384px) {'.CRLF;
 $cssGenere1.=' .yyflab1{flex-grow: 1;flex-shrink: 1;flex-basis: 100%;max-width: 100%;border-bottom-style: none;margin-top: 8px;border-right: 1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid;min-height:30px;}'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.yyflab1 div{margin: auto;font-weight:bold;}'.CRLF;
 $cssGenere1.='.yyfinp1{border: 1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid;flex-grow: 1;flex-shrink: 0;flex-basis: 200px;padding: 3px;flex-direction: column;}'.CRLF;
 $cssGenere1.='.yyfinp1 div{margin: auto 2px;}'.CRLF;
 $cssGenere1.=''.CRLF;
 $cssGenere1.='.yyfooter {position:fixed;bottom:0;height:'.$GLOBALS['footerHeight'].'px;text-align:right;width:100%;background-image: linear-gradient(to bottom, #'.$cssl1['menu']['topColor']['hexValue'].', #'.$cssl1['menu']['bottomColor']['hexValue'].');'.CRLF;
 $cssGenere1.=' box-shadow: 0px -2px 3px #'.$cssl1['menu']['bottomColor']['hexValue'].';'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.yyfooter a{padding:0 5px!important;line-height: '.$GLOBALS['footerHeight'].'px;border-radius: 0;font-family: inherit;color:#'.$cssl1['main']['mainTextColor']['hexValue'].';border-radius:3px;}'.CRLF;
 $cssGenere1.='/*======================================= tree =============================*/'.CRLF;
 $cssGenere1.='.class_treediv1{'.CRLF;
 $cssGenere1.=' border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;'.CRLF;
 $cssGenere1.=' height:40px;'.CRLF;
 $cssGenere1.=' overflow:hidden;'.CRLF;
 $cssGenere1.=' display : flex; '.CRLF;
 $cssGenere1.=' flex-direction: row;'.CRLF;
 $cssGenere1.=' justify-content: space-between; '.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.class_treeIntervalldiv2{border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' solid;}'.CRLF;
 $cssGenere1.='.class_treeTextContentdiv3{text-align:left;flex-grow:1;}'.CRLF;
 $cssGenere1.='.class_treedivFolder1{border:0px lime solid;}'.CRLF;
 $cssGenere1.='.class_treeFold1,.class_treeDelet1{'.CRLF;
 $cssGenere1.=' display:inline-block;'.CRLF;
 $cssGenere1.=' float:left;'.CRLF;
 $cssGenere1.=' height:30px;'.CRLF;
 $cssGenere1.=' width:30px;'.CRLF;
 $cssGenere1.=' min-width:30px;'.CRLF;
 $cssGenere1.=' border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;'.CRLF;
 $cssGenere1.=' text-align: center;'.CRLF;
 $cssGenere1.=' text-decoration: none;'.CRLF;
 $cssGenere1.=' font-size: 2em;'.CRLF;
 $cssGenere1.=' line-height: 1.1em;'.CRLF;
 $cssGenere1.=' border-radius:5px;'.CRLF;
 $cssGenere1.=' color:black;'.CRLF;
 $cssGenere1.=' font-weight:bold;'.CRLF;
 $cssGenere1.=' cursor:pointer;'.CRLF;
 $cssGenere1.=' font-family:monospace;'.CRLF;
 $cssGenere1.='}'.CRLF;
 $cssGenere1.='.class_treeHandle1{'.CRLF;
 $cssGenere1.=' border:1px #'.$cssl1['main']['thinBorderColor']['hexValue'].' outset;'.CRLF;
 $cssGenere1.=' display:inline-block;'.CRLF;
 $cssGenere1.=' float:right;'.CRLF;
 $cssGenere1.=' height:30px;'.CRLF;
 $cssGenere1.=' width:30px;'.CRLF;
 $cssGenere1.=' min-width:45px;'.CRLF;
 $cssGenere1.=' text-align: center;'.CRLF;
 $cssGenere1.=' text-decoration: none;'.CRLF;
 $cssGenere1.=' font-size: 1.5em;'.CRLF;
 $cssGenere1.=' line-height: 1.6em;'.CRLF;
 $cssGenere1.=' border-radius:5px;'.CRLF;
 $cssGenere1.=' font-family:monospace;'.CRLF;
 $cssGenere1.=' cursor:pointer;'.CRLF;
 $cssGenere1.='}'.CRLF;
 return $cssGenere1;
}
//========================================================================================================================
function btl1(){
 return '&nbsp;<a href="zz_css1.php">'.txtsys1('back_to_the_list').'</a>';
}
//========================================================================================================================
function test_input_tdo_cssKO1(){
 $err=0;
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_name_css']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_name_css must not be empty_205_92');
  $err=1;
 }
 return($err);
}



if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= POST ACTIONS  =====================================================================
 //=================================================================================================================================
 //=================================================================================================================================
// echo __LINE__ . '$_POST=<pre>' . var_export($_POST,true) . '</pre>'; exit();
 $_SESSION[PGMK][NAV][BNF]['fld_name_css']       =isset($_POST['fld_name_css'])       ?$_POST['fld_name_css']       : '';
 $_SESSION[PGMK][NAV][BNF]['fld_active_css']     =isset($_POST['fld_active_css'])     ?$_POST['fld_active_css']     : 0;
 
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
 
 foreach($cssList as $k1 => $v1){
  foreach($v1 as $k2 => $v2){
   if(isset($_POST[$k2])){
    if($cssList[$k1][$k2]['type']=='color'){ // $cssList[$k1][$k2]
     $cssList[$k1][$k2]=json_decode($_POST[$k2],true);
    }else if($cssList[$k1][$k2]['type']=='SomeValues'){ // inputBorderWidth
     $cssList[$k1][$k2]['value']=$_POST[$k2];
    }else if($cssList[$k1][$k2]['type']=='yorno'){
     $cssList[$k1][$k2]['value']=$_POST[$k2];     
    }
   }
  }
 }
 
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $cssList , true ) . '</pre>' ; exit(0);
 
 $_SESSION[PGMK][NAV][BNF]['fld_json_css']       =json_encode($cssList);
 //=================================================================================================================================
 //============================================= POST UPDATE =======================================================================
 //=================================================================================================================================
 if(isset($_POST['a'])&&$_POST['a']=='u'){ // update action
  if(test_input_tdo_cssKO1()){
   if(isset($_POST['id1'])&&is_numeric($_POST['id1'])){
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }else{
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : POST id1 = ' . $_POST['id1'];
    header("HTTP/1.1 303 See Other");header('Location: index.php');
    exit();
   }
  }
  $req6="UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__css` SET
      `fld_name_css`       = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_name_css'])       ."'
    , `fld_active_css`     =  ".$_SESSION[PGMK][NAV][BNF]['fld_active_css']                 ."
    , `fld_json_css`       = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_json_css'])       ."'
    , `fld_tsupd_css`      = '".addslashes($GLOBALS['glob_setdate'])                            ."'
    , `fld_cntupd_css`     =  " . ((int)$_POST['fld_cntupd_css']+1)                         ."
  ";
  $req6.="
   WHERE `fld_id_css`=".$_POST['id1']."
  ";
//     AND `fld_cntupd_css` = ".$_POST['fld_cntupd_css']."
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
     break;
    default   :
     $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    break;
   }
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
  }else{
   if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])!=1){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('this_record_has_not_been_updated_because_of_an_other_user');
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('please_retry');
    unset($_SESSION[PGMK][NAV][BNF]['fld_name_css']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_active_css']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_json_css']);
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
   }
   
   if(!is_dir($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css')){
    if(!mkdir($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css',0777,true)){
     debugSql2(array('message' => ' in ' . __FUNCTION__ . ' cannot create directory "'.$GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css"' , 'file' => __FILE__ , 'line' => __LINE__ ));
    }else{
     $xtxterr=txtsys1('error').' ' . __LINE__ . ' error while creating directory : ' . $GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css' ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 'error' );     
     header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
    }
   }
   $cssTxt=setCssText($cssList);
   $cssList['sizes']['menuHeight']  =$GLOBALS['bodyPaddingTop'];
   $cssList['sizes']['footerHeight']=$GLOBALS['footerHeight'];
   
   if($fd=fopen($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/'.$_POST['id1'].'.css','w')){
    fwrite($fd,$cssTxt);
    fclose($fd);
    if($fd=fopen($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/'.$_POST['id1'].'.js','w')){
     fwrite($fd,'var globalCssSettings1='.json_encode($cssList,JSON_PRETTY_PRINT).';');
     fclose($fd);
    }else{
     $xtxterr=txtsys1('error').' ' . __LINE__ . ' error while creating file : ' . $GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/'.$_POST['id1'].'.js'  ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 'error' );     
     header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
     
    }
   }else{
    $xtxterr=txtsys1('error').' ' . __LINE__ . ' error while creating file : ' . $GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/'.$_POST['id1'].'.css'  ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 'error' );     
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
   }
   
   $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('the_modification_has_been_recorded_at') . ' ' . substr($GLOBALS['glob_setdate'],11);
   updateCssList();
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CONFIRM DELETE ===============================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='cd'){
 
  require_once $GLOBALS['glob_incPath1'].'/__tableDependencies1.php';
  $retDependantTables=dependentValuesExist1(0,'tdo_tbl__css',$_POST['id1'] );
  if(true === $retDependantTables['valuesExist']){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' . txtsys1('you_cannot_delete_because_some_values_are_still_present_in_dependant_table') . ' ' . var_export( $retDependantTables['tables'] , true ) . ' ';
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=d&id='.$_POST['id1']);   
  }

//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__css` WHERE `fld_id_css`=".$_POST['id1']." " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
   txtlog1($xtxterr , BNF , __LINE__ , 'error' );
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=d&id='.$_POST['id1']);
   exit();
  }else{
   unset($_SESSION[PGMK][NAV][BNF]);
   header("HTTP/1.1 303 See Other");header('Location: zz_css1.php');
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CREATE ACTION ================================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='c'){
  if(test_input_tdo_cssKO1()){
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
   exit();
  }
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__css` SET
      `fld_name_css`       = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_name_css'])       ."'
    , `fld_active_css`     =  ".$_SESSION[PGMK][NAV][BNF]['fld_active_css']                 ."
    , `fld_json_css`       = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_json_css'])       ."'
    , `fld_tsupd_css`      = '".addslashes($GLOBALS['glob_setdate'])                           ."'
    , `fld_tscrt_css`      = '".addslashes($GLOBALS['glob_setdate'])                           ."'
  " ;
//  echo __FILE__ . ' ' . __LINE__ . ' $req6 =' . $req6 . '' ; exit();
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
    break;
    default;
    $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    break;
   }
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
   exit();
  }else{
   $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
    exit();
   }else{
    $NewCode=mysqli_fetch_row($resIns);
    $NewCode=$NewCode[0];
    mysqli_free_result($resIns);
    SetSessionMessageAndLog1( txt2('the new value has been inserted_439_36') . ' ('.$NewCode.').' , BNF , __LINE__ , 'information');
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=n&id='.$NewCode);
    exit();
   }
  }
 }
 
}else{ // get action

 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= GET ACTION ========================================================================
 //=================================================================================================================================
 //=================================================================================================================================
 $o1=htmlHead1(array());
 $js1=array();
// echo __LINE__ . '$_SESSION[PGMK]=<pre>' . var_export( $_SESSION[PGMK] , true ) . '</pre>'; exit();
 //=================================================================================================================================
 //============================================= GET DELETE ========================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='d'){ // delete action
  $id=(isset($_GET['id'])&&is_numeric($_GET['id']))?$_GET['id']:0;
  if($id==0){
   header("HTTP/1.1 303 See Other");header('Location: zz_css1.php');
   exit();
  }else{
   $xvalueName=getTdo_css1($_GET['id']);
   if($xvalueName['fld_name_css']==''){
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_delete_this_value');
    header("HTTP/1.1 303 See Other");header('Location: zz_css1.php');
    exit();
   }else{
    require_once $GLOBALS['glob_incPath1'].'/__tableDependencies1.php';
    $retDependantTables=dependentValuesExist1(0,'tdo_tbl__css',$_GET['id'] );
    if(isset($retDependantTables['valuesExist']) && $retDependantTables['valuesExist']==true){
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <div>'.CRLF;
     $o1.=' '.txtsys1('dependent_values_exist').''.CRLF;
     $o1.=' <ul>'.CRLF;
     foreach( $retDependantTables['tables'] as $k1 => $v1){
      $o1.='  <li>'.$v1.'</li>'.CRLF;
     }
     $o1.=' </ul>'.CRLF;
     $o1.=' </div>'.CRLF;
     $o1.=btl1();
    }else{
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <form method="post" class="yyformDelete">'.CRLF;
     $o1.='   '.txtsys1('please_confirm_deletion_of').' : '.CRLF;
     $o1.='   <br /><br /><b>'.enti1($xvalueName['fld_name_css']).'</b><br /><br />'.CRLF;
     $o1.='   <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
     $o1.='   <input type="hidden" value="cd" name="a" id="a" />'."\r\n";
     $o1.='   <button type="submit" class="yydanger">'.txtsys1('i_confirm_the_deletion_button').'</button>'.CRLF;
     $o1.=btl1();
     $o1.=' </form>'."\r\n";
    }
   }
  }
 //=================================================================================================================================
 //============================================= GET UPDATE ========================================================================
 //=================================================================================================================================
 
 }else if(isset($_GET['a'])&&$_GET['a']=='u'){ // update action
  $xxxFldValues=array();
  $js1=array();
  $o1.='<h4>'.txt2('update a record_504_20').' ('.$_GET['id'].')'.btl1().'</h4>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $name2=getTdo_css1($_GET['id']);
  $xxxFldValues['fld_name_css']       =isset( $_SESSION[PGMK][NAV][BNF]['fld_name_css'] )       ? $_SESSION[PGMK][NAV][BNF]['fld_name_css']       : $name2['fld_name_css']       ;
  $xxxFldValues['fld_active_css']     =isset( $_SESSION[PGMK][NAV][BNF]['fld_active_css'] )     ? $_SESSION[PGMK][NAV][BNF]['fld_active_css']     : $name2['fld_active_css']     ;
  $xxxFldValues['fld_json_css']       =isset( $_SESSION[PGMK][NAV][BNF]['fld_json_css'] )       ? $_SESSION[PGMK][NAV][BNF]['fld_json_css']       : $name2['fld_json_css']       ;


  $o1.='<form method="post" >'.CRLF;

  $o1.=' <input type="hidden" value="u" name="a" id="a" />'.CRLF;
  $o1.=' <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;

  $o1.='<div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <input type="hidden" name="fld_cntupd_css" id="fld_cntupd_css1" value="'.$name2['fld_cntupd_css'].'" />'.CRLF;
  $o1.='   <button type="submit" class="yyright1">'.txtsys1('save_the_modification').'</button>'.CRLF;
  $o1.='   <a class="yysuccess yytxtSiz1 yyright1" style="margin-right:15px;" href="?setCss='.$_GET['id'].'" title="'.txt1('use_this_theme_button').'">⇒</a> &nbsp; &nbsp; ';
  $o1.='  </div></div>'.CRLF;
  $o1.='</div>'.CRLF;


  
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_name_css_472_42').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_name_css']).'" name="fld_name_css" id="fld_name_css" maxlength="32" style="width:100%;max-width:34em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_active_css_479_42').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$xxxFldValues['fld_active_css'],'fld_active_css',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  
  $listeDesValeursCss=$xxxFldValues['fld_json_css'];
//  echo __FILE__ . ' ' . __LINE__ . ' $listeDesValeursCss = <pre>' . var_export( $listeDesValeursCss , true ) . '</pre>' ; exit(0);
  $tableauDesCss=array();
  if($listeDesValeursCss!=''){
    $jsonCss=json_decode($listeDesValeursCss,true);
//    echo __FILE__ . ' ' . __LINE__ . ' $jsonCss = <pre>' . var_export( $jsonCss , true ) . '</pre>' ; exit(0);
  }else{
   $jsonCss=array();
  }
  $colPrec='';
  $colCrt='';
  foreach($cssList as $k1 => $v1){
    
   $o1.=' <div class="yyfdiv1">'.CRLF;
   $o1.='  <div class="yyflab1"><div>'.$k1.'</div></div>'.CRLF;
   $o1.='  <div class="yyfinp1"><div style="display:flex;flex-wrap:wrap;">'.CRLF;
    
   foreach($v1 as $k2 => $v2){
    if($v2['type']=='color'){
     $o1.='   <div class="yythinBorder" style="display:flex;flex-wrap:wrap;">';
     if($k1=='backgrounds'){
      if(strpos($k2,'Background')!==false && strpos($k2,'2')===false){
       $o1.='     <div style="width:60px;word-break: break-word;">'.substr($k2,0,strpos($k2,'Background')).'</div>'.CRLF;
      }
     }
     $o1.='    <div>';
     if($k1=='backgrounds'){
      if(strpos($k2,'Background')!==false && strpos($k2,'2')===false){
       $o1.='     <div style="width:20px;word-break: break-word;font-size:0.8em;">B1</div>'.CRLF;
      }else if(strpos($k2,'Background')!==false && strpos($k2,'2')!==false){
       $o1.='     <div style="width:20px;word-break: break-word;font-size:0.8em;">B2</div>'.CRLF;
      }else{
       $o1.='     <div style="width:20px;word-break: break-word;font-size:0.8em;">txt</div>'.CRLF;       
      }
     }else if($k1=='badge'){
      if(strpos($k2,'Background')!==false){
       $o1.='     <div style="width:70px;word-break: break-word;font-size:0.8em;">'.substr($k2,0,strpos($k2,'Background')+3).'</div>'.CRLF;
      }else{
       $o1.='     <div style="width:70px;word-break: break-word;font-size:0.8em;">'.substr($k2,0,strpos($k2,'Text')+3).'</div>'.CRLF;       
      }
     }else{
      $o1.='     <div style="width:145px;word-break: break-word;font-size:0.8em;">'.$k2.'</div>'.CRLF;
      
     }
     $o1.='    </div>';
     
    
     $val=array('hexValue' => $v2['hexValue']);
     if(isset($jsonCss[$k1][$k2])){
      $val=$jsonCss[$k1][$k2];
 //     echo __FILE__ . ' ' . __LINE__ . ' $val = <pre>' . var_export( $val , true ) . '</pre>' ; exit(0);
     }
     $o1.='    <div style="display:flex;">';    
     $o1.='     <input type="hidden" name="'.$k2.'" id="'.$k2.'"   value="'.enti1(json_encode($val)).'" />'.CRLF;
     
     $o1.='     <div id="div__display_color_'.$k2.'" style="display:flex;">'.CRLF;
     if($val!=''){
      $o1.='      <div style="width:35px;height:35px;border:1px #eee inset;background-color:#'.$val['hexValue'].'"></div>';
      $o1.='      <div style="font-size:0.8em;width:125px;">'.enti1($val['hexValue']).'';
      $colCrt=$val['hexValue'];
      if(isset($val['webName']) && $val['webName']!=''){
       $o1.=','.enti1($val['webName']).'';
      }
      if(isset($val['pantoneName']) && $val['pantoneName']!=''){
       $o1.=', pantone:'.enti1($val['pantoneName']).'';
      }
      if(isset($val['materialName']) && $val['materialName']!=''){
       $o1.=', material:'.enti1($val['materialName']).'';
      }
      $o1.='      </div>';
     }
     $o1.='     </div>';
     
     
     $o1.='     <div>';
     $o1.='      <button type="button" id="button_color_'.$k2.'"';
     $o1.=' onclick="javascript:setColor1(';
     $o1.='\''.$k2.'\',';
     $o1.='\'button_color_'.$k2.'\',';
     $o1.='\'div__display_color_'.$k2.'\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">'.txtsys1('update color').'</button>';
     $o1.='     </div>';
     $o1.='    </div>';
     $o1.='   </div>';
     if($k1=='badge'){
 //     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $v1 , true ) . '</pre>' ; exit(0);
      if(strpos($k2,'TextColor')!==false){
       $o1.='<div><span class="yybadge" style="color:#'.$colCrt.';background:#'.$colPrec.';">Badge</span></div>';
 //      $o1.='<div style="flex-basis: 100%;"></div>';
      }
     }    
     $colPrec=$colCrt;
    }else if($v2['type']=='SomeValues'){ // inputBorderWidth
     
     $o1.='<div class="yythinBorder">';
     
     $o1.='     <div><div>'.$k2.'</div></div>';
     $val=isset($jsonCss[$k1][$k2])?$jsonCss[$k1][$k2]['value']:$cssList[$k1][$k2]['value'];
     $somevalues=explode(',',$v2['valueList']);
     $o1.='     <div style="display:flex;flex-wrap:wrap;">';
     foreach($somevalues as $ksom => $vsom){
      $o1.='       <div class="yythinBorder">'.$vsom.' <input type="radio" name="'.$k2.'" value="'.$vsom.'" '.($vsom==$val?' checked="checked" ':'').' /></div>';
     }
     $o1.='     </div>';
     
     
     $o1.='</div>';
     
     
    }else if($v2['type']=='yorno'){
     $o1.='    <div>';
     $o1.='     <div>'.$k2.'</div>'.CRLF;
     $o1.='    </div>';
     
     $val=isset($jsonCss[$k1][$k2])?$jsonCss[$k1][$k2]['value']:$cssList[$k1][$k2]['value'];
     
     $retParam=displayParam2('yorno',$val,$k2,array('unsetPossible'=>false,'dropDown'=>false));
     $o1.=$retParam['html'];
     
    }
    if(isset($v2['hr_after']) && $v2['hr_after']==true ){
     $o1.='<div style="flex-basis: 100%;"></div>';
    }
   }
   
   $o1.='  </div></div>'.CRLF;
   $o1.=' </div>'.CRLF;
   
  }

  $o1.='<div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <input type="hidden" name="fld_cntupd_css" id="fld_cntupd_css2" value="'.$name2['fld_cntupd_css'].'" />'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('save_the_modification').'</button>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.='</div>'.CRLF;

  $o1.='</form>'.CRLF;

 //=================================================================================================================================
 //============================================= GET VIEW ==========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='v'&&isset($_GET['id'])&&is_numeric($_GET['id'])){ // view action
  // if you vant to do something here, go !
 //=================================================================================================================================
 //============================================= GET CREATE ========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='c'){ // create action
 
  $o1.='<h2>'.txt2('Add a new record_616_20'). ' '.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $o1.='<form method="post" class="form1">'.CRLF;
 

  $fld_name_css =isset($_SESSION[PGMK][NAV][BNF]['fld_name_css'] )?$_SESSION[PGMK][NAV][BNF]['fld_name_css']:'';
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_name_css_472_42').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_name_css).'" name="fld_name_css" id="fld_name_css" maxlength="32" style="width:100%;max-width:34em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('record_the_element').'</button>'.CRLF;
  $o1.='   <input type="hidden" name="fld_json_css" id="fld_json_css"  value="" />'.CRLF;
  $o1.='   <input type="hidden" value="0" name="id1" id="id1" />'.CRLF;
  $o1.='   <input type="hidden" value="c" name="a" id="a" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.='</form>'.CRLF;

 }
 $o1.=htmlFoot0(array('js' => $js1));
 dw1($o1);
 if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);
}
