var globalCssSettings1={
    "main": {
        "mainBackgroundColor": {
            "hexValue": "34444C",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "200,32,30",
            "rgbValue": "52,68,76"
        },
        "mainBackgroundColEnd": {
            "hexValue": "111111",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,6",
            "rgbValue": "17,17,17"
        },
        "mainTextColor": {
            "hexValue": "B0BEC5",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 200",
            "hsvValue": "10,10,77",
            "rgbValue": "176,190,197",
            "type": "color"
        },
        "thinBorderColor": {
            "hexValue": "2A4856",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "199,51,34",
            "rgbValue": "42,72,86"
        },
        "linkStartBackgroundColor": {
            "hexValue": "455A64",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 700",
            "hsvValue": "31,31,39",
            "rgbValue": "69,90,100",
            "type": "color"
        },
        "linkEndBackground": {
            "hexValue": "263238",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 900",
            "hsvValue": "32,32,21",
            "rgbValue": "38,50,56",
            "type": "color"
        },
        "linkUnsetTextColor": {
            "type": "color",
            "hexValue": "444444",
            "hr_after": true
        },
        "activeFilterBackground": {
            "hexValue": "B7B700",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "60,100,72",
            "rgbValue": "183,183,0",
            "type": "color"
        },
        "activeFilterColor": {
            "hexValue": "263238",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 900",
            "hsvValue": "32,32,21",
            "rgbValue": "38,50,56",
            "type": "color"
        },
        "inputBorderWidth": {
            "type": "SomeValues",
            "valueList": "1px,2px,3px",
            "value": "2px",
            "hr_after": false
        }
    },
    "menu": {
        "topColor": {
            "hexValue": "455A64",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 700",
            "hsvValue": "31,31,39",
            "rgbValue": "69,90,100",
            "type": "color"
        },
        "bottomColor": {
            "hexValue": "000000",
            "webValue": "000000",
            "webName": "black",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,0",
            "rgbValue": "0,0,0"
        },
        "textColor": {
            "hexValue": "CFD8DC",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 100",
            "hsvValue": "5,5,86",
            "rgbValue": "207,216,220",
            "type": "color"
        },
        "borderColor": {
            "hexValue": "37474F",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 800",
            "hsvValue": "30,30,30",
            "rgbValue": "55,71,79",
            "type": "color"
        },
        "activeBackgroundColor": {
            "hexValue": "607D8B",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 500",
            "hsvValue": "30,30,54",
            "rgbValue": "96,125,139",
            "type": "color"
        }
    },
    "table": {
        "headerBackgroundColor": {
            "hexValue": "455A64",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 700",
            "hsvValue": "31,31,39",
            "rgbValue": "69,90,100",
            "type": "color"
        },
        "headerTextColor": {
            "hexValue": "B0BEC5",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 200",
            "hsvValue": "10,10,77",
            "rgbValue": "176,190,197",
            "type": "color"
        },
        "linkTextColor": {
            "type": "color",
            "hexValue": "0000FF",
            "hr_after": true
        },
        "nthchildBackgroundColor": {
            "hexValue": "37474F",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 800",
            "hsvValue": "30,30,30",
            "rgbValue": "55,71,79",
            "type": "color"
        }
    },
    "backgrounds": {
        "dangerBackground": {
            "hexValue": "701111",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,84,44",
            "rgbValue": "112,17,17",
            "type": "color"
        },
        "danger2Background": {
            "hexValue": "540D0D",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,84,33",
            "rgbValue": "84,13,13"
        },
        "dangerText": {
            "hexValue": "D6D6D6",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,84",
            "rgbValue": "214,214,214"
        },
        "editBackground": {
            "hexValue": "546E7A",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 600",
            "hsvValue": "31,31,47",
            "rgbValue": "84,110,122",
            "type": "color"
        },
        "edit2Background": {
            "hexValue": "445A63",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "198,31,39",
            "rgbValue": "68,90,99"
        },
        "editText": {
            "hexValue": "CFD8DC",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 100",
            "hsvValue": "5,5,86",
            "rgbValue": "207,216,220",
            "type": "color"
        },
        "successBackground": {
            "hexValue": "537F1E",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "87,76,50",
            "rgbValue": "83,127,30",
            "type": "color"
        },
        "success2Background": {
            "hexValue": "466B19",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "87,76,42",
            "rgbValue": "70,107,25"
        },
        "successText": {
            "hexValue": "B5C49B",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "82,21,77",
            "rgbValue": "181,196,155",
            "type": "color"
        },
        "errorBackground": {
            "hexValue": "BA2828",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,78,73",
            "rgbValue": "186,40,40",
            "type": "color"
        },
        "error2Background": {
            "hexValue": "A52424",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,78,65",
            "rgbValue": "165,36,36"
        },
        "errorText": {
            "hexValue": "E5E52D",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "60,80,90",
            "rgbValue": "229,229,45"
        },
        "warningBackground": {
            "hexValue": "D68700",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "38,100,84",
            "rgbValue": "214,135,0"
        },
        "warning2Background": {
            "hexValue": "B57200",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "38,100,71",
            "rgbValue": "181,114,0"
        },
        "warningText": {
            "hexValue": "724600",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "37,100,45",
            "rgbValue": "114,70,0"
        }
    },
    "badge": {
        "badge0Background": {
            "hexValue": "880E4F",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Pink 900",
            "hsvValue": "89,89,53",
            "rgbValue": "136,14,79",
            "type": "color"
        },
        "badge0TextColor": {
            "hexValue": "B0BEC5",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 200",
            "hsvValue": "10,10,77",
            "rgbValue": "176,190,197",
            "type": "color"
        },
        "badge1Background": {
            "hexValue": "004D40",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Teal 900",
            "hsvValue": "100,100,30",
            "rgbValue": "0,77,64",
            "type": "color"
        },
        "badge1TextColor": {
            "hexValue": "B0BEC5",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue grey 200",
            "hsvValue": "10,10,77",
            "rgbValue": "176,190,197",
            "type": "color"
        },
        "badge2Background": {
            "hexValue": "FFEE58",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Yellow 400",
            "hsvValue": "65,65,100",
            "rgbValue": "255,238,88"
        },
        "badge2TextColor": {
            "hexValue": "1976D2",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Blue 700",
            "hsvValue": "88,88,82",
            "rgbValue": "25,118,210"
        },
        "badge3Background": {
            "type": "color",
            "hexValue": "FF00FF"
        },
        "badge3TextColor": {
            "type": "color",
            "hexValue": "FFFF00",
            "hr_after": true
        },
        "badge4Background": {
            "type": "color",
            "hexValue": "00FFFF"
        },
        "badge4TextColor": {
            "type": "color",
            "hexValue": "0000FF",
            "hr_after": true
        },
        "badge5Background": {
            "type": "color",
            "hexValue": "4CAF50"
        },
        "badge5TextColor": {
            "type": "color",
            "hexValue": "FFEB3B",
            "hr_after": true
        },
        "badge6Background": {
            "type": "color",
            "hexValue": "FFEBEE"
        },
        "badge6TextColor": {
            "type": "color",
            "hexValue": "C62828",
            "hr_after": true
        },
        "badge7Background": {
            "type": "color",
            "hexValue": "1E88E5"
        },
        "badge7TextColor": {
            "type": "color",
            "hexValue": "E3F2FD",
            "hr_after": true
        },
        "badge8Background": {
            "type": "color",
            "hexValue": "FFE082"
        },
        "badge8TextColor": {
            "hexValue": "EF2D6E",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "340,81,94",
            "rgbValue": "239,45,110"
        }
    },
    "other": {
        "autocompleteInput": {
            "type": "yorno",
            "value": "0"
        }
    },
    "sizes": {
        "menuHeight": 55,
        "footerHeight": 20
    }
};