var globalCssSettings1={
    "main": {
        "mainBackgroundColor": {
            "hexValue": "FFF4F6",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "351,4,100",
            "rgbValue": "255,244,246",
            "type": "color"
        },
        "mainBackgroundColEnd": {
            "hexValue": "FFE0E4",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "351,12,100",
            "rgbValue": "255,224,228"
        },
        "mainTextColor": {
            "hexValue": "5B0404",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,95,36",
            "rgbValue": "91,4,4",
            "type": "color"
        },
        "thinBorderColor": {
            "hexValue": "FFDBDE",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "355,14,100",
            "rgbValue": "255,219,222"
        },
        "linkStartBackgroundColor": {
            "hexValue": "FFEBEE",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 50",
            "hsvValue": "7,7,100",
            "rgbValue": "255,235,238",
            "type": "color"
        },
        "linkEndBackground": {
            "hexValue": "EF9A9A",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 200",
            "hsvValue": "35,35,93",
            "rgbValue": "239,154,154",
            "type": "color"
        },
        "linkUnsetTextColor": {
            "hexValue": "FFE2E7",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "351,11,100",
            "rgbValue": "255,226,231",
            "type": "color"
        },
        "activeFilterBackground": {
            "hexValue": "ffff00",
            "type": "color"
        },
        "activeFilterColor": {
            "hexValue": "5B0404",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,95,35",
            "rgbValue": "91,4,4",
            "type": "color"
        },
        "inputBorderWidth": {
            "type": "SomeValues",
            "valueList": "1px,2px,3px",
            "value": "2px",
            "hr_after": false
        }
    },
    "menu": {
        "topColor": {
            "hexValue": "EF9A9A",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 200",
            "hsvValue": "35,35,93",
            "rgbValue": "239,154,154",
            "type": "color"
        },
        "bottomColor": {
            "hexValue": "F44336",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 500",
            "hsvValue": "77,77,95",
            "rgbValue": "244,67,54",
            "type": "color"
        },
        "textColor": {
            "hexValue": "FFF4F6",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "351,4,100",
            "rgbValue": "255,244,246",
            "type": "color"
        },
        "borderColor": {
            "hexValue": "EF9A9A",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 200",
            "hsvValue": "35,35,93",
            "rgbValue": "239,154,154",
            "type": "color"
        },
        "activeBackgroundColor": {
            "hexValue": "F44336",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 500",
            "hsvValue": "77,77,95",
            "rgbValue": "244,67,54",
            "type": "color"
        }
    },
    "table": {
        "headerBackgroundColor": {
            "hexValue": "FFCDD2",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 100",
            "hsvValue": "19,19,100",
            "rgbValue": "255,205,210",
            "type": "color"
        },
        "headerTextColor": {
            "hexValue": "B71C1C",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "Red 900",
            "hsvValue": "84,84,71",
            "rgbValue": "183,28,28",
            "type": "color"
        },
        "linkTextColor": {
            "type": "color",
            "hexValue": "0000FF",
            "hr_after": true
        },
        "nthchildBackgroundColor": {
            "hexValue": "FFEDF0",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "350,7,100",
            "rgbValue": "255,237,240",
            "type": "color"
        }
    },
    "backgrounds": {
        "dangerBackground": {
            "hexValue": "00BFFF",
            "webValue": "00BFFF",
            "webName": "deepskyblue",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "100,100,100",
            "rgbValue": "0,191,255"
        },
        "danger2Background": {
            "hexValue": "009ED3",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "195,100,83",
            "rgbValue": "0,158,211"
        },
        "dangerText": {
            "hexValue": "FFFFFF",
            "webValue": "FFFFFF",
            "webName": "white",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,0,100",
            "rgbValue": "255,255,255"
        },
        "editBackground": {
            "hexValue": "FF7272",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,55,100",
            "rgbValue": "255,114,114"
        },
        "edit2Background": {
            "hexValue": "E06464",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "0,55,88",
            "rgbValue": "224,100,100"
        },
        "editText": {
            "hexValue": "914B5E",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "344,48,56",
            "rgbValue": "145,75,94",
            "type": "color"
        },
        "successBackground": {
            "hexValue": "9FD65C",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "87,57,84",
            "rgbValue": "159,214,92"
        },
        "success2Background": {
            "hexValue": "8ABA50",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "87,57,73",
            "rgbValue": "138,186,80"
        },
        "successText": {
            "type": "color",
            "hexValue": "556B2F",
            "hr_after": true
        },
        "errorBackground": {
            "hexValue": "00CED1",
            "webValue": "00CED1",
            "webName": "darkturquoise",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "100,100,81",
            "rgbValue": "0,206,209"
        },
        "error2Background": {
            "hexValue": "00ADAD",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "180,100,68",
            "rgbValue": "0,173,173"
        },
        "errorText": {
            "hexValue": "FFFF33",
            "webValue": "FFFF33",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "80,80,100",
            "rgbValue": "255,255,51"
        },
        "warningBackground": {
            "hexValue": "FFA500"
        },
        "warning2Background": {
            "hexValue": "E08A00",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "37,100,88",
            "rgbValue": "224,138,0"
        },
        "warningText": {
            "hexValue": "824300",
            "webValue": "",
            "webName": "",
            "pantoneName": "",
            "materialName": "",
            "hsvValue": "31,100,51",
            "rgbValue": "130,67,0"
        }
    },
    "badge": {
        "badge0Background": {
            "type": "color",
            "hexValue": "FF0000"
        },
        "badge0TextColor": {
            "type": "color",
            "hexValue": "000000",
            "hr_after": true
        },
        "badge1Background": {
            "type": "color",
            "hexValue": "FF0000"
        },
        "badge1TextColor": {
            "type": "color",
            "hexValue": "000000",
            "hr_after": true
        },
        "badge2Background": {
            "type": "color",
            "hexValue": "FFFF00"
        },
        "badge2TextColor": {
            "type": "color",
            "hexValue": "0000FF",
            "hr_after": true
        },
        "badge3Background": {
            "type": "color",
            "hexValue": "FF00FF"
        },
        "badge3TextColor": {
            "type": "color",
            "hexValue": "FFFF00",
            "hr_after": true
        },
        "badge4Background": {
            "type": "color",
            "hexValue": "00FFFF"
        },
        "badge4TextColor": {
            "type": "color",
            "hexValue": "0000FF",
            "hr_after": true
        },
        "badge5Background": {
            "type": "color",
            "hexValue": "4CAF50"
        },
        "badge5TextColor": {
            "type": "color",
            "hexValue": "FFEB3B",
            "hr_after": true
        },
        "badge6Background": {
            "type": "color",
            "hexValue": "FFEBEE"
        },
        "badge6TextColor": {
            "type": "color",
            "hexValue": "C62828",
            "hr_after": true
        },
        "badge7Background": {
            "type": "color",
            "hexValue": "1E88E5"
        },
        "badge7TextColor": {
            "type": "color",
            "hexValue": "E3F2FD",
            "hr_after": true
        },
        "badge8Background": {
            "type": "color",
            "hexValue": "FFE082"
        },
        "badge8TextColor": {
            "type": "color",
            "hexValue": "F06292",
            "hr_after": true
        }
    },
    "other": {
        "autocompleteInput": {
            "type": "yorno",
            "value": "0"
        }
    },
    "sizes": {
        "menuHeight": 55,
        "footerHeight": 20
    }
};