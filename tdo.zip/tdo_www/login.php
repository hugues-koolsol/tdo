<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['glob_incPath1'].'/lang/'.$GLOBALS['glob_lang'].'_'.BNF , true ) . '</pre>' ; exit(0);
checkGroupPages();

if(isset($_GET['setCss'])){
 include($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/__css.php');
 if(!isset($__css[$_GET['setCss']])){
  $_COOKIE[PGMK.'cssvalue']=1;
  setcookie ( PGMK.'cssvalue' , $_COOKIE[PGMK.'cssvalue'] , time()+3600*24*365);
 }else{
  $_COOKIE[PGMK.'cssvalue']=$_GET['setCss'];
  setcookie ( PGMK.'cssvalue' , $_GET['setCss'] , time()+3600*24*365 );  
 }
 header("HTTP/1.1 303 See Other");header('Location: '.BNF);
 exit(); 
}

if($GLOBALS['glob_maintenance']==false){
 if(isset($_GET['logout'])){
  unset($_SESSION[PGMK]);
  $urlRedir=$GLOBALS['glob_log_in_page_name'];
  if(isset($_GET['timOutRedir'])){
   $urlRedir.='?redir='.urlencode($_GET['timOutRedir']);;
  }
  header("HTTP/1.1 303 See Other");header('Location: '.$urlRedir); 
  exit();
 }
 if(isset($_COOKIE[PGMK.'TestCookie'])&&$_COOKIE[PGMK.'TestCookie']=='1'){
  if(isLogged()){
   header("HTTP/1.1 303 See Other");header('Location: index.php');
   exit();
  }
 }else{
  @include_once($GLOBALS['glob_noVcPath1'].'/serveurActif.php');
  if(isset($GLOBALS['serveurActif'])&&$GLOBALS['serveurActif']==false){
   unset($_SESSION[PGMK]);
  }else{
   if(isLogged()){
    if(isset($_GET['redir'])&&$_GET['redir']!=''){
     header("HTTP/1.1 303 See Other");header('Location: '.$_GET['redir']);
     exit();
    }else{
     header("HTTP/1.1 303 See Other");header('Location: index.php');
     exit();
    }
   }
  }
 }
}else{
 unset($_SESSION[PGMK]);
}
if(isset($_POST['login1'])&&isset($_POST['password1'])){
 $founded=0;
 $_SESSION[PGMK][BNF]['login']=$_POST['login1'];
 $_SESSION[PGMK][BNF]['errormessage']=array();
 if($_POST['login1']==''||$_POST['password1']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error'). ' ' . __LINE__ . ' : ' .txt2('login and password must be filled_50_94');
 }else{
  openDb1();
  // https://stackoverflow.com/questions/5741187/sql-injection-that-gets-around-mysql-real-escape-string
  // put ' ( single quotes ) around text fields search, a mysqli_set_charset( $link , 'utf8mb4' ); has been done on the database connect
  // $2y$12$PT2hRML8DkNW3bw1UEZisOQXYw9dD1FBYNZplDODEYujLW/gejtfi is a reset for login/password = root/root
  $req6='
   SELECT  T0.`fld_id_users`        , T0.`fld_group_id_users`   , T0.`fld_translate_users` , T0.`fld_password_users`       , 	T0.`fld_active_users` ,
           T1.`fld_isactive_groups` , T1.`fld_parent_id_groups` , T1.`fld_role_groups`     , T0.`fld_changepassword_users`
   FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` T0 ,
        `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T1 
   WHERE T0.`fld_login_users`     = \''.addslashes($_POST['login1'])  .'\' 
     AND T0.`fld_group_id_users`  = T1.`fld_id_groups`
   LIMIT 1
  ';
//     AND T0.`fld_password_users` = \''.md5($_POST['password1']).'\'
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   
   while($mpsr6=mysqli_fetch_row($result6)){
    if(password_verify($_POST['password1'], $mpsr6[3]) && $founded==0){
     if($mpsr6[4]==0){
      $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' .  txt2('your personal profile is not active_68_99').'<br />';
      $founded=2;
     }else if($mpsr6[5]==0){
      $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' .  txt2('your group profile is not active_71_99').'<br />';      
      $founded=3;
     }else{
      $_SESSION[PGMK]['loginInit']     =$mpsr6[0];
      $_SESSION[PGMK]['login']         =$mpsr6[0];
      $_SESSION[PGMK]['groupInit']     =$mpsr6[1];
      $_SESSION[PGMK]['group']         =$mpsr6[1];
      $_SESSION[PGMK]['grpCatInit']    =$mpsr6[7];
      $_SESSION[PGMK]['grpCat']        =$mpsr6[7];
      $_SESSION[PGMK]['translate']     =$mpsr6[2];
      $_SESSION[PGMK]['changepassword']=$mpsr6[8];
      $founded=1;
      if($mpsr6[6]==$mpsr6[1] && $mpsr6[0]!=1){
       $_SESSION[PGMK]['isLocalAdmin']=true;
      }else{
       $_SESSION[PGMK]['isLocalAdmin']=false;       
      }
      if(isset($_POST['rememberLogin1']) ){
       $_COOKIE[PGMK.'saveLogin1']=$_POST['login1'];
       setcookie( PGMK.'saveLogin1' , $_POST['login1'] , time()+3600*24*365);
      }else{
       setcookie( PGMK.'saveLogin1' , $_POST['login1'] , time()-3600*24);
       unset($_COOKIE[PGMK.'saveLogin1']);
      }
      if($_SESSION[PGMK]['grpCat']=='i18n'){
        $_SESSION[PGMK]['__i18n_languages']='';
        $tabLogin=explode('-',$_POST['login1']);
        foreach($tabLogin as $k1=>$v1){
         foreach($GLOBALS['glob__availableLanguages'] as $k2=>$v2){
          if($v1==$k2){
           $_SESSION[PGMK]['__i18n_languages'].='-'.$k2.'-';
          }
         }
        }
      }
     }
    }
   }
   mysqli_free_result($result6);
  }else{
   debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));
  }
 
  if($founded==0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' .  txt2('incorrect_login_or_password_78_10').'<br />';
   sleep(2); // Attendre 2 secondes pour donner le temps à l'utilisateur de réfléchir !!!!
  }
 }
 if($founded==1){
  if(isset($_POST['redir'])){
   header("HTTP/1.1 303 See Other");header('Location: '.rawurldecode($_POST['redir']));
   exit();
  }else{
   header("HTTP/1.1 303 See Other");header('Location: index.php');
   exit();
  }
 }else{
  header("HTTP/1.1 303 See Other");header('Location: login.php');
  exit();
 }
}
$o1=htmlHead1(array('nomenu'=>true,'oldbrowser'=>true));



if($GLOBALS['glob_maintenance']==false){
 $o1.=displaySessionMessage1(BNF);
 
 if(isset($_GET['message'])){
  $o1.='<div class="yymessageBox yysuccess">'.$_GET['message'].'</div>';
 }
 
 $o1.='<br />'.CRLF;
 $o1.='<form id="loginForm1" method="post" style="margin:auto auto;display:block;overflow:hidden;max-width:500px;border-radius:3px;">'.CRLF;
 if(isset($_GET['redir'])&&$_GET['redir']!=''){
  $o1.='   <input type="hidden" value="'.rawurlencode($_GET['redir']).'" name="redir" id="redir" />'.CRLF;
 }
 
 $o1.='  <div class="yyfdiv1">'.CRLF;
 $o1.='   <div class="yyflab1">'.CRLF;
 $o1.='    <div>'.txt2('email_121_38').'</div>'.CRLF;
 $o1.='   </div>'.CRLF;
 $o1.='   <div class="yyfinp1">'.CRLF;
 $o1.='    <div style="text-align:center;">'.CRLF;
 $valueLogin1='';
 if(isset($_COOKIE[PGMK.'saveLogin1'])){
  $valueLogin1=$_COOKIE[PGMK.'saveLogin1'];
 }
 $o1.='     <input type="text" value="'.enti1($valueLogin1).'" name="login1" autocomplete="off" id="login1" size="27" maxlength="128" title="Entrez votre adresse mail" autofocus="autofocus" />'.CRLF;
 $o1.='    </div>'.CRLF;
 $o1.='   </div>'.CRLF;
 $o1.='  </div>'.CRLF;
 
 $o1.='  <div class="yyfdiv1">'.CRLF;
 $o1.='   <div class="yyflab1">'.CRLF;
 $o1.='    <div>'.txt2('password_125_41').'</div>'.CRLF;
 $o1.='   </div>'.CRLF;
 $o1.='   <div class="yyfinp1">'.CRLF;
 $o1.='    <div style="text-align:center;">'.CRLF;
 $o1.='     <input type="password" value="" name="password1" id="password1" size="27" maxlength="32" title="Entrez votre mot de passe" />'.CRLF;
 $o1.='    </div>'.CRLF;
 $o1.='   </div>'.CRLF;
 $o1.='  </div>'.CRLF;
 
 $o1.='  <div class="yyfdiv1">'.CRLF;
 $o1.='   <div class="yyflab1">'.CRLF;
 $o1.='    <div>'.txt2('remember_the_login_179_24').'</div>'.CRLF;
 $o1.='   </div>'.CRLF;
 $o1.='   <div class="yyfinp1">'.CRLF;
 $o1.='    <div style="text-align:center;">'.CRLF;
 $checkedRemember='';
 if(isset($_COOKIE[PGMK.'saveLogin1'])){
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_COOKIE , true ) . '</pre>' ; exit(0);
  $checkedRemember=' checked="checked" ';
 }
 
 $o1.='     <input type="checkbox" value="" name="rememberLogin1" id="rememberLogin1" '.$checkedRemember.' />'.CRLF;
 $o1.='    </div>'.CRLF;
 $o1.='   </div>'.CRLF;
 $o1.='  </div>'.CRLF;
 
 $o1.='  <div class="yyfdiv1" style="text-align:center;">'.CRLF;
 if(isset($GLOBALS['serveurActif'])&&$GLOBALS['serveurActif']==false){ 
  $o1.='   <b style="color:red;">Ce serveur est inactif ( consultez gd ou hdf pour l\'activer ).</b>'.CRLF;
 }else{
  $o1.='   <button type="submit" style="margin:0 auto;">'.txt2('enter_135_66').'</button>'.CRLF;
 }
 $o1.='  </div>'.CRLF;
 
 $o1.='</form>'.CRLF;
// $o1.='<script type="text/javascript">setTimeout(function(){try{var el=document.getElementById(\'password1\'); el.focus();setTimeout(function(){var el=document.getElementById(\'login1\');el.focus();el.setSelectionRange(0, 30);if(el.value==\'\'){var el=document.getElementById(\'password1\'); el.focus();}},100);}catch(e){};},100);</script>'.CRLF; 
}else{
 $o1.=' <div class="yythinBorder" style="text-align:center;width:80%;line-height:2em;padding:10px;margin:10px auto;">'.CRLF;
 $o1.='    '.txt2('A maintenance operation is running_155_19') . '';
 $o1.='   <br />';
 $o1.='   <br />';
 $o1.='   '.txt2('you will be able to reconnect in several minutes_158_18').'</td>'.CRLF;
 $o1.='   <br />';
 $o1.='   <br />';
 $o1.='   <a class="yywarning" href="">'.txt2('click here to retry now_161_53').'</a>'.CRLF;
 $o1.='   <br />';
 $o1.='   <br />';
 $o1.='   <a class="yysuccess" target="_blank" href="https://www.koolsol.app/">'.txt2('koolsol ;-)_180_93').'</a>'.CRLF;
 $o1.=' </div>'.CRLF;
}

include($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/__css.php');
if(isset($__css)){
 $o1.='  <div style="display:block;margin:2em auto;text-align:center;">'.CRLF;
 foreach($__css as $k1=>$v1){
  $jsonColorBack1=$v1['main']['mainBackgroundColor']['hexValue'];
  $jsonColorBack2=$v1['main']['mainBackgroundColEnd']['hexValue'];
  $jsonColorTxt1=$v1['main']['mainTextColor']['hexValue'];
  if(isset($_COOKIE[PGMK.'cssvalue']) && $k1==$_COOKIE[PGMK.'cssvalue']){
   $o1.='<span class="yybtn" style="background:linear-gradient(to bottom, #'.$jsonColorBack1.' 0%, #'.$jsonColorBack2.' 100%);color:#'.$jsonColorTxt1.';border-style:inset;border-color:#'.$jsonColorTxt1.';border-width:4px;transform:rotatez(90deg);font-weight:bold;">:-)</span>';
  }else{
   $o1.='<a href="'.BNF.'?setCss='.$k1.'" style="background:linear-gradient(to bottom, #'.$jsonColorBack1.' 0%, #'.$jsonColorBack2.' 100%);color:#'.$jsonColorTxt1.';border-color:#'.$jsonColorTxt1.';">:-)</a>';
  }
 }
 $o1.='  </div>'.CRLF;
}


dw1($o1); $o1='';
$o1.=htmlFoot0(array());
dw1($o1);