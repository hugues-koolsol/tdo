<?php
//========================================================================================================================
//========================================================================================================================
function sortParamAlpha0($a,$b){
 if ($a[$a['param__Name__Display']] == $b[$b['param__Name__Display']]) {
  return 0;
 }
 return ($a[$a['param__Name__Display']] > $b[$b['param__Name__Display']]) ? -1 : 1;
}
//========================================================================================================================
//========================================================================================================================
function sortParamAlpha1($a,$b){
 if ($a[$a['param__Name__Display']] == $b[$b['param__Name__Display']]) {
  return 0;
 }
 return ($a[$a['param__Name__Display']] < $b[$b['param__Name__Display']]) ? -1 : 1;
}
//========================================================================================================================
//========================================================================================================================
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 $someErrors=array();
 openDb1();
 $oneError=false;
/*
input: {funct: "param1", subFunct: "sortParam1", lang: "fr", idParam: 5, sortOrder: 1}
funct: "param1"
idParam: 5
lang: "fr"
subFunct: "sortParam1"
message: {}
status: "KO"
*/ 

 if($ret['input']['subFunct']=='sortParam1'){
  $fld_ininclude_parnams=0;
  $fld_key_parnams='';
  $fld_order_parnams=array();
  $req6="
   SELECT fld_ininclude_parnams , fld_key_parnams , fld_order_parnams FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__paramnames` 
    WHERE `fld_id_parnams`     =   ".$ret['input']['idParam']."
   LIMIT 1
  " ;
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($mpsr6=mysqli_fetch_row($res6)){
    $fld_ininclude_parnams=(int)$mpsr6[0];
    $fld_key_parnams=$mpsr6[1];
    $fld_order_parnams=json_decode($mpsr6[2],true);
   }
   mysqli_free_result($res6);
  }
  if($fld_key_parnams!==''){
   if($fld_ininclude_parnams==1){
    require_once($GLOBALS['glob_incPath1'].'/'.'__param_'.$fld_key_parnams.'.php');
   }else{
    require_once('../'.$GLOBALS['glob_noVcDirName'].'/parameters/'.''.$fld_key_parnams.'.php');
   }
   if(isset($GLOBALS['param__'.$fld_key_parnams.'']['__values'][$ret['input']['lang']])){
    $dataToSort=$GLOBALS['param__'.$fld_key_parnams.'']['__values'][$ret['input']['lang']];
    $arr=array();
    foreach($dataToSort as $k1 => $v1){
     $dataToSort[$k1]['param__Name__Display']=$GLOBALS['param__'.$fld_key_parnams]['param__Name__Display'];
    }
    if($ret['input']['sortOrder']=='1'){
     uasort($dataToSort,'sortParamAlpha1');
    }else{
     uasort($dataToSort,'sortParamAlpha0');
    }
    $order=0;
    $new_fld_order_parnams=array();
    foreach($dataToSort as $k1=>$v1){
     $dataToSort[$k1]['__order']=$order;
     $fld_order_parnams[$ret['input']['lang']][$order]=$v1['fld_id_parvals'];
     $order++;
    }
    $GLOBALS['param__'.$fld_key_parnams.'']['__values'][$ret['input']['lang']]=$dataToSort;
    $ret['output']=$dataToSort;
    $ret['fld_order_parnams']=$fld_order_parnams;
    
    $req7="
     UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__paramnames` SET fld_order_parnams = '".addslashes(json_encode($fld_order_parnams))."'
      WHERE `fld_id_parnams`     =   ".$ret['input']['idParam']."
     LIMIT 1
    " ;
    $res7=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
    
    
    $toWrite='<'.'?php'.CRLF.'$GLOBALS[\'param__'.$fld_key_parnams.'\']='.var_export($GLOBALS['param__'.$fld_key_parnams.''],true).';';
    if($fld_ininclude_parnams==0){
     file_put_contents($GLOBALS['glob_noVcPath1'].'/parameters/'.$fld_key_parnams.'.php',$toWrite);
    }else{
     file_put_contents($GLOBALS['glob_incPath1'].'/__param_'.$fld_key_parnams.'.php',$toWrite);
    }
    $ret['status']='OK';
    
    
   }else{
    $ret['message']='not founded';
   }
  }
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}