<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 $someErrors=array();
 openDb2();
 $oneError=false;
 $req6="
  SELECT fld_order_parnams FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__paramnames` 
   WHERE `fld_id_parnams`     =   ".$ret['input']['idParam']."
  LIMIT 1
 " ;
 $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($res6)){
   $fld_order_parnams=json_decode($mpsr6[0],true);
  }
  mysqli_free_result($res6);
  if(is_null($fld_order_parnams)){
   $fld_order_parnams=array();
  }
  $fld_order_parnams[$ret['input']['lang']]=$ret['input']['order'];
 // if($fdtoto=fopen('toto.txt','a+')){ fwrite($fdtoto, var_export( $fld_order_parnams , true ) ); fclose($fdtoto); } 
  $req7="
   UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__paramnames` SET
   fld_order_parnams='".addslashes(json_encode($fld_order_parnams,JSON_FORCE_OBJECT))."'
   WHERE `fld_id_parnams`     =   ".$ret['input']['idParam']."
  " ;
  $res7=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  }else{
   $oneError=true;
   $someErrors[]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']) . ' req=' . $req7;
  }
  
 }else{ 
  $oneError=true;
  $someErrors[]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']) . ' req6=' . $req6;
 }
 if(false===$oneError){
  $ret['status']='OK';
  require_once($GLOBALS['glob_incPath1'].'/zz_inc_paramkeys1.php');
  writeParamFiles($ret['input']['idParam']);
 }else{
  $ret['message']=$someErrors;
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}