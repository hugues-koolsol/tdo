<?php
$GLOBALS['param__day2c']=array (
  'param__Name__Display' => 'n',
  'param__Name__Sort' => 'n',
  'param__Name__key' => 'day_code',
  'param__Key__type' => 'char',
  '__values' => 
  array (
    'fr' => 
    array (
      1 => 
      array (
        'day_code' => '1',
        'n' => 'Lu',
        'badge' => 'badge0',
        'rule' => '0',
        'fld_id_parvals' => '50',
        '__order' => 0,
      ),
      2 => 
      array (
        'day_code' => '2',
        'n' => 'Ma',
        'badge' => 'badge1',
        'rule' => '0',
        'fld_id_parvals' => '51',
        '__order' => 1,
      ),
      3 => 
      array (
        'day_code' => '3',
        'n' => 'Me',
        'badge' => 'badge2',
        'rule' => '0',
        'fld_id_parvals' => '52',
        '__order' => 2,
      ),
      4 => 
      array (
        'day_code' => '4',
        'n' => 'Je',
        'badge' => 'badge3',
        'rule' => '0',
        'fld_id_parvals' => '53',
        '__order' => 3,
      ),
      5 => 
      array (
        'day_code' => '5',
        'n' => 'Ve',
        'badge' => 'badge4',
        'rule' => '0',
        'fld_id_parvals' => '54',
        '__order' => 4,
      ),
      6 => 
      array (
        'day_code' => '6',
        'n' => 'Sa',
        'badge' => 'badge5',
        'rule' => '0',
        'fld_id_parvals' => '55',
        '__order' => 5,
      ),
      7 => 
      array (
        'day_code' => '7',
        'n' => 'Di',
        'badge' => 'badge6',
        'rule' => '0',
        'fld_id_parvals' => '56',
        '__order' => 6,
      ),
    ),
    'en' => 
    array (
      1 => 
      array (
        'day_code' => '1',
        'n' => 'Mo',
        'badge' => 'badge0',
        'rule' => '0',
        'fld_id_parvals' => '50',
        '__order' => 0,
      ),
      2 => 
      array (
        'day_code' => '2',
        'n' => 'Tu',
        'badge' => 'badge1',
        'rule' => '0',
        'fld_id_parvals' => '51',
        '__order' => 1,
      ),
      3 => 
      array (
        'day_code' => '3',
        'n' => 'We',
        'badge' => 'badge2',
        'rule' => '0',
        'fld_id_parvals' => '52',
        '__order' => 2,
      ),
      4 => 
      array (
        'day_code' => '4',
        'n' => 'Th',
        'badge' => 'badge3',
        'rule' => '0',
        'fld_id_parvals' => '53',
        '__order' => 3,
      ),
      5 => 
      array (
        'day_code' => '5',
        'n' => 'Fr',
        'badge' => 'badge4',
        'rule' => '0',
        'fld_id_parvals' => '54',
        '__order' => 4,
      ),
      6 => 
      array (
        'day_code' => '6',
        'n' => 'Sa',
        'badge' => 'badge5',
        'rule' => '0',
        'fld_id_parvals' => '55',
        '__order' => 5,
      ),
      7 => 
      array (
        'day_code' => '7',
        'n' => 'Su',
        'badge' => 'badge6',
        'rule' => '0',
        'fld_id_parvals' => '56',
        '__order' => 6,
      ),
    ),
  ),
);