<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb2();
//========================================================================================================================
$listeVal1=array(
 'ftp__server'   => array(),
 'ftp__user'     => array(),
 'ftp__password' => array('password' => true),
 'ftp__path'     => array(),
);
$arrDb=array(
 'distant_host'              => array(),
);
//========================================================================================================================
if(isset($_POST) && sizeof($_POST)>0){
 //========================================
 if(isset($_POST['action']) && $_POST['action']=='getDatabaseDefinitionFromServer'){
  
  $tableList1=array();
  $sql='
   SELECT T0.`fld_id_tables`               ,T0.`fld_id_server_tables`  , T0.`fld_name_tables`
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T0
    ORDER BY T0.`fld_id_tables` ASC
  ';
  $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($row=mysqli_fetch_row($req)){
    $tableListToSend[]=array(
     'n' => $row[2], // name 
     's' => $row[1], // server id
    );
   }
  }else{
   debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
  }
  if(sizeof($tableListToSend)>0){
   $localuri='http://localhost'.substr($_SERVER['REQUEST_URI'],0,strrpos($_SERVER['REQUEST_URI'],'/'));
   $localuri.='/zz_maintenance.php?getTables=true&tableList='.rawurlencode(json_encode($tableListToSend));
   $ret=file_get_contents($localuri);
   if($ret!==false){
    if($fdftp=fopen('zzz_tmp_database_local.php','w')){
     fwrite($fdftp,'<'.'?php'.CRLF);
     fwrite($fdftp,'$GLOBALS[\'__db\'][\'database_local\']='.var_export(json_decode($ret,true),true).';'.CRLF);
     fclose($fdftp);
    }
   }
   $distantUri=$_SESSION[PGMK]['distant_host'].'/zz_maintenance.php?getTables=true&tableList='.rawurlencode(json_encode($tableListToSend));
   if($GLOBALS['glob_remoteIsHttps']==true){
    $distantUri='https://'.$distantUri;
   }else{
    $distantUri='http://'.$distantUri;
   }
   $ret=file_get_contents($distantUri);
   if($ret!==false){
    if($fdftp=fopen('zzz_tmp_database_distant.php','w')){
     fwrite($fdftp,'<'.'?php'.CRLF);
     fwrite($fdftp,'$GLOBALS[\'__db\'][\'database_distant\']='.var_export(json_decode($ret,true),true).';'.CRLF);
     fclose($fdftp);
    }
   }
  }
 }
 //========================================
 
 if(isset($_POST['action']) && $_POST['action']=='setMaintenance'){
  if(isset($_SESSION[PGMK]['maintenance'])){
   unset($_SESSION[PGMK]['maintenance']);
   $ret1=file_get_contents($_SESSION[PGMK]['distant_host'].'/zz_maintenance.php?resetPagesOfGroups=true');
   $ret=array();
   $ret['input']['directDelete']=true;
   
   
   if($GLOBALS['glob_incPathAreInSubFolders']==true){
    $ret['input']['pathToDelete']='tdo_inc/__maintenance.php';
   }else{
    $ret['input']['pathToDelete']='../tdo_inc/__maintenance.php';
   }
   include($GLOBALS['glob_incPath1'].'/ajax/ajax_deleteFromServer1.php');
   
   
   if($GLOBALS['glob_incPathAreInSubFolders']==true){
    $ret['input']['pathToDelete']='zz_maintenance.php';
   }else{
    $ret['input']['pathToDelete']='tdo_www/zz_maintenance.php';
   }
   include($GLOBALS['glob_incPath1'].'/ajax/ajax_deleteFromServer1.php');
   
   
  }else{
   
   $ret['input']['directPut']=true;
   $ret['input']['pathToPut']=$GLOBALS['glob_incPath1'].'/__maintenance.php';
   $ret['input']['targetFile']='tdo_inc/__maintenance.php';
   include($GLOBALS['glob_incPath1'].'/ajax/ajax_sendLocalFilesToServer1.php');
   
   $ret['input']['pathToPut']='zz_maintenance.php';
   if($GLOBALS['glob_incPathAreInSubFolders']==true){
    $ret['input']['targetFile']='zz_maintenance.php';
   }else{
    $ret['input']['targetFile']='tdo_www/zz_maintenance.php';
   }
   include($GLOBALS['glob_incPath1'].'/ajax/ajax_sendLocalFilesToServer1.php');
   $_SESSION[PGMK]['maintenance']=true;
  }
 }
 //========================================
 if(isset($_POST['action']) && $_POST['action']=='getLocalDatabases'){
  foreach($arrDb as $k1=>$v1){
   if(isset($_POST[$k1])){
    if($_POST[$k1]!=''){
     $_SESSION[PGMK][$k1]=$_POST[$k1];   
    }else{
     unset($_SESSION[PGMK][$k1]);
    }
   }
  }
 }
 //========================================
 function ftp_files_list($ftp_stream, $directory, $recursive = false, &$files,$initPath) {
   $list = ftp_nlist($ftp_stream, $directory);
   if (is_array($list)) {
     // Strip away dot directories.
     $list = array_slice($list, 2);

     foreach ($list as $filename) {
       $path = $directory . '/' . $filename;
       // If size equals -1 it's a directory.
       if (ftp_size($ftp_stream, $path) === -1) {
         if ($recursive) {
//           $files = array_merge($files, ftp_files_list($ftp_stream, $path, $recursive,$files));
           if($filename=='tdo__userdata'){
            // do nothing
           }else{
            ftp_files_list($ftp_stream, $path, $recursive,$files,$initPath);           
           }
         }
       } else {
         // Strip away root directory path to ensure all file paths are relative.
         $files[] = array(
          'name' => $initPath.substr($path, strpos($path, '/') + 1),
          'size' => ftp_size( $ftp_stream , $path ),
          'time' => date( 'Y-m-d H:i:s', ftp_mdtm( $ftp_stream , $path )),
         );
       }
     }
   }
 } 
 
 
 //========================================
 if(isset($_POST['action']) && $_POST['action']=='tryFtpParam2'){
  $err=0;
  $conn_id=ftp_connect($_SESSION[PGMK]['ftp__server'],21,3);
  if($conn_id==false){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : connexion ' . $_SESSION[PGMK]['ftp__server'];
   $err=1;
  }else{
   if(ftp_login($conn_id, $_SESSION[PGMK]['ftp__user'], $_SESSION[PGMK]['ftp__password'])){ // Tentative d'identification
    $buff1=array();
    if(ftp_pasv($conn_id, true)){
     $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('message').' '. __LINE__ .' : connexion ' . $_SESSION[PGMK]['ftp__server'] . '' ;
    }else{
     $_SESSION[PGMK][NAV][BNF]['warningmessage'][]=txtsys1('warning').' '. __LINE__ .' : ftp_pasv ' . $_SESSION[PGMK]['ftp__server'];
    }
    if($GLOBALS['glob_incPathAreInSubFolders']==true){
     $listeRepertoires=array('');    
    }else{
     $listeRepertoires=array('tdo_cron','tdo_data','tdo_inc','tdo_www');
    }
    $listeDesDonnees=array();
    foreach( $listeRepertoires as $kd1 => $vd1 ){
     $initPath=$vd1==''?'':$vd1.'/';
     ftp_files_list($conn_id,$_SESSION[PGMK]['ftp__path'],true,$listeDesDonnees,$initPath);
    }
    // 'drwxr-sr-x    6 81074      81               4096 Oct 29 12:45 .'

    if($fdftp=fopen('zzz_tmp_ftp.php','w')){
     fwrite($fdftp,'<'.'?php'.CRLF);
     fwrite($fdftp,'$GLOBALS[\'__ftp\'][\'distantDir\']='.var_export($_SESSION[PGMK]['ftp__path'],true).';'.CRLF);
     fwrite($fdftp,'$GLOBALS[\'__ftp\'][\'data\']='.var_export( $listeDesDonnees , true).';');
     fclose($fdftp);
    }
   }else{
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : login ftp';
    $err=1;
   }
   if($err==0){
    $_SESSION[PGMK]['__ftp_ok']=true;
   }else{
    $_SESSION[PGMK]['__ftp_ok']=false;
   }
   ftp_close($conn_id); // Fermeture de la connexion
   
  }
 }

 //========================================
 if(isset($_POST['action']) && $_POST['action']=='setFtpParam1'){
  foreach($listeVal1 as $k1=>$v1){
   if(isset($_POST[$k1])){
    if($_POST[$k1]!=''){
     $_SESSION[PGMK][$k1]=$_POST[$k1];   
    }else{
     unset($_SESSION[PGMK][$k1]);
    }
   }
  }
 }
 header('Location: '.BNF.'');
 exit();
}
//=============================================================================================================================
//=============================================================================================================================
//=============================================================================================================================
if(isset($_GET) && sizeof($_GET)>0){
 //========================================
 if(isset($_GET['action']) && $_GET['action']=='setIncVersion'){
  $arrFileInc=file('za_inc.php');
  foreach($arrFileInc as $k1 => $v1){
   if(substr($v1,0,16)=='$GLOBALS[\'vrsi\']'){ // $GLOBALS['vrsi']='171118-1000'; // version
    $arrFileInc[$k1]='$GLOBALS[\'vrsi\']=\''.date('Ymd-Hi').'\'; // version'.CRLF;
   }
  }
  if($fdincphp=fopen('za_inc.php','w')){ 
   foreach($arrFileInc as $k1 => $v1){
    fwrite($fdincphp, $v1 ); 
   }
   fclose($fdincphp); 
  }
  header('Location: '.BNF.'');
  exit();
 }
 //========================================
}
//=============================================================================================================================
//=============================================================================================================================
//=============================================================================================================================
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_GET , true ) . '</pre>' ; exit(0);

$databaseTableLocalButNotDistant=array();
$databaseFieldLocalButNotDistant=array();
$databaseFieldDifferents=array();
if(isset($_GET) && sizeof($_GET)>0){
 if(isset($_GET['action']) && $_GET['action']=='analyseDbFiles'){
  require_once('zzz_tmp_database_distant.php');
  require_once('zzz_tmp_database_local.php');
  
  if(sizeof($GLOBALS['__db']['database_local']) == sizeof($GLOBALS['__db']['database_distant'])){
   foreach($GLOBALS['__db']['database_local'] as $k1 => $v1){
    if(sizeof($GLOBALS['__db']['database_local'][$k1])==sizeof($GLOBALS['__db']['database_distant'][$k1])){
     foreach($GLOBALS['__db']['database_local'][$k1] as $k2 => $v2){
      if(isset($GLOBALS['__db']['database_distant'][$k1][$k2])){
       if(sizeof($databaseTableLocalButNotDistant)==0){
        foreach($GLOBALS['__db']['database_local'][$k1][$k2]['fields'] as $k3 => $v3){
         if(isset($GLOBALS['__db']['database_distant'][$k1][$k2]['fields'][$k3])){
          
          if(sizeof($databaseFieldLocalButNotDistant)==0){
           if( $GLOBALS['__db']['database_local'][$k1][$k2]['fields'][$k3]['type_champ'] == $GLOBALS['__db']['database_distant'][$k1][$k2]['fields'][$k3]['type_champ'] && 
               $GLOBALS['__db']['database_local'][$k1][$k2]['fields'][$k3]['Collation']  == $GLOBALS['__db']['database_distant'][$k1][$k2]['fields'][$k3]['Collation'] && 
               $GLOBALS['__db']['database_local'][$k1][$k2]['fields'][$k3]['champ_cle']  == $GLOBALS['__db']['database_distant'][$k1][$k2]['fields'][$k3]['champ_cle'] && 
               $GLOBALS['__db']['database_local'][$k1][$k2]['fields'][$k3]['val_defaut'] == $GLOBALS['__db']['database_distant'][$k1][$k2]['fields'][$k3]['val_defaut'] && 
               $GLOBALS['__db']['database_local'][$k1][$k2]['fields'][$k3]['extra']      == $GLOBALS['__db']['database_distant'][$k1][$k2]['fields'][$k3]['extra'] && 
               $GLOBALS['__db']['database_local'][$k1][$k2]['fields'][$k3]['comment']    == $GLOBALS['__db']['database_distant'][$k1][$k2]['fields'][$k3]['comment']
           ){
           }else{
            $databaseFieldDifferents[]=array(
             'database' => $k1 ,
             'table'    => $k2 ,
             'local' => $GLOBALS['__db']['database_local'][$k1][$k2]['fields'][$k3],
             'distant' => $GLOBALS['__db']['database_distant'][$k1][$k2]['fields'][$k3],
            );
           }
          }
         }else{
          $databaseFieldLocalButNotDistant[]=array(
           'database' => $k1 ,
           'table'    => $k2 ,
           'field'    => $v3 ,
          );
//          echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $k3 , true ) . '</pre>' ; exit(0);
         }
         
        }
       }
      }else{
       $databaseTableLocalButNotDistant[]=$k2;
      }
     }
    }else{
     echo __FILE__ . ' ' . __LINE__ . ' todo = <pre>' . var_export( $GLOBALS['__db']['database_local'][$k1] , true ) . '</pre> __LINE__ = <pre>' . var_export( sizeof($GLOBALS['__db']['database_distant'][$k1]) , true ) . '</pre>' ; exit(0);
    }
   }
  }else{
   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
  }
 }
}

//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $databaseFieldDifferents , true ) . '</pre>' ; exit(0);


$filesRemoteButShouldNotBe=array();
$lstDifferentFileSize=array();
$presentInLocalAndAbsentOnRemote=array();
$lstSpecialFiles=array();
if(isset($_GET) && sizeof($_GET)>0){
 if(isset($_GET['action']) && $_GET['action']=='analyseFtpFiles'){
  $newTab=array();
  include 'zzz_tmp_ftp.php';
  if(isset($GLOBALS['__ftp']) && sizeof($GLOBALS['__ftp']) ){
   $curDir='/'.$GLOBALS['__ftp']['distantDir'];
   foreach( $GLOBALS['__ftp']['data'] as $k1 => $v1){
    $key=sha1($v1['name']);
    if(strpos($v1['name'],'/')!==false){
     $filename=substr($v1['name'],strrpos($v1['name'],'/')+1);
     $curDir=substr($v1['name'],0,strrpos($v1['name'],'/'));
    }else{
     $filename=$v1['name'];
     $curDir='';
    }
    $newTab[$key]=array(
     'filename'  => $filename   ,
     'curDir'    => $curDir     ,
     'filesize'  => $v1['size'] ,
     'path'      => $v1['name'] ,
     'fileTimeDistant'  => $v1['time']  ,
    );
   }
  }
//  echo __FILE__ . ' ' . __LINE__ . ' $newTab = <pre>' . var_export( $newTab , true ) . '</pre>' ; exit(0);
  foreach($newTab as $k1 => $v1){
   if($GLOBALS['glob_incPathAreInSubFolders']==true){
    $thePath=$v1['path'];
   }else{
    $thePath='../'.$v1['path'];
   }
   if(is_file($thePath)){
    $newTab[$k1]['presentInBoth']=true;
    $newTab[$k1]['fileTimeLocal']=date('Y-m-d H:i:s',filemtime($thePath));
    $newTab[$k1]['fileSizeLocal']=filesize($thePath);
    if(filesize($thePath)==$v1['filesize']){
     $newTab[$k1]['sameFileSize']=true;
    }else{
     $newTab[$k1]['sameFileSize']=false;
     $lstDifferentFileSize[$k1]=$newTab[$k1];
    }
   }else{
    $newTab[$k1]['presentInBoth']=false;    
    $newTab[$k1]['absentInLocalhost']=true;    
   }
   if($v1['filename']=='__pageList.php' || $v1['filename']=='za_inc.php' ){
    if(is_file($thePath)){
     $lstSpecialFiles[$k1]=$newTab[$k1];
    }
   }
  }
//  echo __FILE__ . ' ' . __LINE__ . ' $newTab = <pre>' . var_export( $newTab , true ) . '</pre>' ; exit(0);
  
  if(sizeof($lstSpecialFiles)>0){
   if($fdftp=fopen('zzz_tmp_ftp_lstSpecialFiles.php','w')){
    fwrite($fdftp,'<'.'?php'.CRLF);
    fwrite($fdftp,'$GLOBALS[\'__ftp_lstSpecialFiles\'][\'data\']='.var_export($lstSpecialFiles,true).';');
    fclose($fdftp);
   }   
  }else{
   if($fdftp=fopen('zzz_tmp_ftp_lstSpecialFiles.php','w')){
    fwrite($fdftp,'<'.'?php'.CRLF);
    fwrite($fdftp,'$GLOBALS[\'__ftp_lstSpecialFiles\'][\'data\']=array();');
    fclose($fdftp);
   }      
  }
  if(sizeof($lstDifferentFileSize)>0){
   if($fdftp=fopen('zzz_tmp_ftp_lstDifferentFileSize.php','w')){
    fwrite($fdftp,'<'.'?php'.CRLF);
    fwrite($fdftp,'$GLOBALS[\'__ftp_lstDifferentFileSize\'][\'data\']='.var_export($lstDifferentFileSize,true).';');
    fclose($fdftp);
   }
  }else{
   if($fdftp=fopen('zzz_tmp_ftp_lstDifferentFileSize.php','w')){
    fwrite($fdftp,'<'.'?php'.CRLF);
    fwrite($fdftp,'$GLOBALS[\'__ftp_lstDifferentFileSize\'][\'data\']=array();');
    fclose($fdftp);
   }
  }
  if(sizeof($filesRemoteButShouldNotBe)>0){
   if($fdftp=fopen('zzz_tmp_ftp_filesRemoteButShouldNotBe.php','w')){
    fwrite($fdftp,'<'.'?php'.CRLF);
    fwrite($fdftp,'$GLOBALS[\'__ftp_filesRemoteButShouldNotBe\'][\'data\']='.var_export($filesRemoteButShouldNotBe,true).';');
    fclose($fdftp);
   }   
  }else{
   if($fdftp=fopen('zzz_tmp_ftp_filesRemoteButShouldNotBe.php','w')){
    fwrite($fdftp,'<'.'?php'.CRLF);
    fwrite($fdftp,'$GLOBALS[\'__ftp_filesRemoteButShouldNotBe\'][\'data\']=array();');
    fclose($fdftp);
   }      
  }
  
//  echo __FILE__ . ' ' . __LINE__ . ' $newTab = <pre>' . var_export( $newTab , true ) . '</pre>' ; exit(0);
  if($GLOBALS['glob_incPathAreInSubFolders']==true){
   $localFiles1=read_all_files('.');
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $localFiles1 , true ) . '</pre>' ; exit(0);
   foreach($localFiles1['files'] as $k1 => $v1){
    $localFiles['files'][]=substr($v1,2);
   }
   $localFiles['dirs']=$localFiles1['dirs'];
  }else{
   $localFiles=read_all_files('../');
  }
//  echo __FILE__ . ' ' . __LINE__ . ' $newTab= <pre>' . var_export( $newTab , true ) . '</pre> localFiles = <pre>' . var_export( $localFiles , true ) . '</pre>' ; exit(0);
  
//  echo __FILE__ . ' ' . __LINE__ . ' $newTab = <pre>' . var_export( $newTab , true ) . '</pre>' ; exit(0);
/*

'1863a92f39a1d705060993e8f0bbe9b255bf5774' => 1863a92f39a1d705060993e8f0bbe9b255bf5774
  array (
    'filename' => 'clients1.php',
    'curDir' => '',
    'filesize' => 11481,
    'path' => 'clients1.php',
    'fileTimeDistant' => '2017-12-08 18:20:37',
    'presentInBoth' => true,
    'fileTimeLocal' => '2017-12-01 16:23:28',
    'fileSizeLocal' => 11481,
    'sameFileSize' => true,
  ),

*/  
  
//  echo __FILE__ . ' ' . __LINE__ . ' $localFiles = <pre>' . var_export( $localFiles , true ) . '</pre>' ; exit(0);
  
  foreach( $localFiles['files'] as $k1=>$v1){
   
   $msha1=sha1($v1);
   if(!isset($newTab[$msha1])){
    if(strpos($v1,'/')!==false){
     $filename=substr($v1,strrpos($v1,'/')+1);
     $curDir=substr($v1,0,strrpos($v1,'/'));
    }else{
     $filename=$v1;
     $curDir='';
    }

    $presentInLocalAndAbsentOnRemote[$msha1]=array(
     'filename' => $filename,
     'curDir'   => $curDir,
     'filesize' => filesize($v1),
     'path'     => $v1,
    );
   }
  }
//  echo __FILE__ . ' ' . __LINE__ . ' $presentInLocalAndAbsentOnRemote = <pre>' . var_export( $presentInLocalAndAbsentOnRemote , true ) . '</pre>' ; exit(0);
  if(sizeof($presentInLocalAndAbsentOnRemote)>0){
   if($fdftp=fopen('zzz_tmp_ftp_presentInLocalAndAbsentOnRemote.php','w')){
    fwrite($fdftp,'<'.'?php'.CRLF);
    fwrite($fdftp,'$GLOBALS[\'__ftp_presentInLocalAndAbsentOnRemote\'][\'data\']='.var_export($presentInLocalAndAbsentOnRemote,true).';');
    fclose($fdftp);
   }   
  }
//  echo __FILE__ . ' ' . __LINE__ . ' $lstDifferentFileSize = <pre>' . var_export( $lstDifferentFileSize , true ) . '</pre> $presentInLocalAndAbsentOnRemote = <pre>' . var_export( $presentInLocalAndAbsentOnRemote , true ) . '</pre>' ; exit(0);
  
 }
}
//========================================================================================================================
function read_all_files($root = '.'){ 
  $files  = array('files'=>array(), 'dirs'=>array()); 
  $directories  = array(); 
  $last_letter  = $root[strlen($root)-1]; 
  $root  = ($last_letter == '\\' || $last_letter == '/') ? $root : $root.DIRECTORY_SEPARATOR; 
  
  $directories[]  = $root; 
  
  while (sizeof($directories)) { 
    $dir  = array_pop($directories); 
    if ($handle = opendir($dir)) { 
      while (false !== ($file = readdir($handle))) { 
        if ($file == '.' || $file == '..') { 
          continue; 
        } 
        $file  = $dir.$file; 
        if (is_dir($file)) { 
          $directory_path = $file.DIRECTORY_SEPARATOR; 
          array_push($directories, $directory_path); 
          $files['dirs'][]  = str_replace('\\','/',$directory_path); 
        } elseif (is_file($file)) { 
          $files['files'][]  = str_replace( '../' , '' , str_replace('\\','/',$file ));
        } 
      } 
      closedir($handle); 
    } 
  } 
  return $files; 
} 

//========================================================================================================================
$o1='';
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_11_18').'</h1>';
$o1.=displaySessionMessage1(BNF);


$o1.='<a href="?action=setIncVersion">'.txt2('update inc version_505_46').'</a>';
$o1.='<br />';

$o1.='<form method="post">'.CRLF;
$o1.='<div class="fdiv1 form-group row">'.CRLF;
$o1.='  <div class="finp1"><div>'.CRLF;
$o1.='   <input type="hidden" name="action" value="setMaintenance" />'.CRLF;
if(!isset($_SESSION[PGMK]['maintenance'])){
 if(isset($_SESSION[PGMK]['ftp__server']) && isset($_SESSION[PGMK]['ftp__user']) && isset($_SESSION[PGMK]['ftp__password'])){
  $o1.='   <button type="submit">'.txt2('set maintenance to on_395_65').'</button>'.CRLF;
 }else{
  $o1.='   '.txt2('Set ftp parameters to be able to set maintenance to on_397_19').''.CRLF;  
 }
}else{
 $o1.='   <button type="submit" class="btn btn-warning">'.txt2('set maintenance to off_400_64').'</button>'.CRLF;
}
$o1.='  </div></div>'.CRLF;
$o1.='</div>'.CRLF;
$o1.='</form>'.CRLF;



if(sizeof($databaseFieldDifferents)>0){
 $htafilSizes='';
 foreach($databaseFieldDifferents as $k1 => $v1){
  $htafilSizes.='<tr id="'.$k1.'">';
  $htafilSizes.='<td>';
  $htafilSizes.=$v1['database'];
  $htafilSizes.='</td>';
  $htafilSizes.='<td>';
  $htafilSizes.=$v1['table'];
  $htafilSizes.='</td>';
  $htafilSizes.='<td>';
  $htafilSizes.='<pre>'.var_export($v1['local'],true).'</pre>';
  $htafilSizes.='</td>';
  $htafilSizes.='<td>';
  $htafilSizes.='<pre>'.var_export($v1['distant'],true).'</pre>';
  $htafilSizes.='</td>';
  $htafilSizes.='</tr>';
 }
 if($htafilSizes!=''){
  $o1.='<table class="tableResult1" id="databaseFieldDifferents">';
  $o1.='<thead class="thead-inverse">';
  $o1.='<th style="text-align:center;">fields differents in database</th>';
  $o1.='<th style="text-align:center;">table</th>';
  $o1.='<th style="text-align:center;">local</th>';
  $o1.='<th style="text-align:center;">distant</th>';
  $o1.='</thead><tbody>'.CRLF;
  $o1.=$htafilSizes;
  $o1.='</tbody></table>'.CRLF;
 }
 
}
if(sizeof($databaseFieldLocalButNotDistant)>0){
 $htafilSizes='';
 foreach($databaseFieldLocalButNotDistant as $k1 => $v1){
  $htafilSizes.='<tr id="'.$k1.'">';
  $htafilSizes.='<td>';
  $htafilSizes.=$v1['database'];
  $htafilSizes.='</td>';
  $htafilSizes.='<td>';
  $htafilSizes.=$v1['table'];
  $htafilSizes.='</td>';
  $htafilSizes.='<td>';
  $htafilSizes.='<pre>'.var_export($v1['field'],true).'</pre>';
  $htafilSizes.='</td>';
  $htafilSizes.='</tr>';
 }
 if($htafilSizes!=''){
  $o1.='<table class="tableResult1" id="databaseFieldLocalButNotDistant">';
  $o1.='<thead class="thead-inverse">';
  $o1.='<th style="text-align:center;">fields absent in remote database</th>';
  $o1.='<th style="text-align:center;">table</th>';
  $o1.='<th style="text-align:center;">field</th>';
  $o1.='</thead><tbody>'.CRLF;
  $o1.=$htafilSizes;
  $o1.='</tbody></table>'.CRLF;
 }
 
}

@include 'zzz_tmp_database_distant.php';  
@include 'zzz_tmp_database_local.php';  
if(isset($GLOBALS['__db']['database_distant']) && isset($GLOBALS['__db']['database_local']) ){
 $o1.='<form method="get">'.CRLF;
 $o1.=' <div class="fdiv1 form-group row">'.CRLF;
 $o1.='  <div class="finp1"><div>'.CRLF;
 $o1.='   <input type="hidden" name="action" value="analyseDbFiles" />'.CRLF;
 $o1.='   <button type="submit" class="btn btn-primary">'.txt2('analyse db file_474_64').'</button>'.CRLF;
 $o1.='  </div></div>'.CRLF;
 $o1.=' </div>'.CRLF;
 $o1.='</form>'.CRLF;
}


if( isset($_SESSION[PGMK]['distant_host']) && isset($_SESSION[PGMK]['maintenance']) && $_SESSION[PGMK]['maintenance'] == true ){
 $o1.='<form method="post">'.CRLF;
 $o1.='<div class="fdiv1 form-group row">'.CRLF;
 $o1.='  <div class="finp1"><div>'.CRLF;
 $o1.='   <input type="hidden" name="action" value="getDatabaseDefinitionFromServer" />'.CRLF;
 $o1.='   <button type="submit" class="btn btn-primary">'.txt2('get database definition from server_486_64').'</button>'.CRLF;
 $o1.='  </div></div>'.CRLF;
 $o1.='</div>'.CRLF;
 $o1.='</form>'.CRLF;
}else{
 $o1.='  '.txt2('Set maintenance to on and table prefix to get database definition from server_491_17').''.CRLF; 
}

$o1.='<form method="post" style="border:1px red solid;">'.CRLF;
foreach($arrDb as $k1=> $v1){
 $o1.=' <div class="fdiv1 form-group">'.CRLF;
 $o1.='  <div class="flab1">'.CRLF;
 $o1.='   <div>'.$k1.'</div>'.CRLF;
 $o1.='  </div>'.CRLF;
 $o1.='  <div class="finp1">'.CRLF;
 $o1.='   <div>'.CRLF;
 $o1.='    <input name="'.$k1.'" id="'.$k1.'" maxlength="64" autocomplete="off" '.CRLF;
 $o1.=' type="text" ';
 if(!isset($_SESSION[PGMK][$k1])){
  $o1.='    value="" style="width:100%;max-width:64em;background-color:red;" />';
 }else{
  $o1.='    value="'.enti1($_SESSION[PGMK][$k1]).'" style="width:100%;max-width:64em;" />';   
 }
 $o1.='   </div>'.CRLF;
 $o1.='  </div>'.CRLF;
 $o1.=' </div>'.CRLF; 
}
$o1.='<div class="fdiv1 form-group">'.CRLF;
$o1.='  <div class="finp1"><div>'.CRLF;
$o1.='   <input type="hidden" name="action" value="getLocalDatabases" />'.CRLF;
$o1.='   <button type="submit" class="btn btn-primary">'.txt2('set table prefix_516_63').'</button>'.CRLF;
$o1.='  </div></div>'.CRLF;
$o1.='</div>'.CRLF;
$o1.='</form>'.CRLF;



if(sizeof($filesRemoteButShouldNotBe)>0){
 $htafilSizes='';
 foreach($filesRemoteButShouldNotBe as $k1 => $v1){
  $htafilSizes.='<tr id="'.$k1.'">';
  $htafilSizes.='<td>';
  $htafilSizes.=$v1['path'];
  $htafilSizes.='</td>';
  $htafilSizes.='<td style="text-align:center;">';
  $htafilSizes.='<input type="checkbox" id="checkDeleteFromServer_'.$k1.'" />';
  $htafilSizes.='</td>';
  $htafilSizes.='</tr>';
 }
 if($htafilSizes!=''){
  $o1.='<table class="tableResult1" id="filesRemoteButShouldNotBe1">';
  $o1.='<thead class="thead-inverse">';
  $o1.='<th style="text-align:center;">file present on remote but should not be</th>';
  $o1.='<th style="text-align:center;">';
  $o1.='<button type="button" onclick="deleteFromSever1(\'filesRemoteButShouldNotBe1\',\'checkDeleteFromServer_\')">'.txt2('delete from server_540_124').'</button>';
  $o1.='<br />';
  $o1.='<input type="checkbox" id="checkDeleteFromServer1" onclick="checkAll1(\'checkDeleteFromServer1\',\'filesRemoteButShouldNotBe1\',\'checkDeleteFromServer_\')" />';
  $o1.='</th>';
  $o1.='</thead><tbody>'.CRLF;
  $o1.=$htafilSizes;
  $o1.='</tbody></table>'.CRLF;
 }
}



if(sizeof($lstSpecialFiles)>0){
 $htafilSizes='';
 foreach($lstSpecialFiles as $k1 => $v1){
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $v1 , true ) . '</pre>' ; exit(0);
  $styspfil1='';
  if($v1['fileTimeLocal']>$v1['fileTimeDistant']){
    $styspfil1='danger';
  }else{
    $styspfil1='success';   
  }
  $htafilSizes.='<tr id="'.$k1.'" class="'.$styspfil1.'">';
  $htafilSizes.='<td>'.$v1['path'].'</td>';
  $htafilSizes.='<td>'.$v1['fileTimeLocal'].'</td>';
  $htafilSizes.='<td>'.$v1['fileTimeDistant'].'</td>';
  $htafilSizes.='<td style="text-align:center;">';
  $htafilSizes.='<input type="checkbox" id="checkPutToServer_'.$k1.'" />';
  $htafilSizes.='</td>';
  $htafilSizes.='</tr>';
 }
 if($htafilSizes!=''){
  $o1.='<table class="tableResult1" id="lstSpecialFiles1">';
  $o1.='<thead class="thead-inverse">';
  $o1.='<th style="text-align:center;">special files</th>';
  $o1.='<th style="text-align:center;">local</th>';
  $o1.='<th style="text-align:center;">distant</th>';
  $o1.='<th style="text-align:center;">';
  $o1.='<button type="button" onclick="putToSever3(\'lstSpecialFiles1\',\'checkPutToServer_\')">'.txt2('to server_570_109').'</button>';
  $o1.='<br />';
  $o1.='<input type="checkbox" id="checkPutToServer3" onclick="checkAll1(\'checkPutToServer3\',\'lstSpecialFiles1\',\'checkPutToServer_\')" />';
  $o1.='</th>';
  $o1.='</thead><tbody>'.CRLF;
  $o1.=$htafilSizes;
  $o1.='</tbody></table>'.CRLF;
 }
}
if(sizeof($lstDifferentFileSize)>0){
 $htafilSizes='';
 foreach($lstDifferentFileSize as $k1 => $v1){
  if(strpos($v1['path'],'/generated/lang/')!==false || 'tdo_inc/__dbaccess.php'==$v1['path'] ){
  }else{
   $htafilSizes.='<tr id="'.$k1.'">';
   $htafilSizes.='<td>';
   $htafilSizes.=$v1['path'];
   $htafilSizes.='</td>';
   $htafilSizes.='<td style="text-align:center;">';
   $htafilSizes.='<input type="checkbox" id="checkPutToServer_'.$k1.'" />';
   $htafilSizes.='</td>';
   $htafilSizes.='</tr>';
  }
 }
 if($htafilSizes!=''){
  $o1.='<table class="tableResult1" id="lstDifferentFileSize1">';
  $o1.='<thead class="thead-inverse">';
  $o1.='<th style="text-align:center;">file present on both with different sizes<br />( not /generated/lang/ )</th>';
  $o1.='<th style="text-align:center;">';
  $o1.='<button type="button" onclick="putToSever1(\'lstDifferentFileSize1\',\'checkPutToServer_\')">'.txt2('to server_570_109').'</button>';
  $o1.='<br />';
  $o1.='<input type="checkbox" id="checkPutToServer1" onclick="checkAll1(\'checkPutToServer1\',\'lstDifferentFileSize1\',\'checkPutToServer_\')" />';
  $o1.='</th>';
  $o1.='</thead><tbody>'.CRLF;
  $o1.=$htafilSizes;
  $o1.='</tbody></table>'.CRLF;
 }
}

if(sizeof($lstDifferentFileSize)>0){
 $htafilSizes='';
 foreach($lstDifferentFileSize as $k1 => $v1){
  if(strpos($v1['path'],'/generated/lang/')!==false){
   $htafilSizes.='<tr id="'.$k1.'">';
   $htafilSizes.='<td>';
   $htafilSizes.=$v1['path'];
   $htafilSizes.='</td>';
   $htafilSizes.='<td style="text-align:center;">';
   $htafilSizes.='<input type="checkbox" id="checkPutToServer_'.$k1.'" />';
   $htafilSizes.='</td>';
   $htafilSizes.='</tr>';
  }
 }
 if($htafilSizes!=''){
  $o1.='<table class="tableResult1" id="lstDifferentFileSize2">';
  $o1.='<thead class="thead-inverse">';
  $o1.='<th style="text-align:center;">file present on both with different sizes<br />( only /generated/lang/ )</th>';
  $o1.='<th style="text-align:center;">';
  $o1.='<button type="button" onclick="putToSever1(\'lstDifferentFileSize2\',\'checkPutToServer_\')">'.txt2('to server_570_109').'</button>';
  $o1.='<br />';
  $o1.='<input type="checkbox" id="checkPutToServer2" onclick="checkAll1(\'checkPutToServer2\',\'lstDifferentFileSize2\',\'checkPutToServer_\')" />';
  $o1.='</th>';
  $o1.='</thead><tbody>'.CRLF;
  $o1.=$htafilSizes;
  $o1.='</tbody></table>'.CRLF;
 }
}

if(sizeof($presentInLocalAndAbsentOnRemote)>0){
 $htafilSizes='';
 foreach($presentInLocalAndAbsentOnRemote as $k1 => $v1){
  if(isset($v1['isRemote']) && $v1['isRemote'] == '0'){
   
  }else{
   $htafilSizes.='<tr id="'.$k1.'">';
   $htafilSizes.='<td>';
   $htafilSizes.=$v1['path'];
   $htafilSizes.='</td>';
   $htafilSizes.='<td style="text-align:center;">';
   $htafilSizes.='<input type="checkbox" id="checkPutToServer_'.$k1.'" />';
   $htafilSizes.='</td>';
   $htafilSizes.='</tr>';
  }
 }
 if($htafilSizes!=''){
  $o1.='<table class="tableResult1" id="lstDifferentFileSize3">';
  $o1.='<thead class="thead-inverse">';
  $o1.='<th style="text-align:center;">file present localhost but absent on remote<br />&nbsp;</th>';
  $o1.='<th style="text-align:center;">';
  $o1.='<button type="button" onclick="putToSever2(\'lstDifferentFileSize3\',\'checkPutToServer_\')">'.txt2('to server_570_109').'</button>';
  $o1.='<br />';
  $o1.='<input type="checkbox" id="checkPutToServer3" onclick="checkAll1(\'checkPutToServer3\',\'lstDifferentFileSize3\',\'checkPutToServer_\')" />';
  $o1.='</th>';
  $o1.='</thead><tbody>'.CRLF;
  $o1.=$htafilSizes;
  $o1.='</tbody></table>'.CRLF;
 }
}




$allIsSet=true;
foreach($listeVal1 as $k1=>$v1){
 if(!isset($_SESSION[PGMK][$k1])){
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $k1 , true ) . '</pre>' ; exit(0);
  $allIsSet=false;
 }
}

@include 'zzz_tmp_ftp.php';  
if(isset($GLOBALS['__ftp']) && sizeof($GLOBALS['__ftp']) ){
 $o1.='<form method="get">'.CRLF;
 $o1.=' <div class="fdiv1 form-group row">'.CRLF;
 $o1.='  <div class="finp1"><div>'.CRLF;
 $o1.='   <input type="hidden" name="action" value="analyseFtpFiles" />'.CRLF;
 $o1.='   <button type="submit" class="btn btn-primary">'.txt2('analyse ftp file_657_64').'</button>'.CRLF;
 $o1.='  </div></div>'.CRLF;
 $o1.=' </div>'.CRLF;
 $o1.='</form>'.CRLF;
}
if($allIsSet==true){
 $o1.='<div>Ftp parameters are good</div>';
 $o1.='<form method="post">'.CRLF;
 $o1.=' <div class="fdiv1 form-group row">'.CRLF;
 $o1.='  <div class="finp1"><div>'.CRLF;
 $o1.='   <input type="hidden" name="action" value="tryFtpParam2" />'.CRLF;
 $o1.='   <button type="submit" class="btn btn-primary">'.txt2('get ftp distant files_668_64').'</button>'.CRLF;
 $o1.='  </div></div>'.CRLF;
 $o1.=' </div>'.CRLF;
 $o1.='</form>'.CRLF;
 
}


//==============================================================================================================
//========================== FTP FORM ==========================================================================
//==============================================================================================================
$o1.='<form method="post" style="border:1px red solid;">'.CRLF;
foreach($listeVal1 as $k1=>$v1){
 $o1.=' <div class="fdiv1 form-group">'.CRLF;
 $o1.='  <div class="flab1">'.CRLF;
 $o1.='   <div>'.$k1.'</div>'.CRLF;
 $o1.='  </div>'.CRLF;
 $o1.='  <div class="finp1">'.CRLF;
 $o1.='   <div>'.CRLF;
 $o1.='    <input name="'.$k1.'" id="'.$k1.'" maxlength="64" autocomplete="off" '.CRLF;
 if(isset($v1['password']) && $v1['password']==true){
  $o1.=' type="password" ';
 }else{
  $o1.=' type="text" ';
 }
 if(!isset($_SESSION[PGMK][$k1])){
  $o1.='    value="" style="width:100%;max-width:64em;background-color:red;" />';
 }else{
  $o1.='    value="'.enti1($_SESSION[PGMK][$k1]).'" style="width:100%;max-width:64em;" />';   
 }
 $o1.='   </div>'.CRLF;
 $o1.='  </div>'.CRLF;
 $o1.=' </div>'.CRLF;
}
$o1.='<div class="fdiv1 form-group">'.CRLF;
$o1.='  <div class="finp1"><div>'.CRLF;
$o1.='   <input type="hidden" name="action" value="setFtpParam1" />'.CRLF;
$o1.='   <button type="submit" class="btn btn-primary">'.txt2('save the ftp values_705_63').'</button>'.CRLF;
$o1.='  </div></div>'.CRLF;
$o1.='</div>'.CRLF;
$o1.='</form>'.CRLF;
 

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();