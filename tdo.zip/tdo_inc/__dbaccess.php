<?php
$GLOBALS['glob_db'][0]['server']   ='localhost:3306';
$GLOBALS['glob_db'][0]['user']     ='admin';
$GLOBALS['glob_db'][0]['password'] ='admin';
$GLOBALS['glob_db'][0]['dbname']   ='tdo';
$GLOBALS['glob_db'][0]['link']     =null;
