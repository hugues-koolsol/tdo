<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb2();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_name_uploadedDocs
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_originalName_uploadedDocs
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_isPicture_uploadedDocs
$xsrch_3=saveSessionSearch1('xsrch_3',BNF);// fld_pictureWidth_uploadedDocs
$xsrch_4=saveSessionSearch1('xsrch_4',BNF);// fld_pictureHeight_uploadedDocs
$xsrch_5=saveSessionSearch1('xsrch_5',BNF);// fld_documentType_uploadedDocs
$xsrch_6=saveSessionSearch1('xsrch_6',BNF);// fld_pictureWeight_uploadedDocs
$xsrch_7=saveSessionSearch1('xsrch_7',BNF);// fld_path_uploadedDocs
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_uploadedDocs
if($xsrch_3!=''){
 if(!is_numeric($xsrch_3)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_29_92') . ' : ' . txt2('fld_pictureWidth_uploadedDocs_29_152');
 }
}
if($xsrch_4!=''){
 if(!is_numeric($xsrch_4)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_29_92') . ' : ' . txt2('fld_pictureHeight_uploadedDocs_34_152');
 }
}
if($xsrch_6!=''){
 if(!is_numeric($xsrch_6)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_29_92') . ' : ' . txt2('fld_pictureWeight_uploadedDocs_39_152');
 }
}
if($xsrch_id!=''){
 if(!is_numeric($xsrch_id)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_29_92') . ' : ' . txt2('fld_id_uploadedDocs_44_152');
 }
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; } // fld_name_uploadedDocs
else if($xsrch_1!=''){ $autofocus='xsrch_1'; } // fld_originalName_uploadedDocs
else if($xsrch_2!=''){ $autofocus='xsrch_2'; } // fld_isPicture_uploadedDocs
else if($xsrch_3!=''){ $autofocus='xsrch_3'; } // fld_pictureWidth_uploadedDocs
else if($xsrch_4!=''){ $autofocus='xsrch_4'; } // fld_pictureHeight_uploadedDocs
else if($xsrch_5!=''){ $autofocus='xsrch_5'; } // fld_documentType_uploadedDocs
else if($xsrch_6!=''){ $autofocus='xsrch_6'; } // fld_pictureWeight_uploadedDocs
else if($xsrch_7!=''){ $autofocus='xsrch_7'; } // fld_path_uploadedDocs
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_list_58_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="filterForm">'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_name_uploadedDocs_64_39').'</label>'.CRLF; // fld_name_uploadedDocs
$o1.='    <input '.($xsrch_0!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_0" id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_1">'.txt2('fld_originalName_uploadedDocs_70_39').'</label>'.CRLF; // fld_originalName_uploadedDocs
$o1.='    <input '.($xsrch_1!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_1" id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_2">'.txt2('fld_isPicture_uploadedDocs_76_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_2!=''?'class="backgroundYellow"':'').' name="xsrch_2"  id="xsrch_2" '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" />'.CRLF;
$o1.='<option value="" '.($xsrch_2==''?'  selected="selected" ':'').'> </option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_2){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_3">'.txt2('fld_pictureWidth_uploadedDocs_29_152').'</label>'.CRLF; // fld_pictureWidth_uploadedDocs
$o1.='    <input '.($xsrch_3!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_3" id="xsrch_3"   value="'.enti1($xsrch_3).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_3'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_4">'.txt2('fld_pictureHeight_uploadedDocs_34_152').'</label>'.CRLF; // fld_pictureHeight_uploadedDocs
$o1.='    <input '.($xsrch_4!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_4" id="xsrch_4"   value="'.enti1($xsrch_4).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_4'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_5">'.txt2('fld_documentType_uploadedDocs_103_39').'</label>'.CRLF; // fld_documentType_uploadedDocs
$o1.='    <input '.($xsrch_5!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_5" id="xsrch_5"   value="'.enti1($xsrch_5).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_5'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_6">'.txt2('fld_pictureWeight_uploadedDocs_39_152').'</label>'.CRLF; // fld_pictureWeight_uploadedDocs
$o1.='    <input '.($xsrch_6!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_6" id="xsrch_6"   value="'.enti1($xsrch_6).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_6'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_7">'.txt2('fld_path_uploadedDocs_115_39').'</label>'.CRLF; // fld_path_uploadedDocs
$o1.='    <input '.($xsrch_7!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_7" id="xsrch_7"   value="'.enti1($xsrch_7).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_7'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_uploadedDocs_44_152').'</label>'.CRLF; // fld_id_uploadedDocs
$o1.='    <input '.($xsrch_id!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">🔎</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_uploadedDocs`            ,T0.`fld_name_uploadedDocs`          ,T0.`fld_originalName_uploadedDocs`  ,T0.`fld_isPicture_uploadedDocs`     ,T0.`fld_pictureWidth_uploadedDocs`  ,
   T0.`fld_pictureHeight_uploadedDocs` ,T0.`fld_documentType_uploadedDocs`  ,T0.`fld_pictureWeight_uploadedDocs` ,T0.`fld_path_uploadedDocs`          
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__uploadedDocs` T0 ) 
 WHERE 1=1 
';
if($xsrch_0!='' ){
 $req6.='
  AND T0.`fld_name_uploadedDocs` LIKE \'%'.addslashes1($xsrch_0).'%\'
 '; 
}
if($xsrch_1!='' ){
 $req6.='
  AND T0.`fld_originalName_uploadedDocs` LIKE \'%'.addslashes1($xsrch_1).'%\'
 '; 
}
if($xsrch_2!='' ){
 $req6.='
  AND T0.`fld_isPicture_uploadedDocs` LIKE \'%'.addslashes1($xsrch_2).'%\'
 '; 
}
if($xsrch_3!='' && is_numeric($xsrch_3)){
 $req6.='
  AND T0.`fld_pictureWidth_uploadedDocs` = '.$xsrch_3.'
 '; 
}
if($xsrch_4!='' && is_numeric($xsrch_4)){
 $req6.='
  AND T0.`fld_pictureHeight_uploadedDocs` = '.$xsrch_4.'
 '; 
}
if($xsrch_5!='' ){
 $req6.='
  AND T0.`fld_documentType_uploadedDocs` LIKE \'%'.addslashes1($xsrch_5).'%\'
 '; 
}
if($xsrch_6!='' && is_numeric($xsrch_6)){
 $req6.='
  AND T0.`fld_pictureWeight_uploadedDocs` = '.$xsrch_6.'
 '; 
}
if($xsrch_7!='' ){
 $req6.='
  AND T0.`fld_path_uploadedDocs` LIKE \'%'.addslashes1($xsrch_7).'%\'
 '; 
}
if($xsrch_id!='' && is_numeric($xsrch_id)){
 $req6.='
  AND T0.`fld_id_uploadedDocs` = '.$xsrch_id.'
 '; 
}
$req6.='
 ORDER BY T0.`fld_id_uploadedDocs` DESC 
'; 
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$__count=0;
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'T0.fld_id_uploadedDocs'=>$mpsr6[0], 
  'T0.fld_name_uploadedDocs'=>$mpsr6[1], 
  'T0.fld_originalName_uploadedDocs'=>$mpsr6[2], 
  'T0.fld_isPicture_uploadedDocs'=>$mpsr6[3], 
  'T0.fld_pictureWidth_uploadedDocs'=>$mpsr6[4], 
  'T0.fld_pictureHeight_uploadedDocs'=>$mpsr6[5], 
  'T0.fld_documentType_uploadedDocs'=>$mpsr6[6], 
  'T0.fld_pictureWeight_uploadedDocs'=>$mpsr6[7], 
  'T0.fld_path_uploadedDocs'=>$mpsr6[8], 
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}
$lsttbl='';
if($__count==0){
 $lst.='<p>'.CRLF;
 $lst.=''.txt2('no_record_founded_224_16').''.CRLF;
 $lst.='<a href="uploadeddocs_action1.php?a=c">'.txt2('add_a_new_record_225_55').'</a>'.CRLF;
 $lst.='</p>'.CRLF;
 $o1.=''.$lst.''.CRLF;  
}else{
 $consUrlRedir=''.
               '&xsrch_0='.rawurlencode($xsrch_0). // fld_name_uploadedDocs 
               '&xsrch_1='.rawurlencode($xsrch_1). // fld_originalName_uploadedDocs 
               '&xsrch_2='.rawurlencode($xsrch_2). // fld_isPicture_uploadedDocs 
               '&xsrch_3='.rawurlencode($xsrch_3). // fld_pictureWidth_uploadedDocs 
               '&xsrch_4='.rawurlencode($xsrch_4). // fld_pictureHeight_uploadedDocs 
               '&xsrch_5='.rawurlencode($xsrch_5). // fld_documentType_uploadedDocs 
               '&xsrch_6='.rawurlencode($xsrch_6). // fld_pictureWeight_uploadedDocs 
               '&xsrch_7='.rawurlencode($xsrch_7). // fld_path_uploadedDocs 
               '&xsrch_id='.rawurlencode($xsrch_id).
               '';
 $ri=' <span class="btn unset">»</span>';
 if($__start+$__nbMax<$__count){
  $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">»</a>';
 }
 $le=' <span class="btn unset">«</span>';
 if($__xpage>0){
  $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">«</a>';
 }

 $o1.='<div>';
 $o1.='<form method="post">';
// $o1.='<button type="submit" name="action1">'.txt0('action1').'</button>';
// $o1.='<button type="submit" name="action2">'.txt0('action2').'</button>';
 $o1.='<a href="uploadeddocs_action1.php?a=c">'.txt2('add_a_new_record_225_55').'</a>'.CRLF;
 $o1.=' '.$le.''.CRLF;  
 $o1.=' '.$ri.''.CRLF;  
 $o1.='</form>';
 $o1.='</div>';

 $o1.=getCss1(890);

 $lsttbl.='<thead><tr>';
 $lsttbl.='<th style="min-width:125px;">'.txtsys1('column_action').'</th>';
 $lsttbl.='<th style="min-width:85px;">'.txt2('fld_id_uploadedDocs_44_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_name_uploadedDocs_64_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_originalName_uploadedDocs_70_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_isPicture_uploadedDocs_76_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_pictureWidth_uploadedDocs_29_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_pictureHeight_uploadedDocs_34_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_documentType_uploadedDocs_103_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_pictureWeight_uploadedDocs_39_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_path_uploadedDocs_115_39').'</th>';
 $lsttbl.='</tr></thead><tbody>';

 foreach($data0 as $k0=>$v0){

  $lsttbl.='<tr>';

  $lsttbl.='<td data-label="'.txtsys1('column_action').'">';
  $lsttbl.='<div>';
  $lsttbl.='<a href="uploadeddocs_action1.php?a=u&id='.$v0['T0.fld_id_uploadedDocs'].'" title="'.txtsys1('edit_button').'">✎</a>';// ✎
  $lsttbl.='<a class="danger" href="uploadeddocs_action1.php?a=d&id='.$v0['T0.fld_id_uploadedDocs'].'" title="'.txtsys1('delete_button').'">✘</a>';// ✘
  $lsttbl.='<a href="uploadeddocs_action1.php?a=du&id='.$v0['T0.fld_id_uploadedDocs'].'" title="'.txtsys1('duplicate_button').'">📋</a>';// 📋 
  $lsttbl.='</div>';
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_id_uploadedDocs_44_152').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_id_uploadedDocs'].''; // fld_id_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_name_uploadedDocs_64_39').'">';
  $lsttbl.=''.$v0['T0.fld_name_uploadedDocs'].''; // fld_name_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_originalName_uploadedDocs_70_39').'">';
  $lsttbl.=''.$v0['T0.fld_originalName_uploadedDocs'].''; // fld_originalName_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_isPicture_uploadedDocs_76_39').'" style="text-align:center;">';
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
  $lsttbl.=displayParam1('yorno',$v0['T0.fld_isPicture_uploadedDocs'],array('unsetPossible'=>false)); // fld_isPicture_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_pictureWidth_uploadedDocs_29_152').'" style="text-align:right;">';
  $lsttbl.=''.$v0['T0.fld_pictureWidth_uploadedDocs'].''; // fld_pictureWidth_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_pictureHeight_uploadedDocs_34_152').'" style="text-align:right;">';
  $lsttbl.=''.$v0['T0.fld_pictureHeight_uploadedDocs'].''; // fld_pictureHeight_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_documentType_uploadedDocs_103_39').'">';
  $lsttbl.=''.$v0['T0.fld_documentType_uploadedDocs'].''; // fld_documentType_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_pictureWeight_uploadedDocs_39_152').'" style="text-align:right;">';
  $lsttbl.=''.$v0['T0.fld_pictureWeight_uploadedDocs'].''; // fld_pictureWeight_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_path_uploadedDocs_115_39').'">';
  $lsttbl.=''.$v0['T0.fld_path_uploadedDocs'].''; // fld_path_uploadedDocs
  $lsttbl.='</td>';

  $lsttbl.='</tr>';

 }

 $o1.='<table class="tableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;

 $o1.=' <div>'.CRLF;
 $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_330_98').' )'.CRLF;
 $o1.='    <a class="buttonAdd" href="uploadeddocs_action1.php?a=c">'.txt2('add_a_new_record_225_55').'</a>'.CRLF;
 $o1.=' </div>'.CRLF;

}

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
