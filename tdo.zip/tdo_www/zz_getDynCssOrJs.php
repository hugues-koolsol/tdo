<?php
//define('BNF',basename( __FILE__ )); 
// line upper is commented because no special auth for this page, 
// if someone wants to read a js or a css, it gives it !
if(isset($_GET['t']) && $_GET['t']=='css'){
 header('Content-Type: text/css; charset=utf-8');  
 $t='.css';
}else if(isset($_GET['t']) && $_GET['t']=='js'){
 header('Content-Type: application/javascript; charset=utf-8');
 $t='.js';
}else{
 exit(0);
}
require_once 'za_inc.php';
if(
    (isset($_GET['n']) && is_numeric($_GET['n']))
 || (isset($_GET['n']) && isset($_GET['c']) && $_GET['c']=='lang' && strlen($_GET['n'])==2)
){
 $n=str_replace('/','',str_replace('..','',$_GET['n']));
 if(!ob_start("ob_gzhandler")) ob_start();
 $offset = 3600 * 24 * 300;
 $ExpStr = "Expires: " . gmdate("D, d M Y H:i:s", time() + $offset) . " GMT";
 Header($ExpStr); 
 if(isset($_GET['c']) && $_GET['c']=='lang'){
  readfile($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/'.$n.'_main'.$t);  
 }else{
  readfile($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/'.$n.$t);
 }
}