<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();


$o1='';
$o1.=htmlHead1(array());
if(isset($_GET['message'])){
 $o1.='<span style="font-size:2em;">'.$_GET['message'].'</span>';
 $o1.='<hr />';
 
}
for($i=0;$i<20;$i++){
 $o1.='page content '.$i.'<br />';
}



$o1.=htmlFoot0(array());
dw1($o1);