<?php
$GLOBALS['glob_grpspgs']=array (
  'todos1.php' => 
  array (
    'm' => '1',
    'o' => '0',
    'aj' => '0',
    'id' => '13',
  ),
  'zz_tables1.php' => 
  array (
    'm' => '1',
    'o' => '1',
    'aj' => '0',
    'id' => '47',
  ),
  'zz_tablelinks1.php' => 
  array (
    'm' => '1',
    'o' => '2',
    'aj' => '0',
    'id' => '20',
  ),
  'zz_generateSources1.php' => 
  array (
    'm' => '1',
    'o' => '3',
    'aj' => '0',
    'id' => '21',
  ),
  'logout.php' => 
  array (
    'm' => '0',
    'o' => '4',
    'aj' => '0',
    'id' => '3',
  ),
  'zz_pages.php' => 
  array (
    'm' => '1',
    'o' => '4',
    'aj' => '0',
    'id' => '9',
  ),
  'zz_groups1.php' => 
  array (
    'm' => '1',
    'o' => '5',
    'aj' => '0',
    'id' => '4',
  ),
  'zz_grpspgs.php' => 
  array (
    'm' => '1',
    'o' => '6',
    'aj' => '0',
    'id' => '10',
  ),
  'zz_paramkeys.php' => 
  array (
    'm' => '1',
    'o' => '7',
    'aj' => '0',
    'id' => '17',
  ),
  'zz_paramrules1.php' => 
  array (
    'm' => '1',
    'o' => '8',
    'aj' => '0',
    'id' => '68',
  ),
  'zz_translate.php' => 
  array (
    'm' => '1',
    'o' => '9',
    'aj' => '0',
    'id' => '16',
  ),
  'zz_users.php' => 
  array (
    'm' => '1',
    'o' => '10',
    'aj' => '0',
    'id' => '12',
  ),
  'uploadeddocs1.php' => 
  array (
    'm' => '1',
    'o' => '11',
    'aj' => '0',
    'id' => '65',
  ),
  'zz_css1.php' => 
  array (
    'm' => '1',
    'o' => '12',
    'aj' => '0',
    'id' => '49',
  ),
  'zz_zztests1.php' => 
  array (
    'm' => '1',
    'o' => '13',
    'aj' => '0',
    'id' => '23',
  ),
  'profile.php' => 
  array (
    'm' => '1',
    'o' => '14',
    'aj' => '0',
    'id' => '41',
  ),
  'login.php' => 
  array (
    'm' => '1',
    'o' => '15',
    'aj' => '0',
    'id' => '2',
  ),
  'index.php' => 
  array (
    'm' => '1',
    'o' => '16',
    'aj' => '0',
    'id' => '1',
  ),
  'zz_synchro1.php' => 
  array (
    'm' => '1',
    'o' => '17',
    'aj' => '0',
    'id' => '43',
  ),
);