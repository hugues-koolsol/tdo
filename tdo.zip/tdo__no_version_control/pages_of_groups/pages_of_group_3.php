<?php
// group 3 : local_admin,m:menu,o:order,aj:ajax
$GLOBALS['glob_grpspgs']=array (
  'uploadeddocs_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 66,
    'remote' => 1,
  ),
  'ajax_updateParam1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 40,
    'remote' => 1,
  ),
  'ajax_translatePageElement1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 89,
    'remote' => 1,
  ),
  'zz_uploadDocument.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 85,
    'remote' => 1,
  ),
  'zz_todos2.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 84,
    'remote' => 1,
  ),
  'zz_log_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 82,
    'remote' => 1,
  ),
  'zz_users_choose1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 79,
    'remote' => 1,
  ),
  'zz_paramnames_choose1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 69,
    'remote' => 1,
  ),
  'ajax_uploaddocs1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 67,
    'remote' => 1,
  ),
  'zz_css_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 50,
    'remote' => 1,
  ),
  'ajax_setSortParamWithoutLang1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 29,
    'remote' => 1,
  ),
  'ajax_setSortParamWithLang1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 27,
    'remote' => 1,
  ),
  'ajax_setSortPagesOfGroup1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 26,
    'remote' => 1,
  ),
  'zz_paramvalues1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 19,
    'remote' => 1,
  ),
  'zz_todos_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 14,
    'remote' => 1,
  ),
  'zz_todos1.php' => 
  array (
    'm' => 1,
    'o' => 0,
    'aj' => 0,
    'id' => 13,
    'remote' => 1,
  ),
  'zz_users_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 8,
    'remote' => 1,
  ),
  'zz_groups_choose1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 6,
    'remote' => 1,
  ),
  'zz_groups_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 5,
    'remote' => 1,
  ),
  'uploadeddocs1.php' => 
  array (
    'm' => 1,
    'o' => 1,
    'aj' => 0,
    'id' => 65,
    'remote' => 1,
  ),
  'zz_paramkeys.php' => 
  array (
    'm' => 1,
    'o' => 2,
    'aj' => 0,
    'id' => 17,
    'remote' => 1,
  ),
  'zz_groups1.php' => 
  array (
    'm' => 1,
    'o' => 3,
    'aj' => 0,
    'id' => 4,
    'remote' => 1,
  ),
  'zz_grpspgs.php' => 
  array (
    'm' => 1,
    'o' => 4,
    'aj' => 0,
    'id' => 10,
    'remote' => 1,
  ),
  'zz_users.php' => 
  array (
    'm' => 1,
    'o' => 5,
    'aj' => 0,
    'id' => 12,
    'remote' => 1,
  ),
  'zz_log1.php' => 
  array (
    'm' => 1,
    'o' => 6,
    'aj' => 0,
    'id' => 81,
    'remote' => 1,
  ),
  'zz_css1.php' => 
  array (
    'm' => 1,
    'o' => 7,
    'aj' => 0,
    'id' => 49,
    'remote' => 1,
  ),
  'index.php' => 
  array (
    'm' => 0,
    'o' => 8,
    'aj' => 0,
    'id' => 1,
    'remote' => 1,
  ),
  'profile.php' => 
  array (
    'm' => 1,
    'o' => 9,
    'aj' => 0,
    'id' => 41,
    'remote' => 1,
  ),
  'login.php' => 
  array (
    'm' => 1,
    'o' => 997,
    'aj' => 0,
    'id' => 2,
    'remote' => 1,
  ),
  'logout.php' => 
  array (
    'm' => 0,
    'o' => 998,
    'aj' => 0,
    'id' => 3,
    'remote' => 1,
  ),
);