var fup1tabObjfileList=[];
var fup1sendingFile=false;
var fup1filecount=0;
var fup1totalSizeOfTheFileS=0;
var fup1sizeUploadedSoFar=0;
var fup1DocumentUploadedList=[];
var fup1TimeOut=64; // 64

function computeFileSize(sizeInBytes){
 var mysize=''; 
 if(sizeInBytes<1024){
  mysize=size+' o';
 }else if(sizeInBytes<1024*1024){
  var size1=parseInt((sizeInBytes/1024),10);
  var size2=String(sizeInBytes-size1*1024).substr(0,1);
  mysize=size1+'.'+size2+' Ko';
 }else{
  var size1=parseInt((sizeInBytes/1024/1024),10);
  var size2=String(sizeInBytes-size1*1024*1024).substr(0,1);
  mysize=size1+'.'+size2+' Mo';
 }
 return mysize;
}

function transfertTermine(){
 document.getElementById('fup1tabObjfileList').innerHTML='Transfert termine ( '+fup1filecount+' )';
 document.getElementById('fileUpload1').innerHTML='<input type="file" name="afile" id="afile" multiple="multiple" />';
 document.querySelector('#afile').addEventListener('change',processFiles,false);
 document.getElementById('fup1DocumentUploadedList').value=JSON.stringify(fup1DocumentUploadedList);
 fup1DocumentUploadedList=[];
 fup1filecount=0;
 setTimeout(
  function(){
   document.getElementById("fileUpload1Form").submit();
  },
  fup1TimeOut
 );
}

function uploadNextFile(){
 document.getElementById('fileUpload1Message').innerHTML='veuillez patienter svp, téléversement du fichier '+fup1filecount+' en cours.';
 if(fup1tabObjfileList.length==0){
  fup1sendingFile=false;
  return;
 }
 if(fup1sendingFile==true){
  setTimeout(uploadNextFile,fup1TimeOut);
 }
 fup1sendingFile=false;
 var file =fup1tabObjfileList.shift();
 fup1filecount++;
 var fd = new FormData();
 fd.append("afile", file);
 var ajaxData=JSON.stringify({'funct' : 'uploaddocs1'}); 
 fd.append("data", ajaxData);
// These extra params aren't necessary but show that you can include other data.
// fd.append("username", "Groucho");
// fd.append("accountnum", 123456);
 var xhr = new XMLHttpRequest();
 xhr.open('POST', 'za_ajax.php', true);
 
 xhr.upload.onprogress = function(e) {
   if(e.lengthComputable){
     var percentComplete = parseInt((e.loaded / e.total) * 100,10);
     if(percentComplete==100){
      fup1sizeUploadedSoFar+=e.loaded;
      var totalCompleted=fup1sizeUploadedSoFar;
     }else{
      var totalCompleted=fup1sizeUploadedSoFar+e.loaded;
     }
//     console.log(percentComplete + '% uploaded');
     if(percentComplete==100){
      document.getElementById('file'+fup1filecount).style.backgroundColor='green';
      fup1sendingFile=false;
     }
     document.getElementById('file'+fup1filecount).style.width=percentComplete+'px';
     document.getElementById('file0').style.width=parseInt(totalCompleted/fup1totalSizeOfTheFileS*100,10)+'px';
   }
 };
 xhr.onload=function() {
   if(this.status == 200) {
     console.log(this.response);
     var resp = JSON.parse(this.response);
     console.log('Server got:', resp);
     if(resp.status=='OK'){
      fup1DocumentUploadedList.push({'data':resp.data});
     }
     document.getElementById('file'+fup1filecount).style.width='100px';
     fup1sendingFile=false;
     if(fup1tabObjfileList.length>0){
      setTimeout(uploadNextFile,fup1TimeOut);
     }else{
      document.getElementById('file0').style.width='100px';
      document.getElementById('file0').style.backgroundColor='green';
      setTimeout(transfertTermine,fup1TimeOut);
     }
   };
 };
 xhr.send(fd);
}

function processFiles(e){
 var input = document.getElementById('afile');
 var list = document.getElementById('fup1tabObjfileList');
 while(list.hasChildNodes()){
  list.removeChild(list.firstChild);
 }
 fup1totalSizeOfTheFileS=0;
 fup1filecount=0;
 fup1sizeUploadedSoFar=0;
 for (var x = 0; x < input.files.length; x++) {
  var li = document.createElement('li');
  fup1totalSizeOfTheFileS+=input.files[x].size;
  var mysize=computeFileSize(input.files[x].size);
  var span1 = document.createElement('span');
  span1.innerHTML = ''+(x+1)+ ': ' + input.files[x].name + ' , ' + mysize;
  li.appendChild(span1);
  var div1 = document.createElement('div');
  div1.style.width='100px';
  div1.style.height='10px';
  div1.style.border='1px red solid';
  var div2 = document.createElement('div');
  div2.style.width='0%';
  div2.style.height='10px';
  div2.style.backgroundColor='blue';
  div2.id='file'+(x+1);
  
  div1.appendChild(div2);
  li.appendChild(div1);
  list.appendChild(li);
  
 }
 var li = document.createElement('li');
 var span1 = document.createElement('span');
 span1.innerHTML = '<b>Total</b>';
 li.appendChild(span1);
 var div1 = document.createElement('div');
 div1.style.width='100px';
 div1.style.height='10px';
 div1.style.border='1px red solid';
 var div2 = document.createElement('div');
 div2.style.width='0%';
 div2.style.height='10px';
 div2.style.backgroundColor='blue';
 div2.id='file0';
 
 div1.appendChild(div2);
 li.appendChild(div1);
 list.appendChild(li);
 
 for(i=0;i<this.files.length;i++){
  fup1tabObjfileList.push(this.files[i]);
 }
 if(fup1tabObjfileList.length>0){
  setTimeout(uploadNextFile,fup1TimeOut);
 }
}


document.querySelector('#afile').addEventListener('change',processFiles,false);