<?php
function getinc_tdo_groups1($id){
 $n=array();
 $n['T0_fld_id_groups']             =0;
 $n['T0_fld_name_groups']           ='';
 $n['T0_fld_parent_id_groups']      =0;
 $n['T0_fld_root_group_id_groups']  =0;
 $n['T0_fld_isactive_groups']       =0;
 $n['T0_fld_category_groups']       ='';
 $n['T0_fld_crtLocAdm_groups']      =0;
 $n['T0_fld_tsupd_groups']          ='1000-01-01 00:00:00';
 $n['T0_fld_tscrt_groups']          ='1000-01-01 00:00:00';
 $n['T0_fld_cntupd_groups']         =0;
 $sql='
  SELECT 
   T0.`fld_id_groups`             ,T0.`fld_name_groups`           ,T0.`fld_parent_id_groups`      ,T0.`fld_root_group_id_groups`  ,T0.`fld_isactive_groups`       ,
   T0.`fld_category_groups`       ,T0.`fld_crtLocAdm_groups`      ,T0.`fld_tsupd_groups`          ,T0.`fld_tscrt_groups`          ,T0.`fld_cntupd_groups`         
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0
  WHERE T0.`fld_id_groups` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['T0_fld_id_groups']             = $row[0];
   $n['T0_fld_name_groups']           = $row[1];
   $n['T0_fld_parent_id_groups']      = $row[2];
   $n['T0_fld_root_group_id_groups']  = $row[3];
   $n['T0_fld_isactive_groups']       = $row[4];
   $n['T0_fld_category_groups']       = $row[5];
   $n['T0_fld_crtLocAdm_groups']      = $row[6];
   $n['T0_fld_tsupd_groups']          = $row[7];
   $n['T0_fld_tscrt_groups']          = $row[8];
   $n['T0_fld_cntupd_groups']         = $row[9];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
//======================================================================
function getinc_tdo_groups_withParentFields1($id){
 $n=array();
 $n['T0_fld_id_groups']             =0;
 $n['T0_fld_name_groups']           ='';
 $n['T0_fld_parent_id_groups']      =0;
 $n['T0_fld_root_group_id_groups']  =0;
 $n['T0_fld_isactive_groups']       =0;
 $n['T0_fld_category_groups']       ='';
 $n['T0_fld_crtLocAdm_groups']      =0;
 $n['T0_fld_tsupd_groups']          ='1000-01-01 00:00:00';
 $n['T0_fld_tscrt_groups']          ='1000-01-01 00:00:00';
 $n['T0_fld_cntupd_groups']         =0;
 $n['T1_fld_id_groups']             =0;
 $n['T1_fld_name_groups']           ='';
 $n['T1_fld_parent_id_groups']      =0;
 $n['T1_fld_root_group_id_groups']  =0;
 $n['T1_fld_isactive_groups']       =0;
 $n['T1_fld_category_groups']       ='';
 $n['T1_fld_crtLocAdm_groups']      =0;
 $n['T1_fld_tsupd_groups']          ='1000-01-01 00:00:00';
 $n['T1_fld_tscrt_groups']          ='1000-01-01 00:00:00';
 $n['T1_fld_cntupd_groups']         =0;
 $n['T2_fld_id_groups']             =0;
 $n['T2_fld_name_groups']           ='';
 $n['T2_fld_parent_id_groups']      =0;
 $n['T2_fld_root_group_id_groups']  =0;
 $n['T2_fld_isactive_groups']       =0;
 $n['T2_fld_category_groups']       ='';
 $n['T2_fld_crtLocAdm_groups']      =0;
 $n['T2_fld_tsupd_groups']          ='1000-01-01 00:00:00';
 $n['T2_fld_tscrt_groups']          ='1000-01-01 00:00:00';
 $n['T2_fld_cntupd_groups']         =0;
 $sql='
  SELECT 
   T0.`fld_id_groups`             ,T0.`fld_name_groups`           ,T0.`fld_parent_id_groups`      ,T0.`fld_root_group_id_groups`  ,T0.`fld_isactive_groups`       ,
   T0.`fld_category_groups`       ,T0.`fld_crtLocAdm_groups`      ,T0.`fld_tsupd_groups`          ,T0.`fld_tscrt_groups`          ,T0.`fld_cntupd_groups`         ,
   T1.`fld_id_groups`             ,T1.`fld_name_groups`           ,T1.`fld_parent_id_groups`      ,T1.`fld_root_group_id_groups`  ,T1.`fld_isactive_groups`       ,
   T1.`fld_category_groups`       ,T1.`fld_crtLocAdm_groups`      ,T1.`fld_tsupd_groups`          ,T1.`fld_tscrt_groups`          ,T1.`fld_cntupd_groups`         ,
   T2.`fld_id_groups`             ,T2.`fld_name_groups`           ,T2.`fld_parent_id_groups`      ,T2.`fld_root_group_id_groups`  ,T2.`fld_isactive_groups`       ,
   T2.`fld_category_groups`       ,T2.`fld_crtLocAdm_groups`      ,T2.`fld_tsupd_groups`          ,T2.`fld_tscrt_groups`          ,T2.`fld_cntupd_groups`         
  FROM ( `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0
       , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T1
       , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T2
       )
  WHERE T0.`fld_id_groups` = '.$id. '

    AND T0.`fld_parent_id_groups`      =T1.`fld_id_groups`

    AND T0.`fld_root_group_id_groups`  =T2.`fld_id_groups`
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['T0_fld_id_groups']             = $row[0];
   $n['T0_fld_name_groups']           = $row[1];
   $n['T0_fld_parent_id_groups']      = $row[2];
   $n['T0_fld_root_group_id_groups']  = $row[3];
   $n['T0_fld_isactive_groups']       = $row[4];
   $n['T0_fld_category_groups']       = $row[5];
   $n['T0_fld_crtLocAdm_groups']      = $row[6];
   $n['T0_fld_tsupd_groups']          = $row[7];
   $n['T0_fld_tscrt_groups']          = $row[8];
   $n['T0_fld_cntupd_groups']         = $row[9];
   $n['T1_fld_id_groups']             = $row[10];
   $n['T1_fld_name_groups']           = $row[11];
   $n['T1_fld_parent_id_groups']      = $row[12];
   $n['T1_fld_root_group_id_groups']  = $row[13];
   $n['T1_fld_isactive_groups']       = $row[14];
   $n['T1_fld_category_groups']       = $row[15];
   $n['T1_fld_crtLocAdm_groups']      = $row[16];
   $n['T1_fld_tsupd_groups']          = $row[17];
   $n['T1_fld_tscrt_groups']          = $row[18];
   $n['T1_fld_cntupd_groups']         = $row[19];
   $n['T2_fld_id_groups']             = $row[20];
   $n['T2_fld_name_groups']           = $row[21];
   $n['T2_fld_parent_id_groups']      = $row[22];
   $n['T2_fld_root_group_id_groups']  = $row[23];
   $n['T2_fld_isactive_groups']       = $row[24];
   $n['T2_fld_category_groups']       = $row[25];
   $n['T2_fld_crtLocAdm_groups']      = $row[26];
   $n['T2_fld_tsupd_groups']          = $row[27];
   $n['T2_fld_tscrt_groups']          = $row[28];
   $n['T2_fld_cntupd_groups']         = $row[29];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
//======================================================================
function get_tdo_groups_difference1($b,$a){ // before , after
 if(
     $b['T0_fld_name_groups']==$a['T0_fld_name_groups']
  && $b['T0_fld_parent_id_groups']==$a['T0_fld_parent_id_groups']
  && $b['T0_fld_root_group_id_groups']==$a['T0_fld_root_group_id_groups']
  && $b['T0_fld_isactive_groups']==$a['T0_fld_isactive_groups']
  && $b['T0_fld_category_groups']==$a['T0_fld_category_groups']
  && $b['T0_fld_crtLocAdm_groups']==$a['T0_fld_crtLocAdm_groups']
 ){
  return '// UPDATE no difference'.CRLF;
 }else{;
  $t1='';
  if($b['T0_fld_name_groups']!=$a['T0_fld_name_groups']){
   $t1.='fld_name_groups from "'.$b['T0_fld_name_groups'].'" to "'.$a['T0_fld_name_groups'].'"'.CRLF;
  }
  if($b['T0_fld_parent_id_groups']!=$a['T0_fld_parent_id_groups']){
   $t1.='fld_parent_id_groups from "'.$b['T0_fld_parent_id_groups'].'" to "'.$a['T0_fld_parent_id_groups'].'"'.CRLF;
  }
  if($b['T0_fld_root_group_id_groups']!=$a['T0_fld_root_group_id_groups']){
   $t1.='fld_root_group_id_groups from "'.$b['T0_fld_root_group_id_groups'].'" to "'.$a['T0_fld_root_group_id_groups'].'"'.CRLF;
  }
  if($b['T0_fld_isactive_groups']!=$a['T0_fld_isactive_groups']){
   $t1.='fld_isactive_groups from "'.$b['T0_fld_isactive_groups'].'" to "'.$a['T0_fld_isactive_groups'].'"'.CRLF;
  }
  if($b['T0_fld_category_groups']!=$a['T0_fld_category_groups']){
   $t1.='fld_category_groups from "'.$b['T0_fld_category_groups'].'" to "'.$a['T0_fld_category_groups'].'"'.CRLF;
  }
  if($b['T0_fld_crtLocAdm_groups']!=$a['T0_fld_crtLocAdm_groups']){
   $t1.='fld_crtLocAdm_groups from "'.$b['T0_fld_crtLocAdm_groups'].'" to "'.$a['T0_fld_crtLocAdm_groups'].'"'.CRLF;
  }
  return '/*'.CRLF.'UPDATE list of differences'.CRLF.CRLF.$t1.CRLF.'*/'.CRLF;
 }
}
//======================================================================
function get_tdo_groups_rebuild_insert1($f){
 $t1='// DELETE FROM `tdo_tbl__groups` OK, the insert would be : '.CRLF;
 $t1.='$sql[]=<'.'<'.'<EOT'.CRLF;
 $t1.='INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` SET'.CRLF;
 $t1.='   `fld_id_groups` = \''.addslashes($f['T0_fld_id_groups']) . '\' '.CRLF;
 $t1.=' , `fld_name_groups` = \''.addslashes($f['T0_fld_name_groups']) . '\' '.CRLF;
 $t1.=' , `fld_parent_id_groups` = \''.addslashes($f['T0_fld_parent_id_groups']) . '\' '.CRLF;
 $t1.=' , `fld_root_group_id_groups` = \''.addslashes($f['T0_fld_root_group_id_groups']) . '\' '.CRLF;
 $t1.=' , `fld_isactive_groups` = \''.addslashes($f['T0_fld_isactive_groups']) . '\' '.CRLF;
 $t1.=' , `fld_category_groups` = \''.addslashes($f['T0_fld_category_groups']) . '\' '.CRLF;
 $t1.=' , `fld_crtLocAdm_groups` = \''.addslashes($f['T0_fld_crtLocAdm_groups']) . '\' '.CRLF;
 $t1.=' , `fld_tsupd_groups` = \''.addslashes($f['T0_fld_tsupd_groups']) . '\' '.CRLF;
 $t1.=' , `fld_tscrt_groups` = \''.addslashes($f['T0_fld_tscrt_groups']) . '\' '.CRLF;
 $t1.=' , `fld_cntupd_groups` = \''.addslashes($f['T0_fld_cntupd_groups']) . '\' '.CRLF;
 $t1.='EOT;'.CRLF;
 return $t1;
}
