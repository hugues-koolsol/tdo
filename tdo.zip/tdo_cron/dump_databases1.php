<?php
define('BNF',basename( __FILE__ ));
$GLOBALS['cron_backup']=true;
require_once('../tdo_www/za_inc.php');

$GLOBALS['now']=time();
$GLOBALS['emailSendTo']='foo@bar.com';
if(!is_dir('tempBackup1')){
 if(!mkdir('tempBackup1',0777)){
  die(__FILE__ . ' ' . __LINE__ . ' error cannot create tempBackup1' ); 
 }
}
//============================================================================================================================================
function creerCsv($tabpar , $fdmysql , $fdexcel , $kbase ){

 $premiereLigneExcel='';
 $listeDesChamps='';
 $tabChamps=array();
 $sql0='DESC `'.$GLOBALS['glob_db'][$kbase]['dbname'].'`.`' . $tabpar['vtable'] .'`';
 $res0=mysqli_query($GLOBALS['glob_db'][$kbase]['link'],$sql0);
 if(mysqli_errno($GLOBALS['glob_db'][$kbase]['link'])==0){
  while($mpsr0=mysqli_fetch_row($res0)){
   if($premiereLigneExcel!='') $premiereLigneExcel.=';';
   $premiereLigneExcel.=$mpsr0[0];
   if($listeDesChamps!='') $listeDesChamps.=' , ';
   $listeDesChamps.='`'.$mpsr0[0].'`';
   $tabChamps[]=$mpsr0;
  }
  mysqli_free_result($res0);
 }else{
  myemail(
    __LINE__ . ' Attention les sauvegardes n\'ont pas été faites' , 
   'Erreur de sql='. $sql0 . ', mysqli_error()='.mysqli_error($GLOBALS['glob_db'][$kbase]['link']) .''.  "\r\n" .' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
   $GLOBALS['emailSendTo']
   );
  die(__FILE__ . ' ' . __LINE__ . ' Sauvegardes non effectuées');
 }

 fwrite( $fdexcel , $premiereLigneExcel . "\r\n" );
 $sql0='SELECT ' . $listeDesChamps . ' FROM `'.$GLOBALS['glob_db'][$kbase]['dbname'].'`.`' . $tabpar['vtable'] .'`';
 $res0=mysqli_query($GLOBALS['glob_db'][$kbase]['link'],$sql0);
 if(mysqli_errno($GLOBALS['glob_db'][$kbase]['link'])==0){
  while($mpsr0=mysqli_fetch_row($res0)){
   $donneesExcel=''; 
   $donneesMysql='';
   foreach($mpsr0 as $kd1 => $vd1){
    $nomChamp =$tabChamps[$kd1][0];
    $typeChamp=$tabChamps[$kd1][1];
    $nullPossible=$tabChamps[$kd1][2];
    $valeurChamp=$vd1;
    if(
       strpos(strtolower($typeChamp),'int(')!==false
     ||strpos(strtolower($typeChamp),'decimal(')!==false
     ||strpos(strtolower($typeChamp),'float(')!==false
     ||strpos(strtolower($typeChamp),'double(')!==false
     ||strpos(strtolower($typeChamp),'real(')!==false
    ){
     $format='num';
    }else if(
       strpos(strtolower($typeChamp),'char')!==false
     ||strpos(strtolower($typeChamp),'text')!==false
     ||strpos(strtolower($typeChamp),'blob')!==false
     ||strpos(strtolower($typeChamp),'enum(')!==false
     ||strpos(strtolower($typeChamp),'set(')!==false
     ||strpos(strtolower($typeChamp),'timestamp')!==false
     ||strpos(strtolower($typeChamp),'datetime')!==false
     ||strpos(strtolower($typeChamp),'date')!==false
     ||strpos(strtolower($typeChamp),'time')!==false
    ){
     $format='texte';
    }else{
     myemail(
       __LINE__ . ' Attention les sauvegardes n\'ont pas été faites' , 
      'Erreur de sql='. $sql0 . ', mysqli_error()='.mysqli_error($GLOBALS['glob_db'][$kbase]['link']) .' un type de champ n\'est pas trouve : $typeChamp=' . $typeChamp . ' , $mpsr0=' . var_export( $mpsr0 , true ) . ' , $nomChamp = ' . $nomChamp .  "\r\n" .' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
      $GLOBALS['emailSendTo']
      );
     die(__FILE__ . ' ' . __LINE__ . ' Sauvegardes non effectuées');
    }
    if($donneesExcel!='') $donneesExcel.=';';
    if($donneesMysql!='') $donneesMysql.=';';
    if($format=='texte'){
     $donneesExcel.='"'.str_replace('"','""',mb_convert_encoding( $valeurChamp , 'CP1252' , 'UTF-8' )).'"';
     $donneesMysql.='"'.str_replace('"','\\"',str_replace('\\','\\\\',$valeurChamp)).'"';
    }else if($format=='num'){
     $donneesExcel.='' .$valeurChamp.'';
     $donneesMysql.='"'.$valeurChamp.'"';
    }
    
   }
   $donneesExcel.="\r\n"; fwrite($fdexcel,$donneesExcel);
   $donneesMysql.="\r\n"; fwrite($fdmysql,$donneesMysql);
  }
  mysqli_free_result($res0);
 }else{
  myemail(
    __LINE__ . ' Attention les sauvegardes n\'ont pas été faites' , 
   'Erreur de sql='. $sql0 . ', mysqli_error()='.mysqli_error($GLOBALS['db'][0]['link']) .''.  "\r\n" .' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
   $GLOBALS['emailSendTo']
   );
  die(__FILE__ . ' ' . __LINE__ . ' Sauvegardes non effectuées');
 }
 return true;
}
//============================================================================================================================================

foreach( $GLOBALS['glob_db'] as $k1 => $v1){

 $files = glob('tempBackup1/{,.}*', GLOB_BRACE);
 foreach($files as $file){ // iterate files
  if(is_file($file)){
   unlink($file); // delete file
  }
 }
 $GLOBALS['FichierZip']=array(
  array( 'nom' => 'tempBackup1/zzz_'.rawurlencode($GLOBALS['glob_db'][$k1]['server'].'|'.$GLOBALS['glob_db'][$k1]['user'].'|'.$GLOBALS['glob_db'][$k1]['dbname']).'-'.date('H-i-s',$GLOBALS['now']).'-zipExcel.zip', 'src' => 'csv_excel' ),
  array( 'nom' => 'tempBackup1/zzz_'.rawurlencode($GLOBALS['glob_db'][$k1]['server'].'|'.$GLOBALS['glob_db'][$k1]['user'].'|'.$GLOBALS['glob_db'][$k1]['dbname']).'-'.date('H-i-s',$GLOBALS['now']).'-zipMysql.zip', 'src' => 'csv_mysql' ),
 );
 
 
 $tableList=array();
 
 $GLOBALS['glob_db'][$k1]['link']=mysqli_connect($v1['server'],$v1['user'],$v1['password'],$v1['dbname']);
 
 // create table list
 if($GLOBALS['glob_db'][$k1]['link']){
  $sql='SHOW TABLES';
  if(!($result=mysqli_query($GLOBALS['glob_db'][$k1]['link'],$sql))) {
   die(__FILE__ . ' ' . __LINE__ . ' error ' . $v1['server'] . ' / ' . $v1['user'] . '  mysqli_error='. mysqli_error($GLOBALS['glob_db'][$k1]['link']) );
  }else{
   while( $row = mysqli_fetch_row( $result ) ){
    $tableList[]=array(
     'tableName'    => $row[0] ,
    );
   }
   sort($tableList);
   mysqli_free_result($result);
  }
 }else{
  die(__FILE__ . ' ' . __LINE__ . ' cannot connect to ' . $v1['server'] . ' / ' . $v1['user']);
 }
 
 // create sql create table
 $texteFichier='';
 foreach($tableList as $k0 => $v0){
  $sql0='SHOW CREATE TABLE `'.$GLOBALS['glob_db'][$k1]['dbname'].'`.`' . $v0['tableName'] .'`';
  $res0=mysqli_query($GLOBALS['glob_db'][$k1]['link'],$sql0);
  if(mysqli_errno($GLOBALS['glob_db'][$k1]['link'])==0){
   while($mpsr0=mysqli_fetch_row($res0)){
    $texteFichier.='--'."\r\n".'-- ' . $v0['tableName'] ."\r\n".'--'."\r\n" . $mpsr0[1] . ';' . "\r\n";
   }
   mysqli_free_result($res0);
  }else{
   die(__FILE__ . ' ' . __LINE__ . ' error ' . $v1['server'] . ' / ' . $v1['user'] . '  mysqli_error='. mysqli_error($GLOBALS['glob_db'][$k1]['link']) );
  }
 }
 $sqlFileName='tempBackup1/zzz_sql_'.rawurlencode($GLOBALS['glob_db'][$k1]['server'].'|'.$GLOBALS['glob_db'][$k1]['user'].'|'.$GLOBALS['glob_db'][$k1]['dbname']).'.sql';
 if($fd=fopen($sqlFileName,'w')){
  if(!fwrite($fd,$texteFichier)){
   die(__FILE__ . ' ' . __LINE__ . ' error ' . $v1['server'] . ' / ' . $v1['user'] . '  cannot write '  );  
  }
 }else{
  die(__FILE__ . ' ' . __LINE__ . ' error ' . $v1['server'] . ' / ' . $v1['user'] . '  cannot open '  );  
 }
 $GLOBALS['tabFichiers']=array();
 //============================================================================================================================================
 foreach($tableList as $ktable => $vtable){
  $GLOBALS['tabFichiers'][]=array(
   'ktable'       => $ktable,
   'vtable'       => $vtable['tableName'],
   'csv_excel'    => 'tempBackup1/temp_excel_'.$vtable['tableName'].'.csv',
   'csv_mysql'    => 'tempBackup1/temp_mysql_'.$vtable['tableName'].'.csv',
   'fd'     => 0,
  );
 }
 // create data files
 foreach($GLOBALS['tabFichiers'] as $k0 => $v0){
  @unlink($v0['csv_mysql']);
  @unlink($v0['csv_excel']);
  $fdexcel=fopen($v0['csv_excel'],'w');
  $fdmysql=fopen($v0['csv_mysql'],'w');
  if($fdmysql!==false&&$fdexcel!==false){
   if(creerCsv($v0 , $fdmysql , $fdexcel, $k1)){
   }else{
    myemail(
      __LINE__ . ' Attention les sauvegardes n\'ont pas été faites' , 
     'Impossible de creer le csv pour ' . var_export( $v0 , true ) . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
     $GLOBALS['emailSendTo']
     );
    die('Sauvegardes non effectuées');
   }
   fclose($fdmysql);
   fclose($fdexcel);
  }else{
   myemail(
     __LINE__ . ' Attention les sauvegardes n\'ont pas été faites' , 
    'Impossible de creer le fichier ' . $v0['csv'] . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
    $GLOBALS['emailSendTo']
   );
   die('Sauvegardes non effectuées');
  }
 }
 
 // create zip files
 foreach( $GLOBALS['FichierZip'] as $kzip => $vzip ){ //
  @unlink($vzip['nom']);
  $zip = new ZipArchive();
  if($zip->open($vzip['nom'], ZIPARCHIVE::CREATE)!==TRUE) {
    myemail(
     __FILE__ . ' ' .__LINE__ . ' Attention les sauvegardes ont pas été faites mais le fichier zip n\'a pas pu être fait' , 
     'Impossible de creer le fichier ' . $vzip['nom'] . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
     $GLOBALS['destinataire']
    );
    die('Sauvegardes non effectuées');
  }
  foreach($GLOBALS['tabFichiers'] as $k0 => $v0){
   if(!$zip->addFile($v0[$vzip['src']])){
    myemail(
     __FILE__ . ' ' .__LINE__ . ' Attention les sauvegardes ont pas été faites , le fichier zip n\'a pas pu être fait' , 
     'Impossible d\'ajouter le fichier ' . $v0[$vzip['src']] . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
     $GLOBALS['destinataire']
    );
    die('Sauvegardes non effectuées');
   }else{
   }
  }
  $zipExcelStatus=$zip->status;
  $zip->close();

  if($zipExcelStatus==0){
   foreach($GLOBALS['tabFichiers'] as $k0 => $v0 ){
    @unlink($v0[$vzip['src']]);
   }
  }
 } 
 
}
echo 'Good job!';