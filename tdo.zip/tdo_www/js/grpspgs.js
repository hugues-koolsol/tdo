//=====================================================================================================================
function afterSortGrpPgs2(context,tree){

 switch(context.action){

  //================================== 
  case 'afterReorganize' :
   var listeDesElementsTries=[];
   var txt='';
   for(var elem in tree){
    txt+=','+tree[elem].id;
    listeDesElementsTries.push(tree[elem].id);
   }
   document.getElementById('sortedMenus1').value=txt.substr(1,txt.length);
   var r = new XMLHttpRequest();
   r.open("POST",'za_ajax.php?setSortPagesOfGroup1',true); // ajax_writeGeneratedFile2.php
   r.timeout=6000;
   r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
   r.onreadystatechange = function () {
    if (r.readyState != 4 || r.status != 200) return;
    try{
     var jsonRet=JSON.parse(r.responseText);
     if(jsonRet.status=='OK'){
      document.location=String(document.location);
      return;
     }else{
      display_ajax_error_in_cons(jsonRet);
      console.log(r);
      return;
     }
    }catch(e){
     console.error(e,r);
    }
   };
   r.onerror=function(e){
    console.error('e=',e);
   }
   var data={
    funct            : 'setSortPagesOfGroup1',
    sortListGroupId  : document.getElementById('sortListGroupId').value,
    order            : listeDesElementsTries,
   };
   r.send('data='+encodeURIComponent(JSON.stringify(data)));
   
  break;

  //================================== 
  case 'init' :   
   var txt='';
   for(var elem in tree){
    txt+=','+tree[elem].id;
   }
   document.getElementById('sortedMenus1').value=txt.substr(1,txt.length);
   
  break;

  //================================== 
  default:
  break;
  
 }
}
var oMyTree2=null;
//=====================================================================================================================
function onSortPagesOfGroups2(par){
 oMyTree2=new cMyTree1('oMyTree2','myTreeId2',jsonTree2,options2,afterSortGrpPgs2); 
}