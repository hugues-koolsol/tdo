<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
// if($fd=fopen('toto.txt','a')){fwrite($fd,''.date('Y-m-d H:i:s'). ' ' . __LINE__ ."\r\n".'$ret='.var_export($ret,true)."\r\n"); fclose($fd);}
/*
$ret=array (
  'status' => 'KO',
  'message' => 
  array (
  ),
  'input' => 
  array (
    'funct' => 'fileNameChangeInGen1',
    'file_name' => 'actor2.php',
  ),
)
*/
 openDb1();
 $ret['fld_id_pages']  =0;
 $ret['fld_id_grpspgs']=0;
 $req6='
  SELECT T0.`fld_id_pages`  
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` T0 
  WHERE T0.`fld_name_pages` = \''.addslashes($ret['input']['file_name']).'\'
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $ret['fld_id_pages']=(int)$mpsr6[0];
   $req7='
    SELECT T0.`fld_id_grpspgs`  
    FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` T0 
    WHERE T0.`fld_page_id_grpspgs` = '.$mpsr6[0].' AND T0.`fld_group_id_grpspgs` = 1
   ';
   $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    while($mpsr7=mysqli_fetch_row($result7)){
     $ret['fld_id_grpspgs']=(int)$mpsr7[0];
    }
    mysqli_free_result($result7);
   }
  }
  mysqli_free_result($result6);
  if($ret['fld_id_pages']!==0){
   $ret['status']='OK';
   $ret['alreadyExist']=true;
   $ret['message']='page already exists';    
  }else{
   $ret['status']='OK';
   $ret['alreadyExist']=false;
   $ret['message']='page does not exists yet';    
  }
 }else{
  $ret['message']='mysqli_error() "'.mysqli_error($GLOBALS['glob_db'][0]['link']).'" , $req6='.$req6;
 }
 
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;   
}