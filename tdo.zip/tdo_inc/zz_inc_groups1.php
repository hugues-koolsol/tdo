<?php
//========================================================================================================================
function getGroup1($id){
 $nam=array();
 $n['fld_id_groups']             =0;
 $n['fld_name_groups']           ='';
 $n['fld_parent_id_groups']      =0;
 $n['fld_isactive_groups']       =0;
 $n['fld_category_groups']       ='';
 $n['fld_root_group_id_groups']  =0;
 $n['fld_crtLocAdm_groups']      =0;
 $n['fld_tsupd_groups']          ='1000-01-01 00:00:00';
 $n['fld_tscrt_groups']          ='1000-01-01 00:00:00';
 $n['fld_cntupd_groups']         =0;
 $sql='
  SELECT 
   T0.`fld_id_groups`            ,T0.`fld_name_groups`      ,T0.`fld_parent_id_groups` ,T0.`fld_isactive_groups`  ,T0.`fld_category_groups`  ,
   T0.`fld_root_group_id_groups` ,T0.`fld_crtLocAdm_groups` ,T0.`fld_tsupd_groups`     ,T0.`fld_tscrt_groups`     ,T0.`fld_cntupd_groups`    
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0
  WHERE T0.`fld_id_groups` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['fld_id_groups']            = $row[0];
   $n['fld_name_groups']          = $row[1];
   $n['fld_parent_id_groups']     = $row[2];
   $n['fld_isactive_groups']      = $row[3];
   $n['fld_category_groups']      = $row[4];
   $n['fld_root_group_id_groups'] = $row[5];
   $n['fld_crtLocAdm_groups']     = $row[6];   
   $n['fld_tsupd_groups']         = $row[7];
   $n['fld_tscrt_groups']         = $row[8];
   $n['fld_cntupd_groups']        = $row[9];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
