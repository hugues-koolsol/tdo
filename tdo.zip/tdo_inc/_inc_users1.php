<?php
function getinc_tdo_users1($id){
 $n=array();
 $n['T0_fld_id_users']              =0;
 $n['T0_fld_login_users']           ='';
 $n['T0_fld_email_users']           ='';
 $n['T0_fld_loginisemail_users']    =0;
 $n['T0_fld_password_users']        ='';
 $n['T0_fld_group_id_users']        =0;
 $n['T0_fld_active_users']          =0;
 $n['T0_fld_translate_users']       =0;
 $n['T0_fld_firstname_users']       ='';
 $n['T0_fld_lastname_users']        ='';
 $n['T0_fld_comment_users']         =null;
 $n['T0_fld_tsupd_users']           ='1000-01-01 00:00:00';
 $n['T0_fld_tscrt_users']           ='1000-01-01 00:00:00';
 $n['T0_fld_cntupd_users']          =0;
 $sql='
  SELECT 
   T0.`fld_id_users`              ,T0.`fld_login_users`           ,T0.`fld_email_users`           ,T0.`fld_loginisemail_users`    ,T0.`fld_password_users`        ,
   T0.`fld_group_id_users`        ,T0.`fld_active_users`          ,T0.`fld_translate_users`       ,T0.`fld_firstname_users`       ,T0.`fld_lastname_users`        ,
   T0.`fld_comment_users`         ,T0.`fld_tsupd_users`           ,T0.`fld_tscrt_users`           ,T0.`fld_cntupd_users`          
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` T0
  WHERE T0.`fld_id_users` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['T0_fld_id_users']              = $row[0];
   $n['T0_fld_login_users']           = $row[1];
   $n['T0_fld_email_users']           = $row[2];
   $n['T0_fld_loginisemail_users']    = $row[3];
   $n['T0_fld_password_users']        = $row[4];
   $n['T0_fld_group_id_users']        = $row[5];
   $n['T0_fld_active_users']          = $row[6];
   $n['T0_fld_translate_users']       = $row[7];
   $n['T0_fld_firstname_users']       = $row[8];
   $n['T0_fld_lastname_users']        = $row[9];
   $n['T0_T0_fld_comment_users']      = $row[10];
   $n['T0_fld_tsupd_users']           = $row[11];
   $n['T0_fld_tscrt_users']           = $row[12];
   $n['T0_fld_cntupd_users']          = $row[13];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
//======================================================================
function getinc_tdo_users_withParentFields1($id){
 $n=array();
 $n['T0_fld_id_users']              =0;
 $n['T0_fld_login_users']           ='';
 $n['T0_fld_email_users']           ='';
 $n['T0_fld_loginisemail_users']    =0;
 $n['T0_fld_password_users']        ='';
 $n['T0_fld_group_id_users']        =0;
 $n['T0_fld_active_users']          =0;
 $n['T0_fld_translate_users']       =0;
 $n['T0_fld_firstname_users']       ='';
 $n['T0_fld_lastname_users']        ='';
 $n['T0_fld_tsupd_users']           ='1000-01-01 00:00:00';
 $n['T0_fld_tscrt_users']           ='1000-01-01 00:00:00';
 $n['T0_fld_cntupd_users']          =0;
 $n['T1_fld_id_groups']             =0;
 $n['T1_fld_name_groups']           ='';
 $n['T1_fld_parent_id_groups']      =0;
 $n['T1_fld_root_group_id_groups']  =0;
 $n['T1_fld_isactive_groups']       =0;
 $n['T1_fld_category_groups']       ='';
 $n['T1_fld_crtLocAdm_groups']      =0;
 $n['T1_fld_tsupd_groups']          ='1000-01-01 00:00:00';
 $n['T1_fld_tscrt_groups']          ='1000-01-01 00:00:00';
 $n['T1_fld_cntupd_groups']         =0;
 $sql='
  SELECT 
   T0.`fld_id_users`              ,T0.`fld_login_users`           ,T0.`fld_email_users`           ,T0.`fld_loginisemail_users`    ,T0.`fld_password_users`        ,
   T0.`fld_group_id_users`        ,T0.`fld_active_users`          ,T0.`fld_translate_users`       ,T0.`fld_firstname_users`       ,T0.`fld_lastname_users`        ,
   T0.`fld_tsupd_users`           ,T0.`fld_tscrt_users`           ,T0.`fld_cntupd_users`          ,T1.`fld_id_groups`             ,T1.`fld_name_groups`           ,
   T1.`fld_parent_id_groups`      ,T1.`fld_root_group_id_groups`  ,T1.`fld_isactive_groups`       ,T1.`fld_category_groups`       ,T1.`fld_crtLocAdm_groups`      ,
   T1.`fld_tsupd_groups`          ,T1.`fld_tscrt_groups`          ,T1.`fld_cntupd_groups`         
  FROM ( `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` T0
       , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T1
       )
  WHERE T0.`fld_id_users` = '.$id. '

    AND T0.`fld_group_id_users`        =T1.`fld_id_groups`
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['T0_fld_id_users']              = $row[0];
   $n['T0_fld_login_users']           = $row[1];
   $n['T0_fld_email_users']           = $row[2];
   $n['T0_fld_loginisemail_users']    = $row[3];
   $n['T0_fld_password_users']        = $row[4];
   $n['T0_fld_group_id_users']        = $row[5];
   $n['T0_fld_active_users']          = $row[6];
   $n['T0_fld_translate_users']       = $row[7];
   $n['T0_fld_firstname_users']       = $row[8];
   $n['T0_fld_lastname_users']        = $row[9];
   $n['T0_fld_tsupd_users']           = $row[10];
   $n['T0_fld_tscrt_users']           = $row[11];
   $n['T0_fld_cntupd_users']          = $row[12];
   $n['T1_fld_id_groups']             = $row[13];
   $n['T1_fld_name_groups']           = $row[14];
   $n['T1_fld_parent_id_groups']      = $row[15];
   $n['T1_fld_root_group_id_groups']  = $row[16];
   $n['T1_fld_isactive_groups']       = $row[17];
   $n['T1_fld_category_groups']       = $row[18];
   $n['T1_fld_crtLocAdm_groups']      = $row[19];
   $n['T1_fld_tsupd_groups']          = $row[20];
   $n['T1_fld_tscrt_groups']          = $row[21];
   $n['T1_fld_cntupd_groups']         = $row[22];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
//======================================================================
function get_tdo_users_difference1($b,$a){ // before , after
 if(
     $b['T0_fld_login_users']==$a['T0_fld_login_users']
  && $b['T0_fld_email_users']==$a['T0_fld_email_users']
  && $b['T0_fld_loginisemail_users']==$a['T0_fld_loginisemail_users']
  && $b['T0_fld_password_users']==$a['T0_fld_password_users']
  && $b['T0_fld_group_id_users']==$a['T0_fld_group_id_users']
  && $b['T0_fld_active_users']==$a['T0_fld_active_users']
  && $b['T0_fld_translate_users']==$a['T0_fld_translate_users']
  && $b['T0_fld_firstname_users']==$a['T0_fld_firstname_users']
  && $b['T0_fld_lastname_users']==$a['T0_fld_lastname_users']
 ){
  return '// UPDATE no difference'.CRLF;
 }else{;
  $t1='';
  if($b['T0_fld_login_users']!=$a['T0_fld_login_users']){
   $t1.='fld_login_users from "'.$b['T0_fld_login_users'].'" to "'.$a['T0_fld_login_users'].'"'.CRLF;
  }
  if($b['T0_fld_email_users']!=$a['T0_fld_email_users']){
   $t1.='fld_email_users from "'.$b['T0_fld_email_users'].'" to "'.$a['T0_fld_email_users'].'"'.CRLF;
  }
  if($b['T0_fld_loginisemail_users']!=$a['T0_fld_loginisemail_users']){
   $t1.='fld_loginisemail_users from "'.$b['T0_fld_loginisemail_users'].'" to "'.$a['T0_fld_loginisemail_users'].'"'.CRLF;
  }
  if($b['T0_fld_password_users']!=$a['T0_fld_password_users']){
   $t1.='fld_password_users from "'.$b['T0_fld_password_users'].'" to "'.$a['T0_fld_password_users'].'"'.CRLF;
  }
  if($b['T0_fld_group_id_users']!=$a['T0_fld_group_id_users']){
   $t1.='fld_group_id_users from "'.$b['T0_fld_group_id_users'].'" to "'.$a['T0_fld_group_id_users'].'"'.CRLF;
  }
  if($b['T0_fld_active_users']!=$a['T0_fld_active_users']){
   $t1.='fld_active_users from "'.$b['T0_fld_active_users'].'" to "'.$a['T0_fld_active_users'].'"'.CRLF;
  }
  if($b['T0_fld_translate_users']!=$a['T0_fld_translate_users']){
   $t1.='fld_translate_users from "'.$b['T0_fld_translate_users'].'" to "'.$a['T0_fld_translate_users'].'"'.CRLF;
  }
  if($b['T0_fld_firstname_users']!=$a['T0_fld_firstname_users']){
   $t1.='fld_firstname_users from "'.$b['T0_fld_firstname_users'].'" to "'.$a['T0_fld_firstname_users'].'"'.CRLF;
  }
  if($b['T0_fld_lastname_users']!=$a['T0_fld_lastname_users']){
   $t1.='fld_lastname_users from "'.$b['T0_fld_lastname_users'].'" to "'.$a['T0_fld_lastname_users'].'"'.CRLF;
  }
  return '/*'.CRLF.'UPDATE list of differences'.CRLF.CRLF.$t1.CRLF.'*/'.CRLF;
 }
}
//======================================================================
function get_tdo_users_rebuild_insert1($f){
 $t1='// DELETE FROM `tdo_tbl__users` OK, the insert would be : '.CRLF;
 $t1.='$sql[]=<'.'<'.'<EOT'.CRLF;
 $t1.='INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` SET'.CRLF;
 $t1.='   `fld_id_users` = \''.addslashes($f['T0_fld_id_users']) . '\' '.CRLF;
 $t1.=' , `fld_login_users` = \''.addslashes($f['T0_fld_login_users']) . '\' '.CRLF;
 $t1.=' , `fld_email_users` = \''.addslashes($f['T0_fld_email_users']) . '\' '.CRLF;
 $t1.=' , `fld_loginisemail_users` = \''.addslashes($f['T0_fld_loginisemail_users']) . '\' '.CRLF;
 $t1.=' , `fld_password_users` = \''.addslashes($f['T0_fld_password_users']) . '\' '.CRLF;
 $t1.=' , `fld_group_id_users` = \''.addslashes($f['T0_fld_group_id_users']) . '\' '.CRLF;
 $t1.=' , `fld_active_users` = \''.addslashes($f['T0_fld_active_users']) . '\' '.CRLF;
 $t1.=' , `fld_translate_users` = \''.addslashes($f['T0_fld_translate_users']) . '\' '.CRLF;
 $t1.=' , `fld_firstname_users` = \''.addslashes($f['T0_fld_firstname_users']) . '\' '.CRLF;
 $t1.=' , `fld_lastname_users` = \''.addslashes($f['T0_fld_lastname_users']) . '\' '.CRLF;
 $t1.=' , `fld_tsupd_users` = \''.addslashes($f['T0_fld_tsupd_users']) . '\' '.CRLF;
 $t1.=' , `fld_tscrt_users` = \''.addslashes($f['T0_fld_tscrt_users']) . '\' '.CRLF;
 $t1.=' , `fld_cntupd_users` = \''.addslashes($f['T0_fld_cntupd_users']) . '\' '.CRLF;
 $t1.='EOT;'.CRLF;
 return $t1;
}
