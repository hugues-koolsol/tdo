<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb2();
//========================================================================================================================
if(isset($_POST) && sizeof($_POST)>0){
 if(isset($_POST['addOneToPriorities'])){
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl_todos` SET
    `fld_priority_todos` = `fld_priority_todos` + 1
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_priority_todos` < 50
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
 }
 if(isset($_POST['subOneToPriorities'])){
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl_todos` SET
    `fld_priority_todos` = `fld_priority_todos` - 1
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_priority_todos` >= 1
     AND `fld_priority_todos` <  50
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
 }
 header('Location: '.BNF);
 exit();
 
}
if(isset($_GET) && sizeof($_GET)>0){
 if(isset($_GET['a']) && $_GET['a']=='plusOne'){
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl_todos` SET
    `fld_priority_todos` = `fld_priority_todos` + 1
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_id_todos`        = '.$_GET['id'].'
     AND `fld_priority_todos` < 99
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
  header('Location: '.BNF);
  exit();
 }
 if(isset($_GET['a']) && $_GET['a']=='minusOne'){
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl_todos` SET
    `fld_priority_todos` = `fld_priority_todos` - 1
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_id_todos`        = '.$_GET['id'].'
     AND `fld_priority_todos` > 0
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
  header('Location: '.BNF);
  exit();  
 }
 if(isset($_GET['a']) && $_GET['a']=='setTo99'){
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl_todos` SET
    `fld_priority_todos` = 99
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_id_todos`        = '.$_GET['id'].'
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
  header('Location: '.BNF);
  exit();
 }
 
 if(isset($_GET['a']) && $_GET['a']=='setTo00'){
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl_todos` SET
    `fld_priority_todos` = 0
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_id_todos`        = '.$_GET['id'].'
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
  header('Location: '.BNF);
  exit();
 } 
}

//========================================================================================================================
$o1='';
$__nbMax=15;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_priority_todos
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_title_todos
$xsrch_3=saveSessionSearch1('xsrch_3',BNF);// fld_comment_todos
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_todos
$xsrch_tri1   =saveSessionSearch1( 'xsrch_tri1'   , BNF );

if($xsrch_0!=''){
 if(!is_numeric($xsrch_0)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field _120_92') . ' : ' . txt2('fld_priority_todos_120_153');
 }
}
if($xsrch_id!=''){
 if(!is_numeric($xsrch_id)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field _120_92') . ' : ' . txt2('fld_id_todos_125_153');
 }
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; }
else if($xsrch_2!=''){ $autofocus='xsrch_2'; }
else if($xsrch_3!=''){ $autofocus='xsrch_3'; }
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
else if($xsrch_tri1!=''){   $autofocus='xsrch_tri1';}

$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_136_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="filterForm">'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0" >'.txt2('fld_priority_todos_120_153').'</label>'.CRLF; // fld_priority_todos
$o1.='    <input '.($xsrch_0!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_0"    id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_2"  >'.txt2('fld_title_todos_151_50').'</label>'.CRLF; // fld_title_todos
$o1.='    <input '.($xsrch_2!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_2"    id="xsrch_2"   value="'.enti1($xsrch_2).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_3"  >'.txt2('fld_comment_todos_159_50').'</label>'.CRLF; // fld_comment_todos
$o1.='    <input '.($xsrch_3!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_3"    id="xsrch_3"   value="'.enti1($xsrch_3).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_3'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_todos_125_153').'</label>'.CRLF; // fld_id_todos
$o1.='    <input '.($xsrch_id!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_tri1" >'.txt2('sort_174_53').'</label>'.CRLF;
$o1.='    <select '.($xsrch_tri1!=''?'class="backgroundYellow"':'').' id="xsrch_tri1" name="xsrch_tri1"/>'.CRLF;
$o1.='     <option value=""           '.($xsrch_tri1==''          ?' selected="selected" ':'').'></option>'.CRLF;
$o1.='     <option value="tri1_by_id" '.($xsrch_tri1=='tri1_by_id'?' selected="selected" ':'').'>Id</option>'.CRLF;
$o1.='    </select>';
$o1.='   </div>'.CRLF;




$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;


//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_todos`       ,T0.`fld_priority_todos` ,T0.`fld_id_user_todos`  ,T0.`fld_title_todos`    ,T0.`fld_comment_todos`  
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl_todos` T0 
 WHERE T0.`fld_id_user_todos`      =       ' . $_SESSION[PGMK]['login'] . '  
';
if($xsrch_0!='' && is_numeric($xsrch_0)){
 $req6.='
  AND T0.`fld_priority_todos` = '.$xsrch_0.'
 '; 
}
if($xsrch_2!='' ){
 $req6.='
  AND T0.`fld_title_todos` LIKE \'%'.$xsrch_2.'%\'
 '; 
}
if($xsrch_3!='' ){
 $req6.='
  AND T0.`fld_comment_todos` LIKE \'%'.$xsrch_3.'%\'
 '; 
}
if($xsrch_id!='' && is_numeric($xsrch_id)){
 $req6.='
  AND T0.`fld_id_todos` = '.$xsrch_id.'
 '; 
}
if($xsrch_tri1==''){
 $req6.='
  ORDER BY T0.`fld_priority_todos` ASC , T0.`fld_id_todos` DESC 
 '; 
}else if($xsrch_tri1=='tri1_by_id'){
 $req6.='
  ORDER BY T0.`fld_id_todos` DESC
 '; 
} 
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 $reqCount6='SELECT FOUND_ROWS();';
 $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $mpsrcount6=mysqli_fetch_row($rescount6);
  $__count=$mpsrcount6[0];
 }
 $lsttbl='';
 if($__count==0){
  $lst.='<p>'.CRLF;
  $lst.=''.txt2('no_record_founded_243_17').''.CRLF;
  $lst.='<a href="todos_action1.php?a=c">'.txt2('add_a_new_record_244_67').'</a>'.CRLF; // todo adjust 
  $lst.='</p>'.CRLF;
  $o1.=''.$lst.''.CRLF;  
 }else{
  $consUrlRedir=''.
                '&amp;xsrch_0='.rawurlencode($xsrch_0). // fld_priority_todos 
                '&amp;xsrch_2='.rawurlencode($xsrch_2). // fld_title_todos 
                '&amp;xsrch_3='.rawurlencode($xsrch_3). // fld_comment_todos 
                '&amp;xsrch_id='.rawurlencode($xsrch_id).
                '&amp;xsrch_tri1='.rawurlencode($xsrch_tri1).
                '';
  $ri='<span class="btn unset">&raquo;</span>';
  if($__start+$__nbMax<$__count){
   $ri='<a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
  }
  $le='<span class="btn unset">&laquo;</span>';
  if($__xpage>0){
   $le='<a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
  }
                
  $o1.='<form method="post">';
  $o1.='<button type="submit" name="addOneToPriorities">'.txt2('Add 1 to priorities_199_68_257_64').'</button>';
  $o1.='&nbsp;<button type="submit" name="subOneToPriorities">'.txt2('Sub 1 to priorities_200_68_258_64').'</button>';
  $o1.='&nbsp;<a href="todos_action1.php?a=c">'.txt2('add_a_new_record_244_67').'</a>'.CRLF;  
  $o1.='&nbsp;'.$le.''.CRLF;  
  $o1.='&nbsp;'.$ri.''.CRLF;  
  $o1.='</form>';

$css='<style type="text/css">
@media screen and (max-width: 850px){
  table.tableResult1 {
    border: 0;
    width:100%;
  }
  table.tableResult1 thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  table.tableResult1 tr {
    border-bottom: 3px solid #eee;
    display: block;
    margin-bottom: 2.001em;
  }
  table.tableResult1 td {
    border-bottom: 1px solid #eee;
    display: block;
    text-align: right!important;
    min-height:30px;
  }
  table.tableResult1 td:before {
    content: attr(data-label);
    float: left!important;
    font-weight:bold;
    margin-right:4px;
  }
  table.tableResult1 td:last-child {border-bottom: 0;}
  table.tableResult1 td.actionColumn div{display:contents;}
  table.tableResult1 td.actionColumn{height:auto;}
  .tableResult1 td {height:auto;word-break: break-all;}
  .tableResult1 td pre {word-break: break-all;white-space: pre-line;}
}
</style>';
  $o1.=$css;

  $lsttbl.='<thead><tr>';
  $lsttbl.='<th>'.txtsys1('column_action').'</th>';
  $lsttbl.='<th>'.txt2('fld_id_todos_125_153').'</th>';
  $lsttbl.='<th>'.txt2('fld_priority_todos_120_153').'</th>';
  $lsttbl.='<th>'.txt2('fld_title_todos_151_50').'</th>';
  $lsttbl.='<th>'.txt2('fld_comment_todos_159_50').'</th>';
  $lsttbl.='</tr></thead><tbody>';
  while($mpsr6=mysqli_fetch_row($result6)){
   
   if($mpsr6[1]==99){
    $lsttbl.='<tr class="success">';   
   }else{
    $lsttbl.='<tr>';   
   }
   
   $lsttbl.='<td data-label="'.txtsys1('column_action').'" style="min-width:260px;">';
   $lsttbl.='<div>';
   $lsttbl.='<a href="todos_action1.php?a=u&amp;id='.$mpsr6[0].'"  class="edit" title="'.txtsys1('edit_button').'">&#9998;</a>';
   $lsttbl.='<a class="danger" href="todos_action1.php?a=d&amp;id='.$mpsr6[0].'" class="danger" title="'.txtsys1('delete_button').'">&#10008;</a>';
   if($mpsr6[1]<99){
    $lsttbl.='<a href="?a=plusOne&amp;id='.$mpsr6[0].''.$consUrlRedir.'" title="'.txt2('add_one_to_this_todo_325_88').'">+1</a>';
   }
   if($mpsr6[1]>0){
    $lsttbl.='<a href="?a=minusOne&amp;id='.$mpsr6[0].''.$consUrlRedir.'" title="'.txt2('sub_one_to_this_todo_328_89').'">-1</a>';
   }   
   if($mpsr6[1]!=99){
    $lsttbl.='<a href="?a=setTo99&amp;id='.$mpsr6[0].''.$consUrlRedir.'" title="'.txt2('setTo99_331_88').'">99</a>';
   }   
   if($mpsr6[1]!=0){
    $lsttbl.='<a href="?a=setTo00&amp;id='.$mpsr6[0].''.$consUrlRedir.'" title="'.txt2('setTo00_334_88').'">00</a>';
   }   
   
   $lsttbl.='</div>';
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_id_todos_125_153').'">';
   $lsttbl.=''.enti1($mpsr6[0]).''; // fld_id_todos
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_priority_todos_120_153').'">';
   $lsttbl.=''.enti1($mpsr6[1]).''; // fld_priority_todos
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_title_todos_151_50').'">';
   $lsttbl.=''.enti1($mpsr6[3]).''; // fld_title_todos
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_comment_todos_159_50').'" ><br />';
   $lsttbl.='<pre>'.enti1(mb_substr($mpsr6[4],0,100)).'</pre>'; // fld_comment_todos  style="white-space: pre-wrap;word-wrap: break-word;"
   $lsttbl.='</td>';

   $lsttbl.='</tr>';
   
  }
  $o1.='<table class="table table-striped table-bordered table-hover table-sm tableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF; // table-condensed
   
  $o1.=' <div>'.CRLF;
  $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_370_99').' )'.CRLF;
  $o1.='   &nbsp;<a class="buttonAdd btn btn-sm btn-primary" href="todos_action1.php?a=c">'.txt2('add_a_new_record_244_67').'</a>'.CRLF; // todo adjust 
  $o1.=' </div>'.CRLF;
   
 }
 mysqli_free_result($result6);
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
}

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();