<?php
if(isset($_POST)&&sizeof($_POST)>0&&isset($_POST['data'])){
 $ret=array('status' => 'KO','message' => array() );
 $ret['input']=json_decode($_POST['data'],true);
 if(isset($ret['input']['funct'])){
  define('BNF' , 'ajax_'.$ret['input']['funct'].'.php' );
  require_once('za_inc.php');
  if(!is_file($GLOBALS['glob_incPath1'].'/ajax/ajax_'.$ret['input']['funct'].'.php')){
   $ret['status']='KO';
   $ret['message'][]='File not founded : "' . $GLOBALS['glob_incPath1'].'/ajax/ajax_'.$ret['input']['funct'].'.php"';
  }else{
   require_once $GLOBALS['glob_incPath1'].'/ajax/ajax_'.$ret['input']['funct'].'.php';
  }
 }else{
  $ret['status']='KO';
  $ret['message'][]='funct is not defined in the input parameters : "'.var_export($ret['input'],true).'"';
 }
}else{
 $ret['status']='KO';
 $ret['message'][]='post data is not defined : "'.var_export($_POST,true).'"'; 
}
header('Content-Type: application/json');
echo json_encode($ret,JSON_FORCE_OBJECT);
exit(0);
