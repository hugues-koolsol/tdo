<?php
function getTdo_zztests1($id){
 $n=array();
 $n['T0_fld_id_zztests']                =0;
 $n['T0_fld_yorno1_zztests']            ='';
 $n['T0_fld_visited_countries_zztests'] ='';
 $n['T0_fld_country1_zztests']          ='';
 $n['T0_fld_title32_zztests']           ='';
 $n['T0_fld_id_parent_zztests']         =null; // null possible
 $n['T0_fld_date1_zztests']             =null; // null possible
 $n['T0_fld_time1_zztests']             =null; // null possible
 $n['T0_fld_dttim1_zztests']            =null; // null possible
 $n['T0_fld_color1_zztests']            ='';
 $n['T0_fld_email1_zztests']            ='';
 $n['T0_fld_zipnum1_zztests']           =0;
 $n['T0_fld_tsupd_zztests']             ='1000-01-01 00:00:00';
 $n['T0_fld_tscrt_zztests']             ='1000-01-01 00:00:00';
 $n['T0_fld_cntupd_zztests']            =0;
 $sql='
  SELECT 
   T0.`fld_id_zztests`                ,T0.`fld_yorno1_zztests`            ,T0.`fld_visited_countries_zztests` ,T0.`fld_country1_zztests`          ,T0.`fld_title32_zztests`           ,
   T0.`fld_id_parent_zztests`         ,T0.`fld_date1_zztests`             ,T0.`fld_time1_zztests`             ,T0.`fld_dttim1_zztests`            ,T0.`fld_color1_zztests`            ,
   T0.`fld_email1_zztests`            ,T0.`fld_zipnum1_zztests`           ,T0.`fld_tsupd_zztests`             ,T0.`fld_tscrt_zztests`             ,T0.`fld_cntupd_zztests`            
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` T0
  WHERE T0.`fld_id_zztests` = '.$id. '
 ';
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $sql , true ) . '</pre>' ; exit(0);
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $row , true ) . '</pre>' ; exit(0);
   $n['T0_fld_id_zztests']                = $row[0];
   $n['T0_fld_yorno1_zztests']            = $row[1];
   $n['T0_fld_visited_countries_zztests'] = $row[2];
   $n['T0_fld_country1_zztests']          = $row[3];
   $n['T0_fld_title32_zztests']           = $row[4];
   $n['T0_fld_id_parent_zztests']         = $row[5];
   $n['T0_fld_date1_zztests']             = $row[6];
   $n['T0_fld_time1_zztests']             = $row[7];
   $n['T0_fld_dttim1_zztests']            = $row[8];
   $n['T0_fld_color1_zztests']            = $row[9];
   $n['T0_fld_email1_zztests']            = $row[10];
   $n['T0_fld_zipnum1_zztests']           = $row[11];
   $n['T0_fld_tsupd_zztests']             = $row[12];
   $n['T0_fld_tscrt_zztests']             = $row[13];
   $n['T0_fld_cntupd_zztests']            = $row[14];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
//======================================================================
//======================================================================
function getTdo_zztests_withParentFields1($id){
 $n=array();
 $n['T0_fld_id_zztests']                =0;
 $n['T0_fld_yorno1_zztests']            ='';
 $n['T0_fld_visited_countries_zztests'] ='';
 $n['T0_fld_country1_zztests']          ='';
 $n['T0_fld_title32_zztests']           ='';
 $n['T0_fld_id_parent_zztests']         =null; // null possible
 $n['T0_fld_date1_zztests']             =null; // null possible
 $n['T0_fld_time1_zztests']             =null; // null possible
 $n['T0_fld_dttim1_zztests']            =null; // null possible
 $n['T0_fld_color1_zztests']            ='';
 $n['T0_fld_email1_zztests']            ='';
 $n['T0_fld_zipnum1_zztests']           =0;
 $n['T0_fld_tsupd_zztests']             ='1000-01-01 00:00:00';
 $n['T0_fld_tscrt_zztests']             ='1000-01-01 00:00:00';
 $n['T0_fld_cntupd_zztests']            =0;
 $n['T1_fld_id_zztests']                =0;
 $n['T1_fld_yorno1_zztests']            ='';
 $n['T1_fld_visited_countries_zztests'] ='';
 $n['T1_fld_country1_zztests']          ='';
 $n['T1_fld_title32_zztests']           ='';
 $n['T1_fld_id_parent_zztests']         =null; // null possible
 $n['T1_fld_date1_zztests']             =null; // null possible
 $n['T1_fld_time1_zztests']             =null; // null possible
 $n['T1_fld_dttim1_zztests']            =null; // null possible
 $n['T1_fld_color1_zztests']            ='';
 $n['T1_fld_email1_zztests']            ='';
 $n['T1_fld_zipnum1_zztests']           =0;
 $n['T1_fld_tsupd_zztests']             ='1000-01-01 00:00:00';
 $n['T1_fld_tscrt_zztests']             ='1000-01-01 00:00:00';
 $n['T1_fld_cntupd_zztests']            =0;
 $sql='
  SELECT 
   T0.`fld_id_zztests`                ,T0.`fld_yorno1_zztests`            ,T0.`fld_visited_countries_zztests` ,T0.`fld_country1_zztests`          ,T0.`fld_title32_zztests`           ,
   T0.`fld_id_parent_zztests`         ,T0.`fld_date1_zztests`             ,T0.`fld_time1_zztests`             ,T0.`fld_dttim1_zztests`            ,T0.`fld_color1_zztests`            ,
   T0.`fld_email1_zztests`            ,T0.`fld_zipnum1_zztests`           ,T0.`fld_tsupd_zztests`             ,T0.`fld_tscrt_zztests`             ,T0.`fld_cntupd_zztests`            ,
   T1.`fld_id_zztests`                ,T1.`fld_yorno1_zztests`            ,T1.`fld_visited_countries_zztests` ,T1.`fld_country1_zztests`          ,T1.`fld_title32_zztests`           ,
   T1.`fld_id_parent_zztests`         ,T1.`fld_date1_zztests`             ,T1.`fld_time1_zztests`             ,T1.`fld_dttim1_zztests`            ,T1.`fld_color1_zztests`            ,
   T1.`fld_email1_zztests`            ,T1.`fld_zipnum1_zztests`           ,T1.`fld_tsupd_zztests`             ,T1.`fld_tscrt_zztests`             ,T1.`fld_cntupd_zztests`            
  FROM ( `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` T0
       )
 LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests`  T1 ON T0.`fld_id_parent_zztests`          = T1.`fld_id_zztests` 
 WHERE 1=1 
   AND T0.`fld_id_zztests`             ='.$id.'
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['T0_fld_id_zztests']                = $row[0];
   $n['T0_fld_yorno1_zztests']            = $row[1];
   $n['T0_fld_visited_countries_zztests'] = $row[2];
   $n['T0_fld_country1_zztests']          = $row[3];
   $n['T0_fld_title32_zztests']           = $row[4];
   $n['T0_fld_id_parent_zztests']         = $row[5];
   $n['T0_fld_date1_zztests']             = $row[6];
   $n['T0_fld_time1_zztests']             = $row[7];
   $n['T0_fld_dttim1_zztests']            = $row[8];
   $n['T0_fld_color1_zztests']            = $row[9];
   $n['T0_fld_email1_zztests']            = $row[10];
   $n['T0_fld_zipnum1_zztests']           = $row[11];
   $n['T0_fld_tsupd_zztests']             = $row[12];
   $n['T0_fld_tscrt_zztests']             = $row[13];
   $n['T0_fld_cntupd_zztests']            = $row[14];
   $n['T1_fld_id_zztests']                = $row[15];
   $n['T1_fld_yorno1_zztests']            = $row[16];
   $n['T1_fld_visited_countries_zztests'] = $row[17];
   $n['T1_fld_country1_zztests']          = $row[18];
   $n['T1_fld_title32_zztests']           = $row[19];
   $n['T1_fld_id_parent_zztests']         = $row[20];
   $n['T1_fld_date1_zztests']             = $row[21];
   $n['T1_fld_time1_zztests']             = $row[22];
   $n['T1_fld_dttim1_zztests']            = $row[23];
   $n['T1_fld_color1_zztests']            = $row[24];
   $n['T1_fld_email1_zztests']            = $row[25];
   $n['T1_fld_zipnum1_zztests']           = $row[26];
   $n['T1_fld_tsupd_zztests']             = $row[27];
   $n['T1_fld_tscrt_zztests']             = $row[28];
   $n['T1_fld_cntupd_zztests']            = $row[29];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}