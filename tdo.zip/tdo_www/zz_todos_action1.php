<?php  // € utf8 check with euro sign
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
require_once $GLOBALS['glob_incPath1'].'/zz_inc_todos1.php';
require_once $GLOBALS['glob_incPath1'].'/zz_inc_users1.php';

openDb1();

//========================================================================================================================
function btl1(){
 return '&nbsp;<a href="zz_todos1.php" class="">'.txtsys1('back_to_the_list').'</a>';
}
//========================================================================================================================
function test_input_tdo_todosKO1(){
 $err=0;
 if($err==0&&!is_numeric($_SESSION[PGMK][NAV][BNF]['fld_priority_todos'])){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_priority_todos must be numerical_23_92');
  $err=1;
 }
 if($GLOBALS['isSuperUser']){
  if($err==0&&!is_numeric($_SESSION[PGMK][NAV][BNF]['fld_id_user_todos'])){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_id_user_todos must be given_28_93'); // dependant field
   $err=1;
  }
 }
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_title_todos']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_title_todos must not be empty_33_92');
  $err=1;
 }
 return($err);
}
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= POST ACTIONS  =====================================================================
 //=================================================================================================================================
 //=================================================================================================================================
// echo __LINE__ . '$_POST=<pre>' . var_export($_POST,true) . '</pre>'; exit();
 $_SESSION[PGMK][NAV][BNF]['fld_priority_todos']        =isset($_POST['fld_priority_todos'])        ?$_POST['fld_priority_todos']        : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_id_user_todos']         =isset($_POST['fld_id_user_todos'])         ?$_POST['fld_id_user_todos']         : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_title_todos']           =isset($_POST['fld_title_todos'])           ?$_POST['fld_title_todos']           : '';
 $_SESSION[PGMK][NAV][BNF]['fld_comment_todos']         =isset($_POST['fld_comment_todos'])         ?$_POST['fld_comment_todos']         : ''; // null possible

 if(!$GLOBALS['isSuperUser']){
  $_SESSION[PGMK][NAV][BNF]['fld_id_user_todos']=$_SESSION[PGMK]['login'];
 }
 
 if($GLOBALS['isSuperUser']){
  // dependant field 
  if(!(isset($_POST['a'])&&($_POST['a']=='cd'||$_POST['a']=='cd'))){ // NOT confirm delete
   $_SESSION[PGMK][NAV][BNF]['choose__fld_id_user_todos'] =isset($_POST['choose__fld_id_user_todos'] )?$_POST['choose__fld_id_user_todos']  :'';
   if($_SESSION[PGMK][NAV][BNF]['choose__fld_id_user_todos']==txtsys1('text_for_the_select_button')){
    $_SESSION[PGMK]['choose']['urlBack']=$_SERVER['HTTP_ORIGIN'].$_SERVER['REQUEST_URI'];
    header('Location: zz_users_choose1.php');
    exit();
   }
  }
 }
 
 //=================================================================================================================================
 //============================================= POST UPDATE =======================================================================
 //=================================================================================================================================
 if(isset($_POST['a'])&&$_POST['a']=='u'){ // update action
  if(test_input_tdo_todosKO1()){
   if(isset($_POST['id1'])&&is_numeric($_POST['id1'])){
    header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }else{
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : POST id1 = ' . $_POST['id1'];
    header('Location: index.php');
    exit();
   }
  }
  if(!$GLOBALS['isSuperUser']){
   $xvalueName=getinc_tdo_todos_withParentFields1($_POST['id1']);
   if($xvalueName['T0_fld_id_user_todos']!=$_SESSION[PGMK]['login']){
    header('Location: zz_todos1.php');
    exit();
   }
  }
  $req6="UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__todos` SET
      `fld_priority_todos`        =  ".$_SESSION[PGMK][NAV][BNF]['fld_priority_todos']                    ."
    , `fld_id_user_todos`         =  ".$_SESSION[PGMK][NAV][BNF]['fld_id_user_todos']                     ."
    , `fld_title_todos`           = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_title_todos'])           ."'
    , `fld_comment_todos`         = ".($_SESSION[PGMK][NAV][BNF]['fld_comment_todos']==''?'NULL':"'".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_comment_todos']) ."'")."
    , `fld_tsupd_todos`           = '".addslashes1($GLOBALS['glob_setdate'])                                 ."'
    , `fld_cntupd_todos`          =  " . ((int)$_POST['fld_cntupd_todos']+1)                              ."
  ";
  $req6.="
   WHERE `fld_id_todos`=".$_POST['id1']."
     AND `fld_cntupd_todos` = ".$_POST['fld_cntupd_todos']."
  ";
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
     break;
    default   :
     $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    break;
   }
   header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
  }else{
   if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])!=1){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('this_record_has_not_been_updated_because_of_an_other_user');
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('please_retry');
    unset($_SESSION[PGMK][NAV][BNF]['fld_priority_todos']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_id_user_todos']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_title_todos']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_comment_todos']);
    header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
   }
   if(isset($_POST['save_the_modification_and_back_to_list'])){
    header('Location: zz_todos1.php');
    exit();
   }else{
    $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('the_modification_has_been_recorded_at') . ' ' . substr($GLOBALS['glob_setdate'],11);
    header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }
  }
 //=================================================================================================================================
 //============================================= POST CONFIRM DELETE ===============================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='cd'){
 
  require_once $GLOBALS['glob_incPath1'].'/__tableDependencies1.php';
  $retDependantTables=dependentValuesExist1(0,'tdo_tbl__todos',$_POST['id1'] );
  if(true === $retDependantTables['valuesExist']){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' . txtsys1('you_cannot_delete_because_some_values_are_still_present_in_dependant_table') . ' ' . var_export( $retDependantTables['tables'] , true ) . ' ';
   header('Location: '.BNF.'?a=d&id='.$_POST['id1']);   
  }
  
  if(!$GLOBALS['isSuperUser']){
   $xvalueName=getinc_tdo_todos_withParentFields1($_POST['id1']);
   if($xvalueName['T0_fld_id_user_todos']!=$_SESSION[PGMK]['login']){
    header('Location: zz_todos1.php');
    exit();
   }
  }
  
  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__todos` WHERE `fld_id_todos`=".$_POST['id1']." " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==1451){ // foreign key constraint
    $xtxterr=txtsys1('error').' ' . __LINE__ . ' ' . txtsys1('constraint_fail');
   }else{
    $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
   }
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
   txtlog1($xtxterr , BNF , __LINE__ , 'error' );
   header('Location: '.BNF.'?a=d&id='.$_POST['id1']);
   exit();
  }else{
   unset($_SESSION[PGMK][NAV][BNF]);
   header('Location: zz_todos1.php');
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CREATE ACTION ================================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='c'){
  if(test_input_tdo_todosKO1()){
   header('Location: '.BNF.'?a=c');
   exit();
  }
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__todos` SET
      `fld_priority_todos`        =  ".$_SESSION[PGMK][NAV][BNF]['fld_priority_todos']                    ."
    , `fld_id_user_todos`         =  ".$_SESSION[PGMK][NAV][BNF]['fld_id_user_todos']                     ."
    , `fld_title_todos`           = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_title_todos'])           ."'
    , `fld_comment_todos`         = ".($_SESSION[PGMK][NAV][BNF]['fld_comment_todos']==''?'NULL':"'".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_comment_todos']) ."'")."
    , `fld_tsupd_todos`           = '".addslashes1($GLOBALS['glob_setdate'])                                ."'
    , `fld_tscrt_todos`           = '".addslashes1($GLOBALS['glob_setdate'])                                ."'
  " ;
//  echo __FILE__ . ' ' . __LINE__ . ' $req6 =' . $req6 . '' ; exit();
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
    break;
    default;
    $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    break;
   }
   header('Location: '.BNF.'?a=c');
   exit();
  }else{
   $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    header('Location: '.BNF.'?a=c');
    exit();
   }else{
    $NewCode=mysqli_fetch_row($resIns);
    $NewCode=$NewCode[0];
    mysqli_free_result($resIns);
    SetSessionMessageAndLog1( txt2('the new value has been inserted_196_36') . ' ('.$NewCode.').' , BNF , __LINE__ , 3);
    if(isset($_POST['record_the_element_and_back_to_list'])){
     header('Location: zz_todos1.php');
     exit();
    }else{
     header('Location: '.BNF.'?a=u&t=n&id='.$NewCode);
     exit();
    }
   }
  }
 }
 
}else{ // get action

 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= GET ACTION ========================================================================
 //=================================================================================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='du'){ // duplicate action
  $xxxFldValues=array();
  $name2=getinc_tdo_todos1($_GET['id']);

  if(!$GLOBALS['isSuperUser']){
   if($name2['T0_fld_id_user_todos']!=$_SESSION[PGMK]['login']){
    header('Location: zz_todos1.php');
    exit();
   }
  }
  
  if($name2['T0_fld_id_todos']==''){
   $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_duplicate_this_value');
   header('Location: zz_todos1.php');
   exit();
  }else{
   // todo set fields for duplicate
   $_SESSION[PGMK][NAV][BNF]['fld_priority_todos']        =$name2['T0_fld_priority_todos'];
   $_SESSION[PGMK][NAV][BNF]['fld_id_user_todos']         =$name2['T0_fld_id_user_todos'];
   $_SESSION[PGMK][NAV][BNF]['fld_title_todos']           =$name2['T0_fld_title_todos'];
   $_SESSION[PGMK][NAV][BNF]['fld_comment_todos']         =$name2['T0_fld_comment_todos'];
   header('Location: '.BNF.'?a=c' );
   exit();
  }
 }
 
 $o1=htmlHead1(array());
 $js1=array();
// echo __LINE__ . '$_SESSION[PGMK]=<pre>' . var_export( $_SESSION[PGMK] , true ) . '</pre>'; exit();
 //=================================================================================================================================
 //============================================= GET DELETE ========================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='d'){ // delete action
  $id=(isset($_GET['id'])&&is_numeric($_GET['id']))?$_GET['id']:0;
  if($id==0){
   header('Location: zz_todos1.php');
   exit();
  }else{
   $xvalueName=getinc_tdo_todos_withParentFields1($_GET['id']);
   if($xvalueName['T0_fld_id_todos']==''){
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_delete_this_value');
    header('Location: zz_todos1.php');
    exit();
   }else{
    if(!$GLOBALS['isSuperUser']){
     if($xvalueName['T0_fld_id_user_todos']!=$_SESSION[PGMK]['login']){
      header('Location: zz_todos1.php');
      exit();
     }
    }
    // use if($xvalueName['field_linked_to_user']!=$_SESSION[PGMK]['login']){ // if the current record you want to update is not yours
    require_once $GLOBALS['glob_incPath1'].'/__tableDependencies1.php';
    $retDependantTables=dependentValuesExist1(0,'tdo_tbl__todos',$_GET['id'] );
    if(isset($retDependantTables['valuesExist']) && $retDependantTables['valuesExist']==true){
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <div>'.CRLF;
     $o1.=__LINE__ . ' '.txtsys1('dependent_values_exist').''.CRLF;
     $o1.=' <ul>'.CRLF;
     foreach( $retDependantTables['tables'] as $k1 => $v1){
      $o1.='  <li>'.$v1.'</li>'.CRLF;
     }
     $o1.=' </ul>'.CRLF;
     $o1.=' </div>'.CRLF;
     $o1.=btl1();
    }else{
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <form method="post" class="formDelete">'.CRLF;
     $o1.='   '.txtsys1('please_confirm_deletion_of').' : '.CRLF;
     $o1.='   <br /><br /><b>'.
           '('.$xvalueName['T0_fld_id_todos'].') '.
           txt2('fld_title_todos_271_17')            . ' : ' .$xvalueName['T0_fld_title_todos'].' <br /> '.
           txt2('fld_login_users_272_17')            . ' : ' .$xvalueName['T1_fld_login_users'].' <br /> '.
           '</b><br />'.CRLF;
     $o1.='   <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
     $o1.='   <input type="hidden" value="cd" name="a" id="a" />'."\r\n";
     $o1.='   <button type="submit" class="danger">'.txtsys1('i_confirm_the_deletion_button').'</button>'.CRLF;
     $o1.=btl1();
     $o1.=' </form>'."\r\n";
      
    }
   }
  }
 //=================================================================================================================================
 //============================================= GET UPDATE ========================================================================
 //=================================================================================================================================
 
 }else if(isset($_GET['a'])&&$_GET['a']=='u'){ // update action
  $xxxFldValues=array();
  $js1=array();
  $o1.='<h2>'.txt2('update a todos_290_20').' ('.$_GET['id'].')'.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $name2=getinc_tdo_todos1($_GET['id']);
  
  if(!$GLOBALS['isSuperUser']){
   if($name2['T0_fld_id_user_todos']!=$_SESSION[PGMK]['login']){
    header('Location: zz_todos1.php');
    exit();
   }
  }
  
  
  $xxxFldValues['T0_fld_priority_todos']        =isset( $_SESSION[PGMK][NAV][BNF]['fld_priority_todos'] )        ? $_SESSION[PGMK][NAV][BNF]['fld_priority_todos']        : $name2['T0_fld_priority_todos']        ;
  $xxxFldValues['T0_fld_id_user_todos']         =isset( $_SESSION[PGMK][NAV][BNF]['fld_id_user_todos'] )         ? $_SESSION[PGMK][NAV][BNF]['fld_id_user_todos']         : $name2['T0_fld_id_user_todos']         ;
  $xxxFldValues['T0_fld_title_todos']           =isset( $_SESSION[PGMK][NAV][BNF]['fld_title_todos'] )           ? $_SESSION[PGMK][NAV][BNF]['fld_title_todos']           : $name2['T0_fld_title_todos']           ;
  $xxxFldValues['T0_fld_comment_todos']         =isset( $_SESSION[PGMK][NAV][BNF]['fld_comment_todos'] )         ? $_SESSION[PGMK][NAV][BNF]['fld_comment_todos']         : $name2['T0_fld_comment_todos']         ;


  $o1.='<form method="post" enctype="multipart/form-data">'.CRLF;

  $o1.=' <input type="hidden" value="u" name="a" id="a" />'.CRLF;
  $o1.=' <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;



  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div style="word-break:break-word;">'.txt2('fld_title_todos_271_17').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input  type="text" value="'.enti1($xxxFldValues['T0_fld_title_todos']).'" name="fld_title_todos" id="fld_title_todos" maxlength="64" style="width:100%;max-width:32em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div style="word-break:break-word;">'.txt2('fld_comment_todos_314_73').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <textarea  name="fld_comment_todos" id="fld_comment_todos"  rows="15" >'.htmlentities($xxxFldValues['T0_fld_comment_todos'],ENT_COMPAT).'</textarea>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div style="word-break:break-word;">'.txt2('fld_priority_todos_321_73').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input  autofocus="autofocus"  type="text" value="'.enti1($xxxFldValues['T0_fld_priority_todos']).'" name="fld_priority_todos" id="fld_priority_todos" maxlength="12" style="width:100;max-width:12em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  if($GLOBALS['isSuperUser']){

   $xDisplayValueFetch = '' ;
   if(
    isset($_SESSION[PGMK][NAV][BNF]['choose__fld_id_user_todos'])&&
    $_SESSION[PGMK][NAV][BNF]['choose__fld_id_user_todos']==txtsys1('text_for_the_select_button')&&
    isset($_SESSION[PGMK]['choose']['valueBack'])
   ){
    if($_SESSION[PGMK][NAV][BNF]['choose__fld_id_user_todos']==txtsys1('text_for_the_select_button')){
     $xxxFldValues['T0_fld_id_user_todos']=$_SESSION[PGMK]['choose']['valueBack'];
    }
    unset($_SESSION[PGMK]['choose']);
   }
   $xGroupValues=getinc_tdo_users1($xxxFldValues['T0_fld_id_user_todos']);
   $xDisplayValueFetch = ' ' .
                          $xGroupValues['T0_fld_login_users'] . ' , ' .
                          $xGroupValues['T0_fld_firstname_users'] . ' , ' .
                          $xGroupValues['T0_fld_lastname_users'] . ' , ' .
                         ' (' . $xGroupValues['T0_fld_id_users'] . ')' . '' ; // todo choose among parent fields 
    
   $o1.='  <div class="fdiv1">'.CRLF;
   $o1.='   <div class="flab1"><div style="word-break:break-word;">'.txt2('parent_fld_id_user_todos_348_75').'</div></div>'.CRLF;
   $o1.='   <div class="finp1"><div>'.CRLF;
   $o1.='    <input type="hidden" value="'.enti1($xxxFldValues['T0_fld_id_user_todos']).'" name="fld_id_user_todos" id="fld_id_user_todos" />'.CRLF;
   $o1.='     <span id="span__dep_fld_id_user_todos">'.$xDisplayValueFetch.'</span>';
   $o1.='    <button type="submit" name="choose__fld_id_user_todos" class="" value="'. txtsys1('text_for_the_select_button') . '">';
   $o1.=''   . txtsys1('text_for_the_select_button') . '';
   $o1.=     '</button>'."\r\n";
   $o1.='   </div></div>'.CRLF;
   $o1.='  </div>'.CRLF;
  }else{
   $o1.='    <input type="hidden" value="'.$_SESSION[PGMK]['login'].'" name="fld_id_user_todos" id="fld_id_user_todos" />'.CRLF;   
  }

  $o1.='<div class="fdiv1">'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="hidden" name="fld_cntupd_todos" id="fld_cntupd_todos" value="'.$name2['T0_fld_cntupd_todos'].'" />'.CRLF;
  $o1.='   <button type="submit" class="">'.txtsys1('save_the_modification').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="save_the_modification_and_back_to_list">'.txtsys1('save_the_modification_and_back_to_list').'</button>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.='</div>'.CRLF;

  $o1.='</form>'.CRLF;

 //=================================================================================================================================
 //============================================= GET VIEW ==========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='v'&&isset($_GET['id'])&&is_numeric($_GET['id'])){ // view action
  // if you vant to do something here, go !
 //=================================================================================================================================
 //============================================= GET CREATE ========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='c'){ // create action
 
  $o1.='<h2>'.txt2('Add a new todos_381_20'). ' '.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $o1.='<form method="post"  enctype="multipart/form-data" class="form1">'.CRLF;
 

  $fld_priority_todos =isset($_SESSION[PGMK][NAV][BNF]['fld_priority_todos'] )?$_SESSION[PGMK][NAV][BNF]['fld_priority_todos']:0;
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div style="word-break:break-word;">'.txt2('fld_priority_todos_321_73').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" autofocus="autofocus" value="'.enti1($fld_priority_todos).'" name="fld_priority_todos" id="fld_priority_todos" maxlength="12" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $fld_title_todos =isset($_SESSION[PGMK][NAV][BNF]['fld_title_todos'] )?$_SESSION[PGMK][NAV][BNF]['fld_title_todos']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div style="word-break:break-word;">'.txt2('fld_title_todos_271_17').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_title_todos).'" name="fld_title_todos" id="fld_title_todos" maxlength="64" style="width:100%;max-width:32em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $fld_comment_todos =isset($_SESSION[PGMK][NAV][BNF]['fld_comment_todos'] )?$_SESSION[PGMK][NAV][BNF]['fld_comment_todos']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div style="word-break:break-word;">'.txt2('fld_comment_todos_314_73').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <textarea  name="fld_comment_todos" id="fld_comment_todos"  rows="15" >'.htmlentities($fld_comment_todos,ENT_COMPAT).'</textarea>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  if($GLOBALS['isSuperUser']){
   $fld_id_user_todos=isset($_SESSION[PGMK][NAV][BNF]['fld_id_user_todos'] )?$_SESSION[PGMK][NAV][BNF]['fld_id_user_todos']:$_SESSION[PGMK]['login'];
   if(
    isset($_SESSION[PGMK][NAV][BNF]['choose__fld_id_user_todos'])&&
    $_SESSION[PGMK][NAV][BNF]['choose__fld_id_user_todos']==txtsys1('text_for_the_select_button')&&
    isset($_SESSION[PGMK]['choose']['valueBack'])
   ){
    if($_SESSION[PGMK][NAV][BNF]['choose__fld_id_user_todos']==txtsys1('text_for_the_select_button')){
     $fld_id_user_todos=$_SESSION[PGMK]['choose']['valueBack'];
    }
    unset($_SESSION[PGMK]['choose']);
   }
   if($fld_id_user_todos!=null){
    $xGroupValues=getinc_tdo_users1($fld_id_user_todos); //$xxxFldValues['T0_fld_id_user_todos']);
    $xDisplayValueFetch = ' ' .
                          $xGroupValues['T0_fld_login_users'] . ' , ' .
                          $xGroupValues['T0_fld_firstname_users'] . ' , ' .
                          $xGroupValues['T0_fld_lastname_users'] . ' , ' .
                          ' (' . $xGroupValues['T0_fld_id_users'] . ')' . '' ;
   }else{
    $xDisplayValueFetch = '';    
   }
   $o1.='  <div class="fdiv1">'.CRLF;
   $o1.='   <div class="flab1"><div style="word-break:break-word;">'.txt2('parent_fld_id_user_todos_348_75').'</div></div>'.CRLF;
   $o1.='   <div class="finp1"><div>'.CRLF;
   $o1.='    <input type="hidden" value="'.enti1($fld_id_user_todos).'" name="fld_id_user_todos" id="fld_id_user_todos" />'.CRLF;
   $o1.='     <span id="span__dep_fld_id_user_todos">'.$xDisplayValueFetch.'</span>';
   $o1.='    <button type="submit" name="choose__fld_id_user_todos" class="btn" value="'. txtsys1('text_for_the_select_button') . '">';
   $o1.=''   . txtsys1('text_for_the_select_button') . '';
   $o1.=     '</button>'."\r\n";
   $o1.='   </div></div>'.CRLF;
   $o1.='  </div>'.CRLF;
  }else{
   $o1.='    <input type="hidden" value="'.$_SESSION[PGMK]['login'].'" name="fld_id_user_todos" id="fld_id_user_todos" />'.CRLF;   
  }

  
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('record_the_element').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="record_the_element_and_back_to_list">'.txtsys1('record_the_element_and_back_to_list').'</button>'.CRLF;
  $o1.='   <input type="hidden" value="0" name="id1" id="id1" />'.CRLF;
  $o1.='   <input type="hidden" value="c" name="a" id="a" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.='</form>'.CRLF;

 }
 $o1.=htmlFoot0(array('js' => $js1));
 dw1($o1);
 if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);
}
