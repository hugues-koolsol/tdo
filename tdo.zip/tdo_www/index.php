<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();


if(isset($_GET['setCss'])){
 include($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/__css.php');
 if(!isset($__css[$_GET['setCss']])){
  $_COOKIE[PGMK.'cssvalue']=1;
  setcookie ( PGMK.'cssvalue' , $_COOKIE[PGMK.'cssvalue'] , time()+3600*24*365);
 }else{
  $_COOKIE[PGMK.'cssvalue']=$_GET['setCss'];
  setcookie ( PGMK.'cssvalue' , $_GET['setCss'] , time()+3600*24*365 );  
 }
 header("HTTP/1.1 303 See Other");header('Location: '.BNF);
 exit(); 
}


$o1='';
$o1.=htmlHead1(array());
if(isset($_GET['message'])){
 if($_GET['message']=='g000001'){
  $o1.='<span style="font-size:2em;">'.txt2('you_are_not_authorized_on_this_page_or_there_is_a_technical_problem_26_45').'</span>';  
 }else{
  $o1.='<span style="font-size:2em;">'.$_GET['message'].'</span>';
 }
 $o1.='<hr />';
}

$o1.='<h1 style="margin:3em auto 2em auto;width:80%; text-align:center;">'.txt2('hello, this is _14_83') . ' ' . PGMK .'</h1>';


$messageNormal=txt2('normal_message_36_21');
$messageWarning=txt2('warning_message_37_22');
$messageDanger=txt2('danger_message_38_21');
$messageSuccess=txt2('success_message_39_22');
$messageError=txt2('error_message_39_22_40_20');
if($messageSuccess!=''||$messageWarning!=''||$messageDanger!=''||$messageNormal!=''||$messageError!=''){
 
 $o1.='<table style="width:89%;margin:5px auto;">';

 if($messageSuccess!=''){
  $o1.='<tr><td class="yysuccess" style="height:50px;text-align:center;border-radius:5px;">'.enti1($messageSuccess) .'</td></tr>';
 }

 if($messageNormal!=''){
  $o1.='<tr><td class="yynormal" style="height:50px;text-align:center;border-radius:5px;">'.enti1($messageNormal) .'</td></tr>';
 }

 if($messageWarning!=''){
  $o1.='<tr><td class="yywarning" style="height:50px;text-align:center;border-radius:5px;">'.enti1($messageWarning) .'</td></tr>';
 }

 if($messageDanger!=''){
  $o1.='<tr><td class="yydanger" style="height:50px;text-align:center;border-radius:5px;">'.enti1($messageDanger) .'</td></tr>';
 }

 if($messageError!=''){
  $o1.='<tr><td class="yyerror" style="height:50px;text-align:center;border-radius:5px;">'.enti1($messageError) .'</td></tr>';
 }

 $o1.='</table>';
 
}


include($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/__css.php');
if(isset($__css)){
 $o1.='  <div style="display:block;margin:2em auto;text-align:center;">'.CRLF;
 foreach($__css as $k1=>$v1){
  $jsonColorBack1=$v1['main']['mainBackgroundColor']['hexValue'];
  $jsonColorBack2=$v1['main']['mainBackgroundColEnd']['hexValue'];
  $jsonColorTxt1=$v1['main']['mainTextColor']['hexValue'];
  if(isset($_COOKIE[PGMK.'cssvalue']) && $k1==$_COOKIE[PGMK.'cssvalue']){
   $o1.='<span class="yybtn" style="background:linear-gradient(to bottom, #'.$jsonColorBack1.' 0%, #'.$jsonColorBack2.' 100%);color:#'.$jsonColorTxt1.';border-style:inset;border-color:#'.$jsonColorTxt1.';border-width:4px;transform:rotatez(90deg);font-weight:bold;">:-)</span>';
  }else{
   $o1.='<a href="'.BNF.'?setCss='.$k1.'" style="background:linear-gradient(to bottom, #'.$jsonColorBack1.' 0%, #'.$jsonColorBack2.' 100%);color:#'.$jsonColorTxt1.';border-color:#'.$jsonColorTxt1.';">:-)</a>';
  }
 }
 $o1.='  </div>'.CRLF;
}




$o1.='<br /><br /><div style="overflow-x:scroll;">'.CRLF;
$o1.='<table class="yythinBorder" style="margin:0 auto;">'.CRLF;
$o1.='<caption style="text-align:center;">'.txt2('ce_tableau_est_adapte_pour_les_mobiles_avec_scroll_33_50').'</caption>'.CRLF;
$o1.='<thead><tr>';
for($i=1;$i<=6;$i++){
 $o1.='<th>&nbsp;&nbsp;&nbsp;c'.$i.'&nbsp;&nbsp;&nbsp;</th>'.CRLF;
}
$o1.='</tr></thead><tbody>'.CRLF;
for($i=1;$i<=5;$i+=1){
 $o1.='<tr>';
 for($j=1;$j<=6;$j+=1){
  $o1.='<td data-label="c'.$j.'">&nbsp;-&nbsp;-&nbsp;data&nbsp;'.($i.''.$j).'&nbsp;-&nbsp;-&nbsp;</td>'.CRLF;
 }
 $o1.='</tr>'.CRLF;
}
$o1.='</tbody>'.CRLF;
$o1.='</table>'.CRLF;
$o1.='</div>'.CRLF;




$o1.=getCss1(600); // todo adjust size

$o1.='<table class="yytableResult1" style="margin:2em auto;width:90%;">'.CRLF;
$o1.='<caption style="text-align:center;">'.txt2('ce_tableau_est_adapte_pour_les_mobiles_19_23').'</caption>'.CRLF;
$o1.='<thead><tr>';
for($i=1;$i<=6;$i++){
 $o1.='<th>c'.$i.'</th>'.CRLF;
}
$o1.='</tr></thead><tbody>'.CRLF;
for($i=1;$i<=4;$i++){
 $o1.='<tr><td class="yyfictif"><hr /></td>';
 for($j=1;$j<=6;$j++){
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
  $o1.='<td data-label="c'.$j.'"> - - data '.($i.''.$j).' - - </td>'.CRLF;
 }
 $o1.='<td class="yyfictif"></td></tr>'.CRLF;
}
$o1.='</tbody>'.CRLF;
$o1.='</table>'.CRLF;


$o1.='<div style="width:10em;margin:2em auto;"><a class="noHide" target="_blank" rel="noreferrer" href="https://www.koolsol.app/" style="width:10em;">koolsol ;-)</a></div>';


$o1.=htmlFoot0(array());
dw1($o1);