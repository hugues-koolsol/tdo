<?php
// group 2 : _anonymous,m:menu,o:order,aj:ajax
$GLOBALS['glob_grpspgs']=array (
  'index.php' => 
  array (
    'm' => '1',
    'o' => '0',
    'aj' => 0,
    'id' => 1,
    'remote' => 1,
  ),
  'login.php' => 
  array (
    'm' => '1',
    'o' => '1',
    'aj' => 0,
    'id' => 2,
    'remote' => 1,
  ),
  'logout.php' => 
  array (
    'm' => 0,
    'o' => 4,
    'aj' => 0,
    'id' => 3,
    'remote' => 1,
  ),
);