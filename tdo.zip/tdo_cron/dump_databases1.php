<?php // €
define('BNF',basename( __FILE__ ));
$GLOBALS['cron_backup']=true;
if(is_file('../za_inc.php')){
 require_once('../za_inc.php');
}else{
 if(is_file('../tdo_www/za_inc.php')){
  require_once('../tdo_www/za_inc.php');
 }else{
  die(__FILE . ' ' . __LINE__ . ' ' . 'Where is the za_inc.php file ?');
 }
}
openDb1();

//================
//== todo start ==
//================

$GLOBALS['emailSendTo']  ='me@mydomain.com';
$GLOBALS['emailHost']    ='mydomain';
$GLOBALS['emailTLD']     ='com';
$GLOBALS['productionUrl']='http://www.mydomain.com/xxx';

if(isset($_SERVER['HTTP_HOST'])){
 if(strpos($_SERVER['HTTP_HOST'],'localhost')!==false){
  $GLOBALS['islocalhost']=true;
 }else{
  $GLOBALS['islocalhost']=false;
 }
}else{
 // todo, find a condition for localhost on your computer for cron execution. Mine is windows so it's easy
 // look in the $_SERVER values a correct condition : 
 // echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_SERVER , true ) . '</pre>' ; exit(0);
 if(isset($_SERVER['OS']) && $_SERVER['OS'] == 'Windows_NT'){
  $GLOBALS['islocalhost']=true;
 }else{
  $GLOBALS['islocalhost']=false;   
 }
 die(__FILE . ' ' . __LINE__ . ' ' . 'todo, find a condition for localhost on your computer for cron execution.'); 
}
die(__FILE . ' ' . __LINE__ . ' ' . 'Fill the parameters before line '.__LINE__.' please'); // fill the parameters upper and comment this line

echo __FILE__ . ' ' . __LINE__ . ' localhost is ' . var_export( $GLOBALS['islocalhost'] , true ) . '' ; exit(0);

// $GLOBALS['islocalhost'] should be false on the server and true on your local computer

//==============
//== todo end ==
//==============

$GLOBALS['emailSendFrom']='noreply-'.PGMK.' <no-reply@'.$GLOBALS['emailHost'].'.'.$GLOBALS['emailTLD'].'>';

$GLOBALS['now']=time();
if(!is_dir('tempBackup1')){
 if(!mkdir('tempBackup1',0777)){
  die(__FILE__ . ' ' . __LINE__ . ' error cannot create tempBackup1' ); 
 }
}

$GLOBALS['table_definition']=array();


//============================================================================================================================================
function myemail($subject,$body,$destinataire){
 if( ( isset($GLOBALS['islocalhost']) && $GLOBALS['islocalhost']==true ) || ( isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST']=='localhost' ) ){
  echo "\r\n\r\n".'fonction myemail' ."\r\n=======\r\n" . 'subject=' . $subject . "\r\n=======\r\n" . 'body=' . "\r\n" . $body . "\r\n=======\r\n\r\n";
 }else{
  $from="From: ".$GLOBALS['emailSendFrom']."\n";
  if(strpos($_SERVER['HTTP_HOST'],$GLOBALS['emailHost'])!==false){
   $from = "From: ".$GLOBALS['emailHost']." ".PGMK." <no-reply@".$GLOBALS['emailHost'].".".$GLOBALS['emailTLD'].">\n"; // ajout du champ From
  }
  $headers = $from;
  $headers .='Content-Type: text/html; charset="utf-8"'."\r\n";
  $headers .='Content-Transfer-Encoding: 8bit';
  $message.= '<html>'.CRLF;
  $message.= '<head>'.CRLF;
  $message.= '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'.CRLF;
  $message.= '<title>'.$subject.'</title>'.CRLF;
  $message.= '</head>';
  $message.= '<body style="background-color:white;margin:0;padding:0;border:0;font-size:0.9em;color:#444;">'.CRLF;
  $message.= ' <table style="width:100%;border:1px #FFFFFF outset;" align="center">'.CRLF;
  $message.= '  <tr>'.CRLF;
  $message.= '   <td style="text-align:center;" align="center">'.CRLF;
  $message.=$body;
  $message.= '  </tr>'.CRLF;
  $message.= ' </table>'.CRLF;
  $message.= '</body>'.CRLF;
  $message.= '</html>'.CRLF;
  
  if(mail(trim($destinataire), $subject , $message, $headers)){
//   echo "Envoi du mail reussi.";
  }else{
//   echo "Erreur : l'envoi du mail a échoué.";
  } 
 }
}
//============================================================================================================================================
function creerCsv($tabpar , $fdmysql , $fdlibof , $kbase , $tableProp ){

 $premiereLignelibof='';
 $listeDesChamps='';
 $tabChamps=array();
 $sql0='DESC `'.$GLOBALS['glob_db'][$kbase]['dbname'].'`.`' . $tabpar['vtable']['tableName'] .'`';
 $res0=mysqli_query($GLOBALS['glob_db'][$kbase]['link'],$sql0);
 if(mysqli_errno($GLOBALS['glob_db'][$kbase]['link'])==0){
  while($mpsr0=mysqli_fetch_row($res0)){
   if($premiereLignelibof!='') $premiereLignelibof.=';';
   $premiereLignelibof.=$mpsr0[0];
   if($listeDesChamps!='') $listeDesChamps.=' , ';
   if(
       strpos(strtolower($mpsr0[1]),'geometry'          )!==false
     ||strpos(strtolower($mpsr0[1]),'point'             )!==false
     ||strpos(strtolower($mpsr0[1]),'linestring'        )!==false
     ||strpos(strtolower($mpsr0[1]),'polygon'           )!==false
     ||strpos(strtolower($mpsr0[1]),'multipoint'        )!==false
     ||strpos(strtolower($mpsr0[1]),'multilinestring'   )!==false
     ||strpos(strtolower($mpsr0[1]),'multipolygon'      )!==false
     ||strpos(strtolower($mpsr0[1]),'geometrycollection')!==false
   ){
    $listeDesChamps.='ST_AsText(`'.$mpsr0[0].'`)'; // ST_GeomFromText 
   }else if(
       strpos(strtolower($mpsr0[1]),'blob'     )!==false
    || strpos(strtolower($mpsr0[1]),'binary'   )!==false
    || strpos(strtolower($mpsr0[1]),'varbinary')!==false
   ){
    $listeDesChamps.='CONCAT("0x",HEX(CAST(`'.$mpsr0[0].'` AS CHAR(10000) CHARACTER SET utf8mb4)))'; // todo, adjust size
   }else{
    // always export to utf-8
    $listeDesChamps.='CONVERT(`'.$mpsr0[0].'` USING utf8mb4)';
   }
   $mpsr0['transform']=isset($GLOBALS['__remoteTables'][$tabpar['vtable']['tableName']]['fld_restore_transform_tables'])?$GLOBALS['__remoteTables'][$tabpar['vtable']['tableName']]['fld_restore_transform_tables']:'';
   $mpsr0['ignore_for_import']=false;
   $mpsr0['use_default_value']=0;
   $mpsr0['default_value']='todo';
   $tabChamps[]=$mpsr0;
  }
  mysqli_free_result($res0);
 }else{
  myemail(
    __LINE__ . ' Attention les sauvegardes n\'ont pas été faites' , 
   'Erreur de sql='. $sql0 . ', mysqli_error()='.mysqli_error($GLOBALS['glob_db'][$kbase]['link']) .''.  "\r\n" .' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
   $GLOBALS['emailSendTo']
   );
  die(__FILE__ . ' ' . __LINE__ . ' Sauvegardes non effectuées');
 }
 $GLOBALS['table_definition'][$tableProp['dbInd']][$tableProp['tableName']]=$tabChamps;

 fwrite( $fdlibof , "\xef\xbb\xbf".$premiereLignelibof . "\r\n" );
 $sql0='SELECT ' . $listeDesChamps . ' FROM `'.$GLOBALS['glob_db'][$kbase]['dbname'].'`.`' . $tabpar['vtable']['tableName'] .'`';
 $res0=mysqli_query($GLOBALS['glob_db'][$kbase]['link'],$sql0);
 if(mysqli_errno($GLOBALS['glob_db'][$kbase]['link'])==0){
  while($mpsr0=mysqli_fetch_row($res0)){
   $donneesLibreOffice=''; 
   $donneesMysql='';
   $countChamp=0;
   foreach($mpsr0 as $kd1 => $vd1){
    $nomChamp =$tabChamps[$kd1][0];
    $typeChamp=$tabChamps[$kd1][1];
    $nullPossible=$tabChamps[$kd1][2];
    $valeurChamp=$vd1;
    if(
       strpos(strtolower($typeChamp),'int(')!==false
     ||strpos(strtolower($typeChamp),'decimal(')!==false
     ||strpos(strtolower($typeChamp),'float(')!==false
     ||strpos(strtolower($typeChamp),'double(')!==false
     ||strpos(strtolower($typeChamp),'real(')!==false
     ||strpos(strtolower($typeChamp),'bit(')!==false
     ||strpos(strtolower($typeChamp),'year(')!==false
     ||strpos(strtolower($typeChamp),'serial(')!==false
    ){
     $format='num';
    }else if(
       strpos(strtolower($typeChamp),'geometry')!==false
     ||strpos(strtolower($typeChamp),'point')!==false
     ||strpos(strtolower($typeChamp),'linestring')!==false
     ||strpos(strtolower($typeChamp),'polygon')!==false
     ||strpos(strtolower($typeChamp),'multipoint')!==false
     ||strpos(strtolower($typeChamp),'multilinestring')!==false
     ||strpos(strtolower($typeChamp),'multipolygon')!==false
     ||strpos(strtolower($typeChamp),'geometrycollection')!==false
    ){ 
     $format='geometry';
    }else if(
       strpos(strtolower($typeChamp),'char')!==false
     ||strpos(strtolower($typeChamp),'text')!==false
     ||strpos(strtolower($typeChamp),'blob')!==false
     ||strpos(strtolower($typeChamp),'enum(')!==false
     ||strpos(strtolower($typeChamp),'set(')!==false
     ||strpos(strtolower($typeChamp),'timestamp')!==false
     ||strpos(strtolower($typeChamp),'datetime')!==false
     ||strpos(strtolower($typeChamp),'date')!==false
     ||strpos(strtolower($typeChamp),'time')!==false
     ||strpos(strtolower($typeChamp),'json')!==false
    ){
     $format='texte';
    }else{
     myemail(
       __LINE__ . ' Attention les sauvegardes n\'ont pas été faites' , 
      'Erreur de sql sur le champ = ' . $nomChamp . '' . "\r\n\r\n" . '  le type de champ n\'est pas trouve : "' . $typeChamp . '"' . "\r\n\r\n" . ' sql=' . $sql0 . '' ."\r\n\r\n".' , $mpsr0=' . var_export( $mpsr0 , true ) . '' . "\r\n\r\n" .' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
      $GLOBALS['emailSendTo']
      );
     die(__FILE__ . ' ' . __LINE__ . ' Sauvegardes non effectuées');
    }
    if($donneesLibreOffice!='') $donneesLibreOffice.=';';
    if($donneesMysql!='') $donneesMysql.=';';
    if($format=='texte'){
     $donneesLibreOffice.='"'.str_replace('"','""',$valeurChamp).'"';
     $donneesMysql.='"'.str_replace('"','\\"',str_replace('\\','\\\\',$valeurChamp)).'"';
    }else if($format=='geometry'){ // same as text because ST_AsText used SELECT upper
     $donneesLibreOffice.='"'.str_replace('"','""',$valeurChamp).'"';
     $donneesMysql.='"'.str_replace('"','\\"',str_replace('\\','\\\\',$valeurChamp)).'"';
    }else if($format=='num'){
     $donneesLibreOffice.='' .$valeurChamp.'';
     $donneesMysql.='"'.$valeurChamp.'"';
    }
    $countChamp++;
   }
   $donneesLibreOffice.="\r\n"; 
   fwrite($fdlibof,$donneesLibreOffice);
   $donneesMysql.="\r\n"; 
   fwrite($fdmysql,$donneesMysql);
  }
  mysqli_free_result($res0);
 }else{
  myemail(
    __LINE__ . ' Attention les sauvegardes n\'ont pas été faites' , 
   'Erreur de sql='. $sql0 . ', mysqli_error()='.mysqli_error($GLOBALS['db'][0]['link']) .''.  "\r\n" .' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
   $GLOBALS['emailSendTo']
   );
  die(__FILE__ . ' ' . __LINE__ . ' Sauvegardes non effectuées');
 }
 return true;
}
//============================================================================================================================================
$uniqName=uniqid();
foreach( $GLOBALS['glob_db'] as $k1 => $v1){

 $files = glob(realpath('tempBackup1').DIRECTORY_SEPARATOR.'{,.}*', GLOB_BRACE);
 foreach($files as $file){ // iterate files
  if(is_file($file)){
   unlink($file); // delete file
  }
 }
 if(is_file(realpath('../'.$GLOBALS['glob_incPath1'] . DIRECTORY_SEPARATOR. '__remoteTables.php'))){
  require_once(realpath('../'.$GLOBALS['glob_incPath1'] . DIRECTORY_SEPARATOR. '__remoteTables.php'));
 }else{
  if(is_file(realpath('../tdo_www/'.$GLOBALS['glob_incPath1'] . DIRECTORY_SEPARATOR. '__remoteTables.php'))){
   require_once(realpath('../tdo_www/'.$GLOBALS['glob_incPath1'] . DIRECTORY_SEPARATOR. '__remoteTables.php'));
  }else{
   die(__FILE . ' ' . __LINE__ . ' ' . 'Where is the __remoteTables.php file ?');
  }
 }
 
 $tableList=array();
 $GLOBALS['glob_db'][$k1]['link']=mysqli_connect($v1['server'],$v1['user'],$v1['password'],$v1['dbname']);
 mysqli_set_charset( $GLOBALS['glob_db'][$k1]['link'] , 'utf8mb4' ); // DO THIS, IMPORTANT
 // create table list
 if($GLOBALS['glob_db'][$k1]['link']){
  $sql='  
    SELECT `table_name` FROM `information_schema`.`tables`
     WHERE `table_type` = \'BASE TABLE\' AND `table_schema`=\''.$GLOBALS['glob_db'][$k1]['dbname'].'\'  
     ORDER BY `table_name` ASC; 
  ';  
  if(!($result=mysqli_query($GLOBALS['glob_db'][$k1]['link'],$sql))) {
   die(__FILE__ . ' ' . __LINE__ . ' error ' . $v1['server'] . ' / ' . $v1['user'] . '  mysqli_error='. mysqli_error($GLOBALS['glob_db'][$k1]['link']) );
  }else{
   while( $row = mysqli_fetch_row( $result ) ){
    if(true||$row[0]=='test'){ // todo : do some test here if you want to remove some tables
     if(isset($GLOBALS['__remoteTables'][$row[0]])){
      $tableList[]=array(
       'tableName'=>$row[0] ,
       'dbInd'    =>$k1     ,
       'type'     =>'table' ,
      );      
     }
    }
   }
   mysqli_free_result($result);
  }

  // todo : if you want to backup the views, uncomment this block
  
/*
  $sql='  
    SELECT `table_name` FROM `information_schema`.`views`
     WHERE `table_type` = \'BASE TABLE\' AND `table_schema`=\''.$GLOBALS['glob_db'][$k1]['dbname'].'\'  
     ORDER BY `table_name` ASC; 
  ';  
  if(!($result=mysqli_query($GLOBALS['glob_db'][$k1]['link'],$sql))) {
   die(__FILE__ . ' ' . __LINE__ . ' error ' . $v1['server'] . ' / ' . $v1['user'] . '  mysqli_error='. mysqli_error($GLOBALS['glob_db'][$k1]['link']) );
  }else{
   while( $row = mysqli_fetch_row( $result ) ){
    if(true||$row[0]=='test'){ // do some test here if you want to remove some views
     $tableList[]=array(
      'tableName'=>$row[0] ,
      'dbInd'    =>$k1     ,
      'type'     =>'view'  ,
     );
    }
   }
   mysqli_free_result($result);
  }   
*/ 
  
  
  
 }else{
  die(__FILE__ . ' ' . __LINE__ . ' cannot connect to ' . $v1['server'] . ' / ' . $v1['user']);
 }

 sort($tableList);
 
 
 // create sql create table
 $texteFichier='';
 foreach($tableList as $k0 => $v0){
  $sql0='SHOW CREATE TABLE `'.$GLOBALS['glob_db'][$k1]['dbname'].'`.`' . $v0['tableName'] .'`';
  $res0=mysqli_query($GLOBALS['glob_db'][$k1]['link'],$sql0);
  if(mysqli_errno($GLOBALS['glob_db'][$k1]['link'])==0){
   while($mpsr0=mysqli_fetch_row($res0)){
    $texteFichier.='--'."\r\n".'-- ' . $v0['tableName'] ."\r\n".'--'."\r\n" . $mpsr0[1] . ';' . "\r\n";
   }
   mysqli_free_result($res0);
  }else{
   die(__FILE__ . ' ' . __LINE__ . ' error ' . $v1['server'] . ' / ' . $v1['user'] . '  mysqli_error='. mysqli_error($GLOBALS['glob_db'][$k1]['link']) );
  }
 }
 if($fd=fopen(realpath('tempBackup1').DIRECTORY_SEPARATOR.'dump_structure.sql','w')){
  if(!fwrite($fd,$texteFichier)){
   die(__FILE__ . ' ' . __LINE__ . ' error ' . $v1['server'] . ' / ' . $v1['user'] . '  cannot write '  );  
  }
 }else{
  die(__FILE__ . ' ' . __LINE__ . ' error ' . $v1['server'] . ' / ' . $v1['user'] . '  cannot open '  );  
 }
 $GLOBALS['tabFichiers']=array();
 //============================================================================================================================================
 foreach($tableList as $ktable => $vtable){
  $GLOBALS['tabFichiers'][]=array(
   'ktable'       => $ktable,
   'vtable'       => $vtable,
   'csv_libof'    => 'libof_'.$vtable['type'].'_'.$vtable['dbInd'].'_'.$vtable['tableName'].'.csv',
   'csv_mysql'    => 'mysql_'.$vtable['type'].'_'.$vtable['dbInd'].'_'.$vtable['tableName'].'.csv',
   'fd'     => 0,
   'dbInd'        => $vtable['dbInd']
  );
 }
 
 
 // create data files
 foreach($GLOBALS['tabFichiers'] as $k0 => $v0){
  @unlink(realpath('tempBackup1').DIRECTORY_SEPARATOR.$v0['csv_mysql']);
  @unlink(realpath('tempBackup1').DIRECTORY_SEPARATOR.$v0['csv_libof']);
  $fdlibof=fopen(realpath('tempBackup1').DIRECTORY_SEPARATOR.$v0['csv_libof'],'wb');
  $fdmysql=fopen(realpath('tempBackup1').DIRECTORY_SEPARATOR.$v0['csv_mysql'],'wb');
  if($fdmysql!==false&&$fdlibof!==false){
   if(creerCsv($v0 , $fdmysql , $fdlibof, $v0['dbInd'] , $v0['vtable'])){
   }else{
    myemail(
      __LINE__ . ' Attention les sauvegardes n\'ont pas été faites' , 
     'Impossible de creer le csv pour ' . var_export( $v0 , true ) . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
     $GLOBALS['emailSendTo']
     );
    die('Sauvegardes non effectuées');
   }
   fclose($fdmysql);
   fclose($fdlibof);
  }else{
   myemail(
     __LINE__ . ' Attention les sauvegardes n\'ont pas été faites' , 
    'Impossible de creer le fichier ' . $v0['csv'] . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
    $GLOBALS['emailSendTo']
   );
   die('Sauvegardes non effectuées');
  }
 }
 $GLOBALS['FichierZip']=array(
  array( 'nom' => 'ziplibof.zip', 'src' => 'csv_libof' ),
  array( 'nom' => 'zipMysql.zip', 'src' => 'csv_mysql' ),
 );

 // create zip files
 foreach( $GLOBALS['FichierZip'] as $kzip => $vzip ){ //
  @unlink(realpath('tempBackup1').DIRECTORY_SEPARATOR.$vzip['nom']);
  $zip = new ZipArchive();
  if($zip->open(realpath('tempBackup1').DIRECTORY_SEPARATOR.$vzip['nom'], ZIPARCHIVE::CREATE)!==TRUE) {
    myemail(
     __FILE__ . ' ' .__LINE__ . ' Attention les sauvegardes ont pas été faites mais le fichier zip n\'a pas pu être fait' , 
     'Impossible de creer le fichier ' . $vzip['nom'] . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
     $GLOBALS['emailSendTo']
    );
    die('Sauvegardes non effectuées');
  }
  foreach($GLOBALS['tabFichiers'] as $k0 => $v0){
   if(!$zip->addFile('tempBackup1'.DIRECTORY_SEPARATOR.$v0[$vzip['src']],$v0[$vzip['src']])){ // no realpath here ????
    myemail(
     __FILE__ . ' ' .__LINE__ . ' Attention les sauvegardes ont pas été faites , le fichier zip n\'a pas pu être fait' , 
     'Impossible d\'ajouter le fichier ' . $v0[$vzip['src']] . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
     $GLOBALS['emailSendTo']
    );
    die('Sauvegardes non effectuées');
   }
  }
  $ziplibofStatus=$zip->status;
  $zip->close();

  if($ziplibofStatus==0){
   foreach($GLOBALS['tabFichiers'] as $k0 => $v0 ){
    @unlink(realpath('tempBackup1').DIRECTORY_SEPARATOR.$v0[$vzip['src']]); // delete csv file
   }
  }
 }
 
 if($fd=fopen(realpath('tempBackup1').DIRECTORY_SEPARATOR.'php_import.php','w')){
  if(!fwrite($fd,'<'.'?php'."\r\n".'$__tableImport=' . var_export( $GLOBALS['table_definition'] , true ) .';')){
   die(__FILE__ . ' ' . __LINE__ . ' error ' . $v1['server'] . ' / ' . $v1['user'] . '  cannot write '  );  
  }
  fclose($fd);
 }else{
  die(__FILE__ . ' ' . __LINE__ . ' error ' . $v1['server'] . ' / ' . $v1['user'] . '  cannot open '  );  
 }

 // create final zip file
 $nomFinal=''.date('Y-m-d-H-i-s').'_backupDb.zip';
 @unlink(realpath('tempBackup1').DIRECTORY_SEPARATOR.$nomFinal);
 $zip = new ZipArchive();
 if($zip->open(realpath('tempBackup1').DIRECTORY_SEPARATOR.$nomFinal, ZIPARCHIVE::CREATE)!==TRUE) {
   myemail(
    __FILE__ . ' ' .__LINE__ . ' Attention les sauvegardes ont pas été faites mais le fichier zip n\'a pas pu être fait' , 
    'Impossible de creer le fichier ' . $vzip['nom'] . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
    $GLOBALS['emailSendTo']
   );
   die('Sauvegardes non effectuées');
 }
 $tabZips=array('zipMysql.zip','ziplibof.zip','dump_structure.sql','php_import.php');
 foreach($tabZips as $k0 => $v0){
  if(!$zip->addFile('tempBackup1'.DIRECTORY_SEPARATOR.$v0,$v0)){
   myemail(
    __FILE__ . ' ' .__LINE__ . ' Attention les sauvegardes ont pas été faites , le fichier zip n\'a pas pu être fait' , 
    'Impossible d\'ajouter le fichier ' . $v0 . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
    $GLOBALS['emailSendTo']
   );
   die('Sauvegardes non effectuées');
  }
 }
 $zipFinalStatus=$zip->status;
 $zip->close();
 if($zipFinalStatus==0){
  foreach($tabZips as $k0 => $v0 ){
   @unlink(realpath('tempBackup1').DIRECTORY_SEPARATOR.$v0);
  }
 }
 // here, one should send that zip to a ftp and then...
 if(false){
  // ftp transfert zip file
 }
 //
 //
 // ... move the document in the uploaded documents and create an entry in the database
 $targetDir=realpath('..'.DIRECTORY_SEPARATOR.$GLOBALS['glob_noVcDirName']).DIRECTORY_SEPARATOR.$GLOBALS['glob_userDirName'].DIRECTORY_SEPARATOR.'_backups'.DIRECTORY_SEPARATOR.date('Y').DIRECTORY_SEPARATOR.date('m').DIRECTORY_SEPARATOR.date('d');
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $targetDir , true ) . '</pre>' ; exit(0);
 if(!is_dir($targetDir)){
  if(!mkdir($targetDir,0777,true)){
   myemail(
    __FILE__ . ' ' .__LINE__ . ' Attention les sauvegardes ont pas été déplacées ' , 
    'Impossible de creer le repertoire ' . $targetDir . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
    $GLOBALS['emailSendTo']
   );
   die('Sauvegardes non effectuées');

  }
 }
 if(!rename(realpath('tempBackup1').DIRECTORY_SEPARATOR.$nomFinal , $targetDir.DIRECTORY_SEPARATOR.$nomFinal )){
  myemail(
   PGMK . ' Attention les sauvegardes n\'ont pas été déplacées ' , 
   'Impossible d\'ajouter le fichier ' . $v0 . ' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
   $GLOBALS['emailSendTo']
  );
  die('Sauvegardes non effectuées');
 }
 
 $pathInDb='_backups'.'/'.date('Y').'/'.date('m').'/'.date('d').'/'.$nomFinal;
 $fileSize=filesize($targetDir.DIRECTORY_SEPARATOR.$nomFinal);

 $req6="
  INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__uploadeddocs` SET
     `fld_name_uploadedDocs`          = '".addslashes1($nomFinal)                ."'
   , `fld_originalName_uploadedDocs`  = '".addslashes1($nomFinal)                ."'
   , `fld_isPicture_uploadedDocs`     = '0'
   , `fld_pictureWidth_uploadedDocs`  =  0
   , `fld_pictureHeight_uploadedDocs` =  0
   , `fld_documentType_uploadedDocs`  = 'zip'
   , `fld_weight_uploadedDocs`        =  ".$fileSize                             ."
   , `fld_path_uploadedDocs`          = '".addslashes1($pathInDb)                ."'
   , `fld_userId_uploadedDocs`        =  1
   , `fld_tsupd_uploadedDocs`         = '".addslashes1($GLOBALS['glob_setdate']) ."'
   , `fld_tscrt_uploadedDocs`         = '".addslashes1($GLOBALS['glob_setdate']) ."'
 " ;

 $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
  myemail(
   __FILE__ . ' ' .__LINE__ . ' Attention les sauvegardes ont pas été déplacées ' , 
   'Impossible d\'ajouter le fichier dans la base. erreur=' .mysqli_error($GLOBALS['glob_db'][0]['link']).' . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
   $GLOBALS['emailSendTo']
  );
  die('Sauvegardes non effectuées');
 }else{
  $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $NewCode=mysqli_fetch_row($resIns);
   $NewCode=$NewCode[0];
   mysqli_free_result($resIns);
   myemail(
    $GLOBALS['emailHost'] . ' ' . PGMK . ' Sauvegardes OK ' , 
    'Les sauvegardes ont été réalisées correctement, '."\r\n\r\n".'<a href="'.$GLOBALS['productionUrl'].'/uploadeddocs1.php?xsrch_id='.$NewCode.'">Téléchargez les</a> ' ,
    $GLOBALS['emailSendTo']
   );
  }else{
   myemail(
    __LINE__ . ' Attention les sauvegardes ont été faites mais récupération du LAST_INSERT_ID() KO ' , 
    'Attention les sauvegardes ont été faites mais récupération du LAST_INSERT_ID() KO . Le : ' . date('d/m/Y') . ' à ' . date('H:i:s') . ' en ligne ' . __LINE__ ,
    $GLOBALS['emailSendTo']
   );
  }
 }
}
echo 'Good job!';