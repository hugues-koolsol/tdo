<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
$isLoginAndLoginPage=false;
if($ret['input']['page']=='login.php'){
 $isLoginAndLoginPage=true;
}

if($isLoginAndLoginPage || true===checkGroupAjaxPages()){
 if(is_file($ret['input']['page'])){ 
  $ret['message'][]='Founded "'.$ret['input']['page'].'"';
  $fileOutput='';
  $arrFile=file($ret['input']['page']);
  $count=0;
  $someErrors=array();
  openDb2();
  $oneChange=false;
  $original='txt1('.var_export($ret['input']['key'],true).')';
 // if($fdtoto=fopen('toto.txt','a+')){ fwrite($fdtoto, $original ); fclose($fdtoto); }
  
  $alreadyInserted=false;
  foreach($arrFile as $k1 => $v1){
   $pos1=strpos($v1,$original);
   if($pos1!==false){
    $s1=substr($v1,0,$pos1);
    $s2=substr($v1,$pos1+strlen($original));
    $newKey=$ret['input']['key'].'_'.$ret['input']['line'].'_'.$ret['input']['column'];
    $s3=$s1.'txt2('.var_export($newKey,true).')'.$s2;
    $arrFile[$k1]=$s3;
    if(false==$alreadyInserted){
     $req6="
      INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
        `fld_key_lngVals`     = '".addslashes1($newKey)                  ."'
      , `fld_lang_lngVals`    = '".addslashes1($ret['input']['lang'])    ."'
      , `fld_page_id_lngVals` = '".$ret['input']['page_id'] ."'
      , `fld_value_lngVals`   = '".addslashes($ret['input']['value'])   ."'
      , `fld_tsupd_lngVals`   = '".$GLOBALS['glob_setdate']                  ."'
      , `fld_tscrt_lngVals`   = '".$GLOBALS['glob_setdate']                  ."'
     " ;
 //    if($fdtoto=fopen('toto.txt','a+')){ fwrite($fdtoto, $req6 ); fclose($fdtoto); }
     $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
     if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
      $someErrors[]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']);
     }else{
      $oneChange=true;
      $alreadyInserted=true;
     }
    }
   }
   $count++;
  }
   
  if(sizeof($someErrors)==0 && $oneChange ){
   foreach($arrFile as $k1 => $v1){
    $fileOutput.=$v1;
   }
   file_put_contents(str_replace('.php','.php',$ret['input']['page']),$fileOutput);
   $ret['status']='OK';
   require_once($GLOBALS['glob_incPath1'].'/ajax/ajax_writeTranslationFiles1.php');
  }
 }else{
  $ret['message']='Cannot find "'.$ret['input']['page'].'"';
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}