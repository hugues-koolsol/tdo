<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 
  openDb1();
  $filesArray=scandir( 'js' ,SCANDIR_SORT_ASCENDING);
  $filesArray2=array();
  foreach($filesArray as $k1=>$v1){
    if($v1=='.'||$v1=='..'||substr($v1,0,1)=='_'){
      unset($filesArray[$k1]);
    }else{
      $filesArray2[]=array(
       'fileName' => 'js/'.$v1,
       'updated'  => false
      );
    }
  }
  foreach($filesArray2 as $k1=>$v1){
   $filesArray2[$k1]['content']=file($v1['fileName']);
  }
  
  $fileOutput='';
//  $arrFile=file($ret['input']['page']);
  $count=0;
  $someErrors=array();
  $oneChange=false;
  $original='txt1(\''.$ret['input']['key'].'\')';
  $arrayInserted=array();
  foreach( $filesArray2 as $k0=>$v0){
    foreach($v0['content'] as $k1 => $v1){
      $pos1=strpos($v1,$original);
      if($pos1!==false){
        $s1=substr($v1,0,$pos1);
        $s2=substr($v1,$pos1+strlen($original));
        $newKey=$ret['input']['key'].'_'.$ret['input']['line'].'_'.$ret['input']['column'];
        $s3=$s1.'txt2(\''.$newKey.'\')'.$s2;
        $filesArray2[$k0]['content'][$k1]=$s3;
        $filesArray2[$k0]['updated']=true;
        $theKey='__'.$newKey.'__'.$ret['input']['lang'];
        if(!in_array($theKey,$arrayInserted)){
          $req6="
           INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
             `fld_key_lngVals`     = '".addslashes1($newKey)                  ."'
           , `fld_lang_lngVals`    = '".addslashes1($ret['input']['lang'])    ."'
           , `fld_type_lngVals`    = 'javascript'
           , `fld_value_lngVals`   = '".addslashes1($ret['input']['value'])   ."'
           , `fld_tsupd_lngVals`   = '".$GLOBALS['glob_setdate']                  ."'
           , `fld_tscrt_lngVals`   = '".$GLOBALS['glob_setdate']                  ."'
          " ;
          $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
          if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
            $ret['message'][]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']);
          }else{
            $oneChange=true;
            $arrayInserted[]=$theKey;
            $ret['message'][]=$v0['fileName'];
          }
        }
      }
      $count++;
    }
  }
  if($GLOBALS['glob_isLocalHost']){
    if(sizeof($someErrors)==0 ){
      if($oneChange){
        foreach( $filesArray2 as $k0=>$v0){
          $ret['message'][]=$v0['fileName'] . ' ' . $v0['updated'] ;
          if($v0['updated']==true){
            $fileOutput='';
            foreach($v0['content'] as $k1 => $v1){
             $fileOutput.=$v1;
            }
            file_put_contents($v0['fileName'],$fileOutput);
          }
        }
      }
      $ret['status']='OK';
      $ret['input']['type']='javascript';
      require_once($GLOBALS['glob_incPath1'].'/ajax/ajax_writeTranslationFiles1.php');
    }
  }else{
    if(sizeof($someErrors)==0 ){
      $ret['status']='OK';
      $ret['input']['type']='javascript';
      require_once($GLOBALS['glob_incPath1'].'/ajax/ajax_writeTranslationFiles1.php');
    }
  }
  
 
 
 
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
} 