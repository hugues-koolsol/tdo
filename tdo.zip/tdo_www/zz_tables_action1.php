<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
checkGroupPages();
require_once $GLOBALS['glob_incPath1'].'/tables1.php';

openDb2();
//========================================================================================================================
function btl1(){
 return ' <a href="zz_tables1.php" class="">'.txtsys1('back_to_the_list').'</a>';
}
//========================================================================================================================
function test_input_tdo_tablesKO1(){
 $err=0;
 if($err==0&&!is_numeric($_SESSION[PGMK][NAV][BNF]['fld_id_server_tables'])){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_id_server_tables must be numerical_18_92');
  $err=1;
 }
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_name_tables']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_name_tables must not be empty_22_92');
  $err=1;
 }
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_system_tables']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_system_tables must not be empty_26_92');
  $err=1;
 }
 return($err);
}
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= POST ACTIONS  =====================================================================
 //=================================================================================================================================
 //=================================================================================================================================
// echo __LINE__ . '$_POST=<pre>' . var_export($_POST,true) . '</pre>'; exit();
 $_SESSION[PGMK][NAV][BNF]['fld_id_server_tables'] =isset($_POST['fld_id_server_tables']) ?$_POST['fld_id_server_tables'] : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_name_tables']      =isset($_POST['fld_name_tables'])      ?$_POST['fld_name_tables']      : '';
 $_SESSION[PGMK][NAV][BNF]['fld_system_tables']    =isset($_POST['fld_system_tables'])    ?$_POST['fld_system_tables']    : '';
 //=================================================================================================================================
 //============================================= POST UPDATE =======================================================================
 //=================================================================================================================================
 if(isset($_POST['a'])&&$_POST['a']=='u'){ // update action
  if(test_input_tdo_tablesKO1()){
   if(isset($_POST['id1'])&&is_numeric($_POST['id1'])){
    header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }else{
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : POST id1 = ' . $_POST['id1'];
    header('Location: index.php');
    exit();
   }
  }
  $req6="UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tables` SET
      `fld_id_server_tables` =  ".$_SESSION[PGMK][NAV][BNF]['fld_id_server_tables']             ."
    , `fld_name_tables`      = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_name_tables'])      ."'
    , `fld_system_tables`    = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_system_tables'])    ."'
    , `fld_tsupd_tables`     = '".addslashes1($GLOBALS['glob_setdate'])                           ."'
    , `fld_cntupd_tables`    =  " . ((int)$_POST['fld_cntupd_tables']+1)                        ."
  ";
  $req6.="
   WHERE `fld_id_tables`=".$_POST['id1']."
     AND `fld_cntupd_tables` = ".$_POST['fld_cntupd_tables']."
  ";
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
     break;
    default   :
     $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 2 );
    break;
   }
   header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
  }else{
   if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])!=1){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('this_record_has_not_been_updated_because_of_an_other_user');
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('please_retry');
    unset($_SESSION[PGMK][NAV][BNF]['fld_id_server_tables']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_name_tables']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_system_tables']);
    header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
   }
   
   sqllog1( $req6 , BNF , __LINE__ );
   require_once $GLOBALS['glob_incPath1'].'/tablelinks1.php';
   writeTableDependencies1();
   if(isset($_POST['save_the_modification_and_back_to_list'])){
    header('Location: zz_tables1.php');
    exit();
   }else{
    $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('the_modification_has_been_recorded_at') . ' ' . substr($GLOBALS['glob_setdate'],11);
    header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }
  }
 //=================================================================================================================================
 //============================================= POST CONFIRM DELETE ===============================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='cd'){
 
  require_once $GLOBALS['glob_dataPath1'].'/generated/__tableDependencies1.php';
  $retDependantTables=dependentValuesExist1(0,'tdo_tbl__tables','fld_id_tables',$_POST['id1'] );
  if(true === $retDependantTables['valuesExist']){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' . txtsys1('you_cannot_delete_because_some_values_are_still_present_in_dependant_table') . ' ' . var_export( $retDependantTables['tables'] , true ) . ' ';
   header('Location: '.BNF.'?a=d&id='.$_POST['id1']);   
  }

//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tables` WHERE `fld_id_tables`=".$_POST['id1']." " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
   txtlog1($xtxterr , BNF , __LINE__ , 2 );
   header('Location: '.BNF.'?a=d&id='.$_POST['id1']);
   exit();
  }else{
   sqllog1( $req6 , BNF , __LINE__ );
   unset($_SESSION[PGMK][NAV][BNF]);
   require_once $GLOBALS['glob_incPath1'].'/tablelinks1.php';
   writeTableDependencies1();
   header('Location: zz_tables1.php');
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CREATE ACTION ================================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='c'){
  if(test_input_tdo_tablesKO1()){
   header('Location: '.BNF.'?a=c');
   exit();
  }
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tables` SET
      `fld_id_server_tables` =  ".$_SESSION[PGMK][NAV][BNF]['fld_id_server_tables']             ."
    , `fld_name_tables`      = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_name_tables'])      ."'
    , `fld_system_tables`    = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_system_tables'])    ."'
    , `fld_tsupd_tables`     = '".addslashes1($GLOBALS['glob_setdate'])                          ."'
    , `fld_tscrt_tables`     = '".addslashes1($GLOBALS['glob_setdate'])                          ."'
  " ;
//  echo __FILE__ . ' ' . __LINE__ . ' $req6 =' . $req6 . '' ; exit();
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
    break;
    default;
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 2 );
    break;
   }
   header('Location: '.BNF.'?a=c');
   exit();
  }else{
   sqllog1( $req6 , BNF , __LINE__ );
   $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 2 );
    header('Location: '.BNF.'?a=c');
    exit();
   }else{
    $NewCode=mysqli_fetch_row($resIns);
    $NewCode=$NewCode[0];
    mysqli_free_result($resIns);
    SetSessionMessageAndLog1( txt2('the new value has been inserted_174_36') . ' ('.$NewCode.').' , BNF , __LINE__ , 3);
    require_once $GLOBALS['glob_incPath1'].'/tablelinks1.php';
    writeTableDependencies1();
    if(isset($_POST['record_the_element_and_back_to_list'])){
     header('Location: zz_tables1.php');
     exit();
    }else{
     header('Location: '.BNF.'?a=u&t=n&id='.$NewCode);
     exit();
    }
   }
  }
 }
 
}else{ // get action

 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= GET ACTION ========================================================================
 //=================================================================================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='du'){ // duplicate action
  $xxxFldValues=array();
  $name2=getTdo_tables1($_GET['id']);
  if($name2['fld_id_tables']==''){
   $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_duplicate_this_value');
   header('Location: zz_tables1.php');
   exit();
  }else{
   $_SESSION[PGMK][NAV][BNF]['fld_id_server_tables'] =$name2['fld_id_server_tables'];
   $_SESSION[PGMK][NAV][BNF]['fld_name_tables']      =$name2['fld_name_tables'];
   $_SESSION[PGMK][NAV][BNF]['fld_system_tables']    =$name2['fld_system_tables'];
   header('Location: '.BNF.'?a=c' );
   exit();
  }
 }
 
 $o1=htmlHead1(array());
 $js1=array();
// echo __LINE__ . '$_SESSION[PGMK]=<pre>' . var_export( $_SESSION[PGMK] , true ) . '</pre>'; exit();
 //=================================================================================================================================
 //============================================= GET DELETE ========================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='d'){ // delete action
  $id=(isset($_GET['id'])&&is_numeric($_GET['id']))?$_GET['id']:0;
  if($id==0){
   header('Location: zz_tables1.php');
   exit();
  }else{
   $xvalueName=getTdo_tables1($_GET['id']);
   if($xvalueName['fld_id_tables']==''){
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_delete_this_value');
    header('Location: zz_tables1.php');
    exit();
   }else{
    require_once $GLOBALS['glob_dataPath1'].'/generated/__tableDependencies1.php';
    $retDependantTables=dependentValuesExist1(0,'tdo_tbl__tables','fld_id_tables',$_GET['id'] );
    if(isset($retDependantTables['valuesExist']) && $retDependantTables['valuesExist']==true){
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <div>'.CRLF;
     $o1.=' '.txtsys1('dependent_values_exist').''.CRLF;
     $o1.=' <ul>'.CRLF;
     foreach( $retDependantTables['tables'] as $k1 => $v1){
      $o1.='  <li>'.$v1.'</li>'.CRLF;
     }
     $o1.=' </ul>'.CRLF;
     $o1.=' </div>'.CRLF;
     $o1.=btl1();
    }else{
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <form method="post" class="formDelete">'.CRLF;
     $o1.='   '.txtsys1('please_confirm_deletion_of').' : '.CRLF;
     $o1.='   <br /><br /><b>'.
          '('.$xvalueName['fld_id_tables'].') '.
          txt2('fld_name_tables_248_16') . ' : ' .$xvalueName['fld_name_tables'].' <br /> '.
          '</b><br />'.CRLF;
     $o1.='   <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
     $o1.='   <input type="hidden" value="cd" name="a" id="a" />'."\r\n";
     $o1.='   <button type="submit" class="danger">'.txtsys1('i_confirm_the_deletion_button').'</button>'.CRLF;
     $o1.=btl1();
     $o1.=' </form>'."\r\n";
    }
   }
  }
 //=================================================================================================================================
 //============================================= GET UPDATE ========================================================================
 //=================================================================================================================================
 
 }else if(isset($_GET['a'])&&$_GET['a']=='u'){ // update action
  $xxxFldValues=array();
  $js1=array();
  $o1.='<h4>'.txt2('update a record_265_20').' ('.$_GET['id'].')'.btl1().'</h4>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $name2=getTdo_tables1($_GET['id']);
  $xxxFldValues['fld_id_server_tables'] =isset( $_SESSION[PGMK][NAV][BNF]['fld_id_server_tables'] ) ? $_SESSION[PGMK][NAV][BNF]['fld_id_server_tables'] : $name2['fld_id_server_tables'] ;
  $xxxFldValues['fld_name_tables']      =isset( $_SESSION[PGMK][NAV][BNF]['fld_name_tables'] )      ? $_SESSION[PGMK][NAV][BNF]['fld_name_tables']      : $name2['fld_name_tables']      ;
  $xxxFldValues['fld_system_tables']    =isset( $_SESSION[PGMK][NAV][BNF]['fld_system_tables'] )    ? $_SESSION[PGMK][NAV][BNF]['fld_system_tables']    : $name2['fld_system_tables']    ;


  $o1.='<form method="post" >'.CRLF;

  $o1.=' <input type="hidden" value="u" name="a" id="a" />'.CRLF;
  $o1.=' <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_id_server_tables_278_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_id_server_tables']).'" name="fld_id_server_tables" id="fld_id_server_tables" maxlength="12" style="width:100;max-width:12em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_name_tables_248_16').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_name_tables']).'" name="fld_name_tables" id="fld_name_tables" maxlength="128" style="width:100%;max-width:130em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_system_tables_293_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $retParam=displayParam2('yorno',$xxxFldValues['fld_system_tables'],'fld_system_tables',array('unsetPossible'=>false,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.='<div class="fdiv1">'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="hidden" name="fld_cntupd_tables" id="fld_cntupd_tables" value="'.$name2['fld_cntupd_tables'].'" />'.CRLF;
  $o1.='   <button type="submit" class="">'.txtsys1('save_the_modification').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="save_the_modification_and_back_to_list">'.txtsys1('save_the_modification_and_back_to_list').'</button>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.='</div>'.CRLF;

  $o1.='</form>'.CRLF;

 //=================================================================================================================================
 //============================================= GET VIEW ==========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='v'&&isset($_GET['id'])&&is_numeric($_GET['id'])){ // view action
  // if you vant to do something here, go !
 //=================================================================================================================================
 //============================================= GET CREATE ========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='c'){ // create action
 
  $o1.='<h2>'.txt2('Add a new record_321_20'). ' '.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $o1.='<form method="post" class="form1">'.CRLF;
 

  $fld_id_server_tables =isset($_SESSION[PGMK][NAV][BNF]['fld_id_server_tables'] )?$_SESSION[PGMK][NAV][BNF]['fld_id_server_tables']:0;
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_id_server_tables_278_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_id_server_tables).'" name="fld_id_server_tables" id="fld_id_server_tables" maxlength="12" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  if(isset($_GET['new'])){ 
   $_SESSION[PGMK][NAV][BNF]['fld_name_tables']=$_GET['new'];
  }
  $fld_name_tables =isset($_SESSION[PGMK][NAV][BNF]['fld_name_tables'] )?$_SESSION[PGMK][NAV][BNF]['fld_name_tables']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_name_tables_248_16').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_name_tables).'" name="fld_name_tables" id="fld_name_tables" maxlength="128" style="width:100%;max-width:130em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $fld_system_tables =isset($_SESSION[PGMK][NAV][BNF]['fld_system_tables'] )?$_SESSION[PGMK][NAV][BNF]['fld_system_tables']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_system_tables_293_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $retParam=displayParam2('yorno',$fld_system_tables,'fld_system_tables',array('unsetPossible'=>false,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('record_the_element').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="record_the_element_and_back_to_list">'.txtsys1('record_the_element_and_back_to_list').'</button>'.CRLF;
  $o1.='   <input type="hidden" value="0" name="id1" id="id1" />'.CRLF;
  $o1.='   <input type="hidden" value="c" name="a" id="a" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.='</form>'.CRLF;

 }
 $o1.=htmlFoot0(array('js' => $js1));
 dw1($o1);
 if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);
}