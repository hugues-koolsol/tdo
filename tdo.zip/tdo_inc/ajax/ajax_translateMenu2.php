<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 openDb1();
 $req6="
  UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
    `fld_value_lngVals`   = '".addslashes1($ret['input']['value']) ."'
  WHERE `fld_id_lngVals`  = '".$ret['input']['id']            ."'
 " ;
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $ret['status']='OK';
 }else{
  echo 'mysqli_error() "'.mysqli_error($GLOBALS['glob_db'][0]['link']).'" , $req6='.$req6;
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}