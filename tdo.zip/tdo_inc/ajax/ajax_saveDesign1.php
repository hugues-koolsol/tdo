<?php
// do not forget to put this file in the file list !
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 openDb1();
// if($fd=fopen('toto.txt','a')){fwrite($fd,''.date('Y-m-d H:i:s'). ' ' . __LINE__ ."\r\n".'$ret='.var_export($ret,true)."\r\n"); fclose($fd);}
 if($fd=fopen($GLOBALS['glob_incPath1'].'/__design1.php','w')){
  fwrite($fd,'<'.'?php'.CRLF.'$__design1='.var_export($ret['input']['design1'],true).';');
  fclose($fd);
  $ret['status']='OK';
  $ret['message'][]='hello' . BNF;    
 }else{
  $ret['message'][]='KO write in ' . BNF . ' in line ' . __LINE__ ;
 }
 $err=0;
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;   
}