"use strict";
//=====================================================================================================================
/*
usefull colors :
globalCssSettings1.main.mainBackgroundColor.hexValue
globalCssSettings1.main.mainTextColor.hexValue
globalCssSettings1.main.thinBorderColor.hexValue
*/
var globalTimeoutSlowServer = 1500; // after 1.5 seconds of waiting response a message appears.
var globalScrollWidth1 = 0;
var dkW = 0,
    dkH = 0;
var theModal1 = null;
//=====================================================================================================================
var jsonTree2 = null;
var options2 = null;
//=====================================================================================================================
function displayTodosModal1() {
    var r = new XMLHttpRequest();
    r.open("POST", 'za_ajax.php?todo1', true);
    r.timeout = 6000;
    r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    r.onreadystatechange = function() {
        if (r.readyState != 4 || r.status != 200) return;
        try {
            var jsonRet = JSON.parse(r.responseText);
            if (jsonRet.status == 'OK') {
                //      console.log(jsonRet.data);
                if (jsonRet.data) {
                    jsonTree2 = jsonRet.data;
                    options2 = { sortOnly: true };
                    var $o1 = '';
                    $o1 += '<form method="post">';
                    $o1 += ' <input type="hidden" id="sortedTodos2" name="sortedTodos2" value="" />';
                    $o1 += ' <button type="submit" id="buttonSort1" name="buttonSort1" value="sortTodos" style="" >' + txt2('record_these_priorities_2_15') + '</button>';
                    $o1 += '</form>';
                    $o1 += '<br /><br />';
                    $o1 += '<div id="container2" class="yythinBorder" style="max-width:80%;overflow-y:scroll;max-height:500px;margin:2px auto;">';
                    $o1 += '     <div id="myTreeId2"></div>';
                    $o1 += '</div>';
                    $o1 += '<script src="js/hdtree.js?v=20171122-1917"></script>';

                    $o1 += '<br /><br /><br />';

                    var theModalContent = document.createElement('div');
                    theModalContent.innerHTML = $o1;

                    var opt = {
                        x: 0,
                        y: 0,
                        bodyModalContent: theModalContent,
                        centerVertical: true,
                        centerHorizontal: true,
                        fullScreenForBigScreen: false,
                    }
                    theModal1.showModal(opt);
                    // cMyTree1
                    if (oMyTree2 === null) {
                        var theBody = document.getElementsByTagName('body')[0];
                        var theScript = document.createElement('script');
                        theScript.src = 'js/hdtree.js';
                        theScript.type = 'text/javascript';
                        theScript.onload = function() {
                            sortTodos2(null);
                        }
                        theBody.appendChild(theScript);
                    } else {
                        sortTodos2(null);
                    }
                    return;
                } else {
                    alert('' + txt2('nothing_to_do_68_23') + '');
                }

            } else {
                display_ajax_error_in_cons(jsonRet);
                console.log(r);
                alert('BAD job !');
                return;
            }
        } catch (e) {
            console.error(e, r);
            return;
        }
    };
    r.onerror = function(e) {
        console.error('e=', e);
        return;
    }
    var data = {
        funct: 'todo1',
    }
    r.send('data=' + encodeURIComponent(JSON.stringify(data)));
}
//=====================================================================================================================
function initSortModalTodo1() {
    if (theModal1 === null) {
        loadScriptModal(displayTodosModal1);
    } else {
        displayTodosModal1();
    }
}
//=====================================================================================================================
function loadScriptModal(func) {
    var theBody = document.getElementsByTagName('body')[0];
    var theScript = document.createElement('script');
    theScript.src = 'js/modal1.js';
    theScript.type = 'text/javascript';
    theScript.onload = function() {
        theModal1 = new modal1({});
        func();
    }
    theBody.appendChild(theScript);
}
//===============================================================================================================================
function debounce(func, wait, immediate) {
    var timeout;
    return function() {
        var context = this,
            args = arguments;
        var later = function() {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        var callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
};

//=====================================================================================================================
function is_touch_device() {
    return (('ontouchstart' in window) || (navigator.MaxTouchPoints > 0) || (navigator.msMaxTouchPoints > 0));
}
//=====================================================================================================================
function scrollBack2(par) {
    var y = parseInt(getCookie('scrollTop1'), 10);
    if (y > 0) {
        if (par.value === '1') {
            setTimeout(function() { window.scrollTo(0, y); }, 50);
        }
    }
    try {
        document.cookie = 'scrollTop1=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    } catch (e) {}
}
//=====================================================================================================================
function setScrollBackValue1(t) {
    var supportPageOffset = window.pageXOffset !== undefined;
    var isCSS1Compat = ((document.compatMode || "") === "CSS1Compat");
    // var x = supportPageOffset ? window.pageXOffset : isCSS1Compat ? document.documentElement.scrollLeft : document.body.scrollLeft;
    var y = supportPageOffset ? window.pageYOffset : isCSS1Compat ? document.documentElement.scrollTop : document.body.scrollTop;
    setCookie('scrollTop1', y);
    var p = t.parentNode;
    var countMax = 100;
    try {
        while (p.nodeName.toLowerCase() !== 'form' && --countMax > 0) {
            p = p.parentNode;
        }
    } catch (t) {}
    if (p.nodeName.toLowerCase() === 'form') {
        var input = document.createElement('input'); //prepare a new input DOM element
        input.setAttribute('name', t.name); //set the param name
        input.setAttribute('value', t.value); //set the value
        input.setAttribute('type', 'hidden') //set the type
        p.appendChild(input); //append the input to the form
        p.submit();
    }
}
//=====================================================================================================================
function getScrollTopValue1() {
    var supportPageOffset = window.pageXOffset !== undefined;
    var isCSS1Compat = ((document.compatMode || "") === "CSS1Compat");
    // var x = supportPageOffset ? window.pageXOffset : isCSS1Compat ? document.documentElement.scrollLeft : document.body.scrollLeft;
    var y = supportPageOffset ? window.pageYOffset : isCSS1Compat ? document.documentElement.scrollTop : document.body.scrollTop;
    return y;
}
//=====================================================================================================================
function topOfPage() {
    window.scrollTo(0, 0);
}
//=====================================================================================================================
function getPageSize() {
    if (typeof(window.innerWidth) === 'number') {
        dkW = window.innerWidth;
        dkH = window.innerHeight;
    } else {
        if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
            dkW = document.documentElement.clientWidth;
            dkH = document.documentElement.clientHeight;
        } else {
            if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
                dkW = document.body.clientWidth;
                dkH = document.body.clientHeight;
            }
        }
    }
}
//=====================================================================================================================
function setBadge1(targetField, value) {
    document.getElementById(targetField).value = value;
}
//=====================================================================================================================
function submitListFromSelect1(elem) {
    var parentFormFounded = false;
    var par = elem.parentNode;
    var parentTag = par.tagName.toLowerCase();
    var goOn = true;
    while (goOn) {
        if (parentTag == 'form') {
            parentFormFounded = true;
            goOn = false;
        } else {
            if (parentTag == 'body') {
                goOn = false;
            }
        }
        if (goOn) {
            par = par.parentNode;
            parentTag = par.tagName.toLowerCase();
        }
    }
    if (parentFormFounded == true) {
        par.submit();
    }
}
//=====================================================================================================================
function fillValueField1(fieldName, value) {
    document.getElementById(fieldName).value = value;
}
//=====================================================================================================================
function closeColor1(divId) {
    document.getElementById(divId).style.display = 'none';
}
//=====================================================================================================================
function putColor1(valueId, value, buttonId, divId, displayId, objTxt, withColorNull, searchColorMode, callBackColor1, forceValue) {
    //       putColor1('xsrch_7','F0F8FF','button_color_xsrch_7','div_of_button_color_xsrch_7',''       ,'{"hexValue":"F0F8FF","webValue":"F0F8FF","webName":"aliceblue","pantoneName":"","hsvValue":"5,5,100","rgbValue":"240,248,255"}','1'          ,'1'            ,'onChangeColorListForm1'); 
    var oldValue = document.getElementById(valueId).value;
    var newValue = '';
    if (forceValue !== null && typeof(forceValue) != "undefined") {
        if (displayId != '') {
            document.getElementById(displayId).innerHTML = forceValue;
        }
        document.getElementById(valueId).value = forceValue;
        newValue = forceValue;
        if (searchColorMode == 1) {
            if (forceValue == '') {
                document.getElementById(buttonId).innerHTML = txt2('color all_30_54');
            } else if (forceValue == 'NULL') {
                document.getElementById(buttonId).innerHTML = txt2('color null_32_54');
            } else if (forceValue == 'NOT NULL') {
                document.getElementById(buttonId).innerHTML = txt2('color not null_34_54');
            }
        }
    } else {
        //  console.log('searchColorMode='+searchColorMode,'divId='+divId);
        if (searchColorMode == 1) {
            document.getElementById(valueId).value = value;
            newValue = value;
            document.getElementById(buttonId).innerHTML = value;
        } else {
            if (displayId != '') {
                var disp = '';
                var obj = JSON.parse(objTxt);
                disp += '<div style="width:35px;height:35px;border:1px #eee inset;background-color:#' + obj.hexValue + '"></div>';
                disp += '<div>' + obj.hexValue + (obj.webName != '' ? ',' + obj.webName : '') + (obj.pantoneName != '' ? ',pantone=' + obj.pantoneName : '') + (obj.materialName != '' ? ',material=' + obj.materialName : '') + '</div>';
                document.getElementById(displayId).innerHTML = disp;
            }
            document.getElementById(valueId).value = objTxt;
            newValue = objTxt;
        }
        // {"hexValue":"7FFFD4","webValue":"7FFFD4","webName":"aquamarine","pantoneName":"","hsvName":"50,50,100"}
    }
    closeColor1(divId);
    // console.log('callBackColor1=',callBackColor1);
    if (callBackColor1) {
        if (!(callBackColor1 == 'undefined' || callBackColor1 == null || callBackColor1 == '')) {
            if (oldValue != newValue) {
                eval('' + callBackColor1 + '(\'' + valueId + '\');');
            }
        }
    }

}
//=====================================================================================================================
function onChangeColorListForm1(fieldName) {
    // console.log(fieldName);

    var parentFormFounded = false;
    var par = document.getElementById(fieldName).parentNode;
    var parentTag = par.tagName.toLowerCase();
    var goOn = true;
    while (goOn) {
        if (parentTag == 'form') {
            parentFormFounded = true;
            goOn = false;
        } else {
            if (parentTag == 'body') {
                goOn = false;
            }
        }
        if (goOn) {
            par = par.parentNode;
            parentTag = par.tagName.toLowerCase();
        }
    }
    if (parentFormFounded == true) {
        par.submit();
    }
}

//=====================================================================================================================
function fillDivColor1(valueId, buttonId, divId, displayId, withColorNull, searchColorMode, colorInit, callBackColor1) {
    console.log('divId=' + divId);

    var couleurActuelle = document.getElementById(valueId).value.substr(1).toUpperCase();
    if (couleurActuelle >= '000000' && couleurActuelle <= 'FFFFFF') {} else {
        couleurActuelle = 'FFFFFF';
    }

    var x = '<div>';
    x += '<table style="width:100%;"><tbody><tr>';
    if (searchColorMode == 1) {
        x += '<td style="width:12.4%;text-align:right;">';
        x += '<a href="javascript:putColor1(\'' + valueId + '\',\'\',\'' + buttonId + '\',\'' + divId + '\',\'' + displayId + '\',{},\'' + withColorNull + '\',\'' + searchColorMode + '\',\'' + callBackColor1 + '\',\'\')">' + txt2('color all_30_54') + '</a>';
        x += '</td>';
        x += '<td style="width:12.4%;text-align:right;">';
        x += '<a href="javascript:putColor1(\'' + valueId + '\',\'\',\'' + buttonId + '\',\'' + divId + '\',\'' + displayId + '\',{},\'' + withColorNull + '\',\'' + searchColorMode + '\',\'' + callBackColor1 + '\',\'NULL\')">' + txt2('color null_32_54') + '</a>';
        x += '</td>';
        x += '<td style="width:12.4%;text-align:right;">';
        x += '<a href="javascript:putColor1(\'' + valueId + '\',\'\',\'' + buttonId + '\',\'' + divId + '\',\'' + displayId + '\',{},\'' + withColorNull + '\',\'' + searchColorMode + '\',\'' + callBackColor1 + '\',\'NOT NULL\')">' + txt2('color not null_34_54') + '</a>';
        x += '</td>';
    } else {
        if (withColorNull == 1) {
            x += '<td style="width:12.4%;text-align:right;">';
            x += '<a href="javascript:putColor1(\'' + valueId + '\',\'\',\'' + buttonId + '\',\'' + divId + '\',\'' + displayId + '\',{},\'' + withColorNull + '\',\'' + searchColorMode + '\',\'' + callBackColor1 + '\',\'\')">' + txt2('color null_32_54') + '</a>';
            x += '</td>';
        }
    }
    x += '<td style="width:12.4%;text-align:right;">';
    x += ' <a href="javascript:closeColor1(\'' + divId + '\')" style="color:red;">&times;</a>';
    x += '</td>';
    x += '</tr></tbody></table>';
    x += '<iframe width="400" height="690" border="0" ';
    x += ' src="js/_cpicker/index.html?version=0';
    x += '&withColorNull=' + withColorNull + '';
    x += '&searchColorMode=' + searchColorMode + '';
    x += '&divId=' + divId + '';
    x += '&displayId=' + displayId + '';
    x += '&buttonId=' + buttonId + '';
    x += '&v=' + couleurActuelle + '';
    x += '&callBackColor1=' + callBackColor1 + '';
    x += '&c=putColor1(\'' + valueId + '\',[value],[buttonId],[divId],[displayId],[obj],[withColorNull],[searchColorMode],[callBackColor1])"';
    x += '></iframe>';
    x += '<br style="clear:both;"/>';
    // console.log('x=',x);
    document.getElementById(divId).innerHTML = x;

}
//=====================================================================================================================
function setColor1(valueId, buttonId, displayId, withColorNull, searchColorMode, callBackColor1) { // 
    // console.log(valueId,buttonId);
    var widthPop = 410;
    var heightPop = 740;
    try {
        var divId = document.getElementById('div_of_' + buttonId);
        if (null == divId) {
            var divId = document.createElement('div');
            divId.id = 'div_of_' + buttonId;
            divId.style.width = widthPop + 'px';
            divId.style.height = heightPop + 'px';
            divId.style.position = 'absolute';
            divId.style.backgroundColor = '#' + globalCssSettings1.main.mainBackgroundColor.hexValue + '';
            divId.style.left = '0px';
            divId.style.top = '0px';
            divId.style.border = '2px #' + globalCssSettings1.main.thinBorderColor.hexValue + ' outset';
            divId.style.display = 'none';
            document.getElementsByTagName('body')[0].appendChild(divId);
        }
    } catch (e) {
        console.error(e);
    }
    getPageSize();
    var pos1 = document.getElementById(buttonId).getBoundingClientRect();
    if (dkW < 500) {
        divId.style.left = '0px';
        divId.style.top = (parseInt(pos1.top, 10) + getScrollTop1() + 40) + 'px';
    } else {
        if (parseInt(pos1.left, 10) + widthPop > dkW) {
            if ((dkW - widthPop - 30) < 0) {
                divId.style.left = '0px';
            } else {
                divId.style.left = (dkW - widthPop - 30) + 'px';
            }
        } else {
            divId.style.left = parseInt(pos1.left, 10) + 'px';
        }
        divId.style.top = (parseInt(pos1.top, 10) + getScrollTop1()) + 'px';
    }
    divId.style.display = 'block';
    var hourInit = 0,
        minutInit = 0,
        secondInit = 0;
    var yearInit = 0,
        monthInit = 0,
        dayInit = 0;

    var value = document.getElementById(valueId).value;
    if (value == 'NULL' || value == 'NOT NULL' || value == '') {
        var colorInit = '#ffffff';
    } else {
        var colorInit = value;
    }

    fillDivColor1(valueId, buttonId, 'div_of_' + buttonId, displayId, withColorNull, searchColorMode, colorInit, callBackColor1);
}

//=====================================================================================================================
function nextMonthDateTime1(valueId, buttonId, divId, nM, nY, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1) {
    if (nM == 12) {
        nM = '01';
        nY += 1;
    } else {
        nM = (nM + 1) < 10 ? '0' + (nM + 1) : nM + 1;
    }
    // console.log(nY+'-'+nM);
    fillDivDateTime1(valueId, buttonId, divId, nY + '-' + nM, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, 0);
}
//=====================================================================================================================
function previousMonthDateTime1(valueId, buttonId, divId, nM, nY, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1) {
    if (nM == 1) {
        nM = '12';
        nY -= 1;
    } else {
        nM = (nM - 1) < 10 ? '0' + (nM - 1) : nM - 1;
    }
    // console.log(nY+'-'+nM);
    fillDivDateTime1(valueId, buttonId, divId, nY + '-' + nM, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, 0);
}
//=====================================================================================================================
function putDateTime1(nH, nM, nS, valueId, buttonId, divId, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1) {
    if (nH == -3 && nM == -3 && nS == -3) {
        var theTime = '';
        var theTimeTxt = txt2('time all_20_23');
    } else if (nH == -2 && nM == -2 && nS == -2) {
        var theTime = 'NOT NULL';
        var theTimeTxt = txt2('time not null_23_23');
    } else if (nH == -1 && nM == -1 && nS == -1) {
        var theTime = 'NULL';
        var theTimeTxt = txt2('time null_26_23');
    } else {
        //  var theTime=(nH<10?'0'+nH:nH)+'-'+(nM<10?'0'+nM:nM)+'-'+(nS<10?'0'+nS:nS);
        var theTime = yearInit + '-' + (monthInit < 10 ? '0' + monthInit : monthInit) + '-' + (dayInit < 10 ? '0' + dayInit : dayInit) + ' ' + (hourInit < 10 ? '0' + hourInit : hourInit) + ':' + (minutInit < 10 ? '0' + minutInit : minutInit) + ':' + (secondInit < 10 ? '0' + secondInit : secondInit);
        var theTimeTxt = theTime;
    }
    closeDate1(divId);
    var oldValue = document.getElementById(valueId).value;

    document.getElementById(valueId).value = theTime;
    document.getElementById(buttonId).innerHTML = theTimeTxt;

    if (callBackDtTim1) {
        if (!(callBackDtTim1 == 'undefined' || callBackDtTim1 == null || callBackDtTim1 == '')) {
            if (oldValue != theTime) {
                eval('' + callBackDtTim1 + '(\'' + valueId + '\');');
            }
        }
    }

}
//=====================================================================================================================
function fixDateTime1(nY, nM, nD, valueId, buttonId, divId, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, callBackDtTim1) {
    var yearInit = nY;
    var monthInit = nM;
    var dayInit = nD;
    // console.log(yearInit+'-'+monthInit+'-'+dayInit+' '+hourInit+':'+minutInit+':'+secondInit);
    fillDivDateTime1(valueId, buttonId, divId, nY + '-' + nM, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, 0);
}
//=====================================================================================================================
function changeDateTime1(valueId, buttonId, divId, withDateTimeNull, searchDateTimeMode, yearInit, monthInit, dayInit, callBackDtTim1) {
    var hourInit = parseInt(document.getElementById('hour_' + divId).value, 10);
    var minutInit = parseInt(document.getElementById('minute_' + divId).value, 10);
    var secondInit = parseInt(document.getElementById('second_' + divId).value, 10);
    fillDivDateTime1(valueId, buttonId, divId, yearInit + '-' + monthInit, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, 0);
}
//=====================================================================================================================
function onChangeDtTimListForm1(fieldName) {
    // console.log(fieldName);

    var parentFormFounded = false;
    var par = document.getElementById(fieldName).parentNode;
    var parentTag = par.tagName.toLowerCase();
    var goOn = true;
    while (goOn) {
        if (parentTag == 'form') {
            parentFormFounded = true;
            goOn = false;
        } else {
            if (parentTag == 'body') {
                goOn = false;
            }
        }
        if (goOn) {
            par = par.parentNode;
            parentTag = par.tagName.toLowerCase();
        }
    }
    if (parentFormFounded == true) {
        par.submit();
    }
}


//=====================================================================================================================
function setYearModeDateTime1(valueId, buttonId, divId, nM, nY, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1) {
    nM = (nM) < 10 ? '0' + (nM) : nM;
    fillDivDateTime1(valueId, buttonId, divId, nY + '-' + nM, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, 1);
}

//=====================================================================================================================
function setCurrentYear50DateTime1(valueId, buttonId, divId, nM, nY, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, currentYear) {
    nM = '01';
    nY = currentYear;
    fillDivDateTime1(valueId, buttonId, divId, nY + '-' + nM, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, 0);
}

//=====================================================================================================================
function previous50YearDateTime1(valueId, buttonId, divId, nM, nY, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, startYear) {
    nY = startYear;
    fillDivDateTime1(valueId, buttonId, divId, nY + '-' + nM, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, 1);
}
//=====================================================================================================================
function next50YearDateTime1(valueId, buttonId, divId, nM, nY, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, startYear) {
    nY = startYear;
    fillDivDateTime1(valueId, buttonId, divId, nY + '-' + nM, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, 1);
}


//=====================================================================================================================
function fillDivDateTime1(valueId, buttonId, divId, startDate, withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, modeYearDateTime1) {
    var dateIsSet = false;
    if (startDate == '') {
        var value = document.getElementById(valueId).value;
        if (value == 'NULL' || value == 'NOT NULL' || value == '' || value == '1000-01-01') {
            var dt1 = new Date();
        } else {
            var dt1 = new Date(value.substr(0, 4), parseInt(value.substr(5, 2), 10) - 1, value.substr(8, 2)); // 2017-01-01
            dateIsSet = true;
            var dt0 = dt1;
        }
    } else {
        var value = document.getElementById(valueId).value;
        var theDay = 1;
        if (!(value == 'NULL' || value == 'NOT NULL' || value == '' || value == '1000-01-01')) {
            var dt0 = new Date(value.substr(0, 4), parseInt(value.substr(5, 2), 10) - 1, value.substr(8, 2)); // 2017-01-01
            dateIsSet = true;
            theDay = parseInt(value.substr(8), 10);
        }
        var dt1 = new Date(startDate.substr(0, 4), parseInt(startDate.substr(5, 2), 10) - 1, theDay); // 2017-01-01
    }
    var nM = dt1.getMonth() + 1;
    var nY = dt1.getFullYear();
    var nD = dt1.getDate();
    var cM = nM < 10 ? '0' + nM : '' + nM;
    var cD = nD < 10 ? '0' + nD : '' + nD;

    var sty1 = 'font-size:1em;display:block;width:100%;height:100%;padding:0!important;min-width:0px;min-height:0px;color:#' + globalCssSettings1.main.mainTextColor.hexValue + ';';
    var o1 = '';

    if (modeYearDateTime1 == 1) {

        var sty2 = 'text-align:center;width:12.4%;height:35px;border:1px #ccc solid;';

        o1 += '<table style="border:1px #eee solid;width:100%;padding:0;margin:0;border-collapse:collapse;">';

        var startYear = parseInt(nY / 100, 10) * 100;
        if (nY - startYear >= 50) startYear += 50;
        var endYear = startYear + 49;

        o1 += '<tr>';
        o1 += '<td style="' + sty2 + '">';
        o1 += '<a style="' + sty1 + 'font-size:1.0em;" href="javascript:previous50YearDateTime1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\',' + (startYear - 50) + ')">&lt;</a>';

        o1 += '</td>';




        o1 += '<td colspan="3" style="' + sty2 + '">';
        o1 += startYear + '-' + endYear;
        o1 += '</td>';

        o1 += '<td style="' + sty2 + '">';
        o1 += '<a style="' + sty1 + 'font-size:1.0em;" href="javascript:next50YearDateTime1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\',' + (startYear + 50) + ')">&gt;</a>';
        o1 += '</td>';


        o1 += '<td></td>';



        o1 += '<td  style="' + sty2 + '">';
        o1 += '<a style="' + sty1 + 'color:red;font-size:1.5em;" href="javascript:closeDate1(\'' + divId + '\')">&times;</a>';
        o1 += '</td>';



        o1 += '</tr>';


        var currentYear = startYear;
        for (var i = 0; i <= 49; i++) {

            if (i % 7 == 0) {
                o1 += '<tr>';
            }

            o1 += '<td style="' + sty2 + '" data-i="' + i + '-' + (i % 6) + '-' + ((i - 1) % 7) + '-' + '">';
            o1 += '<a style="' + sty1 + 'font-size:1.0em;" href="javascript:setCurrentYear50DateTime1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\',' + (currentYear) + ')">' + currentYear + '</a>';
            o1 += '</td>';

            if (i >= 6 && (i - 6) % 7 == 0) {
                o1 += '</tr>';
            }
            currentYear++;
        }



        o1 += '</tr>';


        o1 += '</table>';
        document.getElementById(divId).innerHTML = o1;

        return;



    }

    o1 += '<table style="border:0;width:100%;padding:0;margin:0;">';
    o1 += '<tr>';
    o1 += '<td></td>';
    o1 += '<td style="text-align:center;width:12.4%;height:35px;">';
    o1 += '<a style="' + sty1 + 'font-size:1.3em;" href="javascript:previousMonthDateTime1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\')">&lt;</a>';
    o1 += '</td>';
    o1 += '<td colspan="3" style="text-align:center;width:37.2%;height:35px;">';
    o1 += '<a href="javascript:setYearModeDateTime1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\')">' + nY + '-' + cM + '</a>';
    o1 += '</td>';
    o1 += '<td style="text-align:center;width:12.4%;height:35px;">';
    o1 += '<a style="' + sty1 + 'font-size:1.3em;" href="javascript:nextMonthDateTime1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\')">&gt;</a>';
    o1 += '</td>';
    o1 += '<td style="text-align:center;width:12.4%;height:35px;">';
    o1 += '&nbsp;';
    o1 += '</td>';
    o1 += '<td style="text-align:center;width:12.4%;height:35px;">';
    o1 += '<a style="' + sty1 + 'color:red;font-size:1.5em;" href="javascript:closeDate1(\'' + divId + '\')" >&times;</a>';
    o1 += '</td>';
    o1 += '</tr>';

    var dtFirstDay = new Date(nY, nM - 1, 1); // 2017-11-01 = mercredi
    var dtFirstDay2 = dtFirstDay;
    var dayOfFirstDay = dtFirstDay.getDay();
    if (dayOfFirstDay == 0) {
        dayOfFirstDay = 7;
    }
    var today = new Date();


    o1 += '<tr>';
    var arrd1 = [
        '' + txt2('calendarWeekShort_1048_11') + '',
        '' + txt2('calendarMondayShort_1048_11') + '',
        '' + txt2('calendarTuesdayShort_1050_11') + '',
        '' + txt2('calendarWednesdayShort_1051_11') + '',
        '' + txt2('calendarThursdayShort_1052_11') + '',
        '' + txt2('calendarFridayShort_1053_11') + '',
        '' + txt2('calendarSaturdayShort_1054_11') + '',
        '' + txt2('calendarSundayShort_1055_11') + '',
    ]
    for (var dd = 0; dd < 8; dd++) {
        o1 += '<td style="text-align:center;">' + arrd1[dd] + '</td>';
    }
    o1 += '</tr>';


    o1 += '<tr>';
    o1 += '<td style="text-align:center;width:12.4%;">' + dtFirstDay.getWeekNumber() + '</td>';
    for (var i = 0; i < dayOfFirstDay - 1; i++) {
        o1 += '<td style="text-align:center;width:12.4%;height:35px;border:0;">&nbsp;</td>';
    }
    if (nM == 2) {
        if ((nY % 4 == 0 && !(nY % 100 == 0)) || nY % 400 == 0) {
            var maxDay = 29;
        } else {
            var maxDay = 28;
        }
    } else if (nM == 4 || nM == 6 || nM == 9 || nM == 11) {
        var maxDay = 30;
    } else {
        var maxDay = 31;
    }
    var fontWeight = '';
    var borderSty1 = '';
    var lineNumber = 1;
    for (var i = 1; i <= maxDay; i++) {
        fontWeight = '';
        borderSty1 = '';

        if (i == today.getDate() && nM == today.getMonth() + 1 && nY == today.getFullYear()) {
            fontWeight = 'font-weight:bold;font-size:1.3em;'
        }
        if (i == dayInit && nM == monthInit && nY == yearInit) {
            borderSty1 = 'border:2px red solid;'
        }

        var bckgrdColor = 'background-color:#fff;';
        if ((dayOfFirstDay + 1) % 7 == 0 || (dayOfFirstDay + 7) % 7 == 0) {
            bckgrdColor = 'background-color:#' + globalCssSettings1.table.headerBackgroundColor.hexValue + ';';
            o1 += '<td style="text-align:center;width:12.4%;height:35px;background-color:#' + globalCssSettings1.table.headerBackgroundColor.hexValue + ';">';
        } else {
            o1 += '<td style="text-align:center;width:12.4%;height:35px;">';
        }
        o1 += '<a style="' + sty1 + fontWeight + borderSty1 + bckgrdColor + '" href="javascript:fixDateTime1(' + nY + ',' + nM + ',' + i + ',\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',\'' + callBackDtTim1 + '\')" >' + i + '</a>';
        o1 += '</td>';
        if (dayOfFirstDay % 7 == 0) {
            o1 += '</tr>';
            o1 += '<tr>';
            dtFirstDay2 = dtFirstDay2.addDays(7);
            if (i + 1 <= maxDay) {
                o1 += '<td style="text-align:center;width:12.4%;">' + dtFirstDay2.getWeekNumber() + '</td>'; // numeroDeSemaine
            }
            lineNumber++;
        }
        dayOfFirstDay++;
    }
    o1 += '</tr>';


    var hInit = '00',
        mInit = '00',
        sInit = '00',
        initialValue = document.getElementById(valueId).value;
    if (initialValue.length == 8 && initialValue != 'NOT NULL') { // 2017-11-07 00:00:00
        hInit = initialValue.substr(11, 2);
        mInit = initialValue.substr(14, 2);
        sInit = initialValue.substr(17, 2);
    }

    // o1+='<table style="border:0;width:100%;padding:0;margin:0;">';

    var val = '',
        selected = '';

    o1 += '<tr>';

    o1 += '<td style="width:12.4%;"></td>';
    o1 += '<td colspan="6" style="text-align:center;">';

    o1 += '<select id="hour_' + divId + '" onchange="changeDateTime1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\')" style="min-height:40px;">';
    for (var i = 0; i <= 23; i++) {
        selected = '';
        val = i < 10 ? '0' + i : i;
        if (hourInit == i) selected = ' selected="selected" ';
        o1 += '<option value="' + val + '" ' + selected + '>' + val + '</option>';
    }
    o1 += '</select>';

    o1 += ' : <select id="minute_' + divId + '" onchange="changeDateTime1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\')"  style="min-height:40px;">';
    for (var i = 0; i <= 59; i++) {
        selected = '';
        val = i < 10 ? '0' + i : i;
        if (minutInit == i) selected = ' selected="selected" ';
        o1 += '<option value="' + val + '" ' + selected + '>' + val + '</option>';
    }
    o1 += '</select>';

    o1 += ' : <select id="second_' + divId + '" onchange="changeDateTime1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\')" style="min-height:40px;">';
    for (var i = 0; i <= 59; i++) {
        selected = '';
        val = i < 10 ? '0' + i : i;
        if (secondInit == i) selected = ' selected="selected" ';
        o1 += '<option value="' + val + '" ' + selected + '>' + val + '</option>';
    }
    o1 += '</select>';

    o1 += '</td>';

    o1 += '<td style="width:12.4%;"></td>';

    o1 += '</tr>';

    if (searchDateTimeMode == 1) {
        var colspan = 2;
    } else {
        var colspan = 4;
    }

    o1 += '<tr>';
    o1 += '<td style="width:12.4%;"></td>';

    o1 += '<td style="text-align:center;height:35px;">'; // null
    if (searchDateTimeMode == 1) {
        o1 += '<a style="' + sty1 + 'font-size:0.9em;line-height:2em;" href="javascript:putDateTime1(-1,-1,-1,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\')">' + txt2('datetime null_231_281') + '</a>';
    } else {
        if (withDateTimeNull == 1) {
            o1 += '<a style="' + sty1 + 'font-size:0.9em;line-height:2em;" href="javascript:putDateTime1(-1,-1,-1,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\')">' + txt2('datetime null_231_281') + '</a>';
        }
    }
    o1 += '</td>';

    o1 += '<td style="width:12.4%;"></td>';

    o1 += '<td style="width:12.4%;text-align:center;height:35px;">'; // not null
    if (searchDateTimeMode == 1) {
        o1 += '<a style="' + sty1 + 'font-size:0.9em;line-height:2em;" href="javascript:putDateTime1(-2,-2,-2,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\')">' + txt2('datetime not null_235_282') + '</a>';
    }
    o1 += '</td>';

    o1 += '<td style="width:12.4%;"></td>';

    o1 += '<td style="width:12.4%;text-align:center;height:35px;">'; // all
    if (searchDateTimeMode == 1) {
        o1 += '<a style="' + sty1 + 'font-size:0.9em;line-height:2em;" href="javascript:putDateTime1(-3,-3,-3,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\')">' + txt2('datetime all_239_282') + '</a>';
    }
    o1 += '</td>';
    o1 += '<td style="width:12.4%;"></td>';
    o1 += '<td style="width:12.4%;"></td>';

    o1 += '</tr>';


    o1 += '<tr>';
    o1 += '<td colspan="7" style="text-align:center;height:35px;">';
    o1 += '<span id=__span_for_' + valueId + '">' + yearInit + '-' + (monthInit < 10 ? '0' + monthInit : monthInit) + '-' + (dayInit < 10 ? '0' + dayInit : dayInit) + ' ' + (hourInit < 10 ? '0' + hourInit : hourInit) + ':' + (minutInit < 10 ? '0' + minutInit : minutInit) + ':' + (secondInit < 10 ? '0' + secondInit : secondInit) + '</span>';
    o1 += '</td>';
    o1 += '<td style="text-align:center;height:35px;">';
    o1 += '<a style="' + sty1 + '" href="javascript:putDateTime1(0,0,0,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateTimeNull + ',' + searchDateTimeMode + ',' + hourInit + ',' + minutInit + ',' + secondInit + ',' + yearInit + ',' + monthInit + ',' + dayInit + ',\'' + callBackDtTim1 + '\')" style="font-size:1.5em;display:block;width:100%;height:100%;">&#10003;</a>';
    o1 += '</td>';
    o1 += '</tr>';


    o1 += '</table>';
    document.getElementById(divId).innerHTML = o1;
}
//=====================================================================================================================
function setDateTime1(valueId, buttonId, withDateTimeNull, searchDateTimeMode, callBackDtTim1) { // 
    // console.log(valueId,buttonId);
    var widthPop = 292;
    var heightPop = 420;
    try {
        var divId = document.getElementById('div_of_' + buttonId);
        if (null == divId) {
            //   console.log('ici');
            var divId = document.createElement('div');
            divId.id = 'div_of_' + buttonId;
            divId.style.width = widthPop + 'px';
            divId.style.height = heightPop + 'px';
            divId.style.position = 'absolute';
            divId.style.backgroundColor = '#' + globalCssSettings1.main.mainBackgroundColor.hexValue + '';
            divId.style.left = '0px';
            divId.style.top = '0px';
            divId.style.border = '2px #' + globalCssSettings1.main.thinBorderColor.hexValue + ' outset';
            divId.style.display = 'none';
            document.getElementsByTagName('body')[0].appendChild(divId);
            //   console.log('ici 2');
        }
    } catch (e) {}
    var pos1 = document.getElementById(buttonId).getBoundingClientRect();
    divId.style.top = (parseInt(pos1.top, 10) + getScrollTop1()) + 'px';
    if (parseInt(pos1.left, 10) + widthPop > dkW) {
        divId.style.left = (dkW - widthPop - 30) + 'px';
    } else {
        divId.style.left = parseInt(pos1.left, 10) + 'px';
    }
    divId.style.display = 'block';
    var hourInit = 0,
        minutInit = 0,
        secondInit = 0;
    var yearInit = 0,
        monthInit = 0,
        dayInit = 0;

    var value = document.getElementById(valueId).value;
    if (value == 'NULL' || value == 'NOT NULL' || value == '') {
        var dt1 = new Date();
        hourInit = dt1.getHours();
        minutInit = dt1.getMinutes();
        secondInit = dt1.getSeconds();
    } else {
        var dt1 = new Date(value.substr(0, 4), parseInt(value.substr(5, 2), 10) - 1, value.substr(8, 2)); // 2017-01-01 01:02:03
        hourInit = parseInt(value.substr(11, 2), 10);
        minutInit = parseInt(value.substr(14, 2), 10);
        hourInit = parseInt(value.substr(17, 2), 10);
    }
    monthInit = dt1.getMonth() + 1;
    yearInit = dt1.getFullYear();
    dayInit = dt1.getDate();
    // console.log(yearInit,monthInit,dayInit,hourInit,minutInit,secondInit);

    fillDivDateTime1(valueId, buttonId, 'div_of_' + buttonId, '', withDateTimeNull, searchDateTimeMode, hourInit, minutInit, secondInit, yearInit, monthInit, dayInit, callBackDtTim1, 0);
}
//=====================================================================================================================
function onChangeTimeListForm1(fieldName) {
    // console.log(fieldName);

    var parentFormFounded = false;
    var par = document.getElementById(fieldName).parentNode;
    var parentTag = par.tagName.toLowerCase();
    var goOn = true;
    while (goOn) {
        if (parentTag == 'form') {
            parentFormFounded = true;
            goOn = false;
        } else {
            if (parentTag == 'body') {
                goOn = false;
            }
        }
        if (goOn) {
            par = par.parentNode;
            parentTag = par.tagName.toLowerCase();
        }
    }
    if (parentFormFounded == true) {
        par.submit();
    }
}
//=====================================================================================================================
function putTime1(nH, nM, nS, valueId, buttonId, divId, withTimeNull, searchTimeMode, callBackTime1, optTime1) {
    if (nH == -3 && nM == -3 && nS == -3) {
        var theTime = '';
        var theTimeTxt = txt2('time all_20_23');
    } else if (nH == -2 && nM == -2 && nS == -2) {
        var theTime = 'NOT NULL';
        var theTimeTxt = txt2('time not null_23_23');
    } else if (nH == -1 && nM == -1 && nS == -1) {
        var theTime = 'NULL';
        var theTimeTxt = txt2('time null_26_23');
    } else {
        //  var theTime=(nH<10?'0'+nH:nH)+'-'+(nM<10?'0'+nM:nM)+'-'+(nS<10?'0'+nS:nS);
        var theTime = document.getElementById('hour_' + divId).value + ':' + document.getElementById('minute_' + divId).value + ':' + document.getElementById('second_' + divId).value;
        var theTimeTxt = theTime;
    }
    closeDate1(divId);
    var oldValue = document.getElementById(valueId).value;
    document.getElementById(valueId).value = theTime;
    if (optTime1 & 1 == 1) {
        document.getElementById(buttonId).innerHTML = theTimeTxt.substr(0, 5);
    } else {
        document.getElementById(buttonId).innerHTML = theTimeTxt;
    }
    if (callBackTime1) {
        if (!(callBackTime1 == 'undefined' || callBackTime1 == null || callBackTime1 == '')) {
            if (oldValue != theTime) {
                eval('' + callBackTime1 + '(\'' + valueId + '\');');
            }
        }
    }
    if (searchTimeMode != 1) {
        if (theTime == '00:00:00') {
            document.getElementById(buttonId).className = 'yysuccess';
        } else if (theTime == 'NULL') {
            document.getElementById(buttonId).className = '';
        } else {
            document.getElementById(buttonId).className = 'yyedit';
        }
    }

}
//=====================================================================================================================
function closeTime1(divId) {
    document.getElementById(divId).style.display = 'none';
}
//=====================================================================================================================
function changeTime1(divId) {
    var newVal = document.getElementById('hour_' + divId).value + ' : ' + document.getElementById('minute_' + divId).value + ' : ' + document.getElementById('second_' + divId).value;
}
//=====================================================================================================================
function fillDivTime1(valueId, buttonId, divId, startTime, withTimeNull, searchTimeMode, callBackTime1, optTime1) {
    // console.log('startDate='+startDate);


    var hInit = '00',
        mInit = '00',
        sInit = '00',
        initialValue = document.getElementById(valueId).value;
    if (initialValue.length == 8 && initialValue != 'NOT NULL') { // 00:00:00
        hInit = initialValue.substr(0, 2);
        mInit = initialValue.substr(3, 2);
        sInit = initialValue.substr(6, 2);
    }

    var sty1 = 'font-size:1em;display:block;width:100%;height:100%;padding:0!important;min-width:0px;min-height:0px;color:#' + globalCssSettings1.main.mainTextColor.hexValue + ';';
    var o1 = '';
    o1 += '<table style="border:0;width:100%;padding:0;margin:0;">';
    o1 += '<tr>';

    o1 += '<td style="width:12.4%;"></td>';
    if (searchTimeMode == 1) {
        o1 += '<td style="text-align:center;height:35px;width:12.4%;">';
        o1 += '<a style="' + sty1 + '" href="javascript:putTime1(-3,-3,-3,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withTimeNull + ',' + searchTimeMode + ',\'' + callBackTime1 + '\',' + optTime1 + ')">' + txt2('time all_20_23') + '</a>';
        o1 += '</td>';
    } else {
        o1 += '<td style="width:12.4%;"></td>';
    }
    if (searchTimeMode == 1) {
        o1 += '<td style="text-align:center;height:35px;width:12.4%;">';
        o1 += '<a style="' + sty1 + '" href="javascript:putTime1(-1,-1,-1,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withTimeNull + ',' + searchTimeMode + ',\'' + callBackTime1 + '\',' + optTime1 + ')">' + txt2('time null_26_23') + '</a>';
        o1 += '</td>';

        o1 += '<td style="text-align:center;height:35px;">';
        o1 += '<a style="' + sty1 + '" href="javascript:putTime1(-2,-2,-2,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withTimeNull + ',' + searchTimeMode + ',\'' + callBackTime1 + '\',' + optTime1 + ')">' + txt2('time not null_23_23') + '</a>';
        o1 += '</td>';

    } else {
        o1 += '<td style="width:12.4%;"></td>';
        o1 += '<td style="width:12.4%;"></td>';
    }
    o1 += '<td style="width:12.4%;"></td>';
    o1 += '<td style="width:12.4%;"></td>';

    if (searchTimeMode != 1) {
        o1 += '<td style="text-align:center;height:35px;width:12.4%;">';
        o1 += '<a style="' + sty1 + '" href="javascript:putTime1(-1,-1,-1,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withTimeNull + ',' + searchTimeMode + ',\'' + callBackTime1 + '\',' + optTime1 + ')" >' + txt2('time null_26_23') + '</a>';
        o1 += '</td>';
    } else {
        o1 += '<td style="width:12.4%;"></td>';
    }

    o1 += '<td style="text-align:center;height:35px;width:12.4%;">';
    o1 += '<a style="' + sty1 + 'color:red;" href="javascript:closeTime1(\'' + divId + '\')">&times;</a>';
    o1 += '</td>';

    o1 += '</tr>';


    var val = '',
        selected = '';

    o1 += '<tr>';

    o1 += '<td colspan="7" style="text-align:center;width:86.8%;">';

    o1 += '<select id="hour_' + divId + '" onchange="changeTime1(\'' + divId + '\')" style="min-height:40px;">';
    for (var i = 0; i <= 23; i++) {
        selected = '';
        val = i < 10 ? '0' + i : i;
        if (hInit == val) selected = ' selected="selected" ';
        o1 += '<option value="' + val + '" ' + selected + '>' + val + '</option>';
    }
    o1 += '</select>';

    o1 += ' : <select id="minute_' + divId + '" onchange="changeTime1(\'' + divId + '\')"  style="min-height:40px;">';
    if (optTime1 & 2 == 2) {
        for (var i = 0; i <= 59; i += 5) {
            selected = '';
            val = i < 10 ? '0' + i : i;
            if (mInit == val) selected = ' selected="selected" ';
            o1 += '<option value="' + val + '" ' + selected + '>' + val + '</option>';
        }
    } else {
        for (var i = 0; i <= 59; i++) {
            selected = '';
            val = i < 10 ? '0' + i : i;
            if (mInit == val) selected = ' selected="selected" ';
            o1 += '<option value="' + val + '" ' + selected + '>' + val + '</option>';
        }
    }
    o1 += '</select>';
    // console.log('optTime1='+optTime1);
    if (optTime1 & 1 == 1) {
        o1 += '<input id="second_' + divId + '" type="hidden" value="00" >';
    } else {
        o1 += ' : <select id="second_' + divId + '" onchange="changeTime1(\'' + divId + '\')" style="min-height:40px;">';
        for (var i = 0; i <= 59; i++) {
            selected = '';
            val = i < 10 ? '0' + i : i;
            if (sInit == val) selected = ' selected="selected" ';
            o1 += '<option value="' + val + '" ' + selected + '>' + val + '</option>';
        }
        o1 += '</select>';

    }

    o1 += '</td>';

    o1 += '<td style="text-align:center;width:12.4%;">';
    o1 += '<a style="' + sty1 + '" href="javascript:putTime1(0,0,0,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withTimeNull + ',' + searchTimeMode + ',\'' + callBackTime1 + '\',' + optTime1 + ')">&#10003;</a>';
    o1 += '</td>';

    o1 += '</tr>';


    if (optTime1 & 4 == 4) {
        o1 += '<tr>';
        o1 += '<td colspan="5" style="border:0px red solid;text-align:left;">';
        var tt = '';
        for (var j = 0; j <= 23; j++) {
            tt = '' + j + ''
            if (j < 10) tt = '0' + j + ''

            o1 += '<a href="javascript:setQuickHourSelect1(\'hour_' + divId + '\',\'' + tt + '\')" class="yysuccess" style="line-height:25px;padding: 0!important;min-height:22px;margin-left: 4px;font-size:0.8em;">' + tt + '</a>';

        }
        o1 += '</td>';

        o1 += '<td colspan="3" style="border:0px red solid;text-align:right;">';
        for (var j = 0; j <= 55; j += 5) {
            tt = '' + j + ''
            if (j < 10) tt = '0' + j + ''
            o1 += '<a href="javascript:setQuickMinuteSelect1(\'minute_' + divId + '\',\'' + tt + '\')" class="yysuccess" style="line-height:25px;padding: 0!important;min-height:22px;margin-left: 4px;font-size:0.8em;">' + tt + '</a>';
        }
        o1 += '</td>';
        o1 += '</tr>';
    }



    o1 += '</table>';
    document.getElementById(divId).innerHTML = o1;
}
//=====================================================================================================================
function setQuickMinuteSelect1(selId, val) {
    var lst = document.getElementById(selId).getElementsByTagName('option');
    for (var i = 0; i < lst.length; i++) {
        if (lst[i].value == val) {
            lst[i].selected = 'selected';
        }
    }
}
//=====================================================================================================================
function setQuickHourSelect1(selId, val) {
    var lst = document.getElementById(selId).getElementsByTagName('option');
    for (var i = 0; i < lst.length; i++) {
        if (lst[i].value == val) {
            lst[i].selected = 'selected';
        }
    }
}
//=====================================================================================================================
function setTime1(valueId, buttonId, withTimeNull, searchTimeMode, callBackTime1, optTime1) { // 
    // console.log(valueId,buttonId);
    // put in the database field comment : {"timeOption":"1"} to set up time option
    // optTime1: 1=hide seconds , 2=only every 5 minutes , 4=quick links on time and minutes , 8=... , 16=...
    //           => 3 = hide seconds and every 5 minuts
    //           => 5 = hide seconds and quick links on time and minutes
    //           => 6 = every 5 minuts and quick links on time and minutes
    //           => 7 = hide seconds and every 5 minuts and quick links on time and minutes

    var widthPop = 300;
    var heightPop = 100;
    if (optTime1 & 4 == 4) {
        heightPop = 260;
    }
    try {
        var divId = document.getElementById('div_of_' + buttonId);
        if (null == divId) {
            //   console.log('ici');
            var divId = document.createElement('div');
            divId.id = 'div_of_' + buttonId;
            divId.style.width = widthPop + 'px';
            divId.style.height = heightPop + 'px';
            divId.style.position = 'absolute';
            divId.style.backgroundColor = '#' + globalCssSettings1.main.mainBackgroundColor.hexValue + '';
            divId.style.left = '0px';
            divId.style.top = '0px';
            divId.style.border = '2px #' + globalCssSettings1.main.thinBorderColor.hexValue + ' outset';
            divId.style.display = 'none';
            document.getElementsByTagName('body')[0].appendChild(divId);
            //   console.log('ici 2');
        }
    } catch (e) {}
    var pos1 = document.getElementById(buttonId).getBoundingClientRect();
    divId.style.top = (parseInt(pos1.top, 10) + getScrollTop1()) + 'px';
    if (parseInt(pos1.left, 10) + widthPop > dkW) {
        divId.style.left = (dkW - widthPop - 30) + 'px';
    } else {
        divId.style.left = parseInt(pos1.left, 10) + 'px';
    }
    divId.style.display = 'block';
    fillDivTime1(valueId, buttonId, 'div_of_' + buttonId, '', withTimeNull, searchTimeMode, callBackTime1, optTime1);
}
//=====================================================================================================================
function getScrollTop1() {
    var a = document.documentElement.scrollTop || window.pageYOffset || document.getElementsByTagName('body')[0].scrollTop || 0;
    a = parseInt(a, 10);
    return a;
}
//=====================================================================================================================
function onChangeDateListForm1(fieldName) {
    // console.log(fieldName);

    var parentFormFounded = false;
    var par = document.getElementById(fieldName).parentNode;
    var parentTag = par.tagName.toLowerCase();
    var goOn = true;
    while (goOn) {
        if (parentTag == 'form') {
            parentFormFounded = true;
            goOn = false;
        } else {
            if (parentTag == 'body') {
                goOn = false;
            }
        }
        if (goOn) {
            par = par.parentNode;
            parentTag = par.tagName.toLowerCase();
        }
    }
    if (parentFormFounded == true) {
        par.submit();
    }

}
//=====================================================================================================================
function closeDate1(divId) {
    document.getElementById(divId).style.display = 'none';
}

//=====================================================================================================================
function previousMonthDate1(valueId, buttonId, divId, nM, nY, withDateNull, searchDateMode, callBackDate1) {
    if (nM == 1) {
        nM = '12';
        nY -= 1;
    } else {
        nM = (nM - 1) < 10 ? '0' + (nM - 1) : nM - 1;
    }
    // console.log(nY+'-'+nM);
    fillDivDate1(valueId, buttonId, divId, nY + '-' + nM, withDateNull, searchDateMode, callBackDate1, 0);
}
//=====================================================================================================================
function nextMonthDate1(valueId, buttonId, divId, nM, nY, withDateNull, searchDateMode, callBackDate1) {
    if (nM == 12) {
        nM = '01';
        nY += 1;
    } else {
        nM = (nM + 1) < 10 ? '0' + (nM + 1) : nM + 1;
    }
    // console.log(nY+'-'+nM);
    fillDivDate1(valueId, buttonId, divId, nY + '-' + nM, withDateNull, searchDateMode, callBackDate1, 0);
}
//=====================================================================================================================
function putDate1(nY, nM, nD, valueId, buttonId, divId, withDateNull, searchDateMode, callBackDate1) {
    if (nY == -2 && nM == -2 && nD == -2) {
        var theDate = 'NOT NULL';
        var theDateTxt = txt2('not void_163_23');
    } else if (nY == -1 && nM == -1 && nD == -1) {
        var theDate = 'NULL';
        var theDateTxt = txt2('void_166_23');
    } else if (nY == 1000 && nM == 1 && nD == 1) {
        var theDate = '1000-01-01';
        if (searchDateMode == 0) {
            var theDateTxt = txt2('void_166_23');
        } else {
            var theDateTxt = txt2('date all_169_23');
        }
    } else {
        var theDate = nY + '-' + (nM < 10 ? '0' + nM : nM) + '-' + (nD < 10 ? '0' + nD : nD);
        var theDateTxt = theDate;
    }
    closeDate1(divId);
    document.getElementById(valueId).value = theDate;
    document.getElementById(buttonId).innerHTML = theDateTxt;
    if (callBackDate1) {
        if (!(callBackDate1 == 'undefined' || callBackDate1 == null || callBackDate1 == '')) {
            eval('' + callBackDate1 + '(\'' + valueId + '\');');
        }
    }
}

//=====================================================================================================================
function previousYearDate1(valueId, buttonId, divId, nM, nY, withDateNull, searchDateMode, callBackDate1) {
    nY -= 1;
    nM = (nM) < 10 ? '0' + (nM) : nM;
    fillDivDate1(valueId, buttonId, divId, nY + '-' + nM, withDateNull, searchDateMode, 0);
}
//=====================================================================================================================
function nextYearDate1(valueId, buttonId, divId, nM, nY, withDateNull, searchDateMode, callBackDate1) {
    nY += 1;
    nM = (nM) < 10 ? '0' + (nM) : nM;
    fillDivDate1(valueId, buttonId, divId, nY + '-' + nM, withDateNull, searchDateMode, callBackDate1, 0);
}
//=====================================================================================================================
Date.prototype.getWeekNumber = function() {
    var d = new Date(Date.UTC(this.getFullYear(), this.getMonth(), this.getDate()));
    var dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    var yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil((((d - yearStart) / 86400000) + 1) / 7)
};
//=====================================================================================================================
Date.prototype.addDays = function(days) {
        var dat = new Date(this.valueOf());
        dat.setDate(dat.getDate() + days);
        return dat;
    }
    //=====================================================================================================================
function setYearModeDate1(valueId, buttonId, divId, nM, nY, withDateNull, searchDateMode, callBackDate1) {
    nM = (nM) < 10 ? '0' + (nM) : nM;
    fillDivDate1(valueId, buttonId, divId, nY + '-' + nM, withDateNull, searchDateMode, callBackDate1, 1);
}

function previous50YearDate1(valueId, buttonId, divId, nM, nY, withDateNull, searchDateMode, callBackDate1, startYear) {
    nM = (nM) < 10 ? '0' + (nM) : nM;
    nY = startYear;
    fillDivDate1(valueId, buttonId, divId, nY + '-' + nM, withDateNull, searchDateMode, callBackDate1, 1);
}

//=====================================================================================================================
function next50YearDate1(valueId, buttonId, divId, nM, nY, withDateNull, searchDateMode, callBackDate1, startYear) {
    nM = (nM) < 10 ? '0' + (nM) : nM;
    nY = startYear;
    fillDivDate1(valueId, buttonId, divId, nY + '-' + nM, withDateNull, searchDateMode, callBackDate1, 1);
}

//=====================================================================================================================
function setCurrentYear50Date1(valueId, buttonId, divId, nM, nY, withDateNull, searchDateMode, callBackDate1, currentYear) {
    nM = '01';
    nY = currentYear;
    fillDivDate1(valueId, buttonId, divId, nY + '-' + nM, withDateNull, searchDateMode, callBackDate1, 0);

}
//=====================================================================================================================
function fillDivDate1(valueId, buttonId, divId, startDate, withDateNull, searchDateMode, callBackDate1, modeYearDate1) {
    // console.log('startDate='+startDate);
    var sty1 = 'font-size:1em;display:block;width:100%;height:100%;padding:0!important;min-width:0px;min-height:0px;color:#' + globalCssSettings1.main.mainTextColor.hexValue + ';';
    var sty2 = 'text-align:center;width:12.4%;height:35px;border:1px #' + globalCssSettings1.main.thinBorderColor.hexValue + ' solid;';
    var o1 = '';

    var dateIsSet = false;
    if (startDate == '') {
        var value = document.getElementById(valueId).value;
        if (value == 'NULL' || value == 'NOT NULL' || value == '' || value == '1000-01-01') {
            var dt1 = new Date();
        } else {
            var dt1 = new Date(value.substr(0, 4), parseInt(value.substr(5, 2), 10) - 1, value.substr(8, 2)); // 2017-01-01
            var dt0 = dt1;
            dateIsSet = true;
        }
    } else {
        var value = document.getElementById(valueId).value;
        var theDay = 1;
        if (!(value == 'NULL' || value == 'NOT NULL' || value == '' || value == '1000-01-01')) {
            var dt0 = new Date(value.substr(0, 4), parseInt(value.substr(5, 2), 10) - 1, value.substr(8, 2));
            dateIsSet = true;
            theDay = parseInt(value.substr(8), 10);
        }
        var dt1 = new Date(startDate.substr(0, 4), parseInt(startDate.substr(5, 2), 10) - 1, theDay);
    }
    var nM = dt1.getMonth() + 1;
    var nY = dt1.getFullYear();
    var nD = dt1.getDate();
    var cM = nM < 10 ? '0' + nM : '' + nM;
    var cD = nD < 10 ? '0' + nD : '' + nD;


    if (modeYearDate1 == 1) {
        o1 += '<table style="width:100%;padding:0;margin:0;border-collapse:collapse;">';

        var startYear = parseInt(nY / 100, 10) * 100;
        if (nY - startYear >= 50) startYear += 50;
        var endYear = startYear + 49;

        o1 += '<tr>';
        o1 += '<td style="' + sty2 + '">';
        o1 += '<a style="' + sty1 + '" href="javascript:previous50YearDate1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\',' + (startYear - 50) + ')">&lt;</a>';
        o1 += '</td>';




        o1 += '<td colspan="3" style="' + sty2 + '">';
        o1 += startYear + '-' + endYear;
        o1 += '</td>';

        o1 += '<td style="' + sty2 + '">';
        o1 += '<a style="' + sty1 + '" href="javascript:next50YearDate1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\',' + (startYear + 50) + ')">&gt;</a>';
        o1 += '</td>';


        o1 += '<td style="' + sty2 + '"></td>';


        o1 += '<td  style="' + sty2 + '">';
        o1 += '<a style="' + sty1 + 'color:red;font-size:1.5em;" href="javascript:closeDate1(\'' + divId + '\')">&times;</a>';
        o1 += '</td>';



        o1 += '</tr>';


        var currentYear = startYear;
        for (var i = 0; i <= 49; i++) {

            if (i % 7 == 0) {
                o1 += '<tr>';
            }

            o1 += '<td style="' + sty2 + '" data-i="' + i + '-' + (i % 6) + '-' + ((i - 1) % 7) + '-' + '">';
            o1 += '<a style="' + sty1 + '" href="javascript:setCurrentYear50Date1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\',' + currentYear + ')">' + currentYear + '</a>';
            o1 += '</td>';

            if (i >= 6 && (i - 6) % 7 == 0) {
                o1 += '</tr>';
            }
            currentYear++;
        }



        o1 += '</tr>';


        o1 += '</table>';
        document.getElementById(divId).innerHTML = o1;

        return;
    }




    // console.log(nY,nM,nD);
    o1 += '<table style="border:1px #' + globalCssSettings1.main.thinBorderColor.hexValue + ' solid;width:100%;padding:0;margin:0;border-collapse:collapse;">';
    o1 += '<tr>';
    o1 += '<td style="' + sty2 + '">';
    o1 += '<a style="' + sty1 + '" href="javascript:previousYearDate1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\')">&lt;</a>';
    o1 += '</td>';


    o1 += '<td colspan="2" style="' + sty2 + '">';
    o1 += '<a href="javascript:setYearModeDate1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\')" style="' + sty1 + '" >' + nY + '</a>';
    o1 += '</td>';



    o1 += '<td style="' + sty2 + '">';
    o1 += '<a style="' + sty1 + '" href="javascript:nextYearDate1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\')">&gt;</a>';
    o1 += '</td>';

    if (searchDateMode == 0) {
        o1 += '<td style="' + sty2 + '"></td>';
    } else {
        o1 += '<td style="' + sty2 + '">'; // all
        o1 += '<a style="' + sty1 + '" href="javascript:putDate1(1000,1,1,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\')">*</a>';
        o1 += '</td>';
    }

    if (withDateNull == 1) {
        o1 += '<td style="' + sty2 + '">';
        o1 += '<a style="' + sty1 + 'font-size:0.8em;" href="javascript:putDate1(-1,-1,-1,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\')">' + txt2('date null_281_216') + '</a>';
        o1 += '</td>';
    } else {
        o1 += '<td style="' + sty2 + '"></td>';
    }
    if (searchDateMode != 0) {
        o1 += '<td style="' + sty2 + '">';
        o1 += '<a style="' + sty1 + 'font-size:0.8em;" href="javascript:putDate1(-2,-2,-2,\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\')">' + txt2('date not null_284_216') + '</a>';
        o1 += '</td>';
    } else {
        o1 += '<td style="' + sty2 + '"></td>';
    }

    o1 += '<td  style="' + sty2 + '">';
    o1 += '<a style="' + sty1 + 'color:red;font-size:1.5em;" href="javascript:closeDate1(\'' + divId + '\')">&times;</a>';
    o1 += '</td>';


    o1 += '</tr>';
    o1 += '<tr>';
    o1 += '<td style="' + sty2 + '"></td>';
    o1 += '<td style="' + sty2 + '">';
    o1 += '<a style="' + sty1 + '" href="javascript:previousMonthDate1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\')">&lt;</a>';
    o1 += '</td>';
    o1 += '<td colspan="3" style="' + sty2 + 'width:37.2%;">';
    o1 += '' + nY + '-' + cM;
    o1 += '</td>';
    o1 += '<td  style="' + sty2 + '">';
    o1 += '<a style="' + sty1 + '" href="javascript:nextMonthDate1(\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + nM + ',' + nY + ',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\')">&gt;</a>';
    o1 += '</td>';
    o1 += '<td colspan="2" style="' + sty2 + '"></td>';

    o1 += '</tr>';


    o1 += '<tr>';
    var arrd1 = [
        '' + txt2('calendarWeekShort_1048_11') + '',
        '' + txt2('calendarMondayShort_1048_11') + '',
        '' + txt2('calendarTuesdayShort_1050_11') + '',
        '' + txt2('calendarWednesdayShort_1051_11') + '',
        '' + txt2('calendarThursdayShort_1052_11') + '',
        '' + txt2('calendarFridayShort_1053_11') + '',
        '' + txt2('calendarSaturdayShort_1054_11') + '',
        '' + txt2('calendarSundayShort_1055_11') + '',
    ]
    for (var dd = 0; dd < 8; dd++) {
        o1 += '<td style="text-align:center;">' + arrd1[dd] + '</td>';
    }
    o1 += '</tr>';



    var dtFirstDay = new Date(nY, nM - 1, 1); // 2017-11-01 = mercredi
    var dayOfFirstDay = dtFirstDay.getDay();
    var dtFirstDay2 = dtFirstDay;
    if (dayOfFirstDay == 0) {
        dayOfFirstDay = 7;
    }
    var today = new Date();
    // console.log('dayOfFirstDay='+dayOfFirstDay);
    o1 += '<tr>';
    o1 += '<td style="text-align:center;">' + dtFirstDay.getWeekNumber() + '</td>'; // numeroDeSemaine
    for (var i = 0; i < dayOfFirstDay - 1; i++) {
        o1 += '<td style="text-align:center;width:12.4%;height:35px;border:0;">&nbsp;</td>';
    }
    if (nM == 2) {
        if ((nY % 4 == 0 && !(nY % 100 == 0)) || nY % 400 == 0) {
            var maxDay = 29;
        } else {
            var maxDay = 28;
        }
    } else if (nM == 4 || nM == 6 || nM == 9 || nM == 11) {
        var maxDay = 30;
    } else {
        var maxDay = 31;
    }
    var fontWeight = '';
    var borderSty1 = '';
    var lineNumber = 1;


    for (var i = 1; i <= maxDay; i++) {
        fontWeight = '';
        borderSty1 = '';
        if (i == today.getDate() && nM == today.getMonth() + 1 && nY == today.getFullYear()) {
            fontWeight = 'font-weight:bold;color:#' + globalCssSettings1.main.mainTextColor.hexValue + ';font-size:1.3em;'
        }
        if (dateIsSet == true && i == nD && nM == dt0.getMonth() + 1 && nY == dt0.getFullYear()) {
            borderSty1 = 'border:2px red solid;'
        }
        var bckgrdColor = 'background-color:#' + globalCssSettings1.main.mainBackgroundColor.hexValue + ';';
        if ((dayOfFirstDay + 1) % 7 == 0 || (dayOfFirstDay + 7) % 7 == 0) {
            o1 += '<td style="' + sty2 + 'background-color:#' + globalCssSettings1.table.headerBackgroundColor.hexValue + ';">';
            bckgrdColor = 'background-color:#' + globalCssSettings1.table.headerBackgroundColor.hexValue + ';';
        } else {
            o1 += '<td style="' + sty2 + '">';
        }
        o1 += '<a style="' + sty1 + fontWeight + borderSty1 + bckgrdColor + '" href="javascript:putDate1(' + nY + ',' + nM + ',' + i + ',\'' + valueId + '\',\'' + buttonId + '\',\'' + divId + '\',' + withDateNull + ',' + searchDateMode + ',\'' + callBackDate1 + '\')">' + i + '</a>';
        o1 += '</td>';
        if (dayOfFirstDay % 7 == 0) {
            o1 += '</tr>';
            o1 += '<tr>';
            dtFirstDay2 = dtFirstDay2.addDays(7);
            if (i + 1 <= maxDay) {
                o1 += '<td style="text-align:center;">' + dtFirstDay2.getWeekNumber() + '</td>'; // numeroDeSemaine
            }
            lineNumber++;
        }
        dayOfFirstDay++;
    }
    o1 += '</table>';
    document.getElementById(divId).innerHTML = o1;
}

//=====================================================================================================================
function setDate1(valueId, buttonId, withDateNull, searchDateMode, callBackDate1) { // 
    // console.log(valueId,buttonId);
    var widthPop = 292;
    var heightPop = 325;
    try {
        var divId = document.getElementById('div_of_' + buttonId);
        if (null == divId) {
            //   console.log('ici');
            var divId = document.createElement('div');
            divId.id = 'div_of_' + buttonId;
            divId.style.width = widthPop + 'px';
            divId.style.height = heightPop + 'px';
            divId.style.position = 'absolute';
            divId.style.backgroundColor = '#' + globalCssSettings1.main.mainBackgroundColor.hexValue + '';
            divId.style.left = '0px';
            divId.style.top = '0px';
            divId.style.border = '3px #' + globalCssSettings1.main.thinBorderColor.hexValue + ' outset';
            divId.style.display = 'none';
            divId.style.background = '#' + globalCssSettings1.main.mainBackgroundColor.hexValue;
            document.getElementsByTagName('body')[0].appendChild(divId);
            //   console.log('ici 2');
        }
    } catch (e) {}
    var pos1 = document.getElementById(buttonId).getBoundingClientRect();
    divId.style.top = (parseInt(pos1.top, 10) + getScrollTop1()) + 'px';
    if (parseInt(pos1.left, 10) + widthPop > dkW) {
        divId.style.left = (dkW - widthPop - 30) + 'px';
    } else {
        divId.style.left = parseInt(pos1.left, 10) + 'px';
    }
    divId.style.display = 'block';
    fillDivDate1(valueId, buttonId, 'div_of_' + buttonId, '', withDateNull, searchDateMode, callBackDate1, 0);
}
//=====================================================================================================================
function myConfirm1(thenGoTo) {
    if (confirm(txt2('sure ?_18_18'))) {
        document.location = thenGoTo;
    }
}
//=====================================================================================================================
function myConfirm0() {
    if (confirm(txt2('sure ?_18_18'))) {
        return true;
    }
    return false;
}
//=====================================================================================================================
function razDependant1(spanId, inputId) {
    try {
        document.getElementById(spanId).innerHTML = '';
    } catch (e) {}
    try {
        document.getElementById(inputId).value = '';
    } catch (e) {}

}
//=====================================================================================================================
function menuDropBoot1(v) {
    if (v.substr(0, 7) == 'jumpTo:') {
        document.location = v.substr(7);
    } else if (v.substr(0, 15) == 'setTranslation:') {
        translate1(v.substr(15));
    } else if (v.substr(0, 8) == 'setLang:') {
        setLanguage(v.substr(8));
    } else {
        document.location = String(document.location);
    }
    setTimeout(slowServer1, globalTimeoutSlowServer);
}
//=====================================================================================================================
function getLocation(href) {
    var match = href.match(/^(https?\:)\/\/(([^:\/?#]*)(?:\:([0-9]+))?)([\/]{0,1}[^?#]*)(\?[^#]*|)(#.*|)$/);
    return match && {
        href: href,
        protocol: match[1],
        host: match[2],
        hostname: match[3],
        port: match[4],
        pathname: match[5],
        search: match[6],
        hash: match[7]
    }
}
//=====================================================================================================================
function setLanguage(k) {
    var loc = getLocation(String(document.location));
    var newSearch = '';
    if (loc.search.substr(0, 1) == '?' && loc.search.substr(1, 1) != '') {
        var tabsearch = loc.search.substr(1).split('&');
        for (var i = 0; i < tabsearch.length; i++) {
            var x = tabsearch[i].split('=');
            if (x[0] == 'lang') {} else {
                if (newSearch != '') {
                    newSearch += '&';
                }
                newSearch += x[0];
                if (x.length > 1) {
                    newSearch += '=' + x[1];
                }
            }
        }
        if (newSearch == '') {
            newSearch += 'lang=' + k;
        } else {
            newSearch += '&lang=' + k;
        }
    } else {
        newSearch = 'lang=' + k;
    }
    var newLoc = loc.protocol + '//' + loc.host + '' + loc.pathname + '?' + newSearch;
    // console.log('newLoc=',newLoc);
    // return;
    document.location = newLoc;
}
//=====================================================================================================================
function translate1(page) {
    var translate = getCookie('translate')
    if (translate == '' || translate == '0') {
        setCookie('translate', '1');
        document.location = String(document.location);
        return;
    } else {
        if (translate == '1') {
            setCookie('translate', '0');
            document.location = String(document.location);
            return;
        }
    }
}
//=====================================================================================================================
function txt1(k) {
    return k;
}
//=====================================================================================================================
function txt2(k) {
    for (var elem in globTablang) {
        if (globTablang[elem].key === k.replace(/\n/g, '\\n')) {
            return globTablang[elem].value.replace(/\\n/g, '\n');
        }
    }
    return k;
}
//=====================================================================================================================
function modifierLeMotDePasse(divId, btnId, fieldName) {
    var t = '';
    if (document.getElementById(divId).innerHTML == '') {
        document.getElementById(btnId).innerHTML = txt2('do not modify password_214_49');
        document.getElementById(divId).innerHTML = txt2('password_215_49') + ' : <input type="password" value="" id="' + fieldName + '" name="' + fieldName + '" /><br />' + txt2('Confirmation_215_152') + ' : <input type="password" value="" id="' + fieldName + '_confirm" name="' + fieldName + '_confirm" />';
    } else {
        document.getElementById(divId).innerHTML = '';
        document.getElementById(btnId).innerHTML = txt2('Update the password_218_49');
    }
}
//=====================================================================================================================
function modifierLeMotDePasse2(divId, btnId, fieldName) {
    var t = '';
    if (document.getElementById(divId).innerHTML == '') {
        document.getElementById(btnId).innerHTML = txt2('do not modify my password_225_49');
        var t1 = txt2('my actual password_226_15') + ' : <input type="password" value="" id="__actualpassword" name="__actualpassword" />';
        t1 += '<br />' + txt2('my new password_227_21') + ' : <input type="password" value="" id="' + fieldName + '" name="' + fieldName + '" />';
        t1 += '<br />' + txt2('my new password confirm_228_21') + ' : <input type="password" value="" id="' + fieldName + '_confirm" name="' + fieldName + '_confirm" />'
        document.getElementById(divId).innerHTML = t1;
    } else {
        document.getElementById(divId).innerHTML = '';
        document.getElementById(btnId).innerHTML = txt2('Update my password_232_49');
    }
}

function mouseOverTranslate(s) {
    document.getElementById(s).background = 'white';
}

function mouseOutTranslate(s) {
    document.getElementById(s).background = 'red';
}
//====================================================================================================================
function getCookie(cn) {
    var cookie = document.cookie;
    var cooKieValue = '';
    //    console.log(cookie,cn);
    var posStart = cookie.indexOf(cn + '=');
    if (posStart >= 0) {
        var pos2 = cookie.indexOf(';', posStart + 1);
        if (pos2 === -1) {
            pos2 = cookie.length;
        }
        var cookieString = cookie.substr(posStart, pos2 - posStart);
        cooKieValue = cookieString.substr(cn.length + 1);
    }
    return cooKieValue;
}
//====================================================================================================================
function setCookie(cn, cv) {
    var today = new Date();
    var expires_date = new Date(today.getTime() + (1000 * 60 * 60 * 24 * 365));
    document.cookie = encodeURI(cn) + '=' + encodeURI(cv) + ';expires=' + expires_date.toGMTString();
}
//=====================================================================================================================
function ent1(s) {
    var x = s.replace(/</g, '&lt;');
    x = x.replace(/>/g, '&gt;');
    x = x.replace(/"/g, '&quot;');
    return x;
}
//=====================================================================================================================
function revent1(s) {
    var x = s.replace(/&lt;/g, '<');
    x = x.replace(/&gt;/g, '>');
    x = x.replace(/&quote;/g, '"');
    return x;
}
//=====================================================================================================================
function ajaxCall(obj) {
    var ajax = null;
    if (window.XMLHttpRequest) {
        ajax = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        ajax = new ActiveXObject("Microsoft.XMLHTTP");
    }
    if (ajax === null) {
        alert('No ajax call on this browser');
        return;
    }
    //  console.log(obj.url);
    ajax.open("POST", 'za_ajax.php?' + obj.url, true);
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    if (obj.timeout) {
        ajax.timeout = obj.timeout;
    } else {
        ajax.timeout = 6000; // 6 secondes 
    }
    ajax.onreadystatechange = function anonymous() {
        if (ajax.readyState === 4) {
            var returnObject = null;
            if (ajax.status === 200) {
                try {
                    returnObject = JSON.parse(ajax.responseText);
                } catch (e) {
                    console.error('Erreur probable dans le décodage après un appel ajax (vérifiez utf-8) %o', ajax, obj, e);
                    return;
                }
                try {
                    obj.retu(returnObject, obj);
                } catch (e) {
                    console.error('erreur de call %o', ajax, e);
                    return;
                }
            } else {
                console.error('Erreur ajax 3 ', ajax);
                try {
                    returnObject = { status: 'KO', message: 'offline' };
                    obj.retu(returnObject, obj);
                } catch (ec) {
                    console.error(ec, obj);
                }
                return;
            }
        }
    };
    try {
        ajax.send('data=' + encodeURIComponent(JSON.stringify(obj.data)));
    } catch (er) {
        console.error(er, obj);
        try {
            var returnObject = { status: 'KO', message: 'offline' };
            obj.retu(returnObject, obj);
        } catch (ec) {
            console.error(ec, obj);
        }
    }
}
//=====================================================================================================================
function displaySlowServer() {
    var opa = parseInt(document.getElementById('sloserver1').style.opacity * 100, 10);
    if (opa < 100) {
        var newOpa = opa / 100 + 0.1;
        if (newOpa > 1) newOpa = 1;
        document.getElementById('sloserver1').style.opacity = newOpa;
        setTimeout(displaySlowServer, 30);
    }
}
//=====================================================================================================================
var getAbsoluteUrl = (function() {
    var a;
    return function(url) {
        if (!a) a = document.createElement('a');
        a.href = url;
        return a.href;
    };
})();
//=====================================================================================================================
function slowServer1() {
    var divId = document.createElement('div');
    divId.id = 'sloserver1';
    divId.style.top = '55px';
    divId.style.left = '0px';
    divId.style.position = 'fixed';
    divId.style.padding = '8px';
    divId.style.zIndex = 10000;
    divId.style.textAlign = 'center';
    divId.style.fontSize = '2em';
    divId.style.width = '99.99%';
    divId.style.borderRadius = '3px';
    divId.className = 'yyerror';
    divId.style.opacity = 0.0;
    divId.innerHTML = txt2('Sorry, the server is very slow_1671_23');
    document.getElementsByTagName('body')[0].appendChild(divId);
    setTimeout(displaySlowServer, 0);
}
//=====================================================================================================================
function clickLink1(e) {
    try {
        e.target.className = "yyunset";
    } catch (e1) {}
    setTimeout(slowServer1, globalTimeoutSlowServer);
}
//=====================================================================================================================
function clickButton1(e) {
    try {
        e.target.style.visibility = "hidden";
    } catch (e1) {}
    setTimeout(slowServer1, globalTimeoutSlowServer);
}
//=====================================================================================================================
function executeFunctionByName(functionName, context /*, args */ ) {
    var args = Array.prototype.slice.call(arguments, 2);
    var namespaces = functionName.split(".");
    var func = namespaces.pop();
    for (var i = 0; i < namespaces.length; i++) {
        context = context[namespaces[i]];
    }
    return context[func].apply(context, args);
}

//=====================================================================================================================
function highLightSelectMenuDrop1(menuDrop, parentMenuId) {
    try {
        var lst1 = document.getElementById('menuDrop' + menuDrop).getElementsByTagName('option');
        for (var i = 0; i < lst1.length; i++) {
            if (lst1[i].value && lst1[i].value.indexOf('setTranslation') < 0 && lst1[i].id && lst1[i].id === 'menu_' + parentMenuId) {
                document.getElementById('menuDrop' + menuDrop).style.background = '#' + globalCssSettings1['menu']['activeBackgroundColor']['hexValue'];
                lst1[i].selected = "selected"; //document.getElementById(menuDrop).selectedIndex=i; 
                return menuDrop;
            }
        }
    } catch (e) {}
    return 0;
}
//=====================================================================================================================
function display_ajax_error_in_cons(jsonRet) {
    var txt = '';
    if (jsonRet.hasOwnProperty('status')) { txt += 'status:' + jsonRet.status + ' '; }
    if (jsonRet.hasOwnProperty('message')) {
        if (Array.isArray(jsonRet.message)) {
            for (var elem in jsonRet.message) {
                txt += '' + jsonRet.message[elem] + '\n';
            }
        } else {
            txt += '' + jsonRet.message + '\n';
        }
    }
    console.log(txt);
    console.log('jsonRet=', jsonRet)
}
//=====================================================================================================================
function fixMenu1() {
    var parentMenuId = 0;
    var setUpSelectDone = -1;
    var menuToHighlight = 0;
    if (globalParentMenu1[zz_page_id]) { // has a parent page ?
        menuToHighlight = globalParentMenu1[zz_page_id];
    } else {
        menuToHighlight = zz_page_id;
    }
    //  alert('current page='+zz_page_id + ' , parentMenu=' + globalParentMenu1[zz_page_id]);
    var elt = (document.getElementById('menu_' + menuToHighlight) ? document.getElementById('menu_' + menuToHighlight) : null);
    if (elt && elt.tagName.toLowerCase() == 'option') {
        setUpSelectDone = parseInt(elt.getAttribute('data-menusel'), 10);
    }
    if (setUpSelectDone !== -1) {
        highLightSelectMenuDrop1(setUpSelectDone, menuToHighlight);
    } else {
        setUpSelectDone = 3;
        var parentLink = (document.getElementById('menu_' + menuToHighlight) ? document.getElementById('menu_' + menuToHighlight) : null);
        if (parentLink && parentLink.href && parentLink.href.indexOf('setTranslation') < 0) {
            parentLink.style.background = '#' + globalCssSettings1['menu']['activeBackgroundColor']['hexValue'];
        }
    }
    if (setUpSelectDone == 1 || setUpSelectDone == 2) {
        if (setUpSelectDone == 1) {
            var pos1 = document.getElementById('menuDrop1').getBoundingClientRect();
            document.getElementById('menuScroller').scrollTo(pos1.left, 0);
            // reset menu 2 to selected="" in case of back button
            var elt2 = document.getElementById('menuDrop2');
            if (elt2) {
                var lst1 = elt2.getElementsByTagName('option');
                for (var i = 0; i < lst1.length; i++) {
                    lst1[i].selected = "";
                }
            }
        }
        if (setUpSelectDone == 2) {
            var pos1 = document.getElementById('menuDrop2').getBoundingClientRect();
            document.getElementById('menuScroller').scrollTo(pos1.left, 0);
            // reset menu 1 to selected="" in case of back button
            var lst1 = document.getElementById('menuDrop1').getElementsByTagName('option');
            for (var i = 0; i < lst1.length; i++) {
                lst1[i].selected = "";
            }
        }
    }
    if (setUpSelectDone == 0) {
        try {
            var elt1 = document.getElementById('menuDrop1');
            if (elt1) {
                var lst1 = elt1.getElementsByTagName('option');
                for (var i = 0; i < lst1.length; i++) {
                    lst1[i].selected = "";
                }
            }
        } catch (e) {}
        try {
            var elt2 = document.getElementById('menuDrop2');
            if (elt2) {
                var lst2 = elt2.getElementsByTagName('option');
                for (var i = 0; i < lst2.length; i++) {
                    lst2[i].selected = "";
                }
            }
        } catch (e) {}
    }
    var lst2 = document.getElementById('menuScroller').getElementsByTagName('a');
    var viewportWidth = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);

    for (var i = 0; i < lst2.length; i++) {
        if (lst2[i].id && lst2[i].id === 'menu_' + zz_page_id) {
            var pos = lst2[i].getBoundingClientRect();
            if (pos.left + pos.width > viewportWidth) {
                var qtScroll = parseInt((pos.left + pos.width) - viewportWidth, 10)
                try { // because of edge
                    document.getElementById('menuScroller').scrollTo(qtScroll + 15, 0);
                } catch (e) {}
                break;
            }
        }
    }
}
//=====================================================================================================================
function afterSetSortPagesOfGroup2(dataJson, objSend) {
    if (dataJson.status && dataJson.status == 'OK') {
        document.location = String(document.location);
    } else {
        display_ajax_error_in_cons(jsonRet);
        console.log(r);
        alert('BAD job !');
        return;
    }
}
//=====================================================================================================================
function afterSortTodo2(context, tree) {
    // console.log(context);
    switch (context.action) {

        case 'afterReorganize':
            //   console.log(tree);
            var txt = '';
            for (var elem in tree) {
                txt += ',' + tree[elem].id;
            }
            document.getElementById('sortedTodos2').value = txt.substr(1, txt.length);
            break;



        case 'afterFold': //   console.log(tree);
            break;



        case 'init': //   console.log(tree);

            var txt = '';

            for (var elem in tree) {
                //    console.log('parentId='+tree[elem].parentId)
                txt += ',' + tree[elem].id;
            }

            document.getElementById('sortedTodos2').value = txt.substr(1, txt.length);
            break;



        default: //   console.log('context=',context,'tree=',tree);
            break;

    }
}
var oMyTree2 = null;
//=====================================================================================================================
function sortTodos2(par) {
    // console.log('par=',par);
    oMyTree2 = new cMyTree1('oMyTree2', 'myTreeId2', jsonTree2, options2, afterSortTodo2);
}
//=====================================================================================================================
function sortMyTodos(par) {
    var listeDesElementsTries = [];
    var list = document.getElementById(par.elementToSort).getElementsByTagName('li');
    for (var i = 0; i < list.length; i++) {
        listeDesElementsTries.push(list[i].id);
    }
    // console.log('in sortMyTodos',listeDesElementsTries);
    if (document.getElementById(par.inputWithSortedElements)) {
        document.getElementById(par.inputWithSortedElements).value = listeDesElementsTries.join(',');
    }
    if (document.getElementById(par.buttonSort) && par.styleOfButton) {
        document.getElementById(par.buttonSort).style.display = par.styleOfButton;
    }
}
//=====================================================================================================================
function getScrollWidth() { //setup globalScrollWidth1
    var body = document.getElementsByTagName('body')[0];
    var div = document.createElement("div");
    div.style.width = '100px';
    div.style.height = '100px';
    div.style.overflow = 'auto';
    div.style.opacity = 0.01;
    body.appendChild(div);
    var bag = document.createElement("div");
    var att1 = 'width:101px;height:101px;overflow:auto;';
    bag.style.width = '101px';
    bag.style.height = '101px';
    bag.style.overflow = 'auto';
    div.appendChild(bag);
    div.scrollTop = 100;
    globalScrollWidth1 = div.scrollTop - 1;
    div.removeChild(bag);
    body.removeChild(div);
}
//=====================================================================================================================
function doLocalPage(par) {
    for (var i = 0; i < par.length; i++) {
        switch (par[i].jsName) {
            case 'onSortPagesOfGroups2':
                onSortPagesOfGroups2(par[i]);
                break;
            case 'sortParamWithLang1':
                sortParamWithLang1(par[i]);
                break;
            case 'sortParamWithoutLang1':
                sortParamWithoutLang1(par[i]);
                break;
            case 'scrollBack2':
                scrollBack2(par[i]);
                break;
            case 'sortTodos2':
                sortTodos2(par[i]);
                break;
            default:
                if (par[i].localhost && par[i].localhost == true) {} else {
                    console.error(par[i].jsName + ' not treated in doLocalPage')
                }
                break;
        }
    }
    if (typeof localhostDoLocalPage === "function") {
        localhostDoLocalPage(par);
    }
}
//=====================================================================================================================
window.onload = function() {
        fixMenu1();
        var lstb1 = document.getElementsByTagName('body')[0].getElementsByTagName('button');
        for (var i = 0; i < lstb1.length; i++) {
            if (!(lstb1[i].onclick)) {
                if (lstb1[i].className && lstb1[i].className.indexOf('noHide') >= 0) {} else {
                    lstb1[i].addEventListener("click", clickButton1, false);
                }
            }
        }
        var lsta1 = document.getElementsByTagName('body')[0].getElementsByTagName('a');
        for (var i = 0; i < lsta1.length; i++) {
            if (lsta1[i].href && !(lsta1[i].href.indexOf('javascript') >= 0)) {
                if (lsta1[i].className && lsta1[i].className.indexOf('noHide') >= 0) {} else {
                    lsta1[i].addEventListener("click", clickLink1, false);
                }
            }
        }
        if (globalCssSettings1.other.autocompleteInput == 0) {
            // ajouter des autocomplete
            var lstb1 = document.getElementsByTagName('body')[0].getElementsByTagName('input');
            for (var i = 0; i < lstb1.length; i++) {
                if (lstb1[i].type && lstb1[i].type.toLowerCase() == 'text') {
                    lstb1[i].setAttribute('autocomplete', 'off');
                }
            }
            var lstb1 = document.getElementsByTagName('body')[0].getElementsByTagName('textarea');
            for (var i = 0; i < lstb1.length; i++) {
                if (lstb1[i].type && lstb1[i].type.toLowerCase() == 'text') {
                    lstb1[i].setAttribute('autocomplete', 'off');
                }
            }
        }
        getScrollWidth();
        getPageSize();
        pageFunction(); // this function calls finally a void function or doLocalPage ( see za_inc.php/function htmlFoot0 to see the implementation )
    }
    //=====================================================================================================================