<?php
function getTdo_uploadeddocs1($id){
 $nam=array();
 $n['fld_id_uploadedDocs']            =0;
 $n['fld_name_uploadedDocs']          ='';
 $n['fld_originalName_uploadedDocs']  ='';
 $n['fld_isPicture_uploadedDocs']     ='';
 $n['fld_pictureWidth_uploadedDocs']  =0;
 $n['fld_pictureHeight_uploadedDocs'] =0;
 $n['fld_documentType_uploadedDocs']  ='';
 $n['fld_pictureWeight_uploadedDocs'] =0;
 $n['fld_path_uploadedDocs']          ='';
 $n['fld_tsupd_uploadedDocs']         ='1000-01-01 00:00:00';
 $n['fld_tscrt_uploadedDocs']         ='1000-01-01 00:00:00';
 $n['fld_cntupd_uploadedDocs']        =0;
 $sql='
  SELECT 
   T0.`fld_id_uploadedDocs`            ,T0.`fld_name_uploadedDocs`          ,T0.`fld_originalName_uploadedDocs`  ,T0.`fld_isPicture_uploadedDocs`     ,T0.`fld_pictureWidth_uploadedDocs`  ,
   T0.`fld_pictureHeight_uploadedDocs` ,T0.`fld_documentType_uploadedDocs`  ,T0.`fld_pictureWeight_uploadedDocs` ,T0.`fld_path_uploadedDocs`          ,T0.`fld_tsupd_uploadedDocs`         ,
   T0.`fld_tscrt_uploadedDocs`         ,T0.`fld_cntupd_uploadedDocs`        
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl_uploadeddocs` T0
  WHERE T0.`fld_id_uploadedDocs` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['fld_id_uploadedDocs']            = $row[0];
   $n['fld_name_uploadedDocs']          = $row[1];
   $n['fld_originalName_uploadedDocs']  = $row[2];
   $n['fld_isPicture_uploadedDocs']     = $row[3];
   $n['fld_pictureWidth_uploadedDocs']  = $row[4];
   $n['fld_pictureHeight_uploadedDocs'] = $row[5];
   $n['fld_documentType_uploadedDocs']  = $row[6];
   $n['fld_pictureWeight_uploadedDocs'] = $row[7];
   $n['fld_path_uploadedDocs']          = $row[8];
   $n['fld_tsupd_uploadedDocs']         = $row[9];
   $n['fld_tscrt_uploadedDocs']         = $row[10];
   $n['fld_cntupd_uploadedDocs']        = $row[11];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
