<?php // € utf8 check with euro sign
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
checkGroupPages();
openDb1();
//========================================================================================================================
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 if(isset($_POST['buttonSort1']) && isset($_POST['sortedTodos2']) && $_POST['sortedTodos2']!=''){
  $sortedIds=explode(',',$_POST['sortedTodos2']);
  $order=0;
  $newTab=array();
  foreach($sortedIds as $k1=>$v1){
   if(is_numeric($v1)){
    $newTab[]=array(
     'id'    => $v1,
     'order' => $order,
    );
    $order++;
   }
  }
  if(count($newTab)>0){
   foreach($newTab as $k1 => $v1){
    $req6='
     UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` SET
       `fld_priority_todos` = '.$v1['order'].'
     WHERE `fld_id_todos`      = '.$v1['id'].' 
       AND `fld_id_user_todos` = '.$_SESSION[PGMK]['login'].' 
    ';
    $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   }
  }
 }
 if(isset($_POST['addOneToPriorities'])){
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` SET
    `fld_priority_todos` = `fld_priority_todos` + 1
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_priority_todos` < 50
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
 }
 if(isset($_POST['subOneToPriorities'])){
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` SET
    `fld_priority_todos` = `fld_priority_todos` - 1
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_priority_todos` >= 1
     AND `fld_priority_todos` <  50
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
 }
 header("HTTP/1.1 303 See Other");header('Location: '.BNF);
 exit();
 
}
if(isset($_GET) && sizeof($_GET)>0){
 if(isset($_GET['a']) && $_GET['a']=='plusOne'){
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` SET
    `fld_priority_todos` = `fld_priority_todos` + 1
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_id_todos`        = '.$_GET['id'].'
     AND `fld_priority_todos` < 99
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
  header("HTTP/1.1 303 See Other");header('Location: '.BNF);
  exit();
 }
 if(isset($_GET['a']) && $_GET['a']=='minusOne'){
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` SET
    `fld_priority_todos` = `fld_priority_todos` - 1
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_id_todos`        = '.$_GET['id'].'
     AND `fld_priority_todos` > 0
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
  header("HTTP/1.1 303 See Other");header('Location: '.BNF);
  exit();  
 }
 if(isset($_GET['a']) && $_GET['a']=='setTo99'){
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` SET
    `fld_priority_todos` = 99
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_id_todos`        = '.$_GET['id'].'
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
  header("HTTP/1.1 303 See Other");header('Location: '.BNF);
  exit();
 }
 
 if(isset($_GET['a']) && $_GET['a']=='setTo00'){
  $req6='
   UPDATE  `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` SET
    `fld_priority_todos` = 0
   WHERE `fld_id_user_todos` = ' . $_SESSION[PGMK]['login'] . ' 
     AND `fld_id_todos`        = '.$_GET['id'].'
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . ' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
  }
  header("HTTP/1.1 303 See Other");header('Location: '.BNF);
  exit();
 } 
}
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_priority_todos
$isSuperUser=false; 
if($_SESSION[PGMK]['login']==1){
 $isSuperUser=true;
}
if($isSuperUser){
 $xsrch_1=saveSessionSearch1('xsrch_1',BNF);// user one can see every item fld_id_user_todos
 $xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_login_users of parent table
}else{
 $xsrch_1=$_SESSION[PGMK]['login'];// fld_id_user_todos 
}
$xsrch_5=saveSessionSearch1('xsrch_5',BNF);// fld_title_todos
$xsrch_6=saveSessionSearch1('xsrch_6',BNF);// fld_comment_todos
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_todos
$xsrch_hide90=saveSessionSearch1('xsrch_hide90',BNF);// fld_id_todos
if(isset($_GET['m'])&&$_GET['m']=='1'){
 $xsrch_hide90=1;
}

$xsrch_sort=saveSessionSearch1('xsrch_sort',BNF);// fld_id_todos
if($isSuperUser){
 if($xsrch_1!=''){
  $xsrch_ids=str_replace('.',',',$xsrch_1);
  $xsrch_ids=explode(',',$xsrch_ids);
  $listIdsOk=true;
  foreach($xsrch_ids as $v1){
   if(!is_numeric($v1)){
    $listIdsOk=false;
    break;
   }
  }
  if(!$listIdsOk){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_137_93') . ' : ' . txt2('fld_id_user_todos_137_153');
  }
 }
}
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if(!$listIdsOk){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_137_93') . ' : ' . txt2('fld_id_todos_152_152');
 }
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; } // fld_priority_todos
else if($xsrch_5!=''){ $autofocus='xsrch_5'; } // fld_title_todos
else if($xsrch_6!=''){ $autofocus='xsrch_6'; } // fld_comment_todos
else if($isSuperUser&&$xsrch_1!=''){ $autofocus='xsrch_1'; } // fld_id_user_todos link to parent table
else if($isSuperUser&&$xsrch_2!=''){ $autofocus='xsrch_2'; } // fld_login_users of parent table
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('list of todos_163_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="filterForm">'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_priority_todos_169_39').'</label>'.CRLF; // fld_priority_todos
$o1.='    <input '.($xsrch_0!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_0" id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_5">'.txt2('fld_title_todos_175_39').'</label>'.CRLF; // fld_title_todos
$o1.='    <input '.($xsrch_5!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_5" id="xsrch_5"   value="'.enti1($xsrch_5).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_5'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_6">'.txt2('fld_comment_todos_181_39').'</label>'.CRLF; // fld_comment_todos
$o1.='    <input '.($xsrch_6!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_6" id="xsrch_6"   value="'.enti1($xsrch_6).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_6'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_todos_152_152').'</label>'.CRLF; // fld_id_todos
$o1.='    <input '.($xsrch_id!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_hide90">'.txt2('hide_90s_199_44').'</label>'.CRLF;
$o1.='    <select '.($xsrch_hide90!=''?'class="backgroundYellow"':'').' name="xsrch_hide90"  id="xsrch_hide90" '.($autofocus=='xsrch_hide90'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='<option value="" '.($xsrch_hide90==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_hide90){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;


if($isSuperUser){

 $o1.='   <div>'.CRLF;
 $o1.='    <label for="xsrch_1">'.txt2('fld_id_user_todos_137_153').'</label>'.CRLF; // fld_id_user_todos
 $o1.='    <input '.($xsrch_1!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_1" id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
 $o1.='   </div>'.CRLF;

 // field fld_login_users of parent table

 $o1.='   <div>'.CRLF;
 $o1.='    <label for="xsrch_2">'.txt2('T1.fld_login_and_names_users_201_40').'</label>'.CRLF; // fld_login_users
 $o1.='    <input '.($xsrch_2!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_2" id="xsrch_2"   value="'.enti1($xsrch_2).'"  size="8" maxlength="64"  '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' />'.CRLF;
 $o1.='   </div>'.CRLF;

}


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_sort">'.txtsys1('sort_order').'</label>'.CRLF; // sort
$o1.='    <select '.($xsrch_sort!=''?'class="backgroundYellow"':'').' name="xsrch_sort"  id="xsrch_sort" '.($autofocus=='xsrch_sort'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='     <option value="" '.($xsrch_sort==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_id_todos'.'"               '.($xsrch_sort=='T0.fld_id_todos'             ?' selected="selected" ':'').'>'.txt2('fld_id_todos_152_152').'</option>'.CRLF;
if($isSuperUser){
 $o1.='     <option value="'.'T0.fld_id_user_todos'.'"         '.($xsrch_sort=='T0.fld_id_user_todos'         ?' selected="selected" ':'').'>'.txt2('fld_id_user_todos_137_153').'</option>'.CRLF;
 $o1.='     <option value="'.'T1.fld_login_users'.'"           '.($xsrch_sort=='T1.fld_login_users'           ?' selected="selected" ':'').'>'.txt2('T1.fld_login_users_216_149').'</option>'.CRLF;
}
$o1.='     <option value="'.'T0.fld_title_todos'.'"           '.($xsrch_sort=='T0.fld_title_todos'           ?' selected="selected" ':'').'>'.txt2('fld_title_todos_175_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_comment_todos'.'"         '.($xsrch_sort=='T0.fld_comment_todos'         ?' selected="selected" ':'').'>'.txt2('fld_comment_todos_181_39').'</option>'.CRLF;
$o1.='    </select>';
$o1.='   </div>'.CRLF;
$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;// #128270
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_todos`              ,T0.`fld_priority_todos`        ,T0.`fld_id_user_todos`         ,concat( T1.`fld_login_users` ,\' \' ,T1.`fld_firstname_users` ,\' \' , T1.`fld_lastname_users` ) , 1 , 
   1                              ,T0.`fld_title_todos`           ,T0.`fld_comment_todos`         
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` T0
        , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` T1 ) 
 WHERE 1=1 
   AND T0.`fld_id_user_todos`=T1.`fld_id_users`
';
if($xsrch_hide90!=='' && $xsrch_hide90==1){
 $req6.='
  AND ( T0.`fld_priority_todos` = 99 OR T0.`fld_priority_todos` < 90 )
 '; 
 
}
if($xsrch_0!='' && is_numeric($xsrch_0)){
 $req6.='
  AND T0.`fld_priority_todos` = '.$xsrch_0.'
 '; 
}
if($isSuperUser){
 if($xsrch_1!=''){
  $xsrch_ids=str_replace('.',',',$xsrch_1);
  $xsrch_ids=explode(',',$xsrch_ids);
  $listIdsOk=true;
  foreach($xsrch_ids as $v1){
   if(!is_numeric($v1)){
    $listIdsOk=false;
    break;
   }
  }
  if($listIdsOk){  $req6.=' AND T0.`fld_id_user_todos` IN ('.implode(',',$xsrch_ids).')  '; }
 }
 // field fld_login_users of parent table
 if($xsrch_2!='' ){ $req6.=' AND CONCAT( T1.`fld_login_users` , \' \' , T1.`fld_firstname_users` , \' \' , T1.`fld_lastname_users` ) LIKE \'%'.addslashes1($xsrch_2).'%\'  '; }
}else{
 $req6.=' AND T0.`fld_id_user_todos` = '.$_SESSION[PGMK]['login'].'  ';
}

if($xsrch_5!='' ){ $req6.='  AND T0.`fld_title_todos` LIKE \'%'.addslashes1($xsrch_5).'%\' '; }
if($xsrch_6!='' ){ $req6.='  AND T0.`fld_comment_todos` LIKE \'%'.addslashes1($xsrch_6).'%\' '; }
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if($listIdsOk){
  $req6.='
   AND T0.`fld_id_todos` IN ('.implode(',',$xsrch_ids).') 
  '; 
 }
}
if($xsrch_sort==''){
 $req6.='
  ORDER BY T0.`fld_priority_todos` ASC , T0.`fld_id_todos` DESC 
 '; 
}
if($xsrch_sort=='T0.fld_id_todos'){
 $req6.='
  ORDER BY T0.`fld_id_todos` DESC 
 '; 
}
if($isSuperUser){

 if($xsrch_sort=='T0.fld_id_user_todos'){
  $req6.='
   ORDER BY T0.`fld_id_user_todos` ASC 
  '; 
 }
 if($xsrch_sort=='T1.fld_login_users'){
  $req6.='
   ORDER BY T1.`fld_login_users` , T1.`fld_firstname_users`  , T1.`fld_lastname_users`
  '; 
 }
}
if($xsrch_sort=='T0.fld_title_todos'){
 $req6.='
  ORDER BY T0.`fld_title_todos` ASC 
 '; 
}
if($xsrch_sort=='T0.fld_comment_todos'){
 $req6.='
  ORDER BY T0.`fld_comment_todos` ASC 
 '; 
}

$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$__count=0;
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'T0.fld_id_todos'              =>$mpsr6[0],
  'T0.fld_priority_todos'        =>$mpsr6[1],
  'T0.fld_id_user_todos'         =>$mpsr6[2],
  'T1.fld_login_users'           =>$mpsr6[3],
  'T0.fld_title_todos'           =>$mpsr6[6],
  'T0.fld_comment_todos'         =>$mpsr6[7],
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}
$lsttbl='';

if($__count==0){
 $lst.='<p>'.CRLF;
 $lst.=''.txt2('no_record_founded_360_16').''.CRLF;
 $lst.='<a href="zz_todos_action1.php?a=c">'.txt2('add_a_new_record_361_51').'</a>'.CRLF;
 $lst.='</p>'.CRLF;
 $o1.=''.$lst.''.CRLF;  
}else{
 $consUrlRedir=''.
               ($xsrch_0!=''?'&amp;xsrch_0='.rawurlencode($xsrch_0):''). // fld_priority_todos 
               ($isSuperUser?($xsrch_1!=''?'&amp;xsrch_1='.rawurlencode($xsrch_1):''):''). // fld_id_user_todos 
                ($isSuperUser?($xsrch_2!=''?'&amp;xsrch_2='.rawurlencode($xsrch_2):''):''). // fld_login_users of parent
               ($xsrch_5!=''?'&amp;xsrch_5='.rawurlencode($xsrch_5):''). // fld_title_todos 
               ($xsrch_6!=''?'&amp;xsrch_6='.rawurlencode($xsrch_6):''). // fld_comment_todos 
               ($xsrch_hide90!=''?'&amp;xsrch_hide90='.rawurlencode($xsrch_hide90):''). // xsrch_hide90 
               ($xsrch_id!=''?'&amp;xsrch_id='.rawurlencode($xsrch_id):'').
               ($xsrch_sort!=''?'&amp;xsrch_sort='.rawurlencode($xsrch_sort):'').
               '';
 $ri=' <span class="btn unset">&raquo;</span>';
 if($__start+$__nbMax<$__count){
  $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
 }
 $le=' <span class="btn unset">&laquo;</span>';
 if($__xpage>0){
  $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
 }

 $o1.='<div>';
 $o1.='<form action="" method="post">';
 $o1.='&nbsp;<button class="edit" type="submit" name="subOneToPriorities">'.txt2('Sub 1 to priorities_372_82').'</button>';
 $o1.='&nbsp;<a href="zz_todos2.php" class="edit" >'.txt2('sort_todos_375_59').'</a>';
 $o1.='&nbsp;<a href="javascript:initSortModalTodo1()" class="edit" >modal '.txt2('sort_todos_375_59').'</a>';
 $o1.='&nbsp;<button class="edit" type="submit" name="addOneToPriorities" >'.txt2('Add 1 to priorities_371_82').'</button>';
 $o1.='&nbsp;<a href="zz_todos_action1.php?a=c">'.txt2('add_a_new_record_361_51').'</a>'.CRLF;
 $o1.='&nbsp;'.$le.''.CRLF;  
 $o1.='&nbsp;'.$ri.''.CRLF;  
 $o1.=' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('records todos_390_80').' )';
 $o1.='</form>';
 $o1.='</div>';

 $o1.=getCss1(890); // todo adjust size

 $lsttbl.='<thead><tr>';
 $lsttbl.='<th style="min-width:285px;">'.txtsys1('column_action').'</th>';
 $lsttbl.='<th style="min-width:85px;">'.txt2('fld_id_todos_152_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_priority_todos_169_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_title_todos_175_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_comment_todos_181_39').'</th>';
 if($isSuperUser){
  $lsttbl.='<th>'.txt2('fld_id_user_todos_137_153').'</th>';
  $lsttbl.='<th>'.txt2('T1.fld_login_users_216_149').'</th>'; // ======== parent field of fld_id_user_todos
 }
 $lsttbl.='</tr></thead><tbody>';

 foreach($data0 as $k0=>$v0){

  if($v0['T0.fld_priority_todos']==99){
   $lsttbl.='<tr class="success"><td class="fictif"></td>';   
  }else{
   $lsttbl.='<tr><td class="fictif"></td>';
  }

  $lsttbl.='<td data-label="" style="text-align:left!important;">';
  $lsttbl.='<div class="flex1">';
  if($isSuperUser&&$v0['T0.fld_id_user_todos']==1){
   $lsttbl.='<a class="danger txtSiz1" href="zz_todos_action1.php?a=d&amp;id='.$v0['T0.fld_id_todos'].'" title="'.txtsys1('delete_button').'">&#10008;</a>';//✘ #10008
  }else{
   $lsttbl.='<a class="danger txtSiz1" href="zz_todos_action1.php?a=d&amp;id='.$v0['T0.fld_id_todos'].'" title="'.txtsys1('delete_button').'">&#10008;</a>';//✘ #10008   
  }
  if($isSuperUser&&$v0['T0.fld_id_user_todos']==1){
   $lsttbl.='<a class="txtSiz2" href="zz_todos_action1.php?a=du&amp;id='.$v0['T0.fld_id_todos'].'" title="'.txtsys1('duplicate_button').'">&#x2398;</a>';//⎘:x2398 📋:#128203
  }else{
   $lsttbl.='<a class="txtSiz2" href="zz_todos_action1.php?a=du&amp;id='.$v0['T0.fld_id_todos'].'" title="'.txtsys1('duplicate_button').'">&#x2398;</a>';//⎘:x2398 📋:#128203   
  }
  if($v0['T0.fld_priority_todos']<99){
   $lsttbl.='<a class="" href="?a=plusOne&amp;id='.$v0['T0.fld_id_todos'].''.$consUrlRedir.'" title="'.txt2('add_one_to_this_todo_328_101').'">+1</a>';
  }else{
   $lsttbl.='<span class=" btn unset" title="'.txt2('add_one_to_this_todo_328_101').'">+1</span>';   
  }
  if($v0['T0.fld_priority_todos']>0){
   if($v0['T0.fld_priority_todos']!=99){
    $lsttbl.='<a href="?a=minusOne&amp;id='.$v0['T0.fld_id_todos'].''.$consUrlRedir.'" title="'.txt2('sub_one_to_this_todo_331_102').'">-1</a>';
   }else{
    $lsttbl.='<span class="btn unset" title="'.txt2('sub_one_to_this_todo_331_102').'">-1</span>';      
   }
  }else{
   $lsttbl.='<span class="btn unset" title="'.txt2('sub_one_to_this_todo_331_102').'">-1</span>';   
  }
  if($v0['T0.fld_priority_todos']!=99){
   $lsttbl.='<a class="" href="?a=setTo99&amp;id='.$v0['T0.fld_id_todos'].''.$consUrlRedir.'" title="'.txt2('setTo99_334_101').'">99</a>';
  }else{
   $lsttbl.='<span class="btn unset" title="'.txt2('setTo99_334_101').'">99</span>';   
  }
  if($v0['T0.fld_priority_todos']!=0){
   $lsttbl.='<a href="?a=setTo00&amp;id='.$v0['T0.fld_id_todos'].''.$consUrlRedir.'" title="'.txt2('setTo00_337_101').'">00</a>';
  }else{
   $lsttbl.='<span class="btn unset" title="'.txt2('setTo00_337_101').'">00</span>';   
  }   
  
  $lsttbl.='<a class="edit txtSiz1" href="zz_todos_action1.php?a=u&amp;id='.$v0['T0.fld_id_todos'].'" title="'.txtsys1('edit_button').'">&#9998;</a>';//✎ #9998
  
  $lsttbl.='</div>';
  $lsttbl.='</td>';
  $sty1='';
  if($v0['T0.fld_priority_todos']>=90&&$v0['T0.fld_priority_todos']<99){
   $sty1='font-weight:bold;';
  }

  $lsttbl.='<td data-label="'.txt2('fld_id_todos_152_152').'" style="text-align:center;'.$sty1.'">';
  $lsttbl.=''.$v0['T0.fld_id_todos'].''; // fld_id_todos
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_priority_todos_169_39').'" style="text-align:center;'.$sty1.'">';
  $lsttbl.=''.enti1($v0['T0.fld_priority_todos']).''; // fld_priority_todos
  $lsttbl.='</td>';

  
  $lsttbl.='<td data-label="'.txt2('fld_title_todos_175_39').'" style="'.$sty1.'">';
  $lsttbl.=''.enti1($v0['T0.fld_title_todos']).''; // fld_title_todos
  $lsttbl.='</td>';

  if($v0['T0.fld_comment_todos']==''||is_null($v0['T0.fld_comment_todos'])){
   $lsttbl.='<td data-label="'.txt2('fld_comment_todos_181_39').'"></td>';
  }else{
   $lsttbl.='<td data-label="'.txt2('fld_comment_todos_181_39').'" style="'.$sty1.'font-family: monospace;white-space: pre-line;">';
   $lsttbl.=''.enti1(mb_substr($v0['T0.fld_comment_todos'],0,100,'UTF-8')).''; // fld_comment_todos
   $lsttbl.='</td>';
  }

  if($isSuperUser){
   $lsttbl.='<td data-label="'.txt2('fld_id_user_todos_137_153').'" style="text-align:center;">';
   $lsttbl.=''.enti1($v0['T0.fld_id_user_todos']).''; // fld_id_user_todos 
   $lsttbl.='</td>';

 // field fld_login_users of parent table
   if($v0['T1.fld_login_users']===0||is_null($v0['T1.fld_login_users'])){
    $lsttbl.='<td data-label="'.txt2('T1.fld_login_users_216_149').'"></td>'; 
   }else{
    $lsttbl.='<td data-label="'.txt2('T1.fld_login_users_216_149').'">';
    $lsttbl.=''.enti1($v0['T1.fld_login_users']).''; // fld_login_users
    $lsttbl.='</td>';
   }

  }
  
  $lsttbl.='<td class="fictif"></td></tr>';

 }

 $o1.='<table class="tableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;

 $o1.=' <div>'.CRLF;
 $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('records todos_390_80').' )'.CRLF;
 $o1.='   &nbsp;<a class="" href="zz_todos_action1.php?a=c">'.txt2('add_a_new_record_361_51').'</a>'.CRLF;
 $o1.=' </div>'.CRLF;

}

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
