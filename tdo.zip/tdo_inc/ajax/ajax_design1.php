<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 

 openDb1();
// if($fd=fopen('toto.txt','a')){fwrite($fd,''.date('Y-m-d H:i:s'). ' ' . __LINE__ ."\r\n".'$ret='.var_export($ret,true)."\r\n"); fclose($fd);}

 //=============================================================================================================================
 if($ret['input']['subFunct']=='linkDelete1'){
  
  if($ret['input']['fld_view_tables']==1){
   
    $txt='';
    $req7="SHOW CREATE TABLE `".$GLOBALS['glob_db'][0]['dbname']."`.`".$ret['input']['parentTableName']."` " ;
    $res7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
     while($row=mysqli_fetch_row($res7)){
      $ret['message'][]=$row[1];
      $txt=$row[1];
     }
     mysqli_free_result($res7);
    }
    if($txt!=''){
      $arr=explode("\n",$txt);
      foreach($arr as $v1){
        if(strpos($v1,'`'.$ret['input']['parentField'].'`')!==false && strpos($v1,'CREATE TABLE')===false  ){
         
          $line=$v1;
          if(substr($v1,-1)==','){
            $line=substr($line,0,-1);
          }
          if(strpos($line,' COMMENT')!==false){
            $line=substr($line,0,strpos($line,' COMMENT'));       
          }
          
          $actualComment=$ret['input']['actualComment'];
          $newComment='';
          if($actualComment==''||$actualComment=='null'){
            $newComment='';
          }else{
            $phpActualComment=json_decode($actualComment,true);
            if(isset($phpActualComment['view_key_for'])){
              foreach( $phpActualComment['view_key_for'] as $k1 => $v1){
                if($v1==$ret['input']['tableName']){
                  unset($phpActualComment['view_key_for'][$k1]);
                }
              }
              if(count($phpActualComment['view_key_for'])==0){
                unset($phpActualComment['view_key_for']);
              }
              if(count($phpActualComment)==0){
                $newComment='';
              }else{
                if(isset($phpActualComment['view_key_for'])){
                  $old=$phpActualComment['view_key_for'];
                  unset($phpActualComment['view_key_for']);
                  $new=array();
                  foreach($old as $v1){
                    $new[]=$v1;
                  }
                  $phpActualComment['view_key_for']=$new;
                }
                $newComment=$phpActualComment;
              }
            }
          }
          if($newComment===''){
            $sql='ALTER TABLE `'.$ret['input']['parentTableName'].'` CHANGE `'.$ret['input']['parentField'].'` '.$line.' ';
          }else{
            $sql='ALTER TABLE `'.$ret['input']['parentTableName'].'` CHANGE `'.$ret['input']['parentField'].'` '.$line.' COMMENT '.var_export(json_encode($newComment),true).'';
          }
          $ret['message']['sql']=$sql;
          $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
          if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
            $ret['message']['newComment']=json_encode($newComment);
            $ret['newComment']=$newComment===''?$newComment:json_encode($newComment);
            $ret['status']='OK';
          }
          break;
        }
      }
    }       
  }else{
   $ret['status']='OK';
  }
  if($ret['status']=='OK'){
   $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tablelinks` WHERE `fld_id_pglnks`   =  ".$ret['input']['db_id_link']." " ;
   $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    $ret['status']='OK';
    $ret['db_id_link']=$ret['input']['db_id_link'];
    require_once($GLOBALS['glob_incPath1'].'/zz_inc_tablelinks1.php');
    writeTableDependencies1();
    
   }
  }
 }
 //=============================================================================================================================
 if($ret['input']['subFunct']=='addLinkFromDesign1'){

  if($ret['input']['child_view']==1){
   
    // ajoute un {"view_key_for":["nom_de_la_vue"]}
    
    $fld_parent_field_display_pglnks=$ret['input']['parentField'];

    $txt='';
    $req7="SHOW CREATE TABLE `".$GLOBALS['glob_db'][0]['dbname']."`.`".$ret['input']['parentTableName']."` " ;
    $res7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
     while($row=mysqli_fetch_row($res7)){
      $ret['message'][]=$row[1];
      $txt=$row[1];
     }
     mysqli_free_result($res7);
    }
    if($txt!=''){
      $arr=explode("\n",$txt);
      foreach($arr as $v1){
        if(strpos($v1,'`'.$ret['input']['parentField'].'`')!==false && strpos($v1,'CREATE TABLE')===false  ){
         
          $line=$v1;
          if(substr($v1,-1)==','){
            $line=substr($line,0,-1);
          }
          if(strpos($line,' COMMENT')!==false){
            $line=substr($line,0,strpos($line,' COMMENT'));       
          }
          
          $actualComment=$ret['input']['actualComment'];
          $newComment='';
          if($actualComment==''||$actualComment=='null'){
            $newComment=json_decode($ret['input']['comment']);
          }else{
            $phpActualComment=json_decode($actualComment,true);
            if(isset($phpActualComment['view_key_for'])){
              foreach($phpActualComment['view_key_for'] as $k1 => $v1){
                if($v1==$ret['input']['view_to_add']){
                  unset($phpActualComment['view_key_for'][$k1]);
                }
              }
            }
            if(isset($phpActualComment['view_key_for'])){
              $phpActualComment['view_key_for'][]=$ret['input']['view_to_add'];
            }else{
              $phpActualComment['view_key_for']=array($ret['input']['view_to_add']);
            }
            if(isset($phpActualComment['view_key_for'])){
             $old=$phpActualComment['view_key_for'];
             unset($phpActualComment['view_key_for']);
             $new=array();
             foreach($old as $v1){
              $new[]=$v1;
             }
             $phpActualComment['view_key_for']=$new;
            }
            
            
            $newComment=$phpActualComment;
          }
          $sql='ALTER TABLE `'.$ret['input']['parentTableName'].'` CHANGE `'.$ret['input']['parentField'].'` '.$line.' COMMENT '.var_export(json_encode($newComment),true).'';
              
          $ret['message']['sql']=$sql;
          $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
          if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
            $ret['message']['newComment']=json_encode($newComment);
            $ret['newComment']=json_encode($newComment);
            $ret['status']='OK';
          }
              
          break;
         
        }
      }
    }    
    
    
  }else{
    $fld_parent_field_display_pglnks='';
    $ret['status']='OK';
  }
  if($ret['status']=='OK'){
    $ret['status']='KO';
    $req6="
     INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tablelinks` SET
        `fld_parent_field_pglnks`         = '".addslashes1($ret['input']['parentField'])      ."'
      , `fld_child_field_pglnks`          = '".addslashes1($ret['input']['childField'])       ."'
      , `fld_parent_field_display_pglnks` = '".addslashes1($fld_parent_field_display_pglnks)  ."'
      , `fld_parent_table_id_pglnks`      =  ".$ret['input']['parentTable']                   ."
      , `fld_children_table_id_pglnks`    =  ".$ret['input']['childTable']                    ."
      , `fld_link_mandatory_pglnks`       =  1
      , `fld_tsupd_pglnks`                = '".addslashes($GLOBALS['glob_setdate'])           ."'
      , `fld_tscrt_pglnks`                = '".addslashes($GLOBALS['glob_setdate'])           ."'
    " ;
    $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
      $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
      if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
        $NewCode=mysqli_fetch_row($resIns);
        $ret['status']='OK';
        $ret['db_id_link']=$NewCode[0];
        mysqli_free_result($resIns);
      }
    }else{
      $ret['message'][]=mysqli_error($GLOBALS['glob_db'][0]['link']);
    }
  }
  require_once($GLOBALS['glob_incPath1'].'/zz_inc_tablelinks1.php');
  writeTableDependencies1();
      
 }
 //=============================================================================================================================
 if($ret['input']['subFunct']=='addTable1'){
  
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tables` SET
      `fld_id_server_tables`         = '".addslashes1($ret['input']['fld_id_server_tables']) ."'
    , `fld_name_tables`              = '".addslashes1($ret['input']['fld_name_tables'])      ."'
    , `fld_system_tables`            = 0
    , `fld_view_tables`              = 0
    , `fld_id_reftbl_of_view_tables` = NULL 
    , `fld_log_tables`               = 1
    , `fld_remote_tables`            = 1
    , `fld_restore_transform_tables` = ''
    , `fld_tsupd_tables`             = '".addslashes($GLOBALS['glob_setdate']) ."'
    , `fld_tscrt_tables`             = '".addslashes($GLOBALS['glob_setdate']) ."'
  " ;
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $ret['status']='OK';
  }else{
   $ret['message'][]=mysqli_error($GLOBALS['glob_db'][0]['link']);   
  }
 }
 
 //=============================================================================================================================
 if($ret['input']['subFunct']=='addView1'){
  
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tables` SET
      `fld_id_server_tables`         = '".addslashes1($ret['input']['fld_id_server_tables']) ."'
    , `fld_name_tables`              = '".addslashes1($ret['input']['view_name'])            ."'
    , `fld_system_tables`            = 0
    , `fld_view_tables`              = 1
    , `fld_id_reftbl_of_view_tables` = ".addslashes1($ret['input']['fld_id_reftbl_of_view_tables'])  ." 
    , `fld_log_tables`               = 0
    , `fld_remote_tables`            = 1
    , `fld_restore_transform_tables` = ''
    , `fld_tsupd_tables`             = '".addslashes($GLOBALS['glob_setdate']) ."'
    , `fld_tscrt_tables`             = '".addslashes($GLOBALS['glob_setdate']) ."'
  " ;
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $ret['status']='OK';
  }else{
   $ret['message'][]=mysqli_error($GLOBALS['glob_db'][0]['link']);   
  }
 }
 
 //=============================================================================================================================
 if($ret['input']['subFunct']=='addLinkDisplayField1'){
  if($ret['input']['actualList']==''){
   $actualList=array();
  }else{
   $actualList=explode(',',$ret['input']['actualList']);
   foreach($actualList as $k1=>$v1){
    if($v1==$ret['input']['nom_champ']){
     unset($actualList[$k1]);
     break;
    }
   }
  }
  $newList=implode(',',$actualList);
  if($newList==''){
   $newList=$ret['input']['nom_champ'];
  }else{
   $newList.=','.$ret['input']['nom_champ'];   
  }
  $req6="
   UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tablelinks` SET
      `fld_parent_field_display_pglnks` = '".addslashes($newList)."'
    , `fld_tsupd_pglnks`                = '".addslashes($GLOBALS['glob_setdate'])      ."'
    , `fld_tscrt_pglnks`                = '".addslashes($GLOBALS['glob_setdate'])      ."'
    WHERE `fld_id_pglnks`   =  ".$ret['input']['db_id_link']."
  " ;
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $ret['status']='OK';
   $ret['newList']=$newList;
  }
 }
 //=============================================================================================================================
 if($ret['input']['subFunct']=='removeLinkDisplayField1'){
  if($ret['input']['actualList']!==''){
   $actualList=explode(',',$ret['input']['actualList']);
   foreach($actualList as $k1=>$v1){
    if($v1==$ret['input']['nom_champ']){
     unset($actualList[$k1]);
     break;
    }
   }
   $newList=implode(',',$actualList);
   $req6="
    UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tablelinks` SET
       `fld_parent_field_display_pglnks` = '".addslashes($newList)."'
     , `fld_tsupd_pglnks`                = '".addslashes($GLOBALS['glob_setdate'])      ."'
     , `fld_tscrt_pglnks`                = '".addslashes($GLOBALS['glob_setdate'])      ."'
     WHERE `fld_id_pglnks`   =  ".$ret['input']['db_id_link']."
   " ;
   $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    $ret['status']='OK';
    $ret['newList']=$newList;
   }
  }
 }
 //=============================================================================================================================
 if($ret['input']['subFunct']=='setParentLinkMandatory1'){
  
  $req6="
   UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tablelinks` SET
      `fld_link_mandatory_pglnks`       =  ".($ret['input']['fld_link_mandatory_pglnks']==1?0:1)."
    , `fld_tsupd_pglnks`                = '".addslashes($GLOBALS['glob_setdate'])      ."'
    , `fld_tscrt_pglnks`                = '".addslashes($GLOBALS['glob_setdate'])      ."'
    WHERE `fld_id_pglnks`   =  ".$ret['input']['db_id_link']."
  " ;
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $ret['status']='OK';
  }
 }
 //=============================================================================================================================
 if($ret['input']['subFunct']=='addComment1'){
  
   $txt='';
   $req6="SHOW CREATE TABLE `".$GLOBALS['glob_db'][$ret['input']['fld_id_server_tables']]['dbname']."`.`".$ret['input']['fld_name_tables']."` " ;
   $ret['message'][]=$req6;
   $res6=@mysqli_query($GLOBALS['glob_db'][$ret['input']['fld_id_server_tables']]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][$ret['input']['fld_id_server_tables']]['link'])==0){
    while($row=mysqli_fetch_row($res6)){
     $ret['message'][]=$row[1];
     $txt=$row[1];
    }
   }
   if($txt!=''){
     $arr=explode("\n",$txt);
     foreach($arr as $v1){
       if(strpos($v1,'`'.$ret['input']['nom_champ'].'`')!==false && strpos($v1,'CREATE TABLE')===false  ){
         $line=$v1;
         if(substr($v1,-1)==','){
          $line=substr($line,0,-1);
         }
         if(strpos($line,' COMMENT')!==false){
          $line=substr($line,0,strpos($line,' COMMENT'));       
         }
         $actualComment=$ret['input']['actualComment'];
         $newComment='';
         if($actualComment==''||$actualComment=='null'){
          $newComment=json_decode($ret['input']['comment']);
         }else{
          $newComment=array_replace_recursive(json_decode($actualComment,true),json_decode($ret['input']['comment'],true));
         }
         $sql='ALTER TABLE `'.$ret['input']['fld_name_tables'].'` CHANGE `'.$ret['input']['nom_champ'].'` '.$line.' COMMENT '.var_export(json_encode($newComment),true).'';
         $ret['message']['sql']=$sql;
         $res6=@mysqli_query($GLOBALS['glob_db'][$ret['input']['fld_id_server_tables']]['link'],$sql);
         if(mysqli_errno($GLOBALS['glob_db'][$ret['input']['fld_id_server_tables']]['link'])==0){
          $ret['status']='OK';
          $ret['message']['newComment']=json_encode($newComment);
          $ret['newComment']=json_encode($newComment);
         }
         break;
       }
     }
   }
  
 }
 //=============================================================================================================================
 if($ret['input']['subFunct']=='clearComment1'){
  
  
   $txt='';
   $req6="SHOW CREATE TABLE `".$GLOBALS['glob_db'][$ret['input']['fld_id_server_tables']]['dbname']."`.`".$ret['input']['fld_name_tables']."` " ;
   $res6=@mysqli_query($GLOBALS['glob_db'][$ret['input']['fld_id_server_tables']]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][$ret['input']['fld_id_server_tables']]['link'])==0){
    while($row=mysqli_fetch_row($res6)){
     $txt=$row[1];
    }
   }
   if($txt!=''){
    $arr=explode("\n",$txt);
    foreach($arr as $v1){
     if(strpos($v1,'`'.$ret['input']['nom_champ'].'`')!==false  && strpos($v1,'CREATE TABLE')===false  ){
      $line=$v1;
      if(substr($v1,-1)==','){
       $line=substr($line,0,-1);
      }
      if(strpos($line,' COMMENT')!==false){
       $line=substr($line,0,strpos($line,' COMMENT'));
      }

      $sql='ALTER TABLE `'.$ret['input']['fld_name_tables'].'` CHANGE `'.$ret['input']['nom_champ'].'` '.$line;
      $ret['message'][]=$sql; // "ALTER TABLE `tdo_city` CHANGE `Name`   `Name` char(35) NOT NULL DEFAULT ''"
      $res6=@mysqli_query($GLOBALS['glob_db'][$ret['input']['fld_id_server_tables']]['link'],$sql);
      if(mysqli_errno($GLOBALS['glob_db'][$ret['input']['fld_id_server_tables']]['link'])==0){
       $ret['status']='OK';
      }
      
      break;
     }
    }
   }
  
 }
 //=============================================================================================================================
 if($ret['input']['subFunct']=='saveDesign1'){
  if($fd=fopen($GLOBALS['glob_incPath1'].'/__localhost-design1.php','w')){
   fwrite($fd,'<'.'?php'.CRLF.'$__design1='.var_export($ret['input']['design1'],true).';');
   fclose($fd);
   $ret['status']='OK';
   $ret['message'][]='hello' . BNF;    
  }else{
   $ret['message'][]='KO write in ' . BNF . ' in line ' . __LINE__ ;
  }
 }
 //=============================================================================================================================
 
 
 
}else{
 
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;   
 
}