<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb2();
//========================================================================================================================

function updateSetOfDependantTables($idSet){
// echo __FILE__ . ' ' . __LINE__ . ' $idSet = <pre>' . var_export( $idSet , true ) . '</pre>' ; exit(0);
 $listOfKeys=array();
 $req6='
  SELECT  T0.`fld_json_parvals`  , T0.`fld_id_parvals`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramvalues` T0 
  WHERE T0.`fld_id_parname_parvals`  = ' . $idSet . '
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $data=null;
  while($mpsr6=mysqli_fetch_row($result6)){
   $data=json_decode($mpsr6[0],true);
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $data , true ) . '</pre>' ; exit(0);
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $data , true ) . '</pre>' ; exit(0);
   foreach($data as $k1 => $v1){
    $listOfKeys[]=$k1;
   }
  }
  mysqli_free_result($result6);
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listOfKeys , true ) . '</pre>' ; exit(0);
 }else{
  $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
  txtlog1($xtxterr , BNF , __LINE__ , 2 );
 }
 if(sizeof($listOfKeys)==0){
  return;
 }
 $dataDefinition=array();
 $req6='
  SELECT  T0.`fld_id_parnams`   , T0.`fld_key_parnams`  , T0.`fld_comment_parnams` , T0.`fld_json_parnams` , T0.`fld_label_parnams`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramnames` T0 
  WHERE T0.`fld_id_parnams` =  ' . $idSet . '
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $data=null;
  while($mpsr6=mysqli_fetch_row($result6)){
   $dataDefinition=json_decode($mpsr6[3],true);
  }
  mysqli_free_result($result6);
 }else{
  $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
  txtlog1($xtxterr , BNF , __LINE__ , 2 );
 }
 if(sizeof($dataDefinition['dependencies'])>=0){
  
  $lstKeys='';
  foreach($listOfKeys as $k1 => $v1){
   $lstKeys.='\''.$v1.'\',' ;
  }
  $lstKeys=substr($lstKeys,0,-1);
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $lstKeys , true ) . '</pre>' ; exit(0);
  
  foreach($dataDefinition['dependencies'] as $k1 => $v1){
   $req6=' SHOW FULL COLUMNS FROM `'.$v1['table'].'` IN `'.$GLOBALS['glob_db'][$v1['id_db']]['dbname'].'` ';
//   echo __FILE__ . ' ' . __LINE__ . ' $v1 = <pre>' . var_export( $v1 , true ) . '</pre>' ; exit(0);
   $result6=mysqli_query($GLOBALS['glob_db'][$v1['id_db']]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][$v1['id_db']]['link'])==0){
    while($mpsr6=mysqli_fetch_array($result6)){
     if($mpsr6[0]==$v1['field'] && $mpsr6[8]!='' ){
      $phpComment=json_decode($mpsr6[8],true);
      if(isset($phpComment['param']) && isset($phpComment['set']) && $phpComment['set']==true ){
       $req7='
        ALTER TABLE `'.$GLOBALS['glob_db'][$v1['id_db']]['dbname'].'`.`tdo_tbl__zztests` 
        CHANGE `'.$v1['field'].'` `'.$v1['field'].'` 
        SET( '.$lstKeys.') 
        CHARACTER SET utf8 
        COLLATE utf8_unicode_ci NOT NULL COMMENT \''.addslashes($mpsr6[8]).'\'
       ';
//       echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . $req7 . '</pre>' ; exit(0);
       $result7=mysqli_query($GLOBALS['glob_db'][$v1['id_db']]['link'],$req7);
       if(mysqli_errno($GLOBALS['glob_db'][$v1['id_db']]['link'])==0){
       }else{
        $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req7 . txtsys1('please_retry') ;
        $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
        txtlog1($xtxterr , BNF , __LINE__ , 2 );
       }
      }
     }
    }
   }else{
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 2 );
   }    
  }
 }
// echo __FILE__ . ' ' . __LINE__ . ' $dataDefinition = <pre>' . var_export( $dataDefinition , true ) . '</pre>' ; exit(0);
 
// echo __FILE__ . ' ' . __LINE__ . ' $listOfKeys = <pre>' . var_export( $listOfKeys , true ) . '</pre>' ; exit(0);
}
//========================================================================================================================

//updateSetOfDependantTables(4);
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
//========================================================================================================================
//========================================================================================================================
if(!isset($_REQUEST['id'])){
 header("HTTP/1.1 303 See Other");header('Location: zz_paramkeys.php');
 exit();
}
require_once($GLOBALS['glob_incPath1'].'/paramkeys1.php');
$dataParam=incGetParam1($_REQUEST['id']);
if($dataParam['fld_id_parnams']==0){
 header("HTTP/1.1 303 See Other");header('Location: zz_paramkeys.php');
 exit();
}

//===============================================================================================================
function checkKeyExist($keyValue,$valuesIn){
 $keyList=array();
 $req6='
  SELECT  SQL_CALC_FOUND_ROWS
   T0.`fld_id_parvals`   , T0.`fld_json_parvals`  
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramvalues` T0 
  WHERE T0.`fld_id_parname_parvals`  = ' . $_REQUEST['id'] . '
 ';
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . $req6 . '</pre>' ; exit(0);
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($mpsr6=mysqli_fetch_row($result6)){
    $values=json_decode( $mpsr6[1] , true );
//    echo __FILE__ . ' ' . __LINE__ . ' $keyValue="'.$keyValue.'" = <pre>' . var_export( $values , true ) . '</pre>' ; exit(0);
    foreach($values as $k1 => $v1){
     $keyList[]=$k1;
    }
    
   }
   mysqli_free_result($result6);
 }else{
  $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
 }
// echo __FILE__ . ' ' . __LINE__ . ' keyValue = '.$keyValue.'<pre>' . var_export( $keyList , true ) . '</pre>in_array($keyValue,$keyList)=<pre>' . var_export( in_array($keyValue,$keyList) , true ) . '</pre>' ; exit();
 return in_array($keyValue,$keyList); 
}
//===============================================================================================================
if(isset($_POST) && sizeof($_POST)>0){
// echo __FILE__ . ' ' . __LINE__ . ' $_POST = <pre>' . var_export( $_POST , true ) . '</pre> $dataParam = <pre>' . var_export( $dataParam , true ) . '</pre>' ; exit(0);
 //===============================================================================================================
 if('del'===$_POST['action'] && isset($_POST['but_delete']) && $_POST['but_delete'] == 'delete'){
  $dataDefJsonParams=json_decode($dataParam['fld_json_parnams'],true);
  $founded=false;
//  echo __FILE__ . ' ' . __LINE__ . ' $dataDefJsonParams = <pre>' . var_export( $dataDefJsonParams , true ) . '</pre>' ; exit(0);
  if(isset($dataDefJsonParams['dependencies']) && sizeof($dataDefJsonParams['dependencies'])>0){
   $keyName='param__'.$dataParam['fld_key_parnams'];
   @include $GLOBALS['glob_dataPath1'].'/generated/_params/'.$dataParam['fld_key_parnams'].'.php';
   if(isset($GLOBALS[$keyName])){
    foreach( $dataDefJsonParams['dependencies'] as $k1 => $v1 ){
     if(false === $founded){
      if($GLOBALS[$keyName]['param__Key__type']=='int'){
       $req6="SELECT `".$v1['field']."` FROM `".$GLOBALS['glob_db'][$v1['id_db']]['dbname']."`.`".$v1['table']."` WHERE `".$v1['field']."` = ".$_POST['key']." LIMIT 1";             
      }else{
       $req6="SELECT `".$v1['field']."` FROM `".$GLOBALS['glob_db'][$v1['id_db']]['dbname']."`.`".$v1['table']."` WHERE `".$v1['field']."` = '".$_POST['key']."' LIMIT 1";      
      }
//      echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . $req6 . '</pre>' ; 
      $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
      if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
       while($mpsr6=mysqli_fetch_row($result6)){
        $founded=true;
        $_SESSION[PGMK][NAV][BNF]['errormessage'][]= txtsys1('error').' ' . __LINE__ . txt2('This value is present in some tables_171_93') . ' "'.$v1['table'].'"  "'.$v1['field'].'" ';
       }
       mysqli_free_result($result6);
      }else{
       $founded=true;
       $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
       txtlog1($xtxterr , BNF , __LINE__ , 2 );
      }     
     }
    }
   }
  }
  if(false===$founded){
//   echo __FILE__ . ' ' . __LINE__ . ' $id = <pre>' . var_export( $_POST['id'] , true ) . '</pre>  $founded = <pre>' . var_export( $founded , true ) . '</pre> $_POST[id_param_value] = <pre>' . var_export( $_POST['id_param_value'] , true ) . '</pre>' ; exit(0);
   $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__paramvalues` WHERE `fld_id_parvals` = '".$_POST['id_param_value'] . "'" ;
   $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 2 );
   }else{
    writeParamFiles($_POST['id']);
    updateSetOfDependantTables($_POST['id']);
    $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('message').' '. __LINE__ .' : ' . txt2('the parameter has been deleted_195_91');
   }
  }
//  echo __FILE__ . ' ' . __LINE__ . ' $founded='.$founded.' ,$_POST = <pre>' . var_export( $_POST , true ) . '</pre>$dataDefJsonParams = <pre>' . var_export( $dataDefJsonParams , true ) . '</pre>' ; exit(0); 
 }
 //===============================================================================================================
 //===============================================================================================================
 
 if('c'===$_POST['action']){
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
  $dataDefJsonParams=json_decode($dataParam['fld_json_parnams'],true);
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $dataDefJsonParams , true ) . '</pre>' ; exit(0);
  $err=0;
  if($err==0){
   foreach($dataDefJsonParams['fields'] as $k1 => $v1){
    if((isset($v1['languageTranslation']) && true===$v1['languageTranslation']) ){
     foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang){
      if(!isset($_POST[$v1['name'].'_'.$klang]) || $_POST[$v1['name'].'_'.$klang]==''){
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : "'.$klang.'" "'.$v1[name].'" : ' . txt2('the parameter must not be void_213_128');
       $err=1;
      }else{
       $_SESSION[PGMK][NAV][BNF][$v1['name'].'_'.$klang]=$_POST[$v1['name'].'_'.$klang];
       if($v1['type']=='int'){
        if(!is_numeric($_POST[$v1['name'].'_'.$klang])){
         $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : "'.$klang.'" "'.$v1[name].'" : ' . txt2('the parameter must be numerical_219_130');       
         $err=1;
        }else{
         $_SESSION[PGMK][NAV][BNF][$v1['name'].'_'.$klang]=(int)$_POST[$v1['name'].'_'.$klang];
        }
       }else{
        $_SESSION[PGMK][NAV][BNF][$v1['name'].'_'.$klang]=$_POST[$v1['name'].'_'.$klang];
       }
      }
     }
     
    }else{
     if(!isset($_POST[$v1['name']]) || $_POST[$v1['name']]==''){
      $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : "'.$v1[name].'" : ' . txt2('the parameter must not be void_213_128');
      $err=1;
     }else{
      $_SESSION[PGMK][NAV][BNF][$v1['name']]=$_POST[$v1['name']];       
      if($v1['type']=='int'){
       if(!is_numeric($_POST[$v1['name'].'_'.$klang])){
        $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : "'.$klang.'" "'.$v1[name].'" : ' . txt2('the parameter must be numerical_219_130');       
        $err=1;
       }else{
        $_SESSION[PGMK][NAV][BNF][$v1['name']]=(int)$_POST[$v1['name']];       
       }
      }else{
       $_SESSION[PGMK][NAV][BNF][$v1['name']]=$_POST[$v1['name']];
      }
     }
    }
   }
  }
  
  if($err==0){
   $paramValues=array();
   $key_name=$dataDefJsonParams['key'];
   $values=array();
   $keyValue=(string)$_POST[$key_name];
   foreach($dataDefJsonParams['fields'] as $k1 => $v1){
    if(isset($v1['languageTranslation']) && true===$v1['languageTranslation']){
     foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang){
      $values[$keyValue][$v1['name']][$klang]=$_POST[$v1['name'].'_'.$klang];    
     }
    }else{
     $values[$keyValue][$v1['name']]=$_POST[$v1['name']];    
    }
   }
   $values[$keyValue]['badge']=$_POST['badge'];
   $values[$keyValue]['rule']=$_POST['rule'];
//   echo __FILE__ . ' ' . __LINE__ . ' $key_name = ' . $key_name . ' $keyValue='.$keyValue.' , $values = <pre>' . var_export( $values , true ) . '</pre>' ; exit(0);
   if(isset($dataDefJsonParams['key']) && checkKeyExist($keyValue,$values)){
//    echo __FILE__ . ' ' . __LINE__ . ' $key_name = ' . $key_name . ' $keyValue='.$keyValue.' , $values = <pre>' . var_export( $values , true ) . '</pre>' ; exit(0);
    $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the key already exists_269_89');
   }else{
//    echo __FILE__ . ' ' . __LINE__ . ' $key_name = ' . $key_name . ' $keyValue='.$keyValue.' , $values = <pre>' . var_export( $values , true ) . '</pre>   addslashes(json_encode($values)) = <pre>' . json_encode($values,JSON_FORCE_OBJECT)  . '</pre>' ; exit(0);
    $req6="
     INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__paramvalues` SET
       `fld_id_parname_parvals`      = ".$_REQUEST['id']."
     , `fld_json_parvals`     = '".addslashes(json_encode($values,JSON_FORCE_OBJECT))   . "'
     , `fld_tsupd_parvals`    = '".$GLOBALS['glob_setdate']         . "'
     , `fld_tscrt_parvals`    = '".$GLOBALS['glob_setdate']         . "'
    " ;
    $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
     $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 2 );
    }else{
     foreach($dataDefJsonParams['fields'] as $k1 => $v1){
      if(isset($v1['languageTranslation']) && true===$v1['languageTranslation']){
       foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang){
        unset($_SESSION[PGMK][NAV][BNF][$v1['name'].'_'.$klang]);       
       }
      }else{
       unset($_SESSION[PGMK][NAV][BNF][$v1['name']]);       
      }
     }
     updateSetOfDependantTables($_REQUEST['id']);
     writeParamFiles($_POST['id']);
     $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('message').' '. __LINE__ .' : ' . txt2('the parameter has been inserted_296_92');
    }
   }
  }
 }
 header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?id='.$_REQUEST['id']);
 exit();
}

$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;

$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_30_18').' <a class="btn btn-sm btn-primary" href="zz_paramkeys.php?m=1">'.txtsys1('back_to_the_list').'</a></h1>';
$o1.=displaySessionMessage1(BNF);

$dataDefJsonParams=json_decode($dataParam['fld_json_parnams'],true);


$o1.='<form method="post" class="form1" action="">';
$o1.=' <input type="hidden" value="'.$dataParam['fld_id_parnams'].'" name="id" id="id" />';
$o1.=' <input type="hidden" value="c" name="action" id="action" />';
if(isset($dataDefJsonParams['key'])){
 $o1.=' <input type="hidden" value="key" name="type" id="type" />'; 
}else{
 $o1.=' <input type="hidden" value="value" name="type" id="type" />';
}
$o1.=' <table class="table table-striped table-bordered table-hover table-sm tableResult1"><tbody>';
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $dataDefJsonParams , true ) . '</pre>' ; exit(0);

foreach($dataDefJsonParams['fields'] as $k1 => $v1){
 if(isset($v1['languageTranslation']) && true===$v1['languageTranslation']){
  $o1.='  <tr>';
  $o1.='   <th rowspan="'.(sizeof($GLOBALS['glob__availableLanguages'])).'">';
  $o1.='    '.enti1($v1['name']).'';
  $o1.='   </th>';
  $countLang=0;
  foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang){
   $countLang++; 
   if($countLang==1){
    $o1.='   <td>';
    $o1.='   '.$klang.'';
    $o1.='   </td>';
    $o1.='   <td>';
    $value=isset($_SESSION[PGMK][NAV][BNF][$v1['name'].'_'.$klang])?$_SESSION[PGMK][NAV][BNF][$v1['name'].'_'.$klang]:'';
    $o1.='    <input type="text" name="'.$v1['name'].'_'.$klang.'" id="'.$v1['name'].'_'.$klang.'" maxlength="'.$v1['length'].'" value="'.enti1($value).'" style="width:100%;" />';
    $o1.='   </td>';
   }else{
    $o1.='  <tr>';
    $o1.='   <td>';
    $o1.='   '.$klang.'';
    $o1.='   </td>';
    $o1.='   <td>';
    $value=isset($_SESSION[PGMK][NAV][BNF][$v1['name'].'_'.$klang])?$_SESSION[PGMK][NAV][BNF][$v1['name'].'_'.$klang]:'';
    $o1.='    <input type="text" name="'.$v1['name'].'_'.$klang.'" id="'.$v1['name'].'_'.$klang.'" maxlength="'.$v1['length'].'" value="'.enti1($value).'" style="width:100%;" />';
    $o1.='   </td>';
    $o1.='  </tr>';
   }
  }
  
 }else{
  $o1.='  <tr>';
  $o1.='   <th>';
  $o1.='    '.enti1($v1['name']).'';
  $o1.='   </th>';
  $o1.='   <td>';
  $value=isset($_SESSION[PGMK][NAV][BNF][$v1['name']])?$_SESSION[PGMK][NAV][BNF][$v1['name']]:'';
  $o1.='    <input type="text" name="'.$v1['name'].'" id="'.$v1['name'].'" maxlength="'.$v1['length'].'" value="'.enti1($value).'" style="width:100%;" />';
  $o1.='   </td>';
  $o1.='  </tr>';
 }
}
$o1.='  <tr>';
$o1.='   <th>';
$o1.='    badge';
$o1.='   </th>';
$o1.='   <td>';
$value=isset($_SESSION[PGMK][NAV][BNF]['badge'])?$_SESSION[PGMK][NAV][BNF]['badge']:'';
$o1.='    <input type="text" name="badge" id="badge" maxlength="32" value="'.enti1($value).'" style="max-width:34em;" />';
$o1.='   </td>';
$o1.='   <td>';
for($bi=0;$bi<=8;$bi++){
 $o1.='   <span class="badge badge'.$bi.'" style="font-size:0.8em;">badge'.$bi.'</span>'; 
}
$o1.='   </td>';
$o1.='  </tr>';


//$dataDefJsonParams['id']

//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $dataDefJsonParams , true ) . '</pre>' ; exit(0);
$rules=array();
$sql='
 SELECT 
  T0.`fld_id_parrules`       ,T0.`fld_name_parrules`     ,T0.`fld_id_param_parrules` ,T0.`fld_tsupd_parrules`    ,T0.`fld_tscrt_parrules`    ,
  T0.`fld_cntupd_parrules`   
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramrules` T0
 WHERE T0.`fld_id_param_parrules` = '.$dataDefJsonParams['id']. '
';
$req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($row=mysqli_fetch_row($req)){
  $n=array();
  $n['fld_id_parrules']       = $row[0];
  $n['fld_name_parrules']     = $row[1];
  $n['fld_id_param_parrules'] = $row[2];
  $n['fld_tsupd_parrules']    = $row[3];
  $n['fld_tscrt_parrules']    = $row[4];
  $n['fld_cntupd_parrules']   = $row[5];
  $rules[$n['fld_id_parrules']]=$n['fld_name_parrules'];
 }
 mysqli_free_result($req);
}else{
 debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
}
 
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $rules , true ) . '</pre>' ; exit(0); 



$o1.='  <tr>';
$o1.='   <th>';
$o1.='    rules';
$o1.='   </th>';
$o1.='   <td>';
$o1.='   <select id="rule" name="rule">';
$o1.='    <option value="0">[void]</option>';
foreach($rules as $kr => $vr){
 $o1.='    <option value="'.$kr.'">'.$vr.'</option>';
}
$o1.='   </select>';
$o1.='   </td>';
$o1.='  </tr>';



// 


$o1.='  <tr>';
$o1.='   <td colspan="3" style="text-align:center;">';
$o1.='    <button type="submit" class="btn btn-primary">'.txt2('Insert the new parameter_50_46').'</button>';
$o1.='   </td>';
$o1.='  </tr>';
$o1.=' </tbody></table>';
$o1.='</form>';

$hasKey=false;
$listOfKeys=array();

//echo __FILE__ . ' ' . __LINE__ . ' $dataDefJsonParams = <pre>' . var_export( $dataDefJsonParams , true ) . '</pre>' ;

//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $dataDefJsonParams['key'] , true ) . '</pre>' ; 

$tabCurrentValues=array();
$req6='
 SELECT  
  T0.`fld_id_parvals`   , T0.`fld_json_parvals`  
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramvalues` T0 
 WHERE T0.`fld_id_parname_parvals`  = ' . $_REQUEST['id'] . '
';
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $tabCurrentValues[$mpsr6[0]]=array(
   'fld_id_parvals' => $mpsr6[0]  ,
   'values'         => json_decode( $mpsr6[1] , true )
  );
 }
 
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
}

//echo __FILE__ . ' ' . __LINE__ . ' $tabCurrentValues = <pre>' . var_export( $tabCurrentValues , true ) . '</pre>' ; exit(0);



$lsttb2='';
$lsttb2.='<thead class="thead-inverse"><tr>';
$lsttb2.='<th>id</th>';
$lsttb2.='<th>key</th>';
$lsttb2.='<th>data</th>';
$lsttb2.='</tr></thead>';
$lsttb2.='<tbody>';
$numInput=0;
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $tabCurrentValues , true ) . '</pre>' ; exit(0);
foreach($tabCurrentValues as $k0 => $v0){
 $lsttb2.='<tr>';
 $lsttb2.='<td>'.$k0.'</td>';
 $theKey=null;
 // trouver le nom de la clé
 foreach($dataDefJsonParams['fields'] as $kf1 => $vf1){
  if($vf1['name'] == $dataDefJsonParams['key'] ){
   foreach($v0['values'] as $kvv1 => $vvv1){
    foreach($vvv1 as $kvv2 => $vvv2){
     if($kvv2==$vf1['name']){
      $lsttb2.='<td>'.$vvv2;
      $lsttb2.=' <form method="post" style="display:inline-block;">';
      $lsttb2.='  <input type="hidden" value="del" name="action" />';
      $lsttb2.='  <input type="hidden" value="'.$v0['fld_id_parvals'].'" name="id_param_value" />';
      $lsttb2.='  <input type="hidden" value="'.$vvv2.'" name="key"  />';
      $lsttb2.='  <input type="hidden" value="'.$dataParam['fld_id_parnams'].'" name="id"  />';
      $lsttb2.='  <button type="submit" value="delete" name="but_delete" title="'.txtsys1('delete_button').'" >&#10008;</button>';       
      $lsttb2.=' </form>';
      $lsttb2.='</td>';
      $theKey=$vvv2;
     }
    }
   }
  }
 }
 $lsttb3='<table border="1">';
 $lsttb3.='<thead class="thead-inverse"><th>name</th><th>value</th></thead><tbody>';
 foreach($dataDefJsonParams['fields'] as $kf1 => $vf1){
  if($vf1['name'] != $dataDefJsonParams['key'] ){
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $vf1 , true ) . '</pre>' ; exit(0);
   $lsttb3.='<tr>';
   $lsttb3.='<td>'.$vf1['name'].'</td>';
   $lsttb3.='<td>';
   
   if(isset($vf1['languageTranslation']) && $vf1['languageTranslation']==true){
    $countLang=0;
    foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang){
     $countLang++;
     $lsttb3.='<span style="font-family:monospace;">'.$klang.' </span>';
     $value=isset($v0['values'][$theKey][$vf1['name']][$klang])?$v0['values'][$theKey][$vf1['name']][$klang]:'';
     $numInput++;
     $lsttb3.='<input type="text" value="' . enti1($value) .'" name="value_'.$numInput.'"  id="value0_update_'.$numInput.'" />';
     $lsttb3.='<button value="update" name="but_update0_'.$numInput.'" id="but_update0_'.$numInput.'" title="'.txtsys1('edit_button').'"';
     $lsttb3.=' onclick="updateParam1(\'but_update0_'.$numInput.'\',\'value0_update_'.$numInput.'\')"';
     $lsttb3.=' data-paramid="'.$_REQUEST['id'].'"';
     $lsttb3.=' data-name="'.$vf1['name'].'"';
     $lsttb3.=' data-lang="'.$klang.'"';
     $lsttb3.=' data-id="'.$k0.'"';
     $lsttb3.=' data-key="'.$theKey.'"';
     $lsttb3.='>&#9998;</button>';
     $lsttb3.='<br />';
    }
   }else{
    $lsttb3.='<span style="font-family:monospace;">&nbsp;&nbsp;&nbsp;</span>';
    $value=isset($v0['values'][$theKey][$vf1['name']])?$v0['values'][$theKey][$vf1['name']]:'';
    $numInput++;
    $lsttb3.='<input type="text" value="' . enti1($value) .'" name="value_'.$numInput.'"  id="value1_update_'.$numInput.'" />';
    $lsttb3.='<button value="update" name="but_update1_'.$numInput.'" id="but_update1_'.$numInput.'" title="'.txtsys1('edit_button').'"';
    $lsttb3.=' onclick="updateParam1(\'but_update1_'.$numInput.'\',\'value1_update_'.$numInput.'\')"';
    $lsttb3.=' data-paramid="'.$_REQUEST['id'].'"';
    $lsttb3.=' data-name="'.$vf1['name'].'"';
    $lsttb3.=' data-lang=""';
    $lsttb3.=' data-id="'.$k0.'"';
    $lsttb3.=' data-key="'.$theKey.'"';
    $lsttb3.='>&#9998;</button>';
    $lsttb3.='</td>';
   }
   $lsttb3.='</td>';
   $lsttb3.='</tr>';
  }
 }
 $lsttb3.='<tr>';
 $lsttb3.='<td>badge</td>';
 $lsttb3.='<td>';
 $lsttb3.='<span style="font-family:monospace;">&nbsp;&nbsp;&nbsp;</span>';
 $value=isset($v0['values'][$theKey]['badge'])?$v0['values'][$theKey]['badge']:'';
 $numInput++;
 $lsttb3.='<input type="text" value="' . enti1($value) .'" name="value_'.$numInput.'"  id="value2_update_'.$numInput.'" />';
 $lsttb3.='<button value="update" name="but_update2_'.$numInput.'" id="but_update2_'.$numInput.'" title="'.txtsys1('edit_button').'"';
 $lsttb3.=' onclick="updateParam1(\'but_update2_'.$numInput.'\',\'value2_update_'.$numInput.'\')"';
 $lsttb3.=' data-paramid="'.$_REQUEST['id'].'"';
 $lsttb3.=' data-name="badge"';
 $lsttb3.=' data-lang=""';
 $lsttb3.=' data-id="'.$k0.'"';
 $lsttb3.=' data-key="'.$theKey.'"';
 $lsttb3.='>&#9998;</button>';
 $lsttb3.='</td>';
 $lsttb3.='</tr>';
 
 $lsttb3.='<tr>';
 $lsttb3.='<td>rule</td>';
 $lsttb3.='<td>';
 $lsttb3.='   <select id="value3_update_'.$numInput.'" name="value3_update_'.$numInput.'">';
 $lsttb3.='    <option value="0">[void]</option>';
 $value=isset($v0['values'][$theKey]['rule'])?$v0['values'][$theKey]['rule']:'0';
 
 foreach($rules as $kr => $vr){
  $lsttb3.='    <option value="'.$kr.'" '.($value==$kr?'selected="selected"':'').'>'.$vr.'</option>';
 }
 $lsttb3.='   </select>';
 $lsttb3.='<button value="update" name="but_update3_'.$numInput.'" id="but_update3_'.$numInput.'" title="'.txtsys1('edit_button').'"';
 $lsttb3.=' onclick="updateParam1(\'but_update3_'.$numInput.'\',\'value3_update_'.$numInput.'\')"';
 $lsttb3.=' data-paramid="'.$_REQUEST['id'].'"';
 $lsttb3.=' data-name="rule"';
 $lsttb3.=' data-lang=""';
 $lsttb3.=' data-id="'.$k0.'"';
 $lsttb3.=' data-key="'.$theKey.'"';
 $lsttb3.='>&#9998;</button>';
 
 $lsttb3.='</td>';
 
 
 $lsttb3.='</tr>';
 
 
 
 
 
 $lsttb3.='</tbody></table>';
 $lsttb2.='<td>'.$lsttb3.'</td>';
 $lsttb2.='<tr>';

/* 
*/ 
 
 
}
$lsttb2.='</tbody>';
$o1.='<table class="table table-striped table-bordered table-hover table-sm tableResult1">'.CRLF.$lsttb2.'</table>'.CRLF;


if(isset($dataDefJsonParams['key'])){
 $hasKey=true; 
 $listOfKeys=array($dataDefJsonParams['key']);
}
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listOfKeys , true ) . '</pre>' ; exit(0);

$tableauTriSansLang=array();
$tableauTriAvecLang=array();

$req6='
 SELECT  SQL_CALC_FOUND_ROWS
  T0.`fld_id_parvals`   , T0.`fld_json_parvals`  
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramvalues` T0 
 WHERE T0.`fld_id_parname_parvals`  = ' . $_REQUEST['id'] . '
';
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 $reqCount6='SELECT FOUND_ROWS();';
 $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $mpsrcount6=mysqli_fetch_row($rescount6);
  $__count=$mpsrcount6[0];
 }
 if($__count==0){
  $o1.='<p>'.txt2('no_record_founded_549_19').'</p>'.CRLF;
 }else{
  while($mpsr6=mysqli_fetch_row($result6)){
   $values=json_decode( $mpsr6[1] , true );
//   echo __FILE__ . ' ' . __LINE__ . ' $values = <pre>' . var_export( $values , true ) . '</pre>' ; 
   foreach($values as $k1 => $v1){
    foreach($v1 as $k2 => $v2){
    
     if(in_array($k2,$listOfKeys)){
     }else{
      if(is_array($v2)){ // multilangue
       $countLang=0;
       foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang){
        $countLang++;
        $value=isset($v2[$klang])?enti1($v2[$klang]):'';
        if($value!=''){
         foreach( $dataDefJsonParams['fields'] as $kparam => $vparam){
          if($vparam['name']==$k2){
//            $tableauTriAvecLang[$klang][$k2][]=array( '__data' => $value , 'id__param' => $mpsr6[0]  );
           $tableauTriAvecLang[$klang][]=array( '__data' => $value , 'id__param' => $mpsr6[0]  );
          }
         }
        }
       }
      }else{
       if($v2!=''){
        foreach( $dataDefJsonParams['fields'] as $kparam => $vparam){
         if($vparam['name']==$k2){
          $tableauTriSansLang['sort__p__'.$mpsr6[0]]=$v2;
         }
        }
       }
      }
     }
    }
   }
  }
  mysqli_free_result($result6);
 } 
 
// echo __FILE__ . ' ' . __LINE__ . ' tableauTriAvecLang = <pre>' . var_export( $tableauTriAvecLang , true ) . '</pre>' ; 
// echo __FILE__ . ' ' . __LINE__ . ' tableauTriSansLang = <pre>' . var_export( $tableauTriSansLang , true ) . '</pre>' ; exit(0); 
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $dataParam , true ) . '</pre>' ; exit(0);
 if(sizeof($tableauTriSansLang)>0 || sizeof($tableauTriAvecLang)>0 ){
  $o1.=CRLF.'<script type="text/javascript" src="js/hdtree.js"></script>'.CRLF;
 }
 if(sizeof($tableauTriAvecLang)>0){
  $ordres=json_decode($dataParam['fld_order_parnams'],true);
//  echo __FILE__ . ' ' . __LINE__ . ' $tableauTriAvecLang = <pre>' . var_export( $tableauTriAvecLang , true ) . '</pre>' ;
  foreach($tableauTriAvecLang as $laLang => $v1){
   $v2=array();
   if(isset($ordres[$laLang])){
    $newTab=array();
    $tabForSort1=array();
    foreach($v1 as $k2 => $vaa){
     $ktemp=$vaa['id__param']; // (int)str_replace('sort__p__','',$k2);
     if(in_array($ktemp,$ordres[$laLang])){
      $order = array_search($ktemp, $ordres[$laLang]);
      $newTab[$k2]['value']=$v1[$k2];
      $newTab[$k2]['order']=$order;
     }else{
      $newTab[$k2]['value']=$v1[$k2];
      $newTab[$k2]['order']=-1;
     }
    }
//    echo __FILE__ . ' ' . __LINE__ . ' $newTab = <pre>' . var_export( $newTab , true ) . '</pre>' ; 
    uasort($newTab, 'sort_param_order');
    foreach($newTab as $k0 => $v0){
     $v2[$k0]=$v0['value'];
    }
   }
//   echo __FILE__ . ' ' . __LINE__ . ' $v2 = <pre>' . var_export( $v2 , true ) . '' ; 
   $tabForSort1=array();
   foreach($v2 as $leNomDuParametre => $v3){
    $tabForSort1[]=array(
     'id'   => $v3['id__param'] ,
     'data' => array(
      'label'  =>  $v3['__data']  ,
     ),
     'parentId' => 0,
     'isOpen'   => 1,
    );
   }
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $tabForSort1 , true ) . '</pre>' ; 
   $o1.='<div style="border:1px #888 solid;">'.CRLF;
   $o1.='<span>'.txt2('tri pour_629_23') . ' "' . $laLang . '"</span>'.CRLF;
   $o1.='<div id="lang_'.$laLang.'_1" data-lang="'.$laLang.'" data-idlist="'.$_GET['id'].'"></div>'.CRLF;
   $o1.='</div>'.CRLF;
   $o1.=CRLF.'<script type="text/javascript">'.CRLF;
   $o1.='var jsonTree1='.json_encode( $tabForSort1 , 0 ).';';
   $o1.='// these are the parameters you can tweek. add some if you wish ...'.CRLF;
   $o1.='var param_'.$laLang.'_1={'.CRLF;
   $o1.=' sortOnly            : true                       ,'.CRLF;
   $o1.=' deleteFunctionName  : \'\'   , // delete function name , \'\' if no delete'.CRLF;
   $o1.=' '.CRLF;
   $o1.=' design              : {'.CRLF;
   $o1.=' '.CRLF;
   $o1.='  buttonsBorderWidthInPx      : parseInt(\'1px\',10),   // default : 1px'.CRLF;
   $o1.='  elementHeightInPx           : parseInt(\'30px\',10),  // default and minimum advise : 40px'.CRLF;
   $o1.='  elementBorderHeightInPx     : parseInt(\'1px\',10),   // default : 1px'.CRLF;
   $o1.=' '.CRLF;
   $o1.='  branchesLeftOffsetInPixels  : parseInt(\'12px\',10),  // default : 12px'.CRLF;
   $o1.='  '.CRLF;
   $o1.='  intervalHeightInPixels      : parseInt(\'10px\',10),  // default : 10px'.CRLF;
   $o1.='  intervalBorderNameStyle     : String(\'solid\'),      // default : solid'.CRLF;
   $o1.='  intervalBorderHeight        : parseInt(\'1px\',10),   // default : 1px // should be 0 or 1 px but you can put nnnpx if you want !'.CRLF;
   $o1.='  intervalBorderColor         : String(\'#eee\'),       // default : #eee'.CRLF;
   $o1.=' }'.CRLF;
   $o1.='}'.CRLF;
   $o1.='// then call the building of the tree with '.CRLF;
   $o1.='var oMyTree_'.$laLang.'_1=new cMyTree1('.CRLF;
   $o1.=' \'oMyTree_'.$laLang.'_1\',  // this object name'.CRLF;
   $o1.=' \'lang_'.$laLang.'_1\', // the id of the html < div > you want to fill'.CRLF;
   $o1.=' jsonTree1,   // the data'.CRLF;
   $o1.=' param_'.$laLang.'_1,      // the parameters'.CRLF;
   $o1.=' onSortParamWithLang2'.CRLF;
   $o1.=');'.CRLF;
   $o1.='</script>'.CRLF;   
  }
 }
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $tableauTriSansLang , true ) . '</pre>' ; exit(0);
 
 if(sizeof($tableauTriSansLang)>0){
  $ordres=json_decode($dataParam['fld_order_parnams'],true);
  if(isset($ordres)){
   $newTab=array();
   $tabForSort1=array();
   foreach($tableauTriSansLang as $k2 => $v2){
    $ktemp=(int)str_replace('sort__p__','',$k2);
    if(in_array($ktemp,$ordres)){
     $order = array_search($ktemp, $ordres);
     $newTab[$ktemp]['value']=$v2;
     $newTab[$ktemp]['order']=$order;
    }else{
     $newTab[$ktemp]['value']=$v2;
     $newTab[$ktemp]['order']=-1;
    }
   }
   uasort($newTab, 'sort_param_order');
   $newTabTrie=array();
   foreach($newTab as $k0 => $v0){
    $newTabTrie[$k0]=$v0['value'];
   }
   $tableauTriSansLang=$newTabTrie;
  }
   
  foreach($tableauTriSansLang as $k1 => $v1){
   $tabForSort1[]=array(
    'id'   => $k1 ,
    'data' => array(
     'label'  =>  enti1($v1)  ,
    ),
    'parentId' => 0,
    'isOpen'   => 1,
   );
  }
  
  $o1.='<div style="border:1px #888 solid;">'.CRLF;
  $o1.='<div id="lang_1" data-idlist="'.$_GET['id'].'"></div>'.CRLF;
  $o1.='</div>'.CRLF;
  $o1.=CRLF.'<script type="text/javascript">'.CRLF;
  $o1.='var jsonTree1='.json_encode( $tabForSort1 , 0 ).';';
  $o1.='// these are the parameters you can tweek. add some if you wish ...'.CRLF;
  $o1.='var param_1={'.CRLF;
  $o1.=' sortOnly            : true                       ,'.CRLF;
  $o1.=' deleteFunctionName  : \'\'   , // delete function name , \'\' if no delete'.CRLF;
  $o1.=' '.CRLF;
  $o1.=' design              : {'.CRLF;
  $o1.=' '.CRLF;
  $o1.='  buttonsBorderWidthInPx      : parseInt(\'1px\',10),   // default : 1px'.CRLF;
  $o1.='  elementHeightInPx           : parseInt(\'30px\',10),  // default and minimum advise : 40px'.CRLF;
  $o1.='  elementBorderHeightInPx     : parseInt(\'1px\',10),   // default : 1px'.CRLF;
  $o1.=' '.CRLF;
  $o1.='  branchesLeftOffsetInPixels  : parseInt(\'12px\',10),  // default : 12px'.CRLF;
  $o1.='  '.CRLF;
  $o1.='  intervalHeightInPixels      : parseInt(\'10px\',10),  // default : 10px'.CRLF;
  $o1.='  intervalBorderNameStyle     : String(\'solid\'),      // default : solid'.CRLF;
  $o1.='  intervalBorderHeight        : parseInt(\'1px\',10),   // default : 1px // should be 0 or 1 px but you can put nnnpx if you want !'.CRLF;
  $o1.='  intervalBorderColor         : String(\'#eee\'),       // default : #eee'.CRLF;
  $o1.=' }'.CRLF;
  $o1.='}'.CRLF;
  $o1.='// then call the building of the tree with '.CRLF;
  $o1.='var oMyTree_1=new cMyTree1('.CRLF;
  $o1.=' \'oMyTree_1\',  // this object name'.CRLF;
  $o1.=' \'lang_1\', // the id of the html < div > you want to fill'.CRLF;
  $o1.=' jsonTree1,   // the data'.CRLF;
  $o1.=' param_1,      // the parameters'.CRLF;
  $o1.=' onSortParamWithoutLang2'.CRLF;
  $o1.=');'.CRLF;
  $o1.='</script>'.CRLF;   
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
}
function sort_param_order($a,$b){
 if($a['order'] == $b['order']) {
  return 0;
 }
 return ($a['order'] < $b['order']) ? -1 : 1; 
}

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();