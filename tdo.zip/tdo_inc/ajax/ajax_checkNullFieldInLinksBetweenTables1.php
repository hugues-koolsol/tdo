<?php
// do not forget to put this file in the file list !
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
// if($fd=fopen('toto.txt','a')){fwrite($fd,''.date('Y-m-d H:i:s'). ' ' . __LINE__ ."\r\n".'$ret='.var_export($ret,true)."\r\n"); fclose($fd);}
/*
 input:
  dbfield: "last_name"
  funct: "checkNullFieldInLinksBetweenTables1"
  htmlfield: "fld_child_field_pglnks"
  tableId: 29

*/

 openDb2();
 require_once $GLOBALS['glob_incPath1'].'/tables1.php';
 $table=getTdo_tables1($ret['input']['tableId']);
 $out='';
 $req6=' SHOW FULL COLUMNS FROM `'.$table['fld_name_tables'].'` IN `'.$GLOBALS['glob_db'][$table['fld_id_server_tables']]['dbname'].'` ';
 $result6=mysqli_query($GLOBALS['glob_db'][$table['fld_id_server_tables']]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][$table['fld_id_server_tables']]['link'])==0){
  while($mpsr6=mysqli_fetch_array($result6)){
   if($mpsr6[0]==$ret['input']['dbfield']){
    $out=$mpsr6[3]; // null possible 'YES' or 'NO'
   }
  }
 }

 $err=0;
 $ret['status']='OK';
 $ret['data']['nullPossible']=$out;
 $ret['message'][]='hello' . BNF;    
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;   
}