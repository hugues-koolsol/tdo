<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb2();
require_once $GLOBALS['glob_incPath1'].'/grpspgs1.php';

//========================================================================================================================
function trierLesPages($a,$b){
 if($a['order']==$b['order']) return 0;
 if($a['order']<=$b['order']) return -1;
 return 1;
}
//============================================================================================================================================

if(isset($_POST) && sizeof($_POST)>0){
  require_once($GLOBALS['glob_incPath1'].'/grpspgs1.php');
  if(isset($_POST['action']) && $_POST['action']=='updateMenuFlag' ){
   updateMenus();
   updateGrpPgsFiles1();
  }else if(isset($_POST['action']) && $_POST['action']=='updateMenuListForGroup' ){
   updatePagesOfGroups();
   updateMenus();
   updateGrpPgsFiles1();
  }
  header('Location: zz_grpspgs.php');
  exit();
}

//========================================================================================================================
$o1='';
$nbMax=15;
$start=0;
$count=0;
$xpage=0;
if(isset($_GET['xpage'])&&is_numeric($_GET['xpage'])){
 $xpage=$_GET['xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['xpage'])) $xpage=$_SESSION[PGMK][NAV][BNF]['xpage'];
}
//echo __LINE__ ; exit();
$xsrch_idgr1  =saveSessionSearch1( 'xsrch_idgr1'    , BNF );


if($xsrch_idgr1!=''){
 if(!is_numeric($xsrch_idgr1)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=enti1('erreur ' . __LINE__ . ', l\'id doit être numérique.').'<br />';;
 }
}

$autofocus='xsrch_idgr1';


$o1.=htmlHead1(array('nomenu'=>true));

$o1.='<h1>'.txt2('Pages des groupes_243_18').'</h1>';
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_SESSION , true ) . '</pre>' ; exit(0);
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="filterForm">'.CRLF;



$o1.='   <div class="form-group col-auto">'.CRLF;
$o1.='    <label class="col-form-label" for="xsrch_idgr1"   class="">id groupe</label>'.CRLF;
$o1.='    <input class="form-control form-control-sm ';
if($xsrch_idgr1!=''){$o1.='backgroundYellow ';}
$o1.=    '" type="text" name="xsrch_idgr1"    id="xsrch_idgr1"   value="'.enti1($xsrch_idgr1).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_idgr1'?' autofocus="autofocus" ':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;


$o1.=' </form>'.CRLF;

//===================
$start=$xpage*$nbMax;
$_SESSION[PGMK][NAV][BNF]['xpage']=$xpage;
$lst='';

// cas 1 , rien de spécifié
if(($xsrch_idgr1=='' || !is_numeric($xsrch_idgr1))){

 $o1.='<p>'.txt2('Select a group_318_18').'</p>'.CRLF;

  
 $req6='
  SELECT  SQL_CALC_FOUND_ROWS
   T0.`fld_id_groups`   , T0.`fld_name_groups` 
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0 
  WHERE 1=1 
 ';
 if($_SESSION[PGMK]['group']!=1){
  $req6.='
   AND T0.`fld_parent_id_groups` = '.$_SESSION[PGMK]['group'].'
   AND T0.`fld_parent_id_groups` <> T0.`fld_id_groups`
  ' ;
 }
 $req6.='
  ORDER BY T0.`fld_id_groups` ASC 
 ' ;
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $count=$mpsrcount6[0];
 //  echo __LINE__ . '<pre>' . var_export( $mpsrcount6 , true ) . '</pre>' ;
  }
  $lsttbl='';
  if($count==0){
   $lsttbl.='<p>Il n\'y a pas de groupe avec les critères indiqués</p>'.CRLF;
  }else{
   $lsttbl.='<div class="divTextCentered">';
   while($mpsr6=mysqli_fetch_row($result6)){
    $lsttbl.='<a class="btn btn-sm btn-primary" href="zz_grpspgs.php?xsrch_idgr1='.$mpsr6[0].'" class="pageListAuth">'.enti1($mpsr6[1]).' ('.$mpsr6[0].')</a>&nbsp;';
   }
   $lsttbl.='</div>';
  }
  $o1.=$lsttbl;
  mysqli_free_result($result6);
 }else{
  $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));
 }

}else{
 
 if($xsrch_idgr1!='' || is_numeric($xsrch_idgr1)){
  $req7='
   SELECT  SQL_CALC_FOUND_ROWS
    T0.`fld_id_groups`   , T0.`fld_name_groups` 
   FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0 
   WHERE T0.`fld_id_groups`        = '.$xsrch_idgr1.'
  ' ;
  if($_SESSION[PGMK]['group']!=1){
   $req7.='
    AND T0.`fld_parent_id_groups` = '.$_SESSION[PGMK]['group'].'
    AND T0.`fld_parent_id_groups` <> T0.`fld_id_groups`
   ' ;
  }
  $req7.='
   ORDER BY T0.`fld_id_groups` ASC 
  ' ;
  
  $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $reqCount7='SELECT FOUND_ROWS();';
   $rescount7=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount7);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    $mpsrcount7=mysqli_fetch_row($rescount7);
    $count=$mpsrcount7[0];
   }
   $lsttbl='';
   if($count==0){
    $o1.='<p>Il n\'y a pas de groupe avec les critères indiqués</p>'.CRLF;
   }else{
    while($mpsr7=mysqli_fetch_row($result7)){
     $fld_group_id_grpspgs=$mpsr7[0];
    }    
    mysqli_free_result($result7);
    
    require_once($GLOBALS['glob_incPath1'].'/sys/__pageList.php');
    $listeDesPages=array();
    $testLocalAdminPage=false;
    $testUserPage=false;
    if($xsrch_idgr1!=1){
     require_once($GLOBALS['glob_incPath1'].'/groups1.php');
     $dataGroup=getGroup1($xsrch_idgr1);
     if($dataGroup['fld_id_groups']==$dataGroup['fld_parent_id_groups']){
      $testLocalAdminPage=true;
     }else{
      $testUserPage=true;
     }
//     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $dataGroup , true ) . '</pre>' ; exit(0);
    }
    
    
    foreach($GLOBALS['__pageList'] as $k1 => $v1){
     $putPage=true;
     if($v1['fld_isajax_pages']==1){
      if(!is_file($GLOBALS['glob_incPath1'].'/ajax/'.$v1['fld_name_pages'])){
       $putPage=false;
      }
     }else{
      if(!is_file($v1['fld_name_pages'])){
       $putPage=false;
      }
     }
     if($testLocalAdminPage && $v1['fld_localadmin_pages'] != '1'){
      $putPage=false;
     }
     if($testUserPage && $v1['fld_isuser_pages'] != '1'){
      $putPage=false;
     }
     if($putPage==true){
      $listeDesPages['fld_id_pages_'.$v1['fld_id_pages']]=array(
       'fld_id_pages'         => $v1['fld_id_pages'],
       'fld_name_pages'       => $v1['fld_name_pages'],
       'fld_menu_pages'     => $v1['fld_menu_pages'],
       'fld_isajax_pages'     => $v1['fld_isajax_pages'],
       'fld_localadmin_pages' => $v1['fld_localadmin_pages'],
       'fld_isuser_pages'     => $v1['fld_isuser_pages'],
       'fld_isaction_pages'   => $v1['fld_isaction_pages'],
       'isset'                => false,
       'menu'                 => false,
       'order'                => 9999,
      );
     }
    }
    

    $req7='
     SELECT  SQL_CALC_FOUND_ROWS
       T0.`fld_page_id_grpspgs` , T0.`fld_group_id_grpspgs` , T0.`fld_is_menu_grpspgs` , T0.`fld_menu_order_grpspgs`
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` T0 
     WHERE T0.fld_group_id_grpspgs = '.$fld_group_id_grpspgs.'
    ' ;
    $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
     while($mpsr7=mysqli_fetch_row($result7)){
      if(isset($listeDesPages['fld_id_pages_'.$mpsr7[0]])){
       $listeDesPages['fld_id_pages_'.$mpsr7[0]]['isset'] = true;
       $listeDesPages['fld_id_pages_'.$mpsr7[0]]['menu']  = ($mpsr7[2]=='1'?true:false);
       $order=$mpsr7[3];
       if($listeDesPages['fld_id_pages_'.$mpsr7[0]]['menu']===false){
        $order=9999;
       }
       $listeDesPages['fld_id_pages_'.$mpsr7[0]]['order'] = $order;
      }
     }
     
     mysqli_free_result($result7);
    }else{
     $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req7));
    }
    
    if(sizeof($listeDesPages)>0){
     uasort($listeDesPages,'trierLesPages');
    }
    
    $tabForSort1=array();
    foreach( $listeDesPages as $k1 => $v1){
     $label='';
     if(($v1['isset'] && $v1['menu']==true && $v1['order']>=0) ){
//        $o1.=' {id :  2 , data:{label:\'a\'}   , parentId : 0 , isOpen : 1 },'.CRLF;

      
      $label.='<div style="display:inline-block;border:1px #eee solid;">';
//      $label.=txt2('has access_448_93') . ' ' ;
      if($fld_group_id_grpspgs==1 || $v1['fld_id_pages'] == 1 || $v1['fld_id_pages'] == 2 || $v1['fld_id_pages'] == 3){
       $label.='<input type="checkbox" style="display:none;" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" checked="checked" disabled="disabled" />';
       $lsttbl.='<input type="hidden" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']"  />';
      }else{
       if($v1['isset']==false){
        $label.='<input type="checkbox" style="display:none;" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" />';
       }else{
        $label.='<input type="checkbox" style="display:none;" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" checked="checked" />';
       }
      }
      $label.='</div>';
      
      
      
      $label.='<div style="display:inline-block;border:1px #eee solid;">';
//      $label.='&nbsp; '.txt2('In menu_467_23') . ' ';
      if($v1['menu']==false){
       $label.='<input type="checkbox" style="" value="'.$v1['fld_id_pages'].'" name="menu['.$v1['fld_id_pages'].']" />';
      }else{
       $label.='<input type="checkbox" style="" value="'.$v1['fld_id_pages'].'" name="menu['.$v1['fld_id_pages'].']" checked="checked" />';
      }
      $label.='</div>';

      $label.='<div style="display:inline-block;border:1px #eee solid;">&nbsp;';
      $label.=''.txt3('menu__'.$v1['fld_name_pages']).'  ('.enti1($v1['fld_id_pages']).')'; // '.enti1($v1['fld_name_pages']).'
      $label.='</div>';

      $tabForSort1[]=array(
       'id'   => $v1['fld_id_pages'] ,
       'data' => array(
        'label'  =>  $label  ,
       ),
       'parentId' => 0,
       'isOpen'   => 1,
      );
      
      
     }
    }
    require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
    
    foreach( $listeDesPages as $k1 => $v1){
     if(!($v1['isset'] && $v1['menu']==true && $v1['order']>=0) ){
      
      $lsttbl.='<tr>';
      
      
      $lsttbl.='<td class="actionColumn" data-label="'.txtsys1('column_action').'">';
      if($fld_group_id_grpspgs==1 || $v1['fld_id_pages'] == 1 || $v1['fld_id_pages'] == 2 || $v1['fld_id_pages'] == 3){
       $lsttbl.='<input type="checkbox" style="" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" checked="checked" disabled="disabled" />';
       $lsttbl.='<input type="hidden" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']"  />';
      }else{
       if($v1['isset']==false){
        $lsttbl.='<input type="checkbox" style="" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" />';
       }else{
        $lsttbl.='<input type="checkbox" style="" value="'.$v1['fld_id_pages'].'" name="page['.$v1['fld_id_pages'].']" checked="checked" />';
       }
       
      }
      $lsttbl.='</td>';
      

      $lsttbl.='<td data-label="'.txt2('page (id)_433_66').'">';
      $lsttbl.=''.enti1($v1['fld_name_pages']).' ('.$v1['fld_id_pages'].') '; 
      $lsttbl.='</td>';
/*
      $lsttbl.='<td data-label="'.txt2('actif_433_96').'">';
      $lsttbl.=displayParam1('yorno',$v1['fld_menu_pages']);
      $lsttbl.='</td>';
*/
      $lsttbl.='<td data-label="'.txt2('fld_isajax_pages_530_143').'" style="text-align:center;">';
       $lsttbl.=displayParam1('yorno',$v1['fld_isajax_pages']);
      $lsttbl.='</td>';
      
      $lsttbl.='<td data-label="'.txt2('menu_433_122').'">'; // menu
      if($v1['fld_menu_pages']==1){
       if($v1['menu']==false){
        $lsttbl.='<input type="checkbox" style="" value="'.$v1['fld_id_pages'].'" name="menu['.$v1['fld_id_pages'].']" />';
       }else{
        $lsttbl.='<input type="checkbox" style="" value="'.$v1['fld_id_pages'].'" name="menu['.$v1['fld_id_pages'].']" checked="checked" />';
       }
      }
      $lsttbl.='</td>';
      
      $lsttbl.='<td data-label="'.txt2('fld_localadmin_pages_510_40').'">';
       $lsttbl.=displayParam1('yorno',$v1['fld_localadmin_pages']);
      $lsttbl.='</td>';
      
      $lsttbl.='<td data-label="'.txt2('fld_isuser_pages_514_40').'">';
       $lsttbl.=displayParam1('yorno',$v1['fld_isuser_pages']);
      $lsttbl.='</td>';

      
      
      $lsttbl.='</tr>';
     }
    }
     
    $o1.='<form method="post">'.CRLF;
    if(sizeof($tabForSort1)>0){
     $o1.='<input type="hidden" id="sortListGroupId" value="' . $fld_group_id_grpspgs . '" />';
     $o1.='<div id="menu_pages1"></div>'.CRLF;
     $o1.='<script type="text/javascript" src="js/hdtree.js"></script>'.CRLF;
     $o1.='<script type="text/javascript">'.CRLF;
     
     $o1.='var jsonTree1='.json_encode( $tabForSort1 , 0 ).';';
     $o1.='// these are the parameters you can tweek. add some if you wish ...'.CRLF;
     $o1.='var param1={'.CRLF;
     $o1.=' sortOnly            : true                       ,'.CRLF;
     $o1.=' deleteFunctionName  : \'\'   , // delete function name , \'\' if no delete'.CRLF;
     $o1.=' noIdPrintAfterLabel : true   ,'.CRLF;
     $o1.=' '.CRLF;
     $o1.=' design              : {'.CRLF;
     $o1.=' '.CRLF;
     $o1.='  buttonsBorderWidthInPx      : parseInt(\'1px\',10),   // default : 1px'.CRLF;
     $o1.='  elementHeightInPx           : parseInt(\'30px\',10),  // default and minimum advise : 40px'.CRLF;
     $o1.='  elementBorderHeightInPx     : parseInt(\'1px\',10),   // default : 1px'.CRLF;
     $o1.=' '.CRLF;
     $o1.='  branchesLeftOffsetInPixels  : parseInt(\'12px\',10),  // default : 12px'.CRLF;
     $o1.='  '.CRLF;
     $o1.='  intervalHeightInPixels      : parseInt(\'10px\',10),  // default : 10px'.CRLF;
     $o1.='  intervalBorderNameStyle     : String(\'solid\'),      // default : solid'.CRLF;
     $o1.='  intervalBorderHeight        : parseInt(\'1px\',10),   // default : 1px // should be 0 or 1 px but you can put nnnpx if you want !'.CRLF;
     $o1.='  intervalBorderColor         : String(\'#eee\'),       // default : #eee'.CRLF;
     $o1.=' }'.CRLF;
     $o1.='}'.CRLF;
     $o1.='// then call the building of the tree with '.CRLF;
     $o1.='var oMyTree1=new cMyTree1('.CRLF;
     $o1.=' \'oMyTree1\',  // this object name'.CRLF;
     $o1.=' \'menu_pages1\', // the id of the html < div > you want to fill'.CRLF;
     $o1.=' jsonTree1,   // the data'.CRLF;
     $o1.=' param1,      // the parameters'.CRLF;
     $o1.=' onSortPagesOfGroups2'.CRLF;
     $o1.=');'.CRLF;
     $o1.='</script>'.CRLF;;
     
    }
    
    if($lsttbl!=''){
     
   $css='<style type="text/css">
   @media screen and (max-width: 550px){/* todo adjust size */
     table.tableResult1 {
       border: 0;
       width:100%;
     }
     table.tableResult1 thead {
       border: none;
       clip: rect(0 0 0 0);
       height: 1px;
       margin: -1px;
       overflow: hidden;
       padding: 0;
       position: absolute;
       width: 1px;
     }
     table.tableResult1 tr {
       border-bottom: 3px solid #eee;
       display: block;
       margin-bottom: 2.001em;
     }
     table.tableResult1 td {
       border-bottom: 1px solid #eee;
       display: block;
       text-align: right!important;
       min-height:30px;
     }
     table.tableResult1 td:before {
       content: attr(data-label);
       float: left;
       font-weight:bold;
     }
     table.tableResult1 td:last-child {
       border-bottom: 0;
     }
     table.tableResult1 td.actionColumn div{
      display:contents;
     }
     table.tableResult1 td.actionColumn{
      height:auto;
     }
     .tableResult1 td {
      height:auto;
     }
   }
   </style>';
     $o1.=$css;
     
     
     $lsttbl1='<thead><tr>';
     $lsttbl1.='<th>'.txt2('action_433_39').'</th>';
     $lsttbl1.='<th>'.txt2('page (id)_433_66').'</th>';
//     $lsttbl1.='<th>'.txt2('actif_433_96').'</th>';
     $lsttbl1.='<th>'.txt2('fld_isajax_pages_530_143').'</th>';
     $lsttbl1.='<th>'.txt2('menu_433_122').'</th>';
     $lsttbl1.='<th>'.txt2('fld_localadmin_pages_510_40').'</th>';
     $lsttbl1.='<th>'.txt2('fld_isuser_pages_514_40').'</th>';
     $lsttbl1.='</tr></thead>'.$lsttbl;
     $o1.=' <table class="tableResult1" >'.CRLF;
     $o1.=''.$lsttbl1.'<tbody>'.CRLF;
     if($fld_group_id_grpspgs!=1){
      $o1.='  <tr>'.CRLF;
      $o1.='   <td colspan="4">'.CRLF;
      $o1.='    <input type="hidden" name="fld_group_id_grpspgs" value="'.$fld_group_id_grpspgs.'" />'.CRLF;
      $o1.='    <button type="input" name="action" value="updateMenuListForGroup">'.txt2('Mettre à jour les pages du groupe_502_91').'</button>'.CRLF;
      $o1.='   </td>'.CRLF;
      $o1.='   <td colspan="2">'.CRLF;
      $o1.='    <input type="hidden" name="fld_group_id_grpspgs" value="'.$fld_group_id_grpspgs.'" />'.CRLF;
      $o1.='    <button type="input" name="action" value="updateMenuFlag">'.txt2('update the order_502_83').'</button>'.CRLF;
      $o1.='   </td>'.CRLF;
      $o1.='  </tr>'.CRLF;
     }else{
      $o1.='  <tr>'.CRLF;
      $o1.='   <td colspan="3">'.CRLF;
      $o1.='   </td>'.CRLF;
      $o1.='   <td>'.CRLF;
      $o1.='    <input type="hidden" name="fld_group_id_grpspgs" value="'.$fld_group_id_grpspgs.'" />'.CRLF;
      $o1.='    <button type="input" name="action" value="updateMenuFlag">'.txt2('update the order_502_83').'</button>'.CRLF;
      $o1.='   </td>'.CRLF;
      $o1.='  </tr>'.CRLF;       
     }
     $o1.='</tbody></table>'.CRLF;
     $o1.='</form>'.CRLF;
    }
   }
  }else{
   $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req7));
  }
 }
}

$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();