<?php
//========================================================================================================================
function ordonnerPagesDeGroupes($a,$b){
 if($a['o']==$b['o']) return 0;
 if($a['o']<=$b['o']) return -1;
 return 1;
}
//========================================================================================================================
function updateGrpPgsFiles1(){
 if(!isset($GLOBALS['__pageList'])){
  include($GLOBALS['glob_incPath1'].'/__pageList.php');
 }
 $req6='SELECT T0.`fld_id_groups` , `fld_name_groups` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0 ORDER BY `fld_id_groups` ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $listePages1=array(
    'index.php' => array (
      'm' => 1,      // menu
      'o' => 996,    // order
      'aj' => 0,     // ajax
      'id' => 1,     // id
      'remote' => 1, // remote
    ),
    'login.php' => array (
      'm' => 1,
      'o' => 997,
      'aj' => 0,
      'id' => 2,
      'remote' => 1,
    ),
    'logout.php' => array (
      'm' => 0,
      'o' => 998,
      'aj' => 0,
      'id' => 3,
      'remote' => 1,
    ),
   );
   if($mpsr6[0]!='2'){
    $listePages1['profile.php']=array(
      'm' => 1,
      'o' => 999,
      'aj' => 0,
      'id' => 41,
      'remote' => 1,
    );
   }
   $req7='
    SELECT T0.`fld_group_id_grpspgs`     , T0.`fld_page_id_grpspgs` , T0.`fld_is_menu_grpspgs` , T0.`fld_menu_order_grpspgs`  
    FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` T0 
    WHERE T0.`fld_group_id_grpspgs` = '.$mpsr6[0].'
      AND T0.`fld_group_id_grpspgs` <> 2
    ORDER BY T0.`fld_menu_order_grpspgs` ASC      
   ';
   $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    while($mpsr7=mysqli_fetch_row($result7)){
     $thePage = array();
     foreach($GLOBALS['__pageList'] as $k1 => $v1){
      if($v1['fld_id_pages']==$mpsr7[1]){
       $thePage=$v1;
      }
     }

     if(count($thePage)>0){
      if($mpsr7[1]==1 && $thePage['fld_name_pages']=='profile.php' ){
       echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listePages1 , true ) . '</pre>' ; exit(0);
      }
      if(isset($listePages1[$thePage['fld_name_pages']])){
       $listePages1[$thePage['fld_name_pages']]['m']=(int)$mpsr7[2];
       $listePages1[$thePage['fld_name_pages']]['o']=(int)$mpsr7[3];
       $listePages1[$thePage['fld_name_pages']]['aj']=(int)$thePage['fld_isajax_pages'];
      }else{
       $listePages1[$thePage['fld_name_pages']]=array(
        'm'        => (int)$mpsr7[2] , // menu
        'o'        => (int)$mpsr7[3] , // order
        'aj'       => (int)$thePage['fld_isajax_pages'] ,
        'id'       => (int)$mpsr7[1] , // id
        'remote'   => (int)$thePage['fld_isremote_pages']  ,
       );
      }
     }
    }
    mysqli_free_result($result7);
   }else{
    debugSql2(array('sqler' => ' in getGroup1 ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req7 , 'file' => __FILE__ , 'line' => __LINE__ ));
   }
   
   if(count($listePages1)>0){
    uasort($listePages1 , 'ordonnerPagesDeGroupes');
    if(!is_dir($GLOBALS['glob_noVcPath1'].'/pages_of_groups')){
     if(!mkdir($GLOBALS['glob_noVcPath1'].'/pages_of_groups',0777,true)){
      debugSql2(array('message' => ' in ' . __FUNCTION__ . ' cannot create directory "'.$GLOBALS['glob_noVcPath1'].'/pages_of_groups"' , 'file' => __FILE__ , 'line' => __LINE__ ));
     }
    }
    
    if($fd=fopen($GLOBALS['glob_noVcPath1'].'/pages_of_groups/pages_of_group_'.$mpsr6[0].'.php' , 'w')){
     fwrite($fd,'<?'.'php'.CRLF.'// group '.$mpsr6[0].' : '.$mpsr6[1].',m:menu,o:order,aj:ajax'.CRLF.'$GLOBALS[\'glob_grpspgs\']='.var_export($listePages1,true).';');
     fclose($fd);
    }else{
      debugSql2(array('message' => ' in ' . __FUNCTION__ . ' cannot create file "'.$GLOBALS['glob_noVcPath1'].'/pages_of_groups/pages_of_group_'.$mpsr6[0].'"' , 'file' => __FILE__ , 'line' => __LINE__ ));     
    }
   }
  }
  mysqli_free_result($result6);
  
  buildGroupTree(1);
 }else{
  debugSql2(array('sqler' => ' in ' . __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6 , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
}
//============================================================================================================================================
function buildGroupTree($idParentGroup){
 if($idParentGroup==1){
  $groupList='';
  $req6='
   SELECT
    T0.`fld_id_groups` , `fld_name_groups` , `fld_parent_id_groups`
   FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0 
   ORDER BY `fld_id_groups`
  ';
  $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($mpsr6=mysqli_fetch_row($result6)){
    $groupList.=','.$mpsr6[0];
   }
   mysqli_free_result($result6);
  }
  if($fd=fopen($GLOBALS['glob_noVcPath1'].'/pages_of_groups/groups_of_group_'.$idParentGroup.'.php' , 'w')){
   fwrite($fd,'<?'.'php'.CRLF.'// group '.$mpsr6[0].' : '.$mpsr6[1].''.CRLF.'$GLOBALS[\'glob_treegrp\']='.var_export(substr($groupList,1),true).';');
   fclose($fd);
  }else{
   debugSql2(array('message' => ' in ' . __FUNCTION__ . ' cannot create file "'.$GLOBALS['glob_noVcPath1'].'/pages_of_groups/pages_of_group_'.$mpsr6[0].'"' , 'file' => __FILE__ , 'line' => __LINE__ ));     
  }
 }
 $arr=array();
 $req6='
  SELECT
   T0.`fld_root_group_id_groups` , T0.`fld_id_groups` , T0.`fld_name_groups` , T0.`fld_isactive_groups` , T0.`fld_role_groups`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0 
  WHERE `fld_id_groups`        NOT IN ( 1 , 2 )
  ORDER BY T0.`fld_root_group_id_groups` , T0.`fld_id_groups`
 ';
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . $req6  . '</pre>' ; exit(0);
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
//   $tree[$mpsr6[0]][]=array('fld_id_groups'=>$mpsr6[1],'fld_name_groups'=>$mpsr6[2],'fld_isactive_groups'=>$mpsr6[3],'fld_role_groups'=>$mpsr6[4],'children'=>array());
   $arr[]=array('id'=>$mpsr6[1],'parentid'=>$mpsr6[0],'name'=>$mpsr6[2],'dep'=>'');
   $arr2['g'.$mpsr6[0]]['g'.$mpsr6[1]]='';
  }
  mysqli_free_result($result6);
 }
 $arr3=array();
 foreach($arr2 as $k1=>$v1){
  $arr3[$k1]='';
  foreach($v1 as $k2=>$v2){
   $arr3[$k2]='';
  }
 }
 $new=array();
 foreach($arr as $a){
  $new[$a['parentid']][] = $a;
 }
 $tree=createTree($new, array($arr[0]));
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $tree , true ) . '</pre><pre>' . var_export( $arr3 , true ) . '</pre>' ; exit(0);
 
 myDep($tree,$arr3);
 foreach($arr3 as $k1=>$v1){
  $arr3[$k1]=substr($k1,1).$v1; // le groupe n contient le groupe n
 }
 
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $tree , true ) . '</pre><pre>' . var_export( $arr3 , true ) . '</pre>' ; exit(0);
 foreach($arr3 as $k1=>$v1){
  if($k1!='g1'&&$v1!=''){
   if($fd=fopen($GLOBALS['glob_noVcPath1'].'/pages_of_groups/groups_of_group_'.substr($k1,1).'.php' , 'w')){
    fwrite($fd,'<?'.'php'.CRLF.'// group '.$mpsr6[0].' : '.$mpsr6[1].''.CRLF.'$GLOBALS[\'glob_treegrp\']='.var_export($v1,true).';');
    fclose($fd);
   }else{
    debugSql2(array('message' => ' in ' . __FUNCTION__ . ' cannot create file "'.$GLOBALS['glob_noVcPath1'].'/pages_of_groups/pages_of_group_'.$mpsr6[0].'"' , 'file' => __FILE__ , 'line' => __LINE__ ));     
   }
  }
 }
}
//============================================================================================================================================
function myDep($tree,&$arr3){
 $s='';
 foreach($tree as $k1=>$v1){
  $arr3['g'.$v1['parentid']].=','.$v1['id'];
  $s.=','.$v1['id'];
  if(isset($v1['children'])){
   $t=myDep($v1['children'],$arr3);
   $arr3['g'.$v1['parentid']].=$t;
   $s.=$t;
  }
 }
 return $s;
}

//============================================================================================================================================
function createTree(&$list, $parent){
 $tree = array();
 foreach ($parent as $k=>$l){
  if(isset($list[$l['id']])){
   $l['children']=createTree($list, $list[$l['id']]);
  }
  $tree[]=$l;
 } 
 return $tree;
} 

//============================================================================================================================================
function updatePagesOfGroups(){
 $updated=false;
 include($GLOBALS['glob_incPath1'].'/__pageList.php');
 $listeDesPages1=array();
 foreach($GLOBALS['__pageList'] as $k1 => $v1){
  $listeDesPages1['fld_id_pages_'.$v1['fld_id_pages']]=array(
   'fld_id_pages'         => $v1['fld_id_pages'],
   'fld_name_pages'       => $v1['fld_name_pages'],
   'fld_menu_pages'       => $v1['fld_menu_pages'],
   'fld_isajax_pages'     => $v1['fld_isajax_pages'],
   'fld_localadmin_pages' => $v1['fld_localadmin_pages'],
   'fld_isuser_pages'     => $v1['fld_isuser_pages'],
   'fld_isaction_pages'   => $v1['fld_isaction_pages'],
   'isset'                => false,
  );
 }
 if(isset($_POST['fld_group_id_grpspgs'])){
  $req7='
   SELECT  SQL_CALC_FOUND_ROWS
     T0.`fld_page_id_grpspgs` , T0.`fld_group_id_grpspgs`
   FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` T0 
   WHERE T0.fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].'
  ' ;
  $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($mpsr7=mysqli_fetch_row($result7)){
    $listeDesPages1['fld_id_pages_'.$mpsr7[0]]['isset'] = true;
   }
   
   mysqli_free_result($result7);
   
   foreach( $listeDesPages1 as $k1 => $v1){
    if($v1['isset']===false && isset($_POST['page'][$v1['fld_id_pages']])){
     $req8='INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET `fld_group_id_grpspgs` = '.$_POST['fld_group_id_grpspgs'].' , `fld_page_id_grpspgs` = '.$v1['fld_id_pages'].'' ;
     $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
     if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
      $updated=true;
     }else{
      $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req='.$req7.' ';
     }
    }else if($v1['isset']==true && !isset($_POST['page'][$v1['fld_id_pages']])){
     $req8='DELETE FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` WHERE `fld_group_id_grpspgs` = '.$_POST['fld_group_id_grpspgs'].' AND `fld_page_id_grpspgs` = '.$v1['fld_id_pages'].'' ;
     $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
     if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
      $updated=true;
     }else{
      $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req='.$req8.' ';
     }
    }
   }
  }else{
   $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req7));
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req='.$req7.' ';
  }
  if(true===$updated){
   $_SESSION[PGMK][NAV][BNF]['message'][]=__LINE__ . ' ' . txt2('Des mises à jour ont été faites_180_64');
  }else{
   $_SESSION[PGMK][NAV][BNF]['message'][]=__LINE__ . ' ' . txt2('Aucune mise à jour a été faite_182_64');
  }
 }
 return $updated;
}
//============================================================================================================================================
function updateMenus(){
 $updated=false;
 $listeDesPages=array();
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
 if( isset($_POST['fld_group_id_grpspgs']) && isset($_POST['action'])  ){
  
  $req7='
   SELECT  T0.`fld_page_id_grpspgs` , T0.`fld_is_menu_grpspgs`
   FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` T0 
   WHERE T0.fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].'
  ' ;
//  echo __FILE__ . ' ' . __LINE__ . ' $req7 = <pre>' . $req7 . '</pre>' ; exit(0);
  $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($mpsr7=mysqli_fetch_row($result7)){
//    echo __FILE__ . ' ' . __LINE__ . ' $mpsr7[1] = <pre>' . $mpsr7[1] . ' $mpsr7[0] = <pre>' . $mpsr7[0] . '</pre> $_POST = <pre>' . var_export($_POST , true) . '</pre>' ;
    $req8='';
    if($mpsr7[1]=='1' && !isset($_POST['menu'][$mpsr7[0]])){
     // delete
     $req8='
      UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET 
      `fld_is_menu_grpspgs` = \'0\' ,
      `fld_tsupd_grpspgs` = \''.$GLOBALS['glob_setdate'].'\' 
      WHERE fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].' AND `fld_page_id_grpspgs` = '.$mpsr7[0].'' ;
    }else if($mpsr7[1]=='0' && isset($_POST['menu'][$mpsr7[0]])){
     // add
     $req8='
      UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET 
      `fld_is_menu_grpspgs` = \'1\' ,
      `fld_tsupd_grpspgs`   = \''.$GLOBALS['glob_setdate'].'\' 
      WHERE fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].' AND `fld_page_id_grpspgs` = '.$mpsr7[0].'' ;
    }
    if($req8!=''){
     $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
     if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
      $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req8='.$req8.' ';
     }else{
      if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])!=0){
       $updated=true;
      }
     }
    }
   }
 //  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $updated , true ) . '</pre>' ; exit(0);
   mysqli_free_result($result7);
  }
  
  $listeDesMenusDeCeGroupe=array();
  $req7='
   SELECT  T0.`fld_page_id_grpspgs` , T0.`fld_is_menu_grpspgs`
   FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` T0 
   WHERE T0.fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].'
     AND T0.`fld_is_menu_grpspgs` = \'1\'
  ';
  $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($mpsr7=mysqli_fetch_row($result7)){
    $listeDesMenusDeCeGroupe[]=$mpsr7[0];
   }
   mysqli_free_result($result7);
  }  
  
  foreach($_POST['menu'] as $k1 => $v1){
   $trouve=false;
   foreach($listeDesMenusDeCeGroupe as $k2 => $v2){
    if($v1 == $v2){
     $trouve=true;
    }
   }
   if(false===$trouve){
    $req8='
     UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET 
     `fld_is_menu_grpspgs` = \'1\' ,
     `fld_tsupd_grpspgs`   = \''.$GLOBALS['glob_setdate'].'\' 
     WHERE fld_group_id_grpspgs = '.$_POST['fld_group_id_grpspgs'].' 
       AND `fld_page_id_grpspgs` = '.$v1.'
    ' ;
 //   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . $req8 . '</pre>' ; exit(0);
    $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $req8 , true ) . '</pre>' ; exit(0);
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req8='.$req8.' ';
    }else{
     
     if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])==0){
 //     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
      $req8='
       INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__grpspgs` SET 
          `fld_is_menu_grpspgs` = \'1\' 
        , `fld_group_id_grpspgs` = '.$_POST['fld_group_id_grpspgs'].' 
        , `fld_page_id_grpspgs`  = '.$v1.'
        , `fld_tscrt_grpspgs`   = \''.$GLOBALS['glob_setdate'].'\'
        , `fld_tsupd_grpspgs`   = \''.$GLOBALS['glob_setdate'].'\'
      ' ;
      $result8=mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
      if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=' :-( ' . __LINE__ . ' : mysqli_error='.mysqli_error($GLOBALS['glob_db'][0]['link']).'  $req8='.$req8.' ';
      }else{
       $updated=true;
      }
     }
    }
   }
  }
  if($updated==true){
   $_SESSION[PGMK][NAV][BNF]['message'][]=__LINE__ . ' : '.txt2('Des modifications des menus ont été effectuées_106_65');
  }else{
   $_SESSION[PGMK][NAV][BNF]['message'][]=__LINE__ . ' : '.txt2('Aucune modification de menu effectuée_108_65');     
  }
 }
 return $updated;
}
//============================================================================================================================================
