<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 openDb2();
 $oneError=false;
 $data=null;
// if($fdtoto=fopen('toto.txt','a+')){ fwrite($fdtoto, var_export( $_POST , true ) ); fclose($fdtoto); } 
 
 $txtValue='';
 $req6='
  SELECT  T0.`fld_json_parvals`  
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramvalues` T0 
  WHERE T0.`fld_id_parvals`  = ' . $ret['input']['id'] . '
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $data=null;
  while($mpsr6=mysqli_fetch_row($result6)){
   $txtValue=$mpsr6[0];
   $data=json_decode($mpsr6[0],true);
  }
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $data , true ) . '</pre>';
  mysqli_free_result($result6);
 }else{
  $oneError=true;
  $someErrors[]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']) . ' req6=' . $req6;
 }
 if($oneError==false){
  if($data===NULL){
   $oneError=true;
   $someErrors[]='cannot json $txtValue="' . $txtValue . '"';
  }else{
//   if($fdtoto=fopen('toto.txt','a+')){ fwrite($fdtoto, var_export( $data , true ) ); fclose($fdtoto); } 
   if($ret['input']['lang']==''){
    $data[$ret['input']['key']][$ret['input']['name']]=$ret['input']['value'];
   }else{
    $data[$ret['input']['key']][$ret['input']['name']][$ret['input']['lang']]=$ret['input']['value'];
   }
   $req6="
    UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__paramvalues` SET
      `fld_json_parvals`     = '".addslashes(json_encode($data,JSON_FORCE_OBJECT))   . "'
    , `fld_tsupd_parvals`    = '".$GLOBALS['glob_setdate']         . "'
    WHERE
     `fld_id_parvals`    = '".$ret['input']['id']. "'
   " ;
   $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $someErrors[]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']) . ' req6=' . $req6;
   }else{
    require_once($GLOBALS['glob_incPath1'].'/paramkeys1.php');
    writeParamFiles($ret['input']['paramId']);
   }
  }
 }
 
 if(false===$oneError){
  $ret['status']='OK';
 }else{
  $ret['message']=$someErrors;
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF; 
}