<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();
$o1=htmlHead1(array());
$js1=array();
$showSystemTables=false;
if(isset($_GET['m']) && $_GET['m']==1){
 if(PGMK!='t'.'do'){
  $showSystemTables=false;
 }else{
  $showSystemTables=true;
 }
}
if(isset($_GET['showSystemTables']) && $_GET['showSystemTables']==1){
 $showSystemTables=true;
}
//========================================================================================================
$o1.='<h1>Design</h1>';

$listeDesTables1=array();
$sql='
 SELECT 
  T0.`fld_id_tables`                ,T0.`fld_id_server_tables`   , T0.`fld_name_tables`      ,T0.`fld_system_tables`            ,T0.`fld_view_tables`  ,
  T0.`fld_id_reftbl_of_view_tables` ,T0.`fld_log_tables`         , T0.`fld_remote_tables`    ,T0.`fld_restore_transform_tables` ,T0.`fld_tsupd_tables` ,
  T0.`fld_tscrt_tables`             ,   T0.`fld_cntupd_tables` 
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T0
 WHERE 1=1
';
$req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($row=mysqli_fetch_row($req)){
  $n=array();
  $n['fld_id_tables']                = $row[0];
  $n['fld_id_server_tables']         = $row[1];
  $n['fld_name_tables']              = $row[2];
  $n['fld_system_tables']            = $row[3];
  $n['fld_view_tables']              = $row[4];
  $n['fld_id_reftbl_of_view_tables'] = $row[5];
  $n['fld_log_tables']               = $row[6];
  $n['fld_remote_tables']            = $row[7];
  $n['fld_restore_transform_tables'] = $row[8];
  $n['fld_tsupd_tables']             = $row[9];
  $n['fld_tscrt_tables']             = $row[10];
  $n['fld_cntupd_tables']            = $row[11];
  $n['displayed']                    = false;
  $n['fld_left_table']               = 0;
  $n['fld_top_table']                = 0;
  $n['fld_width_table']              = 0;
  $listeDesTables1[]=$n;
 }
 mysqli_free_result($req);
}else{
 debugSql2(array('sqler' => '' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
}

$listeDesChampsTables=array(
 'canvas' => array(
  'width'  => 0,
  'height' => 0,
  'mode'   => 'mode_table1'
 ),
);

$pos0=-1;
foreach($listeDesTables1 as $k1=>$v1){
 
 $pos0++;
 
 
 $pos1=-1;
 $sql=' SHOW FULL COLUMNS FROM `'.$v1['fld_name_tables'].'` IN `'.$GLOBALS['glob_db'][0]['dbname'].'` ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $row , true ) . '</pre>' ; exit(0);
   $pos1++;
   $listeDesChampsTables['tables'][$pos0]['table']=$v1;
   $listeDesChampsTables['tables'][$pos0]['fields'][$pos1]=array(
    'nom_champ'            => $row[0],
    'type_champ'           => $row[1],
    'Collation'            => $row[2],
    'null_possible'        => $row[3],
    'champ_cle'            => $row[4],
    'val_defaut'           => $row[5],
    'extra'                => $row[6],
    'privileges'           => $row[7],
    'comment'              => $row[8],
    'position'             => $pos1,
   );
   // recherche du champ parent du champ courant
   
   $parentField=array();
   $sql2='
    SELECT 
     T2.`fld_name_tables`                   , T0.`fld_parent_field_pglnks` , T0.`fld_link_mandatory_pglnks` , T0.`fld_id_pglnks` , T0.`fld_parent_field_display_pglnks`
    FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tablelinks` T0 ,
         `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables`     T2
    WHERE 1=1
      AND T0.`fld_children_table_id_pglnks` = '.$v1['fld_id_tables'].'
      AND T0.`fld_child_field_pglnks`       = \''.$row[0].'\'
      AND T2.`fld_id_tables`                = T0.`fld_parent_table_id_pglnks`
   ';
   $req2=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql2);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    while($row2=mysqli_fetch_row($req2)){
    
     $parentField['db_id_link']                      = $row2[3];
     $parentField['fld_name_tables']                 = $row2[0];
     $parentField['fld_parent_field_pglnks']         = $row2[1];
     $parentField['fld_parent_field_display_pglnks'] = $row2[4];
     $parentField['fld_link_mandatory_pglnks']       = (int)$row2[2];
     $parentField['centerKnee']                      = true;
     $parentField['parentOnLeft']                    = false;
     $parentField['childOnRight']                    = false;
     $parentField['kneeX']                           = 0;
     $parentField['kneeY']                           = 0;
    }
    mysqli_free_result($req2);
   }else{
    debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql2 , 'file' => __FILE__ , 'line' => __LINE__ ));
   }
   if(count($parentField)>0){
    $listeDesChampsTables['tables'][$pos0]['fields'][$pos1]['parent']=$parentField;
   }
  }
 }else{
  debugSql2(array('sqler' => '' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
}

@include($GLOBALS['glob_incPath1'].'/__design1.php');


foreach($listeDesChampsTables['tables'] as $k1=>$v1){
 $class='';
 if(isset($__design1) && is_array($__design1)){
   for($i=0;$i<count($__design1['tables']);$i++){
     if($__design1['tables'][$i]['table']['fld_name_tables']==$v1['table']['fld_name_tables']){
       if($__design1['tables'][$i]['table']['displayed']==$v1){
         $listeDesChampsTables['tables'][$k1]['table']['displayed']=true;
         $class='yyedit';
       }
       $listeDesChampsTables['tables'][$k1]['table']['fld_left_table'] = $__design1['tables'][$i]['table']['fld_left_table'];
       $listeDesChampsTables['tables'][$k1]['table']['fld_top_table']  = $__design1['tables'][$i]['table']['fld_top_table'] ;
       foreach($v1['fields'] as $k2=>$v2){
         if(isset($v2['parent'])){
           for($j=0;$j<count($__design1['tables'][$i]['fields']);$j++){
             if(isset($__design1['tables'][$i]['fields'][$j]['parent']) && $__design1['tables'][$i]['fields'][$j]['nom_champ'] == $v2['nom_champ']){
               
               if(isset($__design1['tables'][$i]['fields'][$j]['parent']['centerKnee'])){
                 $listeDesChampsTables['tables'][$k1]['fields'][$k2]['parent']['centerKnee']=$__design1['tables'][$i]['fields'][$j]['parent']['centerKnee'];
               }
               if(isset($__design1['tables'][$i]['fields'][$j]['parent']['parentOnLeft'])){
                 $listeDesChampsTables['tables'][$k1]['fields'][$k2]['parent']['parentOnLeft']=$__design1['tables'][$i]['fields'][$j]['parent']['parentOnLeft'];
               }
               if(isset($__design1['tables'][$i]['fields'][$j]['parent']['childOnRight'])){
                 $listeDesChampsTables['tables'][$k1]['fields'][$k2]['parent']['childOnRight']=$__design1['tables'][$i]['fields'][$j]['parent']['childOnRight'];
               }
               if(isset($__design1['tables'][$i]['fields'][$j]['parent']['kneeX'])){
                 $listeDesChampsTables['tables'][$k1]['fields'][$k2]['parent']['kneeX']=$__design1['tables'][$i]['fields'][$j]['parent']['kneeX'];
               }
               if(isset($__design1['tables'][$i]['fields'][$j]['parent']['kneeY'])){
                 $listeDesChampsTables['tables'][$k1]['fields'][$k2]['parent']['kneeY']=$__design1['tables'][$i]['fields'][$j]['parent']['kneeY'];
               }
             }
           }
         }
       }
     }
   }
 }
 $typeVt='<span class="yybadge1">tbl:</span>';
 if($v1['table']['fld_view_tables']==1){
  $typeVt='<span class="yybadge0">view:</span>';
 }
 if($v1['table']['fld_system_tables']==true){
  if($showSystemTables==true){
   $o1.='<a href="javascript:myDraw1.activateTable2(\''.$v1['table']['fld_name_tables'].'\')" class="'.$class.'" id="link1_'.$v1['table']['fld_name_tables'].'">'.$typeVt.$v1['table']['fld_name_tables'].'</a>';
  }
 }else{
  $o1.='<a href="javascript:myDraw1.activateTable2(\''.$v1['table']['fld_name_tables'].'\')" class="'.$class.'" id="link1_'.$v1['table']['fld_name_tables'].'">'.$typeVt.$v1['table']['fld_name_tables'].'</a>';
 }
}

$tableList1=array();
foreach($GLOBALS['glob_db'] as $k1 => $v1){

 $req6='
   SELECT `table_name`              , T1.`fld_system_tables` , T1.`fld_id_tables` , T1.`fld_id_server_tables` , T1.`fld_log_tables` ,
          T1.`fld_remote_tables`
     FROM `information_schema`.`tables`
     LEFT JOIN `'.$v1['dbname'].'`.`tdo_tbl__tables` T1 ON `table_name` = T1.`fld_name_tables`
    WHERE `table_type` = \'BASE TABLE\' AND `table_schema`=\''.$v1['dbname'].'\'  
      AND T1.`fld_system_tables` IS NULL
    ORDER BY `table_name` ASC; 
 ';

 $result6=mysqli_query($v1['link'],$req6);
 if(mysqli_errno($v1['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $tableList1[]=array(
    'server_index'         => $k1,
    'table_name'           => $mpsr6[0],
    'system_table'         => $mpsr6[1],
    'fld_id_tables'        => $mpsr6[2],
    'fld_id_server_tables' => $mpsr6[3],
    'type'                 => 'table'  ,
    'log_table'            => $mpsr6[4],
   );
  }
  mysqli_free_result($result6);
 }else{
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=':-( '. __LINE__ .' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
 }
}
foreach($tableList1 as $k2 => $v2){
 $o1.='<a href="javascript:myDraw1.addTable1(\''.$v2['table_name'].'\','.$v2['server_index'].')" class="yywarning" id="link1_'.$v2['table_name'].'"><span class="yybadge1">tbl:</span>'.$v2['table_name'].'</a>';
}

$viewList1=array();


//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listeDesChampsTables , true ) . '</pre>' ; exit(0);
foreach($GLOBALS['glob_db'] as $k1 => $v1){

 $req6='
   SELECT `table_name` , T1.`fld_system_tables` , T1.`fld_id_tables` , T1.`fld_id_server_tables`
     FROM `information_schema`.`views`
     LEFT JOIN `'.$v1['dbname'].'`.`tdo_tbl__tables` T1 ON `table_name` = T1.`fld_name_tables`
    WHERE `table_schema`=\''.$GLOBALS['glob_db'][0]['dbname'].'\'  
      AND T1.`fld_system_tables` IS NULL
    ORDER BY `table_name` ASC; 
 ';  
 $result6=mysqli_query($v1['link'],$req6);
 if(mysqli_errno($v1['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $viewList1[]=array(
    'server_index'        => $k1,
    'view_name'           => $mpsr6[0],
   );
  }
  mysqli_free_result($result6);
 }else{
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=':-( '. __LINE__ .' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;
 }

// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . $req6 . '</pre>' ; exit(0);
}
foreach($viewList1 as $k2 => $v2){
 $o1.='<a href="javascript:myDraw1.addView1(\''.$v2['view_name'].'\','.$v2['server_index'].')" class="yywarning" id="link1_'.$v2['view_name'].'"><span class="yybadge0">view:</span>'.$v2['view_name'].'</a>';
}



$parentCanvasMinWidth=300;
$parentCanvasMinHeight=300;

if(isset($__design1['canvas']['width']) && $__design1['canvas']['width']>=$parentCanvasMinWidth){
 $listeDesChampsTables['canvas']['width']=$__design1['canvas']['width'];
}else{
 $listeDesChampsTables['canvas']['width']=$parentCanvasMinWidth;
}
if(isset($__design1['canvas']['height']) && $__design1['canvas']['height']>=$parentCanvasMinHeight){
 $listeDesChampsTables['canvas']['height']=$__design1['canvas']['height'];
}else{
 $listeDesChampsTables['canvas']['height']=$parentCanvasMinHeight; 
}

//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listeDesChampsTables['canvas'] , true ) . '</pre>' ; exit(0);
$o1.='<a href="javascript:myDraw1.save1()" class="yysuccess" id="save1">'.txt2('save_228_78').'</a>';

$o1.='<div id="canvas1" class="" style="min-height:'.$parentCanvasMinHeight.'px;min-width:'.$parentCanvasMinWidth.'px;padding:0;margin:0;border:0;"></div>';

if($showSystemTables==false){
 $o1.='<a href="?showSystemTables=1" class="yywarning" >'.txt2('show system tables_233_62').'</a>';
}else{
 $o1.='<a href="?showSystemTables=0" class="yysuccess" >'.txt2('hide system tables_235_62').'</a>'; 
}

$arrModes=array('mode_table1','mode_field1','mode_link1');
foreach($arrModes as $v1){
 if($v1=='mode_table1') $modeName=txt2('mode_table1_240_40');
 if($v1=='mode_field1') $modeName=txt2('mode_field1_241_40');
 if($v1=='mode_link1')  $modeName=txt2('mode_link1_242_40');
 if($listeDesChampsTables['canvas']['mode']==$v1){
  $o1.='<a id="'.$v1.'" href="javascript:myDraw1.setDesignMode1(\''.$v1.'\')" class="yyedit btn" >'.$modeName.'</span>'; 
 }else{
  $o1.='<a id="'.$v1.'" href="javascript:myDraw1.setDesignMode1(\''.$v1.'\')" class="">'.$modeName.'</a>';
 }
}



$listOfParams=array();
$sql='
 SELECT T0.`fld_key_parnams`  
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramnames` T0
 WHERE T0.`fld_id_parnams` NOT IN ( 1 , 3 )
 ORDER BY T0.`fld_id_parnams`
';
$req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($row=mysqli_fetch_row($req)){
  $listOfParams[]=$row[0];
 }
 mysqli_free_result($req);
}else{
 debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
}




$o1.='<div id="list_of_fields1" class="yythinBorder" style="min-width:500px;margin-top:10px;"></div>';
$o1.='<script type="text/javascript">';
$o1.='var globTableData='.json_encode($listeDesChampsTables).';';
$o1.='var globParamList='.json_encode($listOfParams).';';
$o1.='</script>';

//========================================================================================================
$o1.=CRLF.'<script src="js/design-localhost.js" type="text/javascript"></script>'.CRLF;

$js1[]=array(
 'jsName'     => 'design1',
 'localhost'  => true,
 'data'       => array(
    'glob'                  => 'globTableData' ,
    'divId1'                => 'canvas1'       ,
    'objName'               => 'myDraw1'       ,
    'parentCanvasMinWidth'  => $parentCanvasMinWidth,
    'parentCanvasMinHeight' => $parentCanvasMinHeight,
 )
);

$o1.=htmlFoot0(array('js' => $js1));
dw1($o1);
cleanSession1();