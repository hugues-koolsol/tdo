<?php
$GLOBALS['param__group_role']=array (
  'param__Name__Display' => 'n',
  'param__Name__Sort' => 'n',
  'param__Name__key' => 'group_role',
  'param__Key__type' => 'char',
  '__values' => 
  array (
    'fr' => 
    array (
      'i18n' => 
      array (
        'group_role' => 'i18n',
        'n' => 'traducteur',
        'badge' => 'yybadge3',
        'rule' => 0,
        'fld_id_parvals' => '71',
        '__order' => 0,
      ),
      'anonymous' => 
      array (
        'group_role' => 'anonymous',
        'n' => 'anonyme',
        'badge' => 'yybadge1',
        'rule' => 0,
        'fld_id_parvals' => '69',
        '__order' => 1,
      ),
      'root' => 
      array (
        'group_role' => 'root',
        'n' => 'développeur racine',
        'badge' => 'yybadge0',
        'rule' => 0,
        'fld_id_parvals' => '68',
        '__order' => 2,
      ),
      'local_admin' => 
      array (
        'group_role' => 'local_admin',
        'n' => 'administrateur local',
        'badge' => 'yybadge2',
        'rule' => 0,
        'fld_id_parvals' => '70',
        '__order' => 3,
      ),
    ),
    'en' => 
    array (
      'i18n' => 
      array (
        'group_role' => 'i18n',
        'n' => 'translator',
        'badge' => 'yybadge3',
        'rule' => 0,
        'fld_id_parvals' => '71',
        '__order' => 0,
      ),
      'anonymous' => 
      array (
        'group_role' => 'anonymous',
        'n' => 'anonymous',
        'badge' => 'yybadge1',
        'rule' => 0,
        'fld_id_parvals' => '69',
        '__order' => 1,
      ),
      'root' => 
      array (
        'group_role' => 'root',
        'n' => 'root developer',
        'badge' => 'yybadge0',
        'rule' => 0,
        'fld_id_parvals' => '68',
        '__order' => 2,
      ),
      'local_admin' => 
      array (
        'group_role' => 'local_admin',
        'n' => 'local administrator',
        'badge' => 'yybadge2',
        'rule' => 0,
        'fld_id_parvals' => '70',
        '__order' => 3,
      ),
    ),
  ),
  'param__definition' => 
  array (
    'comment' => 'group roles for users',
    'key' => 'group_role',
    'fields' => 
    array (
      0 => 
      array (
        'name' => 'group_role',
        'type' => 'char',
        'length' => 32,
        'comment' => 'root,anonymous,local_admin,user',
      ),
      1 => 
      array (
        'name' => 'n',
        'type' => 'char',
        'length' => 64,
        'languageTranslation' => true,
        'comment1' => 'the transform name',
      ),
    ),
    'dependencies' => 
    array (
      0 => 
      array (
        'id_db' => 0,
        'table' => 'tdo_tbl__groups',
        'field' => 'fld_role_groups',
      ),
    ),
    'id' => '7',
  ),
);