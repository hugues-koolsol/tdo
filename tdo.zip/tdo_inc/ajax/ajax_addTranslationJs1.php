<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 /*
  funct: "addTranslationJs1"
  idparent: "js_1"
  key: "record_these_priorities_32_109"
  option: "create"
  value: "rzgreger"
 */ 
 openDb1();
 $oneError=false;
 if($ret['input']['option']=='create'){
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
     `fld_key_lngVals`     = '".addslashes1($ret['input']['key'])    ."'
   , `fld_lang_lngVals`    = '".addslashes1($ret['input']['lang'])   ."'
   , `fld_type_lngVals`    = 'javascript'
   , `fld_value_lngVals`   = '".addslashes1($ret['input']['value'])  ."'
   , `fld_tsupd_lngVals`   = '".$GLOBALS['glob_setdate']            ."'
   , `fld_tscrt_lngVals`   = '".$GLOBALS['glob_setdate']            ."'
  " ;
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $oneError=true;
   $ret['message'][]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']) . ' req6=' . $req6;
  }
 }else{
  $req6="
   UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
     `fld_value_lngVals`   = '".addslashes1($ret['input']['value'])   ."'
   , `fld_tsupd_lngVals`   = '".$GLOBALS['glob_setdate']                  ."'
   WHERE
       `fld_key_lngVals`     = '".addslashes($ret['input']['key'])     ."'
   AND `fld_lang_lngVals`    = '".addslashes($ret['input']['lang'])    ."'
   AND `fld_type_lngVals`    = 'javascript'
  " ;
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $oneError=true;
   $ret['message'][]='mysqli_error()='.mysqli_error($GLOBALS['glob_db'][0]['link']) . ' req6=' . $req6;
  }  
 }
 if(false===$oneError){
  $ret['status']='OK';
  $ret['input']['type']='javascript';
  include 'ajax_writeTranslationFiles1.php';
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}