<?php
$__tableNames=array (
  'tdo_tbl__css' => 'css',
  'tdo_tbl__groups' => 'groupes d\'utilisateurs',
  'tdo_tbl__grpspgs' => 'pages des groupes d\'utilisateurs',
  'tdo_tbl__langvalues' => 'traductions',
  'tdo_tbl__log' => 'logs',
  'tdo_tbl__pages' => 'pages',
  'tdo_tbl__paramnames' => 'paramètres',
  'tdo_tbl__paramrules' => 'règles des paramètres',
  'tdo_tbl__paramvalues' => 'valeurs des paramètres',
  'tdo_tbl__tablelinks' => 'liens entre les tables',
  'tdo_tbl__tables' => 'tables',
  'tdo_tbl__todos' => 'todos',
  'tdo_tbl__uploadeddocs' => 'documents téléversés',
  'tdo_tbl__users' => 'utilisateurs',
  'tdo_tbl__zztests' => 'ma table de test',
);