<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();


if(isset($_GET['setCss'])){
 include($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/__css.php');
 if(!isset($__css[$_GET['setCss']])){
  $_COOKIE[PGMK.'cssvalue']=1;
  setcookie ( PGMK.'cssvalue' , $_COOKIE[PGMK.'cssvalue'] , time()+3600*24*365);
 }else{
  $_COOKIE[PGMK.'cssvalue']=$_GET['setCss'];
  setcookie ( PGMK.'cssvalue' , $_GET['setCss'] , time()+3600*24*365 );  
 }
 header("HTTP/1.1 303 See Other");header('Location: '.BNF);
 exit(); 
}


$o1='';
$o1.=htmlHead1(array());
if(isset($_GET['message'])){
 if($_GET['message']=='g000001'){
  $o1.='<span style="font-size:2em;">'.txt2('you_are_not_authorized_on_this_page_or_there_is_a_technical_problem_26_45').'</span>';  
 }else{
  $o1.='<span style="font-size:2em;">'.$_GET['message'].'</span>';
 }
 $o1.='<hr />';
}

$o1.='<h1 style="margin:3em auto 2em auto;width:80%; text-align:center;">'.txt2('hello, this is _14_83') . ' ' . PGMK .'</h1>';


$o1.='<div style="overflow-x:scroll;">'.CRLF;
$o1.='<table class="thinBorder" style="margin:0 auto;">'.CRLF;
$o1.='<caption style="text-align:center;">'.txt2('ce_tableau_est_adapte_pour_les_mobiles_avec_scroll_33_50').'</caption>'.CRLF;
$o1.='<thead><tr><th>&nbsp;&nbsp;&nbsp;c1&nbsp;&nbsp;&nbsp;</th><th>&nbsp;&nbsp;&nbsp;c2&nbsp;&nbsp;&nbsp;</th><th>&nbsp;&nbsp;&nbsp;c3&nbsp;&nbsp;&nbsp;</th><th>&nbsp;&nbsp;&nbsp;c4&nbsp;&nbsp;&nbsp;</th><th>&nbsp;&nbsp;&nbsp;c5&nbsp;&nbsp;&nbsp;</th><th>&nbsp;&nbsp;&nbsp;c6&nbsp;&nbsp;&nbsp;</th></tr></thead>'.CRLF;
$o1.='<tbody>'.CRLF;
for($i=10;$i<=40;$i+=10){
 $o1.='<tr>';
 $o1.='<td data-label="c1">&nbsp;-&nbsp;-&nbsp;d&nbsp;'.($i+1).'&nbsp;-&nbsp;-&nbsp;</td><td data-label="c2">&nbsp;-&nbsp;-&nbsp;d&nbsp;'.($i+2).'&nbsp;-&nbsp;-&nbsp;</td><td data-label="c3">&nbsp;-&nbsp;-&nbsp;d&nbsp;'.($i+3).'&nbsp;-&nbsp;-&nbsp;</td><td data-label="c4">&nbsp;-&nbsp;-&nbsp;d&nbsp;'.($i+4).'&nbsp;-&nbsp;-&nbsp;</td><td data-label="c5">&nbsp;-&nbsp;-&nbsp;d&nbsp;'.($i+4).'&nbsp;-&nbsp;-&nbsp;</td><td data-label="c6">&nbsp;-&nbsp;-&nbsp;d&nbsp;'.($i+4).'&nbsp;-&nbsp;-&nbsp;</td>'.CRLF;
 $o1.='</tr>'.CRLF;
}
$o1.='</tbody>'.CRLF;
$o1.='</table>'.CRLF;
$o1.='</div>'.CRLF;




$o1.=getCss1(400); // todo adjust size

$o1.='<table class="tableResult1" style="margin:2em auto;">'.CRLF;
$o1.='<caption style="text-align:center;">'.txt2('ce_tableau_est_adapte_pour_les_mobiles_19_23').'</caption>'.CRLF;
$o1.='<thead><tr><th>c1</th><th>c2</th><th>c3</th><th>c4</th></tr></thead>'.CRLF;
$o1.='<tbody>'.CRLF;
for($i=10;$i<=40;$i+=10){
 $o1.='<tr>';
 $o1.='<td class="fictif"></td><td data-label="c1"> - - d '.($i+1).' - - </td><td data-label="c2"> - - d '.($i+2).' - - </td><td data-label="c3"> - - d '.($i+3).' - - </td><td data-label="c4"> - - d '.($i+4).' - - </td><td class="fictif"></td>'.CRLF;
 $o1.='</tr>'.CRLF;
}
$o1.='</tbody>'.CRLF;
$o1.='</table>'.CRLF;


include($GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/__css.php');
if(isset($__css)){
 $o1.='  <div style="display:block;margin:2em auto;text-align:center;">'.CRLF;
 foreach($__css as $k1=>$v1){
  $jsonTemp=json_decode($v1['fld_color_back_css'],true);
  $jsonColorBack=$jsonTemp['hexValue'];
  $jsonTemp=json_decode($v1['fld_color_text_css'],true);
  $jsonColorText=$jsonTemp['hexValue'];
  if(isset($_COOKIE[PGMK.'cssvalue']) && $k1==$_COOKIE[PGMK.'cssvalue']){
   $o1.='<span class="btn" style="background:#'.$jsonColorBack.';color:#'.$jsonColorText.';border-style:inset;border-color:#'.$jsonColorText.';border-width:4px;transform:rotatez(90deg);font-weight:bold;">:-)</span>';
  }else{
   $o1.='<a href="'.BNF.'?setCss='.$k1.'" style="background:#'.$jsonColorBack.';color:#'.$jsonColorText.';border-color:#'.$jsonColorText.';">:-)</a>';
  }
 }
 $o1.='  </div>'.CRLF;
}


$o1.='<div target="_blank" style="width:10em;margin:2em auto;"><a href="https://www.koolsol.app/" style="width:10em;">koolsol ;-)</a></div>';


$o1.=htmlFoot0(array());
dw1($o1);