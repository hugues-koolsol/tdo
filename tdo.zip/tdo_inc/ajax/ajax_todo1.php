<?php
// do not forget to put this file in the file list !
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
 openDb1();
 $err=0;
 $req6='
  SELECT  SQL_CALC_FOUND_ROWS   
    T0.`fld_id_todos`              ,T0.`fld_priority_todos`        ,T0.`fld_id_user_todos`         ,concat( T1.`fld_login_users` ,\' \' ,T1.`fld_firstname_users` ,\' \' , T1.`fld_lastname_users` ) , 1 , 
    1                              ,T0.`fld_title_todos`           ,T0.`fld_comment_todos`         
  FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__todos` T0
         , `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users` T1 ) 
  WHERE 1=1 
    AND T0.`fld_id_user_todos`=T1.`fld_id_users`
    AND ( T0.`fld_priority_todos` <80 )
    AND T0.`fld_id_user_todos` = '.$_SESSION[PGMK]['login'].'  
    ORDER BY T0.`fld_priority_todos` ASC
 ';
 $data0=array();
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $data0[]=array(
   'id'       => (int)$mpsr6[0],
   'data'     => array( 'label' => ' ' .$mpsr6[1] . ' '.$mpsr6[6] . ' ' ), // displayParam1('yorno',$mpsr6[1],array('unsetPossible'=>true))
   'parentId' => 0,
   'isOpen'   => 1,
   );
  }
  mysqli_free_result($result6);
  $ret['status']='OK';
  $ret['data']  =$data0;
 }else{
  $ret['message'][]='hello ' . BNF . ' ' . ' sqler=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ' ,reque=' . $req6;  
 }
 
 
 
 
 
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;   
}