<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();
require_once $GLOBALS['glob_incPath1'].'/zz_inc_users0.php';
require_once $GLOBALS['glob_incPath1'].'/zz_inc_groups1.php';

//========================================================================================================================
if(isset($_GET['a'])&&$_GET['a']='useThisProfile'){
 if($_SESSION[PGMK]['groupInit']==1||$_SESSION['isLocalAdmin']){
  $doit=false;
  if($_SESSION[PGMK]['loginInit']==1){
   $doit=true;
   $sql='
    SELECT T1.`fld_category_groups`
    FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users`  T0 ,
         `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T1
    WHERE T0.`fld_id_users`         = '.addslashes($_GET['fld_id_users']). '
      AND T0.`fld_group_id_users`   = T1.`fld_id_groups`
   ';
   $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    while($row=mysqli_fetch_row($req)){
     $category=$row[0];
    }
    mysqli_free_result($req);
   }else{
    debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
   }
   
  }else{
   if($_SESSION['isLocalAdmin']){
    // L'utilisateur sélectionné fait-il partie d'un groupe dont le groupe parent est celui de l'adminlocal en cours
    $sql='
     SELECT T1.`fld_category_groups`
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users`  T0 ,
          `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T1
     WHERE T0.`fld_id_users`         = '.addslashes($_GET['fld_id_users']). '
       AND T0.`fld_group_id_users`   = T1.`fld_id_groups`
       AND ( T1.`fld_parent_id_groups` = '.addslashes($_SESSION[PGMK]['groupInit']).' OR T1.`fld_root_group_id_groups` = '.$_SESSION[PGMK]['groupInit'].' )

    ';
    $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
     while($row=mysqli_fetch_row($req)){
      $doit=true;
      $category=$row[0];
     }
     mysqli_free_result($req);
    }else{
     debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
    }
   }
  }
  if($doit){
   $_SESSION[PGMK]['login'] =$_GET['fld_id_users'];
   $_SESSION[PGMK]['group'] =$_GET['fld_group_id_users'];
   $_SESSION[PGMK]['grpCat']=$category;
  }
 }
 header("HTTP/1.1 303 See Other");header('Location: '.BNF .'');
 exit(0);
}
//========================================================================================================================
function test_input_usersKO1($name2){
 $err=0;
 
 if($err==0&&$name2['fld_loginisemail_users']==1){
  if($err==0&&!filter_var($_SESSION[PGMK][NAV][BNF]['fld_email_users'], FILTER_VALIDATE_EMAIL)){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('this email is not correct_16_93');
   $err=1;
  }
 }else{
  if($err==0&&$name2['fld_loginisemail_users']!=''){
   if($err==0&&!filter_var($_SESSION[PGMK][NAV][BNF]['fld_email_users'], FILTER_VALIDATE_EMAIL)){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('this email is not correct_16_93');
    $err=1;
   }
  }
  if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_login_users']==''){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_login_users must not be empty_27_93');
   $err=1;
  }
 }
 if($err==0&&$name2['fld_loginisemail_users']==1){
  $_SESSION[PGMK][NAV][BNF]['fld_login_users']=$_SESSION[PGMK][NAV][BNF]['fld_email_users'];
 }
 
 if($err==0&&isset($_POST['fld_password_users'])){
  if($_SESSION[PGMK][NAV][BNF]['fld_password_users']==''){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_password_users must not be empty_37_93');
   $err=1;
  }
  if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_password_users']!=$_SESSION[PGMK][NAV][BNF]['fld_password_users_confirm']){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_password_users must be the same as confirmation_41_93');
   $err=1;
  }
  if($err==0){
   $name2=getuser1($_SESSION[PGMK]['loginInit']);
   if(!password_verify($_SESSION[PGMK][NAV][BNF]['__actualpassword'], $name2['fld_password_users'])){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the actual password is wrong_45_93');
    $err=1;
   }
  }
 }
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_firstname_users']==''){
  $_SESSION[PGMK][NAV][BNF]['warningmessage'][]=txtsys1('warning').' '. __LINE__ .' : ' . txt2('fld_firstname_users is empty_50_94');
 }
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_lastname_users']==''){
  $_SESSION[PGMK][NAV][BNF]['warningmessage'][]=txtsys1('warning').' '. __LINE__ .' : ' . txt2('fld_lastname_users is empty_54_94');
 }
 return($err);
}
//========================================================================================================================

//========================================================================================================================
if(isset($_POST)&&sizeof($_POST)>=1){ // post action

 
// echo __LINE__ . ' $_POST=<pre>' . var_export($_POST,true) . '</pre>'; exit();
 if(isset($_POST['__formNumber']) && $_POST['__formNumber']=='2'){
  setcookie( '__aspect' , $_POST['__aspect']);
 }else{
  $_SESSION[PGMK][NAV][BNF]['fld_login_users']        =isset($_POST['fld_login_users'])        ?$_POST['fld_login_users']        : '';
  $_SESSION[PGMK][NAV][BNF]['fld_email_users']        =isset($_POST['fld_email_users'])        ?$_POST['fld_email_users']        : '';
  $_SESSION[PGMK][NAV][BNF]['fld_loginisemail_users'] =isset($_POST['fld_loginisemail_users']) ?$_POST['fld_loginisemail_users'] : 0;
  $_SESSION[PGMK][NAV][BNF]['fld_firstname_users']    =isset($_POST['fld_firstname_users'])    ?$_POST['fld_firstname_users']    : '';
  $_SESSION[PGMK][NAV][BNF]['fld_lastname_users']     =isset($_POST['fld_lastname_users'])     ?$_POST['fld_lastname_users']     : '';
  if(isset($_POST['fld_password_users'])){
   $_SESSION[PGMK][NAV][BNF]['fld_password_users']         = isset($_POST['fld_password_users'])         ? $_POST['fld_password_users']         : '' ;
   $_SESSION[PGMK][NAV][BNF]['fld_password_users_confirm'] = isset($_POST['fld_password_users_confirm']) ? $_POST['fld_password_users_confirm'] : '' ;
   $_SESSION[PGMK][NAV][BNF]['__actualpassword']           = isset($_POST['__actualpassword'])           ? $_POST['__actualpassword']           : '' ;
  }
  $name2=getuser1($_SESSION[PGMK]['loginInit']);
  
  if(test_input_usersKO1($name2)){
   header("HTTP/1.1 303 See Other");header('Location: '.BNF);
   exit();
  }
 // echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0);
  $req6="UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__users` SET
      `fld_login_users`        = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_login_users'])        ."'
    , `fld_email_users`        = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_email_users'])        ."'
    , `fld_firstname_users`    = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_firstname_users'])    ."'
    , `fld_lastname_users`     = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_lastname_users'])     ."'
    , `fld_tsupd_users`        = '".addslashes($GLOBALS['glob_setdate'])                        ."'
    , `fld_cntupd_users`       =  " . ((int)$_POST['fld_cntupd_users']+1)                           ."
  ";
  if(isset($_POST['fld_password_users'])){
   $optionsHash = array('cost'=>12);
   $passWordHash=password_hash($_SESSION[PGMK][NAV][BNF]['fld_password_users'],PASSWORD_BCRYPT,$optionsHash);
   
   $req6.="
    , `fld_password_users`             = '".addslashes($passWordHash)."'
   ";
  }
  $req6.="
   WHERE `fld_id_users`=".$_SESSION[PGMK]['loginInit']."
  ";
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
     break;
    default   :
     $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    break;
   }
   header("HTTP/1.1 303 See Other");header('Location: '.BNF); exit();
  }
  sqllog1( $req6 , BNF , __LINE__ );
  $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('the_modification_has_been_recorded_at') . ' ' . substr($GLOBALS['glob_setdate'],11);
 }
 
 
 header("HTTP/1.1 303 See Other");header('Location: '.BNF);
 exit();

}

//========================================================================================================================
$o1='';
$o1.=htmlHead1(array());
$o1.='<h1>'.txt2('page_title_profile_10_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

if($_SESSION[PGMK]['login']!=$_SESSION[PGMK]['loginInit']){
 $o1.='<div class="yywarning" style="text-align:center;font-size:1.2em;padding:15px;">'.txt2('you are using a other profile than yours_140_47').'(id='.$_SESSION[PGMK]['login'].')'.'</div>';
}


$xxxFldValues=array();
$js1=array();
$o1.=displaySessionMessage1(BNF);
$loginInitData=getuser1($_SESSION[PGMK]['loginInit']);
$myLogiData   =getuser1($_SESSION[PGMK]['login']);
if($_SESSION[PGMK]['loginInit']==$_SESSION[PGMK]['login']){
 $xxxFldValues['fld_login_users']        =isset( $_SESSION[PGMK][NAV][BNF]['fld_login_users'] )        ? $_SESSION[PGMK][NAV][BNF]['fld_login_users']        : $loginInitData['fld_login_users']        ;
 $xxxFldValues['fld_email_users']        =isset( $_SESSION[PGMK][NAV][BNF]['fld_email_users'] )        ? $_SESSION[PGMK][NAV][BNF]['fld_email_users']        : $loginInitData['fld_email_users']        ;
 $xxxFldValues['fld_password_users']     =isset( $_SESSION[PGMK][NAV][BNF]['fld_password_users'] )     ? $_SESSION[PGMK][NAV][BNF]['fld_password_users']     : $loginInitData['fld_password_users']     ;
 $xxxFldValues['fld_firstname_users']    =isset( $_SESSION[PGMK][NAV][BNF]['fld_firstname_users'] )    ? $_SESSION[PGMK][NAV][BNF]['fld_firstname_users']    : $loginInitData['fld_firstname_users']    ;
 $xxxFldValues['fld_lastname_users']     =isset( $_SESSION[PGMK][NAV][BNF]['fld_lastname_users'] )     ? $_SESSION[PGMK][NAV][BNF]['fld_lastname_users']     : $loginInitData['fld_lastname_users']     ;
 $xxxFldValues['fld_translate_users']    =$loginInitData['fld_translate_users']    ;
 $xxxFldValues['fld_loginisemail_users'] =$loginInitData['fld_loginisemail_users'] ;
 $xxxFldValues['fld_group_id_users']     = $loginInitData['fld_group_id_users']    ;


 $o1.='<form method="post" >'.CRLF;

 $o1.='<input type="hidden" value="u" name="a" id="a" />'.CRLF;
 $o1.='<input type="hidden" value="'.$_SESSION[PGMK]['loginInit'].'" name="id1" id="id1" />'.CRLF;
 $o1.='<input type="hidden" value="'.enti1($xxxFldValues['fld_loginisemail_users']).'" name="fld_loginisemail_users" id="fld_loginisemail_users"  />'.CRLF;

 if($xxxFldValues['fld_loginisemail_users']==0){
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_login_users_39_43').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_login_users']).'" name="fld_login_users" id="fld_login_users" maxlength="64" style="width:100%;max-width:66em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
 }

 $o1.=' <div class="yyfdiv1">'.CRLF;
 $o1.='  <div class="yyflab1"><div>'.txt2('fld_email_users_50_42').'</div></div>'.CRLF;
 $o1.='  <div class="yyfinp1"><div>'.CRLF;
 $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_email_users']).'" name="fld_email_users" id="fld_email_users" maxlength="128" style="width:100%;max-width:130em;" />'.CRLF;
 $o1.='   <br />'.CRLF;
 $o1.='   <a id="btnModif" class="yybtn" href="javascript:modifierLeMotDePasse2(\'divMod\',\'btnModif\',\'fld_password_users\')">'.txt2('Modifier le mot de passe_51_171').'</a>'.CRLF;
 $o1.='   <div id="divMod"></div>'.CRLF;
 $o1.='  </div></div>'.CRLF;
 $o1.=' </div>'.CRLF;


 $o1.=' <div class="yyfdiv1">'.CRLF;
 $o1.='  <div class="yyflab1"><div>'.txt2('fld_firstname_users_82_42').'</div></div>'.CRLF;
 $o1.='  <div class="yyfinp1"><div>'.CRLF;
 $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_firstname_users']).'" name="fld_firstname_users" id="fld_firstname_users" maxlength="64" style="width:100%;max-width:66em;" />'.CRLF;
 $o1.='  </div></div>'.CRLF;
 $o1.=' </div>'.CRLF;

 $o1.=' <div class="yyfdiv1">'.CRLF;
 $o1.='  <div class="yyflab1"><div>'.txt2('fld_lastname_users_89_42').'</div></div>'.CRLF;
 $o1.='  <div class="yyfinp1"><div>'.CRLF;
 $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_lastname_users']).'" name="fld_lastname_users" id="fld_lastname_users" maxlength="64" style="width:100%;max-width:66em;" />'.CRLF;
 $o1.='  </div></div>'.CRLF;
 $o1.=' </div>'.CRLF;


 $o1.='<div class="yyfdiv1">'.CRLF;
 $o1.='  <div class="yyfinp1"><div>'.CRLF;
 $o1.='   <input type="hidden" name="fld_cntupd_users" id="fld_cntupd_users" value="'.$loginInitData['fld_cntupd_users'].'" />'.CRLF;
 $o1.='   <button type="submit">'.txtsys1('save_the_modification').'</button>'.CRLF;
 $o1.='  </div></div>'.CRLF;
 $o1.='</div>'.CRLF;

 $o1.='</form>'.CRLF;
}
  
$xDisplayValueFetch = '' ;
$xGroupValues=getGroup1($loginInitData['fld_group_id_users']);
$xDisplayValueFetch = txt2('you are in this group of users : "_81_30') . '"' . enti1( $xGroupValues['fld_name_groups'] ) . '"' ;
if($loginInitData['fld_translate_users']==1){
 $xDisplayValueFetch.= '<br />'.txt2('you can translate the pages_83_40') . '' ;   
}
$o1.='  <div class="yyfdiv1">'.CRLF;
$o1.='   <div class="yyflab1"><div>'.txt2('other informations_86_43').'</div></div>'.CRLF;
$o1.='   <div class="yyfinp1"><div>'.CRLF;
$o1.='     '.$xDisplayValueFetch.'';
$o1.='   </div></div>'.CRLF;
$o1.='  </div>'.CRLF;

//========================================================================================================================
//========================================================================================================================
//========================================================================================================================
//========================================================================================================================

if($_SESSION['isLocalAdmin'] || $_SESSION[PGMK]['loginInit']==1){
 
     $__nbMax=20;
     $__start=0;
     $__count=0;
     $__xpage=0;
     if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
      $__xpage=$_GET['__xpage'];
     }else{
      if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
     }
     $xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_login_users
     $xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_email_users
     $xsrch_4=saveSessionSearch1('xsrch_4',BNF);// fld_group_id_users
     $xsrch_5=saveSessionSearch1('xsrch_5',BNF);// fld_active_users
     $xsrch_6=saveSessionSearch1('xsrch_6',BNF);// fld_translate_users
     $xsrch_7=saveSessionSearch1('xsrch_7',BNF);// fld_firstname_users
     $xsrch_8=saveSessionSearch1('xsrch_8',BNF);// fld_lastname_users
     $xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_users
     if($xsrch_4!=''){
      if(!is_numeric($xsrch_4)){
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_234_97') . ' : ' . txt2('fld_group_id_users_234_157');
      }
     }
     if($xsrch_id!=''){
      if(!is_numeric($xsrch_id)){
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_234_97') . ' : ' . txt2('fld_id_users_239_157');
      }
     }
     $autofocus='xsrch_0';
     if($xsrch_0!=''){      $autofocus='xsrch_0'; }
     else if($xsrch_1!=''){ $autofocus='xsrch_1'; }
     else if($xsrch_4!=''){ $autofocus='xsrch_4'; }
     else if($xsrch_5!=''){ $autofocus='xsrch_5'; }
     else if($xsrch_6!=''){ $autofocus='xsrch_6'; }
     else if($xsrch_7!=''){ $autofocus='xsrch_7'; }
     else if($xsrch_8!=''){ $autofocus='xsrch_8'; }
     else if($xsrch_id!=''){ $autofocus='xsrch_id'; }

     $o1.=' <form method="get" class="yyfilterForm">'.CRLF;


     $o1.='   <div>'.CRLF;
     $o1.='    <label for="xsrch_0">'.txt2('fld_login_users_258_67').'</label>'.CRLF; // fld_login_users
     $o1.='    <input class=" ';
     if($xsrch_0!=''){$o1.=' yybackgroundYellow';}
     $o1.=     '" type="text" name="xsrch_0"    id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="32"';
     $o1.=' '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
     $o1.='   </div>'.CRLF;


     $o1.='   <div>'.CRLF;
     $o1.='    <label for="xsrch_1">'.txt2('fld_email_users_267_67').'</label>'.CRLF; // fld_email_users
     $o1.='    <input class=" ';
     if($xsrch_1!=''){$o1.=' yybackgroundYellow';}
     $o1.=     '" type="text" name="xsrch_1"    id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="32"';
     $o1.=' '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
     $o1.='   </div>'.CRLF;

     $o1.='   <div>'.CRLF;
     $o1.='    <label for="xsrch_7">'.txt2('fld_firstname_users_337_67').'</label>'.CRLF; // fld_firstname_users
     $o1.='    <input class=" ';
     if($xsrch_7!=''){$o1.=' yybackgroundYellow';}
     $o1.=     '" type="text" name="xsrch_7"    id="xsrch_7"   value="'.enti1($xsrch_7).'"  size="8" maxlength="32"';
     $o1.=' '.($autofocus=='xsrch_7'?'autofocus="autofocus"':'').' />'.CRLF;
     $o1.='   </div>'.CRLF;


     $o1.='   <div>'.CRLF;
     $o1.='    <label for="xsrch_8">'.txt2('fld_lastname_users_346_67').'</label>'.CRLF; // fld_lastname_users
     $o1.='    <input class=" ';
     if($xsrch_8!=''){$o1.=' yybackgroundYellow';}
     $o1.=     '" type="text" name="xsrch_8"    id="xsrch_8"   value="'.enti1($xsrch_8).'"  size="8" maxlength="32"';
     $o1.=' '.($autofocus=='xsrch_8'?'autofocus="autofocus"':'').' />'.CRLF;
     $o1.='   </div>'.CRLF;


     require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
     $o1.='   <div>'.CRLF;
     $o1.='    <label for="xsrch_5">'.txt2('fld_active_users_303_67').'</label>'.CRLF;
     $o1.='    <select name="xsrch_5"  id="xsrch_5" class="';
     if($xsrch_5!=''){$o1.=' yybackgroundYellow';}
     $o1.='" '.($autofocus=='xsrch_5'?'autofocus="autofocus"':'').' />'.CRLF;
     $o1.='<option value="" '.($xsrch_5==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
     foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
      if((string)$kp==(string)$xsrch_5){
       $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
      }else{
       $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
      }
     }
     $o1.='    </select>';
     $o1.='   </div>'.CRLF;



     $o1.='   <div>'.CRLF;
     $o1.='    <label for="xsrch_4">'.txt2('fld_group_id_users_234_157').'</label>'.CRLF; // fld_group_id_users
     $o1.='    <input class=" ';
     if($xsrch_4!=''){$o1.=' yybackgroundYellow';}
     $o1.=     '" type="text" name="xsrch_4"    id="xsrch_4"   value="'.enti1($xsrch_4).'"  size="8" maxlength="32"';
     $o1.=' '.($autofocus=='xsrch_4'?'autofocus="autofocus"':'').' />'.CRLF;
     $o1.='   </div>'.CRLF;

     require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
     $o1.='   <div>'.CRLF;
     $o1.='    <label for="xsrch_6">'.txt2('fld_translate_users_320_67').'</label>'.CRLF;
     $o1.='    <select name="xsrch_6"  id="xsrch_6" class="';
     if($xsrch_6!=''){$o1.=' yybackgroundYellow';}
     $o1.='" '.($autofocus=='xsrch_6'?'autofocus="autofocus"':'').' />'.CRLF;
     $o1.='<option value="" '.($xsrch_6==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
     foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
      if((string)$kp==(string)$xsrch_6){
       $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
      }else{
       $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
      }
     }
     $o1.='    </select>';
     $o1.='   </div>'.CRLF;


     $o1.='   <div>'.CRLF;
     $o1.='    <label for="xsrch_id">'.txt2('fld_id_users_239_157').'</label>'.CRLF; // fld_id_users
     $o1.='    <input class=" ';
     if($xsrch_id!=''){$o1.=' yybackgroundYellow';}
     $o1.=     '" type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32"';
     $o1.=' '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
     $o1.='   </div>'.CRLF;

     $o1.='   <div>'.CRLF;
     $o1.='    <button class="button_search">&#128270;</button>'.CRLF;
     $o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
     $o1.='   </div>'.CRLF;

     $o1.=' </form>'.CRLF;
     //====================================================================================================
     $__start=$__xpage*$__nbMax;
     $_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
     $lst='';
     if($_SESSION[PGMK]['loginInit']==1){
      $req6='
       SELECT  SQL_CALC_FOUND_ROWS   
         T0.`fld_id_users`           ,T0.`fld_login_users`        ,T0.`fld_email_users`        ,T0.`fld_loginisemail_users` ,                      1     ,
         T0.`fld_group_id_users`     ,T0.`fld_active_users`       ,T0.`fld_translate_users`    ,T0.`fld_firstname_users`    ,T0.`fld_lastname_users`     ,
         T1.`fld_category_groups`
       FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users`  T0 ,
            `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T1 
       WHERE fld_group_id_users <> 2 
         AND T1.`fld_id_groups`        = T0.`fld_group_id_users`
      ';
     }else if($_SESSION['isLocalAdmin']){
      $req6='
       SELECT  SQL_CALC_FOUND_ROWS   
         T0.`fld_id_users`           ,T0.`fld_login_users`        ,T0.`fld_email_users`        ,T0.`fld_loginisemail_users` ,                      1     ,
         T0.`fld_group_id_users`     ,T0.`fld_active_users`       ,T0.`fld_translate_users`    ,T0.`fld_firstname_users`    ,T0.`fld_lastname_users`     ,
         T1.`fld_category_groups`
       FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__users`  T0 ,
            `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T1 
       WHERE fld_group_id_users        <> 2 
         AND T1.`fld_id_groups`        = T0.`fld_group_id_users`
         AND ( T1.`fld_parent_id_groups` = '.$_SESSION[PGMK]['groupInit'].' OR T1.`fld_root_group_id_groups` = '.$_SESSION[PGMK]['groupInit'].' )
      ';
     }
     if($xsrch_0!='' ){
      $req6.='
       AND T0.`fld_login_users` LIKE \'%'.$xsrch_0.'%\'
      '; 
     }
     if($xsrch_1!='' ){
      $req6.='
       AND T0.`fld_email_users` LIKE \'%'.$xsrch_1.'%\'
      '; 
     }
     if($xsrch_4!='' && is_numeric($xsrch_4)){
      $req6.='
       AND T0.`fld_group_id_users` = '.$xsrch_4.'
      '; 
     }

     if($xsrch_5!='' && is_numeric($xsrch_5)){
      $req6.='
       AND T0.`fld_active_users` = '.$xsrch_5.'
      '; 
     }
     if($xsrch_6!='' && is_numeric($xsrch_6)){
      $req6.='
       AND T0.`fld_translate_users` = '.$xsrch_6.'
      '; 
     }
     if($xsrch_7!='' ){
      $req6.='
       AND T0.`fld_firstname_users` LIKE \'%'.$xsrch_7.'%\'
      '; 
     }
     if($xsrch_8!='' ){
      $req6.='
       AND T0.`fld_lastname_users` LIKE \'%'.$xsrch_8.'%\'
      '; 
     }
     if($xsrch_id!='' && is_numeric($xsrch_id)){
      $req6.='
       AND T0.`fld_id_users` = '.$xsrch_id.'
      '; 
     }
     $req6.='
      ORDER BY T0.`fld_id_users` ASC 
     '; 
     $req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
     //echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
     $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
     if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
      $reqCount6='SELECT FOUND_ROWS();';
      $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
      if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
       $mpsrcount6=mysqli_fetch_row($rescount6);
       $__count=$mpsrcount6[0];
      }
      $lsttbl='';
      if($__count==0){
       $lst.='<p>'.CRLF;
       $lst.=''.txt2('no_record_founded_449_22').''.CRLF;
       $lst.='</p>'.CRLF;
       $o1.=''.$lst.''.CRLF;  
      }else{
       $consUrlRedir=''.
                     '&amp;xsrch_0='.rawurlencode($xsrch_0). // fld_login_users 
                     '&amp;xsrch_1='.rawurlencode($xsrch_1). // fld_email_users 
                     '&amp;xsrch_4='.rawurlencode($xsrch_4). // fld_group_id_users 
                     '&amp;xsrch_5='.rawurlencode($xsrch_5). // fld_active_users 
                     '&amp;xsrch_6='.rawurlencode($xsrch_6). // fld_translate_users 
                     '&amp;xsrch_7='.rawurlencode($xsrch_7). // fld_firstname_users 
                     '&amp;xsrch_8='.rawurlencode($xsrch_8). // fld_lastname_users 
                     '&amp;xsrch_id='.rawurlencode($xsrch_id).
                     '';
       $ri=' <span class="yybtn yyunset">&raquo;</span>';
       if($__start+$__nbMax<$__count){
        $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
       }
       $le=' <span class="yybtn yyunset">&laquo;</span>';
       if($__xpage>0){
        $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
       }
       $o1.='<div>';
       $o1.='<form method="post">';
       $o1.='&nbsp;'.$le.''.CRLF;  
       $o1.='&nbsp;'.$ri.''.CRLF;  
       $o1.='</form>';
       $o1.='</div>';

       $o1.=getCss1(890); // todo adjust size


       $lsttbl.='<thead><tr>';
       $lsttbl.='<th>'.txtsys1('column_action').'</th>';
       $lsttbl.='<th>'.txt2('fld_id_users_239_157').'</th>';
       $lsttbl.='<th>'.txt2('fld_login_users_258_67').'</th>';
       $lsttbl.='<th>'.txt2('fld_email_users_267_67').'</th>';
       $lsttbl.='<th>'.txt2('fld_firstname_users_337_67').'</th>';
       $lsttbl.='<th>'.txt2('fld_lastname_users_346_67').'</th>';
       $lsttbl.='<th>'.txt2('fld_loginisemail_users_276_67').'</th>';
       $lsttbl.='<th>'.txt2('fld_active_users_303_67').'</th>';
       $lsttbl.='<th>'.txt2('fld_group_id_users_234_157').'</th>';
       $lsttbl.='<th>'.txt2('fld_category_groups_576_29').'</th>';
       $lsttbl.='<th>'.txt2('fld_translate_users_320_67').'</th>';
       $lsttbl.='</tr></thead><tbody>';
       while($mpsr6=mysqli_fetch_row($result6)){
        
        $lsttbl.='<tr><td class="yyfictif"></td>';

        $lsttbl.='<td data-label="" style="text-align:left!important;">';
        $lsttbl.='<div>';
        if($_SESSION[PGMK]['login']!=$mpsr6[0]){
         $lsttbl.='<a class="yytxtSiz1 yysuccess" href="'.BNF.'?a=useThisProfile&amp;fld_id_users='.$mpsr6[0].'&fld_group_id_users='.$mpsr6[5].'" title="'.txt2('use this profile_527_133').'">⇒</a>';
        }else{
         $lsttbl.='<span class="yytxtSiz1 yysuccess yybtn yyunset" title="'.txt2('use this profile_527_133').'">⇒</a>';
        }
        $lsttbl.='</div>';
        $lsttbl.='</td>';

        $lsttbl.='<td data-label="'.txt2('fld_id_users_239_157').'" style="text-align:right;">';
        $lsttbl.=''.enti1($mpsr6[0]).''; // fld_id_users
        $lsttbl.='</td>';

        $lsttbl.='<td data-label="'.txt2('fld_login_users_258_67').'">';
        $lsttbl.=''.enti1($mpsr6[1]).''; // fld_login_users
        $lsttbl.='</td>';

        $lsttbl.='<td data-label="'.txt2('fld_email_users_267_67').'">';
        $lsttbl.=''.enti1($mpsr6[2]).''; // fld_email_users
        $lsttbl.='</td>';

        $lsttbl.='<td data-label="'.txt2('fld_firstname_users_337_67').'">';
        $lsttbl.=''.enti1($mpsr6[8]).''; // fld_firstname_users
        $lsttbl.='</td>';

        $lsttbl.='<td data-label="'.txt2('fld_lastname_users_346_67').'">';
        $lsttbl.=''.enti1($mpsr6[9]).''; // fld_lastname_users
        $lsttbl.='</td>';

        $lsttbl.='<td data-label="'.txt2('fld_loginisemail_users_276_67').'" style="text-align:center;">';
        require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
        $lsttbl.=displayParam1('yorno',$mpsr6[3]); // fld_loginisemail_users
        $lsttbl.='</td>';

        $lsttbl.='<td data-label="'.txt2('fld_active_users_303_67').'" style="text-align:center;">';
        require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
        $lsttbl.=displayParam1('yorno',$mpsr6[6]); // fld_active_users
        $lsttbl.='</td>';
        
        $lsttbl.='<td data-label="'.txt2('fld_group_id_users_234_157').'"  style="text-align:right;">';
        $lsttbl.=''.enti1($mpsr6[5]).''; // fld_group_id_users
        $lsttbl.='</td>';

        $lsttbl.='<td data-label="'.txt2('fld_category_groups_576_29').'" style="text-align:center;">';
        $lsttbl.=displayParam1('group_category',$mpsr6[10],array('unsetPossible'=>false)); // fld_category_groups
        $lsttbl.='</td>';
        

        $lsttbl.='<td data-label="'.txt2('fld_translate_users_320_67').'" style="text-align:center;">';
        require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
        $lsttbl.=displayParam1('yorno',$mpsr6[7]); // fld_translate_users
        $lsttbl.='</td>';

        $lsttbl.='</tr>';
        
       }
       $o1.='<table class="yytableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;
        
       $o1.=' <div>'.CRLF;
       $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_599_104').' )'.CRLF;
       $o1.=' </div>'.CRLF;
      }
      mysqli_free_result($result6);
     }else{
      $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
     }
 
 
 
}

//====================================================================================================
$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
