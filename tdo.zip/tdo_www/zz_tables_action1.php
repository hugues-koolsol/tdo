<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
require_once($GLOBALS['glob_incPath1'].'/__param_restore_transform.php');
checkGroupPages();
require_once $GLOBALS['glob_incPath1'].'/zz_inc_tables1.php';

openDb1();
//========================================================================================================================
function btl1(){
 return ' <a href="zz_tables1.php" class="">'.txtsys1('back_to_the_list').'</a>';
}
//========================================================================================================================
function writeRemoteTableList(){
 $req6='
  SELECT
    T0.`fld_id_tables`                ,T0.`fld_id_server_tables` ,T0.`fld_name_tables`      ,T0.`fld_system_tables`    , T0.`fld_view_tables`              ,
    T0.`fld_id_reftbl_of_view_tables` ,T1.`fld_name_tables`      ,T0.`fld_log_tables`       ,T0.`fld_remote_tables`    , T0.`fld_restore_transform_tables`
  FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T0 ) 
  LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables`  T1 ON T0.`fld_id_reftbl_of_view_tables` = T1.`fld_id_tables`
  WHERE T0.`fld_view_tables`   = 0 
    AND T0.`fld_remote_tables` = 1
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $data0[]=array(
    'T0.fld_id_tables'                => $mpsr6[0],
    'T0.fld_id_server_tables'         => $mpsr6[1],
    'T0.fld_name_tables'              => $mpsr6[2],
    'T0.fld_system_tables'            => $mpsr6[3],
    'T0.fld_view_tables'              => $mpsr6[4],
    'T0.fld_id_reftbl_of_view_tables' => $mpsr6[5],
    'T1.fld_name_tables'              => $mpsr6[6],  
    'T0.fld_log_tables'               => $mpsr6[7],
    'T0.fld_remote_tables'            => $mpsr6[8],
    'T0.fld_restore_transform_tables' => $mpsr6[9],
   );
  }
  mysqli_free_result($result6);
  if(sizeof($data0)>0){
   $reqCount6='SELECT FOUND_ROWS();';
   $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    $mpsrcount6=mysqli_fetch_row($rescount6);
    $__count=$mpsrcount6[0];
   }
  }
 }else{
  $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2(' In writeRemoteTableList sql=_52_87').$req6;
  return;
 }
 $tabFichiers=array();
 foreach($data0 as $k1=>$v1){
  $tabFichiers[$v1['T0.fld_name_tables']]=array(
   'fld_id_tables' => $v1['T0.fld_id_tables'],
   'fld_restore_transform_tables' => $v1['T0.fld_restore_transform_tables'],
   'fld_id_server_tables'         => $v1['T0.fld_id_server_tables'],
   'fld_view_tables'              => $v1['T0.fld_view_tables'],
   'fld_log_tables'               => $v1['T0.fld_log_tables'],
  );
 }
 if($fd=fopen($GLOBALS['glob_incPath1'].'/__remoteTables.php','w')){
  fwrite($fd,'<'.'?php'."\r\n".'$GLOBALS[\'__remoteTables\']='.var_export($tabFichiers,true).';');
  fclose($fd);
 }
}
//========================================================================================================================
function test_input_tdo_tablesKO1(){
 $err=0;
 if($err==0&&!is_numeric($_SESSION[PGMK][NAV][BNF]['fld_id_server_tables'])){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_id_server_tables must be numerical_18_92');
  $err=1;
 }
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_name_tables']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_name_tables must not be empty_22_92');
  $err=1;
 }
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_system_tables']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_system_tables must not be empty_26_92');
  $err=1;
 }
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_view_tables']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_view_tables must not be empty_30_92');
  $err=1;
 } 
 
 if($err==0&&is_numeric($_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables'])&&$_SESSION[PGMK][NAV][BNF]['fld_view_tables']=='0'){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('a table reference must be given only for a view_35_92');
  $err=1;
 }
 
 if($err==0&&!is_numeric($_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables'])&&$_SESSION[PGMK][NAV][BNF]['fld_view_tables']=='1'){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('a table reference must be given for a view_40_92');
  $err=1;
 }
 
 if($err==0&& $_SESSION[PGMK][NAV][BNF]['fld_view_tables']=='1' && $_SESSION[PGMK][NAV][BNF]['fld_log_tables']=='1'){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('views cannot be logged_45_92');
  $err=1;
 }
 
 
 
 return($err);
}
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= POST ACTIONS  =====================================================================
 //=================================================================================================================================
 //=================================================================================================================================
// echo __LINE__ . '$_POST=<pre>' . var_export($_POST,true) . '</pre>'; exit();
 $_SESSION[PGMK][NAV][BNF]['fld_id_server_tables']         =isset($_POST['fld_id_server_tables'])         ?$_POST['fld_id_server_tables']         : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_name_tables']              =isset($_POST['fld_name_tables'])              ?$_POST['fld_name_tables']              : '';
 $_SESSION[PGMK][NAV][BNF]['fld_system_tables']            =isset($_POST['fld_system_tables'])            ?$_POST['fld_system_tables']            : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_view_tables']              =isset($_POST['fld_view_tables'])              ?$_POST['fld_view_tables']              : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables'] =isset($_POST['fld_id_reftbl_of_view_tables']) ?$_POST['fld_id_reftbl_of_view_tables'] : ''; // null possible
 $_SESSION[PGMK][NAV][BNF]['fld_log_tables']               =isset($_POST['fld_log_tables'])               ?$_POST['fld_log_tables']               : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_remote_tables']            =isset($_POST['fld_remote_tables'])            ?$_POST['fld_remote_tables']            : 1;
 $_SESSION[PGMK][NAV][BNF]['fld_restore_transform_tables'] =isset($_POST['fld_restore_transform_tables']) ?$_POST['fld_restore_transform_tables'] : '';
 
 // dependant field fetch choose 
 if(!(isset($_POST['a'])&&($_POST['a']=='cd'||$_POST['a']=='cd'))){ // NOT confirm delete
  $_SESSION[PGMK][NAV][BNF]['choose__fld_id_reftbl_of_view_tables'] =isset($_POST['choose__fld_id_reftbl_of_view_tables'] )?$_POST['choose__fld_id_reftbl_of_view_tables']  :'';
  if($_SESSION[PGMK][NAV][BNF]['choose__fld_id_reftbl_of_view_tables']==txtsys1('text_for_the_select_button')){
   $_SESSION[PGMK]['choose']['urlBack']=$_SERVER['HTTP_ORIGIN'].$_SERVER['REQUEST_URI'];
   header('Location: zz_tables_choose1.php');
   exit();
  }
 }
 
 
 //=================================================================================================================================
 //============================================= POST UPDATE =======================================================================
 //=================================================================================================================================
 if(isset($_POST['a'])&&$_POST['a']=='u'){ // update action
  if(test_input_tdo_tablesKO1()){
   if(isset($_POST['id1'])&&is_numeric($_POST['id1'])){
    header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }else{
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : POST id1 = ' . $_POST['id1'];
    header('Location: index.php');
    exit();
   }
  }
  $req6="UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tables` SET
      `fld_id_server_tables`         =  ".$_SESSION[PGMK][NAV][BNF]['fld_id_server_tables']              ."
    , `fld_name_tables`              = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_name_tables'])      ."'
    , `fld_system_tables`            = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_system_tables'])    ."'
    , `fld_view_tables`              = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_view_tables'])      ."'
    , `fld_id_reftbl_of_view_tables` = ".($_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables']==''?'NULL':addslashes1($_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables']))."
    , `fld_log_tables`               =  ".$_SESSION[PGMK][NAV][BNF]['fld_log_tables']                    ."
    , `fld_remote_tables`            =  ".$_SESSION[PGMK][NAV][BNF]['fld_remote_tables']                 ."
    , `fld_restore_transform_tables` = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_restore_transform_tables']) ."'
    , `fld_tsupd_tables`             = '".addslashes1($GLOBALS['glob_setdate'])                          ."'
    , `fld_cntupd_tables`            =  " . ((int)$_POST['fld_cntupd_tables']+1)                         ."
  ";
  $req6.="
   WHERE `fld_id_tables`=".$_POST['id1']."
     AND `fld_cntupd_tables` = ".$_POST['fld_cntupd_tables']."
  ";
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
     break;
    default   :
     $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    break;
   }
   header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
  }else{
   if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])!=1){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('this_record_has_not_been_updated_because_of_an_other_user');
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('please_retry');
    unset($_SESSION[PGMK][NAV][BNF]['fld_id_server_tables']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_name_tables']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_system_tables']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_view_tables']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_log_tables']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_remote_tables']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_restore_transform_tables']);
    header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
   }
   require_once $GLOBALS['glob_incPath1'].'/zz_inc_tablelinks1.php';
   writeTableDependencies1();
   writeRemoteTableList();
   if(isset($_POST['save_the_modification_and_back_to_list'])){
    header('Location: zz_tables1.php');
    exit();
   }else{
    $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('the_modification_has_been_recorded_at') . ' ' . substr($GLOBALS['glob_setdate'],11);
    if(isset($_POST['record_the_element_and_back_to_list'])){
     header('Location: zz_tables1.php');
     exit();
    }else if(isset($_POST['record_the_element_and_back_to_generate'])){
     header('Location: zz_generateSources1.php?m=1');
     exit();
    }else{
     header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    }
    exit();
   }
  }
 //=================================================================================================================================
 //============================================= POST CONFIRM DELETE ===============================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='cd'){
 
  require_once $GLOBALS['glob_incPath1'].'/__tableDependencies1.php';
  $retDependantTables=dependentValuesExist1(0,'tdo_tbl__tables',$_POST['id1'] );
  if(true === $retDependantTables['valuesExist']){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' . txtsys1('you_cannot_delete_because_some_values_are_still_present_in_dependant_table') . ' ' . var_export( $retDependantTables['tables'] , true ) . ' ';
   header('Location: '.BNF.'?a=d&id='.$_POST['id1']);   
  }

//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tables` WHERE `fld_id_tables`=".$_POST['id1']." " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
   txtlog1($xtxterr , BNF , __LINE__ , 'error' );
   header('Location: '.BNF.'?a=d&id='.$_POST['id1']);
   exit();
  }else{
   unset($_SESSION[PGMK][NAV][BNF]);
   require_once $GLOBALS['glob_incPath1'].'/zz_inc_tablelinks1.php';
   writeTableDependencies1();
   writeRemoteTableList();
   header('Location: zz_tables1.php');
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CREATE ACTION ================================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='c'){
  if(test_input_tdo_tablesKO1()){
   header('Location: '.BNF.'?a=c');
   exit();
  }
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__tables` SET
      `fld_id_server_tables`         =  ".$_SESSION[PGMK][NAV][BNF]['fld_id_server_tables']              ."
    , `fld_name_tables`              = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_name_tables'])      ."'
    , `fld_system_tables`            = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_system_tables'])    ."'
    , `fld_view_tables`              = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_view_tables'])      ."'
    , `fld_id_reftbl_of_view_tables` = ".($_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables']==''?'NULL':addslashes1($_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables']))."
    , `fld_log_tables`               =  ".$_SESSION[PGMK][NAV][BNF]['fld_log_tables']                    ."
    , `fld_remote_tables`            =  ".$_SESSION[PGMK][NAV][BNF]['fld_remote_tables']                 ."
    , `fld_restore_transform_tables` = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_restore_transform_tables']) ."'
    , `fld_tsupd_tables`             = '".addslashes1($GLOBALS['glob_setdate'])                          ."'
    , `fld_tscrt_tables`             = '".addslashes1($GLOBALS['glob_setdate'])                          ."'
  " ;
//  echo __FILE__ . ' ' . __LINE__ . ' $req6 =' . $req6 . '' ; exit();
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
    break;
    default;
    $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    break;
   }
   header('Location: '.BNF.'?a=c');
   exit();
  }else{
   $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    header('Location: '.BNF.'?a=c');
    exit();
   }else{
    $NewCode=mysqli_fetch_row($resIns);
    $NewCode=$NewCode[0];
    mysqli_free_result($resIns);
    SetSessionMessageAndLog1( txt2('the new value has been inserted_174_36') . ' ('.$NewCode.').' , BNF , __LINE__ , 'information');
    require_once $GLOBALS['glob_incPath1'].'/zz_inc_tablelinks1.php';
    writeTableDependencies1();
    writeRemoteTableList();
    if(isset($_POST['record_the_element_and_back_to_list'])){
     header('Location: zz_tables1.php');
     exit();
    }else if(isset($_POST['record_the_element_and_back_to_generate'])){
     header('Location: zz_generateSources1.php?m=1');
     exit();
    }else{
     header('Location: '.BNF.'?a=u&t=n&id='.$NewCode);
     exit();
    }
   }
  }
 }
 
}else{ // get action

 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= GET ACTION ========================================================================
 //=================================================================================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='du'){ // duplicate action
  $xxxFldValues=array();
  $name2=getTdo_tables1($_GET['id']);
  if($name2['fld_id_tables']==''){
   $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_duplicate_this_value');
   header('Location: zz_tables1.php');
   exit();
  }else{
   $_SESSION[PGMK][NAV][BNF]['fld_id_server_tables']         =$name2['fld_id_server_tables'];
   $_SESSION[PGMK][NAV][BNF]['fld_name_tables']              =$name2['fld_name_tables'];
   $_SESSION[PGMK][NAV][BNF]['fld_system_tables']            =$name2['fld_system_tables'];
   $_SESSION[PGMK][NAV][BNF]['fld_view_tables']              =$name2['fld_view_tables'];   
   $_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables'] =$name2['fld_id_reftbl_of_view_tables'];
   $_SESSION[PGMK][NAV][BNF]['fld_log_tables']               =$name2['fld_log_tables'];
   $_SESSION[PGMK][NAV][BNF]['fld_remote_tables']            =$name2['fld_remote_tables'];
   $_SESSION[PGMK][NAV][BNF]['fld_restore_transform_tables'] =$name2['T0_fld_restore_transform_tables'];
   header('Location: '.BNF.'?a=c' );
   exit();
  }
 }
 
 $o1=htmlHead1(array());
 $js1=array();
// echo __LINE__ . '$_SESSION[PGMK]=<pre>' . var_export( $_SESSION[PGMK] , true ) . '</pre>'; exit();
 //=================================================================================================================================
 //============================================= GET DELETE ========================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='d'){ // delete action
  $id=(isset($_GET['id'])&&is_numeric($_GET['id']))?$_GET['id']:0;
  if($id==0){
   header('Location: zz_tables1.php');
   exit();
  }else{
   $xvalueName=getTdo_tables1($_GET['id']);
   if($xvalueName['fld_id_tables']==''){
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_delete_this_value');
    header('Location: zz_tables1.php');
    exit();
   }else{
    require_once $GLOBALS['glob_incPath1'].'/__tableDependencies1.php';
    $retDependantTables=dependentValuesExist1(0,'tdo_tbl__tables',$_GET['id'] );
    if(isset($retDependantTables['valuesExist']) && $retDependantTables['valuesExist']==true){
     $o1.=displaySessionMessage1(BNF);
     $o1.='<div style="text-align:center;">'.CRLF;
     $o1.=' <div class="yyerror yymessageBox" >'.txtsys1('error') . ' ' . __LINE__ . ' '.txtsys1('dependent_values_exist').'</div>'.CRLF;
     $o1.=' <ul style="list-style:none;padding:0;">';
     foreach( $retDependantTables['tables'] as $k1 => $v1){
      $o1.='<li>'.$v1.'</li>';
     }
     $o1.='</ul>'.CRLF;
     $o1.=btl1();
     $o1.='</div>'.CRLF;
    }else{
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <form method="post" class="yyformDelete">'.CRLF;
     $o1.='   '.txtsys1('please_confirm_deletion_of').' : '.CRLF;
     $o1.='   <br /><br /><b>'.
          '('.$xvalueName['fld_id_tables'].') '.
          txt2('fld_name_tables_248_16') . ' : ' .$xvalueName['fld_name_tables'].' <br /> '.
          '</b><br />'.CRLF;
     $o1.='   <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
     $o1.='   <input type="hidden" value="cd" name="a" id="a" />'."\r\n";
     $o1.='   <button type="submit" class="yydanger">'.txtsys1('i_confirm_the_deletion_button').'</button>'.CRLF;
     $o1.=btl1();
     $o1.=' </form>'."\r\n";
    }
   }
  }
 //=================================================================================================================================
 //============================================= GET UPDATE ========================================================================
 //=================================================================================================================================
 
 }else if(isset($_GET['a'])&&$_GET['a']=='u'){ // update action
  $xxxFldValues=array();
  $js1=array();
  $o1.='<h4>'.txt2('update a record_265_20').' ('.$_GET['id'].')'.btl1().'</h4>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $name2=getTdo_tables1($_GET['id']);
  $xxxFldValues['fld_id_server_tables']         =isset( $_SESSION[PGMK][NAV][BNF]['fld_id_server_tables'] )         ? $_SESSION[PGMK][NAV][BNF]['fld_id_server_tables']         : $name2['fld_id_server_tables']         ;
  $xxxFldValues['fld_name_tables']              =isset( $_SESSION[PGMK][NAV][BNF]['fld_name_tables'] )              ? $_SESSION[PGMK][NAV][BNF]['fld_name_tables']              : $name2['fld_name_tables']              ;
  $xxxFldValues['fld_system_tables']            =isset( $_SESSION[PGMK][NAV][BNF]['fld_system_tables'] )            ? $_SESSION[PGMK][NAV][BNF]['fld_system_tables']            : $name2['fld_system_tables']            ;
  $xxxFldValues['fld_view_tables']              =isset( $_SESSION[PGMK][NAV][BNF]['fld_view_tables'] )              ? $_SESSION[PGMK][NAV][BNF]['fld_view_tables']              : $name2['fld_view_tables']              ;
  $xxxFldValues['fld_id_reftbl_of_view_tables'] =isset( $_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables'] ) ? $_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables'] : $name2['fld_id_reftbl_of_view_tables'] ;
  $xxxFldValues['fld_log_tables']               =isset( $_SESSION[PGMK][NAV][BNF]['fld_log_tables'] )               ? $_SESSION[PGMK][NAV][BNF]['fld_log_tables']               : $name2['fld_log_tables']               ;
  $xxxFldValues['fld_remote_tables']            =isset( $_SESSION[PGMK][NAV][BNF]['fld_remote_tables'] )            ? $_SESSION[PGMK][NAV][BNF]['fld_remote_tables']            : $name2['fld_remote_tables']            ;
  $xxxFldValues['fld_restore_transform_tables'] =isset( $_SESSION[PGMK][NAV][BNF]['fld_restore_transform_tables'] ) ? $_SESSION[PGMK][NAV][BNF]['fld_restore_transform_tables'] : $name2['fld_restore_transform_tables'] ;


  $o1.='<form method="post" >'.CRLF;

  $o1.=' <input type="hidden" value="u" name="a" id="a" />'.CRLF;
  $o1.=' <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_id_server_tables_278_42').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_id_server_tables']).'" name="fld_id_server_tables" id="fld_id_server_tables" maxlength="12" style="width:100;max-width:12em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_name_tables_248_16').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_name_tables']).'" name="fld_name_tables" id="fld_name_tables" maxlength="128" style="width:100%;max-width:130em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_system_tables_293_42').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $retParam=displayParam2('yorno',$xxxFldValues['fld_system_tables'],'fld_system_tables',array('unsetPossible'=>false,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_view_tables_311_42').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $retParam=displayParam2('yorno',$xxxFldValues['fld_view_tables'],'fld_view_tables',array('unsetPossible'=>false,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $xDisplayValueFetch = '' ;
  if(
   isset($_SESSION[PGMK][NAV][BNF]['choose__fld_id_reftbl_of_view_tables'])&&
   $_SESSION[PGMK][NAV][BNF]['choose__fld_id_reftbl_of_view_tables']==txtsys1('text_for_the_select_button')&&
   isset($_SESSION[PGMK]['choose']['valueBack'])
  ){
   if($_SESSION[PGMK][NAV][BNF]['choose__fld_id_reftbl_of_view_tables']==txtsys1('text_for_the_select_button')){
    $xxxFldValues['fld_id_reftbl_of_view_tables']=$_SESSION[PGMK]['choose']['valueBack'];
   }
   unset($_SESSION[PGMK]['choose']);
  }
  if($xxxFldValues['fld_id_reftbl_of_view_tables']!=null){
   $xGroupValues=getTdo_tables1($xxxFldValues['fld_id_reftbl_of_view_tables']);
   $xDisplayValueFetch = ' ' .
                         $xGroupValues['fld_name_tables'] . ' , ' .
                         ' (' . $xGroupValues['fld_id_tables'] . ')' . '' ;
  }else{
   $xDisplayValueFetch = '';    
  }
   
  $o1.='  <div class="yyfdiv1">'.CRLF;
  $o1.='   <div class="yyflab1"><div style="word-break:break-word;">'.txt2('parent_fld_id_reftbl_of_view_tables_345_74').'</div></div>'.CRLF;
  $o1.='   <div class="yyfinp1"><div>'.CRLF;
  $o1.='    <input type="hidden" value="'.enti1($xxxFldValues['fld_id_reftbl_of_view_tables']).'" name="fld_id_reftbl_of_view_tables" id="fld_id_reftbl_of_view_tables" />'.CRLF;
  $o1.='     <span id="span__dep_fld_id_reftbl_of_view_tables">'.$xDisplayValueFetch.'</span>';
  $o1.='    <button type="submit" name="choose__fld_id_reftbl_of_view_tables" class="" value="'. txtsys1('text_for_the_select_button') . '">';
  $o1.=''   . txtsys1('text_for_the_select_button') . '';
  $o1.=     '</button>'."\r\n";
  $o1.='    <button type="button" class="yywarning" onclick="razDependant1(\'span__dep_fld_id_reftbl_of_view_tables\',\'fld_id_reftbl_of_view_tables\')">';
  $o1.=''   . txtsys1('raz_button') . '';
  $o1.=     '</button>'."\r\n";
  $o1.='   </div></div>'.CRLF;
  $o1.='  </div>'.CRLF;

  
  
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div style="word-break:break-word;">'.txt2('fld_log_tables_404_73').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $retParam=displayParam2('yorno',$xxxFldValues['fld_log_tables'],'fld_log_tables',array('unsetPossible'=>false,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div style="word-break:break-word;">'.txt2('fld_remote_tables_419_73').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $retParam=displayParam2('yorno',$xxxFldValues['fld_remote_tables'],'fld_remote_tables',array('unsetPossible'=>false,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div style="word-break:break-word;">'.txt2('fld_restore_transform_tables_489_73').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $retParam=displayParam2('restore_transform',$xxxFldValues['fld_restore_transform_tables'],'fld_restore_transform_tables',array('unsetPossible'=>true,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  

  $o1.='<div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <input type="hidden" name="fld_cntupd_tables" id="fld_cntupd_tables" value="'.$name2['fld_cntupd_tables'].'" />'.CRLF;
  $o1.='   <button type="submit" class="">'.txtsys1('save_the_modification').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="save_the_modification_and_back_to_list">'.txtsys1('save_the_modification_and_back_to_list').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="record_the_element_and_back_to_generate">'.txt2('record_the_element_and_back_to_genetate_419_97').'</button>'.CRLF;
  $o1.='   <a href="zz_generateSources1.php?m=1" class="yywarning" >'.txt2('go to generate_420_74').'</a>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.='</div>'.CRLF;

  $o1.='</form>'.CRLF;

 //=================================================================================================================================
 //============================================= GET VIEW ==========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='v'&&isset($_GET['id'])&&is_numeric($_GET['id'])){ // view action
  // if you vant to do something here, go !
 //=================================================================================================================================
 //============================================= GET CREATE ========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='c'){ // create action
 
  $o1.='<h2>'.txt2('Add a new record_321_20'). ' '.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $o1.='<form method="post" class="form1">'.CRLF;
 

  $fld_id_server_tables =isset($_SESSION[PGMK][NAV][BNF]['fld_id_server_tables'] )?$_SESSION[PGMK][NAV][BNF]['fld_id_server_tables']:0;
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_id_server_tables_278_42').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_id_server_tables).'" name="fld_id_server_tables" id="fld_id_server_tables" maxlength="12" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  if(isset($_GET['new'])){ 
   $_SESSION[PGMK][NAV][BNF]['fld_name_tables']=$_GET['new'];
  }
  $fld_name_tables =isset($_SESSION[PGMK][NAV][BNF]['fld_name_tables'] )?$_SESSION[PGMK][NAV][BNF]['fld_name_tables']:'';
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_name_tables_248_16').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_name_tables).'" name="fld_name_tables" id="fld_name_tables" maxlength="128" style="width:100%;max-width:130em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $fld_system_tables =isset($_SESSION[PGMK][NAV][BNF]['fld_system_tables'] )?$_SESSION[PGMK][NAV][BNF]['fld_system_tables']:'';
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_system_tables_293_42').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $retParam=displayParam2('yorno',$fld_system_tables,'fld_system_tables',array('unsetPossible'=>false,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  
  if(isset($_GET['view'])){ 
   $_SESSION[PGMK][NAV][BNF]['fld_view_tables']='1';
  }
  $fld_view_tables =isset($_SESSION[PGMK][NAV][BNF]['fld_view_tables'] )?$_SESSION[PGMK][NAV][BNF]['fld_view_tables']:'';
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div>'.txt2('fld_view_tables_311_42').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $retParam=displayParam2('yorno',$fld_view_tables,'fld_view_tables',array('unsetPossible'=>false,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  
  $fld_id_reftbl_of_view_tables=isset($_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables'] )?$_SESSION[PGMK][NAV][BNF]['fld_id_reftbl_of_view_tables']:null;
  if(
   isset($_SESSION[PGMK][NAV][BNF]['choose__fld_id_reftbl_of_view_tables'])&&
   $_SESSION[PGMK][NAV][BNF]['choose__fld_id_reftbl_of_view_tables']==txtsys1('text_for_the_select_button')&&
   isset($_SESSION[PGMK]['choose']['valueBack'])
  ){
   if($_SESSION[PGMK][NAV][BNF]['choose__fld_id_reftbl_of_view_tables']==txtsys1('text_for_the_select_button')){
    $fld_id_reftbl_of_view_tables=$_SESSION[PGMK]['choose']['valueBack'];
   }
   unset($_SESSION[PGMK]['choose']);
  }
  if($fld_id_reftbl_of_view_tables!=null){
  $xGroupValues=getTdo_tables1($fld_id_reftbl_of_view_tables);
   $xDisplayValueFetch = ' ' .
                         $xGroupValues['fld_name_tables'] . ' , ' .
                         ' (' . $xGroupValues['fld_id_tables'] . ')' . '' ;
  }else{
   $xDisplayValueFetch = '';    
  }
  $o1.='  <div class="yyfdiv1">'.CRLF;
  $o1.='   <div class="yyflab1"><div style="word-break:break-word;">'.txt2('parent_fld_id_reftbl_of_view_tables_345_74').'</div></div>'.CRLF;
  $o1.='   <div class="yyfinp1"><div>'.CRLF;
  $o1.='    <input type="hidden" value="'.enti1($fld_id_reftbl_of_view_tables).'" name="fld_id_reftbl_of_view_tables" id="fld_id_reftbl_of_view_tables" />'.CRLF;
  $o1.='     <span id="span__dep_fld_id_reftbl_of_view_tables">'.$xDisplayValueFetch.'</span>';
  $o1.='    <button type="submit" name="choose__fld_id_reftbl_of_view_tables" class="yybtn" value="'. txtsys1('text_for_the_select_button') . '">';
  $o1.=''   . txtsys1('text_for_the_select_button') . '';
  $o1.=     '</button>'."\r\n";
  $o1.='    <button type="button" class="yywarning" onclick="razDependant1(\'span__dep_fld_id_reftbl_of_view_tables\',\'fld_id_reftbl_of_view_tables\')">';
  $o1.=''   . txtsys1('raz_button') . '';
  $o1.=     '</button>'."\r\n";
  $o1.='   </div></div>'.CRLF;
  $o1.='  </div>'.CRLF;

  if(isset($_GET['view'])){ 
   $_SESSION[PGMK][NAV][BNF]['fld_log_tables']='0';
  }  
  $fld_log_tables =isset($_SESSION[PGMK][NAV][BNF]['fld_log_tables'] )?$_SESSION[PGMK][NAV][BNF]['fld_log_tables']:'1';
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div style="word-break:break-word;">'.txt2('fld_log_tables_404_73').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $retParam=displayParam2('yorno',$fld_log_tables,'fld_log_tables',array('unsetPossible'=>false,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  
  if(isset($_GET['view'])){ 
   $_SESSION[PGMK][NAV][BNF]['fld_remote_tables']='1';
  }  
  $fld_remote_tables =isset($_SESSION[PGMK][NAV][BNF]['fld_remote_tables'] )?$_SESSION[PGMK][NAV][BNF]['fld_remote_tables']:'1';
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div style="word-break:break-word;">'.txt2('fld_remote_tables_419_73').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $retParam=displayParam2('yorno',$fld_remote_tables,'fld_remote_tables',array('unsetPossible'=>false,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  
  
  $fld_restore_transform_tables =isset($_SESSION[PGMK][NAV][BNF]['fld_restore_transform_tables'] )?$_SESSION[PGMK][NAV][BNF]['fld_restore_transform_tables']:'';
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyflab1"><div style="word-break:break-word;">'.txt2('fld_restore_transform_tables_489_73').'</div></div>'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $retParam=displayParam2('restore_transform',$fld_restore_transform_tables,'fld_restore_transform_tables',array('unsetPossible'=>true,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  
  
  $o1.=' <div class="yyfdiv1">'.CRLF;
  $o1.='  <div class="yyfinp1"><div>'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('record_the_element').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="record_the_element_and_back_to_list">'.txtsys1('record_the_element_and_back_to_list').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="record_the_element_and_back_to_generate">'.txt2('record_the_element_and_back_to_genetate_419_97').'</button>'.CRLF;
  $o1.='   <a href="zz_generateSources1.php?m=1" class="yywarning" >'.txt2('back_to_generate_without_recording_534_74').'</a>'.CRLF;
  $o1.='   <input type="hidden" value="0" name="id1" id="id1" />'.CRLF;
  $o1.='   <input type="hidden" value="c" name="a" id="a" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.='</form>'.CRLF;

 }
 $o1.=htmlFoot0(array('js' => $js1));
 dw1($o1);
 if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);
}