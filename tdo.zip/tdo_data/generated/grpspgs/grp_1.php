<?php
$GLOBALS['glob_grpspgs']=array (
  'ajax_translateMenu1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'ajax_translateMenu2.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'ajax_updTranslateSys1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'ajax_addTranslateSys1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'ajax_translateJs1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'ajax_addTranslationJs1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'ajax_getPageToTranslate1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'ajax_setSortParamWithoutLang1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'ajax_writeTranslationFiles1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'ajax_setSortParamWithLang1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'ajax_setSortPagesOfGroup1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'ajax_translatePage2.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'zz_zztests_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
  ),
  'zz_tablelinks_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
  ),
  'zz_zztests_choose1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
  ),
  'zz_paramvalues1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
  ),
  'zz_paramkeys_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
  ),
  'zz_pages_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
  ),
  'ajax_translateText1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'zz_groups_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
  ),
  'todos_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
  ),
  'todos1.php' => 
  array (
    'm' => '1',
    'o' => '0',
    'aj' => '0',
  ),
  'ajax_updateParam1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
  ),
  'zz_groups_choose1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
  ),
  'zz_users_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
  ),
  'zz_pages.php' => 
  array (
    'm' => '1',
    'o' => '1',
    'aj' => '0',
  ),
  'zz_paramkeys.php' => 
  array (
    'm' => '1',
    'o' => '2',
    'aj' => '0',
  ),
  'zz_tables1.php' => 
  array (
    'm' => '1',
    'o' => '3',
    'aj' => '0',
  ),
  'zz_tablelinks1.php' => 
  array (
    'm' => '1',
    'o' => '4',
    'aj' => '0',
  ),
  'login.php' => 
  array (
    'm' => '1',
    'o' => '05',
    'aj' => '0',
  ),
  'zz_groups1.php' => 
  array (
    'm' => '1',
    'o' => '5',
    'aj' => '0',
  ),
  'logout.php' => 
  array (
    'm' => '1',
    'o' => '06',
    'aj' => '0',
  ),
  'zz_grpspgs.php' => 
  array (
    'm' => '1',
    'o' => '6',
    'aj' => '0',
  ),
  'index.php' => 
  array (
    'm' => '1',
    'o' => '07',
    'aj' => '0',
  ),
  'zz_generateSources1.php' => 
  array (
    'm' => '1',
    'o' => '7',
    'aj' => '0',
  ),
  'zz_users.php' => 
  array (
    'm' => '1',
    'o' => '8',
    'aj' => '0',
  ),
  'zz_translate.php' => 
  array (
    'm' => '1',
    'o' => '9',
    'aj' => '0',
  ),
  'zz_css1.php' => 
  array (
    'm' => '1',
    'o' => '10',
    'aj' => '0',
  ),
  'zz_synchro1.php' => 
  array (
    'm' => '1',
    'o' => '11',
    'aj' => '0',
  ),
  'profile.php' => 
  array (
    'm' => '1',
    'o' => '13',
    'aj' => '0',
  ),
  'zz_zztests1.php' => 
  array (
    'm' => '1',
    'o' => '14',
    'aj' => '0',
  ),
);