<?php
function incGetTodo1($id){
 $nam=array();
 $nam['fld_id_todos']       = 0;
 $nam['fld_id_user_todos']  = 0;
 $nam['fld_title_todos']    = '';
 $nam['fld_comment_todos']  = '';
 $nam['fld_tsupd_todos']    = '0000-00-00 00:00:00';
 $nam['fld_tscrt_todos']    = '0000-00-00 00:00:00';
 $nam['fld_cntupd_todos']   = 0;
 $nam['fld_priority_todos'] = 0;
 
 
 $req6='
  SELECT
   T0.`fld_id_todos`    , T0.`fld_id_user_todos`     , T0.`fld_title_todos`    , T0.`fld_comment_todos` , T0.`fld_tsupd_todos` , 
   T0.`fld_tscrt_todos` , T0.`fld_cntupd_todos`      , T0.`fld_priority_todos`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl_todos` T0
  WHERE T0.`fld_id_todos` = '.$id. '
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $nam['fld_id_todos']        = $mpsr6[0];
   $nam['fld_id_user_todos']   = $mpsr6[1];
   $nam['fld_title_todos']     = $mpsr6[2];
   $nam['fld_comment_todos']   = $mpsr6[3];
   $nam['fld_tsupd_todos']     = $mpsr6[4];
   $nam['fld_tscrt_todos']     = $mpsr6[5];
   $nam['fld_cntupd_todos']    = $mpsr6[6];
   $nam['fld_priority_todos']  = $mpsr6[7];
  }
  mysqli_free_result($result6);
 }else{
  debugSql2(array('sqler' => ' in ' . __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6 , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($nam);
}
