<?php
function getTdo_zztests1($id){
 $nam=array();
 $n['fld_id_zztests']                =0;
 $n['fld_yorno1_zztests']            ='';
 $n['fld_visited_countries_zztests'] ='';
 $n['fld_country1_zztests']          ='FR';
 $n['fld_title32_zztests']           ='';
 $n['fld_id_parent_zztests']         =0;
 $n['fld_date1_zztests']             ='1000-01-01';
 $n['fld_time1_zztests']             ='00:00:00';
 $n['fld_dttim1_zztests']            ='1000-01-01 00:00:00';
 $n['fld_color1_zztests']            ='';
 $n['fld_tsupd_zztests']             ='1000-01-01 00:00:00';
 $n['fld_tscrt_zztests']             ='1000-01-01 00:00:00';
 $n['fld_cntupd_zztests']            =0;
 $sql='
  SELECT 
   T0.`fld_id_zztests`                ,T0.`fld_yorno1_zztests`            ,T0.`fld_visited_countries_zztests` ,T0.`fld_country1_zztests`          ,T0.`fld_title32_zztests`           ,
   T0.`fld_id_parent_zztests`         ,T0.`fld_date1_zztests`             ,T0.`fld_time1_zztests`             ,T0.`fld_dttim1_zztests`            ,T0.`fld_color1_zztests`            ,
   T0.`fld_tsupd_zztests`             ,T0.`fld_tscrt_zztests`             ,T0.`fld_cntupd_zztests`            
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` T0
  WHERE T0.`fld_id_zztests` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['fld_id_zztests']                = $row[0];
   $n['fld_yorno1_zztests']            = $row[1];
   $n['fld_visited_countries_zztests'] = $row[2];
   $n['fld_country1_zztests']          = $row[3];
   $n['fld_title32_zztests']           = $row[4];
   $n['fld_id_parent_zztests']         = $row[5];
   $n['fld_date1_zztests']             = $row[6];
   $n['fld_time1_zztests']             = $row[7];
   $n['fld_dttim1_zztests']            = $row[8];
   $n['fld_color1_zztests']            = $row[9];
   $n['fld_tsupd_zztests']             = $row[10];
   $n['fld_tscrt_zztests']             = $row[11];
   $n['fld_cntupd_zztests']            = $row[12];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
