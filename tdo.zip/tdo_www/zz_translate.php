<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();
$o1='';
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('translations_13_18').'</h1>';
$elemsToPrint='';
//=================================================================================================================================
//=================================================================================================================================
function forGenerateAllPages($id,$name){
 $ret=array();
 $ret['input']['page_id']=$id;
 $ret['input']['page']=$name;
 include $GLOBALS['glob_incPath1'].'/ajax/ajax_writeTranslationFiles1.php';
}
//=================================================================================================================================
if(isset($_GET['type']) && $_GET['type']=='allPages'){
 require_once($GLOBALS['glob_incPath1'].'/__pageList.php');
 foreach($GLOBALS['__pageList'] as $k1 => $v1){
  if($v1['fld_isajax_pages']!='1'){
   $ret['input']['page_id']=$v1['fld_id_pages'];
   $ret['input']['page']   =$v1['fld_name_pages'];
   forGenerateAllPages( $v1['fld_id_pages'] , $v1['fld_name_pages'] );
  }
 } 
}
//=================================================================================================================================
//=================================================================================================================================
if(isset($_POST) && sizeof($_POST)>0){
 if(isset($_POST['targetPage']) && isset($_POST['sourcePage']) && is_numeric($_POST['targetPage']) && is_numeric($_POST['sourcePage']) ){
  $sql='
   SELECT 
    T0.`fld_id_lngVals`      ,T0.`fld_key_lngVals`     ,T0.`fld_lang_lngVals`    ,T0.`fld_page_id_lngVals` ,T0.`fld_value_lngVals`   ,
    T0.`fld_type_lngVals`    ,T0.`fld_tsupd_lngVals`   ,T0.`fld_tscrt_lngVals`   ,T0.`fld_cntupd_lngVals`  
   FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0
   WHERE T0.`fld_page_id_lngVals` = '.$_POST['sourcePage']. '
  ';
  $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($row=mysqli_fetch_row($req)){
    
    $req7="
     INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` SET
        `fld_key_lngVals`     = '".addslashes($row[1])                  ."'
      , `fld_lang_lngVals`    = '".addslashes($row[2])                  ."'
      , `fld_page_id_lngVals` = ".$_POST['targetPage']                  ."
      , `fld_value_lngVals`   = '".addslashes($row[4])                  ."'
      , `fld_type_lngVals`    = '".addslashes($row[5])                  ."'
      , `fld_tsupd_lngVals`   = '".addslashes($GLOBALS['glob_setdate']) ."'
      , `fld_tscrt_lngVals`   = '".addslashes($GLOBALS['glob_setdate']) ."'
    " ;
    $res7=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
     switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
      case 1062 :
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
      break;
      default;
      $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
      $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
      txtlog1($xtxterr , BNF , __LINE__ , 'error' );
      break;
     }
    }
   }
   mysqli_free_result($req);
   
   header("HTTP/1.1 303 See Other");header('Location:'.BNF.'?type=page&page='.urlencode($_POST['page']).'&id='.$_POST['targetPage']);
   exit();
   
   
  }else{
   debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
  }
 } 
 header("HTTP/1.1 303 See Other");header('Location:'.BNF.'');
 exit();
}
//=================================================================================================================================
//=================================================================================================================================
if(isset($_GET['type']) && $_GET['type']=='deleteUnusedTranslations'){
// INSERT INTO `tdo_tbl__langvalues` (`fld_id_lngVals`, `fld_key_lngVals`, `fld_lang_lngVals`, `fld_page_id_lngVals`, `fld_value_lngVals`, `fld_type_lngVals`, `fld_tsupd_lngVals`, `fld_tscrt_lngVals`, `fld_cntupd_lngVals`) VALUES (NULL, 'zz_groups.php', 'fr', NULL, 'groupes', 'menu', '1000-01-01 00:00:00.000000', '1000-01-01 00:00:00.000000', '0') 

 if(isset($_GET['toDelete1']) && is_numeric($_GET['toDelete1'])){
  $sql='DELETE  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` WHERE fld_id_lngVals IN ('.$_GET['toDelete1'].')   ';
  $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 }
 
 if(isset($_GET['toDelete2']) && isset($_GET['fld_id_pages']) && is_numeric($_GET['fld_id_pages'])){
  $sql='
   DELETE  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` 
    WHERE fld_page_id_lngVals =   ' . $_GET['fld_id_pages']          .'  
      AND fld_key_lngVals     = \'' . addslashes($_GET['toDelete2']) .'\'   
  ';
  $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 }
 


 $elemsToPrint='';
 $toDelete='';
 $arrToDel=array();
 $sql='
  SELECT T0.fld_id_lngVals , T0.fld_lang_lngVals , T0.fld_value_lngVals , T0.fld_page_id_lngVals , T0.fld_key_lngVals
    FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0
    LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.tdo_tbl__pages T1 ON T0.fld_key_lngVals = T1.fld_name_pages
   WHERE T0.`fld_type_lngVals` LIKE \'menu\' 
     AND T1.fld_id_pages IS NULL
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $toDelete.=','.$row[0];
   $arrToDel[]=array(
    'fld_id_lngVals'      => $row[0] ,
    'fld_lang_lngVals'    => $row[1] ,
    'fld_value_lngVals'   => $row[2] ,
    'fld_page_id_lngVals' => $row[3] ,
    'fld_key_lngVals'     => $row[4] ,
   );
  }
  mysqli_free_result($req);

  if($toDelete!==''){
   $elemsToPrint.='<table border="1"><thead><th>action</th><th>fld_id_lngVals</th><th>fld_key_lngVals</th><th>fld_lang_lngVals</th><th>fld_value_lngVals</th><th>fld_page_id_lngVals</th></thead><tbody>';
   foreach($arrToDel as $k1=>$v1){
    $elemsToPrint.='<tr>';
    $elemsToPrint.='<td><a class="yydanger yytxtSiz1" href="zz_translate.php?type=deleteUnusedTranslations&amp;toDelete1='.$v1['fld_id_lngVals'].'">&#10008;</a></td>';
    $elemsToPrint.='<td>'.$v1['fld_id_lngVals'].'</td>';
    $elemsToPrint.='<td>'.$v1['fld_key_lngVals'].'</td>';
    $elemsToPrint.='<td>'.$v1['fld_lang_lngVals'].'</td>';
    $elemsToPrint.='<td>'.$v1['fld_value_lngVals'].'</td>';
    $elemsToPrint.='<td>'.$v1['fld_page_id_lngVals'].'</td>';
    $elemsToPrint.='</tr>';
   }
   $elemsToPrint.='</tbody></table>';
  }
  $arrPages1=array();
  $motsClesInutiles1=array();
  $sql='
   SELECT T0.fld_name_pages  , T0.fld_id_pages
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` T0
    WHERE T0.`fld_isajax_pages` = 0
    LIMIT 100
  ';
  $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($row=mysqli_fetch_row($req)){
    $arrPages1[]=array(
     'fld_name_pages'      => $row[0] ,
     'fld_id_pages'        => $row[1] ,
    );
   }
   mysqli_free_result($req);
   foreach( $arrPages1 as $k1=> $v1){
    $arrKey1=array();
    $sql='
     SELECT DISTINCT T0.fld_key_lngVals
       FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0
      WHERE T0.`fld_type_lngVals` = \'page\' 
        AND T0.fld_page_id_lngVals = '.$v1['fld_id_pages'].'
    ';
    $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
     while($row=mysqli_fetch_row($req)){
      $arrKey1[]=$row[0];
     }
     mysqli_free_result($req);
     if(count($arrKey1)>0){
      $fileContent=file_get_contents($v1['fld_name_pages']);
      foreach($arrKey1 as $k2=>$v2){
       if(strpos($fileContent,$v2)===false){
        $motsClesInutiles1[]=array(
         'page'         => $v1['fld_name_pages'] ,
         'motCle'       => $v2                   ,
         'fld_id_pages' => $v1['fld_id_pages']   ,
        );
       }
      }
     }
    }else{
     debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
    }
   }
   if(count($motsClesInutiles1)>1){
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $motsClesInutiles1 , true ) . '</pre>' ; exit(0);
    $elemsToPrint.='<div class="yysuccess yymessageBox">' . count($motsClesInutiles1) . ' ' . txt2('useless_key_190_100') . '</div>';
    $elemsToPrint.='<table border="1"><thead><th>action</th><th>page</th><th>fld_key_lngVals</th><th>fld_id_pages</th></thead><tbody>';
    foreach($motsClesInutiles1 as $k1=>$v1){
     $elemsToPrint.='<tr>';
     $elemsToPrint.='<td><a class="yydanger yytxtSiz1" href="zz_translate.php?type=deleteUnusedTranslations&amp;toDelete2='.urlencode($v1['motCle']).'&amp;fld_id_pages='.urlencode($v1['fld_id_pages']).'">&#10008;</a></td>';
     $elemsToPrint.='<td>'.$v1['page'].'</td>';
     $elemsToPrint.='<td>'.$v1['motCle'].'</td>';
     $elemsToPrint.='<td>'.$v1['fld_id_pages'].'</td>';
     $elemsToPrint.='</tr>';
    }
    $elemsToPrint.='</tbody></table>';
   }
  }else{
   debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
  }
  
  
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 

}
if(isset($_GET['type']) && $_GET['type']=='tables'){
 
 $listeDesTables='';
 $tabTables=array();
 if($GLOBALS['glob_isLocalHost']==true){
  $sql='
   SELECT T0.`fld_name_tables` FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T0  ORDER BY T0.`fld_name_tables` ';
  $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($row=mysqli_fetch_row($req)){
    $listeDesTables.=',\''.$row[0].'\'';
    $tabTables1[]=$row[0];
   }
   mysqli_free_result($req);
  }else{
   debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
  }
 }else{
  require_once($GLOBALS['glob_incPath1'].'/__remoteTables.php');
  foreach($GLOBALS['__remoteTables'] as $k1=>$v1){
   $listeDesTables.=',\''.$k1.'\'';
   $tabTables1[]=$k1;
  }
 }
 
 $listeDesTables=substr($listeDesTables,1);
 $tabTranslatedTables=array();
 $sql='
  SELECT T0.`fld_key_lngVals`           ,T0.`fld_lang_lngVals`          ,T0.`fld_value_lngVals`      
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0
  WHERE T0.`fld_key_lngVals` IN ( ' . $listeDesTables . ' )
    AND T0.`fld_type_lngVals` = \'table\'
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $tabTranslatedTables[$row[0].'_'.$row[1]]=$row[2];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 $elemsToPrint='';
 $elemsToPrint.='<table border="1"><thead>';
 $elemsToPrint.='<th>'.txt2('table_name_128_29').'</th>';
 $elemsToPrint.='<th>'.txt2('language_key_129_29').'</th>';
 $elemsToPrint.='<th>'.txt2('translated_values_130_29').'</th>';
 $elemsToPrint.='</thead><tbody>';
 $rowSpan=count($GLOBALS['glob__availableLanguages']);
 $count=0;
 foreach($tabTables1 as $v1){
  $elemsToPrint.='<tr>';
  $elemsToPrint.='<td rowspan="'.$rowSpan.'" style="width:30%;">';
  $elemsToPrint.=''.$v1.'';
  $elemsToPrint.='</td>';
  foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang1){
   $count++;
   $elemsToPrint.='<td style="width:10%;text-align:center;">';
   $elemsToPrint.=$klang;
   $elemsToPrint.='</td>';
   $elemsToPrint.='<td style="width:60%;">';
   if(isset($tabTranslatedTables[$v1.'_'.$klang])){
    $elemsToPrint.='<input id="input_id_'.$count.'" data-lang="'.$klang.'" type="text" data-translated="1" value="'.enti1($tabTranslatedTables[$v1.'_'.$klang]).'" style="width:90%;"/>';
    $elemsToPrint.='<button onclick="translateTable1(\''.$v1.'\',\''.$klang.'\',\'input_id_'.$count.'\')" style="min-width:15px;width:15px;padding:0;">T</button>';
   }else{
    $elemsToPrint.='<input id="input_id_'.$count.'" data-lang="'.$klang.'" type="text" data-translated="0" class="yydanger" value="" style="width:90%;border:2px inset;"/>';
    $elemsToPrint.='<button onclick="translateTable1(\''.$v1.'\',\''.$klang.'\',\'input_id_'.$count.'\')" style="min-width:15px;width:15px;padding:0;">T</button>';
   }    
   $elemsToPrint.='</td>';
   $elemsToPrint.='</tr>';
  }
 }
 $elemsToPrint.='</tbody></table>';
 
 
}
//=================================================================================================================================
if(isset($_GET['type']) && $_GET['type']=='js'){
 $ret=array();
 
 
 $ret['input']['typeJs']=true;
 $ret['input']['currentLanguage']=$GLOBALS['glob_lang'];
 
 include $GLOBALS['glob_incPath1'].'/ajax/ajax_getJavascriptToTranslate1.php';
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . htmlentities(var_export( $ret['output'] , true )) . '</pre>' ; exit(0);
 if(sizeof($ret['output'])>0){
  $bgColor='white';
  $lstToPrint='<tr><td colspan="3" class="yydanger" style="text-align:center;font-size:1.5em;">'.$GLOBALS['glob_lang'].' / <b>javascript</b></td></tr>';
  $i=0;
  $alreadySet=array();
  foreach($ret['output'] as $k1 => $v1){
   $i++;
   if($v1['type'] =='txt1' && !in_array($v1['key'],$alreadySet)){
    $lstToPrint.='<tr id="trjs__tr_'.$i.'">';
    
    $lstToPrint.='<td class="yythinBorder" style="width:34%;">';
    $lstToPrint.=''.$GLOBALS['glob_lang'].'';
    $lstToPrint.='<input type="text" value="" id="trjs__va_'.$i.'" style="width:80%;" />';
    $lstToPrint.='<button onclick="translateJs1('.$i.')" id="trjs__inp_'.$i.'" data-line="'.$v1['lineNumber'].'" data-col="'.$v1['colNumber'].'" style="min-width:15px;width:15px;padding:0;">T</button>';
    $lstToPrint.='</td>';
    
    $lstToPrint.='<td class="yythinBorder" id="trjs__ke_'.$i.'" style="width:33%;word-break: break-word;">'.$v1['key'].'</td>';
    
    $lstToPrint.='<td class="yythinBorder" style="font-size:0.8em;word-break: break-word;width:33%;">'.enti1($v1['line']).'</td>';
    
    array_push($alreadySet,$v1['key']);
    $lstToPrint.='</tr>';
   }
  }
//  $elemsToPrint.='<input type="hidden" name="page__name_to_translate" id="page__name_to_translate" value="'.$ret['input']['page'].'" />';
  $elemsToPrint.='<table border="1" class="yythinBorder" style="border-collapse:collapse;width:100%;">'.$lstToPrint.'</table>';
  $lstValTranslated='<table border="1" class="yythinBorder" style="border-collapse:collapse;"><tr><th>key</th><th>lang</th><th>value</th></tr>';
  $alreadySet=array();
  $count=0;
  foreach($ret['output'] as $k1 => $v1   ){
   if($v1['type'] =='txt2' && !in_array($v1['key'],$alreadySet) ){
    $elem=$v1['key'];
    array_push($alreadySet,$v1['key']);
    $numeroLang=0;
    foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang1){
     $numeroLang++;
     $lstValTranslated.='<tr>';
     if($numeroLang==1){
      $lstValTranslated.='<td style="white-space: pre-wrap;word-break: break-word;width:30%;" rowspan="'.sizeof($GLOBALS['glob__availableLanguages']).'">'.$elem.'</td>';
     }
     $lstValTranslated.='<td style="width:10%;text-align:center;">'.$klang.'</td>';
     $lstValTranslated.='<td  style="width:60%;">';
     if(isset($ret['translateValues'][$elem][$klang])){
      $cls1='';
      if($ret['translateValues'][$elem][$klang]['value']==$elem){
       $cls1='yywarning';
      }
      $lstValTranslated.='<input id="js_'.$count.'" class="'.$cls1.'"         data-option="update" type="text" value="'.enti1($ret['translateValues'][$elem][$klang]['value']).'" style="width:90%;font-size:0.8em;" />';     
     }else{
      $lstValTranslated.='<input id="js_'.$count.'" class="yydanger" data-option="create" type="text" value="" style="width:90%;font-size:0.8em;" />';           
     }
     $lstValTranslated.='<button type="button" style="width:15px;height:35px;min-width:15px;min-height:35px;padding:0;border-radius:2px;" ';
     $lstValTranslated.=' onclick="addTranslationJs1(this)" ';
     $lstValTranslated.=' data-lang="'.$klang.'" ';
     $lstValTranslated.=' data-idparent="js_'.$count.'" ';
     $lstValTranslated.=' data-key="'.enti1($elem).'" ';
     $lstValTranslated.='>T</button>';
     $lstValTranslated.='</td>';
     $count++;
     
    }
    $lstValTranslated.='</tr>';
    
   }
  }
  $lstValTranslated.='</table>';
  $elemsToPrint.=$lstValTranslated;
 } 
 
}
//=================================================================================================================================
if(isset($_GET['type']) && $_GET['type']=='deleteTranslation' && isset($_GET['page'])&& isset($_GET['id']) && is_numeric($_GET['id'])){
 $req6='
  DELETE FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues`  
  WHERE `fld_page_id_lngVals`   =  '.$_GET['id'].'
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  header("HTTP/1.1 303 See Other");header('Location: zz_translate.php?type=page&page='.$_GET['page'].'&id='.$_GET['id'].'');
  exit();
 }else{
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ .' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;  
  header("HTTP/1.1 303 See Other");header('Location: zz_translate.php');
  exit();
 }
}
//=================================================================================================================================
if(isset($_GET['type']) && $_GET['type']=='page' && isset($_GET['page'])&& isset($_GET['page_id'])){
 $ret=array();
 $ret['input']['page']=$_GET['page'];
 $ret['input']['page_id']=$_GET['page_id'];
 include $GLOBALS['glob_incPath1'].'/ajax/ajax_getPageToTranslate1.php';
 if(sizeof($ret['output'])>0){
  $bgColor='white';
  $lstToPrint='<tr><td colspan="5">'.$GLOBALS['glob_lang'].'/<b>' . $_GET['page'] . '</b></td></tr>';
  $i=0;
  $alreadySet=array();
  foreach($ret['output'] as $k1 => $v1){
   $i++;
   if($v1['type'] =='txt1' && !in_array($v1['key'],$alreadySet)){
    $lstToPrint.='<tr id="trjs__tr_'.$i.'">';
    $lstToPrint.='<td style="width:165px;">';
    $lstToPrint.=''.$GLOBALS['glob_lang'].'';
    $lstToPrint.='<input type="text" value="" id="trjs__va_'.$i.'" style="width:125px;background-color:red;" />';
    $lstToPrint.='<button onclick="translate2('.$i.','.$_GET['page_id'].','.$v1['lineNumber'].','.$v1['colNumber'].',\''.$_GET['page'].'\')" id="trjs__inp_'.$i.'" style="min-width:15px;width:15px;padding:0;">T</button>';
    $lstToPrint.='</td>';
    $lstToPrint.='<td id="trjs__li_'.$i.'">'.$v1['lineNumber'].'</td>';
    $lstToPrint.='<td id="trjs__co_'.$i.'">'.$v1['colNumber'].'</td>';
    $lstToPrint.='<td id="trjs__ke_'.$i.'" style="background-color:'.$bgColor.';">'.$v1['key'].'</td>';
    $lstToPrint.='<td style="font-size:0.8em;">'.enti1($v1['line']).'</td>';
    array_push($alreadySet,$v1['key']);
    $lstToPrint.='</tr>';
   }
  }
  
  $elemsToPrint.='<input type="hidden" name="page__name_to_translate" id="page__name_to_translate" value="'.$_GET['page'].'" /><table border="1">'.$lstToPrint.'</table>';
  $lstValTranslated='<table><thead>';
  $lstValTranslated.='<tr><th>key</th><th style="padding-left:0px;padding-right:0px;">lang</th><th>value</th><th>T</th></tr>';
  $lstValTranslated.='</thead><tbody>';
  $alreadySet=array();
  $numberOfLangs=sizeof($GLOBALS['glob__availableLanguages']);
  foreach($ret['output'] as $k1 => $v1   ){
   if($v1['type'] =='txt2' && !in_array($v1['key'],$alreadySet) ){
    $elem=$v1['key'];
    array_push($alreadySet,$v1['key']);
    $numeroLang=0;
    foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang1){
     $numeroLang++;
     $lstValTranslated.='<tr>';
     if($numeroLang==1){
      $lstValTranslated.='<td rowspan="2"  style="max-width:80px;word-wrap: break-word;border:1px red solid;">'.$elem.'</td>';
      $lstValTranslated.='<td  style="width:5%;word-wrap: break-word;padding-left:0px;padding-right:0px;text-align:right;">'.$klang.'</td>';
     }else if($numberOfLangs==$numeroLang){
      $lstValTranslated.='<td  style="width:5%;word-wrap: break-word;padding-left:0px;padding-right:0px;text-align:right;border-bottom:1px red solid;">'.$klang.'</td>';
     }else{
      $lstValTranslated.='<td  style="width:5%;word-wrap: break-word;padding-left:0px;padding-right:0px;text-align:right;">'.$klang.'</td>';
     }
     if($numberOfLangs==$numeroLang){
      $lstValTranslated.='<td style="width:60%;border-bottom:1px red solid;">';
     }else{
      $lstValTranslated.='<td style="width:60%;">';
     }
     $lstValTranslated.='<input id="translate__key_'.$klang.'_'.$elem.'" type="text" ';     
     if(isset($ret['translateValues'][$elem][$klang])){
      $lstValTranslated.=' value="'.enti1($ret['translateValues'][$elem][$klang]['value']).'" style="width:100%;" />';     
     }else{
      $lstValTranslated.=' value="" style="width:100%;background-color:red;" />';           
     }
     $lstValTranslated.='</td>';
     if($numberOfLangs==$numeroLang){
      $lstValTranslated.='<td style="width:5%;padding-left:0;padding-right:0;border-bottom:1px red solid;">';
     }else{
      $lstValTranslated.='<td style="width:5%;padding-left:0;padding-right:0;">';
     }
     $lstValTranslated.='<button type="button" style="height:30px;min-width:30px;padding:1px;border-radius:5px;" ';
     $lstValTranslated.=' id="'.$klang.'__'.$elem.'" ';
     $lstValTranslated.=' onclick="addTranslation(this)"';
     $lstValTranslated.=' data-pageid="'.$_GET['page_id'].'"';
     $lstValTranslated.=' data-fromValue="true"';
     $lstValTranslated.=' data-otherSpan=""';
     $lstValTranslated.=' data-idparent="translate__key_'.$klang.'_'.$elem.'"';
     $lstValTranslated.=' data-idtranslate="'.$_GET['page'].'|'.$elem.'|'.$klang.'"'; // "fld_title_todos_48_54", "en"
     $lstValTranslated.='> T </button>';
     $lstValTranslated.='</td>';
    }
    $lstValTranslated.='</tr>';
    
   }
  }
  $lstValTranslated.='</tbody></table>';
  $elemsToPrint.=$lstValTranslated;
 }

}
//=================================================================================================================================
if(isset($_GET['type']) && $_GET['type']=='inc' ){
 $ret=array();
 $ret['input']['page']=$_GET['page'];
 $ret['input']['page_id']=$_GET['id'];
 include $GLOBALS['glob_incPath1'].'/ajax/ajax_getPageToTranslate1.php';
 if(sizeof($ret['output'])>0){
  $bgColor='white';
  $lstToPrint='<tr><td colspan="5">'.$GLOBALS['glob_lang'].'/<b>' . $_GET['page'] . '</b></td></tr>';
  $i=0;
  $alreadySet=array();
  foreach($ret['output'] as $k1 => $v1){
   $i++;
   if($v1['type'] =='txt1' && !in_array($v1['key'],$alreadySet)){
    $lstToPrint.='<tr id="trjs__tr_'.$i.'">';
    $lstToPrint.='<td style="width:165px;">';
    $lstToPrint.=''.$GLOBALS['glob_lang'].'';
    $lstToPrint.='<input type="text" value="" id="trjs__va_'.$i.'" style="width:125px;" />';
    $lstToPrint.='<button onclick="translate2('.$i.','.$_GET['id'].','.$v1['lineNumber'].','.$v1['colNumber'].')" id="trjs__inp_'.$i.'" style="min-width:15px;width:15px;padding:0;">T</button>';
    $lstToPrint.='</td>';
    $lstToPrint.='<td id="trjs__li_'.$i.'">'.$v1['lineNumber'].'</td>';
    $lstToPrint.='<td id="trjs__co_'.$i.'">'.$v1['colNumber'].'</td>';
    $lstToPrint.='<td id="trjs__ke_'.$i.'" style="background-color:'.$bgColor.';">'.$v1['key'].'</td>';
    $lstToPrint.='<td style="font-size:0.8em;">'.enti1($v1['line']).'</td>';
    array_push($alreadySet,$v1['key']);
    $lstToPrint.='</tr>';
   }
  }
  $elemsToPrint.='<input type="hidden" name="page__name_to_translate" id="page__name_to_translate" value="'.$_GET['page'].'" /><table border="1">'.$lstToPrint.'</table>';
  $lstValTranslated='<table border="1"><tr><th>key</th><th>lang</th><th>value</th></tr>';
  $alreadySet=array();
  foreach($ret['output'] as $k1 => $v1   ){
   if($v1['type'] =='txt2' && !in_array($v1['key'],$alreadySet) ){
    $elem=$v1['key'];
    array_push($alreadySet,$v1['key']);
    $numeroLang=0;
    foreach($GLOBALS['glob__availableLanguages'] as $klang => $vlang1){
     $numeroLang++;
     $lstValTranslated.='<tr>';
     if($numeroLang==1){
      $lstValTranslated.='<td rowspan="2">'.$elem.'</td>';
     }
     $lstValTranslated.='<td>'.$klang.'</td>';
     $lstValTranslated.='<td>';
     if(isset($ret['translateValues'][$elem][$klang])){
      $lstValTranslated.='<input id="translate__key_'.$klang.'_'.$elem.'" type="text" value="'.enti1($ret['translateValues'][$elem][$klang]['value']).'" />';     
     }else{
      $lstValTranslated.='<input id="translate__key_'.$klang.'_'.$elem.'" type="text" value="" style="background-color:red;" />';           
     }
     $lstValTranslated.='<button type="button" style="width:15px;height:15px;min-width:15px;min-height:15px;padding:0;border-radius:2px;" ';
     $lstValTranslated.=' id="'.$klang.'__'.$elem.'" ';
     $lstValTranslated.=' onclick="addTranslation(this)"';
     $lstValTranslated.=' data-pageid="'.$_GET['id'].'"';
     $lstValTranslated.=' data-fromValue="true"';
     $lstValTranslated.=' data-otherSpan=""';
     $lstValTranslated.=' data-idparent="translate__key_'.$klang.'_'.$elem.'"';
     $lstValTranslated.=' data-idtranslate="'.$_GET['page'].'|'.$elem.'|'.$klang.'"'; // "fld_title_todos_48_54", "en"
     $lstValTranslated.='>T</button>';
     $lstValTranslated.='</td>';
    }
    $lstValTranslated.='</tr>';
    
   }
  }
  $lstValTranslated.='</table>';
  $elemsToPrint.=$lstValTranslated;
 }
}
//=================================================================================================================================
//=================================================================================================================================

if(isset($_GET['type']) && $_GET['type']=='menu'){
 $listeDesTraductions=array();
 require_once($GLOBALS['glob_incPath1'].'/__pageList.php'); 
 $req6='
  SELECT  T0.`fld_key_lngVals`  , T0.`fld_lang_lngVals`   , T0.`fld_id_lngVals` , T0.`fld_value_lngVals` , T0.`fld_page_id_lngVals`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues`   T0 
  WHERE T0.`fld_type_lngVals`   =  \'menu\'
  ORDER BY T0.`fld_key_lngVals` , T0.`fld_lang_lngVals`
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   if(isset($GLOBALS['glob__availableLanguages'][$mpsr6[1]])){
    $doIt=true;
    if($GLOBALS['glob_isLocalHost']==false){
     if(isset($GLOBALS['__pageList'][$mpsr6[0]])){
      if($GLOBALS['__pageList'][$mpsr6[0]]['fld_isremote_pages']=='1'  ){
       $doIt=true;
      }else{
       $doIt=false;
      }
     }else{
      $doIt=false;
     }
    }
    if($doIt){
     $listeDesTraductions[$mpsr6[0].'_'.$mpsr6[1]]=array(
      'id'                  => $mpsr6[2] ,
      'value'               => $mpsr6[3] ,
      'fld_key_lngVals'     => $mpsr6[0] ,
      'fld_lang_lngVals'    => $mpsr6[1] ,
      'added'               => false     ,
     );
    }
   }
  }
  mysqli_free_result($result6);
 }else{
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=':-( '. __LINE__ .' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;  
 }
 
 // insérer les nouveaux menus de dev qui ne sont pas encore en prod
 $dataInserted=false;
 foreach($GLOBALS['__pageList'] as $k0=>$v0){
  foreach($GLOBALS['glob__availableLanguages'] as $kl1 => $vl1){
   if('1' == $v0['fld_menu_pages'] && ( '1' == $v0['fld_isremote_pages'] || $GLOBALS['glob_isLocalHost'] ) ){
    $founded=false;
    foreach($listeDesTraductions as $k1=>$v1){
     if($v1['fld_key_lngVals']==$k0 && $kl1==$v1['fld_lang_lngVals']){
      $founded=true;
      break;
     }
    }
    if($founded==false){
     $listeDesTraductions[$k0.'_'.$k1]=array(
      'id'                => $v0['fld_id_pages'] ,
      'value'             => ''   ,
      'fld_key_lngVals'   => $k0  ,
      'fld_lang_lngVals'  => $kl1 ,
      'added'             => true ,
     );
     $req7='
      INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` SET
        `fld_key_lngVals`     = \''.addslashes($k0).'\'
      , `fld_lang_lngVals`    = \''.addslashes($kl1).'\'
      , `fld_type_lngVals`    = \'menu\'
      , `fld_value_lngVals`   = \'menu_'.str_replace('.php','',$k0).'\'
      , `fld_page_id_lngVals` = NULL
     ';
     $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
     $dataInserted=true;
    }
   }
  }
 }
 if($dataInserted==true){
//========================================================  
  function trierMenuParNomEtParLangue($a, $b) {
   if ($a['fld_key_lngVals'] == $b['fld_key_lngVals']) {
    if ($a['fld_lang_lngVals'] == $b['fld_lang_lngVals']) {
     return 0;
    }
    return ($a['fld_lang_lngVals'] < $b['fld_lang_lngVals']) ? -1 : 1;
   }
   return ($a['fld_key_lngVals'] < $b['fld_key_lngVals']) ? -1 : 1;
  }  
//========================================================  
  uasort($listeDesTraductions , 'trierMenuParNomEtParLangue');
 }
 
 $elemsToPrint.='<fieldset><legend>'.txt2('List of menus_123_43').'</legend>';
 $menuPrec='';
 foreach($listeDesTraductions as $k1=>$v1){
  if($menuPrec!=$v1['fld_key_lngVals']){
   $elemsToPrint.='<br /><span style="font-family:monospace;">'.$v1['fld_key_lngVals'].' : </span>';
  }
  $menuPrec=$v1['fld_key_lngVals'];
  $elemsToPrint.='<br /><span style="font-family:monospace;">'.$v1['fld_lang_lngVals'].' : </span>';
  if($v1['added']==true){
   $elemsToPrint.='<input type="text" id="'.$k1.'" value="" style="background:red;" />';
   $elemsToPrint.='<button type="button" onclick="tanslateMenu1(\''.$k1.'\',\''.$v1['fld_key_lngVals'].'\',\''.$v1['fld_lang_lngVals'].'\')" >T</button>';
  }else{
   $elemsToPrint.='<input type="text" id="'.$k1.'" value="'.enti1($v1['value']).'" />';
   $elemsToPrint.='<button type="button" onclick="tanslateMenu2(\''.$k1.'\','.$v1['id'].')" >T</button>';
  }
  
 }
 $elemsToPrint.='</fieldset>';
}
//=================================================================================================================================
if(isset($_GET['type']) && $_GET['type']=='login'){
 $listeDesTraductions=array();
 require_once($GLOBALS['glob_incPath1'].'/__pageList.php'); 
 $req6='
  SELECT  T0.`fld_key_lngVals`  , T0.`fld_lang_lngVals`   , T0.`fld_id_lngVals` , T0.`fld_value_lngVals` , T0.`fld_page_id_lngVals`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues`   T0 
  WHERE T0.`fld_type_lngVals`      =  \'page\'
    AND T0.`fld_page_id_lngVals`   =  2
  ORDER BY T0.`fld_key_lngVals` , T0.`fld_lang_lngVals`
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   if(isset($GLOBALS['glob__availableLanguages'][$mpsr6[1]])){
    $doIt=true;
    if($GLOBALS['glob_isLocalHost']==false){
     if(isset($GLOBALS['__pageList'][$mpsr6[0]])){
      if($GLOBALS['__pageList'][$mpsr6[0]]['fld_isremote_pages']=='1'  ){
       $doIt=true;
      }else{
       $doIt=false;
      }
     }else{
      $doIt=false;
     }
    }
    if($doIt){
     $listeDesTraductions[$mpsr6[0].'_'.$mpsr6[1]]=array(
      'id'                  => $mpsr6[2] ,
      'value'               => $mpsr6[3] ,
      'fld_key_lngVals'     => $mpsr6[0] ,
      'fld_lang_lngVals'    => $mpsr6[1] ,
      'added'               => false     ,
     );
    }
   }
  }
  mysqli_free_result($result6);
 }else{
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=':-( '. __LINE__ .' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;  
 }
 
 $elemsToPrint.='<fieldset><legend>'.txt2('List_of_phrases_on_the_home_page_479_43').'</legend>';
 $menuPrec='';
 foreach($listeDesTraductions as $k1=>$v1){
  if($menuPrec!=$v1['fld_key_lngVals']){
   $elemsToPrint.='<hr /><span style="font-family:monospace;font-weight:bold;">'.$v1['fld_key_lngVals'].' : </span>';
  }
  $menuPrec=$v1['fld_key_lngVals'];
  $elemsToPrint.='<br /><span style="font-family:monospace;">'.$v1['fld_lang_lngVals'].' : </span>';
  $elemsToPrint.='<input type="text" id="page_element_'.$v1['id'].'" value="'.enti1($v1['value']).'" style="width:50%;" />';
  $elemsToPrint.='<button type="button" onclick="translatePageElement1(\'page_element_'.$v1['id'].'\','.$v1['id'].')" >T</button>';
  
 }
 $elemsToPrint.='</fieldset>';
}
//=================================================================================================================================
if(isset($_GET['type']) && $_GET['type']=='system'){
 $arrSys=array(
  'text_for_the_select_button','error','warning','message',
  'edit_button','delete_button', 'duplicate_button','sort_order',
  'this_record_has_not_been_updated_because_of_an_other_user','please_retry','save_the_modification','this_record_already_exist','please_confirm_deletion_of','save_the_modification_and_back_to_list','record_the_element_and_back_to_list',
  'back_to_the_list','the_modification_has_been_recorded_at','record_the_element',
  'column_action',
  'i_confirm_the_deletion_button',
  'Value_not_founded_in_paramerters',
  'you_cannot_delete_because_some_values_are_still_present_in_dependant_table',
  'you_cannot_delete_this_value',
  'constraint_fail',
  'all_values_of_set_list',
  'menu_other',
  'the_navigation_has_been_lost',
  'undefined',
  'raz_button','dependent_values_exist',
  'date all','date null','date not null','time all','time null','time not null','datetime all','datetime null','datetime not null',
  'color all','color null','color not null','update color',
  'calendarWeekShort','calendarMondayShort','calendarTuesdayShort','calendarWednesdayShort','calendarThursdayShort','calendarFridayShort','calendarSaturdayShort','calendarSundayShort',
  'the_date_is_not_at_a_good_format_for_the_field','the_time_is_not_at_a_good_format_for_the_field','the_date_or_the_time_is_not_at_a_good_format_for_the_field','the_date_cannot_be_lower_than_today_for_the_field','the_date_cannot_be_greater_than_today_for_the_field',
  'you_must_fill_a_value_for_the_field','you_must_fill_a_numeric_value_for_the_field','the_email_address_is_not_valid_for_the_field',
  'an_error_occured_and_a_message_will_be_sent_to_the_administrator','correct_the_warning_values',
  'no_records_found_with_these_search_criteria',
  'you_must_fill_a_phone_number_for_the_field'
 );
 $lstToPrint='<tr><td colspan="5">'.$GLOBALS['glob_lang'].'/<b>'.txt2('the system elements_145_66').'</b></td></tr>';
 $i=0;
 $tabSysVal=array();
 $req6='
  SELECT  T0.`fld_key_lngVals`   , T0.`fld_lang_lngVals`  , T0.`fld_value_lngVals`
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues`   T0 
  WHERE T0.`fld_type_lngVals`        =  \'system\'
 ';
 $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($mpsr6=mysqli_fetch_row($result6)){
   $tabSysVal[$mpsr6[0]][$mpsr6[1]]=$mpsr6[2];
  }
  mysqli_free_result($result6);
 }
 foreach( $arrSys as $k1 => $v1){
  $numLang=0;
  foreach( $GLOBALS['glob__availableLanguages'] as $k2 => $v2){
   $i++;
   $numLang++;
   $lstToPrint.='<tr id="trjs__tr_'.$i.'">';
   if($numLang==1){
    $lstToPrint.='<td rowspan="2" style="max-width:300px;word-break:break-all;" >'.$v1.'</td>';
   }
   $lstToPrint.='<td style="max-width:300px;">'.$k2.'<input type="hidden" id="trjs__la_'.$i.'" value="'.enti1($k2).'" /><input type="hidden" id="trjs__ke_'.$i.'" value="'.enti1($v1).'" /></td>';
   $lstToPrint.='<td style="width:400px;">';
   if(!isset($tabSysVal[$v1][$k2])){
    $lstToPrint.='<input type="text" value="" id="trjs__va_'.$i.'" style="width:380px;background:red;" />';
   }else{
    $lstToPrint.='<input type="text" value="'.enti1($tabSysVal[$v1][$k2]).'" id="trjs__va_'.$i.'" style="width:380px;" />';
   }
   $lstToPrint.='<button onclick="addTranslateSys1('.$i.')" id="trjs__inp_'.$i.'" style="min-width:15px;width:15px;padding:0;">T</button>';
   $lstToPrint.='</td>';
   $lstToPrint.='</tr>';    
  }
 }
 $elemsToPrint.='<table border="1" class="">'.$lstToPrint.'</table>';
}
//=================================================================================================================================

require_once($GLOBALS['glob_incPath1'].'/__pageList.php');
$o1.=displaySessionMessage1(BNF);

$o1.=$elemsToPrint;

$o1.=txt2('Select the element to translate_171_11');
$o1.='<ul>';
$o1.='<li><a href="zz_translate.php?type=login">'.txt2('the_login_page_566_56').'</a></li>';
$o1.='<li><a href="zz_translate.php?type=system">'.txt2('the system elements_145_66').'</a></li>';
$o1.='<li><a href="zz_translate.php?type=js">'.txt2('the javascripts_246_53').'</a></li>';
$o1.='<li><a href="zz_translate.php?type=menu">'.txt2('the menus_173_55').'</a></li>';
$o1.='<li><a href="zz_translate.php?type=tables">'.txt2('the_tables_653_57').'</a></li>';
if($GLOBALS['glob_isLocalHost']==true){
 $o1.='<li><a href="zz_translate.php?type=deleteUnusedTranslations">'.txt2('delete_unused_translations_790_76').'</a></li>';
 
 $o1.='<li>';
 $o1.=txt2('the pages_175_11');
 $o1.='<ul>';

 $pageLitsToDisplay=array();

 if($handle = opendir('.')){
  while(false!==($entry = readdir($handle))){
   if($entry != "." && $entry != ".." && !is_dir($entry) ){
    if(isset($GLOBALS['__pageList'][$entry])){
     $take=false;
     if($_SESSION[PGMK]['login']==1){
      $take=true; 
     }else{
      if($GLOBALS['__pageList'][$entry]['fld_isuser_pages']=='1' || $GLOBALS['__pageList'][$entry]['fld_localadmin_pages']=='1' ){
       $take=true;     
      }
     }
     if($take==true){
      $pageLitsToDisplay[]=$GLOBALS['__pageList'][$entry];
     }
    }
   }
  }
  closedir($handle);
 }

 foreach($pageLitsToDisplay as $k1 => $v1){

  if(isset($_GET['type']) && $_GET['type']=='page' && isset($_GET['page']) && $_GET['page']==$v1['fld_name_pages']){
   $o1.='<li class="yysuccess" style="min-height:40px;">';
  }else{
   $o1.='<li style="min-height:40px;">';
   
  }
  $o1.='<a href="javascript:myConfirm1(\'zz_translate.php?type=deleteTranslation&amp;page='.$v1['fld_name_pages'].'&amp;id='.$v1['fld_id_pages'].'\')">'.txt2('delete translations_399_166').'</a>';
  $o1.='<a href="zz_translate.php?type=page&amp;page='.$v1['fld_name_pages'].'&amp;page_id='.$v1['fld_id_pages'].'">'.$v1['fld_name_pages'].'</a>';
  
  $o1.='<form id="copy_translation_'.$v1['fld_id_pages'].'" style="display:inline-block;" onsubmit="return myConfirm0()" method="post">'.CRLF;
  $o1.='<input type="hidden" name="page" value="'.$v1['fld_name_pages'].'" />'.CRLF;
  $o1.='<button type="submit" class="noHide" name="targetPage" value="'.$v1['fld_id_pages'].'">'.txt2('copy from_453_52').'</button>'.CRLF;
  $o1.='<select style="max-width:125px;font-size:0.75em;"  name="sourcePage">'.CRLF;
  $o1.='<option value="">'.txt2('choose a page_455_32').'</option>'.CRLF;
  foreach($pageLitsToDisplay as $k2 => $v2){
   $o1.='<option value="'.$v2['fld_id_pages'].'">'.$v2['fld_name_pages'].'</option>'.CRLF;
  }
  $o1.='</select>'.CRLF;
  $o1.='</form>'.CRLF;
  
  
  $o1.='</li>';
 }
 $o1.='</ul>';
 $o1.='</li>'; 
 
}


$o1.='<li><a href="zz_translate.php?type=allPages">'.txt2('generate translation files for all pages_231_59').'</a></li>';
$o1.='</ul>';
$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();