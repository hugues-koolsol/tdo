<?php // € utf8 check with euro sign
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
checkGroupPages();

if(isset($_GET['idchoose'])){
 $_SESSION[PGMK]['choose']['valueBack']=$_GET['idchoose'];
 header('Location: '.$_SESSION[PGMK]['choose']['urlBack']); 
 exit();
}

if(!isset($_SESSION[PGMK]['choose']['urlBack'])){
 header('Location: index.php?message='.urlencode(txtsys1('the_navigation_has_been_lost')));
 exit();
}
openDb2();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_id_server_tables
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_name_tables
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_system_tables
if(PGMK=='t'.'do'){
 $xsrch_2='';
}else{
 $xsrch_2='0';
}
$xsrch_3=saveSessionSearch1('xsrch_3',BNF);// fld_view_tables

if(isset($_GET['noView']) && $_GET['noView']=='1'){
 $xsrch_3='0';
}else{
 $xsrch_3='';
}

$xsrch_4=saveSessionSearch1('xsrch_4',BNF);// fld_id_reftbl_of_view_tables
$xsrch_6=saveSessionSearch1('xsrch_6',BNF);// fld_name_tables of parent table
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_tables
$xsrch_sort=saveSessionSearch1('xsrch_sort',BNF);// fld_id_tables
if($xsrch_4!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_4);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if(!$listIdsOk){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_51_92') . ' : ' . txt2('fld_id_reftbl_of_view_tables_51_152');
 }
}
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if(!$listIdsOk){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_51_92') . ' : ' . txt2('fld_id_tables_65_152');
 }
}
$autofocus='xsrch_1';
if($xsrch_1!=''){      $autofocus='xsrch_1'; } // fld_id_server_tables
else if($xsrch_0!=''){ $autofocus='xsrch_0'; } // fld_name_tables
else if($xsrch_2!=''){ $autofocus='xsrch_2'; } // fld_system_tables
else if($xsrch_3!=''){ $autofocus='xsrch_3'; } // fld_view_tables
else if($xsrch_4!=''){ $autofocus='xsrch_4'; } // fld_id_reftbl_of_view_tables link to parent table
else if($xsrch_6!=''){ $autofocus='xsrch_6'; } // fld_name_tables of parent table
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('select a tables_78_18');
$o1.='&nbsp;<a class="buttonBack" href="'.$_SESSION[PGMK]['choose']['urlBack'].'">Retour</a>'.CRLF;
$o1.='</h1>';

$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="filterForm">'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_1">'.txt2('fld_name_tables_88_39').'</label>'.CRLF; // fld_name_tables
$o1.='    <input '.($xsrch_1!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_1" id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="128"  '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_2">'.txt2('fld_system_tables_93_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_2!=''?'class="backgroundYellow"':'').' name="xsrch_2"  id="xsrch_2" '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='<option value="" '.($xsrch_2==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_2){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_3">'.txt2('fld_view_tables_107_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_3!=''?'class="backgroundYellow"':'').' name="xsrch_3"  id="xsrch_3" '.($autofocus=='xsrch_3'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='<option value="" '.($xsrch_3==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_3){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_4">'.txt2('fld_id_reftbl_of_view_tables_51_152').'</label>'.CRLF; // fld_id_reftbl_of_view_tables
$o1.='    <input '.($xsrch_4!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_4" id="xsrch_4"   value="'.enti1($xsrch_4).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_4'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;




// field fld_name_tables of parent table

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_6">'.txt2('T1.fld_name_tables_131_39').'</label>'.CRLF; // fld_name_tables
$o1.='    <input '.($xsrch_6!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_6" id="xsrch_6"   value="'.enti1($xsrch_6).'"  size="8" maxlength="128"  '.($autofocus=='xsrch_6'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_id_server_tables_153_39').'</label>'.CRLF; // fld_id_server_tables
$o1.='    <input '.($xsrch_0!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_0" id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_tables_65_152').'</label>'.CRLF; // fld_id_tables
$o1.='    <input '.($xsrch_id!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_sort">'.txtsys1('sort_order').'</label>'.CRLF; // sort
$o1.='    <select '.($xsrch_sort!=''?'class="backgroundYellow"':'').' name="xsrch_sort"  id="xsrch_sort" '.($autofocus=='xsrch_sort'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='     <option value="" '.($xsrch_sort==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_id_server_tables'.'"         '.($xsrch_sort=='T0.fld_id_server_tables'         ?' selected="selected" ':'').'>'.txt2('fld_id_server_tables_153_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_name_tables'.'"              '.($xsrch_sort=='T0.fld_name_tables'              ?' selected="selected" ':'').'>'.txt2('fld_name_tables_88_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_system_tables'.'"            '.($xsrch_sort=='T0.fld_system_tables'            ?' selected="selected" ':'').'>'.txt2('fld_system_tables_93_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_view_tables'.'"              '.($xsrch_sort=='T0.fld_view_tables'              ?' selected="selected" ':'').'>'.txt2('fld_view_tables_107_39').'</option>'.CRLF;
$o1.='     <option value="'.'T0.fld_id_reftbl_of_view_tables'.'" '.($xsrch_sort=='T0.fld_id_reftbl_of_view_tables' ?' selected="selected" ':'').'>'.txt2('fld_id_reftbl_of_view_tables_51_152').'</option>'.CRLF;
$o1.='     <option value="'.'T1.fld_name_tables'.'"              '.($xsrch_sort=='T1.fld_name_tables'              ?' selected="selected" ':'').'>'.txt2('T1.fld_name_tables_131_39').'</option>'.CRLF;
$o1.='    </select>';
$o1.='   </div>'.CRLF;
$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;// #128270
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_tables`                ,T0.`fld_id_server_tables`         ,T0.`fld_name_tables`              ,T0.`fld_system_tables`            ,T0.`fld_view_tables`              ,
   T0.`fld_id_reftbl_of_view_tables` ,T1.`fld_name_tables`              
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T0 ) 
 LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables`  T1 ON T0.`fld_id_reftbl_of_view_tables` = T1.`fld_id_tables`
 WHERE 1=1 
';
if($xsrch_0!='' && is_numeric($xsrch_0)){
 $req6.='
  AND T0.`fld_id_server_tables` = '.$xsrch_0.'
 '; 
}
if($xsrch_1!='' ){
 $req6.='
  AND T0.`fld_name_tables` LIKE \'%'.addslashes1($xsrch_1).'%\'
 '; 
}
if($xsrch_2!='' ){
 $req6.='
  AND T0.`fld_system_tables` LIKE \'%'.addslashes1($xsrch_2).'%\'
 '; 
}
if($xsrch_3!='' ){
 $req6.='
  AND T0.`fld_view_tables` LIKE \'%'.addslashes1($xsrch_3).'%\'
 '; 
}
if($xsrch_4!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_4);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if($listIdsOk){
  $req6.='
   AND T0.`fld_id_reftbl_of_view_tables` IN ('.implode(',',$xsrch_ids).') 
  '; 
 }
}
// field fld_name_tables of parent table
if($xsrch_6!='' ){
 $req6.='
  AND T1.`fld_name_tables` LIKE \'%'.addslashes1($xsrch_6).'%\'
 '; 
}
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if($listIdsOk){
  $req6.='
   AND T0.`fld_id_tables` IN ('.implode(',',$xsrch_ids).') 
  '; 
 }
}
// adjust the order
if($xsrch_sort==''){ $req6.='ORDER BY T0.`fld_id_tables` DESC ';}
if($xsrch_sort=='T0.fld_id_server_tables'){          $req6.=' ORDER BY T0.`fld_id_server_tables` ASC  '; }
if($xsrch_sort=='T0.fld_name_tables'){               $req6.=' ORDER BY T0.`fld_name_tables` ASC  '; }
if($xsrch_sort=='T0.fld_system_tables'){             $req6.=' ORDER BY T0.`fld_system_tables` ASC  '; }
if($xsrch_sort=='T0.fld_view_tables'){               $req6.=' ORDER BY T0.`fld_view_tables` ASC  '; }
if($xsrch_sort=='T0.fld_id_reftbl_of_view_tables'){  $req6.=' ORDER BY T0.`fld_id_reftbl_of_view_tables` ASC  '; }
if($xsrch_sort=='T1.fld_name_tables'){  $req6.=' ORDER BY T1.`fld_name_tables` ASC ';}
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$__count=0;
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'T0.fld_id_tables'                =>$mpsr6[0],
  'T0.fld_id_server_tables'         =>$mpsr6[1],
  'T0.fld_name_tables'              =>$mpsr6[2],
  'T0.fld_system_tables'            =>$mpsr6[3],
  'T0.fld_view_tables'              =>$mpsr6[4],
  'T0.fld_id_reftbl_of_view_tables' =>$mpsr6[5],
  'T1.fld_name_tables'              =>$mpsr6[6],
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}
$lsttbl='';
if($__count==0){
 $lst.='<p>'.CRLF;
 $lst.=''.txt2('no_record_founded_304_16').''.CRLF;
 $lst.='</p>'.CRLF;
 $o1.=''.$lst.''.CRLF;  
}else{
 $consUrlRedir=''.
               ($xsrch_0!=''?'&amp;xsrch_0='.rawurlencode($xsrch_0):''). // fld_id_server_tables 
               ($xsrch_1!=''?'&amp;xsrch_1='.rawurlencode($xsrch_1):''). // fld_name_tables 
               ($xsrch_2!=''?'&amp;xsrch_2='.rawurlencode($xsrch_2):''). // fld_system_tables 
               ($xsrch_3!=''?'&amp;xsrch_3='.rawurlencode($xsrch_3):''). // fld_view_tables 
               ($xsrch_4!=''?'&amp;xsrch_4='.rawurlencode($xsrch_4):''). // fld_id_reftbl_of_view_tables 
                ($xsrch_6!=''?'&amp;xsrch_6='.rawurlencode($xsrch_6):''). // fld_name_tables of parent
               ($xsrch_id!=''?'&amp;xsrch_id='.rawurlencode($xsrch_id):'').
               ($xsrch_sort!=''?'&amp;xsrch_sort='.rawurlencode($xsrch_sort):'').
               '';
 $ri=' <span class="btn unset">&raquo;</span>';
 if($__start+$__nbMax<$__count){
  $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
 }
 $le=' <span class="btn unset">&laquo;</span>';
 if($__xpage>0){
  $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
 }

 $o1.='<div>';
 $o1.='<form method="post">';
 $o1.='&nbsp;'.$le.''.CRLF;  
 $o1.='&nbsp;'.$ri.''.CRLF;  
 $o1.=' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('records tables_302_80').' )'.CRLF;
 $o1.='</form>';
 $o1.='</div>';

 $o1.=getCss1(890); // todo adjust size

 $lsttbl.='<thead><tr>';
 $lsttbl.='<th style="min-width:125px;">'.txtsys1('column_action').'</th>';
 $lsttbl.='<th style="min-width:85px;">'.txt2('fld_id_tables_65_152').'</th>';
 $lsttbl.='<th>'.txt2('fld_name_tables_88_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_system_tables_93_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_view_tables_107_39').'</th>';
 $lsttbl.='<th>'.txt2('fld_id_reftbl_of_view_tables_51_152').'</th>';
 $lsttbl.='<th>'.txt2('T1.fld_name_tables_131_39').'</th>'; // ======== parent field of fld_id_reftbl_of_view_tables
 $lsttbl.='<th>'.txt2('fld_id_server_tables_153_39').'</th>';
 $lsttbl.='</tr></thead><tbody>';

 foreach($data0 as $k0=>$v0){

  $lsttbl.='<tr>';

  $lsttbl.='<td data-label="'.txtsys1('column_action').'">';
  $lsttbl.='<div>';
   $lsttbl.='<a href="'.BNF.'?idchoose='.$v0['T0.fld_id_tables'].'">'.txtsys1('text_for_the_select_button') . '</a>';
  $lsttbl.='</div>';
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_id_tables_65_152').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_id_tables'].''; // fld_id_tables
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_name_tables_88_39').'">';
  $lsttbl.=''.$v0['T0.fld_name_tables'].''; // fld_name_tables
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_system_tables_93_39').'" style="text-align:center;">';
  $lsttbl.=displayParam1('yorno',$v0['T0.fld_system_tables'],array('unsetPossible'=>false)); // fld_system_tables
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_view_tables_107_39').'" style="text-align:center;">';
  $lsttbl.=displayParam1('yorno',$v0['T0.fld_view_tables'],array('unsetPossible'=>false)); // fld_view_tables
  $lsttbl.='</td>';

  $lsttbl.='<td data-label="'.txt2('fld_id_reftbl_of_view_tables_51_152').'" style="text-align:center;">';
  $lsttbl.=''.$v0['T0.fld_id_reftbl_of_view_tables'].''; // fld_id_reftbl_of_view_tables
  $lsttbl.='</td>';


// field fld_name_tables of parent table
  if($v0['T1.fld_name_tables']===0||is_null($v0['T1.fld_name_tables'])){
   $lsttbl.='<td data-label="'.txt2('T1.fld_name_tables_131_39').'"></td>'; 
  }else{
   $lsttbl.='<td data-label="'.txt2('T1.fld_name_tables_131_39').'">';
   $lsttbl.=''.$v0['T1.fld_name_tables'].''; // fld_name_tables
   $lsttbl.='</td>';
  }

  $lsttbl.='<td data-label="'.txt2('fld_id_server_tables_153_39').'" style="text-align:right;">';
  $lsttbl.=''.$v0['T0.fld_id_server_tables'].''; // fld_id_server_tables
  $lsttbl.='</td>';


  $lsttbl.='</tr>';

 }

 $o1.='<table class="tableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;

 $o1.=' <div>'.CRLF;
 $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('records tables_302_80').' )'.CRLF;
 $o1.=' </div>'.CRLF;

}

$o1.='<script type="text/javascript">var globalChooseUrlBack=\''.$_SESSION[PGMK]['choose']['urlBack'].'\';</script>';
$o1.=htmlFoot0(array());
dw1($o1);
