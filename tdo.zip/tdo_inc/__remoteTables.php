<?php
$GLOBALS['__remoteTables']=array (
  'tdo_tbl__groups' => 
  array (
    'fld_id_tables' => '1',
    'fld_restore_transform_tables' => '',
    'fld_id_server_tables' => '0',
    'fld_view_tables' => '0',
    'fld_log_tables' => '0',
  ),
  'tdo_tbl__grpspgs' => 
  array (
    'fld_id_tables' => '2',
    'fld_restore_transform_tables' => '',
    'fld_id_server_tables' => '0',
    'fld_view_tables' => '0',
    'fld_log_tables' => '0',
  ),
  'tdo_tbl__langvalues' => 
  array (
    'fld_id_tables' => '3',
    'fld_restore_transform_tables' => '',
    'fld_id_server_tables' => '0',
    'fld_view_tables' => '0',
    'fld_log_tables' => '0',
  ),
  'tdo_tbl__log' => 
  array (
    'fld_id_tables' => '4',
    'fld_restore_transform_tables' => '',
    'fld_id_server_tables' => '0',
    'fld_view_tables' => '0',
    'fld_log_tables' => '0',
  ),
  'tdo_tbl__paramnames' => 
  array (
    'fld_id_tables' => '6',
    'fld_restore_transform_tables' => '',
    'fld_id_server_tables' => '0',
    'fld_view_tables' => '0',
    'fld_log_tables' => '0',
  ),
  'tdo_tbl__paramvalues' => 
  array (
    'fld_id_tables' => '7',
    'fld_restore_transform_tables' => '',
    'fld_id_server_tables' => '0',
    'fld_view_tables' => '0',
    'fld_log_tables' => '0',
  ),
  'tdo_tbl__users' => 
  array (
    'fld_id_tables' => '11',
    'fld_restore_transform_tables' => '',
    'fld_id_server_tables' => '0',
    'fld_view_tables' => '0',
    'fld_log_tables' => '0',
  ),
  'tdo_tbl__todos' => 
  array (
    'fld_id_tables' => '13',
    'fld_restore_transform_tables' => '',
    'fld_id_server_tables' => '0',
    'fld_view_tables' => '0',
    'fld_log_tables' => '0',
  ),
  'tdo_tbl__css' => 
  array (
    'fld_id_tables' => '14',
    'fld_restore_transform_tables' => '',
    'fld_id_server_tables' => '0',
    'fld_view_tables' => '0',
    'fld_log_tables' => '0',
  ),
  'tdo_tbl__uploadeddocs' => 
  array (
    'fld_id_tables' => '17',
    'fld_restore_transform_tables' => '',
    'fld_id_server_tables' => '0',
    'fld_view_tables' => '0',
    'fld_log_tables' => '0',
  ),
);