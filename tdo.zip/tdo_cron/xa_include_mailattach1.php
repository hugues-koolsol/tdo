<?php

class hdfmail {

    public static function prepareAttachment($path) {
        $rn = "\r\n";

        if (file_exists($path)) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $ftype = finfo_file($finfo, $path);
            $file = fopen($path, "r");
            $attachment = fread($file, filesize($path));
            $attachment = chunk_split(base64_encode($attachment));
            fclose($file);

            $msg = 'Content-Type: \'' . $ftype . '\'; name="' . basename($path) . '"' . $rn;
            $msg .= "Content-Transfer-Encoding: base64" . $rn;
            $msg .= 'Content-ID: <' . basename($path) . '>' . $rn;
            $msg .= $rn . $attachment . $rn . $rn;
            return $msg;
        } else {
            return false;
        }
    }

    public static function sendMail($from,$to, $subject, $content, $paths = array(), $cc = '', $bcc = '', $_headers = false, $test = false) {

        $rn = "\r\n";
        $boundary = md5(rand());
        $boundary_content = md5(rand());

        // Headers
        $headers = 'From: '.$from.'' . $rn;
        $headers .= 'Mime-Version: 1.0' . $rn;
        $headers .= 'Content-Type: multipart/related;boundary=' . $boundary . $rn;

        //adresses cc and ci
        if ($cc != '') {
            $headers .= 'Cc: ' . $cc . $rn;
        }
        if ($bcc != '') {
            $headers .= 'Bcc: ' . $cc . $rn;
        }
        $headers .= $rn;

        // Message Body
        $msg = $rn . '--' . $boundary . $rn;
        $msg.= "Content-Type: multipart/alternative;" . $rn;
        $msg.= " boundary=\"$boundary_content\"" . $rn;

        //Body Mode text
        $msg.= $rn . "--" . $boundary_content . $rn;
        $msg .= 'Content-Type: text/plain; charset=UTF-8' . $rn;
        $msg .= strip_tags($content) . $rn;

        //Body Mode Html        
        $msg.= $rn . "--" . $boundary_content . $rn;
        $msg .= 'Content-Type: text/html; charset=UTF-8' . $rn;
        $msg .= 'Content-Transfer-Encoding: quoted-printable' . $rn;
        if (false && $_headers) {
            $msg .= $rn . '<img src=3D"cid:google1.png" />' . $rn;
        }
        
        //equal sign are email special characters. =3D is the = sign
        
        $msg .= $rn . '<div>' . nl2br(str_replace("=", "=3D", $content)) . '</div>' . $rn;
        if (false && $_headers) {
            $msg .= $rn . '<img src=3D"cid:bdd_mysql_world.png" />' . $rn;
        }
        $msg .= $rn . '--' . $boundary_content . '--' . $rn;

        //if attachement
        if (count($paths)>0){
            foreach($paths as $path){
                if( $path != '' && file_exists($path)) {
                    $conAttached = self::prepareAttachment($path);
                    if ($conAttached !== false) {
                        $msg .= $rn . '--' . $boundary . $rn;
                        $msg .= $conAttached;
                    }
                }
            }
        }
        
        //other attachement : here used on HTML body for picture headers/footers
        if (false && $_headers) {
            $imgHead = dirname(__FILE__) . '/google1.png';
            $conAttached = self::prepareAttachment($imgHead);
            if ($conAttached !== false) {
                $msg .= $rn . '--' . $boundary . $rn;
                $msg .= $conAttached;
            }
            $imgFoot = dirname(__FILE__) . '/bdd_mysql_world.png';
            $conAttached = self::prepareAttachment($imgFoot);
            if ($conAttached !== false) {
                $msg .= $rn . '--' . $boundary . $rn;
                $msg .= $conAttached;
            }
        }

        // Fin
        $msg .= $rn . '--' . $boundary . '--' . $rn;
        

        if( $test ){
         if($fd=fopen('toto.txt' , 'a+')){
          
              fwrite($fd,"\r\n simulation dans " . __FILE__ . ' ' . date('Y-m-d-H-i-s') ." ==========\r\n");
              fwrite($fd,"\r\nto " . $to ."\r\n");
              fwrite($fd,"\r\nsubject " . $subject ."\r\n");
              fwrite($fd,"\r\nattach " . var_export( $paths , true ) ."\r\n");
              fwrite($fd,"\r\n msg " . $msg ."\r\n");
              fwrite($fd,"\r\n /simulation dans " . __FILE__ . ' ' . date('Y-m-d-H-i-s') ." ==========\r\n");
              fclose($fd);
         }
         
        }else{
        
            // Function mail()
            @mail($to, $subject, $msg, $headers);
        }
    }
}
/*
// exemple d'appel
$monMail  = new hdfmail();
$from     = 'no-reply from sophiemallebranche.com <no-reply@sophiemallebranche.com>';
$to       = 'hdfoug@gmail.com';
$subject  = '👍 💣 🙂 ⚠ Ceci est le sujet de mon email avec des accents € é à ! '.date('Y-m-d-H:i:s');
$content  = '<p style="font-size:18px;">👍 💣 🙂 ⚠ Ceci est le contenu de mon email avec des accents € é à et une longue phrase pour voir ce que ça donne !</p>';
$content .= '<br /><a style="font-size:16px;" href="http://www.koolsol.com">Et hop, un lien koolsol</a>!';
$content .= '<br />hello,world <hr />';
$paths    = array(
    realpath( dirname(__FILE__) . '/un_fichier_texte.txt' ),
    realpath( dirname(__FILE__) . '/google1.png'          ),
);
$cc       = '';
$bcc      = '';
$_headers = false; // attention, ceci est fait pour mettre des images dans le contenu du mail

$monMail->sendMail($from,$to, $subject, $content, $paths , $cc , $bcc , $_headers );
*/


//===================================================================================
function saveRemoteFile($url, $filename){
 $ch = curl_init($url);
 $fp = fopen($filename, "w");
 curl_setopt($ch, CURLOPT_FILE, $fp);
 curl_setopt($ch, CURLOPT_HEADER, 0);
 curl_setopt($ch, CURLOPT_USERAGENT      , "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0"); //Make this valid if possible
 if(strpos($url,'https')!==false){
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 }
 curl_exec($ch);
 if(curl_exec($ch) === false){
  $curlinfo1=curl_getinfo($ch);
 }
 $errors=curl_error($ch);
 curl_close($ch);
 fclose($fp);
 if($errors==''){
 }else{
  echo 'Curl Error '. __FILE__ . ' ' . __LINE__ . ' $errors = <pre>' . var_export( $errors , true ) . '</pre> $curlinfo1 = <pre>' . var_export( $curlinfo1 , true ) . '</pre>' ; 
  exit(0);
 }
}
/*
// exemple d'appel
$htmlsource0 =dirname(realpath(__FILE__)).DIRECTORY_SEPARATOR.'htmlSource0.html';
$url0='https://annuaire.sante.fr/web/site-pro/extractions-publiques';
saveRemoteFile($url0,$htmlsource0) ;
*/
//===================================================================================


?>