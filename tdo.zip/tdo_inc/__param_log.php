<?php
$GLOBALS['param__log']=array (
  'param__Name__Display' => 'n',
  'param__Name__Sort' => 'n',
  'param__Name__key' => 'log_type',
  'param__Key__type' => 'char',
  '__values' => 
  array (
    'fr' => 
    array (
      'error' => 
      array (
        'log_type' => 'error',
        'n' => 'Erreur',
        'badge' => 'badge0',
        'rule' => '0',
        'fld_id_parvals' => '63',
        '__order' => 0,
      ),
      'information' => 
      array (
        'log_type' => 'information',
        'n' => 'Info',
        'badge' => 'badge1',
        'rule' => '0',
        'fld_id_parvals' => '64',
        '__order' => 1,
      ),
      'sql' => 
      array (
        'log_type' => 'sql',
        'n' => 'sql',
        'badge' => 'badge2',
        'rule' => '0',
        'fld_id_parvals' => '65',
        '__order' => 2,
      ),
    ),
    'en' => 
    array (
      'error' => 
      array (
        'log_type' => 'error',
        'n' => 'Error',
        'badge' => 'badge0',
        'rule' => '0',
        'fld_id_parvals' => '63',
      ),
      'information' => 
      array (
        'log_type' => 'information',
        'n' => 'Information',
        'badge' => 'badge1',
        'rule' => '0',
        'fld_id_parvals' => '64',
      ),
      'sql' => 
      array (
        'log_type' => 'sql',
        'n' => 'sql',
        'badge' => 'badge2',
        'rule' => '0',
        'fld_id_parvals' => '65',
      ),
    ),
  ),
  'param__definition' => 
  array (
    'comment' => 'This is an example',
    'key' => 'log_type',
    'fields' => 
    array (
      0 => 
      array (
        'name' => 'log_type',
        'type' => 'char',
        'length' => 16,
        'comment' => 'sql,error,info',
      ),
      1 => 
      array (
        'name' => 'n',
        'type' => 'char',
        'length' => 32,
        'languageTranslation' => true,
        'comment1' => 'log name',
      ),
    ),
    'dependencies' => 
    array (
      0 => 
      array (
        'id_db' => 0,
        'table' => 'tdo_tbl__log',
        'field' => 'fld_typ_log',
      ),
    ),
    'id' => '4',
  ),
);