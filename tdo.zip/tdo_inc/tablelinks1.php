<?php
//============================================================================================================================================
function getRequestTable($withoutPrefixTable1,$dbName){
 if($withoutPrefixTable1=='on'){
  $req6='
    SELECT `table_name` , T1.`fld_system_tables` , T1.`fld_id_tables` , T1.`fld_id_server_tables`
      FROM `information_schema`.`tables`
      LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T1 ON `table_name` = T1.`fld_name_tables`
     WHERE `table_type` = \'BASE TABLE\' AND `table_schema`=\''.$dbName.'\'  
     ORDER BY `table_name` ASC; 
  ';  
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' .  $req6 . '</pre>' ; exit(0);
 }else{
  $req6='
    SELECT `table_name` , T1.`fld_system_tables` , T1.`fld_id_tables` , T1.`fld_id_server_tables`
      FROM `information_schema`.`tables`
      LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T1 ON `table_name` = T1.`fld_name_tables`
     WHERE `table_type` = \'BASE TABLE\' AND `table_schema`=\''.$dbName.'\'  AND `table_name` LIKE \''.$GLOBALS['__table_prefix'].'%\'
     ORDER BY `table_name` ASC; 
  ';  
 }
 return $req6;
}
//============================================================================================================================================
function getRequestView($withoutPrefixTable1,$dbName){
 if($withoutPrefixTable1=='on'){
  $req6='
    SELECT `table_name` , T1.`fld_system_tables` , T1.`fld_id_tables` , T1.`fld_id_server_tables`
      FROM `information_schema`.`views`
      LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T1 ON `table_name` = T1.`fld_name_tables`
     WHERE `table_schema`=\''.$dbName.'\'  
     ORDER BY `table_name` ASC; 
  ';  
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' .  $req6 . '</pre>' ; exit(0);
 }else{
  $req6='
    SELECT `table_name` , T1.`fld_system_tables` , T1.`fld_id_tables` , T1.`fld_id_server_tables`
      FROM `information_schema`.`views`
      LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables` T1 ON `table_name` = T1.`fld_name_tables`
     WHERE `table_schema`=\''.$dbName.'\'  AND `table_name` LIKE \''.$GLOBALS['__table_prefix'].'%\'
     ORDER BY `table_name` ASC; 
  ';  
 }
 return $req6;
}
//============================================================================================================================================
function writeTableDependencies1(){
 $ret=array(
  'status'  => true    ,
  'problem' => array() ,
 );
 $sqlList=array();
 $sourceGenere='';
 $txtDependances='';
 $sql='
  SELECT 
   T0.`fld_id_pglnks`     ,T1.`fld_id_server_tables` ,T1.`fld_name_tables`  ,T0.`fld_parent_field_pglnks`  ,T2.`fld_id_server_tables`  ,
   T2.`fld_name_tables`   ,T0.`fld_child_field_pglnks`   
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tablelinks` T0 ,
       `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables`     T1 ,
       `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables`     T2 
 WHERE T1.`fld_id_tables` = T0.`fld_parent_table_id_pglnks` 
   AND T2.`fld_id_tables` = T0.`fld_children_table_id_pglnks` 
  ORDER BY T0.`fld_id_pglnks`
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $par=array(
    'idBase' => $row[4],
    'table'  => $row[5],
   );
   getTableInfos($par);
   $kChamp=-1;
   $vchamp=array();
   foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
    if($v1['nom_champ']==$row[6]){
     $kChamp=$k1;
     $vchamp=$v1;
    }
   }
   if($kChamp==-1){
    $ret['status']=false;
    $ret['problem'][]='field '.$row[6].' Not founded in this table';
   }else{
    $txtDependances.=' if($idParentDb=='.$row[1].' && $parentTable==\''.$row[2].'\' && $parentField == \''.$row[3].'\' ){'.CRLF;
    if($GLOBALS['__listeDesChamps'][$kChamp])
    if(strpos(strtolower($vchamp['type_champ']),'int(')     !==false || 
       strpos(strtolower($vchamp['type_champ']),'decimal(') !==false || 
       strpos(strtolower($vchamp['type_champ']),'float(')   !==false || 
       strpos(strtolower($vchamp['type_champ']),'double(')  !==false || 
       strpos(strtolower($vchamp['type_champ']),'real(')    !==false){
     $txtDependances.='  $sqlList[]=array('.CRLF;
     $txtDependances.='   \'sql\'    => \'SELECT `'.$row[6].'` FROM `\'.$GLOBALS[\'glob_db\']['.$row[4].'][\'dbname\'].\'`.`'.$row[5].'` WHERE `'.$row[6].'` = \'.$value.\' LIMIT 1\','.CRLF;
     $txtDependances.='   \'table\'  => \''.$row[5].'\','.CRLF;
     $txtDependances.='   \'idBase\' => '.$row[4].','.CRLF;
     $txtDependances.='  );'.CRLF;
    }else{
     $txtDependances.='  $sqlList[]=array('.CRLF;
     $txtDependances.='   \'sql\'   => \'SELECT `'.$row[6].'` FROM `\'.$GLOBALS[\'glob_db\']['.$row[4].'][\'dbname\'].\'`.`.'.$row[5].'` WHERE `'.$row[6].'` = \\\'\'.addslashes($value).\'\\\' LIMIT 1\','.CRLF;    
     $txtDependances.='   \'table\' => \''.$row[5].'\','.CRLF;
     $txtDependances.='   \'idBase\' => '.$row[4].','.CRLF;
     $txtDependances.='  );'.CRLF;
    }
    $txtDependances.=' }'.CRLF;
   }
  }
 }else{
  $ret['status']=false;
  $ret['problem'][]=$sql;
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));  
 }
 if( true ===   $ret['status']){
  $sourceGenere.='<'.'?php'.CRLF;
  $sourceGenere.='// this programm is generated'.CRLF;
  $sourceGenere.='function dependentValuesExist1($idParentDb,$parentTable,$parentField,$value,$options=array()){'.CRLF;
  $sourceGenere.=' $ret=array('.CRLF;
  $sourceGenere.='  \'valuesExist\' => false   ,'.CRLF;
  $sourceGenere.='  \'tables\'      => array() ,'.CRLF;
  $sourceGenere.=' );'.CRLF;
  $sourceGenere.=' $sqlList=array();'.CRLF;
  $sourceGenere.=$txtDependances;
  $sourceGenere.=' foreach( $sqlList as $k1 => $v1 ){'.CRLF;
  $sourceGenere.='  if(false === $ret[\'valuesExist\']){'.CRLF;
  $sourceGenere.='   $req=mysqli_query($GLOBALS[\'glob_db\'][$v1[\'idBase\']][\'link\'],$v1[\'sql\']);'.CRLF;
  $sourceGenere.='   if(mysqli_errno($GLOBALS[\'glob_db\'][$v1[\'idBase\']][\'link\'])==0){'.CRLF;
  $sourceGenere.='    while($row=mysqli_fetch_row($req)){'.CRLF;
  $sourceGenere.='     $ret[\'valuesExist\']=true;'.CRLF;
  $sourceGenere.='     $ret[\'tables\'][]=$v1[\'table\'];'.CRLF;
  $sourceGenere.='    }'.CRLF;
  $sourceGenere.='    mysqli_free_result($req);'.CRLF;
  $sourceGenere.='   }else{'.CRLF;
  $sourceGenere.='    $ret[\'valuesExist\']=true;'.CRLF;
  $sourceGenere.='    $ret[\'tables\'][]=$v1[\'table\'];'.CRLF;
  $sourceGenere.='    debugSql2(array(\'sqler\' => \' in \'. __FUNCTION__ . \' \' . mysqli_error($GLOBALS[\'glob_db\'][[$v1[\'idBase\']]][\'link\']),\'reque\' => $v1[\'sql\'] , \'file\' => __FILE__ , \'line\' => __LINE__ ));  '.CRLF;
  $sourceGenere.='   }'.CRLF;
  $sourceGenere.='  }'.CRLF;
  $sourceGenere.=' }'.CRLF;
  $sourceGenere.=' return $ret;'.CRLF;
  $sourceGenere.='}'.CRLF;
  if($fd=fopen($GLOBALS['glob_dataPath1'].'/generated/__tableDependencies1.php','w')){
   fwrite($fd,$sourceGenere);
   fclose($fd);
  }
 }
 return $ret;
}
//============================================================================================================================================
function getTableInfos(&$get){
 $GLOBALS['__listeDesChamps']=array();
 $GLOBALS['__parentTables']=array();
 $GLOBALS['__longueurMax']=25; // on prévoit assez large par défaut

 $req6=' SHOW FULL COLUMNS FROM `'.$get['table'].'` IN `'.$GLOBALS['glob_db'][$get['idBase']]['dbname'].'` ';
 $result6=mysqli_query($GLOBALS['glob_db'][$get['idBase']]['link'],$req6);
 if(mysqli_errno($GLOBALS['glob_db'][$get['idBase']]['link'])==0){
  while($mpsr6=mysqli_fetch_array($result6)){
   $fieldSize=0;
   if(strpos($mpsr6[1],'char')!==null){
    $fieldSize=(int)str_replace(')','',str_replace('(','',substr($mpsr6[1],strpos($mpsr6[1],'('))));
   }
   $isNumericField=false;
   if(strpos(strtolower($mpsr6[1]),'int(')    !==false ||
     strpos(strtolower($mpsr6[1]),'decimal(') !==false ||
     strpos(strtolower($mpsr6[1]),'float(')   !==false ||
     strpos(strtolower($mpsr6[1]),'double(')  !==false ||
     strpos(strtolower($mpsr6[1]),'real(')    !==false){
    $isNumericField=true;
   }
   $GLOBALS['__listeDesChamps'][]=array(
    'nom_champ'      => $mpsr6[0],
    'type_champ'     => $mpsr6[1],
    'Collation'      => $mpsr6[2],
    'null_possible'  => $mpsr6[3],
    'champ_cle'      => $mpsr6[4],
    'val_defaut'     => $mpsr6[5],
    'extra'          => $mpsr6[6],
    'privileges'     => $mpsr6[7],
    'comment'        => $mpsr6[8],
    'fieldSize'      => $fieldSize,
    'isNumericField' => $isNumericField
   );
  }
  mysqli_free_result($result6);
 }else{
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=':-( '. __LINE__ .' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;  
 }
 $GLOBALS['__autoincrement']='';
 $GLOBALS['__fld_cntupd']='';
 $GLOBALS['__listeChampsCles']=array();
 if(sizeof($GLOBALS['__listeDesChamps'])>0){
  foreach($GLOBALS['__listeDesChamps'] as $k1 => $v1){
   if($mpsr6[1]=='geometry'){
    if($GLOBALS['__longueurMax']<strlen($v1['nom_champ'])-11){ // ST_AsText() , ST_GeomFromText()
     $GLOBALS['__longueurMax']=strlen($v1['nom_champ'])+11;
    }    
   }else{
    if($GLOBALS['__longueurMax']<strlen($v1['nom_champ'])){
     $GLOBALS['__longueurMax']=strlen($v1['nom_champ']);
    }
   }
   if($v1['extra']=='auto_increment' && 'PRI' == $v1['champ_cle']){
    $GLOBALS['__autoincrement']=$v1['nom_champ'];
   }else{
    if('PRI' == $v1['champ_cle']){
     $GLOBALS['__listeChampsCles'][]=$v1['nom_champ'];
    }
   }
   if(strpos($v1['nom_champ'],'fld_cntupd_')!==false){
    $GLOBALS['__fld_cntupd']=$v1['nom_champ'];
   }
   
   if($v1['comment']!=''){
    $phpComment=json_decode($v1['comment'],true);
 //   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $phpComment , true ) . '</pre>' ; exit(0);
    if($phpComment!==null){
     if(isset($phpComment['view_key_for']) ){
      foreach($phpComment['view_key_for'] as $k3 => $v3){
       if($v3==$get['table']){
        $GLOBALS['__autoincrement']=$v1['nom_champ'];
       }
      }
     }
    }
   }
  }
  $GLOBALS['__longueurMax']+=1;
 }
 if($GLOBALS['__autoincrement']!=''){
  $GLOBALS['__listeChampsCles']=array();
 }

 if(substr($get['table'],0,8)==PGMK.'_tbl_'){
  $funcname=str_replace('tbl__','',$get['table']);
  $funcname=str_replace('tbl_','',$funcname);
  $funcname=strtoupper(substr($funcname,0,1)).substr($funcname,1); // donne Tdo_test
 }else{
  $funcname=$get['table'];
 }
 
 $GLOBALS['funcname']=$funcname;
 $GLOBALS['__hasParentFields']=false;
 $numParent1=1;
 $indParentTable=-1;
 foreach( $GLOBALS['__listeDesChamps'] as $k1 => $v1){
  $sql='
   SELECT 
    T0.`fld_id_pglnks`   , T2.`fld_id_server_tables`      , 0  , T0.`fld_parent_field_pglnks` , T0.`fld_link_mandatory_pglnks`, 
    T3.`fld_name_tables` , T0.`fld_parent_field_display_pglnks`
   FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tablelinks` T0 ,
        `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables`     T2 , 
        `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tables`     T3 
   WHERE T2.`fld_id_tables`           = T0.`fld_children_table_id_pglnks` 
     AND T2.`fld_name_tables`         = \''.addslashes($get['table'])    .'\'
     AND T0.`fld_child_field_pglnks`  = \''.addslashes($v1['nom_champ']) .'\'
     AND T0.`fld_parent_table_id_pglnks` = T3.`fld_id_tables`
  ';
  $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   while($row=mysqli_fetch_row($req)){
    $GLOBALS['__listeDesChamps'][$k1]['parentField']=array(
     'id'                              => $row[0],
     'fld_parent_idbase_pglnks'        => $row[1],
     'fld_parent_field_pglnks'         => $row[3],
     'fld_link_mandatory_pglnks'       => $row[4],
     'fld_name_tables'                 => $row[5],
     'fld_parent_field_display_pglnks' => $row[6],
     'numParent1'                      => $numParent1,
     'fieldList'                      => array(),
    );
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['__listeDesChamps'][$k1]['parentField'] , true ) . '</pre>' ; exit(0);
    $numParent1++;
    $GLOBALS['__hasParentFields']=true;
   }
   mysqli_free_result($req);
   if(isset($GLOBALS['__listeDesChamps'][$k1]['parentField'])){
    $lstChampsParents=$GLOBALS['__listeDesChamps'][$k1]['parentField']['fld_parent_field_display_pglnks'];
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['__listeDesChamps'][$k1]['parentField'] , true ) . '</pre>' ; exit(0);
    $tabLstChampsParents=explode(',',$lstChampsParents);
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $tabLstChampsParents , true ) . '</pre>' ; exit(0);
    $GLOBALS['__listeDesChampsParents']=array();
    foreach($tabLstChampsParents as $kcp => $vcp){
     $req6=' SHOW FULL COLUMNS FROM `'.$GLOBALS['__listeDesChamps'][$k1]['parentField']['fld_name_tables'].'` IN `'.$GLOBALS['glob_db'][$get['idBase']]['dbname'].'` ';
//     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $req6 , true ) . '</pre>' ; exit(0);
     $result6=mysqli_query($GLOBALS['glob_db'][$get['idBase']]['link'],$req6);
     if(mysqli_errno($GLOBALS['glob_db'][$get['idBase']]['link'])==0){
      while($mpsr6=mysqli_fetch_array($result6)){
       $fieldSize=0;
       if(strpos($mpsr6[1],'char')!==null){
        $fieldSize=(int)str_replace(')','',str_replace('(','',substr($mpsr6[1],strpos($mpsr6[1],'('))));
       }
       $isNumericField=false;
       if(strpos(strtolower($mpsr6[1]),'int(')    !==false ||
         strpos(strtolower($mpsr6[1]),'decimal(') !==false ||
         strpos(strtolower($mpsr6[1]),'float(')   !==false ||
         strpos(strtolower($mpsr6[1]),'double(')  !==false ||
         strpos(strtolower($mpsr6[1]),'real(')    !==false){
        $isNumericField=true;
       }
       if($mpsr6[0]==$vcp){
        $GLOBALS['__listeDesChampsParents'][]=array(
         'champ_lien_parent' => $v1['nom_champ'],
         'nom_champ'         => $mpsr6[0],
         'type_champ'        => $mpsr6[1],
         'Collation'         => $mpsr6[2],
         'null_possible'     => $mpsr6[3],
         'champ_cle'         => $mpsr6[4],
         'val_defaut'        => $mpsr6[5],
         'extra'             => $mpsr6[6],
         'privileges'        => $mpsr6[7],
         'comment'           => $mpsr6[8],
         'fieldSize'         => $fieldSize,
         'isNumericField'    => $isNumericField
        );        
       }
       if($GLOBALS['__longueurMax']<strlen($mpsr6[0])){
        $GLOBALS['__longueurMax']=strlen($mpsr6[0])+1;
       }
      }
      mysqli_free_result($result6);
     }else{
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=':-( '. __LINE__ .' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;  
     }
    }
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['__listeDesChampsParents'] , true ) . '</pre>' ; exit(0);
    $GLOBALS['__listeDesChamps'][$k1]['parentField']['fieldList']=$GLOBALS['__listeDesChampsParents'];
    
     $req6=' SHOW FULL COLUMNS FROM `'.$GLOBALS['__listeDesChamps'][$k1]['parentField']['fld_name_tables'].'` IN `'.$GLOBALS['glob_db'][$get['idBase']]['dbname'].'` ';
//     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $req6 , true ) . '</pre>' ; exit(0);
     $result6=mysqli_query($GLOBALS['glob_db'][$get['idBase']]['link'],$req6);
     if(mysqli_errno($GLOBALS['glob_db'][$get['idBase']]['link'])==0){
      $indParentTable++;  
      $GLOBALS['__parentTables'][$indParentTable]=array(
       'child_table_name'   => $get['table']                                                       ,
       'child_field_name'   => $GLOBALS['__listeDesChamps'][$k1]['nom_champ']                      ,
       'parent_table_name'  => $GLOBALS['__listeDesChamps'][$k1]['parentField']['fld_name_tables'] ,
       'parent_field_name'  => $GLOBALS['__listeDesChamps'][$k1]['parentField']['fld_parent_field_pglnks'] ,
       'numParent1'         => $GLOBALS['__listeDesChamps'][$k1]['parentField']['numParent1'] ,
       'mandatory'          => $GLOBALS['__listeDesChamps'][$k1]['parentField']['fld_link_mandatory_pglnks'] ,
       'parent_fields'      => array(),
      );
      while($mpsr6=mysqli_fetch_array($result6)){
       $fieldSize=0;
       if(strpos($mpsr6[1],'char')!==null){
        $fieldSize=(int)str_replace(')','',str_replace('(','',substr($mpsr6[1],strpos($mpsr6[1],'('))));
       }
       $isNumericField=false;
       if(strpos(strtolower($mpsr6[1]),'int(')    !==false ||
         strpos(strtolower($mpsr6[1]),'decimal(') !==false ||
         strpos(strtolower($mpsr6[1]),'float(')   !==false ||
         strpos(strtolower($mpsr6[1]),'double(')  !==false ||
         strpos(strtolower($mpsr6[1]),'real(')    !==false){
        $isNumericField=true;
       }

       $GLOBALS['__parentTables'][$indParentTable]['parent_fields'][]=array(
        'nom_champ'         => $mpsr6[0],
        'type_champ'        => $mpsr6[1],
        'Collation'         => $mpsr6[2],
        'null_possible'     => $mpsr6[3],
        'champ_cle'         => $mpsr6[4],
        'val_defaut'        => $mpsr6[5],
        'extra'             => $mpsr6[6],
        'privileges'        => $mpsr6[7],
        'comment'           => $mpsr6[8],
        'fieldSize'         => $fieldSize,
        'isNumericField'    => $isNumericField
       );
       if($GLOBALS['__longueurMax']<strlen($mpsr6[0])){
        $GLOBALS['__longueurMax']=strlen($mpsr6[0])+1;
       }
      }
      mysqli_free_result($result6);
     }else{
       $_SESSION[PGMK][NAV][BNF]['errormessage'][]=':-( '. __LINE__ .' : mysqli_error=' . mysqli_error($GLOBALS['glob_db'][0]['link']) . ', req=' . $req6 ;  
     }    
    
    
    
   }
  }else{
   debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
  }
 }
 
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['__listeDesChamps'] , true ) . '</pre>' ; exit(0);
 $GLOBALS['__showDeleteFieldName']='';
 if($GLOBALS['__autoincrement']!=''){
  $GLOBALS['__showDeleteFieldName']=','.$GLOBALS['__autoincrement'];
 }
 foreach( $GLOBALS['__listeDesChamps'] as $k1 => $v1){
  if($v1['comment']!=''){
   $phpComment=json_decode($v1['comment'],true);
   if($phpComment!==null){
    foreach($phpComment as $k2=> $v2){
     $GLOBALS['__listeDesChamps'][$k1][$k2]=$v2;
    }
    if(isset($phpComment['showDeleteField']) && $phpComment['showDeleteField'] == true){
     $GLOBALS['__showDeleteFieldName'].=','.$v1['nom_champ'];
    }
    if(isset($phpComment['subtype'])){
     $GLOBALS['__listeDesChamps'][$k1]['subtype']=$phpComment['subtype'];
    }
    if(isset($phpComment['param'])){
     if(is_file($GLOBALS['glob_dataPath1'].'/generated/_params/'.$phpComment['param'].'.php')){
      $GLOBALS['__listeDesChamps'][$k1]['param_name']=$phpComment['param'];
      if(isset($phpComment['set']) && $phpComment['set']==true){
       $GLOBALS['__listeDesChamps'][$k1]['param_isSetOfValues']=true;
      }
      if(isset($phpComment['unsetPossible']) && $phpComment['unsetPossible']==true){
       $GLOBALS['__listeDesChamps'][$k1]['unsetPossible']=true;
      }
     }else{
//      echo __FILE__ . ' ' . __LINE__ . ' $v1 = <pre>' . var_export( $v1 , true ) . '</pre>' ; exit(0);
      $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' The param file "' . $phpComment['param'] . '" has not been founded  for this field ' . $v1['nom_champ'] ;
     }
    }
   }else{
    echo __FILE__ . ' ' . __LINE__ . ' error on json for comment definition on comment = <pre>' . var_export( $v1['comment'] , true ) . '</pre>' ; exit(0);
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' The json of the comment <pre>'.var_export( $phpComment , true ) . '</pre> is not correct for the field ' . $v1['nom_champ'] ;
   }
  }
 }
 if($GLOBALS['__showDeleteFieldName']!=''){
  $GLOBALS['__showDeleteFieldName']=substr($GLOBALS['__showDeleteFieldName'],1);
 }
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['__showDeleteFieldName'] , true ) . '</pre>' ; exit(0);
 foreach( $GLOBALS['__listeDesChamps'] as $k0 => $v0){
  if(isset($v0['parentField'])){
   foreach( $GLOBALS['__listeDesChamps'][$k0]['parentField']['fieldList'] as $k1 => $v1){
    
    if($v1['comment']!=''){
     $phpComment=json_decode($v1['comment'],true);
     if($phpComment!==null){
/*      
      foreach($phpComment as $k2=> $v2){
       $GLOBALS['__listeDesChamps'][$k1][$k2]=$v2;
      }
*/
      if(isset($phpComment['subtype'])){
       $GLOBALS['__listeDesChamps'][$k0]['parentField']['fieldList'][$k1]['subtype']=$phpComment['subtype'];
      }
      if(isset($phpComment['param'])){
       if(is_file($GLOBALS['glob_dataPath1'].'/generated/_params/'.$phpComment['param'].'.php')){
        $GLOBALS['__listeDesChamps'][$k0]['parentField']['fieldList'][$k1]['param_name']=$phpComment['param'];
        if(isset($phpComment['set']) && $phpComment['set']==true){
         $GLOBALS['__listeDesChamps'][$k0]['parentField']['fieldList'][$k1]['param_isSetOfValues']=true;
        }
        if(isset($phpComment['unsetPossible']) && $phpComment['unsetPossible']==true){
         $GLOBALS['__listeDesChamps'][$k0]['parentField']['fieldList'][$k1]['unsetPossible']=true;
        }
       }else{
  //      echo __FILE__ . ' ' . __LINE__ . ' $v1 = <pre>' . var_export( $v1 , true ) . '</pre>' ; exit(0);
        $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' The param file "' . $phpComment['param'] . '" has not been founded  for this field ' . $v1['nom_champ'] ;
       }
      }
     }else{
//      echo __FILE__ . ' ' . __LINE__ . ' error on json for comment definition on comment = <pre>' . var_export( $v1['comment'] , true ) . '</pre>' ; exit(0);
      $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' The json of the comment <pre>'.var_export( $phpComment , true ) . '</pre> is not correct for the field ' . $v1['nom_champ'] ;
     }
    }
   }
  }  
 }
 
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['__parentTables'] , true ) . '</pre><pre>' . var_export( $GLOBALS['__listeDesChamps'] , true ) . '</pre>' ; exit(0);
 

}
//============================================================================================================================================
function getTablelinks1($id){
 $nam=array();
 $n['fld_id_pglnks']                   =0;
 $n['fld_parent_table_id_pglnks']      =0;
 $n['fld_parent_field_display_pglnks'] ='';
 $n['fld_parent_field_pglnks']         ='';
 $n['fld_children_table_id_pglnks']    =0;
 $n['fld_child_field_pglnks']          ='';
 $n['fld_link_mandatory_pglnks']       =0;
 $n['fld_tsupd_pglnks']                ='1000-01-01 00:00:00';
 $n['fld_tscrt_pglnks']                ='1000-01-01 00:00:00';
 $n['fld_cntupd_pglnks']               =0;
 $sql='
  SELECT 
   T0.`fld_id_pglnks`                   ,T0.`fld_parent_table_id_pglnks`      ,T0.`fld_parent_field_display_pglnks` ,T0.`fld_parent_field_pglnks`         ,T0.`fld_children_table_id_pglnks`    ,
   T0.`fld_child_field_pglnks`          ,T0.`fld_link_mandatory_pglnks`       ,T0.`fld_tsupd_pglnks`                ,T0.`fld_tscrt_pglnks`                ,T0.`fld_cntupd_pglnks`               
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__tablelinks` T0
  WHERE T0.`fld_id_pglnks` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['fld_id_pglnks']                   = $row[0];
   $n['fld_parent_table_id_pglnks']      = $row[1];
   $n['fld_parent_field_display_pglnks'] = $row[2];
   $n['fld_parent_field_pglnks']         = $row[3];
   $n['fld_children_table_id_pglnks']    = $row[4];
   $n['fld_child_field_pglnks']          = $row[5];
   $n['fld_link_mandatory_pglnks']       = $row[6];
   $n['fld_tsupd_pglnks']                = $row[7];
   $n['fld_tscrt_pglnks']                = $row[8];
   $n['fld_cntupd_pglnks']               = $row[9];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n); 
}
//============================================================================================================================================