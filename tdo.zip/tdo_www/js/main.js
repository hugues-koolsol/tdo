var globalTimeoutSlowServer=1500; // after 1.5 seconds of waiting response a message appears.
var dkW=0,dkH=0;
if(typeof (window.innerWidth) === 'number'){
 dkW = window.innerWidth;
 dkH = window.innerHeight;
}else{
 if(document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
  dkW = document.documentElement.clientWidth;
  dkH = document.documentElement.clientHeight;
 }else{
  if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
   dkW = document.body.clientWidth;
   dkH = document.body.clientHeight;
  }
 }
}
//console.log(dkW)
//=====================================================================================================================
function submitListFromSelect1(elem){
 var parentFormFounded=false;
 var par=elem.parentNode;
 var parentTag=par.tagName.toLowerCase();
 var goOn=true;
 while(goOn){
  if(parentTag=='form'){
   parentFormFounded=true;
   goOn=false;
  }else{
   if(parentTag=='body'){
    goOn=false;
   }
  }
  if(goOn){
   par=par.parentNode;
   parentTag=par.tagName.toLowerCase();
  }
 }
 if(parentFormFounded==true){
  par.submit();
 } 
}
//=====================================================================================================================
function fillValueField1(fieldName,value){
 document.getElementById(fieldName).value=value;
}
//=====================================================================================================================
function fillLinkField1(fieldName,inputId){
 document.getElementById(inputId).value=fieldName;
}
//=====================================================================================================================
function closeColor1(divId){
 document.getElementById(divId).style.display='none';
}
//=====================================================================================================================
function putColor1(valueId  ,value   , buttonId             ,divId                        ,displayId,objTxt                                                                                                                          ,withColorNull,searchColorMode,callBackColor1          ,forceValue){
//       putColor1('xsrch_7','F0F8FF','button_color_xsrch_7','div_of_button_color_xsrch_7',''       ,'{"hexValue":"F0F8FF","webValue":"F0F8FF","webName":"aliceblue","pantoneName":"","hsvValue":"5,5,100","rgbValue":"240,248,255"}','1'          ,'1'            ,'onChangeColorListForm1'); 
// console.log('objTxt=',objTxt,'forceValue=',forceValue,'displayId='+displayId);
 var oldValue=document.getElementById(valueId).value;
 var newValue='';
 if(forceValue!==null && typeof(forceValue) != "undefined"){
  if(displayId!=''){
   document.getElementById(displayId).innerHTML=forceValue;
  }
  document.getElementById(valueId).value=forceValue;
  newValue=forceValue;
  if(searchColorMode==1){
   if(forceValue==''){
    document.getElementById(buttonId).innerHTML=txt2('color all_30_54');
   }else if(forceValue=='NULL'){
    document.getElementById(buttonId).innerHTML=txt2('color null_32_54');    
   }else if(forceValue=='NOT NULL'){
    document.getElementById(buttonId).innerHTML=txt2('color not null_34_54');    
   }
  }
 }else{
  console.log('searchColorMode='+searchColorMode,'divId='+divId);
  if(searchColorMode==1){
   document.getElementById(valueId).value=value;
   newValue=value;
   document.getElementById(buttonId).innerHTML=value;
  }else{
   if(displayId!=''){
    var disp='';
    var obj=JSON.parse(objTxt);
    disp+='<div style="width:35px;height:35px;border:1px #eee inset;background-color:#'+obj.hexValue+'"></div>';   
    disp+='<div>'+obj.hexValue+(obj.webName!=''?','+obj.webName:'')+(obj.pantoneName!=''?',pantone='+obj.pantoneName:'')+(obj.materialName!=''?',material='+obj.materialName:'')+'</div>';   
    document.getElementById(displayId).innerHTML=disp;
   }
   document.getElementById(valueId).value=objTxt;
   newValue=objTxt;
  }
  // {"hexValue":"7FFFD4","webValue":"7FFFD4","webName":"aquamarine","pantoneName":"","hsvName":"50,50,100"}
 }
 closeColor1(divId);
 console.log('callBackColor1=',callBackColor1);
 if(callBackColor1){
  if(!(callBackColor1=='undefined' || callBackColor1 == null || callBackColor1=='')){
   if(oldValue!=newValue){
    eval(''+callBackColor1+'(\''+valueId+'\');');
   }
  }
 }
 
}
//=====================================================================================================================
function onChangeColorListForm1(fieldName){
// console.log(fieldName);
 
 var parentFormFounded=false;
 var par=document.getElementById(fieldName).parentNode;
 var parentTag=par.tagName.toLowerCase();
 var goOn=true;
 while(goOn){
  if(parentTag=='form'){
   parentFormFounded=true;
   goOn=false;
  }else{
   if(parentTag=='body'){
    goOn=false;
   }
  }
  if(goOn){
   par=par.parentNode;
   parentTag=par.tagName.toLowerCase();
  }
 }
 if(parentFormFounded==true){
  par.submit();
 }
}

//=====================================================================================================================
function fillDivColor1(valueId,buttonId,divId,displayId,withColorNull,searchColorMode,colorInit,callBackColor1){
 console.log('colorInit='+colorInit);

  var couleurActuelle=document.getElementById(valueId).value.substr(1).toUpperCase();
  if(couleurActuelle>='000000'&&couleurActuelle<='FFFFFF'){
  }else{
   couleurActuelle='FFFFFF';
  }
 
 var x='<div>';
 x+='<table style="width:100%;"><tbody><tr>';
 if(searchColorMode==1){
  x+='<td style="width:12.4%;text-align:right;">';
  x+='<a href="javascript:putColor1(\''+valueId+'\',\'\',\''+buttonId+'\',\''+divId+'\',\''+displayId+'\',{},\''+withColorNull+'\',\''+searchColorMode+'\',\''+callBackColor1+'\',\'\')">'+txt2('color all_30_54')+'</a>';
  x+='</td>';
  x+='<td style="width:12.4%;text-align:right;">';
  x+='<a href="javascript:putColor1(\''+valueId+'\',\'\',\''+buttonId+'\',\''+divId+'\',\''+displayId+'\',{},\''+withColorNull+'\',\''+searchColorMode+'\',\''+callBackColor1+'\',\'NULL\')">'+txt2('color null_32_54')+'</a>';
  x+='</td>';
  x+='<td style="width:12.4%;text-align:right;">';
  x+='<a href="javascript:putColor1(\''+valueId+'\',\'\',\''+buttonId+'\',\''+divId+'\',\''+displayId+'\',{},\''+withColorNull+'\',\''+searchColorMode+'\',\''+callBackColor1+'\',\'NOT NULL\')">'+txt2('color not null_34_54')+'</a>';
  x+='</td>';
 }else{
  if(withColorNull==1){
   x+='<td style="width:12.4%;text-align:right;">';
   x+='<a href="javascript:putColor1(\''+valueId+'\',\'\',\''+buttonId+'\',\''+divId+'\',\''+displayId+'\',{},\''+withColorNull+'\',\''+searchColorMode+'\',\''+callBackColor1+'\',\'\')">'+txt2('color null_32_54')+'</a>';  
   x+='</td>';
  }
 }
 x+='<td style="width:12.4%;text-align:right;">';
 x+=' <a href="javascript:closeColor1(\''+divId+'\')" style="color:red;">&times;</a>';
 x+='</td>';
 x+='</tr></tbody></table>';
 x+='<iframe width="468" height="500" border="0" ';
 x+=' src="js/_cpicker/index.html?version=0';
 x+='&withColorNull='+withColorNull+'';
 x+='&searchColorMode='+searchColorMode+'';
 x+='&divId='+divId+'';
 x+='&displayId='+displayId+'';
 x+='&buttonId='+buttonId+'';
 x+='&v='+couleurActuelle+'';
 x+='&callBackColor1='+callBackColor1+'';
 x+='&c=putColor1(\''+valueId+'\',[value],[buttonId],[divId],[displayId],[obj],[withColorNull],[searchColorMode],[callBackColor1])"';
 x+='></iframe>';
 x+='<br style="clear:both;"/>';
// console.log('x=',x);
 document.getElementById(divId).innerHTML= x;
 
}
//=====================================================================================================================
function setColor1(valueId,buttonId,displayId,withColorNull,searchColorMode,callBackColor1){ // 
// console.log(valueId,buttonId);
 var widthPop=470;
 var heightPop=500;
 try{
  var divId=document.getElementById('div_of_'+buttonId);
  if(null==divId){
//   console.log('ici');
   var divId=document.createElement('div');
   divId.id='div_of_'+buttonId;
   divId.style.width=widthPop+'px';
   divId.style.height=heightPop+'px';
   divId.style.position='absolute';
   divId.style.backgroundColor='white';
   divId.style.left='0px';
   divId.style.top='0px';
   divId.style.border='2px #eee outset';
   divId.style.border='2px #eee outset';
   divId.style.display='none';
   document.getElementsByTagName('body')[0].appendChild(divId);
//   console.log('ici 2');
  }
 }catch(e){
 }
 var pos1=document.getElementById(buttonId).getBoundingClientRect();
 divId.style.top=(parseInt(pos1.top,10)+getScrollTop1())+'px';
 if(parseInt(pos1.left,10)+widthPop>dkW){
  if((dkW-widthPop-30)<0){
   divId.style.left='0px';
  }else{
   divId.style.left=(dkW-widthPop-30)+'px';
  }
 }else{
  divId.style.left=parseInt(pos1.left,10)+'px';
 }
 divId.style.display='block';
 var hourInit=0,minutInit=0,secondInit=0;
 var yearInit=0,monthInit=0,dayInit=0;
 
 var value=document.getElementById(valueId).value;
 if(value=='NULL' ||value=='NOT NULL' || value==''){
  var colorInit='#ffffff';
 }else{
  var colorInit=value;
 }
 
 fillDivColor1(valueId,buttonId,'div_of_'+buttonId,displayId,withColorNull,searchColorMode,colorInit,callBackColor1);
}

//=====================================================================================================================
function nextMonthDateTime1(valueId,buttonId,divId,nM,nY,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit,callBackDtTim1){
 if(nM==12){
  nM='01';
  nY+=1;
 }else{
  nM=(nM+1)<10?'0'+(nM+1):nM+1;
 }
// console.log(nY+'-'+nM);
 fillDivDateTime1(valueId,buttonId,divId,nY+'-'+nM,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit);
}
//=====================================================================================================================
function previousMonthDateTime1(valueId,buttonId,divId,nM,nY,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit,callBackDtTim1){
 if(nM==1){
  nM='12';
  nY-=1;
 }else{
  nM=(nM-1)<10?'0'+(nM-1):nM-1;
 }
// console.log(nY+'-'+nM);
 fillDivDateTime1(valueId,buttonId,divId,nY+'-'+nM,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit,callBackDtTim1);
}
//=====================================================================================================================
function putDateTime1(nH,nM,nS,valueId,buttonId,divId,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit,callBackDtTim1){
 if(nH==-3&&nM==-3&&nS==-3){
  var theTime='';
  var theTimeTxt=txt2('time all_20_23');
 }else if(nH==-2&&nM==-2&&nS==-2){
  var theTime='NOT NULL';
  var theTimeTxt=txt2('time not null_23_23');
 }else if(nH==-1&&nM==-1&&nS==-1){
  var theTime='NULL';
  var theTimeTxt=txt2('time null_26_23');
 }else{
//  var theTime=(nH<10?'0'+nH:nH)+'-'+(nM<10?'0'+nM:nM)+'-'+(nS<10?'0'+nS:nS);
  var theTime=yearInit+'-'+(monthInit<10?'0'+monthInit:monthInit)+'-'+(dayInit<10?'0'+dayInit:dayInit)+' '+(hourInit<10?'0'+hourInit:hourInit)+':'+(minutInit<10?'0'+minutInit:minutInit)+':'+(secondInit<10?'0'+secondInit:secondInit);
  var theTimeTxt=theTime;
 }
 closeDate1(divId);
 var oldValue=document.getElementById(valueId).value;
 
 document.getElementById(valueId).value=theTime;
 document.getElementById(buttonId).innerHTML=theTimeTxt;
 
 if(callBackDtTim1){
  if(!(callBackDtTim1=='undefined' || callBackDtTim1 == null || callBackDtTim1=='')){
   if(oldValue!=theTime){
    eval(''+callBackDtTim1+'(\''+valueId+'\');');
   }
  }
 }
 
}
//=====================================================================================================================
function fixDateTime1(nY,nM,nD,valueId,buttonId,divId,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,callBackDtTim1){
 var yearInit=nY;
 var monthInit=nM;
 var dayInit=nD;
 console.log(yearInit+'-'+monthInit+'-'+dayInit+' '+hourInit+':'+minutInit+':'+secondInit);
 fillDivDateTime1(valueId,buttonId,divId,nY+'-'+nM,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit,callBackDtTim1);
}
//=====================================================================================================================
function changeDateTime1(valueId,buttonId,divId,withDateTimeNull,searchDateTimeMode,yearInit,monthInit,dayInit,callBackDtTim1){
 var hourInit=parseInt(document.getElementById('hour_'+divId).value,10);
 var minutInit=parseInt(document.getElementById('minute_'+divId).value,10);
 var secondInit=parseInt(document.getElementById('second_'+divId).value,10);
 fillDivDateTime1(valueId,buttonId,divId,yearInit+'-'+monthInit,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit,callBackDtTim1);
}
//=====================================================================================================================
function onChangeDtTimListForm1(fieldName){
// console.log(fieldName);
 
 var parentFormFounded=false;
 var par=document.getElementById(fieldName).parentNode;
 var parentTag=par.tagName.toLowerCase();
 var goOn=true;
 while(goOn){
  if(parentTag=='form'){
   parentFormFounded=true;
   goOn=false;
  }else{
   if(parentTag=='body'){
    goOn=false;
   }
  }
  if(goOn){
   par=par.parentNode;
   parentTag=par.tagName.toLowerCase();
  }
 }
 if(parentFormFounded==true){
  par.submit();
 }
}
//=====================================================================================================================
function fillDivDateTime1(valueId,buttonId,divId,startDate,withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit,callBackDtTim1){
// console.log('startDate='+startDate);
// console.log(yearInit+'-'+monthInit+'-'+dayInit+' '+hourInit+':'+minutInit+':'+secondInit);
 var dateIsSet=false;
 if(startDate==''){
  var value=document.getElementById(valueId).value;
  if(value=='NULL' ||value=='NOT NULL' || value=='' || value=='1000-01-01' ){
//   console.log('ici')
   var dt1=new Date();
  }else{
   var dt1=new Date(value.substr(0,4),parseInt(value.substr(5,2),10)-1,value.substr(8,2)); // 2017-01-01
   dateIsSet=true;
   var dt0=dt1;
  }
 }else{
  var value=document.getElementById(valueId).value;
  var theDay=1;
  if(!(value=='NULL' ||value=='NOT NULL' || value=='' || value=='1000-01-01') ){
   var dt0=new Date(value.substr(0,4),parseInt(value.substr(5,2),10)-1,value.substr(8,2)); // 2017-01-01
   dateIsSet=true;
   theDay=parseInt(value.substr(8),10);
  }
  var dt1=new Date(startDate.substr(0,4),parseInt(startDate.substr(5,2),10)-1 , theDay ); // 2017-01-01
 }
 var nM=dt1.getMonth()+1;
 var nY=dt1.getFullYear();
 var nD=dt1.getDate();
 var cM=nM<10?'0'+nM:''+nM;
 var cD=nD<10?'0'+nD:''+nD;
// console.log(nY,nM,nD);
 var sty1='font-size:1em;display:block;width:100%;height:100%;padding:0!important;min-width:0px;min-height:0px;color:#444;';
 var o1='';
 o1+='<table style="border:0;width:100%;padding:0;margin:0;">';
 o1+='<tr>';
 o1+='<td></td>';
 o1+='<td style="text-align:center;width:12.4%;height:35px;">';
 o1+='<a style="'+sty1+'font-size:1.3em;" href="javascript:previousMonthDateTime1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+',\''+callBackDtTim1+'\')">&lt;</a>';
 o1+='</td>';
 o1+='<td colspan="3" style="text-align:center;width:37.2%;height:35px;">';
 o1+=''+nY + '-' + cM;
 o1+='</td>';
 o1+='<td style="text-align:center;width:12.4%;height:35px;">';
 o1+='<a style="'+sty1+'font-size:1.3em;" href="javascript:nextMonthDateTime1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+',\''+callBackDtTim1+'\')">&gt;</a>';
 o1+='</td>';
 o1+='<td style="text-align:center;width:12.4%;height:35px;">';
 o1+='&nbsp;';
 o1+='</td>';
 o1+='<td style="text-align:center;width:12.4%;height:35px;">';
 o1+='<a style="'+sty1+'color:red;font-size:1.5em;" href="javascript:closeDate1(\''+divId+'\')" >&times;</a>';
 o1+='</td>';
 o1+='</tr>';
 
 var dtFirstDay=new Date(nY,nM-1,1); // 2017-11-01 = mercredi
 var dtFirstDay2=dtFirstDay;
 var dayOfFirstDay=dtFirstDay.getDay();
 if(dayOfFirstDay==0){
  dayOfFirstDay=7;
 }
 var today=new Date();


 o1+='<tr>';
 var arrd1=[
  ''+txt2('calendarWeekShort_1048_11')+'',
  ''+txt2('calendarMondayShort_1048_11')+'',
  ''+txt2('calendarTuesdayShort_1050_11')+'',
  ''+txt2('calendarWednesdayShort_1051_11')+'',
  ''+txt2('calendarThursdayShort_1052_11')+'',
  ''+txt2('calendarFridayShort_1053_11')+'',
  ''+txt2('calendarSaturdayShort_1054_11')+'',
  ''+txt2('calendarSundayShort_1055_11')+'',
 ]
 for(var dd=0;dd<8;dd++){
  o1+='<td style="text-align:center;">'+arrd1[dd]+'</td>'; 
 }
 o1+='</tr>';

 
 o1+='<tr>';
 o1+='<td style="text-align:center;width:12.4%;">'+dtFirstDay.getWeekNumber()+'</td>';
 for(var i=0;i<dayOfFirstDay-1;i++){
  o1+='<td style="text-align:center;width:12.4%;height:35px;border:0;">&nbsp;</td>';
 }
 if(nM==2){
  if((nY%4==0 && !(nY%100==0)) || nY%400==0  ){
   var maxDay=29;
  }else{
   var maxDay=28;
  }
 }else if(nM==4||nM==6||nM==9||nM==11){
  var maxDay=30;
 }else{
  var maxDay=31;  
 }
 var fontWeight='';
 var borderSty1='';
 var lineNumber=1;
 for( var i=1;i<=maxDay;i++){
  fontWeight='';
  borderSty1='';
  if(i==today.getDate()&&nM==today.getMonth()+1 && nY==today.getFullYear()){
   fontWeight='font-weight:bold;color:blue;'
  }
  if(i==dayInit&&nM==monthInit && nY==yearInit){
   borderSty1='border:1px red solid;'
  }
  var bckgrdColor='background-color:#fff;';
  if((dayOfFirstDay+1)%7==0 || (dayOfFirstDay+7)%7==0 ){
   bckgrdColor='background-color:#eee;';
   o1+='<td style="text-align:center;width:12.4%;height:35px;background-color:#eee;">';
  }else{
   o1+='<td style="text-align:center;width:12.4%;height:35px;">';    
  }
  o1+='<a style="'+sty1+fontWeight+borderSty1+bckgrdColor+'" href="javascript:fixDateTime1('+nY+','+nM+','+i+',\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+',\''+callBackDtTim1+'\')" >'+i+'</a>';
  o1+='</td>';       
  if(dayOfFirstDay%7==0){
   o1+='</tr>';
   o1+='<tr>';
   dtFirstDay2=dtFirstDay2.addDays(7);
   if(i+1<=maxDay){
    o1+='<td style="text-align:center;width:12.4%;">'+dtFirstDay2.getWeekNumber()+'</td>'; // numeroDeSemaine
   }
   lineNumber++;
  }
  dayOfFirstDay++;
 }
 o1+='</tr>';
 
 
 var hInit='00',mInit='00',sInit='00',initialValue=document.getElementById(valueId).value;
 if(initialValue.length==8 && initialValue!='NOT NULL'){ // 2017-11-07 00:00:00
  hInit=initialValue.substr(11,2);
  mInit=initialValue.substr(14,2);
  sInit=initialValue.substr(17,2);
 }
 
// o1+='<table style="border:0;width:100%;padding:0;margin:0;">';
 
 var val='',selected='';
 
 o1+='<tr>';
 
 o1+='<td style="width:12.4%;"></td>';
 o1+='<td colspan="6" style="text-align:center;">';
 
 o1+='<select id="hour_'+divId+'" onchange="changeDateTime1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+yearInit+','+monthInit+','+dayInit+',\''+callBackDtTim1+'\')" style="min-height:40px;">';
 for(var i=0;i<=23;i++){
  selected='';
  val=i<10?'0'+i:i;
  if(hourInit==i) selected=' selected="selected" ';
  o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
 }
 o1+='</select>';
 
 o1+=' : <select id="minute_'+divId+'" onchange="changeDateTime1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+yearInit+','+monthInit+','+dayInit+',\''+callBackDtTim1+'\')"  style="min-height:40px;">';
 for(var i=0;i<=59;i++){
  selected='';
  val=i<10?'0'+i:i;
  if(minutInit==i) selected=' selected="selected" ';
  o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
 }
 o1+='</select>';
 
 o1+=' : <select id="second_'+divId+'" onchange="changeDateTime1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+yearInit+','+monthInit+','+dayInit+',\''+callBackDtTim1+'\')" style="min-height:40px;">';
 for(var i=0;i<=59;i++){
  selected='';
  val=i<10?'0'+i:i;
  if(secondInit==i) selected=' selected="selected" ';
  o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
 }
 o1+='</select>';
 
 o1+='</td>';

 o1+='<td style="width:12.4%;"></td>';
 
 o1+='</tr>';

 if(searchDateTimeMode==1){
  var colspan=2;
 }else{
  var colspan=4;
 }
 
 o1+='<tr>'; 
 o1+='<td style="width:12.4%;"></td>';
 
 o1+='<td style="text-align:center;height:35px;">'; // null
 if(searchDateTimeMode==1){
  o1+='<a style="'+sty1+'font-size:0.9em;line-height:2em;" href="javascript:putDateTime1(-1,-1,-1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+',\''+callBackDtTim1+'\')">'+txt2('datetime null_231_281')+'</a>';
 }else{
  if(withDateTimeNull==1){
   o1+='<a style="'+sty1+'font-size:0.9em;line-height:2em;" href="javascript:putDateTime1(-1,-1,-1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+',\''+callBackDtTim1+'\')">'+txt2('datetime null_231_281')+'</a>';
  }
 }
 o1+='</td>';

 o1+='<td style="width:12.4%;"></td>';
 
 o1+='<td style="width:12.4%;text-align:center;height:35px;">'; // not null
 if(searchDateTimeMode==1){
  o1+='<a style="'+sty1+'font-size:0.9em;line-height:2em;" href="javascript:putDateTime1(-2,-2,-2,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+',\''+callBackDtTim1+'\')">'+txt2('datetime not null_235_282')+'</a>';
 }
 o1+='</td>';

 o1+='<td style="width:12.4%;"></td>';

 o1+='<td style="width:12.4%;text-align:center;height:35px;">'; // all
 if(searchDateTimeMode==1){
  o1+='<a style="'+sty1+'font-size:0.9em;line-height:2em;" href="javascript:putDateTime1(-3,-3,-3,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+',\''+callBackDtTim1+'\')">'+txt2('datetime all_239_282')+'</a>';
 }
 o1+='</td>';

/* 
 
 if(searchDateTimeMode==1){
  
 }else{
  o1+='<td style="text-align:center;height:35px;">';
  o1+='';
  o1+='</td>';
  o1+='<td style="width:12.4%;"></td>';
  o1+='<td style="width:12.4%;"></td>';
  
 }
*/
 
 o1+='<td style="width:12.4%;"></td>';
 o1+='<td style="width:12.4%;"></td>';
 
 o1+='</tr>';
 
 
 o1+='<tr>';
 o1+='<td colspan="7" style="text-align:center;height:35px;">';
 o1+='<span id=__span_for_'+valueId+'">'+yearInit+'-'+(monthInit<10?'0'+monthInit:monthInit)+'-'+(dayInit<10?'0'+dayInit:dayInit)+' '+(hourInit<10?'0'+hourInit:hourInit)+':'+(minutInit<10?'0'+minutInit:minutInit)+':'+(secondInit<10?'0'+secondInit:secondInit)+'</span>';
 o1+='</td>';
 o1+='<td style="text-align:center;height:35px;">';
 o1+='<a style="'+sty1+'" href="javascript:putDateTime1(0,0,0,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateTimeNull+','+searchDateTimeMode+','+hourInit+','+minutInit+','+secondInit+','+yearInit+','+monthInit+','+dayInit+',\''+callBackDtTim1+'\')" style="font-size:1.5em;display:block;width:100%;height:100%;">&#10003;</a>';
 o1+='</td>';
 o1+='</tr>';
  
 
 o1+='</table>';
 document.getElementById(divId).innerHTML=o1;
}
//=====================================================================================================================
function setDateTime1(valueId,buttonId,withDateTimeNull,searchDateTimeMode,callBackDtTim1){ // 
// console.log(valueId,buttonId);
 var widthPop=292;
 var heightPop=420;
 try{
  var divId=document.getElementById('div_of_'+buttonId);
  if(null==divId){
//   console.log('ici');
   var divId=document.createElement('div');
   divId.id='div_of_'+buttonId;
   divId.style.width=widthPop+'px';
   divId.style.height=heightPop+'px';
   divId.style.position='absolute';
   divId.style.backgroundColor='white';
   divId.style.left='0px';
   divId.style.top='0px';
   divId.style.border='2px #eee outset';
   divId.style.border='2px #eee outset';
   divId.style.display='none';
   document.getElementsByTagName('body')[0].appendChild(divId);
//   console.log('ici 2');
  }
 }catch(e){
 }
 var pos1=document.getElementById(buttonId).getBoundingClientRect();
 divId.style.top=(parseInt(pos1.top,10)+getScrollTop1())+'px';
 if(parseInt(pos1.left,10)+widthPop>dkW){
  divId.style.left=(dkW-widthPop-30)+'px';
 }else{
  divId.style.left=parseInt(pos1.left,10)+'px';
 }
 divId.style.display='block';
 var hourInit=0,minutInit=0,secondInit=0;
 var yearInit=0,monthInit=0,dayInit=0;
 
 var value=document.getElementById(valueId).value;
 if(value=='NULL' ||value=='NOT NULL' || value==''){
  var dt1=new Date();
  hourInit   = dt1.getHours();
  minutInit  = dt1.getMinutes();
  secondInit = dt1.getSeconds();
 }else{
  var dt1=new Date(value.substr(0,4),parseInt(value.substr(5,2),10)-1,value.substr(8,2)); // 2017-01-01 01:02:03
  hourInit  = parseInt(value.substr(11,2),10);
  minutInit = parseInt(value.substr(14,2),10);
  hourInit  = parseInt(value.substr(17,2),10);
 }
 monthInit=dt1.getMonth()+1;
 yearInit=dt1.getFullYear();
 dayInit=dt1.getDate();
// console.log(yearInit,monthInit,dayInit,hourInit,minutInit,secondInit);
 
 fillDivDateTime1(valueId,buttonId,'div_of_'+buttonId,'',withDateTimeNull,searchDateTimeMode,hourInit,minutInit,secondInit,yearInit,monthInit,dayInit,callBackDtTim1);
}
//=====================================================================================================================
function onChangeTimeListForm1(fieldName){
// console.log(fieldName);
 
 var parentFormFounded=false;
 var par=document.getElementById(fieldName).parentNode;
 var parentTag=par.tagName.toLowerCase();
 var goOn=true;
 while(goOn){
  if(parentTag=='form'){
   parentFormFounded=true;
   goOn=false;
  }else{
   if(parentTag=='body'){
    goOn=false;
   }
  }
  if(goOn){
   par=par.parentNode;
   parentTag=par.tagName.toLowerCase();
  }
 }
 if(parentFormFounded==true){
  par.submit();
 }
}
//=====================================================================================================================
function putTime1(nH,nM,nS,valueId,buttonId,divId,withTimeNull,searchTimeMode,callBackTime1,optTime1){
 if(nH==-3&&nM==-3&&nS==-3){
  var theTime='';
  var theTimeTxt=txt2('time all_20_23');
 }else if(nH==-2&&nM==-2&&nS==-2){
  var theTime='NOT NULL';
  var theTimeTxt=txt2('time not null_23_23');
 }else if(nH==-1&&nM==-1&&nS==-1){
  var theTime='NULL';
  var theTimeTxt=txt2('time null_26_23');
 }else{
//  var theTime=(nH<10?'0'+nH:nH)+'-'+(nM<10?'0'+nM:nM)+'-'+(nS<10?'0'+nS:nS);
  var theTime=document.getElementById('hour_'+divId).value+':'+document.getElementById('minute_'+divId).value+':'+document.getElementById('second_'+divId).value;
  var theTimeTxt=theTime;
 }
 closeDate1(divId);
 var oldValue=document.getElementById(valueId).value;
 document.getElementById(valueId).value=theTime;
 if(optTime1&1==1){
  document.getElementById(buttonId).innerHTML=theTimeTxt.substr(0,5);
 }else{
  document.getElementById(buttonId).innerHTML=theTimeTxt;  
 }
 if(callBackTime1){
  if(!(callBackTime1=='undefined' || callBackTime1 == null || callBackTime1=='')){
   if(oldValue!=theTime){
    eval(''+callBackTime1+'(\''+valueId+'\');');
   }
  }
 }
 if(searchTimeMode!=1){
  if(theTime=='00:00:00'){
   document.getElementById(buttonId).className='success';
  }else if(theTime=='NULL'){
   document.getElementById(buttonId).className='';
  }else{
   document.getElementById(buttonId).className='edit';
  }
 }
 
}
//=====================================================================================================================
function closeTime1(divId){
 document.getElementById(divId).style.display='none';
}
//=====================================================================================================================
function changeTime1(divId){
 var newVal=document.getElementById('hour_'+divId).value+' : '+document.getElementById('minute_'+divId).value+' : '+document.getElementById('second_'+divId).value;
}
//=====================================================================================================================
function fillDivTime1(valueId,buttonId,divId,startTime,withTimeNull,searchTimeMode,callBackTime1,optTime1){
// console.log('startDate='+startDate);


 var hInit='00',mInit='00',sInit='00',initialValue=document.getElementById(valueId).value;
 if(initialValue.length==8 && initialValue!='NOT NULL'){ // 00:00:00
  hInit=initialValue.substr(0,2);
  mInit=initialValue.substr(3,2);
  sInit=initialValue.substr(6,2);
 }
 
 var sty1='font-size:1em;display:block;width:100%;height:100%;padding:0!important;min-width:0px;min-height:0px;color:#444;';
 var o1='';
 o1+='<table style="border:0;width:100%;padding:0;margin:0;">';
 o1+='<tr>';
 
 o1+='<td style="width:12.4%;"></td>';
 if(searchTimeMode==1){ 
  o1+='<td style="text-align:center;height:35px;width:12.4%;">';
  o1+='<a style="'+sty1+'" href="javascript:putTime1(-3,-3,-3,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withTimeNull+','+searchTimeMode+',\''+callBackTime1+'\','+optTime1+')">'+txt2('time all_20_23')+'</a>';
  o1+='</td>';
 }else{
  o1+='<td style="width:12.4%;"></td>';
 }
 if(searchTimeMode==1){
  o1+='<td style="text-align:center;height:35px;width:12.4%;">';
  o1+='<a style="'+sty1+'" href="javascript:putTime1(-1,-1,-1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withTimeNull+','+searchTimeMode+',\''+callBackTime1+'\','+optTime1+')">'+txt2('time null_26_23')+'</a>';
  o1+='</td>';
  
  o1+='<td style="text-align:center;height:35px;">';
  o1+='<a style="'+sty1+'" href="javascript:putTime1(-2,-2,-2,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withTimeNull+','+searchTimeMode+',\''+callBackTime1+'\','+optTime1+')">'+txt2('time not null_23_23')+'</a>';
  o1+='</td>';

 }else{
  o1+='<td style="width:12.4%;"></td>';
  o1+='<td style="width:12.4%;"></td>';  
 }
 o1+='<td style="width:12.4%;"></td>';
 o1+='<td style="width:12.4%;"></td>';
 
 if(searchTimeMode!=1){ 
  o1+='<td style="text-align:center;height:35px;width:12.4%;">';
  o1+='<a style="'+sty1+'" href="javascript:putTime1(-1,-1,-1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withTimeNull+','+searchTimeMode+',\''+callBackTime1+'\','+optTime1+')" >'+txt2('time null_26_23')+'</a>';
  o1+='</td>';
 }else{
  o1+='<td style="width:12.4%;"></td>';
 }
 
 o1+='<td style="text-align:center;height:35px;width:12.4%;">';
 o1+='<a style="'+sty1+'color:red;" href="javascript:closeTime1(\''+divId+'\')">&times;</a>';
 o1+='</td>';
 
 o1+='</tr>';
 
 
 var val='',selected='';
 
 o1+='<tr>';
 
 o1+='<td colspan="7" style="text-align:center;width:86.8%;">';
 
 o1+='<select id="hour_'+divId+'" onchange="changeTime1(\''+divId+'\')" style="min-height:40px;">';
 for(var i=0;i<=23;i++){
  selected='';
  val=i<10?'0'+i:i;
  if(hInit==val) selected=' selected="selected" ';
  o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
 }
 o1+='</select>';
 
 o1+=' : <select id="minute_'+divId+'" onchange="changeTime1(\''+divId+'\')"  style="min-height:40px;">';
 if(optTime1&2==2){
  for(var i=0;i<=59;i+=5){
   selected='';
   val=i<10?'0'+i:i;
   if(mInit==val) selected=' selected="selected" ';
   o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
  }
 }else{
  for(var i=0;i<=59;i++){
   selected='';
   val=i<10?'0'+i:i;
   if(mInit==val) selected=' selected="selected" ';
   o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
  }
 }
 o1+='</select>';
// console.log('optTime1='+optTime1);
 if(optTime1&1==1){
  o1+='<input id="second_'+divId+'" type="hidden" value="00" >';  
 }else{
  o1+=' : <select id="second_'+divId+'" onchange="changeTime1(\''+divId+'\')" style="min-height:40px;">';
  for(var i=0;i<=59;i++){
   selected='';
   val=i<10?'0'+i:i;
   if(sInit==val) selected=' selected="selected" ';
   o1+='<option value="'+val+'" '+selected+'>'+val+'</option>';
  }
  o1+='</select>';
  
 }
 
 o1+='</td>';

 o1+='<td style="text-align:center;width:12.4%;">';
 o1+='<a style="'+sty1+'" href="javascript:putTime1(0,0,0,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withTimeNull+','+searchTimeMode+',\''+callBackTime1+'\','+optTime1+')">&#10003;</a>';
 o1+='</td>';

 o1+='</tr>';
 
 
 if(optTime1&4==4){
  o1+='<tr>'; 
  o1+='<td colspan="5" style="border:0px red solid;text-align:left;">';
  var ttt='';
  for(var j=0;j<=23;j++){
   tt=''+j+''
   if(j<10) tt='0'+j+''
   
   o1+='<a href="javascript:setQuickHourSelect1(\'hour_'+divId+'\',\''+tt+'\')" class="success" style="line-height:25px;padding: 0!important;min-height:22px;margin-left: 4px;font-size:0.8em;">'+tt+'</a>';
   
  }
  o1+='</td>';
  
  o1+='<td colspan="3" style="border:0px red solid;text-align:right;">';
  for(var j=0;j<=55;j+=5){
   tt=''+j+''
   if(j<10) tt='0'+j+'' 
   o1+='<a href="javascript:setQuickMinuteSelect1(\'minute_'+divId+'\',\''+tt+'\')" class="success" style="line-height:25px;padding: 0!important;min-height:22px;margin-left: 4px;font-size:0.8em;">'+tt+'</a>';
  }
  o1+='</td>';
  o1+='</tr>';
 }
 
 

 o1+='</table>';
 document.getElementById(divId).innerHTML=o1;
}
//=====================================================================================================================
function setQuickMinuteSelect1(selId,val){
 var lst=document.getElementById(selId).getElementsByTagName('option');
 for(var i=0;i<lst.length;i++){
  if(lst[i].value==val){
   lst[i].selected='selected';
  }
 }
}
//=====================================================================================================================
function setQuickHourSelect1(selId,val){
 var lst=document.getElementById(selId).getElementsByTagName('option');
 for(var i=0;i<lst.length;i++){
  if(lst[i].value==val){
   lst[i].selected='selected';
  }
 }
}
//=====================================================================================================================
function setTime1(valueId,buttonId,withTimeNull,searchTimeMode,callBackTime1,optTime1){ // 
// console.log(valueId,buttonId);
// put in the database field comment : {"timeOption":"1"} to set up time option
// optTime1: 1=hide seconds , 2=only every 5 minutes , 4=quick links on time and minutes , 8=... , 16=...
//           => 3 = hide seconds and every 5 minuts
//           => 5 = hide seconds and quick links on time and minutes
//           => 6 = every 5 minuts and quick links on time and minutes
//           => 7 = hide seconds and every 5 minuts and quick links on time and minutes

 var widthPop=300;
 var heightPop=100;
 if(optTime1&4==4){
  heightPop=260;
 }
 try{
  var divId=document.getElementById('div_of_'+buttonId);
  if(null==divId){
//   console.log('ici');
   var divId=document.createElement('div');
   divId.id='div_of_'+buttonId;
   divId.style.width=widthPop+'px';
   divId.style.height=heightPop+'px';
   divId.style.position='absolute';
   divId.style.backgroundColor='white';
   divId.style.left='0px';
   divId.style.top='0px';
   divId.style.border='2px #eee outset';
   divId.style.display='none';
   document.getElementsByTagName('body')[0].appendChild(divId);
//   console.log('ici 2');
  }
 }catch(e){
 }
 var pos1=document.getElementById(buttonId).getBoundingClientRect();
 divId.style.top=(parseInt(pos1.top,10)+getScrollTop1())+'px';
 if(parseInt(pos1.left,10)+widthPop>dkW){
  divId.style.left=(dkW-widthPop-30)+'px';
 }else{
  divId.style.left=parseInt(pos1.left,10)+'px';
 }
 divId.style.display='block';
 fillDivTime1(valueId,buttonId,'div_of_'+buttonId,'',withTimeNull,searchTimeMode,callBackTime1,optTime1);
}
//=====================================================================================================================
function getScrollTop1(){
 var a=document.documentElement.scrollTop || window.pageYOffset || document.getElementsByTagName('body')[0].scrollTop || 0;
 a=parseInt(a,10);
 return a;
}
//=====================================================================================================================
function onChangeDateListForm1(fieldName){
// console.log(fieldName);
 
 var parentFormFounded=false;
 var par=document.getElementById(fieldName).parentNode;
 var parentTag=par.tagName.toLowerCase();
 var goOn=true;
 while(goOn){
  if(parentTag=='form'){
   parentFormFounded=true;
   goOn=false;
  }else{
   if(parentTag=='body'){
    goOn=false;
   }
  }
  if(goOn){
   par=par.parentNode;
   parentTag=par.tagName.toLowerCase();
  }
 }
 if(parentFormFounded==true){
  par.submit();
 }

}
//=====================================================================================================================
function closeDate1(divId){
 document.getElementById(divId).style.display='none';
}

//=====================================================================================================================
function previousMonthDate1(valueId,buttonId,divId,nM,nY,withDateNull,searchDateMode,callBackDate1){
 if(nM==1){
  nM='12';
  nY-=1;
 }else{
  nM=(nM-1)<10?'0'+(nM-1):nM-1;
 }
// console.log(nY+'-'+nM);
 fillDivDate1(valueId,buttonId,divId,nY+'-'+nM,withDateNull,searchDateMode,callBackDate1);
}
//=====================================================================================================================
function nextMonthDate1(valueId,buttonId,divId,nM,nY,withDateNull,searchDateMode,callBackDate1){
 if(nM==12){
  nM='01';
  nY+=1;
 }else{
  nM=(nM+1)<10?'0'+(nM+1):nM+1;
 }
// console.log(nY+'-'+nM);
 fillDivDate1(valueId,buttonId,divId,nY+'-'+nM,withDateNull,searchDateMode,callBackDate1);
}
//=====================================================================================================================
function putDate1(nY,nM,nD,valueId,buttonId,divId,withDateNull,searchDateMode,callBackDate1){
 if(nY==-2 && nM==-2 && nD==-2){
  var theDate='NOT NULL';
  var theDateTxt=txt2('not void_163_23');
 }else if(nY==-1 && nM==-1 && nD==-1){
  var theDate='NULL';
  var theDateTxt=txt2('void_166_23');
 }else if(nY==1000&&nM==1&&nD==1){
  var theDate='1000-01-01';
  if(searchDateMode==0){
   var theDateTxt=txt2('void_166_23');   
  }else{
   var theDateTxt=txt2('date all_169_23');
  }
 }else{
  var theDate=nY+'-'+(nM<10?'0'+nM:nM)+'-'+(nD<10?'0'+nD:nD);
  var theDateTxt=theDate;
 }
 closeDate1(divId);
 document.getElementById(valueId).value=theDate;
 document.getElementById(buttonId).innerHTML=theDateTxt;
 if(callBackDate1){
  if(!(callBackDate1=='undefined' || callBackDate1 == null || callBackDate1=='')){
   eval(''+callBackDate1+'(\''+valueId+'\');');
  }
 } 
}
//=====================================================================================================================
function previousYearDate1(valueId,buttonId,divId,nM,nY,withDateNull,searchDateMode,callBackDate1){
 nY-=1;
 nM=(nM)<10?'0'+(nM):nM;
 fillDivDate1(valueId,buttonId,divId,nY+'-'+nM,withDateNull,searchDateMode);
}
//=====================================================================================================================
function nextYearDate1(valueId,buttonId,divId,nM,nY,withDateNull,searchDateMode,callBackDate1){
 nY+=1;
 nM=(nM)<10?'0'+(nM):nM;
 fillDivDate1(valueId,buttonId,divId,nY+'-'+nM,withDateNull,searchDateMode,callBackDate1);
}
//=====================================================================================================================
Date.prototype.getWeekNumber = function(){
  var d = new Date(Date.UTC(this.getFullYear(), this.getMonth(), this.getDate()));
  var dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  var yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
  return Math.ceil((((d - yearStart) / 86400000) + 1)/7)
};
//=====================================================================================================================
Date.prototype.addDays = function(days) {
  var dat = new Date(this.valueOf());
  dat.setDate(dat.getDate() + days);
  return dat;
}
//=====================================================================================================================
function fillDivDate1(valueId,buttonId,divId,startDate,withDateNull,searchDateMode,callBackDate1){
 console.log('startDate='+startDate);
 var dateIsSet=false;
 if(startDate==''){
  var value=document.getElementById(valueId).value;
  if(value=='NULL' ||value=='NOT NULL' || value=='' || value=='1000-01-01' ){
//   console.log('ici')
   var dt1=new Date();
  }else{
   var dt1=new Date(value.substr(0,4),parseInt(value.substr(5,2),10)-1,value.substr(8,2)); // 2017-01-01
   var dt0=dt1;
   dateIsSet=true;
  }
 }else{
  var value=document.getElementById(valueId).value;
  var theDay=1;
  if(!(value=='NULL' ||value=='NOT NULL' || value=='' || value=='1000-01-01') ){
   var dt0=new Date(value.substr(0,4),parseInt(value.substr(5,2),10)-1,value.substr(8,2));
   dateIsSet=true;
   theDay=parseInt(value.substr(8),10);
  }
  var dt1=new Date(startDate.substr(0,4),parseInt(startDate.substr(5,2),10)-1 , theDay );
 }
 var nM=dt1.getMonth()+1;
 var nY=dt1.getFullYear();
 var nD=dt1.getDate();
 var cM=nM<10?'0'+nM:''+nM;
 var cD=nD<10?'0'+nD:''+nD;
// console.log(nY,nM,nD);
 var sty1='font-size:1em;display:block;width:100%;height:100%;padding:0!important;min-width:0px;min-height:0px;color:#444;';
 var sty2='text-align:center;width:12.4%;height:35px;border:1px #ccc solid;';
 var o1='';
 o1+='<table style="border:1px #eee solid;width:100%;padding:0;margin:0;border-collapse:collapse;">';
 o1+='<tr>';
 o1+='<td></td>';      
 o1+='<td style="'+sty2+'">';
 o1+='<a style="'+sty1+'" href="javascript:previousYearDate1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateNull+','+searchDateMode+',\''+callBackDate1+'\')">&lt;</a>';
 o1+='</td>';
 o1+='<td style="'+sty2+'">';
 o1+=nY;
 o1+='</td>';
 o1+='<td style="'+sty2+'">';
 o1+='<a style="'+sty1+'" href="javascript:nextYearDate1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateNull+','+searchDateMode+',\''+callBackDate1+'\')">&gt;</a>';
 o1+='</td>';
 
 if(searchDateMode==0){
  o1+='<td></td>';      
 }else{
  o1+='<td style="'+sty2+'">'; // all
  o1+='<a style="'+sty1+'" href="javascript:putDate1(1000,1,1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateNull+','+searchDateMode+',\''+callBackDate1+'\')">*</a>';
  o1+='</td>';
 }
 
 if(withDateNull==1){
  o1+='<td style="'+sty2+'">';    
  o1+='<a style="'+sty1+'font-size:0.8em;" href="javascript:putDate1(-1,-1,-1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateNull+','+searchDateMode+',\''+callBackDate1+'\')">'+txt2('date null_281_216')+'</a>'; 
  o1+='</td>';
 }else{
  o1+='<td></td>';      
 }
 if(searchDateMode!=0){
  o1+='<td style="'+sty2+'">';    
  o1+='<a style="'+sty1+'font-size:0.8em;" href="javascript:putDate1(-2,-2,-2,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateNull+','+searchDateMode+',\''+callBackDate1+'\')">'+txt2('date not null_284_216')+'</a>'; 
  o1+='</td>';    
 }else{
  o1+='<td></td>';  
 }
 
 o1+='<td  style="'+sty2+'">';
 o1+='<a style="'+sty1+'color:red;font-size:1.5em;" href="javascript:closeDate1(\''+divId+'\')">&times;</a>';
 o1+='</td>';
 
 
 o1+='</tr>';
 o1+='<tr>';
 o1+='<td></td>';  
 o1+='<td style="'+sty2+'">';
 o1+='<a style="'+sty1+'" href="javascript:previousMonthDate1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateNull+','+searchDateMode+',\''+callBackDate1+'\')">&lt;</a>';
 o1+='</td>';
 o1+='<td colspan="3" style="'+sty2+'width:37.2%;">'; 
 o1+=''+nY + '-' + cM;
 o1+='</td>';
 o1+='<td  style="'+sty2+'">';
 o1+='<a style="'+sty1+'" href="javascript:nextMonthDate1(\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+nM+','+nY+','+withDateNull+','+searchDateMode+',\''+callBackDate1+'\')">&gt;</a>';
 o1+='</td>';
 o1+='<td colspan="2"></td>';  
 
 o1+='</tr>';
 
 
 o1+='<tr>';
 var arrd1=[
  ''+txt2('calendarWeekShort_1048_11')+'',
  ''+txt2('calendarMondayShort_1048_11')+'',
  ''+txt2('calendarTuesdayShort_1050_11')+'',
  ''+txt2('calendarWednesdayShort_1051_11')+'',
  ''+txt2('calendarThursdayShort_1052_11')+'',
  ''+txt2('calendarFridayShort_1053_11')+'',
  ''+txt2('calendarSaturdayShort_1054_11')+'',
  ''+txt2('calendarSundayShort_1055_11')+'',
 ]
 for(var dd=0;dd<8;dd++){
  o1+='<td style="text-align:center;">'+arrd1[dd]+'</td>'; 
 }
 o1+='</tr>';
 
 
 
 var dtFirstDay=new Date(nY,nM-1,1); // 2017-11-01 = mercredi
 var dayOfFirstDay=dtFirstDay.getDay();
 var dtFirstDay2=dtFirstDay;
 if(dayOfFirstDay==0){
  dayOfFirstDay=7;
 }
 var today=new Date();
// console.log('dayOfFirstDay='+dayOfFirstDay);
 o1+='<tr>';
 o1+='<td style="text-align:center;">'+dtFirstDay.getWeekNumber()+'</td>';  // numeroDeSemaine
 for(var i=0;i<dayOfFirstDay-1;i++){
  o1+='<td style="text-align:center;width:12.4%;height:35px;border:0;">&nbsp;</td>';
 }
 if(nM==2){
  if((nY%4==0 && !(nY%100==0)) || nY%400==0  ){
   var maxDay=29;
  }else{
   var maxDay=28;
  }
 }else if(nM==4||nM==6||nM==9||nM==11){
  var maxDay=30;
 }else{
  var maxDay=31;  
 }
 var fontWeight='';
 var borderSty1='';
 var lineNumber=1;
 for( var i=1;i<=maxDay;i++){
  fontWeight='';
  borderSty1='';
  if(i==today.getDate()&&nM==today.getMonth()+1 && nY==today.getFullYear()){
   fontWeight='font-weight:bold;color:blue;'
  }
  if(dateIsSet==true && i==nD&&nM==dt0.getMonth()+1 && nY==dt0.getFullYear()){
   borderSty1='border:1px red solid;'
  }
  var bckgrdColor='background-color:#fff;';
  if((dayOfFirstDay+1)%7==0 || (dayOfFirstDay+7)%7==0 ){
   o1+='<td style="'+sty2+'background-color:#eee;">';
   bckgrdColor='background-color:#eee;';
  }else{
   o1+='<td style="'+sty2+'">';    
  }
  o1+='<a style="'+sty1+fontWeight+borderSty1+bckgrdColor+'" href="javascript:putDate1('+nY+','+nM+','+i+',\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateNull+','+searchDateMode+',\''+callBackDate1+'\')">'+i+'</a>';
  o1+='</td>';       
  if(dayOfFirstDay%7==0){
   o1+='</tr>';
   o1+='<tr>';
   dtFirstDay2=dtFirstDay2.addDays(7);
   if(i+1<=maxDay){
    o1+='<td style="text-align:center;">'+dtFirstDay2.getWeekNumber()+'</td>'; // numeroDeSemaine
   }
   lineNumber++;
  }
  dayOfFirstDay++;
 }
/* 
 if(withDateNull==1 || searchDateMode==1){
//  console.log(lineNumber);
  if(lineNumber<=5){
   o1+='</tr>';
   o1+='<tr>';
  }
  o1+='<td colspan="2"  style="'+sty2+'width:24.8%;">';    
  o1+='<a style="'+sty1+'font-size:0.8em;" href="javascript:putDate1(-1,-1,-1,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateNull+','+searchDateMode+','+callBackDate1+')">'+txt2('date null_281_216')+'</a>'; 
  o1+='</td>';
  console.log(searchDateMode);
  if(searchDateMode!=0){
   o1+='<td colspan="2" style="'+sty2+'width:24.8%;">';    
   o1+='<a style="'+sty1+'font-size:0.8em;" href="javascript:putDate1(-2,-2,-2,\''+valueId+'\',\''+buttonId+'\',\''+divId+'\','+withDateNull+','+searchDateMode+','+callBackDate1+')">'+txt2('date not null_284_216')+'</a>'; 
   o1+='</td>';    
  }
  o1+='</tr>';
 }
*/ 
 
 o1+='</table>';
 document.getElementById(divId).innerHTML=o1;
}
//=====================================================================================================================
function setDate1(valueId,buttonId,withDateNull,searchDateMode,callBackDate1){ // 
// console.log(valueId,buttonId);
 var widthPop=292;
 var heightPop=315;
 try{
  var divId=document.getElementById('div_of_'+buttonId);
  if(null==divId){
//   console.log('ici');
   var divId=document.createElement('div');
   divId.id='div_of_'+buttonId;
   divId.style.width=widthPop+'px';
   divId.style.height=heightPop+'px';
   divId.style.position='absolute';
   divId.style.backgroundColor='white';
   divId.style.left='0px';
   divId.style.top='0px';
   divId.style.border='2px #eee outset';
   divId.style.border='2px #eee outset';
   divId.style.display='none';
   document.getElementsByTagName('body')[0].appendChild(divId);
//   console.log('ici 2');
  }
 }catch(e){
 }
 var pos1=document.getElementById(buttonId).getBoundingClientRect();
 divId.style.top=(parseInt(pos1.top,10)+getScrollTop1())+'px';
 if(parseInt(pos1.left,10)+widthPop>dkW){
  divId.style.left=(dkW-widthPop-30)+'px';
 }else{
  divId.style.left=parseInt(pos1.left,10)+'px';
 }
 divId.style.display='block';
 fillDivDate1(valueId,buttonId,'div_of_'+buttonId,'',withDateNull,searchDateMode,callBackDate1);
}
//=====================================================================================================================
function myConfirm1(thenGoTo){
 if(confirm(txt2('sure ?_18_18'))){
  document.location=thenGoTo;
 }
}
//=====================================================================================================================
function myConfirm0(){
 if(confirm(txt2('sure ?_18_18'))){
  return true;
 }
 return false;
}
//=====================================================================================================================
function razDependant1(spanId,inputId){
 try{
  document.getElementById(spanId).innerHTML='';
 }catch(e){}
 try{
  document.getElementById(inputId).value='';
 }catch(e){}
 
}
//=====================================================================================================================
function updateParam1(buttonId,inputId){
// console.log('updateParam1=',buttonId,inputId);
 var data={
  funct   : 'updateParam1',
  id      : document.getElementById(buttonId).getAttribute('data-id'),
  name    : document.getElementById(buttonId).getAttribute('data-name'),
  key     : document.getElementById(buttonId).getAttribute('data-key'),
  lang    : document.getElementById(buttonId).getAttribute('data-lang'),
  paramId : document.getElementById(buttonId).getAttribute('data-paramid'),
  value : document.getElementById(inputId).value
 };
// console.log('data',data); return;
 ajaxCall({
  data  : data,
  url   : 'updateParam1',
  retu  : afterUpdateParam1
 });
}
//=====================================================================================================================
function afterUpdateParam1(dataJson,objSend){
 console.log(dataJson,objSend);
}

//=====================================================================================================================
function menuDropBoot1(v){
 if(v.substr(0,7)=='jumpTo:'){
  document.location=v.substr(7);
 }else if(v.substr(0,15)=='setTranslation:'){
  translate1(v.substr(15));
 }else if(v.substr(0,8)=='setLang:'){
  setLanguage(v.substr(8));
 }else{
  console.log(v);
  document.location=String(document.location);
 }
 setTimeout(slowServer1,globalTimeoutSlowServer); 
}
//=====================================================================================================================
function getLocation(href) {
    var match = href.match(/^(https?\:)\/\/(([^:\/?#]*)(?:\:([0-9]+))?)([\/]{0,1}[^?#]*)(\?[^#]*|)(#.*|)$/);
    return match && {
        href: href,
        protocol: match[1],
        host: match[2],
        hostname: match[3],
        port: match[4],
        pathname: match[5],
        search: match[6],
        hash: match[7]
    }
}
//=====================================================================================================================
function setLanguage(k){
 var loc=getLocation(String(document.location));
 var newSearch='';
 console.log(loc);
 if(loc.search.substr(0,1)=='?' && loc.search.substr(1,1)!=''){
  var tabsearch=loc.search.substr(1).split('&');
  console.log('tabsearch=',tabsearch);
  for(var i=0;i<tabsearch.length;i++){
   var x=tabsearch[i].split('=');
   console.log('x=',x,x[0]);
   if(x[0]=='lang'){
//    tabsearch.splice(i, 1);
   }else{
    console.log('ici');
    if(newSearch!=''){
     newSearch+='&';
    }
    newSearch+=x[0];
    if(x.length>1){
     newSearch+='='+x[1];
    }
   }
  }
  if(newSearch==''){
   newSearch+='lang='+k;
  }else{
   newSearch+='&lang='+k;
  }
 }else{
  newSearch='lang='+k;
 }
 var newLoc=loc.protocol+'//'+loc.host+''+loc.pathname+'?'+newSearch;
// console.log('newLoc=',newLoc);
// return;
 document.location=newLoc;
}
//=====================================================================================================================
function translate1(page){
 var translate=getCookie('translate')
 if(translate==''||translate=='0'){
  setCookie('translate','1');
  document.location=String(document.location);
  return;
 }else{
  if(translate=='1'){
   setCookie('translate','0');
   document.location=String(document.location);
   return;
  }
 }
}
//=====================================================================================================================
function txt1(k){
 return k;
}
//=====================================================================================================================
function txt2(k){
 for(elem in globTablang){
  if(globTablang[elem].key===k){
   return globTablang[elem].value;
  }
 }
 return k;
}
//=====================================================================================================================
function onSortParamWithLang2(context,tree){
 console.log(context,tree);
 var listeDesElementsTries=[]; 
 for(var elem in tree){
  listeDesElementsTries.push(tree[elem].id);
 }
 switch(context.action){
  case 'afterReorganize' :
  var data={
   funct   : 'setSortParamWithLang1',
   idParam : document.getElementById(context.divId).getAttribute('data-idlist'),
   lang    : document.getElementById(context.divId).getAttribute('data-lang'),
   order   : listeDesElementsTries,
  };
//  console.log(data);
  ajaxCall({
   data  : data,
   url   : 'setSortParamWithLang1',
   retu  : afterSetSortParamWithLang2
  });
  break;  
 }
}
//=====================================================================================================================
function afterSetSortParamWithLang2(dataJson,objSend){
 console.log(dataJson,objSend);
}
//=====================================================================================================================
function onSortParamWithoutLang2(context,tree){
 console.log(context,tree);
 var listeDesElementsTries=[]; 
 for(var elem in tree){
  listeDesElementsTries.push(tree[elem].id);
 }
 
 switch(context.action){
  case 'afterReorganize' :
  var data={
   funct   : 'setSortParamWithoutLang1',
   idParam : document.getElementById(context.divId).getAttribute('data-idlist'),
   order   : listeDesElementsTries,
  };
  console.log(data);

  ajaxCall({
   data  : data,
   url   : 'setSortParamWithoutLang1',
   retu  : afterSetSortParamWithoutLang2
  });

  break;
 }

}
//=====================================================================================================================
function afterSetSortParamWithoutLang2(dataJson,objSend){
 console.log(dataJson,objSend);
}
//=====================================================================================================================
function onSortParamWithoutLang(e){
 console.log('dans onSortParamWithoutLang, e=',e)
 var listName=e.target.id;
 var listeDesElementsTries=[];
 var lst=document.getElementById(listName).getElementsByTagName('li');
 for(var i=0;i<lst.length;i++){
  listeDesElementsTries.push(parseInt(lst[i].id.replace(/sort__p__/,''),10))
 }
 console.log('listName="'+listName+'" ',listeDesElementsTries,document.getElementById(listName).getAttribute('data-idlist'),document.getElementById(listName).getAttribute('data-paramname'));
 var data={
  funct:'setSortParamWithoutLang1',
  idParam:document.getElementById(listName).getAttribute('data-idlist'),
  paramName:document.getElementById(listName).getAttribute('data-paramname'),
  order:listeDesElementsTries,
 };
 ajaxCall({
  data  : data,
  url   : 'setSortParamWithoutLang1',
  retu  : afterSetSortParamWithoutLang1
 });
}
//=====================================================================================================================
function afterSetSortParamWithoutLang1(dataJson,objSend){
 console.log(dataJson,objSend);
}
//=====================================================================================================================
function modifierLeMotDePasse(divId,btnId,fieldName){
 var t='';
 if(document.getElementById(divId).innerHTML==''){
  document.getElementById(btnId).innerHTML=txt2('do not modify password_214_49');
  document.getElementById(divId).innerHTML=txt2('password_215_49')+' : <input type="password" value="" id="'+fieldName+'" name="'+fieldName+'" /><br />'+txt2('Confirmation_215_152')+' : <input type="password" value="" id="'+fieldName+'_confirm" name="'+fieldName+'_confirm" />';
 }else{
  document.getElementById(divId).innerHTML='';
  document.getElementById(btnId).innerHTML=txt2('Update the password_218_49');
 }
}
//=====================================================================================================================
function modifierLeMotDePasse2(divId,btnId,fieldName){
 var t='';
 if(document.getElementById(divId).innerHTML==''){
  document.getElementById(btnId).innerHTML=txt2('do not modify my password_225_49');
  var t1=txt2('my actual password_226_15')+' : <input type="password" value="" id="__actualpassword" name="__actualpassword" />';
  t1+='<br />'+txt2('my new password_227_21')+' : <input type="password" value="" id="'+fieldName+'" name="'+fieldName+'" />';
  t1+='<br />'+txt2('my new password confirm_228_21')+' : <input type="password" value="" id="'+fieldName+'_confirm" name="'+fieldName+'_confirm" />'
  document.getElementById(divId).innerHTML=t1;
 }else{
  document.getElementById(divId).innerHTML='';
  document.getElementById(btnId).innerHTML=txt2('Update my password_232_49');
 }
}
function mouseOverTranslate(s){
 document.getElementById(s).background='white'; 
}
function mouseOutTranslate(s){
 document.getElementById(s).background='red';
}
//=====================================================================================================================
function tanslateMenu2(fromId,id){
 ajaxCall({
  data  : {funct:'translateMenu2',value:document.getElementById(fromId).value,id:id,fromId:fromId},
  url   : 'translateMenu2',
  retu  : afterTanslateMenu2
 });
}
//=====================================================================================================================
function afterTanslateMenu2(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.fromId).style.background='lime';
}
//=====================================================================================================================
function tanslateMenu1(fromId,page,lang){
 ajaxCall({
  data  : {funct:'translateMenu1',value:document.getElementById(fromId).value,page:page,lang:lang,fromId:fromId},
  url   : 'translateMenu1',
  retu  : afterTanslateMenu1
 });
}
//=====================================================================================================================
function afterTanslateMenu1(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.fromId).style.background='lime';
}
//=====================================================================================================================
function launchTranslate(){
 ajaxCall({
  data  : {funct:'getPageToTranslate1',page:globBNF,page_id:zz_page_id},
  url   : 'getPageToTranslate1',
  retu  : afterTranslate1
 });
}
function getTranslateValueInit(key,lang){
 theValue='';
 theBackgroundColor='';
 if('the value must be numerical for the field'==key){
  if(lang=='fr'){
   theValue='la valeur doit être numérique pour le champ';
   theBackgroundColor='background-color:lightgreen;'
  }else if(lang=='en'){
   theValue='the value must be numerical for the field';
   theBackgroundColor='background-color:lightgreen;'
  }
 }
 else if('no_record_founded'==key){
  if(lang=='fr'){
   theValue='aucune valeur trouvée avec les critères indiqués';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='no values were founded with these criterias';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('page_title_list'==key){
  if(lang=='fr'){
   theValue='liste de';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='list of the ';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('add_a_new_record'==key){
  if(lang=='fr'){
   theValue='ajouter une nouvelle un nouveau ';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='add a new ';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('the new value has been inserted'==key){
  if(lang=='fr'){
   theValue='une nouvelle un nouveau xxx a été inséré';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='the new value has been inserted';
   theBackgroundColor='background-color:orange;'
  }
 } 
 else if('update a record'==key){
  if(lang=='fr'){
   theValue='modification d\'un d\'une xxx';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='modification of a xxx';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('Add a new record'==key){
  if(lang=='fr'){
   theValue='ajout d\'un d\'une xxx';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='add a new xxx';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if(key.indexOf('_id_')>=0){
  if(lang=='fr'){
   theValue='id';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='id';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if(key.indexOf('must not be empty')>=0){
  if(lang=='fr'){
   theValue='le la xxx ne doit pas être vide';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='the xxx must not be void';
   theBackgroundColor='background-color:orange;'
  }
 }
 
 return {theValue:theValue,theBackgroundColor:theBackgroundColor};
}
//=====================================================================================================================
function afterTranslate1(dataJson,objSend){
// console.log(dataJson,objSend);
 var bgColor='white';
 var out='';
 var theInitTranslatedValue={};
 if(dataJson.status=='OK'){
  var lstToTranslate='';
  lstToTranslate+='<tr><td colspan="5">'+globLang+'</td></tr>';
  var i=0;
//  console.log(dataJson.output);
  for(var elem in dataJson.output){
//   console.log(elem , dataJson.output[elem]);
   if(dataJson.output[elem].type=='txt1'){
    lstToTranslate+='<tr id="trjs__tr_'+i+'">';
    lstToTranslate+='<td style="width:35em;">';
    lstToTranslate+=''+globLang+'';
    theInitTranslatedValue=getTranslateValueInit(dataJson.output[elem].key,globLang);
    lstToTranslate+='<input type="text" value="'+ent1(theInitTranslatedValue.theValue)+'" id="trjs__va_'+i+'" style="width:30em;font-size:0.8em;'+theInitTranslatedValue.theBackgroundColor+'">';
    lstToTranslate+='<button onclick="translate2('+i+','+zz_page_id+','+dataJson.output[elem].lineNumber+','+dataJson.output[elem].colNumber+',\''+objSend.data.page+'\')" id="trjs__inp_'+i+'" style="min-width:15px;width:15px;padding:0;">T</button>';
    lstToTranslate+='</td>';
    lstToTranslate+='<td id="trjs__ke_'+i+'" style="background-color:'+bgColor+';">'+dataJson.output[elem].key+'</td>';
    lstToTranslate+='<td style="font-size:0.8em;">'+ent1(dataJson.output[elem].line)+'</td>';
    lstToTranslate+='</tr>';
   }
   i++;
  }
//  console.log('lstToTranslate=',lstToTranslate);
  if(lstToTranslate!=''){
   out+='<table border="1">'+lstToTranslate+'</table>';
  }
  var listeDesBoutonsTranslateAvecCles=[];
  var numberOfLanguages=0;
  for(var lang in globAvailableLanguages){
   numberOfLanguages++;
  }
  var elem2='';
  if(dataJson.translateValues!=null){
   var lstValTranslated='<table border="1" style="border-collapse:collapse;"><tr><th>key</th><th>lang</th><th>value</th></tr>';
   for(var elem in dataJson.translateValues){
    var countLanguage=0;
    for( var lang in globAvailableLanguages){
     countLanguage++;
     lstValTranslated+='<tr>';
     if(countLanguage==1){
      lstValTranslated+='<td rowspan="'+numberOfLanguages+'" style="white-space: pre-wrap;word-break: break-word;max-width: 301px;">'+elem+'</td>';
     }
     lstValTranslated+='<td>'+lang+'</td>';
     lstValTranslated+='<td>';
     if(dataJson.translateValues[elem][lang]){
      if(dataJson.translateValues[elem][lang].value != ''){
       lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem)+'" type="text" value="'+ent1(dataJson.translateValues[elem][lang].value)+'" style="width:30em;font-size:0.8em;" />';     
      }else{
       lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem)+'" type="text" value="'+ent1(dataJson.translateValues[elem][lang].value)+'" style="background-color:red;width:30em;font-size:0.8em;" />';     
      }
     }else{
      elem2=elem;
      if(elem.lastIndexOf('_')>=0){
       elem2=elem.substr(0,elem.lastIndexOf('_'));
       if(elem2.lastIndexOf('_')>=0){
        elem2=elem2.substr(0,elem2.lastIndexOf('_'));
       }
      }
      
      theInitTranslatedValue=getTranslateValueInit(elem2,lang);
      if(theInitTranslatedValue.theValue==''){
       lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem)+'" type="text" value="" style="background-color:red;width:30em;font-size:0.8em;" />';           
      }else{
       lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem)+'" type="text" value="'+ent1(theInitTranslatedValue.theValue)+'" style="width:30em;font-size:0.8em;'+theInitTranslatedValue.theBackgroundColor+'" />';           
      }
     }
     lstValTranslated+='<button ';
     lstValTranslated+=' type="button" ';
     lstValTranslated+=' id="'+lang+'__'+ent1(elem)+'" ';
     lstValTranslated+=' style="width:15px;height:35px;min-width:15px;min-height:35px;padding:0;border-radius:2px;"';
     lstValTranslated+=' data-pageid="'+zz_page_id+'"';
     lstValTranslated+=' data-fromValue="true"';
     lstValTranslated+=' data-otherSpan=""';
     lstValTranslated+=' data-idparent="translate__key_'+lang+'_'+ent1(elem)+'"';
     lstValTranslated+=' data-idtranslate="'+globBNF+'|'+ent1(elem)+'|'+lang+'"';
     lstValTranslated+='>T</button>';
     listeDesBoutonsTranslateAvecCles.push(lang+'__'+ent1(elem));
     lstValTranslated+='</td>';
    }
    lstValTranslated+='</tr>';
   }
   lstValTranslated+='</table>'
   out+=lstValTranslated;
  }
  
//  console.log('objSend=',objSend);
  out+='<button onclick="writeTranslationFiles1('+objSend.data.page_id+',\''+objSend.data.page+'\')">Générer les fichiers de traduction</button>';
  
  var lst=document.getElementsByTagName('span');
  var lstElements=[];
  for(var i=0;i<lst.length;i++){
   if(lst[i].className && lst[i].className=='forTranslation'){
    var parentIsAnchorOrButton=false;
    if(lst[i].parentNode.nodeName.toLowerCase()=='a' || lst[i].parentNode.nodeName.toLowerCase()=='button'){
     parentIsAnchorOrButton=true;
    }
    var newElement=document.createElement('button');
    newElement.innerHTML='T';
    newElement.type='button';
    newElement.style.width='15px';
    newElement.style.height='15px';
    newElement.style.minWidth='15px';
    newElement.style.minHeight='15px';
    newElement.style.padding='0';
    newElement.style.borderRadius='2px';
    newElement.setAttribute('data-idtranslate',lst[i].getAttribute('data-idtranslate'));
    newElement.setAttribute('data-idparent',lst[i].id);
    newElement.setAttribute('data-pageid',zz_page_id);
    if(parentIsAnchorOrButton){
     
     newElement.setAttribute('data-otherSpan','other__span__'+lst[i].id);
     var newSpan=document.createElement('span');
     newSpan.id='other__span__'+lst[i].id;
     newSpan.setAttribute('data-idtranslate',lst[i].getAttribute('data-idtranslate'));
     newSpan.setAttribute('data-idparent',lst[i].id);
     newSpan.contentEditable=true
     newSpan.contentEditable="true";
     newSpan.setAttribute("contenteditable", "true");
     newSpan.innerHTML=lst[i].innerHTML;
     newSpan.className='forTranslation2';
     lst[i].parentNode.parentNode.insertBefore(newElement, lst[i].parentNode.nextSibling);
     lst[i].parentNode.parentNode.insertBefore(newSpan, lst[i].parentNode.nextSibling);
    }else{
     newElement.setAttribute('data-otherSpan','');
     lst[i].parentNode.insertBefore(newElement, lst[i].nextSibling);
    }
    lstElements.push(newElement);
   }
  }
  
  
  document.getElementById('zztranslate').innerHTML=out;
  if(lstElements.length>0){
   for(var i=0;i<lstElements.length;i++){
    lstElements[i].addEventListener('click',addTranslation,false);
   }
  }
  
//  console.log('listeDesBoutonsTranslateAvecCles=' , listeDesBoutonsTranslateAvecCles );
  
  if(listeDesBoutonsTranslateAvecCles.length>0){
   for(var i=0;i<listeDesBoutonsTranslateAvecCles.length;i++){
    try{
     document.getElementById(listeDesBoutonsTranslateAvecCles[i]).addEventListener('click',addTranslation,false);
    }catch(e){
     console.log('e=',e,listeDesBoutonsTranslateAvecCles[i]);
    }
   }
   
  }
  
 }
}
//=====================================================================================================================
function translateJs1(i){
 var data={
  funct   : 'translateJs1',
  line    : document.getElementById('trjs__inp_'+i).getAttribute('data-line'),
  column  : document.getElementById('trjs__inp_'+i).getAttribute('data-col'),
  key     : document.getElementById('trjs__ke_'+i).innerHTML,
  value   : document.getElementById('trjs__va_'+i).value,
  page    : 'js/main.js',
  lang    : globLang ,
  elem    : 'trjs__va_'+i ,
  butt    : 'trjs__inp_'+i ,
  page_id : 0 ,
 }
 console.log(data);

 ajaxCall({
  data  : data,
  url   : 'translateJs1',
  retu  : afterTranslateJs1
 });

}
//=====================================================================================================================
function afterTranslateJs1(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.elem).style.background='lime';
 document.getElementById(objSend.data.butt).style.display='none';
}
//=====================================================================================================================
function translate2(i,page_id,lineNumber,columnNumber,pageName){
 var data={
  funct   : 'translatePage2',
  line    : lineNumber    ,
  column  : columnNumber  ,
  key     : document.getElementById('trjs__ke_'+i).innerHTML         ,
  value   : document.getElementById('trjs__va_'+i).value             ,
  page    : pageName ,
  lang    : globLang       ,
  elem    : 'trjs__va_'+i  ,
  butt    : 'trjs__inp_'+i ,
  page_id : page_id ,
 }
 ajaxCall({
  data  : data,
  url   : 'translatePage2',
  retu  : afterTranslate2
 });
 
}
//=====================================================================================================================
function afterTranslate2(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.elem).style.background='lime';
 document.getElementById(objSend.data.butt).style.display='none';
}
//=====================================================================================================================
function writeTranslationFiles1(pageId,pageName){
 var data={
  funct   : 'writeTranslationFiles1',
  page    : pageName ,
  page_id : pageId   ,
 }
 ajaxCall({
  data  : data,
  url   : 'writeTranslationFiles1',
  retu  : afterWriteTranslationFiles1
 });
}
//=====================================================================================================================
function afterWriteTranslationFiles1(dataJson,objSend){
 console.log(dataJson,objSend);
}
//=====================================================================================================================
function addTranslationJs1(e){
 var elem=e.srcElement?e.srcElement:e;
// console.log(elem);
 var targetText='';
 var srcZone='';
 srcZone=elem.getAttribute('data-idparent');
 targetText=document.getElementById(elem.getAttribute('data-idparent')).value;
 var targetTranslation=elem.getAttribute('data-idtranslate').split('|');
 var data={
  funct   : 'addTranslationJs1',
  key     : revent1(targetTranslation[1]),
  page    : targetTranslation[0],
  lang    : targetTranslation[2],
  value   : targetText,
  page_id : 0 ,
  srcZone : srcZone ,
 }
 ajaxCall({
  data  : data,
  url   : 'addTranslationJs1',
  retu  : afterAddTranslationJs1
 });
}
//=====================================================================================================================
function afterAddTranslationJs1(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.srcZone).style.background='lime';
}
//=====================================================================================================================
function addTranslation(e){
 var elem=e.srcElement?e.srcElement:e;
// console.log(elem);
 var targetText='';
 var srcZone='';
 if(elem.getAttribute('data-otherSpan')==''){
  srcZone=elem.getAttribute('data-idparent');
  if(elem.getAttribute('data-fromValue')=='true'){
   targetText=document.getElementById(elem.getAttribute('data-idparent')).value;
  }else{
   targetText=document.getElementById(elem.getAttribute('data-idparent')).innerHTML;
  }
  
 }else{
  srcZone=elem.getAttribute('data-otherSpan');
  if(elem.getAttribute('data-fromValue')=='true'){
   targetText=document.getElementById(elem.getAttribute('data-otherSpan')).value;
  }else{
   targetText=document.getElementById(elem.getAttribute('data-otherSpan')).innerHTML;
  }
 }
 var page_id=elem.getAttribute('data-pageid');
 var targetTranslation=elem.getAttribute('data-idtranslate').split('|');

 var data={
  funct   : 'translateText1',
  key     : revent1(targetTranslation[1]),
  page    : targetTranslation[0],
  lang    : targetTranslation[2],
  value   : targetText,
  page_id : page_id ,
  srcZone : srcZone ,
 }
 ajaxCall({
  data  : data,
  url   : 'translateText1',
  retu  : afterTranslateText1
 });
}
//=====================================================================================================================
function afterTranslateText1(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById(objSend.data.srcZone).style.background='lime';
}
//=====================================================================================================================
function addTranslateSys1(i){
 var data={
  funct   : 'addTranslateSys1',
  key     : document.getElementById('trjs__ke_'+i).value,
  lang    : document.getElementById('trjs__la_'+i).value,
  value   : document.getElementById('trjs__va_'+i).value,
  i       : i
 }
 ajaxCall({
  data  : data,
  url   : 'addTranslateSys1',
  retu  : afterAddTranslateSys1
 });
}
//=====================================================================================================================
function afterAddTranslateSys1(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById('trjs__va_'+objSend.data.i).style.background='lime';
}
//====================================================================================================================
function getCookie(cn){
 var cookie=document.cookie;
 var cooKieValue='';
//    console.log(cookie,cn);
 var posStart=cookie.indexOf(cn+'=');
 if(posStart>=0){
  var pos2=cookie.indexOf(';',posStart+1);
  if(pos2===-1){
   pos2=cookie.length;
  }
  var cookieString=cookie.substr(posStart,pos2-posStart);
  cooKieValue=cookieString.substr(cn.length+1);
 }
 return cooKieValue;
}
//====================================================================================================================
function setCookie(cn,cv){
 var today=new Date();
 var expires_date=new Date(today.getTime()+(1000*60*60*24*365));
 document.cookie=encodeURI(cn)+'='+encodeURI(cv)+';expires='+expires_date.toGMTString();
} 
//=====================================================================================================================
function ent1(s){
 var x=s.replace(/</g,'&lt;');
 x=x.replace(/>/g,'&gt;');
 x=x.replace(/"/g,'&quot;');
 return x;
}
//=====================================================================================================================
function revent1(s){
 var x=s.replace(/&lt;/g,'<');
 x=x.replace(/&gt;/g,'>');
 x=x.replace(/&quote;/g,'"');
 return x;
}
//=====================================================================================================================
function ajaxCall(obj){
 var ajax=null;
 if(window.XMLHttpRequest){
  ajax=new XMLHttpRequest();
 }else if(window.ActiveXObject){
  ajax=new ActiveXObject("Microsoft.XMLHTTP");
 }
 if(ajax===null){
  alert('No ajax call on this browser');
  return;
 }
//  console.log(obj.url);
 ajax.open("POST",'za_ajax.php?'+obj.url,true);
 ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
 if(obj.timeout){
  ajax.timeout = obj.timeout;
 }else{
  ajax.timeout = 6000; // 6 secondes 
 }
 ajax.onreadystatechange=function anonymous(){
  if(ajax.readyState===4){
   var returnObject=null;
   if(ajax.status===200){
    try{
     returnObject=JSON.parse(ajax.responseText);
     probablementOffLine=false;
    }catch(e){
     console.log('Erreur probable dans le décodage après un appel ajax (vérifiez utf-8) %o',ajax,obj,e);
     return;
    }
    try{
     obj.retu(returnObject,obj);
    }catch(e){
     console.log('erreur de call %o',ajax,e);
     return;
    }
   }else{
    console.log('Erreur ajax 3 ',ajax);
    try{
     returnObject={status:'KO',message:'offline'};
     probablementOffLine=true;
     obj.retu(returnObject,obj);
    }catch(ec){
     console.log(ec,obj);
    }
    return;
   }
  }
 };
 try{
  ajax.send('data='+encodeURIComponent(JSON.stringify(obj.data)));
 }catch(er){
  console.log(er,obj);
  try{
   var returnObject={status:'KO',message:'offline'};
   obj.retu(returnObject,obj);
  }catch(ec){
   console.log(ec,obj);
  }
 }
}
//=====================================================================================================================
function displaySlowServer(){
 var opa=document.getElementById('sloserver1').style.opacity*100;
 if(opa<100){
  document.getElementById('sloserver1').style.opacity=opa/100+0.1;
  setTimeout(displaySlowServer,100);
 }
}
//=====================================================================================================================
function slowServer1(){
 var divId=document.createElement('div');
 divId.id='sloserver1';
 divId.style.top='55px';
 divId.style.left='0px';
 divId.style.position='fixed';
 divId.style.padding='8px';
 divId.style.zIndex=10000;
 divId.style.border='2px #eee outset';
 divId.style.border='2px #eee outset';
 divId.style.backgroundColor='yellow';
 divId.style.color='red';
 divId.style.textAlign='center';
 divId.style.fontSize='2em';
 divId.style.opacity=0.0;
 divId.innerHTML=txt2('Sorry, the server is very slow_1671_23');
 document.getElementsByTagName('body')[0].appendChild(divId);
 setTimeout(displaySlowServer,0);
}
//=====================================================================================================================
function clickLink1(e){
 console.log(e.target);
 try{
  e.target.className="unset";
 }catch(e1){
  console.log(e1);
 }
 setTimeout(slowServer1,globalTimeoutSlowServer);
}
//=====================================================================================================================
function clickButton1(e){
 try{
  e.target.style.visibility="hidden";
 }catch(e1){
  console.log(e1);
 }
 setTimeout(slowServer1,globalTimeoutSlowServer);
}
//=====================================================================================================================
function trySetMenuSelect(curUrl){
 var setUpSelectDone=0;
 try{
  var lst1=document.getElementById('menuDrop1').getElementsByTagName('option');
  for(var i=0;i<lst1.length;i++){
   if(lst1[i].value && lst1[i].value.indexOf('setTranslation')<0 && lst1[i].value.indexOf(curUrl)>=0){
    document.getElementById('menuDrop1').style.background='#'+globalCssSettings1['menu']['activeBackgroundColor']['hexValue'];
    lst1[i].selected="selected"; //document.getElementById('menuDrop1').selectedIndex=i; 
    setUpSelectDone=1;
    break;
   }
  }
  var lst2=document.getElementById('menuDrop2').getElementsByTagName('option');
  for(var i=0;i<lst2.length;i++){
   if(lst2[i].value && lst2[i].value.indexOf('setTranslation')<0 && lst2[i].value.indexOf(curUrl)>=0){
    document.getElementById('menuDrop2').style.background='#'+globalCssSettings1['menu']['activeBackgroundColor']['hexValue'];
    lst2[i].selected="selected"; //document.getElementById('menuDrop1').selectedIndex=i; 
    setUpSelectDone=2;
    break;
   }
  }
 }catch(e){}
 return setUpSelectDone;
}
//=====================================================================================================================
function fixMenu1(){
 var setUpSelectDone=-1,newUrl='',curUrl='';
 if('undefined' != typeof globalChooseUrlBack){ // is set in choose list
  curUrl=globalChooseUrlBack
 }else{
  curUrl=String(document.location);
 }
 curUrl=curUrl.substr(curUrl.lastIndexOf('/')+1);
 if(curUrl.indexOf('#')>0){
  curUrl=curUrl.substr(0,curUrl.indexOf('#'));
 }
 if(curUrl.indexOf('?')>0){
  curUrl=curUrl.substr(0,curUrl.indexOf('?'));
 }
 if(curUrl!=''){
  try{
   setUpSelectDone=trySetMenuSelect(curUrl);
   if(setUpSelectDone==0){
    if(globalPageList[curUrl] && globalPageList[curUrl].fld_isaction_pages=='1' && globalPageList[curUrl].fld_parentN_pages!='' ){
     if(globalPageList[curUrl])
     newUrl=globalPageList[globalPageList[curUrl].fld_parentN_pages].fld_name_pages;
     setUpSelectDone=trySetMenuSelect(newUrl);
     if(setUpSelectDone==0){
      var lst2=document.getElementById('menuScroller').getElementsByTagName('a');
      for(var i=0;i<lst2.length;i++){
       if(lst2[i].href && lst2[i].href.indexOf('setTranslation')<0 && lst2[i].href.indexOf(newUrl)>=0){
        lst2[i].style.background='#'+globalCssSettings1['menu']['activeBackgroundColor']['hexValue'];
        setUpSelectDone=3;
        break;
       }
      }
     }
    }
   }
  }catch(e){}
  if(setUpSelectDone==1 || setUpSelectDone==2){
   if(setUpSelectDone==1){
    var pos1=document.getElementById('menuDrop1').getBoundingClientRect();
    document.getElementById('menuScroller').scrollTo(pos1.left,0);
   }
   if(setUpSelectDone==2){
    var pos1=document.getElementById('menuDrop2').getBoundingClientRect();
    document.getElementById('menuScroller').scrollTo(pos1.left,0);
   }
  }
  if(setUpSelectDone==0){
   try{
    var lst1=document.getElementById('menuDrop1').getElementsByTagName('option');
    for(var i=0;i<lst1.length;i++){
     lst1[i].selected="";
    }
   }catch(e){}
   try{
    var lst2=document.getElementById('menuDrop2').getElementsByTagName('option');
    for(var i=0;i<lst2.length;i++){
     lst2[i].selected="";
    }
   }catch(e){}
  }
  var lst2=document.getElementById('menuScroller').getElementsByTagName('a');
  for(var i=0;i<lst2.length;i++){
   if(lst2[i].href && lst2[i].href.indexOf(curUrl)>=0){
    var pos=lst2[i].getBoundingClientRect();
    if(pos.left+pos.width>dkW){
     var qtScroll=parseInt((pos.left+pos.width)-dkW,10)
     document.getElementById('menuScroller').scrollTo(qtScroll+15,0);
    }
   }
  }
 }
}
//=====================================================================================================================
function onSortPagesOfGroups1(){
// console.log('onSortPagesOfGroups1');
 var listeDesElementsTries=[];
 var list=document.getElementById('MyList1').getElementsByTagName('li');
 for(var i=0;i<list.length;i++){
  if(list[i].className=='sortable'){
   listeDesElementsTries.push(list[i].id);
  }
 }
 if(listeDesElementsTries.length>1){
  var data={
   funct:'setSortPagesOfGroup1',
   sortListGroupId:document.getElementById('sortListGroupId').value,
   order:listeDesElementsTries,
  };
  ajaxCall({
   data  : data,
   url   : 'setSortPagesOfGroup1',
   retu  : afterSetSortPagesOfGroup2
  });
 }
}
//=====================================================================================================================
function onSortPagesOfGroups2(context,tree){
 // option 2 : sort with the tree function
 switch(context.action){
  case 'afterReorganize' :
   var listeDesElementsTries=[];
   for(var elem in tree){
    listeDesElementsTries.push(tree[elem].id);
   }
   var data={
    funct:'setSortPagesOfGroup1',
    sortListGroupId:document.getElementById('sortListGroupId').value,
    order:listeDesElementsTries,
   };
   ajaxCall({
    data  : data,
    url   : 'setSortPagesOfGroup1',
    retu  : afterSetSortPagesOfGroup2
   });
  break;
 }
}
//=====================================================================================================================
function afterSetSortPagesOfGroup2(dataJson,objSend){
 console.log(dataJson,objSend);
 if(dataJson.status && dataJson.status=='OK'){
  document.location=String(document.location);
 }
}

//=====================================================================================================================
function doLocalPage(par){
// console.log('doLocalPage',par);
 for( var i=0;i<par.length;i++){
  switch(par[i].jsName){
   case 'onSortPagesOfGroups1':
    var list=document.getElementById(par[i].data.id);   
    Sortable.create(list,{onSort:function(e){onSortPagesOfGroups1();}}); // That's all.
    break;
   default:
    console.log(par[i].jsType + ' not treated' )
    break;
  }
  
 }
}
//=====================================================================================================================
window.onload=function(){ 
 fixMenu1();
 var lstb1=document.getElementsByTagName('body')[0].getElementsByTagName('button');
 for(var i=0;i<lstb1.length;i++){
  if(!(lstb1[i].onclick)){
   if(lstb1[i].className && lstb1[i].className.indexOf('noHide')>=0){
   }else{
    lstb1[i].addEventListener("click",clickButton1,false);
   }
  }
 }
 var lsta1=document.getElementsByTagName('body')[0].getElementsByTagName('a');
 for(var i=0;i<lsta1.length;i++){
  if(lsta1[i].href && !(lsta1[i].href.indexOf('javascript')>=0)){
   if(lsta1[i].className && lsta1[i].className.indexOf('noHide')>=0){
   }else{
    lsta1[i].addEventListener("click",clickLink1,false);
   }
  }
 }
 pageFunction();
}
//====================================================================================================================
// sortable, thanks you https://rubaxa.github.io/Sortable/ :-)
!function(t){"use strict";"function"==typeof define&&define.amd?define(t):"undefined"!=typeof module&&void 0!==module.exports?module.exports=t():window.Sortable=t()}(function(){"use strict";if("undefined"==typeof window||!window.document)return function(){throw new Error("Sortable.js requires a window with a document")};var t,e,n,o,i,r,a,l,s,c,d,h,u,f,p,g,v,m,_,b,D,y={},w=/\s+/g,T=/left|right|inline/,S="Sortable"+(new Date).getTime(),C=window,E=C.document,x=C.parseInt,k=C.setTimeout,N=C.jQuery||C.Zepto,B=C.Polymer,P=!1,Y="draggable"in E.createElement("div"),X=!navigator.userAgent.match(/(?:Trident.*rv[ :]?11\.|msie)/i)&&((D=E.createElement("x")).style.cssText="pointer-events:auto","auto"===D.style.pointerEvents),O=!1,I=Math.abs,M=Math.min,A=[],R=[],L=function(){return!1},F=ot(function(t,e,n){if(n&&e.scroll){var o,i,r,a,d,h,u=n[S],f=e.scrollSensitivity,p=e.scrollSpeed,g=t.clientX,v=t.clientY,m=window.innerWidth,b=window.innerHeight;if(s!==n&&(l=e.scroll,s=n,c=e.scrollFn,!0===l)){l=n;do{if(l.offsetWidth<l.scrollWidth||l.offsetHeight<l.scrollHeight)break}while(l=l.parentNode)}l&&(o=l,i=l.getBoundingClientRect(),r=(I(i.right-g)<=f)-(I(i.left-g)<=f),a=(I(i.bottom-v)<=f)-(I(i.top-v)<=f)),r||a||(a=(b-v<=f)-(v<=f),((r=(m-g<=f)-(g<=f))||a)&&(o=C)),y.vx===r&&y.vy===a&&y.el===o||(y.el=o,y.vx=r,y.vy=a,clearInterval(y.pid),o&&(y.pid=setInterval(function(){h=a?a*p:0,d=r?r*p:0,"function"==typeof c&&"continue"!==c.call(u,d,h,t,_,o)||(o===C?C.scrollTo(C.pageXOffset+d,C.pageYOffset+h):(o.scrollTop+=h,o.scrollLeft+=d))},24)))}},30),H=function(t){function e(t,e){return null!=t&&!0!==t||null!=(t=n.name)?"function"==typeof t?t:function(n,o){var i=o.options.group.name;return e?t:t&&(t.join?t.indexOf(i)>-1:i==t)}:L}var n={},o=t.group;o&&"object"==typeof o||(o={name:o}),n.name=o.name,n.checkPull=e(o.pull,!0),n.checkPut=e(o.put),n.revertClone=o.revertClone,t.group=n};try{window.addEventListener("test",null,Object.defineProperty({},"passive",{get:function(){P={capture:!1,passive:!1}}}))}catch(t){}function W(t,e){if(!t||!t.nodeType||1!==t.nodeType)throw"Sortable: `el` must be HTMLElement, and not "+{}.toString.call(t);this.el=t,this.options=e=it({},e),t[S]=this;var n={group:null,sort:!0,disabled:!1,store:null,handle:null,scroll:!0,scrollSensitivity:30,scrollSpeed:10,draggable:/[uo]l/i.test(t.nodeName)?"li":">*",ghostClass:"sortable-ghost",chosenClass:"sortable-chosen",dragClass:"sortable-drag",ignore:"a, img",filter:null,preventOnFilter:!0,animation:0,setData:function(t,e){t.setData("Text",e.textContent)},dropBubble:!1,dragoverBubble:!1,dataIdAttr:"data-id",delay:0,forceFallback:!1,fallbackClass:"sortable-fallback",fallbackOnBody:!1,fallbackTolerance:0,fallbackOffset:{x:0,y:0},supportPointer:!1!==W.supportPointer};for(var o in n)!(o in e)&&(e[o]=n[o]);H(e);for(var i in this)"_"===i.charAt(0)&&"function"==typeof this[i]&&(this[i]=this[i].bind(this));this.nativeDraggable=!e.forceFallback&&Y,V(t,"mousedown",this._onTapStart),V(t,"touchstart",this._onTapStart),e.supportPointer&&V(t,"pointerdown",this._onTapStart),this.nativeDraggable&&(V(t,"dragover",this),V(t,"dragenter",this)),R.push(this._onDragOver),e.store&&this.sort(e.store.get(this))}function j(e,n){"clone"!==e.lastPullMode&&(n=!0),o&&o.state!==n&&(G(o,"display",n?"none":""),n||o.state&&(e.options.group.revertClone?(i.insertBefore(o,r),e._animate(t,o)):i.insertBefore(o,t)),o.state=n)}function U(t,e,n){if(t){n=n||E;do{if(">*"===e&&t.parentNode===n||nt(t,e))return t}while(void 0,t=(i=(o=t).host)&&i.nodeType?i:o.parentNode)}var o,i;return null}function V(t,e,n){t.addEventListener(e,n,P)}function q(t,e,n){t.removeEventListener(e,n,P)}function z(t,e,n){if(t)if(t.classList)t.classList[n?"add":"remove"](e);else{var o=(" "+t.className+" ").replace(w," ").replace(" "+e+" "," ");t.className=(o+(n?" "+e:"")).replace(w," ")}}function G(t,e,n){var o=t&&t.style;if(o){if(void 0===n)return E.defaultView&&E.defaultView.getComputedStyle?n=E.defaultView.getComputedStyle(t,""):t.currentStyle&&(n=t.currentStyle),void 0===e?n:n[e];e in o||(e="-webkit-"+e),o[e]=n+("string"==typeof n?"":"px")}}function Q(t,e,n){if(t){var o=t.getElementsByTagName(e),i=0,r=o.length;if(n)for(;i<r;i++)n(o[i],i);return o}return[]}function Z(t,e,n,i,r,a,l,s,c){t=t||e[S];var d=E.createEvent("Event"),h=t.options,u="on"+n.charAt(0).toUpperCase()+n.substr(1);d.initEvent(n,!0,!0),d.to=r||e,d.from=a||e,d.item=i||e,d.clone=o,d.oldIndex=l,d.newIndex=s,d.originalEvent=c,e.dispatchEvent(d),h[u]&&h[u].call(t,d)}function J(t,e,n,o,i,r,a,l){var s,c,d=t[S],h=d.options.onMove;return(s=E.createEvent("Event")).initEvent("move",!0,!0),s.to=e,s.from=t,s.dragged=n,s.draggedRect=o,s.related=i||e,s.relatedRect=r||e.getBoundingClientRect(),s.willInsertAfter=l,s.originalEvent=a,t.dispatchEvent(s),h&&(c=h.call(d,s,a)),c}function K(t){t.draggable=!1}function $(){O=!1}function tt(t){for(var e=t.tagName+t.className+t.src+t.href+t.textContent,n=e.length,o=0;n--;)o+=e.charCodeAt(n);return o.toString(36)}function et(t,e){var n=0;if(!t||!t.parentNode)return-1;for(;t&&(t=t.previousElementSibling);)"TEMPLATE"===t.nodeName.toUpperCase()||">*"!==e&&!nt(t,e)||n++;return n}function nt(t,e){if(t){if(t.matches)return t.matches(e);if(t.msMatchesSelector)return t.msMatchesSelector(e)}return!1}function ot(t,e){var n,o;return function(){void 0===n&&(n=arguments,o=this,k(function(){1===n.length?t.call(o,n[0]):t.apply(o,n),n=void 0},e))}}function it(t,e){if(t&&e)for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n]);return t}function rt(t){return B&&B.dom?B.dom(t).cloneNode(!0):N?N(t).clone(!0)[0]:t.cloneNode(!0)}function at(t){return k(t,0)}function lt(t){return clearTimeout(t)}return W.prototype={constructor:W,_onTapStart:function(e){var n,o=this,i=this.el,r=this.options,l=r.preventOnFilter,s=e.type,c=e.touches&&e.touches[0],d=(c||e).target,h=e.target.shadowRoot&&e.path&&e.path[0]||d,u=r.filter;if(function(t){A.length=0;var e=t.getElementsByTagName("input"),n=e.length;for(;n--;){var o=e[n];o.checked&&A.push(o)}}(i),!t&&!(/mousedown|pointerdown/.test(s)&&0!==e.button||r.disabled)&&!h.isContentEditable&&(d=U(d,r.draggable,i))&&a!==d){if(n=et(d,r.draggable),"function"==typeof u){if(u.call(this,e,d,this))return Z(o,h,"filter",d,i,i,n),void(l&&e.preventDefault())}else if(u&&(u=u.split(",").some(function(t){if(t=U(h,t.trim(),i))return Z(o,t,"filter",d,i,i,n),!0})))return void(l&&e.preventDefault());r.handle&&!U(h,r.handle,i)||this._prepareDragStart(e,c,d,n)}},_prepareDragStart:function(n,o,l,s){var c,d=this,h=d.el,u=d.options,p=h.ownerDocument;l&&!t&&l.parentNode===h&&(m=n,i=h,e=(t=l).parentNode,r=t.nextSibling,a=l,g=u.group,f=s,this._lastX=(o||n).clientX,this._lastY=(o||n).clientY,t.style["will-change"]="all",c=function(){d._disableDelayedDrag(),t.draggable=d.nativeDraggable,z(t,u.chosenClass,!0),d._triggerDragStart(n,o),Z(d,i,"choose",t,i,i,f)},u.ignore.split(",").forEach(function(e){Q(t,e.trim(),K)}),V(p,"mouseup",d._onDrop),V(p,"touchend",d._onDrop),V(p,"touchcancel",d._onDrop),V(p,"selectstart",d),u.supportPointer&&V(p,"pointercancel",d._onDrop),u.delay?(V(p,"mouseup",d._disableDelayedDrag),V(p,"touchend",d._disableDelayedDrag),V(p,"touchcancel",d._disableDelayedDrag),V(p,"mousemove",d._disableDelayedDrag),V(p,"touchmove",d._disableDelayedDrag),u.supportPointer&&V(p,"pointermove",d._disableDelayedDrag),d._dragStartTimer=k(c,u.delay)):c())},_disableDelayedDrag:function(){var t=this.el.ownerDocument;clearTimeout(this._dragStartTimer),q(t,"mouseup",this._disableDelayedDrag),q(t,"touchend",this._disableDelayedDrag),q(t,"touchcancel",this._disableDelayedDrag),q(t,"mousemove",this._disableDelayedDrag),q(t,"touchmove",this._disableDelayedDrag),q(t,"pointermove",this._disableDelayedDrag)},_triggerDragStart:function(e,n){(n=n||("touch"==e.pointerType?e:null))?(m={target:t,clientX:n.clientX,clientY:n.clientY},this._onDragStart(m,"touch")):this.nativeDraggable?(V(t,"dragend",this),V(i,"dragstart",this._onDragStart)):this._onDragStart(m,!0);try{E.selection?at(function(){E.selection.empty()}):window.getSelection().removeAllRanges()}catch(t){}},_dragStarted:function(){if(i&&t){var e=this.options;z(t,e.ghostClass,!0),z(t,e.dragClass,!1),W.active=this,Z(this,i,"start",t,i,i,f)}else this._nulling()},_emulateDragOver:function(){if(_){if(this._lastX===_.clientX&&this._lastY===_.clientY)return;this._lastX=_.clientX,this._lastY=_.clientY,X||G(n,"display","none");var t=E.elementFromPoint(_.clientX,_.clientY),e=t,o=R.length;if(t&&t.shadowRoot&&(e=t=t.shadowRoot.elementFromPoint(_.clientX,_.clientY)),e)do{if(e[S]){for(;o--;)R[o]({clientX:_.clientX,clientY:_.clientY,target:t,rootEl:e});break}t=e}while(e=e.parentNode);X||G(n,"display","")}},_onTouchMove:function(t){if(m){var e=this.options,o=e.fallbackTolerance,i=e.fallbackOffset,r=t.touches?t.touches[0]:t,a=r.clientX-m.clientX+i.x,l=r.clientY-m.clientY+i.y,s=t.touches?"translate3d("+a+"px,"+l+"px,0)":"translate("+a+"px,"+l+"px)";if(!W.active){if(o&&M(I(r.clientX-this._lastX),I(r.clientY-this._lastY))<o)return;this._dragStarted()}this._appendGhost(),b=!0,_=r,G(n,"webkitTransform",s),G(n,"mozTransform",s),G(n,"msTransform",s),G(n,"transform",s),t.preventDefault()}},_appendGhost:function(){if(!n){var e,o=t.getBoundingClientRect(),r=G(t),a=this.options;z(n=t.cloneNode(!0),a.ghostClass,!1),z(n,a.fallbackClass,!0),z(n,a.dragClass,!0),G(n,"top",o.top-x(r.marginTop,10)),G(n,"left",o.left-x(r.marginLeft,10)),G(n,"width",o.width),G(n,"height",o.height),G(n,"opacity","0.8"),G(n,"position","fixed"),G(n,"zIndex","100000"),G(n,"pointerEvents","none"),a.fallbackOnBody&&E.body.appendChild(n)||i.appendChild(n),e=n.getBoundingClientRect(),G(n,"width",2*o.width-e.width),G(n,"height",2*o.height-e.height)}},_onDragStart:function(e,n){var r=this,a=e.dataTransfer,l=r.options;r._offUpEvents(),g.checkPull(r,r,t,e)&&((o=rt(t)).draggable=!1,o.style["will-change"]="",G(o,"display","none"),z(o,r.options.chosenClass,!1),r._cloneId=at(function(){i.insertBefore(o,t),Z(r,i,"clone",t)})),z(t,l.dragClass,!0),n?("touch"===n?(V(E,"touchmove",r._onTouchMove),V(E,"touchend",r._onDrop),V(E,"touchcancel",r._onDrop),l.supportPointer&&(V(E,"pointermove",r._onTouchMove),V(E,"pointerup",r._onDrop))):(V(E,"mousemove",r._onTouchMove),V(E,"mouseup",r._onDrop)),r._loopId=setInterval(r._emulateDragOver,50)):(a&&(a.effectAllowed="move",l.setData&&l.setData.call(r,a,t)),V(E,"drop",r),r._dragStartId=at(r._dragStarted))},_onDragOver:function(a){var l,s,c,f,p,m,_=this.el,D=this.options,y=D.group,w=W.active,C=g===y,E=!1,x=D.sort;if((void 0!==a.preventDefault&&(a.preventDefault(),!D.dragoverBubble&&a.stopPropagation()),!t.animated)&&(b=!0,w&&!D.disabled&&(C?x||(f=!i.contains(t)):v===this||(w.lastPullMode=g.checkPull(this,w,t,a))&&y.checkPut(this,w,t,a))&&(void 0===a.rootEl||a.rootEl===this.el))){if(F(a,D,this.el),O)return;if(l=U(a.target,D.draggable,_),s=t.getBoundingClientRect(),v!==this&&(v=this,E=!0),f)return j(w,!0),e=i,void(o||r?i.insertBefore(t,o||r):x||i.appendChild(t));if(0===_.children.length||_.children[0]===n||_===a.target&&(p=a,m=_.lastElementChild.getBoundingClientRect(),p.clientY-(m.top+m.height)>5||p.clientX-(m.left+m.width)>5)){if(0!==_.children.length&&_.children[0]!==n&&_===a.target&&(l=_.lastElementChild),l){if(l.animated)return;c=l.getBoundingClientRect()}j(w,C),!1!==J(i,_,t,s,l,c,a)&&(t.contains(_)||(_.appendChild(t),e=_),this._animate(s,t),l&&this._animate(c,l))}else if(l&&!l.animated&&l!==t&&void 0!==l.parentNode[S]){d!==l&&(d=l,h=G(l),u=G(l.parentNode));var N=(c=l.getBoundingClientRect()).right-c.left,B=c.bottom-c.top,P=T.test(h.cssFloat+h.display)||"flex"==u.display&&0===u["flex-direction"].indexOf("row"),Y=l.offsetWidth>t.offsetWidth,X=l.offsetHeight>t.offsetHeight,I=(P?(a.clientX-c.left)/N:(a.clientY-c.top)/B)>.5,M=l.nextElementSibling,A=!1;if(P){var R=t.offsetTop,L=l.offsetTop;A=R===L?l.previousElementSibling===t&&!Y||I&&Y:l.previousElementSibling===t||t.previousElementSibling===l?(a.clientY-c.top)/B>.5:L>R}else E||(A=M!==t&&!X||I&&X);var H=J(i,_,t,s,l,c,a,A);!1!==H&&(1!==H&&-1!==H||(A=1===H),O=!0,k($,30),j(w,C),t.contains(_)||(A&&!M?_.appendChild(t):l.parentNode.insertBefore(t,A?M:l)),e=t.parentNode,this._animate(s,t),this._animate(c,l))}}},_animate:function(t,e){var n=this.options.animation;if(n){var o=e.getBoundingClientRect();1===t.nodeType&&(t=t.getBoundingClientRect()),G(e,"transition","none"),G(e,"transform","translate3d("+(t.left-o.left)+"px,"+(t.top-o.top)+"px,0)"),e.offsetWidth,G(e,"transition","all "+n+"ms"),G(e,"transform","translate3d(0,0,0)"),clearTimeout(e.animated),e.animated=k(function(){G(e,"transition",""),G(e,"transform",""),e.animated=!1},n)}},_offUpEvents:function(){var t=this.el.ownerDocument;q(E,"touchmove",this._onTouchMove),q(E,"pointermove",this._onTouchMove),q(t,"mouseup",this._onDrop),q(t,"touchend",this._onDrop),q(t,"pointerup",this._onDrop),q(t,"touchcancel",this._onDrop),q(t,"pointercancel",this._onDrop),q(t,"selectstart",this)},_onDrop:function(a){var l=this.el,s=this.options;clearInterval(this._loopId),clearInterval(y.pid),clearTimeout(this._dragStartTimer),lt(this._cloneId),lt(this._dragStartId),q(E,"mouseover",this),q(E,"mousemove",this._onTouchMove),this.nativeDraggable&&(q(E,"drop",this),q(l,"dragstart",this._onDragStart)),this._offUpEvents(),a&&(b&&(a.preventDefault(),!s.dropBubble&&a.stopPropagation()),n&&n.parentNode&&n.parentNode.removeChild(n),i!==e&&"clone"===W.active.lastPullMode||o&&o.parentNode&&o.parentNode.removeChild(o),t&&(this.nativeDraggable&&q(t,"dragend",this),K(t),t.style["will-change"]="",z(t,this.options.ghostClass,!1),z(t,this.options.chosenClass,!1),Z(this,i,"unchoose",t,e,i,f,null,a),i!==e?(p=et(t,s.draggable))>=0&&(Z(null,e,"add",t,e,i,f,p,a),Z(this,i,"remove",t,e,i,f,p,a),Z(null,e,"sort",t,e,i,f,p,a),Z(this,i,"sort",t,e,i,f,p,a)):t.nextSibling!==r&&(p=et(t,s.draggable))>=0&&(Z(this,i,"update",t,e,i,f,p,a),Z(this,i,"sort",t,e,i,f,p,a)),W.active&&(null!=p&&-1!==p||(p=f),Z(this,i,"end",t,e,i,f,p,a),this.save()))),this._nulling()},_nulling:function(){i=t=e=n=r=o=a=l=s=m=_=b=p=d=h=v=g=W.active=null,A.forEach(function(t){t.checked=!0}),A.length=0},handleEvent:function(e){switch(e.type){case"drop":case"dragend":this._onDrop(e);break;case"dragover":case"dragenter":t&&(this._onDragOver(e),function(t){t.dataTransfer&&(t.dataTransfer.dropEffect="move");t.preventDefault()}(e));break;case"mouseover":this._onDrop(e);break;case"selectstart":e.preventDefault()}},toArray:function(){for(var t,e=[],n=this.el.children,o=0,i=n.length,r=this.options;o<i;o++)U(t=n[o],r.draggable,this.el)&&e.push(t.getAttribute(r.dataIdAttr)||tt(t));return e},sort:function(t){var e={},n=this.el;this.toArray().forEach(function(t,o){var i=n.children[o];U(i,this.options.draggable,n)&&(e[t]=i)},this),t.forEach(function(t){e[t]&&(n.removeChild(e[t]),n.appendChild(e[t]))})},save:function(){var t=this.options.store;t&&t.set(this)},closest:function(t,e){return U(t,e||this.options.draggable,this.el)},option:function(t,e){var n=this.options;if(void 0===e)return n[t];n[t]=e,"group"===t&&H(n)},destroy:function(){var t=this.el;t[S]=null,q(t,"mousedown",this._onTapStart),q(t,"touchstart",this._onTapStart),q(t,"pointerdown",this._onTapStart),this.nativeDraggable&&(q(t,"dragover",this),q(t,"dragenter",this)),Array.prototype.forEach.call(t.querySelectorAll("[draggable]"),function(t){t.removeAttribute("draggable")}),R.splice(R.indexOf(this._onDragOver),1),this._onDrop(),this.el=t=null}},V(E,"touchmove",function(t){W.active&&t.preventDefault()}),W.utils={on:V,off:q,css:G,find:Q,is:function(t,e){return!!U(t,e,t)},extend:it,throttle:ot,closest:U,toggleClass:z,clone:rt,index:et,nextTick:at,cancelNextTick:lt},W.create=function(t,e){return new W(t,e)},W.version="1.7.0",W});
//=====================================================================================================================
