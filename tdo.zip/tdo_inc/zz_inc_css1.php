<?php
//================================================================================================================================
function getTdo_css1($id){
 $n=array();
 $n['fld_id_css']         =0;
 $n['fld_name_css']       ='';
 $n['fld_active_css']     =0;
 $n['fld_color_back_css'] ='';
 $n['fld_color_text_css'] ='';
 $n['fld_json_css']       ='';
 $n['fld_tsupd_css']      ='1000-01-01 00:00:00';
 $n['fld_tscrt_css']      ='1000-01-01 00:00:00';
 $n['fld_cntupd_css']     =0;
 $sql='
  SELECT 
   T0.`fld_id_css`         ,T0.`fld_name_css`       ,T0.`fld_active_css`     ,T0.`fld_color_back_css` ,T0.`fld_color_text_css` ,
   T0.`fld_json_css`       ,T0.`fld_tsupd_css`      ,T0.`fld_tscrt_css`      ,T0.`fld_cntupd_css`     
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__css` T0
  WHERE T0.`fld_id_css` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['fld_id_css']         = $row[0];
   $n['fld_name_css']       = $row[1];
   $n['fld_active_css']     = $row[2];
   $n['fld_color_back_css'] = $row[3];
   $n['fld_color_text_css'] = $row[4];
   $n['fld_json_css']       = $row[5];
   $n['fld_tsupd_css']      = $row[6];
   $n['fld_tscrt_css']      = $row[7];
   $n['fld_cntupd_css']     = $row[8];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
//================================================================================================================================
function updateCssList(){
 $list=array();
 $n=array();
 $sql='
  SELECT 
   T0.`fld_id_css`         ,T0.`fld_name_css`       ,T0.`fld_active_css`     ,T0.`fld_color_back_css` ,T0.`fld_color_text_css` ,
   1                       ,T0.`fld_tsupd_css`      ,T0.`fld_tscrt_css`      ,T0.`fld_cntupd_css`     
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__css` T0
  ORDER BY T0.`fld_id_css` 
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['fld_id_css']         = $row[0];
   $n['fld_name_css']       = $row[1];
   $n['fld_active_css']     = $row[2];
   $n['fld_color_back_css'] = $row[3];
   $n['fld_color_text_css'] = $row[4];
//   $n['fld_json_css']       = $row[5];
   $n['fld_tsupd_css']      = str_replace(' ','-',str_replace(':','_',$row[6]));
   $n['fld_tscrt_css']      = $row[7];
   $n['fld_cntupd_css']     = $row[8];
   $list[$n['fld_id_css']]=$n;
  }
  if($fd=fopen('css/__css.php','w')){
   fwrite($fd,'<'.'?'.'php'.CRLF.'$__css='.var_export($list,true).';');
   fclose($fd);
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 } 
}