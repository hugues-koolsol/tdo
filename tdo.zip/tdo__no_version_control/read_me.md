this directory contains the files that are not under version control like svn or git

__dbaccess.php           file      contains the database configuration

user_data                directory contains user files/directory like images or documents uploaded by the user

pages_of_groups          directory contains the files pages_of_group_n.php where n is the id of the group of users

translation_for_pages    directory contains the translated strings for each page

parameters               directory contains the parameters values like languages, yes/no , days labels, log flags, list of countries ... 
                                   that the user or the super user can update