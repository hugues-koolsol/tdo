<?php
// group  : 
$GLOBALS['glob_treegrp']='1,2,3,4';