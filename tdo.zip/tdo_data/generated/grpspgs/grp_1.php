<?php
$GLOBALS['glob_grpspgs']=array (
  'zz_zztests_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
    'id' => '24',
  ),
  'zz_paramvalues1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
    'id' => '19',
  ),
  'ajax_translateJs1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '32',
  ),
  'ajax_addTranslationJs1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '31',
  ),
  'ajax_getPageToTranslate1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '30',
  ),
  'ajax_setSortParamWithoutLang1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '29',
  ),
  'ajax_writeTranslationFiles1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '28',
  ),
  'ajax_setSortParamWithLang1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '27',
  ),
  'ajax_setSortPagesOfGroup1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '26',
  ),
  'ajax_translatePage2.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '25',
  ),
  'ajax_translateMenu1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '35',
  ),
  'ajax_translateMenu2.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '36',
  ),
  'zz_tablelinks_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
    'id' => '22',
  ),
  'ajax_translateText1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '37',
  ),
  'zz_paramkeys_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
    'id' => '18',
  ),
  'ajax_updTranslateSys1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '34',
  ),
  'ajax_updateParam1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '40',
  ),
  'todos_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
    'id' => '14',
  ),
  'zz_zztests_choose1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
    'id' => '42',
  ),
  'zz_pages.php' => 
  array (
    'm' => '1',
    'o' => '0',
    'aj' => '0',
    'id' => '9',
  ),
  'zz_users_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
    'id' => '8',
  ),
  'zz_pages_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
    'id' => '7',
  ),
  'zz_groups_choose1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
    'id' => '6',
  ),
  'zz_groups_action1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '0',
    'id' => '5',
  ),
  'ajax_addTranslateSys1.php' => 
  array (
    'm' => '0',
    'o' => '0',
    'aj' => '1',
    'id' => '33',
  ),
  'todos1.php' => 
  array (
    'm' => '1',
    'o' => '1',
    'aj' => '0',
    'id' => '13',
  ),
  'zz_tables1.php' => 
  array (
    'm' => '1',
    'o' => '2',
    'aj' => '0',
    'id' => '47',
  ),
  'zz_tablelinks1.php' => 
  array (
    'm' => '1',
    'o' => '3',
    'aj' => '0',
    'id' => '20',
  ),
  'zz_groups1.php' => 
  array (
    'm' => '1',
    'o' => '4',
    'aj' => '0',
    'id' => '4',
  ),
  'zz_grpspgs.php' => 
  array (
    'm' => '1',
    'o' => '5',
    'aj' => '0',
    'id' => '10',
  ),
  'zz_paramkeys.php' => 
  array (
    'm' => '1',
    'o' => '6',
    'aj' => '0',
    'id' => '17',
  ),
  'zz_paramrules1.php' => 
  array (
    'm' => '1',
    'o' => '7',
    'aj' => '0',
    'id' => '68',
  ),
  'zz_generateSources1.php' => 
  array (
    'm' => '1',
    'o' => '8',
    'aj' => '0',
    'id' => '21',
  ),
  'zz_users.php' => 
  array (
    'm' => '1',
    'o' => '9',
    'aj' => '0',
    'id' => '12',
  ),
  'zz_translate.php' => 
  array (
    'm' => '1',
    'o' => '10',
    'aj' => '0',
    'id' => '16',
  ),
  'zz_css1.php' => 
  array (
    'm' => '1',
    'o' => '11',
    'aj' => '0',
    'id' => '49',
  ),
  'zz_synchro1.php' => 
  array (
    'm' => '1',
    'o' => '12',
    'aj' => '0',
    'id' => '43',
  ),
  'profile.php' => 
  array (
    'm' => '1',
    'o' => '13',
    'aj' => '0',
    'id' => '41',
  ),
  'uploadeddocs1.php' => 
  array (
    'm' => '1',
    'o' => '14',
    'aj' => '0',
    'id' => '65',
  ),
  'zz_zztests1.php' => 
  array (
    'm' => '1',
    'o' => '15',
    'aj' => '0',
    'id' => '23',
  ),
  'login.php' => 
  array (
    'm' => '1',
    'o' => '16',
    'aj' => '0',
    'id' => '2',
  ),
  'logout.php' => 
  array (
    'm' => '1',
    'o' => '17',
    'aj' => '0',
    'id' => '3',
  ),
  'index.php' => 
  array (
    'm' => '1',
    'o' => '18',
    'aj' => '0',
    'id' => '1',
  ),
);