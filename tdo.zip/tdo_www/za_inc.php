<?php
//PLEASE, keep this comment with the EURO sign, this source MUST be in utf-8 ---- € déjà
usleep(25000);// 0.25 seconds of wait because the browser may be too slow for redirect
define('CRLF',"\r\n");
define('PGMK' , 'tdo'); // program key = app key
define('APP_SHORT_NAME' , PGMK); // put here the short name of the app, it is used in the <title>, default is PGMK but you should change it
define('NAV' , 'NAV');
define('SESSION_MAX_TIME',3600*10);
define('SECRET_KEY_FOR_MAINTENANCE','1234567890');
date_default_timezone_set('Europe/Paris'); // todo put here your default timezone


$GLOBALS['vrsi']                       ='20171122-1917'; // version, please, keep this declaration in first column
$GLOBALS['__table_prefix']             =PGMK.'_'; // important because there is a scan of tables in superuser mode
$GLOBALS['glob_incPath1']              = '..'.DIRECTORY_SEPARATOR.PGMK.'_inc';
$GLOBALS['glob_noVcDirName']           =PGMK.'__no_version_control';
$GLOBALS['glob_userDirName']           ='_user_data';
$GLOBALS['glob_noVcPath1']             = '..'.DIRECTORY_SEPARATOR.$GLOBALS['glob_noVcDirName'];
$GLOBALS['glob_userPath1']             = $GLOBALS['glob_noVcPath1'].DIRECTORY_SEPARATOR.$GLOBALS['glob_userDirName'];
$GLOBALS['glob_maintenance']           =false;
$GLOBALS['glob_translate']             = isset($_COOKIE['translate']) && $_COOKIE['translate']=='1'?true:false;
$GLOBALS['glob_translateTable']        = array();
$GLOBALS['glob_log_in_page_name']      = 'login.php';
@include( $GLOBALS['glob_incPath1'].DIRECTORY_SEPARATOR.'__maintenance.php');
if(!(isset($GLOBALS['cron_backup']) && $GLOBALS['cron_backup'] == true )){
 if($GLOBALS['glob_maintenance']==true){
  if(BNF!='logout.php' && BNF!=$GLOBALS['glob_log_in_page_name']){
   header("HTTP/1.1 303 See Other");header('Location: logout.php');
   exit();
  }
 }
}
require_once($GLOBALS['glob_incPath1'].''.DIRECTORY_SEPARATOR.'__lang1.php');
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['__sys1'] , true ) . '</pre>' ; exit(0);
//it looks like : $GLOBALS['glob__availableLanguages'] = array('fr' => array( 'n' => 'Français' ) , 'en' => array( 'n' => 'English' ) );
$GLOBALS['glob_defaultLanguage']    = 'fr';
$GLOBALS['glob_lv']=array();
$GLOBALS['glob_setdate']=date('Y-m-d H:i:s');
$GLOBALS['glob_isLocalHost']=false;
if(isset($_SERVER['HTTP_HOST']) && strpos($_SERVER['HTTP_HOST'],'localhost')!==false){
 $GLOBALS['glob_isLocalHost']=true;
}

if(!(isset($GLOBALS['cron_backup']) && $GLOBALS['cron_backup'] == true )){
 if(!defined('BNF')) {
  define('BNF',basename( __FILE__ ));
  define('PAGE_ID',0);
 }else{
  require_once $GLOBALS['glob_incPath1'].''.DIRECTORY_SEPARATOR.'__pageList.php';
  if(!isset($GLOBALS['__pageList'][BNF])){
   header("HTTP/1.1 303 See Other");header('Location: index.php?message='.urlencode('Technical error : "' . BNF . '" is not in the page list'));
   exit();
  }
  define('PAGE_ID',$GLOBALS['__pageList'][BNF]['fld_id_pages']);
 }
}
if(isset($_GET['lang'])){
 if( isset( $GLOBALS['glob__availableLanguages'][$_GET['lang']] ) ){
  setcookie( PGMK.'lang' , $_GET['lang'] , time()+3600*24*365, '/' );
  $GLOBALS['glob_lang']=$_GET['lang'];
 }else{
  if( isset( $GLOBALS['glob__availableLanguages'][$GLOBALS['glob_defaultLanguage']] ) ){
   setcookie( PGMK.'lang' , $GLOBALS['glob_defaultLanguage'] , time()+3600*24*365, '/'  );
   $GLOBALS['glob_lang']=$GLOBALS['glob_defaultLanguage'];
  }else{
   reset($GLOBALS['glob__availableLanguages']);
   $GLOBALS['glob_lang']= key($GLOBALS['glob__availableLanguages']);
   setcookie( PGMK.'lang' , $GLOBALS['glob_lang'] , time()+3600*24*365, '/'  );
  }
 }
}else{
 if(isset($_COOKIE[PGMK.'lang'])){
   if( isset( $GLOBALS['glob__availableLanguages'][$_COOKIE[PGMK.'lang']] ) ){
    $GLOBALS['glob_lang']=$_COOKIE[PGMK.'lang'];
    setcookie( PGMK.'lang' , $GLOBALS['glob_lang'] , time()+3600*24*365, '/'  );
   }else{
    if( isset( $GLOBALS['glob__availableLanguages'][$GLOBALS['glob_defaultLanguage']] ) ){
     setcookie( PGMK.'lang' , $GLOBALS['glob_defaultLanguage'] , time()+3600*24*365, '/'  );
     $GLOBALS['glob_lang']=$GLOBALS['glob_defaultLanguage'];
    }else{
     reset($GLOBALS['glob__availableLanguages']);
     $GLOBALS['glob_lang']= key($GLOBALS['glob__availableLanguages']);
     setcookie( PGMK.'lang' , $GLOBALS['glob_lang'] , time()+3600*24*365, '/'  );
    }
   }
 }else{
  if( isset( $GLOBALS['glob__availableLanguages'][$GLOBALS['glob_defaultLanguage']] ) ){
   setcookie(PGMK.'lang',$GLOBALS['glob_defaultLanguage'] , time()+3600*24*365, '/' );
   $GLOBALS['glob_lang']=$GLOBALS['glob_defaultLanguage'];
  }else{
   reset($GLOBALS['glob__availableLanguages']);
   $GLOBALS['glob_lang']= key($GLOBALS['glob__availableLanguages']);
   setcookie( PGMK.'lang' , $GLOBALS['glob_lang'] , time()+3600*24*365, '/'  );
  }
 }
}
//echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $GLOBALS['glob_lang'] , true ) . '</pre>' ; exit(0);

$GLOBALS['glob_maintenanceEnCours']=false; // false : NE PAS MODIFIER ICI, VOIR UN PEU PLUS BAS
if(isset($GLOBALS['cron_backup']) && $GLOBALS['cron_backup'] == true ){
 error_reporting(E_ALL);
 $GLOBALS['glob_debug']=true;
}else{
 if(strpos($_SERVER['HTTP_HOST'],'localhost')!==false){
  error_reporting(E_ALL);
  $GLOBALS['glob_debug']=true;
 }else{
  error_reporting(0);
  $GLOBALS['glob_debug']=false;
 }
}

if(isset($_GET['hdftest'])){
 if($_GET['hdftest']=='1'){
  setcookie(PGMK.'TestCookie' , 1 , time() + 14400); // 4 heures
 }else if($_GET['hdftest']=='0'){
  setcookie(PGMK.'TestCookie' , 0 , time() + 14400); // 4 heures
 }
}
$GLOBALS['isSuperUser']=false; 
if(isset($_SESSION[PGMK]['login']) && $_SESSION[PGMK]['login']==1){
 $GLOBALS['isSuperUser']=true;
}

// database config
require_once( $GLOBALS['glob_noVcPath1'] . '/__dbaccess.php' );
/*
// ko on php >= 7.3
if(get_magic_quotes_gpc()==1){
 $_GET    =hmq1($_GET);
 $_POST   =hmq1($_POST);
 $_COOKIE =hmq1($_COOKIE);
 $_REQUEST=hmq1($_REQUEST);
}
//========================================================================================================================
function hmq1($value){
 if(is_array($value)){
  $result=array();
  foreach($value as $k=>$v){
   if(is_array($v)){
    $result[$k]=hmq1($v);
   }else{
    $result[$k]=stripslashes($v);
   }
  }
  return $result;
 }else{
  return stripslashes($value);
 }
}
*/
//========================================================================================================================
function openDb1(){
 foreach($GLOBALS['glob_db'] as $k1=>$v1){
  if(null===$GLOBALS['glob_db'][$k1]['link']){
   $link = mysqli_connect($v1['server'],$v1['user'],$v1['password'],$v1['dbname']);
   if(!$link){
    error_log(__FILE__ . ' ' . __LINE__ . ' no db connect ('.$v1['server'].','/$v1['user'].')');
    die(__FILE__ . ' ' . __LINE__ . ' no db connect');
   }else{
    $GLOBALS['glob_db'][$k1]['link']=$link;
    // https://stackoverflow.com/questions/5741187/sql-injection-that-gets-around-mysql-real-escape-string
    if($GLOBALS['glob_db'][$k1]['setname']!=''){
     mysqli_set_charset( $link , $GLOBALS['glob_db'][$k1]['setname'] ); // utf8mb4 is good DO THIS, IMPORTANT BECAUSE OF THE STACKOVERFLOW POST UPPER
    }
    // put ' ( single quotes ) around text fields search
    // utf8mb4 exists since MySQL 5.5.3 (released in early 2010)
    // see https://mathiasbynens.be/notes/mysql-utf8mb4
    
   }
  }
 }
}
//========================================================================================================================
function debugSql1($par){
 $o1='';
 if(isset($par['sqler'])) $o1.='<p>'.$par['sqler'].'</p>';
 if(isset($par['reque'])) $o1.='<p>'.$par['reque'].'</p>';
 return $o1;
}
//========================================================================================================================
function debugSql2($par){
 $o1='';
 if(isset($par['line'])) $o1.=$par['line'].' ';
 if(isset($par['file'])) $o1.=$par['file'].' ';
 if(isset($par['sqler'])) $o1.='<p>'.$par['sqler'].'</p>';
 if(isset($par['reque'])) $o1.='<p>'.$par['reque'].'</p>';
 if(isset($par['message'])) $o1.='<p>'.$par['message'].'</p>';
 echo $o1;
 exit();
}
//========================================================================================================================
function testLogin1($par){
 if(session_status()==PHP_SESSION_NONE){
  session_start();
 }
 if(!isLogged()){
  header("HTTP/1.1 303 See Other");header('Location: login.php?redir='.rawurlencode($_SERVER['REQUEST_URI']).'');
  exit();
 }
 $founded=0;
 foreach( $GLOBALS['glob_groups'][$_SESSION[PGMK]['group']]['menus'] as $k1 => $v1){
  $curr=parse_url($v1['page']);
  $curr=$curr['path'];
  if(basename($par['page'])==$curr) $founded=1; // $v1['page']
 }
 if($founded==0){
  header("HTTP/1.1 303 See Other");header('Location: index.php');
  exit();
 }
}
//========================================================================================================================
function cleanSession1(){
 if(isset($_GET['men'])&&$_GET['men']=='1'){
  xcleanSession1( array( 'except' => '' ) );
 }else{
  xcleanSession1( array( 'except' => BNF ) );
 }
}
//========================================================================================================================
function xcleanSession1($par){
 if(isset($_SESSION[PGMK][NAV])){
  foreach($_SESSION[PGMK][NAV] as $k=>$v){
   if($par['except']!=$k){
    unset($_SESSION[PGMK][NAV][$k]);
   }
  }
 }
 if(isset($_SESSION[PGMK]['choose'])) unset($_SESSION[PGMK]['choose']);
}
//========================================================================================================================
function saveSessionSearch1( $k , $bnf){
 $ret='';
 $ret = isset($_GET[$k])?$_GET[$k]:'';
 if(isset($_GET[$k])){
  $_SESSION[PGMK][NAV][$bnf][$k]=$_GET[$k];
  $ret=$_GET[$k];
 }else{
  if(isset($_SESSION[PGMK][NAV][$bnf][$k])){
   $ret=$_SESSION[PGMK][NAV][$bnf][$k];
  }else{
   $ret='';
  }
 }
 return($ret);
}
//========================================================================================================================
function replaceJs($s){
 $s=str_replace('\'','\\\'',$s);
 $s=str_replace("\r",'\\\r',$s);
 $s=str_replace("\n",'\\\n',$s);
 return $s;
}
//========================================================================================================================
function displaySessionMessage1($f){
 $theMessages='';
// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_SESSION[PGMK][NAV] , true ) . '</pre>' ; exit(0);
 if(isset($_SESSION[PGMK][NAV][$f]['message'])){
  if(sizeof($_SESSION[PGMK][NAV][$f]['message'])>0){
   foreach($_SESSION[PGMK][NAV][$f]['message'] as $kerr => $verr ){
    $theMessages.='<div class="yymessageBox yysuccess">' . $verr . '</div>'.CRLF;
   }
  }
  unset($_SESSION[PGMK][NAV][$f]['message']);
 }
 if(isset($_SESSION[PGMK][NAV]['message'])){
  if(sizeof($_SESSION[PGMK][NAV]['message'])>0){
   foreach($_SESSION[PGMK][NAV]['message'] as $kerr => $verr ){
    $theMessages.='<div class="yymessageBox yysuccess">' . $verr . '</div>'.CRLF;
   }
  }
  unset($_SESSION[PGMK][NAV]['message']);
 }

 if(isset($_SESSION[PGMK][NAV][$f]['errormessage'])){
  if(sizeof($_SESSION[PGMK][NAV][$f]['errormessage'])>0){
   foreach($_SESSION[PGMK][NAV][$f]['errormessage'] as $kerr => $verr ){
    $theMessages.='<div class="yymessageBox yyerror">' . $verr . '</div>'.CRLF;
   }
  }
  unset($_SESSION[PGMK][NAV][$f]['errormessage']);
 }
 if(isset($_SESSION[PGMK][NAV]['errormessage'])){
  if(sizeof($_SESSION[PGMK][NAV]['errormessage'])>0){
   foreach($_SESSION[PGMK][NAV]['errormessage'] as $kerr => $verr ){
    $theMessages.='<div class="yymessageBox yyerror">' . $verr . '</div>'.CRLF;
   }
  }
  unset($_SESSION[PGMK][NAV]['errormessage']);
 }

 if(isset($_SESSION[PGMK][NAV][$f]['warningmessage'])){
  if(sizeof($_SESSION[PGMK][NAV][$f]['warningmessage'])>0){
   foreach($_SESSION[PGMK][NAV][$f]['warningmessage'] as $kerr => $verr ){
    $theMessages.='<div class="yymessageBox yywarning">' . $verr . '</div>'.CRLF;
   }
  }
  unset($_SESSION[PGMK][NAV][$f]['warningmessage']);
 }
 if(isset($_SESSION[PGMK][NAV]['warningmessage'])){
  if(sizeof($_SESSION[PGMK][NAV]['warningmessage'])>0){
   foreach($_SESSION[PGMK][NAV]['warningmessage'] as $kerr => $verr ){
    $theMessages.='<div class="yymessageBox yywarning">' . $verr . '</div>'.CRLF;
   }
  }
  unset($_SESSION[PGMK][NAV]['warningmessage']);
 }
 return $theMessages;
}
//========================================================================================================================
function isLogged(){
 if($GLOBALS['glob_maintenanceEnCours']==true){
  unset($_SESSION[PGMK]);
  header("HTTP/1.1 303 See Other");header('Location: login.php');
  exit();
 }
 if(isset($_COOKIE[PGMK.'TestCookie'])&&$_COOKIE[PGMK.'TestCookie']=='1'){
 }else{
  @include_once($GLOBALS['glob_noVcPath1'].'/serveurActif.php');
  if(isset($GLOBALS['serveurActif'])&&$GLOBALS['serveurActif']==false){
   unset($_SESSION[PGMK]);
   header("HTTP/1.1 303 See Other");header('Location: xp_aa_login.php');
   exit();
  }
 }
 if(isset($_SESSION[PGMK]['login'])&&isset($_SESSION[PGMK]['group'])){
  if(isset($_SESSION[PGMK]['SESSION_LAST_ACTIVITY'])&&(time()-$_SESSION[PGMK]['SESSION_LAST_ACTIVITY']>SESSION_MAX_TIME)){
   unset($_SESSION[PGMK]);
   session_unset();     // unset $_SESSION variable for the run-time
   session_destroy();   // destroy session data in storage
   return false;
  }
  $_SESSION[PGMK]['SESSION_LAST_ACTIVITY']=time(); // update last activity time stamp
  if(!isset($_SESSION[PGMK]['SESSION_CREATED'])) {
   $_SESSION[PGMK]['SESSION_CREATED'] = time();
  }else if(time() - $_SESSION[PGMK]['SESSION_CREATED']>SESSION_MAX_TIME) {
   session_regenerate_id(true);    // change session ID for the current session an invalidate old session ID
   $_SESSION[PGMK]['SESSION_CREATED']=time();  // update creation time
  }
  return true;
 }
 return false;
}
//========================================================================================================================
function enti1($s){
 return htmlentities( $s , ENT_COMPAT , 'utf-8' ) ;
}
//========================================================================================================================
function microtime_float(){
 list($usec, $sec) = explode(" ", microtime());
 return ((float)$usec + (float)$sec);
}
//========================================================================================================================
function dw1($s){ // echo is for debugging purpose only use dw1
 echo $s;
}
//========================================================================================================================
//========================================================================================================================
function checkGroupPages(){
 if(!isset($_SESSION[PGMK]['groupInit']) || !isset($_SESSION[PGMK]['group'])){
  $_SESSION[PGMK]['groupInit']=2; // anonymous
  $_SESSION[PGMK]['group']=2; // anonymous
 } 
 require_once($GLOBALS['glob_noVcPath1'].'/pages_of_groups/pages_of_group_'.$_SESSION[PGMK]['group'].'.php');
 if($_SESSION[PGMK]['groupInit']==1){ // root can do all
  return;
 }
 if(BNF==$GLOBALS['glob_log_in_page_name']){
  return;
 }
 if(BNF!='profile.php' && isset($_SESSION[PGMK]['changepassword']) && $_SESSION[PGMK]['groupInit']==$_SESSION[PGMK]['group'] && $_SESSION[PGMK]['changepassword']==1){
  $_SESSION[PGMK][NAV]['errormessage']='changepassword';
  header("HTTP/1.1 303 See Other");header('Location: profile.php');
  exit(0);
 }
 if(isset($GLOBALS['glob_grpspgs'][BNF])){
  return;
 }
 // session is closed and can redirect
 if(!isset($_SESSION[PGMK]['login']) && $_SERVER['QUERY_STRING']!='' && $_SERVER['SCRIPT_NAME']!=''){
  header("HTTP/1.1 303 See Other");header('Location: login.php?redir='.$_SERVER['SCRIPT_NAME'].'?'.urlencode($_SERVER['QUERY_STRING']));
  exit(0);
 }
 // session is closed and cannnot redirest
 if(!isset($_SESSION[PGMK]['login'])){
  header("HTTP/1.1 303 See Other");header('Location: index.php');
  exit(0);
 }
 header("HTTP/1.1 303 See Other");header('Location: index.php?message=g000001&f='.urlencode(BNF));
 exit();
}

//========================================================================================================================
function updateInsertYorno1($par){
 $o1='';
 $count=0;

 $fieldList=array();
 $js1=array();
// echo __FILE__ . ' ' . __LINE__ . ' $GLOBALS[$par[globalTab]] =<pre>' . var_export( $GLOBALS[$par['globalTab']] , true ) . '</pre>' ; exit();
 $tab=array( '0' => 'Non' , '1' => 'Oui' );
 foreach( $tab as $k1 => $v1){

  $checked='';
  if(isset($par['values'])){
   if( $par['values'][$par['field']]==$k1 ){
    $checked =' checked="checked" ';
   }
  }else if(isset($par['value'])){
   if( $par['value']==$k1 ){
    $checked =' checked="checked" ';
   }
  }

  $o1.='<label class="radio" id="label_'.$par['field'].'_'.$count.'" for="'.$par['field'].'_'.$count.'" >'.$v1.' : </label>'.CRLF;
  $o1.='<input type="radio" name="'.$par['field'].'" id="'.$par['field'].'_'.$count.'" value="'.$k1.'"   '.$checked.' />'.CRLF;
  $fieldList[]=array(
   'group'      => $par['field'] ,
   'label'      => 'label_'.$par['field'].'_'.$count,
   'field'      => ''.$par['field'].'_'.$count,
   'statusInit' => $checked
  );
  $count++;
 }
 $js1=array(
  'jstype' => isset($par['js'])?$par['js']:'setcolorYorn1' ,
  'components' => array(
   'fields'    => $fieldList        ,
   'debug'     => $GLOBALS['glob_debug'] ,
  )
 );
 return array( 'html' => $o1 , 'js' => $js1);
}

//========================================================================================================================
function txtlog1( $txt1 , $bnf1 , $lin1 , $typ){
 $req8='
  INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`'.PGMK.'_tbl__log` SET
  `fld_text_log`=\''.addslashes($txt1).';\',
  `fld_bnf_log`=\''.addslashes($bnf1).'\',
  `fld_typ_log`=\''.addslashes($typ).'\',
  `fld_line_log`='.$lin1.',
  `fld_user_id_log`=' . $_SESSION[PGMK]['loginInit'].',
  `fld_timstp_log`= \''.$GLOBALS['glob_setdate'].'\',
  `fld_group_id_log`=' . $_SESSION[PGMK]['groupInit'].'
 ';
 $res8=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
}
//========================================================================================================================
function sqllog1( $req1 , $bnf1 , $lin1 ){
 $req8='
  INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`'.PGMK.'_tbl__log` SET
  `fld_text_log`=\''.addslashes($req1).'\',
  `fld_bnf_log`=\''.addslashes($bnf1).'\',
  `fld_typ_log`=\'sql\',
  `fld_line_log`='.$lin1.',
  `fld_user_id_log`=' . $_SESSION[PGMK]['loginInit'].',
  `fld_timstp_log` = \''.$GLOBALS['glob_setdate'].'\',
  `fld_group_id_log`=' . $_SESSION[PGMK]['groupInit'].'
 ';
 $res8=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
}
//========================================================================================================================
function SetSessionMessageAndLog1($mes1,$bnf1,$lin1,$typ1){
 $req8='
  INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`'.PGMK.'_tbl__log` SET
  `fld_text_log`=\''.addslashes($mes1).'\'                ,
  `fld_bnf_log`=\''.addslashes($bnf1).'\'                ,
  `fld_line_log`='.$lin1.'                               ,
  `fld_user_id_log`=' . $_SESSION[PGMK]['loginInit'] . ' ,
  `fld_typ_log`='.$typ1.'                                ,
  `fld_timstp_log` = \''.$GLOBALS['glob_setdate'].'\'    ,
  `fld_group_id_log`=' . $_SESSION[PGMK]['groupInit'].'
 ' ;
 $res8=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
 $_SESSION[PGMK][NAV][$bnf1]['message'][]=$mes1;
}
//========================================================================================================================
function buildSetDirectCondition($xsearch,$arr,$field){
 $req6='';

 if(is_array($xsearch)){
  if(in_array('__all_values_of_set__' , $xsearch)){
   foreach($arr as $k2 => $v2){
    $req6.='
     AND FIND_IN_SET( \''.$k2.'\' , '.$field.' )>0
    ';
   }
  }else{
   if(implode(',',$xsearch)!=''){
    $arrcond=array();
    foreach($xsearch as $k1=>$v1){
     if($v1!=''){
      $arrcond[]=$v1;
     }
    }
    if(sizeof($arrcond)>0){
     $strOr='';
     foreach($arrcond as $k2 => $v2){
      $strOr.=' FIND_IN_SET( \''.$v2.'\' , '.$field.' )>0 OR';
     }
     $strOr=substr($strOr,0,-2);
     $req6.='
      AND ( ' . $strOr . ' )
     ';
    }
   }
  }
 }else{
  if(implode(',',$xsearch)!=''){
   $str='';
   foreach($xsearch as $k1=>$v1){
    if($v1!=''){
     $str.='\''.$v1.'\',';
    }
   }
   if($str!=''){
    $str=substr($str,0,-1);
    $req6.='
     AND '.$field.' in ('.$str.')
    ';
   }
  }
 }
 return $req6; 
}
//========================================================================================================================
function buildSetCondition($xsearch,$paramName,$field){
 $req6='';

 if(is_array($xsearch)){
  if(in_array('__all_values_of_set__' , $xsearch)){
   foreach($GLOBALS[$paramName]['__values'][$GLOBALS['glob_lang']] as $k2 => $v2){
    $req6.='
     AND FIND_IN_SET( \''.$k2.'\' , '.$field.' )>0
    ';
   }
  }else{
   if(implode(',',$xsearch)!=''){
    $arrcond=array();
    foreach($xsearch as $k1=>$v1){
     if($v1!=''){
      $arrcond[]=$v1;
     }
    }
    if(sizeof($arrcond)>0){
     $strOr='';
     foreach($arrcond as $k2 => $v2){
      $strOr.=' FIND_IN_SET( \''.$v2.'\' , '.$field.' )>0 OR';
     }
     $strOr=substr($strOr,0,-2);
     $req6.='
      AND ( ' . $strOr . ' )
     ';
    }
   }
  }
 }else{
  if(implode(',',$xsearch)!=''){
   $str='';
   foreach($xsearch as $k1=>$v1){
    if($v1!=''){
     $str.='\''.$v1.'\',';
    }
   }
 //   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $str , true ) . '</pre>' ; exit(0);
   if($str!=''){
    $str=substr($str,0,-1);
    $req6.='
     AND '.$field.' in ('.$str.')
    ';
   }
  }
 }
 return $req6;
}
//========================================================================================================================
function displayParam1($paramName,$paramValue,$options=array()){
 if(is_file($GLOBALS['glob_noVcPath1'].'/parameters/'.$paramName.'.php')){
  require_once $GLOBALS['glob_noVcPath1'].'/parameters/'.$paramName.'.php';
 }else{
  require_once $GLOBALS['glob_incPath1'].'/__param_'.$paramName.'.php';
 }
 if($GLOBALS['param__'.$paramName]['param__Name__Sort']!=''){

  if(isset($options['set']) && $options['set']==true){
   if($paramValue==''){
    return '';
   }else{
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $paramValue , true ) . '</pre>' ; exit(0);
    $arr=explode(',',$paramValue);
    if(is_array($arr)){
     $toReturn='';
     foreach($GLOBALS['param__'.$paramName]['__values'][$GLOBALS['glob_lang']] as $k2 => $v2){
      if(in_array($k2,$arr)){
       if(isset($v2['badge']) && $v2['badge']!=''){
        if(isset($options['adjust1']) && $options['adjust1']==true){
         $toReturn.='<span class="yybadge '.$v2['badge'].'" style="font-size:0.8rem;line-height: 1rem;vertical-align:middle;">'.$v2[$GLOBALS['param__'.$paramName]['param__Name__Display']].'</span> | ';
        }else{
         $toReturn.='<span class="yybadge '.$v2['badge'].'" style="font-size:0.8rem;">'.$v2[$GLOBALS['param__'.$paramName]['param__Name__Display']].'</span> | ';
        }
       }else{
        $toReturn.=''.$v2[$GLOBALS['param__'.$paramName]['param__Name__Display']].' | ';
       }
      }
     }
     if($toReturn!=''){
      return substr($toReturn,0,-3);
     }else{
      return txtsys1('Value_not_founded_in_paramerters') . ' "' . $paramName .'" "' . $paramValue .'"';
     }
    }
   }
  }else{

//   echo __FILE__ . ' ' . __LINE__ . ' paramName="'.$paramName.'" $paramValue="'.$paramValue.'" , __LINE__ = <pre>' . var_export( $GLOBALS['param__'.$paramName]['__values'][$GLOBALS['glob_lang']] , true ) . '</pre>' ; exit(0);

   foreach($GLOBALS['param__'.$paramName]['__values'][$GLOBALS['glob_lang']] as $k1 => $v1){
    if($k1==$paramValue && $paramValue !== ''){
     $toreturn='';
     if(isset($v1['badge']) && $v1['badge']!==''){
      if(isset($options['adjust1']) && $options['adjust1']==true){
       $toreturn='<span class="yybadge '.$v1['badge'].'" style="font-size:0.8rem;line-height: 1rem;vertical-align:middle;">'.$v1[$GLOBALS['param__'.$paramName]['param__Name__Display']].'</span>';
      }else{
       $toreturn='<span class="yybadge '.$v1['badge'].'" style="font-size:0.8rem;">'.$v1[$GLOBALS['param__'.$paramName]['param__Name__Display']].'</span>';
      }
     }else{
      $toreturn=$v1[$GLOBALS['param__'.$paramName]['param__Name__Display']];
     }
     return $toreturn ;
    }
   }
  }
 }
 if(isset($options['unsetPossible']) && $options['unsetPossible'] == true){
  return '';
 }else{
  return txtsys1('Value_not_founded_in_paramerters') . ' paramName="' . $paramName .'" $paramValue="' . $paramValue .'"';
 }
}
//========================================================================================================================
function displaySet1($arr,$currentValue,$fieldName){
 $ret=array(
  'html' => '',
  'js'   => '',
 );
 if($currentValue==''){
  $currentValue=array();
 }else{
  if(is_array($currentValue)){
  }else{
   $currentValue=explode(',',$currentValue);
  }
 }
 $count=0;
 foreach($arr as $k1 => $v1){
  if(in_array( $v1 , $currentValue)){
   $ret['html'].='<label class="form-check-label" id="'.$fieldName.'_label_'.$count.'" for="'.$fieldName.'_'.$count.'" style="cursor:pointer;margin-top:5px;margin-bottom:5px;display:inline-block;font-weight:bold;">';
   $ret['html'].='<input type="checkbox" name="'.$fieldName.'[]" id="'.$fieldName.'_'.$count.'" value="'.htmlentities($v1,ENT_COMPAT).'" checked="checked"  style="" />'.CRLF;
  }else{
   $ret['html'].='<label class="form-check-label" id="'.$fieldName.'_label_'.$count.'" for="'.$fieldName.'_'.$count.'" style="cursor:pointer;margin-top:5px;margin-bottom:5px;display:inline-block;">';
   $ret['html'].='<input type="checkbox" name="'.$fieldName.'[]" id="'.$fieldName.'_'.$count.'" value="'.htmlentities($v1,ENT_COMPAT).'"  style="" />'.CRLF;
  }
  $ret['html'].=''.$v1.'';
  $ret['html'].='</label>'.CRLF;
  $ret['html'].='&nbsp; ';
  $count++;
 }
 return $ret;
}
//========================================================================================================================
function displayParam2($paramName,$currentValue,$fieldName,$options){
 $ret=array(
  'html' => '',
  'js'   => '',
 );
 if(is_file($GLOBALS['glob_noVcPath1'].'/parameters/'.$paramName.'.php')){
  require_once $GLOBALS['glob_noVcPath1'].'/parameters/'.$paramName.'.php';
 }else{
  require_once $GLOBALS['glob_incPath1'].'/__param_'.$paramName.'.php';
 }
 if(isset($GLOBALS['param__'.$paramName])){
  if(isset($options['set']) && $options['set'] == true ){
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $options , true ) . '</pre>' ; exit(0);
   if($currentValue==''){
    $currentValue=array();
   }else{
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $currentValue , true ) . '</pre>' ; exit(0);
    if(is_array($currentValue)){
    }else{
     $currentValue=explode(',',$currentValue);
//     echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $currentValue , true ) . '</pre>' ; exit(0);
    }
   }
   $count=0;
   foreach($GLOBALS['param__'.$paramName]['__values'][$GLOBALS['glob_lang']] as $k1 => $v1){
//    echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $currentValue , true ) . '</pre>' ; exit(0);
    if(in_array( $k1 , $currentValue)){
     $ret['html'].='<label class="form-check-label" id="'.$fieldName.'_label_'.$count.'" for="'.$fieldName.'_'.$count.'" style="cursor:pointer;margin-top:5px;margin-bottom:5px;display:inline-block;font-weight:bold;">';
     $ret['html'].='<input '.(isset($options['readonly'])&&$options['readonly']==true?' onclick="return false;" ':'').' type="checkbox" name="'.$fieldName.'[]" id="'.$fieldName.'_'.$count.'" value="'.$k1.'" checked="checked"  style="" />'.CRLF;
    }else{
     $ret['html'].='<label class="form-check-label" id="'.$fieldName.'_label_'.$count.'" for="'.$fieldName.'_'.$count.'" style="cursor:pointer;margin-top:5px;margin-bottom:5px;display:inline-block;">';
     $ret['html'].='<input '.(isset($options['readonly'])&&$options['readonly']==true?' onclick="return false;" ':'').' type="checkbox" name="'.$fieldName.'[]" id="'.$fieldName.'_'.$count.'" value="'.$k1.'"  style="" />'.CRLF;
    }
    $ret['html'].=''.$v1[$GLOBALS['param__'.$paramName]['param__Name__Display']].'';
    $ret['html'].='</label>'.CRLF;
    $ret['html'].='&nbsp; ';
    $count++;
   }
  }else{
   // onfocus="this.defaultIndex=this.selectedIndex;" onchange="this.selectedIndex=this.defaultIndex;"
   $count=0;
   $isPrechecked=false;
   if(isset($options['dropDown']) && $options['dropDown'] == true ){
//    echo __FILE__ . ' ' . __LINE__ . ' $currentValue = <pre>' . var_export( $currentValue , true ) . '</pre>' ; exit(0);
//    $ret['html'].='<select '.(isset($options['readonly'])&&$options['readonly']==true?' onfocus="this.defaultIndex=this.selectedIndex;" onchange="this.selectedIndex=this.defaultIndex;" ':'').' name="'.$fieldName.'" id="'.$fieldName.'" >';
    $ret['html'].='<select name="'.$fieldName.'" id="'.$fieldName.'" >';
//    echo __FILE__ . ' ' . __LINE__ . ' $options[unsetPossible] = <pre>' . var_export( $options['unsetPossible'] , true ) . '</pre>' ; exit(0);
    if(isset($options['unsetPossible']) && $options['unsetPossible'] == true ){
     if(''==$currentValue){
      $ret['html'].='<option value="" selected="selected">['.txtsys1('undefined').']</option>';
     }else{
      $ret['html'].='<option '.(isset($options['readonly'])&&$options['readonly']==true?' disabled="disabled" ':'').'  value="">['.txtsys1('undefined').']</option>';
     }
    }
    foreach($GLOBALS['param__'.$paramName]['__values'][$GLOBALS['glob_lang']] as $k1 => $v1){
     if($k1==$currentValue){
      $ret['html'].='<option value="'.$k1.'" selected="selected">'.$v1[$GLOBALS['param__'.$paramName]['param__Name__Display']].'</option>';
     }else{
      $ret['html'].='<option '.(isset($options['readonly'])&&$options['readonly']==true?' disabled="disabled" ':'').' value="'.$k1.'" >'.$v1[$GLOBALS['param__'.$paramName]['param__Name__Display']].'</option>';
     }
    }
    $ret['html'].='</select>';
   }else{
    if(isset($options['unsetPossible']) && $options['unsetPossible'] == true ){
     if($currentValue==''){
      $ret['html'].='<label class="form-check-label" id="'.$fieldName.'_label_'.$count.'" for="'.$fieldName.'_'.$count.'" style="cursor:pointer;font-weight:bold;margin-top:5px;margin-bottom:5px;display:inline-block;font-weight:bold;">';
      $ret['html'].='<input '.(isset($options['readonly'])&&$options['readonly']==true?' onclick="return false;" ':'').' type="radio" name="'.$fieldName.'" id="'.$fieldName.'_'.$count.'" value="" checked="checked"  style="transform:scale(1.3);display:inline-block;" />';
      $ret['html'].=' '.txtsys1('undefined').'';
      $ret['html'].='</label>'.CRLF;
      $isPrechecked=true;
     }else{
      $ret['html'].='<label class="form-check-label" id="'.$fieldName.'_label_'.$count.'" for="'.$fieldName.'_'.$count.'" style="cursor:pointer;margin-top:5px;margin-bottom:5px;display:inline-block;">';
      $ret['html'].='<input '.(isset($options['readonly'])&&$options['readonly']==true?' onclick="return false;" ':'').' type="radio" name="'.$fieldName.'" id="'.$fieldName.'_'.$count.'" value="" style="" />';
      $ret['html'].=' '.txtsys1('undefined').'';
      $ret['html'].='</label>'.CRLF;
     }
     $ret['html'].='&nbsp;&nbsp;';
     $count++;
    }
    foreach($GLOBALS['param__'.$paramName]['__values'][$GLOBALS['glob_lang']] as $k1 => $v1){
     if($k1==$currentValue && $isPrechecked==false){
      $ret['html'].='<label class="form-check-label" id="'.$fieldName.'_label_'.$count.'" for="'.$fieldName.'_'.$count.'" style="cursor:pointer;margin-top:5px;margin-bottom:5px;display:inline-block;font-weight:bold;">';
      $ret['html'].='<input '.(isset($options['readonly'])&&$options['readonly']==true?' onclick="return false;" ':'').' type="radio" name="'.$fieldName.'" id="'.$fieldName.'_'.$count.'" value="'.$k1.'" checked="checked" style="transform:scale(1.3);" />';
      $ret['html'].=' '.$v1[$GLOBALS['param__'.$paramName]['param__Name__Display']].'';
      $ret['html'].='</label>'.CRLF;
     }else{
      $ret['html'].='<label class="form-check-label" id="'.$fieldName.'_label_'.$count.'" for="'.$fieldName.'_'.$count.'" style="cursor:pointer;margin-top:5px;margin-bottom:5px;display:inline-block;">';
      $ret['html'].='<input '.(isset($options['readonly'])&&$options['readonly']==true?' onclick="return false;" ':'').' type="radio" name="'.$fieldName.'" id="'.$fieldName.'_'.$count.'" value="'.$k1.'" style="" />';
      $ret['html'].=' '.$v1[$GLOBALS['param__'.$paramName]['param__Name__Display']].'';
      $ret['html'].='</label>'.CRLF;
     }
     $ret['html'].='&nbsp;&nbsp;';
     $count++;
    }
   }

  }

 }else{
  $ret['html'] = txtsys1('error') . ' param "'.$paramName.'" not founded';
 }
 return $ret;
}
//========================================================================================================================
function checkGroupAjaxPages(){
 if(!isset($_SESSION[PGMK]['groupInit'])){
  $_SESSION[PGMK]['groupInit']=2; // anonymous
 }
 require_once($GLOBALS['glob_noVcPath1'].'/pages_of_groups/pages_of_group_'.$_SESSION[PGMK]['group'].'.php');
 if($_SESSION[PGMK]['groupInit']==1){ // root can do all
  return true;
 }
 if(isset($GLOBALS['glob_grpspgs'][BNF]) && $GLOBALS['glob_grpspgs'][BNF]['aj']=='1'){
  return true;
 }
 if(isset($GLOBALS['glob_grpspgs']['index.php']['a']) && $GLOBALS['glob_grpspgs']['index.php']['a']=='1'){
  return false;
  header("HTTP/1.1 303 See Other");header('Location: index.php?message=g000001&f='.urlencode(BNF));
  exit();
 }
 if(isset($GLOBALS['glob_grpspgs'][$GLOBALS['glob_log_in_page_name']]['a']) && $GLOBALS['glob_grpspgs'][$GLOBALS['glob_log_in_page_name']]['a']=='1'){
  return false;
 }
 return false;
}
//========================================================================================================================
function txt4($s){ // for translation of data-label inside tables
 static $pos=0;
 $pos++;
 if(true===$GLOBALS['glob_translate']){
  return $s.'"><span class="translate" data-idTranslate="'.$s.'_'.$pos.'" id="'.$s.'_'.$pos.'"><temp prop="';
 }else{
  return $s;
 }
}
//========================================================================================================================
function txt1($s){
 static $pos=0;
 $pos++;
 if(true===$GLOBALS['glob_translate']){
  return '<span class="translate" data-idTranslate="'.$s.'_'.$pos.'" id="'.$s.'_'.$pos.'">'.$s.'</span>';
 }else{
  return $s;
 }

}
//========================================================================================================================
function txt2($s){
 if(isset($GLOBALS['glob_lv'][$s])){
  if($GLOBALS['glob_translate']){
   return ''.$GLOBALS['glob_lv'][$s].'';
   return '<span class="forTranslation" id="to__translate_'.$s.'" data-idtranslate="'.BNF.'|'.$s.'|'.$GLOBALS['glob_lang'].'" contenteditable="true">'.$GLOBALS['glob_lv'][$s].'</span>';
  }else{
   return $GLOBALS['glob_lv'][$s];
  }
 }else{
  if(isset($GLOBALS['glob_grpspgs'][BNF]) && !is_null($GLOBALS['glob_grpspgs'][BNF]) ){
   if($GLOBALS['glob_translate']){
    $req8='
     INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`dgo_tbl__langvalues` SET
     `fld_key_lngVals`     =\''.addslashes($s).'\'                   ,
     `fld_lang_lngVals`    =\''.addslashes($GLOBALS['glob_lang']).'\' ,
     `fld_page_id_lngVals` =  '.$GLOBALS['glob_grpspgs'][BNF]['id'].' ,
     `fld_value_lngVals`   =\''.addslashes($s).'\'                    ,
     `fld_type_lngVals`    =\'page\'                                  ,
     `fld_tsupd_lngVals`   = \''.$GLOBALS['glob_setdate'].'\'         ,
     `fld_tscrt_lngVals`   = \''.$GLOBALS['glob_setdate'].'\'         ,
     `fld_cntupd_lngVals`  = 0
    ';
    $res8=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req8);
   }
  }
 }
 return $s;
}
//========================================================================================================================
function txt3($s){ // for menus
 if(isset($GLOBALS['glob_lv'][$s])){
  return ''.$GLOBALS['glob_lv'][$s].'';
 }else{
  return ''.$s.'';
 }
}
//========================================================================================================================
function txtsys1($s){
 if(isset($GLOBALS['glob_lv']['system__'.$s])){
  return ''.$GLOBALS['glob_lv']['system__'.$s].'';
 }else{
  return ''.$s.'';
 }
}
//========================================================================================================================
function checkmydate($date){ // "yyyy-mm-dd"
 if(strlen($date)!=10) return false;
 $tempDate = explode('-', $date);
 if(count($tempDate)!=3) return false;
 if(!(is_numeric($tempDate[0]) && is_numeric($tempDate[1]) && is_numeric($tempDate[2]))) return false;
 return checkdate($tempDate[1], $tempDate[2], $tempDate[0]); // m d y
}
//========================================================================================================================
function checkmytime($time){ // "hh:mm:ss"
 if(strlen($time)!=8) return false;
 $tempTime = explode(':', $time);
 if(count($tempTime)!=3) return false;
 if(!(is_numeric($tempTime[0]) && is_numeric($tempTime[1]) && is_numeric($tempTime[2]))) return false;
 if(!((int)$tempTime[0]>=0 && (int)$tempTime[0]<=23 && (int)$tempTime[1]>=0 && (int)$tempTime[1]<=59 && (int)$tempTime[2]>=0 && (int)$tempTime[2]<=59 )) return false;
 return true;
}
//========================================================================================================================
function checkmydatetime($datetime){ // "YYYY-MM-DD hh:mm:ss"
 if(strlen($datetime)!=19) return false;
 $tempDateTime = explode(' ', $datetime);
 if(count($tempDateTime)!=2) return false;
 if(checkmydate($tempDateTime[0]) && checkmytime($tempDateTime[1])){
  return true;
 }
 return false;
}
//========================================================================================================================
function numericOk1($s){ // 0123456789
 for($i=0;$i<strlen($s);$i++){
  $c=substr($s,$i,1);
  if(!($c>='0'&&$c<='9')){
   return false;
  }
 }
 return true;
}
//========================================================================================================================
function phoneOk1($s){ // +33 (0)1 23 45 67 89
 for($i=0;$i<strlen($s);$i++){
  $c=substr($s,$i,1);
  if(!(($c>='0'&&$c<='9')||$c===' '||$c==='('||$c===')'||$c==='+')){
   return false;
  }
 }
 return true;
}
//========================================================================================================================
function getCss1($limitPx){
 $css='<style type="text/css">
@media screen and (max-width: '.$limitPx.'px){
 table.yytableResult1{border: 0;width:100%;max-width:540px;margin:0 auto;}
 table.yytableResult1 thead{border:none;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;}
 table.yytableResult1 tr{display:block;margin-bottom:2em;border-radius:4px;box-shadow: 0px 0px 5px;}
 table.yytableResult1 td{display:block;text-align:right!important;min-height:36px;word-break:break-word;line-height:1.5em;margin-top:12px;}
 table.yytableResult1 td:before{content:attr(data-label);float:left!important;font-weight:bold;margin-right:12px;padding-right:5px;}
 table.yytableResult1 td:last-child{border-bottom:0;}
 .yytableResult1 td {height:auto;}
}
</style>';
return $css;
}
//========================================================================================================================
function htmlHead1($par){
 $o1='';
 if(!ob_start("ob_gzhandler")) ob_start();
 header('Content-Type: text/html; charset=utf-8');
 $o1.='<!DOCTYPE html>'.CRLF;
 $o1.='<html lang="'.$GLOBALS['glob_lang'].'">'.CRLF;
 $o1.='<head>'.CRLF;
 $o1.='<meta charset="utf-8" />'.CRLF;
 $o1.='<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />'.CRLF;
 $o1.='<title>'.APP_SHORT_NAME.'</title>'.CRLF;
 $o1.='<meta name="description" content="'.APP_SHORT_NAME.'" />'.CRLF;
 $o1.='<meta name="viewport" content="width=device-width" />'.CRLF;
// $o1.='<link rel="Shortcut icon" href="favicon.ico" type="image/x-icon" />'.CRLF;
 include $GLOBALS['glob_noVcPath1'].'/dynamic_js_and_css/__css.php';
 if(!isset($_COOKIE[PGMK.'cssvalue'])){
  $_COOKIE[PGMK.'cssvalue']=1;
  setcookie ( PGMK.'cssvalue' , $_COOKIE[PGMK.'cssvalue'], time()+3600*24*365, '/' );
 }else{
  if(!isset($__css[$_COOKIE[PGMK.'cssvalue']])){
   $_COOKIE[PGMK.'cssvalue']=1;
   setcookie ( PGMK.'cssvalue' , $_COOKIE[PGMK.'cssvalue'], time()+3600*24*365, '/'  );
  }
 }
 $o1.='<link rel="stylesheet" href="zz_getDynCssOrJs.php?n='.$_COOKIE[PGMK.'cssvalue'].'&t=css&v='.$__css[$_COOKIE[PGMK.'cssvalue']]['fld_tsupd_css'].'" />'.CRLF;
 $o1.='<script type="text/javascript" src="zz_getDynCssOrJs.php?n='.$_COOKIE[PGMK.'cssvalue'].'&t=js&v='.$__css[$_COOKIE[PGMK.'cssvalue']]['fld_tsupd_css'].'"></script>'.CRLF;
 $o1.='<script type="text/javascript" src="js/__parentMenu.js?v='.$GLOBALS['vrsi'].'"></script>'.CRLF;
 $o1.='<script type="text/javascript">'.CRLF;
 $o1.='var globLang=\''.$GLOBALS['glob_lang'].'\';'.CRLF;
 $o1.='var globMaxSessionTime='.SESSION_MAX_TIME.';'.CRLF;
 $o1.='var zz_page_id='.PAGE_ID.';'.CRLF;
 $o1.='var globAvailableLanguages='.json_encode($GLOBALS['glob__availableLanguages'],JSON_FORCE_OBJECT).';'.CRLF;
 $o1.='var globBNF=\''.BNF.'\';'.CRLF;
 $o1.='var globTranslator='.(isset($_SESSION[PGMK]['translate'])&&$_SESSION[PGMK]['translate']=='1'?'true':'false').';'.CRLF;
 $o1.='var globTranslate='.($GLOBALS['glob_translate']?'true':'false').';'.CRLF;
 $o1.='var globTablang=[];'.CRLF;
 $o1.='</script>'.CRLF;
 $o1.='<script src="js/main.js?v='.$GLOBALS['vrsi'].'"></script>'.CRLF;
 $o1.='<script src="zz_getDynCssOrJs.php?n='.$GLOBALS['glob_lang'].'&t=js&c=lang&v='.$GLOBALS['vrsi'].'"></script>'.CRLF;

 $breakMenuSelect=array(5,12); // value1 = number of item before menu 1, value2 = total number of items before menu 2
 $o1.='</head>'.CRLF;
 $o1.='<body>'.CRLF;
 $o1.='  <nav id="navbar" class="yynavbar">'.CRLF;
 $o1.='    <div id="menuScroller">'.CRLF;
 $o1.='      <div>'.CRLF;
 $o1.='        <ul>'.CRLF;
 $o1.='          <li><a href="index.php" class="'.('index.php'===BNF?'yymenusel1':'').'" style="font-size:1.5em;line-height:15px;">&#127968;</a></li>'.CRLF;
 $countMenuItems=0;
 $countMenuOther=0;
 if(isset($_SESSION[PGMK]['groupInit']) && isset($GLOBALS['glob_grpspgs'])){
  foreach($GLOBALS['glob_grpspgs'] as $k1 => $v1){
   if($v1['m']=='1' && $k1 !='index.php' && $k1!='logout.php' && ($GLOBALS['glob_isLocalHost'] || (!$GLOBALS['glob_isLocalHost'] && $v1['remote']==1 ))){
    if($_SESSION[PGMK]['groupInit']!=2&&$k1==$GLOBALS['glob_log_in_page_name']){
    }else if($_SESSION[PGMK]['groupInit']==2&&$k1=='logout.php'){
    }else{
     if($countMenuItems<$breakMenuSelect[0]){
      $o1.='          <li>'.CRLF;
      $o1.='            <a id="menu_'.$v1['id'].'" class="'.($k1===BNF?'yymenusel1':'').'" href="'.$k1.'?m=1">'.txt3('menu__'.$k1).'</a>'.CRLF;
      $o1.='          </li>'.CRLF;
      $countMenuItems++;
     }else{
      if($countMenuItems==$breakMenuSelect[0]){
       $o1.='<li>'.CRLF;
       $o1.='<select id="menuDrop1" onchange="menuDropBoot1(this.value);" name="menuDrop1">'.CRLF;
       $countMenuOther++;
       $o1.='<option> - - '.txtsys1('menu_other').' '.$countMenuOther.'</option>'.CRLF;
       $o1.='<option data-menusel="'.$countMenuOther.'" id="menu_'.$v1['id'].'" value="jumpTo:'.$k1.'?m=1" '.(BNF==$k1?'selected="selected"':'').'>'.txt3('menu__'.$k1).'</option>'.CRLF;
       $countMenuItems++;
      }else{
       if($countMenuItems==$breakMenuSelect[1]){
        $o1.='</select>'.CRLF;
        $o1.='<select id="menuDrop2" onchange="menuDropBoot1(this.value);" name="menuDrop2" >'.CRLF;
        $countMenuOther++;
        $o1.='<option style=""> - - '.txtsys1('menu_other').' '.$countMenuOther.'</option>'.CRLF;
        if(BNF==$k1){
         $o1.='<option data-menusel="'.$countMenuOther.'" id="menu_'.$v1['id'].'" value="jumpTo:'.$k1.'?m=1" selected="selected">'.txt3('menu__'.$k1).'</option>'.CRLF;
        }else{
         $o1.='<option data-menusel="'.$countMenuOther.'" id="menu_'.$v1['id'].'" value="jumpTo:'.$k1.'?m=1">'.txt3('menu__'.$k1).'</option>'.CRLF;
        }
        $countMenuItems++;
       }else{
        if(BNF==$k1){
         $o1.='<option data-menusel="'.$countMenuOther.'" id="menu_'.$v1['id'].'" value="jumpTo:'.$k1.'?m=1" selected="selected">'.txt3('menu__'.$k1).'</option>'.CRLF;
        }else{
         $o1.='<option data-menusel="'.$countMenuOther.'" id="menu_'.$v1['id'].'" value="jumpTo:'.$k1.'?m=1">'.txt3('menu__'.$k1).'</option>'.CRLF;
        }
        $countMenuItems++;
       }
      }
     }
    }
   }
  }
  if(isset($_SESSION[PGMK]['translate']) && $_SESSION[PGMK]['translate']=='1' ){
   $displayTranslate=false;
   if( isset($_COOKIE['translate']) && $_COOKIE['translate']=='1' && isset($_SESSION[PGMK]['loginInit']) ){
    $displayTranslate=true;
   }
   if(isset($_SESSION[PGMK]['loginInit'])){
    $displayTranslate=true;    
   }
   
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_SESSION[PGMK] , true ) . '</pre>' ; exit(0);
   
   if(true==$displayTranslate){
    
    $styleMenuTranslatered='';
    if(isset($_COOKIE['translate']) && $_COOKIE['translate']=='1'){
     $styleMenuTranslatered='color:red;';
    }
    if($countMenuItems<$breakMenuSelect[0]){
     $o1.='          <li>'.CRLF;
     $o1.='            <a class="nav-link" href="javascript:translate1(\''.BNF.'\')" style="'.$styleMenuTranslatered.'">&#945;-&#937; &#128506; a-Z</a>'.CRLF;
     $o1.='          </li>'.CRLF;
     $countMenuItems++;
    }else{
     if($countMenuItems==$breakMenuSelect[0]){
      $o1.='<li>'.CRLF;
      $o1.='<select id="menuDrop1" onchange="menuDropBoot1(this.value);" name="menuDrop1" >'.CRLF;
      $countMenuOther++;
      $o1.='<option> - - '.txtsys1('menu_other').' '.$countMenuOther.'</option>'.CRLF;
      if(isset($_COOKIE['translate']) && $_COOKIE['translate']=='1'){
       $o1.='<option data-menusel="'.$countMenuOther.'" value="setTranslation:'.BNF.'" style="color:red;">&#945;-&#937; &#128506; a-Z</option>'.CRLF;
      }else{
       $o1.='<option data-menusel="'.$countMenuOther.'" value="setTranslation:'.BNF.'">&#945;-&#937; &#128506; a-Z</option>'.CRLF;
      }
      $countMenuItems++;
     }else{
      if($countMenuItems==$breakMenuSelect[1]){
       $o1.='</select>'.CRLF;
       $o1.='<select id="menuDrop2" onchange="menuDropBoot1(this.value);" name="menuDrop2">'.CRLF;
       $countMenuOther++;
       $o1.='<option> - - '.txtsys1('menu_other').' '.$countMenuOther.'</option>'.CRLF;
       if(isset($_COOKIE['translate']) && $_COOKIE['translate']=='1'){
        $o1.='<option data-menusel="'.$countMenuOther.'" value="setTranslation:'.BNF.'" style="color:red;">&#945;-&#937; &#128506; a-Z</option>'.CRLF;
       }else{
        $o1.='<option data-menusel="'.$countMenuOther.'" value="setTranslation:'.BNF.'">&#945;-&#937; &#128506; a-Z</option>'.CRLF;
       }
       $countMenuItems++;
      }else{
       if(isset($_COOKIE['translate']) && $_COOKIE['translate']=='1'){
        $o1.='<option data-menusel="'.$countMenuOther.'" value="setTranslation:'.BNF.'" style="color:red;">&#945;-&#937; &#128506; a-Z</option>'.CRLF;
       }else{
        $o1.='<option data-menusel="'.$countMenuOther.'" value="setTranslation:'.BNF.'">&#945;-&#937; 🌎  a-Z</option>'.CRLF;
       }
       $countMenuItems++;
      }
     }
    }    
    
    
   }
  }
 }

// echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( is_array($GLOBALS['glob__availableLanguages']) , true ) . '</pre>' ; exit(0);
 if(sizeof($GLOBALS['glob__availableLanguages'])>0){
  foreach($GLOBALS['glob__availableLanguages'] as $k1 => $v1){
   if($GLOBALS['glob_lang']!=$k1){
    if($countMenuItems<$breakMenuSelect[0]){
     $o1.='          <li>'.CRLF;
     $o1.='            <a class="nav-link" href="javascript:setLanguage(\''.$k1.'\')">'.$v1['n'].'</a>'.CRLF;
     $o1.='          </li>'.CRLF;
     $countMenuItems++;
    }else{
     if($countMenuItems==$breakMenuSelect[0]){
      $o1.='<li>'.CRLF;
      $o1.='<select id="menuDrop1" onchange="menuDropBoot1(this.value);" name="menuDrop1">'.CRLF;
      $countMenuOther++;
      $o1.='<option style="">'.txtsys1('menu_other').' '.$countMenuOther.'</option>'.CRLF;
      $o1.='<option value="setLang:'.$k1.'">'.$v1['n'].'</option>'.CRLF;
      $countMenuItems++;
     }else{
      if($countMenuItems==$breakMenuSelect[1]){
       $o1.='</select>'.CRLF;
       $o1.='</li>'.CRLF;
       $o1.='<li>'.CRLF;
       $o1.='<select id="menuDrop2" onchange="menuDropBoot1(this.value);" name="menuDrop2">'.CRLF;
       $countMenuOther++;
       $o1.='<option>'.txtsys1('menu_other').' '.$countMenuOther.'</option>'.CRLF;
       $o1.='<option value="setLang:'.$k1.'">'.$v1['n'].'</option>'.CRLF;
       $countMenuItems++;
      }else{
       $o1.='<option value="setLang:'.$k1.'">'.$v1['n'].'</option>'.CRLF;
       $countMenuItems++;
      }
     }
    }
   }
  }
 }
 if($countMenuItems>=1){
  $o1.='  </select>'.CRLF;
 }
 $o1.='</li>'.CRLF;
 $o1.='</ul>'.CRLF;
 $o1.='      </div>'.CRLF;
 if(isset($_SESSION[PGMK]['groupInit']) && $_SESSION[PGMK]['groupInit']!=2){
  $o1.='       <div>'.CRLF;
  $o1.='        <ul><li><a id="buttonQuit2" href="logout.php" alt="" class="yydanger">'.txt3('menu__logout.php').'</a></li></ul>'.CRLF;
  $o1.='       </div>'.CRLF;
 }

 $o1.='      </div>'.CRLF;
 $o1.='    </nav>  '.CRLF;
 $o1.='    <main id="mainContent">'.CRLF;
 return($o1);
}
//========================================================================================================================
function htmlFoot0($par){
 $o1='';
 $o1.='</main>'.CRLF;
 $classFooter='';
 if(isset($_SESSION[PGMK]['login']) && $_SESSION[PGMK]['login']!=$_SESSION[PGMK]['loginInit']){
  $classFooter=' yywarning';
 }  
 $o1.='<footer id="footer" class="yyfooter'.$classFooter.'" style="display:flex;justify-content: space-around;">'.CRLF;
 if(isset($_SESSION[PGMK]['login']) && $_SESSION[PGMK]['login']>0){
  if(isset($_SESSION[PGMK]['login']) && $_SESSION[PGMK]['grpCatInit'] != $_SESSION[PGMK]['grpCat']){
   $o1.='<span class="noHide yyerror" style="padding:0 1px;" >'.$_SESSION[PGMK]['grpCat'].'</span>'.CRLF;
  }
 }
 if(isset($_SESSION[PGMK]['login']) && $_SESSION[PGMK]['login']==1){
  if($GLOBALS['glob_isLocalHost']){
   $o1.='<a target="_blank" class="noHide yysuccess" style="" href="zz_design.php?m=1">design</a>'.CRLF;
   $o1.='<a target="_blank" class="noHide yyedit" href="zz_generateSources1.php?m=1">src</a>'.CRLF;
  }
  $o1.='<a target="_blank" class="noHide yywarning" href="zz_todos1.php?m=1">todo</a>'.CRLF;
 }else{
  $o1.='<a target="_blank" class="noHide" rel="noreferrer" href="https://www.koolsol.app">koolsol</a>'.CRLF;
  $o1.='<a target="_blank" class="noHide" rel="noreferrer" href="https://github.com/hugues-koolsol/%74%64%6F">&#116;&#100;&#111;</a>'.CRLF;
 }
 $o1.='<a class="noHide yydanger" href="javascript:topOfPage()" >&nbsp;&#8657;&nbsp;</a>'.CRLF;
 $o1.='</footer>'.CRLF;
 if($_SERVER['HTTP_HOST']=='localhost'){
  $o1.='<script src="js/main-localhost.js?v='.$GLOBALS['vrsi'].'"></script>'.CRLF;
 }
 if($GLOBALS['glob_translate'] || 'zz_translate.php'==BNF){
  $o1.='<script src="js/translate.js?v='.$GLOBALS['vrsi'].'"></script>'.CRLF;
  $o1.='<div id="zztranslate"></div>'.CRLF;
 }
 $o1.='<script type="text/javascript">'.CRLF;
 if(isset($par['js'])){
  $o1.='function pageFunction(){'.CRLF;
  $txt1='';
  foreach($par['js'] as $k1 => $v1){
   if(isset($v1['jsName'])){
    if($txt1!='') $txt1.=','.CRLF;
    $txt1.=' '.json_encode($v1,JSON_FORCE_OBJECT).'';
   }
  }
  $o1.=' arrayLocalJs=['.CRLF.$txt1.CRLF.' ];'.CRLF;
  $o1.=' doLocalPage(arrayLocalJs);'.CRLF;
  $o1.='}'.CRLF;
 }else{
  $o1.='function pageFunction(){ /* do nothing */};'.CRLF;
 }
 if($GLOBALS['glob_debug']){
  $o1.='var modeDebug=true;'.CRLF;
 }else{
  $o1.='var modeDebug=false;'.CRLF;
 }
 if($GLOBALS['glob_maintenanceEnCours']){
  $o1.='var globVarMaintenanceEnCours=true;'.CRLF;
 }else{
  $o1.='var globVarMaintenanceEnCours=false;'.CRLF;
 }
 if($GLOBALS['glob_translate'] && isset($_SESSION[PGMK]['login'])){
  $o1.='var modeTranslate=true;'.CRLF;
  $o1.='var globalLangTranslate=\''.$GLOBALS['glob_lang'].'\';'.CRLF;
  $o1.='setTimeout(\'launchTranslate()\',500);'.CRLF;
 }else{
  $o1.='var modeTranslate=false;'.CRLF;
 }
 $o1.='</script>'.CRLF;

 $o1.='</body>'.CRLF;
 $o1.='</html>'.CRLF;
 return($o1);
}
//========================================================================================================================
function addslashes1($s){
 $s=addslashes($s);
 $ua=array(    'à' => 'à' , 'â' => 'â' ,'ã' => 'ã' , 'á' => 'á' ,
                            'é' => 'é' , 'è' => 'è' ,'ê' => 'ê' , 'É' => 'É' , 
                            'ï' => 'ï' , 'î' => 'î' ,
                            'ñ' => 'ñ' , 'Ñ' => 'Ñ' ,
                            'ó' => 'ó' , 'ô' => 'ô' , 'ö' => 'ö' , 
                            'ü' => 'ü' , 'Ü' => 'Ü' , 
 ); 
 return strtr( $s, $ua );  
}
//========================================================================================================================

//========================================================================================================================
//========================================================================================================================
//========================================================================================================================