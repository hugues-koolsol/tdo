<?php // € utf8 check with euro sign
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb1();
//========================================================================================================================
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 // méthode 1, tri avec sortable
 if(isset($_POST['buttonSort1']) && isset($_POST['sortedPages']) && $_POST['sortedPages']!=''){
  $sortedIds=explode(',',$_POST['sortedPages']);
  $order=0;
  $newTab=array();
  foreach($sortedIds as $k1=>$v1){
   if(is_numeric($v1)){
    $newTab[]=array(
     'id'    => $v1,
     'order' => $order,
    );
    $order++;
   }
  }
  if(count($newTab)>0){
   foreach($newTab as $k1 => $v1){
    $req6='
     UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` SET
       `fld_order_all_pages` = '.$v1['order'].'
     WHERE `fld_id_pages`      = '.$v1['id'].' 
    ';
    $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   }
   header('Location: zz_pages.php?m=1');
   exit();
  }
 }
 // méthode 2, tri avec hftree
 if(isset($_POST['buttonSort2']) && isset($_POST['sortedPages2']) && $_POST['sortedPages2']!=''){
  $sortedIds=explode(',',$_POST['sortedPages2']);
  $order=0;
  $newTab=array();
  foreach($sortedIds as $k1=>$v1){
   if(is_numeric($v1)){
    $newTab[]=array(
     'id'    => $v1,
     'order' => $order,
    );
    $order++;
   }
  }
  if(count($newTab)>0){
   foreach($newTab as $k1 => $v1){
    $req6='UPDATE `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` SET `fld_order_all_pages` = '.$v1['order'].' WHERE `fld_id_pages` = '.$v1['id'].' ';
    $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   }
   header('Location: zz_pages.php?m=1');
   exit();
  }
 }
 header('Location: '.BNF.'');
 exit();
}
//========================================================================================================================
$o1='';
$__count=0;
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('sort_pages_42_18').'&nbsp;<a href="zz_pages.php" class="">'.txtsys1('back_to_the_list').'</a>'.'</h1>';
$o1.=displaySessionMessage1(BNF);

$toFooterArray=array();
//====================================================================================================
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_pages`              ,T0.`fld_name_pages`            ,T0.`fld_menu_pages`            ,T0.`fld_isajax_pages`          ,T0.`fld_isremote_pages`        ,
   T0.`fld_isuser_pages`          ,T0.`fld_localadmin_pages`      ,T0.`fld_isaction_pages`        ,T0.`fld_parent_pages`          ,T1.`fld_name_pages`            ,
   T0.`fld_order_all_pages`       
 FROM (   `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages` T0 ) 
 LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__pages`  T1 ON T0.`fld_parent_pages` = T1.`fld_id_pages`
 WHERE 1=1 
   ORDER BY T0.`fld_order_all_pages` ASC
';

//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$data0=array();
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 while($mpsr6=mysqli_fetch_row($result6)){
  $data0[]=array(
  'T0.fld_id_pages'              =>$mpsr6[0],
  'T0.fld_name_pages'            =>$mpsr6[1],
  'T0.fld_menu_pages'            =>$mpsr6[2],
  'T0.fld_isajax_pages'          =>$mpsr6[3],
  'T0.fld_isremote_pages'        =>$mpsr6[4],
  'T0.fld_isuser_pages'          =>$mpsr6[5],
  'T0.fld_localadmin_pages'      =>$mpsr6[6],
  'T0.fld_isaction_pages'        =>$mpsr6[7],
  'T0.fld_parent_pages'          =>$mpsr6[8],
  'T1.fld_name_pages'            =>$mpsr6[9],
  'T0.fld_order_all_pages'       =>$mpsr6[10],
  );
 }
 mysqli_free_result($result6);
 if(sizeof($data0)>0){
  $reqCount6='SELECT FOUND_ROWS();';
  $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
   $mpsrcount6=mysqli_fetch_row($rescount6);
   $__count=$mpsrcount6[0];
  }
 }
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));  
}

//============================================================================
// méthode 2, tri avec hftree
//============================================================================

$phpTree=array();
foreach($data0 as $k0=>$v0){
 $phpTree[]=array(
  'id'       => $v0['T0.fld_id_pages'],
  'data'     => array( 'label' => $v0['T0.fld_name_pages'] ),
  'parentId' => 0,
 );
}

$o1.='<form method="post">';
$o1.=' <input type="hidden" id="sortedPages2" name="sortedPages2" value="" />';
$o1.=' <button type="submit" id="buttonSort2" name="buttonSort2" value="sortTodos" style="" >'.txt2('record_this_sort_order_110_102').'</button>';
$o1.='</form>';

$o1.='<div id="container2" style="max-width:80%;border:1px #f00 solid;overflow-y:scroll;max-height:500px;">';
$o1.='     <div id="myTreeId2"></div>';
$o1.='</div>';

$o1.='<br /><br /><br />';

$o1.='<script src="js/hdtree.js?v=20171122-1917"></script>';
$o1.='<script type="text/javascript">';
$o1.='var jsonTree2='.json_encode($phpTree).';';
$o1.='var options2={';
$o1.=' sortOnly : true  ,';
$o1.='}';
$o1.='</script>';

$toFooterArray=array(
 'js' => array(
  array( 
   'jsName'                  => 'sortTable2'         ,
   'objectName'              => 'oMyTree2'        ,
   'elementToSort'           => 'myTreeId2'       ,
   'dataToSort'              => 'jsonTree2'       ,
   'options'                 => 'options2'        ,
   'callBack'                => 'afterSortTable1' ,
   'localhost'               => true
  ),
 ),
);


//var oMyTree2=new cMyTree1('oMyTree2','myTreeId2',jsonTree2,options2,myCallBackAction1);

/*

//============================================================================
// méthode 1, tri avec sortable
//============================================================================

$lst='';
$lsttbl='';
if($__count==0){
 $lst.='<p>'.CRLF;
 $lst.=''.txt2('no_record_founded_93_16').''.CRLF;
 $lst.='</p>'.CRLF;
 $o1.=''.$lst.''.CRLF;  
}else{

 $o1.=getCss1(890); // todo adjust size
 $currentOrder='';
 $lsttbl.='<ul id="mypages1" style="list-style:none;padding:0;">';
 foreach($data0 as $k0=>$v0){
  $currentOrder.=','.$v0['T0.fld_id_pages'];
  $lsttbl.='<li class="thinBorder" id="'.$v0['T0.fld_id_pages'].'" style="min-height:40px;padding:5px;margin:5px;max-width:80%;word-break:break-word;">';
  $lsttbl.='&nbsp;<span class="edit thinBorder">&nbsp;&#8661;&nbsp;</span>&nbsp;'.$v0['T0.fld_order_all_pages'].' '.enti1($v0['T0.fld_name_pages']);
  $lsttbl.='</li>';
 }
 $lsttbl.='</ul>';
 $o1.='<form method="post">';
 $o1.=' <input type="hidden" id="sortedPages" name="sortedPages" value="'.substr($currentOrder,1).'" />';
 $o1.=' <button type="submit" id="buttonSort1" name="buttonSort1" value="sortTodos" style="" >'.txt2('record_this_sort_order_110_102').'</button>';
 $o1.='</form>';

 $o1.=''.CRLF.$lsttbl.''.CRLF;

 $toFooterArray=array(
  'js' => array(
   array( 
    'jsName'                  => 'sortable1'    , 
    'elementToSort'           => 'mypages1'     , 
    'sortFunction'            => 'sortMyTodos'  , 
    'inputWithSortedElements' => 'sortedPages'  , 
    'buttonSort'              => 'buttonSort1'  ,
    'styleOfButton'           => 'inline-block' , 
   ),
  ),
 );

}
*/

$o1.=htmlFoot0($toFooterArray);
dw1($o1);
cleanSession1();
