<?php
function getinc_tdo_zztests1($id){
 $n=array();
 $n['T0_fld_id_zztests']                =0;
 $n['T0_fld_yorno1_zztests']            ='';
 $n['T0_fld_visited_countries_zztests'] ='';
 $n['T0_fld_country1_zztests']          ='';
 $n['T0_fld_title32_zztests']           ='';
 $n['T0_fld_id_parent_zztests']         =null; // null possible
 $n['T0_fld_order_in_parent_zztests']   =0;
 $n['T0_fld_date1_zztests']             =null; // null possible
 $n['T0_fld_time1_zztests']             =null; // null possible
 $n['T0_fld_dttim1_zztests']            =null; // null possible
 $n['T0_fld_color1_zztests']            ='';
 $n['T0_fld_email1_zztests']            ='';
 $n['T0_fld_zipnum1_zztests']           =0;
 $n['T0_fld_tsupd_zztests']             ='1000-01-01 00:00:00';
 $n['T0_fld_tscrt_zztests']             ='1000-01-01 00:00:00';
 $n['T0_fld_cntupd_zztests']            =0;
 $sql='
  SELECT 
   T0.`fld_id_zztests`                ,T0.`fld_yorno1_zztests`            ,T0.`fld_visited_countries_zztests` ,T0.`fld_country1_zztests`          ,T0.`fld_title32_zztests`           ,
   T0.`fld_id_parent_zztests`         ,T0.`fld_order_in_parent_zztests`   ,T0.`fld_date1_zztests`             ,T0.`fld_time1_zztests`             ,T0.`fld_dttim1_zztests`            ,
   T0.`fld_color1_zztests`            ,T0.`fld_email1_zztests`            ,T0.`fld_zipnum1_zztests`           ,T0.`fld_tsupd_zztests`             ,T0.`fld_tscrt_zztests`             ,
   T0.`fld_cntupd_zztests`            
  FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` T0
  WHERE T0.`fld_id_zztests` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['T0_fld_id_zztests']                = $row[0];
   $n['T0_fld_yorno1_zztests']            = $row[1];
   $n['T0_fld_visited_countries_zztests'] = $row[2];
   $n['T0_fld_country1_zztests']          = $row[3];
   $n['T0_fld_title32_zztests']           = $row[4];
   $n['T0_fld_id_parent_zztests']         = $row[5];
   $n['T0_fld_order_in_parent_zztests']   = $row[6];
   $n['T0_fld_date1_zztests']             = $row[7];
   $n['T0_fld_time1_zztests']             = $row[8];
   $n['T0_fld_dttim1_zztests']            = $row[9];
   $n['T0_fld_color1_zztests']            = $row[10];
   $n['T0_fld_email1_zztests']            = $row[11];
   $n['T0_fld_zipnum1_zztests']           = $row[12];
   $n['T0_fld_tsupd_zztests']             = $row[13];
   $n['T0_fld_tscrt_zztests']             = $row[14];
   $n['T0_fld_cntupd_zztests']            = $row[15];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
//======================================================================
function getinc_tdo_zztests_withParentFields1($id){
 $n=array();
 $n['T0_fld_id_zztests']                =0;
 $n['T0_fld_yorno1_zztests']            ='';
 $n['T0_fld_visited_countries_zztests'] ='';
 $n['T0_fld_country1_zztests']          ='';
 $n['T0_fld_title32_zztests']           ='';
 $n['T0_fld_id_parent_zztests']         =null; // null possible
 $n['T0_fld_order_in_parent_zztests']   =0;
 $n['T0_fld_date1_zztests']             =null; // null possible
 $n['T0_fld_time1_zztests']             =null; // null possible
 $n['T0_fld_dttim1_zztests']            =null; // null possible
 $n['T0_fld_color1_zztests']            ='';
 $n['T0_fld_email1_zztests']            ='';
 $n['T0_fld_zipnum1_zztests']           =0;
 $n['T0_fld_tsupd_zztests']             ='1000-01-01 00:00:00';
 $n['T0_fld_tscrt_zztests']             ='1000-01-01 00:00:00';
 $n['T0_fld_cntupd_zztests']            =0;
 $n['T1_fld_id_zztests']                =0;
 $n['T1_fld_yorno1_zztests']            ='';
 $n['T1_fld_visited_countries_zztests'] ='';
 $n['T1_fld_country1_zztests']          ='';
 $n['T1_fld_title32_zztests']           ='';
 $n['T1_fld_id_parent_zztests']         =null; // null possible
 $n['T1_fld_order_in_parent_zztests']   =0;
 $n['T1_fld_date1_zztests']             =null; // null possible
 $n['T1_fld_time1_zztests']             =null; // null possible
 $n['T1_fld_dttim1_zztests']            =null; // null possible
 $n['T1_fld_color1_zztests']            ='';
 $n['T1_fld_email1_zztests']            ='';
 $n['T1_fld_zipnum1_zztests']           =0;
 $n['T1_fld_tsupd_zztests']             ='1000-01-01 00:00:00';
 $n['T1_fld_tscrt_zztests']             ='1000-01-01 00:00:00';
 $n['T1_fld_cntupd_zztests']            =0;
 $sql='
  SELECT 
   T0.`fld_id_zztests`                ,T0.`fld_yorno1_zztests`            ,T0.`fld_visited_countries_zztests` ,T0.`fld_country1_zztests`          ,T0.`fld_title32_zztests`           ,
   T0.`fld_id_parent_zztests`         ,T0.`fld_order_in_parent_zztests`   ,T0.`fld_date1_zztests`             ,T0.`fld_time1_zztests`             ,T0.`fld_dttim1_zztests`            ,
   T0.`fld_color1_zztests`            ,T0.`fld_email1_zztests`            ,T0.`fld_zipnum1_zztests`           ,T0.`fld_tsupd_zztests`             ,T0.`fld_tscrt_zztests`             ,
   T0.`fld_cntupd_zztests`            ,T1.`fld_id_zztests`                ,T1.`fld_yorno1_zztests`            ,T1.`fld_visited_countries_zztests` ,T1.`fld_country1_zztests`          ,
   T1.`fld_title32_zztests`           ,T1.`fld_id_parent_zztests`         ,T1.`fld_order_in_parent_zztests`   ,T1.`fld_date1_zztests`             ,T1.`fld_time1_zztests`             ,
   T1.`fld_dttim1_zztests`            ,T1.`fld_color1_zztests`            ,T1.`fld_email1_zztests`            ,T1.`fld_zipnum1_zztests`           ,T1.`fld_tsupd_zztests`             ,
   T1.`fld_tscrt_zztests`             ,T1.`fld_cntupd_zztests`            
  FROM ( `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` T0
       )
 LEFT JOIN `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests`  T1 ON T0.`fld_id_parent_zztests`          = T1.`fld_id_zztests` 
  WHERE T0.`fld_id_zztests` = '.$id. '
 ';
 $req=mysqli_query($GLOBALS['glob_db'][0]['link'],$sql);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  while($row=mysqli_fetch_row($req)){
   $n['T0_fld_id_zztests']                = $row[0];
   $n['T0_fld_yorno1_zztests']            = $row[1];
   $n['T0_fld_visited_countries_zztests'] = $row[2];
   $n['T0_fld_country1_zztests']          = $row[3];
   $n['T0_fld_title32_zztests']           = $row[4];
   $n['T0_fld_id_parent_zztests']         = $row[5];
   $n['T0_fld_order_in_parent_zztests']   = $row[6];
   $n['T0_fld_date1_zztests']             = $row[7];
   $n['T0_fld_time1_zztests']             = $row[8];
   $n['T0_fld_dttim1_zztests']            = $row[9];
   $n['T0_fld_color1_zztests']            = $row[10];
   $n['T0_fld_email1_zztests']            = $row[11];
   $n['T0_fld_zipnum1_zztests']           = $row[12];
   $n['T0_fld_tsupd_zztests']             = $row[13];
   $n['T0_fld_tscrt_zztests']             = $row[14];
   $n['T0_fld_cntupd_zztests']            = $row[15];
   $n['T1_fld_id_zztests']                = $row[16];
   $n['T1_fld_yorno1_zztests']            = $row[17];
   $n['T1_fld_visited_countries_zztests'] = $row[18];
   $n['T1_fld_country1_zztests']          = $row[19];
   $n['T1_fld_title32_zztests']           = $row[20];
   $n['T1_fld_id_parent_zztests']         = $row[21];
   $n['T1_fld_order_in_parent_zztests']   = $row[22];
   $n['T1_fld_date1_zztests']             = $row[23];
   $n['T1_fld_time1_zztests']             = $row[24];
   $n['T1_fld_dttim1_zztests']            = $row[25];
   $n['T1_fld_color1_zztests']            = $row[26];
   $n['T1_fld_email1_zztests']            = $row[27];
   $n['T1_fld_zipnum1_zztests']           = $row[28];
   $n['T1_fld_tsupd_zztests']             = $row[29];
   $n['T1_fld_tscrt_zztests']             = $row[30];
   $n['T1_fld_cntupd_zztests']            = $row[31];
  }
  mysqli_free_result($req);
 }else{
  debugSql2(array('sqler' => ' in '. __FUNCTION__ . ' ' . mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $sql , 'file' => __FILE__ , 'line' => __LINE__ ));
 }
 return($n);
}
//======================================================================
function get_tdo_zztests_difference1($b,$a){ // before , after
 if(
     $b['T0_fld_yorno1_zztests']==$a['T0_fld_yorno1_zztests']
  && $b['T0_fld_visited_countries_zztests']==$a['T0_fld_visited_countries_zztests']
  && $b['T0_fld_country1_zztests']==$a['T0_fld_country1_zztests']
  && $b['T0_fld_title32_zztests']==$a['T0_fld_title32_zztests']
  && $b['T0_fld_id_parent_zztests']==$a['T0_fld_id_parent_zztests']
  && $b['T0_fld_order_in_parent_zztests']==$a['T0_fld_order_in_parent_zztests']
  && $b['T0_fld_date1_zztests']==$a['T0_fld_date1_zztests']
  && $b['T0_fld_time1_zztests']==$a['T0_fld_time1_zztests']
  && $b['T0_fld_dttim1_zztests']==$a['T0_fld_dttim1_zztests']
  && $b['T0_fld_color1_zztests']==$a['T0_fld_color1_zztests']
  && $b['T0_fld_email1_zztests']==$a['T0_fld_email1_zztests']
  && $b['T0_fld_zipnum1_zztests']==$a['T0_fld_zipnum1_zztests']
 ){
  return '// UPDATE no difference'.CRLF;
 }else{;
  $t1='';
  if($b['T0_fld_yorno1_zztests']!=$a['T0_fld_yorno1_zztests']){
   $t1.='fld_yorno1_zztests from "'.$b['T0_fld_yorno1_zztests'].'" to "'.$a['T0_fld_yorno1_zztests'].'"'.CRLF;
  }
  if($b['T0_fld_visited_countries_zztests']!=$a['T0_fld_visited_countries_zztests']){
   $t1.='fld_visited_countries_zztests from "'.$b['T0_fld_visited_countries_zztests'].'" to "'.$a['T0_fld_visited_countries_zztests'].'"'.CRLF;
  }
  if($b['T0_fld_country1_zztests']!=$a['T0_fld_country1_zztests']){
   $t1.='fld_country1_zztests from "'.$b['T0_fld_country1_zztests'].'" to "'.$a['T0_fld_country1_zztests'].'"'.CRLF;
  }
  if($b['T0_fld_title32_zztests']!=$a['T0_fld_title32_zztests']){
   $t1.='fld_title32_zztests from "'.$b['T0_fld_title32_zztests'].'" to "'.$a['T0_fld_title32_zztests'].'"'.CRLF;
  }
  if($b['T0_fld_id_parent_zztests']!=$a['T0_fld_id_parent_zztests']){
   $t1.='fld_id_parent_zztests from "'.(is_null($b['T0_fld_id_parent_zztests'])?'NULL':$b['T0_fld_id_parent_zztests']).'" to "'.(is_null($a['T0_fld_id_parent_zztests'])?'NULL':$a['T0_fld_id_parent_zztests']).'"'.CRLF;
  }
  if($b['T0_fld_order_in_parent_zztests']!=$a['T0_fld_order_in_parent_zztests']){
   $t1.='fld_order_in_parent_zztests from "'.$b['T0_fld_order_in_parent_zztests'].'" to "'.$a['T0_fld_order_in_parent_zztests'].'"'.CRLF;
  }
  if($b['T0_fld_date1_zztests']!=$a['T0_fld_date1_zztests']){
   $t1.='fld_date1_zztests from "'.(is_null($b['T0_fld_date1_zztests'])?'NULL':$b['T0_fld_date1_zztests']).'" to "'.(is_null($a['T0_fld_date1_zztests'])?'NULL':$a['T0_fld_date1_zztests']).'"'.CRLF;
  }
  if($b['T0_fld_time1_zztests']!=$a['T0_fld_time1_zztests']){
   $t1.='fld_time1_zztests from "'.(is_null($b['T0_fld_time1_zztests'])?'NULL':$b['T0_fld_time1_zztests']).'" to "'.(is_null($a['T0_fld_time1_zztests'])?'NULL':$a['T0_fld_time1_zztests']).'"'.CRLF;
  }
  if($b['T0_fld_dttim1_zztests']!=$a['T0_fld_dttim1_zztests']){
   $t1.='fld_dttim1_zztests from "'.(is_null($b['T0_fld_dttim1_zztests'])?'NULL':$b['T0_fld_dttim1_zztests']).'" to "'.(is_null($a['T0_fld_dttim1_zztests'])?'NULL':$a['T0_fld_dttim1_zztests']).'"'.CRLF;
  }
  if($b['T0_fld_color1_zztests']!=$a['T0_fld_color1_zztests']){
   $t1.='fld_color1_zztests from "'.(is_null($b['T0_fld_color1_zztests'])?'NULL':$b['T0_fld_color1_zztests']).'" to "'.(is_null($a['T0_fld_color1_zztests'])?'NULL':$a['T0_fld_color1_zztests']).'"'.CRLF;
  }
  if($b['T0_fld_email1_zztests']!=$a['T0_fld_email1_zztests']){
   $t1.='fld_email1_zztests from "'.(is_null($b['T0_fld_email1_zztests'])?'NULL':$b['T0_fld_email1_zztests']).'" to "'.(is_null($a['T0_fld_email1_zztests'])?'NULL':$a['T0_fld_email1_zztests']).'"'.CRLF;
  }
  if($b['T0_fld_zipnum1_zztests']!=$a['T0_fld_zipnum1_zztests']){
   $t1.='fld_zipnum1_zztests from "'.$b['T0_fld_zipnum1_zztests'].'" to "'.$a['T0_fld_zipnum1_zztests'].'"'.CRLF;
  }
  if($_SESSION[PGMK]['login'] != $_SESSION[PGMK]['loginInit']){
   $t1.=CRLF.'========='.CRLF.'loginInit('.$_SESSION[PGMK]['loginInit'].') != login('.$_SESSION[PGMK]['login'].')'.CRLF.'========='.CRLF;
  }
  return '/*'.CRLF.'UPDATE list of differences'.CRLF.CRLF.$t1.CRLF.'*/'.CRLF;
 }
}
//======================================================================
function get_tdo_zztests_rebuild_insert1($f){
 $t1='// DELETE FROM `tdo_tbl__zztests` OK, the insert would be : '.CRLF;
 $t1.='$sql[]=<'.'<'.'<EOT'.CRLF;
 $t1.='INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` SET'.CRLF;
 $t1.='   `fld_id_zztests` = \''.addslashes($f['T0_fld_id_zztests']) . '\' '.CRLF;
 $t1.=' , `fld_yorno1_zztests` = \''.addslashes($f['T0_fld_yorno1_zztests']) . '\' '.CRLF;
 $t1.=' , `fld_visited_countries_zztests` = \''.addslashes($f['T0_fld_visited_countries_zztests']) . '\' '.CRLF;
 $t1.=' , `fld_country1_zztests` = \''.addslashes($f['T0_fld_country1_zztests']) . '\' '.CRLF;
 $t1.=' , `fld_title32_zztests` = \''.addslashes($f['T0_fld_title32_zztests']) . '\' '.CRLF;
 $t1.=' , `fld_id_parent_zztests` = '.(is_null($f['T0_fld_id_parent_zztests'])?'NULL':'\''.addslashes($f['T0_fld_id_parent_zztests']).'\'') . ' '.CRLF;
 $t1.=' , `fld_order_in_parent_zztests` = \''.addslashes($f['T0_fld_order_in_parent_zztests']) . '\' '.CRLF;
 $t1.=' , `fld_date1_zztests` = '.(is_null($f['T0_fld_date1_zztests'])?'NULL':'\''.addslashes($f['T0_fld_date1_zztests']).'\'') . ' '.CRLF;
 $t1.=' , `fld_time1_zztests` = '.(is_null($f['T0_fld_time1_zztests'])?'NULL':'\''.addslashes($f['T0_fld_time1_zztests']).'\'') . ' '.CRLF;
 $t1.=' , `fld_dttim1_zztests` = '.(is_null($f['T0_fld_dttim1_zztests'])?'NULL':'\''.addslashes($f['T0_fld_dttim1_zztests']).'\'') . ' '.CRLF;
 $t1.=' , `fld_color1_zztests` = '.(is_null($f['T0_fld_color1_zztests'])?'NULL':'\''.addslashes($f['T0_fld_color1_zztests']).'\'') . ' '.CRLF;
 $t1.=' , `fld_email1_zztests` = '.(is_null($f['T0_fld_email1_zztests'])?'NULL':'\''.addslashes($f['T0_fld_email1_zztests']).'\'') . ' '.CRLF;
 $t1.=' , `fld_zipnum1_zztests` = \''.addslashes($f['T0_fld_zipnum1_zztests']) . '\' '.CRLF;
 $t1.=' , `fld_tsupd_zztests` = \''.addslashes($f['T0_fld_tsupd_zztests']) . '\' '.CRLF;
 $t1.=' , `fld_tscrt_zztests` = \''.addslashes($f['T0_fld_tscrt_zztests']) . '\' '.CRLF;
 $t1.=' , `fld_cntupd_zztests` = \''.addslashes($f['T0_fld_cntupd_zztests']) . '\' '.CRLF;
 $t1.='EOT;'.CRLF;
 return $t1;
}
