<?php
$GLOBALS['param__restore_transform']=array (
  'param__Name__Display' => 'n',
  'param__Name__Sort' => 'n',
  'param__Name__key' => 'restore_transform',
  'param__Key__type' => 'char',
  '__values' => 
  array (
    'fr' => 
    array (
      'ISO-8859-15|UTF-8' => 
      array (
        'restore_transform' => 'ISO-8859-15|UTF-8',
        'n' => 'ISO-8859-15 -> UTF-8',
        'badge' => 'yybadge1',
        'rule' => 0,
        'fld_id_parvals' => '67',
        '__order' => 0,
      ),
    ),
    'en' => 
    array (
      'ISO-8859-15|UTF-8' => 
      array (
        'restore_transform' => 'ISO-8859-15|UTF-8',
        'n' => 'ISO-8859-15 -> UTF-8',
        'badge' => 'yybadge1',
        'rule' => 0,
        'fld_id_parvals' => '67',
        '__order' => 0,
      ),
    ),
  ),
  'param__definition' => 
  array (
    'comment' => 'encoding transform for restore',
    'key' => 'restore_transform',
    'fields' => 
    array (
      0 => 
      array (
        'name' => 'restore_transform',
        'type' => 'char',
        'length' => 32,
        'comment' => '8859-15|UTF-8,8859-1|UTF-8,',
      ),
      1 => 
      array (
        'name' => 'n',
        'type' => 'char',
        'length' => 64,
        'languageTranslation' => true,
        'comment1' => 'the transform name',
      ),
    ),
    'dependencies' => 
    array (
      0 => 
      array (
        'id_db' => 0,
        'table' => 'tdo_tbl__tables',
        'field' => 'fld_restore_transform_tables',
      ),
    ),
    'id' => '6',
  ),
);