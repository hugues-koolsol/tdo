<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
require_once($GLOBALS['glob_incPath1'].'/__param_group_category.php');
require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');

checkGroupPages();
openDb1();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_name_groups
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_parent_id_groups
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// parent_name
$xsrch_3=saveSessionSearch1('xsrch_3',BNF);// fld_isactive_groups
$xsrch_4=saveSessionSearch1('xsrch_4',BNF);// fld_category_groups
$xsrch_5=saveSessionSearch1('xsrch_5',BNF);// fld_root_group_id_groups
$xsrch_6=saveSessionSearch1('xsrch_6',BNF);// fld_name_groups of parent table
$xsrch_7=saveSessionSearch1('xsrch_7',BNF);// fld_crtLocAdm_groups
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_groups
if($xsrch_1!=''){
 if(!is_numeric($xsrch_1)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_24_92') . ' : ' . txt2('fld_parent_id_groups_24_152');
 }
}
if($xsrch_5!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_5);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if(!$listIdsOk){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_must_fill_a_numeric_value_for_the_field') . ' : ' . txt2('fld_root_group_id_groups_45_157');
 }
}

if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if(!$listIdsOk){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_must_fill_a_numeric_value_for_the_field') . ' : ' . txt2('fld_id_groups_60_157');
 }
}

$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; }
else if($xsrch_1!=''){ $autofocus='xsrch_1'; }
else if($xsrch_2!=''){ $autofocus='xsrch_2'; }
else if($xsrch_3!=''){ $autofocus='xsrch_3'; } // fld_isactive_groups
else if($xsrch_4!=''){ $autofocus='xsrch_4'; } // fld_category_groups
else if($xsrch_5!=''){ $autofocus='xsrch_5'; } // fld_root_group_id_groups link to parent table
else if($xsrch_6!=''){ $autofocus='xsrch_6'; } // fld_name_groups of parent table
else if($xsrch_7!=''){ $autofocus='xsrch_7'; } // fld_crtLocAdm_groups
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array());
$o1.='<h1>'.txt2('page_title_list_38_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="yyfilterForm">'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_name_groups_45_62').'</label>'.CRLF; // fld_name_groups
$o1.='    <input class="';
if($xsrch_0!=''){$o1.=' yybackgroundYellow';}
$o1.=     '" type="text" name="xsrch_0"    id="xsrch_0"   value="'.enti1($xsrch_0).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

if($_SESSION[PGMK]['group']==1){

 $o1.='   <div>'.CRLF;
 $o1.='    <label for="xsrch_1">'.txt2('fld_parent_id_groups_24_152').'</label>'.CRLF; // fld_parent_id_groups
 $o1.='    <input class="';
 if($xsrch_1!=''){$o1.=' yybackgroundYellow';}
 $o1.=     '" type="text" name="xsrch_1"    id="xsrch_1"   value="'.enti1($xsrch_1).'"  size="8" maxlength="32"';
 $o1.=' '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' />'.CRLF;
 $o1.='   </div>'.CRLF;


 $o1.='   <div>'.CRLF;
 $o1.='    <label for="xsrch_2">'.txt2('fld_parent_group_neme_63_62').'</label>'.CRLF;
 $o1.='    <input class="';
 if($xsrch_2!=''){$o1.=' yybackgroundYellow';}
 $o1.=     '" type="text" name="xsrch_2"    id="xsrch_2"   value="'.enti1($xsrch_2).'"  size="8" maxlength="32"';
 $o1.=' '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' />'.CRLF;
 $o1.='   </div>'.CRLF;
}

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_4">'.txt2('fld_category_groups_79_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_4!=''?'class="yybackgroundYellow"':'').' name="xsrch_4"  id="xsrch_4" '.($autofocus=='xsrch_4'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='<option value="" '.($xsrch_4==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__group_category']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_4){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__group_category']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__group_category']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_3">'.txt2('fld_isactive_groups_83_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_3!=''?'class="yybackgroundYellow"':'').' name="xsrch_3"  id="xsrch_3" '.($autofocus=='xsrch_3'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='<option value="" '.($xsrch_3==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_3){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_7">'.txt2('fld_crtLocAdm_groups_138_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_7!=''?'class="yybackgroundYellow"':'').' name="xsrch_7"  id="xsrch_7" '.($autofocus=='xsrch_7'?'autofocus="autofocus"':'').' onchange="submitListFromSelect1(this)" >'.CRLF;
$o1.='<option value="" '.($xsrch_7==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_7){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_5">'.txt2('fld_root_group_id_groups_45_157').'</label>'.CRLF; // fld_root_group_id_groups
$o1.='    <input '.($xsrch_5!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_5" id="xsrch_5"   value="'.enti1($xsrch_5).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_5'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

// field fld_name_groups of parent table

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_6">'.txt2('T2.fld_name_groups_152_39').'</label>'.CRLF; // fld_name_groups
$o1.='    <input '.($xsrch_6!=''?'class="yybackgroundYellow"':'').' type="text" name="xsrch_6" id="xsrch_6"   value="'.enti1($xsrch_6).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_6'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_groups_29_152').'</label>'.CRLF; // fld_id_groups
$o1.='    <input class="';
if($xsrch_id!=''){$o1.=' yybackgroundYellow';}
$o1.=     '" type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32"';
$o1.=' '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_groups`        ,T0.`fld_name_groups`      ,T0.`fld_parent_id_groups` ,T1.`fld_name_groups` , T0.`fld_isactive_groups` ,
   T0.`fld_category_groups`  ,T0.`fld_root_group_id_groups`  ,T2.`fld_name_groups` ,T0.`fld_crtLocAdm_groups` 
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T0 , 
      `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T1 ,
      `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__groups` T2 
 WHERE T0.`fld_parent_id_groups`     = T1.`fld_id_groups`
   AND T0.`fld_root_group_id_groups` = T2.`fld_id_groups`
';

if($_SESSION[PGMK]['groupInit']!=1){
 $req6.='
  AND ( T0.`fld_parent_id_groups` ='.$_SESSION[PGMK]['group'].' OR T0.`fld_root_group_id_groups` = '.$_SESSION[PGMK]['group'].' )
  AND ( T0.`fld_id_groups`        <> '.$_SESSION[PGMK]['group'].' )
 '; 
//   AND T0.`fld_id_groups`        <> T0.`fld_parent_id_groups`
 
}
if($xsrch_0!='' ){
 $req6.='
  AND T0.`fld_name_groups` LIKE \'%'.$xsrch_0.'%\'
 '; 
}
if($xsrch_1!='' && is_numeric($xsrch_1)){
 $req6.='
  AND T0.`fld_parent_id_groups` = '.$xsrch_1.'
 '; 
}
if($xsrch_2!='' ){
 $req6.='
  AND T1.`fld_name_groups` LIKE \'%'.addslashes($xsrch_2).'%\'
 '; 
}
if($xsrch_3!='' && is_numeric($xsrch_3)){
 $req6.='
  AND T0.`fld_isactive_groups` = '.$xsrch_3.'
 '; 
}
if($xsrch_4!='' ){
 $req6.='
  AND T0.`fld_category_groups` LIKE \'%'.addslashes1($xsrch_4).'%\'
 '; 
}
if($xsrch_5!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_5);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if($listIdsOk){
  $req6.='
   AND T0.`fld_root_group_id_groups` IN ('.implode(',',$xsrch_ids).') 
  '; 
 }
}
// field fld_name_groups of parent table
if($xsrch_6!='' ){
 $req6.='
  AND T2.`fld_name_groups` LIKE \'%'.addslashes1($xsrch_6).'%\'
 '; 
}
if($xsrch_7!='' ){
 $req6.='
  AND T0.`fld_crtLocAdm_groups` = '.$xsrch_7.' 
 '; 
}
if($xsrch_id!=''){
 $xsrch_ids=str_replace('.',',',$xsrch_id);
 $xsrch_ids=explode(',',$xsrch_ids);
 $listIdsOk=true;
 foreach($xsrch_ids as $v1){
  if(!is_numeric($v1)){
   $listIdsOk=false;
   break;
  }
 }
 if($listIdsOk){
  $req6.='
   AND T0.`fld_id_groups` IN ('.implode(',',$xsrch_ids).') 
  '; 
 }
}

$req6.='
 ORDER BY T0.`fld_id_groups` DESC 
'; 
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 $reqCount6='SELECT FOUND_ROWS();';
 $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $mpsrcount6=mysqli_fetch_row($rescount6);
  $__count=$mpsrcount6[0];
 }
 $lsttbl='';
 if($__count==0){
  $lst.='<p>'.CRLF;
  $lst.=''.txt2('no_record_founded_134_17').''.CRLF;
  $lst.='<a href="zz_groups_action1.php?a=c">'.txt2('add_a_new_record_135_94').'</a>'.CRLF;
  $lst.='</p>'.CRLF;
  $o1.=''.$lst.''.CRLF;  
 }else{
  $consUrlRedir=''.
                '&amp;xsrch_0='.rawurlencode($xsrch_0). // fld_name_groups 
                '&amp;xsrch_1='.rawurlencode($xsrch_1). // fld_parent_id_groups 
                '&amp;xsrch_2='.rawurlencode($xsrch_2). // T1.`fld_name_groups`  
                '&amp;xsrch_3='.rawurlencode($xsrch_3). // fld_isactive_groups 
                ($xsrch_4!=''?'&amp;xsrch_4='.rawurlencode($xsrch_4):''). // fld_category_groups 
                ($xsrch_5!=''?'&amp;xsrch_5='.rawurlencode($xsrch_5):''). // fld_root_group_id_groups 
                ($xsrch_6!=''?'&amp;xsrch_6='.rawurlencode($xsrch_6):''). // fld_name_groups of parent
                ($xsrch_7!=''?'&amp;xsrch_7='.rawurlencode($xsrch_7):''). // fld_crtLocAdm_groups 
                '&amp;xsrch_id='.rawurlencode($xsrch_id).
                '';
  $ri=' <span class="yybtn yyunset">&raquo;</span>';
  if($__start+$__nbMax<$__count){
   $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
  }
  $le=' <span class="yybtn yyunset">&laquo;</span>';
  if($__xpage>0){
   $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
  }
  $o1.='<div>';
  $o1.='<form method="post" class="yylistForm1">';
  $o1.='<a href="zz_groups_action1.php?a=c">'.txt2('add_a_new_record_135_94').'</a>'.CRLF;
  $o1.=' '.$le.$ri.''.CRLF;  
  $o1.=' <div style="display:inline-block;"> page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_250_99').' )</div>';
  $o1.='</form>';
  $o1.='</div>';

  $o1.=getCss1(890);

  $lsttbl.='<thead><tr>';
  $lsttbl.='<th>'.txtsys1('column_action').'</th>';
  $lsttbl.='<th>'.txt2('fld_id_groups_29_152').'</th>';
  $lsttbl.='<th>'.txt2('fld_name_groups_45_62').'</th>';
  if($_SESSION[PGMK]['group']==1){  
   $lsttbl.='<th>'.txt2('parent_name_214_24').'</th>';
   $lsttbl.='<th>'.txt2('fld_parent_id_groups_24_152').'</th>';
  }  
  $lsttbl.='<th>'.txt2('fld_isactive_groups_83_39').'</th>';  
  $lsttbl.='<th>'.txt2('fld_crtLocAdm_groups_138_39').'</th>';
  
  $lsttbl.='<th>'.txt2('fld_category_groups_79_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_root_group_id_groups_45_157').'</th>';
  $lsttbl.='<th>'.txt2('T2.fld_name_groups_152_39').'</th>'; // ======== parent field of fld_root_group_id_groups
  $lsttbl.='</tr></thead><tbody>';
  while($mpsr6=mysqli_fetch_row($result6)){
   
   $lsttbl.='<tr>';

   $lsttbl.='<td style="min-width:90px;text-align:left;">';
   $lsttbl.='<div class="yyflex1">';
   $showDelete=true;
   $showEdit=true;
   if($_SESSION[PGMK]['loginInit']!=1){
    if($_SESSION[PGMK]['loginInit']==$mpsr6[0]){
     $showDelete=false;
     $showEdit=false;
    }
   }
   if($mpsr6[0]==1 || $mpsr6[0]==2 || $mpsr6[0]==3 || $mpsr6[0]==4 ){
    $showDelete=false;
   }
   
   if($showDelete==true){
    $lsttbl.='<a class="yytxtSiz1 yydanger" href="zz_groups_action1.php?a=d&amp;id='.$mpsr6[0].'" title="'.txtsys1('delete_button').'">&#10008;</a>';
   }else{
    $lsttbl.='<span class="yytxtSiz1 yydanger yybtn yyunset" title="'.txtsys1('delete_button').'">&#10008;</span>';
   }
   if($showEdit==true){
    $lsttbl.='<a class="yytxtSiz1 yyedit" href="zz_groups_action1.php?a=u&amp;id='.$mpsr6[0].'" title="'.txtsys1('edit_button').'">&#9998;</a>';
   }
   $lsttbl.='</div>';
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_id_groups_29_152').'">';
   $lsttbl.=''.enti1($mpsr6[0]).''; // fld_id_groups
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_name_groups_45_62').'">';
   $lsttbl.=''.enti1($mpsr6[1]).''; // fld_name_groups
   $lsttbl.='</td>';
   
   if($_SESSION[PGMK]['group']==1){  

    $lsttbl.='<td data-label="'.txt2('parent_name_214_24').'" style="text-align:center;">';
    $lsttbl.=''.enti1($mpsr6[3]).''; // parent_name
    $lsttbl.='</td>';   
    
    $lsttbl.='<td data-label="'.txt2('fld_parent_id_groups_24_152').'" style="text-align:center;">';
    $lsttbl.=''.enti1($mpsr6[2]).''; // fld_parent_id_groups
    $lsttbl.='</td>';
    
   }

   $lsttbl.='<td data-label="'.txt2('fld_isactive_groups_83_39').'" style="text-align:center;">';
   $lsttbl.=displayParam1('yorno',$mpsr6[4]); // fld_isactive_groups
   $lsttbl.='</td>';
   
   $lsttbl.='<td data-label="'.txt2('fld_crtLocAdm_groups_138_39').'" style="text-align:center;">';
   $lsttbl.=displayParam1('yorno',$mpsr6[8],array('unsetPossible'=>false)); // fld_crtLocAdm_groups
   $lsttbl.='</td>';


   
   

   $lsttbl.='<td data-label="'.txt2('fld_category_groups_79_39').'" style="text-align:center;">';
   $lsttbl.=displayParam1('group_category',$mpsr6[5],array('unsetPossible'=>false)); // fld_category_groups
   $lsttbl.='</td>';


   
   $lsttbl.='<td data-label="'.txt2('fld_root_group_id_groups_45_157').'" style="text-align:center;">';
   $lsttbl.=''.enti1($mpsr6[6]).''; // fld_root_group_id_groups
   $lsttbl.='</td>';


   $lsttbl.='<td data-label="'.txt2('T2.fld_name_groups_152_39').'" style="text-align:center;">';
   $lsttbl.=''.enti1($mpsr6[7]).''; // fld_name_groups
   $lsttbl.='</td>';

   
   
   $lsttbl.='<td class="yyfictif"></td></tr>';
   
  }
  $o1.='<table class="yytableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;
   
  $o1.=' <div class="yylistForm1">'.CRLF;
  $o1.='  <a href="zz_groups_action1.php?a=c">'.txt2('add_a_new_record_135_94').'</a>'.CRLF; // todo adjust 
  $o1.='   '.$le.' '.$ri.'<div style="display:inline-block;"> page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_250_99').' )</div>'.CRLF;
  $o1.=' </div>'.CRLF;
   
 }
 mysqli_free_result($result6);
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
}
$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
