<?php
// group 1 : root,m:menu,o:order,aj:ajax
$GLOBALS['glob_grpspgs']=array (
  'ajax_updTranslateSys1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 34,
    'remote' => 1,
  ),
  'ajax_translateMenu2.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 36,
    'remote' => 1,
  ),
  'ajax_setSortPagesOfGroup1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 26,
    'remote' => 1,
  ),
  'ajax_setSortParamWithLang1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 27,
    'remote' => 1,
  ),
  'ajax_writeTranslationFiles1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 28,
    'remote' => 1,
  ),
  'ajax_setSortParamWithoutLang1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 29,
    'remote' => 1,
  ),
  'ajax_getPageToTranslate1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 30,
    'remote' => 1,
  ),
  'ajax_addTranslationJs1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 31,
    'remote' => 1,
  ),
  'ajax_addTranslateSys1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 33,
    'remote' => 1,
  ),
  'ajax_translateMenu1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 35,
    'remote' => 1,
  ),
  'uploadeddocs_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 66,
    'remote' => 1,
  ),
  'zz_zztests_choose1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 42,
    'remote' => 0,
  ),
  'ajax_uploaddocs1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 67,
    'remote' => 1,
  ),
  'zz_paramnames_choose1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 69,
    'remote' => 1,
  ),
  'zz_paramrules_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 70,
    'remote' => 0,
  ),
  'ajax_writeGeneratedFile1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 71,
    'remote' => 0,
  ),
  'ajax_writeGeneratedFile2.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 72,
    'remote' => 0,
  ),
  'ajax_fileNameChangeInGen1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 74,
    'remote' => 0,
  ),
  'ajax_insertThisPageInPagesAndGroup1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 75,
    'remote' => 0,
  ),
  'ajax_checkNullFieldInLinksBetweenTables1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 76,
    'remote' => 0,
  ),
  'ajax_translatePage2.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 25,
    'remote' => 1,
  ),
  'ajax_translateJs1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 32,
    'remote' => 1,
  ),
  'zz_tablelinks_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 22,
    'remote' => 0,
  ),
  'ajax_updateParam1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 40,
    'remote' => 1,
  ),
  'ajax_translatePageElement1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 89,
    'remote' => 1,
  ),
  'zz_pages_choose1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 51,
    'remote' => 0,
  ),
  'zz_css_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 50,
    'remote' => 1,
  ),
  'zz_groups_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 5,
    'remote' => 1,
  ),
  'zz_groups_choose1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 6,
    'remote' => 1,
  ),
  'zz_todos1.php' => 
  array (
    'm' => 1,
    'o' => 0,
    'aj' => 0,
    'id' => 13,
    'remote' => 1,
  ),
  'zz_users_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 8,
    'remote' => 1,
  ),
  'ajax_translateText1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 37,
    'remote' => 1,
  ),
  'zz_pages_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 7,
    'remote' => 0,
  ),
  'zz_tables_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 48,
    'remote' => 0,
  ),
  'zz_todos2.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 84,
    'remote' => 1,
  ),
  'zz_pages2.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 87,
    'remote' => 0,
  ),
  'ajax_deleteFromServer1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 46,
    'remote' => 0,
  ),
  'ajax_sendLocalFilesToServer2.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 45,
    'remote' => 0,
  ),
  'zz_paramkeys_action1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 18,
    'remote' => 1,
  ),
  'zz_paramvalues1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 0,
    'id' => 19,
    'remote' => 1,
  ),
  'ajax_sendLocalFilesToServer1.php' => 
  array (
    'm' => 0,
    'o' => 0,
    'aj' => 1,
    'id' => 44,
    'remote' => 0,
  ),
  'zz_tables1.php' => 
  array (
    'm' => 1,
    'o' => 1,
    'aj' => 0,
    'id' => 47,
    'remote' => 0,
  ),
  'zz_zztests_action1.php' => 
  array (
    'm' => 0,
    'o' => 1,
    'aj' => 0,
    'id' => 83,
    'remote' => 0,
  ),
  'zz_tablelinks1.php' => 
  array (
    'm' => 1,
    'o' => 2,
    'aj' => 0,
    'id' => 20,
    'remote' => 0,
  ),
  'zz_log_action1.php' => 
  array (
    'm' => 0,
    'o' => 2,
    'aj' => 0,
    'id' => 82,
    'remote' => 1,
  ),
  'zz_generateSources1.php' => 
  array (
    'm' => 1,
    'o' => 3,
    'aj' => 0,
    'id' => 21,
    'remote' => 0,
  ),
  'zz_pages.php' => 
  array (
    'm' => 1,
    'o' => 4,
    'aj' => 0,
    'id' => 9,
    'remote' => 0,
  ),
  'zz_tables_choose1.php' => 
  array (
    'm' => 0,
    'o' => 4,
    'aj' => 0,
    'id' => 80,
    'remote' => 0,
  ),
  'zz_users_choose1.php' => 
  array (
    'm' => 0,
    'o' => 5,
    'aj' => 0,
    'id' => 79,
    'remote' => 1,
  ),
  'zz_groups1.php' => 
  array (
    'm' => 1,
    'o' => 5,
    'aj' => 0,
    'id' => 4,
    'remote' => 1,
  ),
  'zz_grpspgs.php' => 
  array (
    'm' => 1,
    'o' => 6,
    'aj' => 0,
    'id' => 10,
    'remote' => 1,
  ),
  'zz_paramkeys.php' => 
  array (
    'm' => 1,
    'o' => 7,
    'aj' => 0,
    'id' => 17,
    'remote' => 1,
  ),
  'zz_todos_action1.php' => 
  array (
    'm' => 0,
    'o' => 7,
    'aj' => 0,
    'id' => 14,
    'remote' => 1,
  ),
  'zz_translate.php' => 
  array (
    'm' => 1,
    'o' => 8,
    'aj' => 0,
    'id' => 16,
    'remote' => 1,
  ),
  'zz_users.php' => 
  array (
    'm' => 1,
    'o' => 9,
    'aj' => 0,
    'id' => 12,
    'remote' => 1,
  ),
  'zz_paramrules1.php' => 
  array (
    'm' => 1,
    'o' => 10,
    'aj' => 0,
    'id' => 68,
    'remote' => 0,
  ),
  'zz_log1.php' => 
  array (
    'm' => 1,
    'o' => 11,
    'aj' => 0,
    'id' => 81,
    'remote' => 1,
  ),
  'zz_css1.php' => 
  array (
    'm' => 1,
    'o' => 12,
    'aj' => 0,
    'id' => 49,
    'remote' => 1,
  ),
  'uploadeddocs1.php' => 
  array (
    'm' => 1,
    'o' => 13,
    'aj' => 0,
    'id' => 65,
    'remote' => 1,
  ),
  'zz_zztests1.php' => 
  array (
    'm' => 1,
    'o' => 14,
    'aj' => 0,
    'id' => 23,
    'remote' => 0,
  ),
  'zz_synchro1.php' => 
  array (
    'm' => 1,
    'o' => 15,
    'aj' => 0,
    'id' => 43,
    'remote' => 0,
  ),
  'zz_restore1.php' => 
  array (
    'm' => 1,
    'o' => 16,
    'aj' => 0,
    'id' => 86,
    'remote' => 0,
  ),
  'login.php' => 
  array (
    'm' => 1,
    'o' => 17,
    'aj' => 0,
    'id' => 2,
    'remote' => 1,
  ),
  'zz_design.php' => 
  array (
    'm' => 1,
    'o' => 18,
    'aj' => 0,
    'id' => 91,
    'remote' => 0,
  ),
  'profile.php' => 
  array (
    'm' => 1,
    'o' => 19,
    'aj' => 0,
    'id' => 41,
    'remote' => 1,
  ),
  'index.php' => 
  array (
    'm' => 1,
    'o' => 20,
    'aj' => 0,
    'id' => 1,
    'remote' => 1,
  ),
  'logout.php' => 
  array (
    'm' => 0,
    'o' => 998,
    'aj' => 0,
    'id' => 3,
    'remote' => 1,
  ),
);