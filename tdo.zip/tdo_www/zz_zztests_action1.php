<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
require_once $GLOBALS['glob_incPath1'].'/zztests1.php';

openDb2();
//========================================================================================================================
function btl1(){
 return ' <a href="zz_zztests1.php" class="">'.txtsys1('back_to_the_list').'</a>';
}
//========================================================================================================================
function test_input_tdo_zztestsKO1(){
 $err=0;
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_title32_zztests']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_title32_zztests must not be empty_17_92');
  $err=1;
 }
 return($err);
}
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= POST ACTIONS  =====================================================================
 //=================================================================================================================================
 //=================================================================================================================================
// echo __LINE__ . '$_POST=<pre>' . var_export($_POST,true) . '</pre>'; exit();
 $_SESSION[PGMK][NAV][BNF]['fld_yorno1_zztests']            =isset($_POST['fld_yorno1_zztests'])            ?$_POST['fld_yorno1_zztests']            : '';
 if(isset($_POST['fld_visited_countries_zztests']) ){
  $_SESSION[PGMK][NAV][BNF]['fld_visited_countries_zztests']= implode(',',$_POST['fld_visited_countries_zztests']);
 }else{
  $_SESSION[PGMK][NAV][BNF]['fld_visited_countries_zztests']='';
 }
 $_SESSION[PGMK][NAV][BNF]['fld_country1_zztests']          =isset($_POST['fld_country1_zztests'])          ?$_POST['fld_country1_zztests']          : '';
 $_SESSION[PGMK][NAV][BNF]['fld_title32_zztests']           =isset($_POST['fld_title32_zztests'])           ?$_POST['fld_title32_zztests']           : '';
 $_SESSION[PGMK][NAV][BNF]['fld_id_parent_zztests']         =isset($_POST['fld_id_parent_zztests'])         ?$_POST['fld_id_parent_zztests']         : ''; // null possible
 $_SESSION[PGMK][NAV][BNF]['fld_date1_zztests']             =isset($_POST['fld_date1_zztests'])             ?$_POST['fld_date1_zztests']             : ''; // null possible
 $_SESSION[PGMK][NAV][BNF]['fld_time1_zztests']             =isset($_POST['fld_time1_zztests'])             ?$_POST['fld_time1_zztests']             : ''; // null possible
 $_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests']            =isset($_POST['fld_dttim1_zztests'])            ?$_POST['fld_dttim1_zztests']            : ''; // null possible
 $_SESSION[PGMK][NAV][BNF]['fld_color1_zztests']            =isset($_POST['fld_color1_zztests'])            ?$_POST['fld_color1_zztests']            : ''; // null possible

 // dependant field 
 if(!(isset($_POST['a'])&&($_POST['a']=='cd'||$_POST['a']=='cd'))){ // NOT confirm delete
  $_SESSION[PGMK][NAV][BNF]['choose__fld_id_parent_zztests'] =isset($_POST['choose__fld_id_parent_zztests'] )?$_POST['choose__fld_id_parent_zztests']  :'';
  if($_SESSION[PGMK][NAV][BNF]['choose__fld_id_parent_zztests']==txtsys1('text_for_the_select_button')){
   $_SESSION[PGMK]['choose']['urlBack']=$_SERVER['HTTP_ORIGIN'].$_SERVER['REQUEST_URI'];
   header('Location: zz_zztests_choose1.php'); // todo check 
   exit();
  }
 }

 if($_SESSION[PGMK][NAV][BNF]['fld_date1_zztests']=='' || $_SESSION[PGMK][NAV][BNF]['fld_date1_zztests']=='NULL' ){$_SESSION[PGMK][NAV][BNF]['fld_date1_zztests']=NULL;} // fld_date1_zztests can be NULL

 if($_SESSION[PGMK][NAV][BNF]['fld_time1_zztests']=='' || $_SESSION[PGMK][NAV][BNF]['fld_time1_zztests']=='NULL' ){$_SESSION[PGMK][NAV][BNF]['fld_time1_zztests']=NULL;} // fld_time1_zztests can be NULL

 if($_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests']=='' || $_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests']=='NULL' ){$_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests']=NULL;} // fld_dttim1_zztests can be NULL

 if($_SESSION[PGMK][NAV][BNF]['fld_color1_zztests']==''){$_SESSION[PGMK][NAV][BNF]['fld_color1_zztests']=NULL;} // fld_color1_zztests can be NULL

 //=================================================================================================================================
 //============================================= POST UPDATE =======================================================================
 //=================================================================================================================================
 if(isset($_POST['a'])&&$_POST['a']=='u'){ // update action
  if(test_input_tdo_zztestsKO1()){
   if(isset($_POST['id1'])&&is_numeric($_POST['id1'])){
    header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }else{
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : POST id1 = ' . $_POST['id1'];
    header('Location: index.php');
    exit();
   }
  }
  $req6="UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__zztests` SET
      `fld_yorno1_zztests`            = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_yorno1_zztests'])            ."'
    , `fld_visited_countries_zztests` = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_visited_countries_zztests']) ."'
    , `fld_country1_zztests`          = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_country1_zztests'])          ."'
    , `fld_title32_zztests`           = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_title32_zztests'])           ."'
    , `fld_id_parent_zztests`         = ".($_SESSION[PGMK][NAV][BNF]['fld_id_parent_zztests']==''?'NULL':addslashes($_SESSION[PGMK][NAV][BNF]['fld_id_parent_zztests']))."
    , `fld_date1_zztests`             =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_date1_zztests'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_date1_zztests'])."'")."
    , `fld_time1_zztests`             =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_time1_zztests'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_time1_zztests'])."'")."
    , `fld_dttim1_zztests`            =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests'])."'")."
    , `fld_color1_zztests`            =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_color1_zztests'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_color1_zztests'])."'")."
    , `fld_tsupd_zztests`             = '".addslashes($GLOBALS['glob_setdate'])                                   ."'
    , `fld_cntupd_zztests`            =  " . ((int)$_POST['fld_cntupd_zztests']+1)                                ."
  ";
  $req6.="
   WHERE `fld_id_zztests`=".$_POST['id1']."
     AND `fld_cntupd_zztests` = ".$_POST['fld_cntupd_zztests']."
  ";
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
     break;
    default   :
     $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 2 );
    break;
   }
   header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
  }else{
   if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])!=1){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('this_record_has_not_been_updated_because_of_an_other_user');
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('please_retry');
    unset($_SESSION[PGMK][NAV][BNF]['fld_yorno1_zztests']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_visited_countries_zztests']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_country1_zztests']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_title32_zztests']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_id_parent_zztests']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_date1_zztests']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_time1_zztests']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_color1_zztests']);
    header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
   }
   
   sqllog1( $req6 , BNF , __LINE__ );
   $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('the_modification_has_been_recorded_at') . ' ' . substr($GLOBALS['glob_setdate'],11);
   header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CONFIRM DELETE ===============================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='cd'){
 
  require_once $GLOBALS['glob_dataPath1'].'/generated/__tableDependencies1.php';
  $retDependantTables=dependentValuesExist1(0,'tdo_tbl__zztests','fld_id_zztests',$_POST['id1'] );
  if(true === $retDependantTables['valuesExist']){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' . txtsys1('you_cannot_delete_because_some_values_are_still_present_in_dependant_table') . ' ' . var_export( $retDependantTables['tables'] , true ) . ' ';
   header('Location: '.BNF.'?a=d&id='.$_POST['id1']);   
  }

//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__zztests` WHERE `fld_id_zztests`=".$_POST['id1']." " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
   txtlog1($xtxterr , BNF , __LINE__ , 2 );
   header('Location: '.BNF.'?a=d&id='.$_POST['id1']);
   exit();
  }else{
   sqllog1( $req6 , BNF , __LINE__ );
   unset($_SESSION[PGMK][NAV][BNF]);
   header('Location: zz_zztests1.php');
   exit();
  }
 //=================================================================================================================================
 //============================================= POST CREATE ACTION ================================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='c'){
  if(test_input_tdo_zztestsKO1()){
   header('Location: '.BNF.'?a=c');
   exit();
  }
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__zztests` SET
      `fld_yorno1_zztests`            = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_yorno1_zztests'])            ."'
    , `fld_visited_countries_zztests` = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_visited_countries_zztests']) ."'
    , `fld_country1_zztests`          = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_country1_zztests'])          ."'
    , `fld_title32_zztests`           = '".addslashes($_SESSION[PGMK][NAV][BNF]['fld_title32_zztests'])           ."'
    , `fld_id_parent_zztests`         = ".($_SESSION[PGMK][NAV][BNF]['fld_id_parent_zztests']==''?'NULL':addslashes($_SESSION[PGMK][NAV][BNF]['fld_id_parent_zztests']))."
    ,`fld_date1_zztests`             =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_date1_zztests'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_date1_zztests'])."'")."
    ,`fld_time1_zztests`             =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_time1_zztests'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_time1_zztests'])."'")."
    ,`fld_dttim1_zztests`            =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests'])."'")."
    ,`fld_color1_zztests`            =  ".(is_null($_SESSION[PGMK][NAV][BNF]['fld_color1_zztests'])?'NULL':"'".addslashes($_SESSION[PGMK][NAV][BNF]['fld_color1_zztests'])."'")."
    , `fld_tsupd_zztests`             = '".addslashes($GLOBALS['glob_setdate'])                                  ."'
    , `fld_tscrt_zztests`             = '".addslashes($GLOBALS['glob_setdate'])                                  ."'
  " ;
//  echo __FILE__ . ' ' . __LINE__ . ' $req6 =' . $req6 . '' ; exit();
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
    break;
    default;
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 2 );
    break;
   }
   header('Location: '.BNF.'?a=c');
   exit();
  }else{
   sqllog1( $req6 , BNF , __LINE__ );
   $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $xtxterr=txtsys1('error').' ' . __LINE__ . 'mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 2 );
    header('Location: '.BNF.'?a=c');
    exit();
   }else{
    $NewCode=mysqli_fetch_row($resIns);
    $NewCode=$NewCode[0];
    mysqli_free_result($resIns);
    SetSessionMessageAndLog1( txt2('the new value has been inserted_203_36') . ' ('.$NewCode.').' , BNF , __LINE__ , 3);
    header('Location: '.BNF.'?a=u&t=n&id='.$NewCode);
    exit();
   }
  }
 }
 
}else{ // get action

 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= GET ACTION ========================================================================
 //=================================================================================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='du'){ // duplicate action
  $xxxFldValues=array();
  $name2=getTdo_zztests1($_GET['id']);
  if($name2['fld_title32_zztests']==''){
   $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_duplicate_this_value');
   header('Location: zz_zztests1.php');
   exit();
  }else{
   $_SESSION[PGMK][NAV][BNF]['fld_yorno1_zztests']            =$name2['fld_yorno1_zztests'];
   $_SESSION[PGMK][NAV][BNF]['fld_visited_countries_zztests'] =$name2['fld_visited_countries_zztests'];
   $_SESSION[PGMK][NAV][BNF]['fld_country1_zztests']          =$name2['fld_country1_zztests'];
   $_SESSION[PGMK][NAV][BNF]['fld_title32_zztests']           =$name2['fld_title32_zztests'];
   $_SESSION[PGMK][NAV][BNF]['fld_id_parent_zztests']         =$name2['fld_id_parent_zztests'];
   $_SESSION[PGMK][NAV][BNF]['fld_date1_zztests']             =$name2['fld_date1_zztests'];
   $_SESSION[PGMK][NAV][BNF]['fld_time1_zztests']             =$name2['fld_time1_zztests'];
   $_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests']            =$name2['fld_dttim1_zztests'];
   $_SESSION[PGMK][NAV][BNF]['fld_color1_zztests']            =$name2['fld_color1_zztests'];
   header('Location: '.BNF.'?a=c' );
   exit();
  }
 }
 
 $o1=htmlHead1(array());
 $js1=array();
// echo __LINE__ . '$_SESSION[PGMK]=<pre>' . var_export( $_SESSION[PGMK] , true ) . '</pre>'; exit();
 //=================================================================================================================================
 //============================================= GET DELETE ========================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='d'){ // delete action
  $id=(isset($_GET['id'])&&is_numeric($_GET['id']))?$_GET['id']:0;
  if($id==0){
   header('Location: zz_zztests1.php');
   exit();
  }else{
   $xvalueName=getTdo_zztests1($_GET['id']);
//   echo __FILE__ . ' ' . __LINE__ . ' TODO at LINE = <pre>' . var_export( __LINE__ , true ) . '</pre>' ; exit(0); 
   if($xvalueName['fld_title32_zztests']==''){
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_delete_this_value');
    header('Location: zz_zztests1.php');
    exit();
   }else{
    require_once $GLOBALS['glob_dataPath1'].'/generated/__tableDependencies1.php';
    $retDependantTables=dependentValuesExist1(0,'tdo_tbl__zztests','fld_id_zztests',$_GET['id'] );
    if(isset($retDependantTables['valuesExist']) && $retDependantTables['valuesExist']==true){
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <div>'.CRLF;
     $o1.=' '.txtsys1('dependent_values_exist').''.CRLF;
     $o1.=' <ul>'.CRLF;
     foreach( $retDependantTables['tables'] as $k1 => $v1){
      $o1.='  <li>'.$v1.'</li>'.CRLF;
     }
     $o1.=' </ul>'.CRLF;
     $o1.=' </div>'.CRLF;
     $o1.=btl1();
    }else{
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <form method="post" class="formDelete">'.CRLF;
     $o1.='   '.txtsys1('please_confirm_deletion_of').' : '.CRLF;
     $o1.='   <br /><br /><b>'.$xvalueName['fld_title32_zztests'].'</b><br /><br />'.CRLF;
     $o1.='   <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
     $o1.='   <input type="hidden" value="cd" name="a" id="a" />'."\r\n";
     $o1.='   <button type="submit" class="danger">'.txtsys1('i_confirm_the_deletion_button').'</button>'.CRLF;
     $o1.=btl1();
     $o1.=' </form>'."\r\n";
    }
   }
  }
 //=================================================================================================================================
 //============================================= GET UPDATE ========================================================================
 //=================================================================================================================================
 
 }else if(isset($_GET['a'])&&$_GET['a']=='u'){ // update action
  $xxxFldValues=array();
  $js1=array();
  $o1.='<h4>'.txt2('update a record_291_20').' ('.$_GET['id'].')'.btl1().'</h4>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $name2=getTdo_zztests1($_GET['id']);
  $xxxFldValues['fld_yorno1_zztests']            =isset( $_SESSION[PGMK][NAV][BNF]['fld_yorno1_zztests'] )            ? $_SESSION[PGMK][NAV][BNF]['fld_yorno1_zztests']            : $name2['fld_yorno1_zztests']            ;
  $xxxFldValues['fld_visited_countries_zztests'] =isset( $_SESSION[PGMK][NAV][BNF]['fld_visited_countries_zztests'] ) ? $_SESSION[PGMK][NAV][BNF]['fld_visited_countries_zztests'] : $name2['fld_visited_countries_zztests'] ;
  $xxxFldValues['fld_country1_zztests']          =isset( $_SESSION[PGMK][NAV][BNF]['fld_country1_zztests'] )          ? $_SESSION[PGMK][NAV][BNF]['fld_country1_zztests']          : $name2['fld_country1_zztests']          ;
  $xxxFldValues['fld_title32_zztests']           =isset( $_SESSION[PGMK][NAV][BNF]['fld_title32_zztests'] )           ? $_SESSION[PGMK][NAV][BNF]['fld_title32_zztests']           : $name2['fld_title32_zztests']           ;
  $xxxFldValues['fld_id_parent_zztests']         =isset( $_SESSION[PGMK][NAV][BNF]['fld_id_parent_zztests'] )         ? $_SESSION[PGMK][NAV][BNF]['fld_id_parent_zztests']         : $name2['fld_id_parent_zztests']         ;
  $xxxFldValues['fld_date1_zztests']             =isset( $_SESSION[PGMK][NAV][BNF]['fld_date1_zztests'] )             ? $_SESSION[PGMK][NAV][BNF]['fld_date1_zztests']             : $name2['fld_date1_zztests']             ;
  $xxxFldValues['fld_time1_zztests']             =isset( $_SESSION[PGMK][NAV][BNF]['fld_time1_zztests'] )             ? $_SESSION[PGMK][NAV][BNF]['fld_time1_zztests']             : $name2['fld_time1_zztests']             ;
  $xxxFldValues['fld_dttim1_zztests']            =isset( $_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests'] )            ? $_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests']            : $name2['fld_dttim1_zztests']            ;
  $xxxFldValues['fld_color1_zztests']            =isset( $_SESSION[PGMK][NAV][BNF]['fld_color1_zztests'] )            ? $_SESSION[PGMK][NAV][BNF]['fld_color1_zztests']            : $name2['fld_color1_zztests']            ;


  $o1.='<form method="post" >'.CRLF;

  $o1.=' <input type="hidden" value="u" name="a" id="a" />'.CRLF;
  $o1.=' <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_yorno1_zztests_311_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
  $retParam=displayParam2('yorno',$xxxFldValues['fld_yorno1_zztests'],'fld_yorno1_zztests',array('unsetPossible'=>true,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_visited_countries_zztests_321_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/country.php');
  $retParam=displayParam2('country',$xxxFldValues['fld_visited_countries_zztests'],'fld_visited_countries_zztests',array('set'=>true));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_country1_zztests_331_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/country.php');
  $retParam=displayParam2('country',$xxxFldValues['fld_country1_zztests'],'fld_country1_zztests',array('unsetPossible'=>true,'dropDown'=>true));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_title32_zztests_340_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_title32_zztests']).'" name="fld_title32_zztests" id="fld_title32_zztests" maxlength="32" style="width:100%;max-width:34em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $xDisplayValueFetch = '' ;
  if(
   isset($_SESSION[PGMK][NAV][BNF]['choose__fld_id_parent_zztests'])&&
   $_SESSION[PGMK][NAV][BNF]['choose__fld_id_parent_zztests']==txtsys1('text_for_the_select_button')&&
   isset($_SESSION[PGMK]['choose']['valueBack'])&&
   $_SESSION[PGMK]['choose']['valueBack']!=0
  ){
   if($_SESSION[PGMK][NAV][BNF]['choose__fld_id_parent_zztests']==txtsys1('text_for_the_select_button')){
    $xxxFldValues['fld_id_parent_zztests']=$_SESSION[PGMK]['choose']['valueBack'];
   }
   unset($_SESSION[PGMK]['choose']);
  }
  if($xxxFldValues['fld_id_parent_zztests']!=''){
   $xGroupValues=getTdo_zztests1($xxxFldValues['fld_id_parent_zztests']);
   $xDisplayValueFetch = '' .  $xGroupValues['fld_title32_zztests']  . ' (' . $xGroupValues['fld_id_zztests'] . ')' . '' ;
  }else{
   $xDisplayValueFetch = '';    
  }
   
  $o1.='  <div class="fdiv1">'.CRLF;
  $o1.='   <div class="flab1"><div>'.txt2('parent_fld_id_parent_zztests_367_43').'</div></div>'.CRLF;
  $o1.='   <div class="finp1"><div>'.CRLF;
  $o1.='    <input type="hidden" value="'.enti1($xxxFldValues['fld_id_parent_zztests']).'" name="fld_id_parent_zztests" id="fld_id_parent_zztests" />'.CRLF;
  $o1.='     <span id="span__dep_fld_id_parent_zztests">'.$xDisplayValueFetch.'</span>';
  $o1.='    <button type="submit" name="choose__fld_id_parent_zztests" class="" value="'. txtsys1('text_for_the_select_button') . '">';
  $o1.=''   . txtsys1('text_for_the_select_button') . '';
  $o1.=     '</button>'."\r\n";
  $o1.='    <button type="button" class="warning" onclick="razDependant1(\'span__dep_fld_id_parent_zztests\',\'fld_id_parent_zztests\')">';
  $o1.=''   . txtsys1('raz_button') . '';
  $o1.=     '</button>'."\r\n";
  $o1.='   </div></div>'.CRLF;
  $o1.='  </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_date1_zztests_381_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  if($xxxFldValues['fld_date1_zztests']=='1000-01-01') $xxxFldValues['fld_date1_zztests']='';
  $o1.='    <input type="hidden" name="fld_date1_zztests"    id="fld_date1_zztests"   value="'.enti1($xxxFldValues['fld_date1_zztests']).'" />'.CRLF;
  $o1.='    <button type="button" style="padding:0px!important;font-size:0.8em;" id="button_date_fld_date1_zztests" onclick="javascript:setDate1(\'fld_date1_zztests\',\'button_date_fld_date1_zztests\',1,0)">';
  $o1.=(($xxxFldValues['fld_date1_zztests']=='1000-01-01' || $xxxFldValues['fld_date1_zztests']=='' )?txtsys1('date null'):($xxxFldValues['fld_date1_zztests']=='NULL'?txtsys1('date null'):($xxxFldValues['fld_date1_zztests']=='NOT NULL'?txtsys1('date not null'):$xxxFldValues['fld_date1_zztests'])));
  $o1.='</button>';
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_time1_zztests_392_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='    <input type="hidden" name="fld_time1_zztests"    id="fld_time1_zztests"   value="'.enti1($xxxFldValues['fld_time1_zztests']).'" />'.CRLF;
  $o1.='    <button type="button" id="button_time_fld_time1_zztests" style="border-style:outset;font-size:0.8em;padding:5px;width:auto;"  '.($xxxFldValues['fld_time1_zztests']=='00:00:00'?' class="success" ':($xxxFldValues['fld_time1_zztests']!=''?' class="edit" ':'')).' ';
  $o1.=' onclick="javascript:setTime1(\'fld_time1_zztests\',\'button_time_fld_time1_zztests\',1,0,\'\',0)">';
  $o1.=($xxxFldValues['fld_time1_zztests']==''?txtsys1('time null'):($xxxFldValues['fld_time1_zztests']=='NULL'?txtsys1('time null'):($xxxFldValues['fld_time1_zztests']=='NOT NULL'?txtsys1('time not null'):$xxxFldValues['fld_time1_zztests'])));
  $o1.='</button>';
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_dttim1_zztests_403_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='    <input type="hidden" name="fld_dttim1_zztests"    id="fld_dttim1_zztests"   value="'.enti1($xxxFldValues['fld_dttim1_zztests']).'" />'.CRLF;
  $o1.='    <button type="button" style="padding:0px!important;font-size:0.8em;" id="button_datetime_fld_dttim1_zztests" onclick="javascript:setDateTime1(\'fld_dttim1_zztests\',\'button_datetime_fld_dttim1_zztests\',1,0,\'\')" >';
  $o1.=($xxxFldValues['fld_dttim1_zztests']==''?txtsys1('datetime null'):($xxxFldValues['fld_dttim1_zztests']=='NULL'?txtsys1('datetime null'):($xxxFldValues['fld_dttim1_zztests']=='NOT NULL'?txtsys1('datetime not null'):$xxxFldValues['fld_dttim1_zztests'])));
  $o1.='</button>';
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_color1_zztests_413_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div style="display:flex;">'.CRLF;
  $o1.='   <input type="hidden" name="fld_color1_zztests" id="fld_color1_zztests"   value="'.enti1($xxxFldValues['fld_color1_zztests']).'" />'.CRLF;
  $o1.='   <div id="div__display_color_fld_color1_zztests" style="display:flex;">'.CRLF;
  if($xxxFldValues['fld_color1_zztests']!=''){  // fld_color1_zztests
   $val=json_decode($xxxFldValues['fld_color1_zztests'],true);
   $o1.='    <div style="width:35px;height:35px;border:1px #eee inset;background-color:#'.$val['hexValue'].'"></div>';
   $o1.='    <div>'.$val['hexValue'].'';
   if(isset($val['webName']) && $val['webName']!=''){
    $o1.=','.$val['webName'].'';
   }
   if(isset($val['pantoneName']) && $val['pantoneName']!=''){
    $o1.=', pantone:'.$val['pantoneName'].'';
   }
   $o1.='    </div>';
  }
  $o1.='   </div>';
  $o1.='   <div>';
  $o1.='    <button type="button" id="button_color_fld_color1_zztests" onclick="javascript:setColor1(\'fld_color1_zztests\',\'button_color_fld_color1_zztests\',\'div__display_color_fld_color1_zztests\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">';
  $o1.=txtsys1('update color');
  $o1.='</button>';
  $o1.='   </div>';
     
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.='<div class="fdiv1">'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="hidden" name="fld_cntupd_zztests" id="fld_cntupd_zztests" value="'.$name2['fld_cntupd_zztests'].'" />'.CRLF;
  $o1.='   <button type="submit" class="">'.txtsys1('save_the_modification').'</button>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.='</div>'.CRLF;

  $o1.='</form>'.CRLF;

 //=================================================================================================================================
 //============================================= GET VIEW ==========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='v'&&isset($_GET['id'])&&is_numeric($_GET['id'])){ // view action
  // if you vant to do something here, go !
 //=================================================================================================================================
 //============================================= GET CREATE ========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='c'){ // create action
 
  $o1.='<h2>'.txt2('Add a new record_459_20'). ' '.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $o1.='<form method="post" class="form1">'.CRLF;
 
  $fld_yorno1_zztests =isset($_SESSION[PGMK][NAV][BNF]['fld_yorno1_zztests'] )?$_SESSION[PGMK][NAV][BNF]['fld_yorno1_zztests']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_yorno1_zztests_311_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
  $retParam=displayParam2('yorno',$fld_yorno1_zztests,'fld_yorno1_zztests',array('unsetPossible'=>true,'dropDown'=>false));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $fld_visited_countries_zztests =isset($_SESSION[PGMK][NAV][BNF]['fld_visited_countries_zztests'] )?$_SESSION[PGMK][NAV][BNF]['fld_visited_countries_zztests']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_visited_countries_zztests_321_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/country.php');
  $retParam=displayParam2('country',$fld_visited_countries_zztests,'fld_visited_countries_zztests',array('set'=>true));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $fld_country1_zztests =isset($_SESSION[PGMK][NAV][BNF]['fld_country1_zztests'] )?$_SESSION[PGMK][NAV][BNF]['fld_country1_zztests']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_country1_zztests_331_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_dataPath1'].'/generated/_params/country.php');
  $retParam=displayParam2('country',$fld_country1_zztests,'fld_country1_zztests',array('unsetPossible'=>true,'dropDown'=>true));
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $fld_title32_zztests =isset($_SESSION[PGMK][NAV][BNF]['fld_title32_zztests'] )?$_SESSION[PGMK][NAV][BNF]['fld_title32_zztests']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_title32_zztests_340_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_title32_zztests).'" name="fld_title32_zztests" id="fld_title32_zztests" maxlength="32" style="width:100%;max-width:34em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $fld_id_parent_zztests=isset($_SESSION[PGMK][NAV][BNF]['fld_id_parent_zztests'] )?$_SESSION[PGMK][NAV][BNF]['fld_id_parent_zztests']:'';
  if(
   isset($_SESSION[PGMK][NAV][BNF]['choose__fld_id_parent_zztests'])&&
   $_SESSION[PGMK][NAV][BNF]['choose__fld_id_parent_zztests']==txtsys1('text_for_the_select_button')&&
   isset($_SESSION[PGMK]['choose']['valueBack'])&&
   $_SESSION[PGMK]['choose']['valueBack']!=0
  ){
   if($_SESSION[PGMK][NAV][BNF]['choose__fld_id_parent_zztests']==txtsys1('text_for_the_select_button')){
    $fld_id_parent_zztests=$_SESSION[PGMK]['choose']['valueBack'];
   }
   unset($_SESSION[PGMK]['choose']);
  }
  if($fld_id_parent_zztests!=''){
   $xGroupValues=getTdo_zztests1($fld_id_parent_zztests); // todo check this function
   $xDisplayValueFetch = '' .  $xGroupValues['fld_title32_zztests']  . ' (' . $xGroupValues['fld_id_zztests'] . ')' . '' ; // todo check among the fields of the parent table
  }else{
   $xDisplayValueFetch ='';
  }
  $o1.='  <div class="fdiv1">'.CRLF;
  $o1.='   <div class="flab1"><div>'.txt2('parent_fld_id_parent_zztests_367_43').'</div></div>'.CRLF;
  $o1.='   <div class="finp1"><div>'.CRLF;
  $o1.='    <input type="hidden" value="'.enti1($fld_id_parent_zztests).'" name="fld_id_parent_zztests" id="fld_id_parent_zztests" />'.CRLF;
  $o1.='     <span id="span__dep_fld_id_parent_zztests">'.$xDisplayValueFetch.'</span>';
  $o1.='    <button type="submit" name="choose__fld_id_parent_zztests" class="btn" value="'. txtsys1('text_for_the_select_button') . '">';
  $o1.=''   . txtsys1('text_for_the_select_button') . '';
  $o1.=     '</button>'."\r\n";
  $o1.='    <button type="button" class="warning" onclick="razDependant1(\'span__dep_fld_id_parent_zztests\',\'fld_id_parent_zztests\')">';
  $o1.=''   . txtsys1('raz_button') . '';
  $o1.=     '</button>'."\r\n";
  $o1.='   </div></div>'.CRLF;
  $o1.='  </div>'.CRLF;


  $fld_date1_zztests =isset($_SESSION[PGMK][NAV][BNF]['fld_date1_zztests'] )?$_SESSION[PGMK][NAV][BNF]['fld_date1_zztests']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_date1_zztests_381_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  if($fld_date1_zztests=='1000-01-01') $fld_date1_zztests='';
  $o1.='    <input type="hidden" name="fld_date1_zztests"    id="fld_date1_zztests"   value="'.enti1($fld_date1_zztests).'" />'.CRLF;
  $o1.='    <button type="button" style="padding:0px!important;font-size:0.8em;" id="button_date_fld_date1_zztests" onclick="javascript:setDate1(\'fld_date1_zztests\',\'button_date_fld_date1_zztests\',1,0)" >';
  $o1.=(($fld_date1_zztests=='1000-01-01' || $fld_date1_zztests=='' )?txtsys1('date null'):($fld_date1_zztests=='NULL'?txtsys1('date null'):($fld_date1_zztests=='NOT NULL'?txtsys1('date not null'):$fld_date1_zztests)));
  $o1.='</button>';
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $fld_time1_zztests =isset($_SESSION[PGMK][NAV][BNF]['fld_time1_zztests'] )?$_SESSION[PGMK][NAV][BNF]['fld_time1_zztests']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_time1_zztests_392_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='    <input type="hidden" name="fld_time1_zztests"    id="fld_time1_zztests"   value="'.enti1($fld_time1_zztests).'" />'.CRLF;
  $o1.='    <button type="button" style="padding:0px!important;font-size:0.8em;" id="button_time_fld_time1_zztests" ';
  $o1.=' onclick="javascript:setTime1(\'fld_time1_zztests\',\'button_time_fld_time1_zztests\',1,0,\'\',0)" >';
  $o1.=($fld_time1_zztests==''?txtsys1('time null'):($fld_time1_zztests=='NULL'?txtsys1('time null'):($fld_time1_zztests=='NOT NULL'?txtsys1('time not null'):$fld_time1_zztests)));
  $o1.='</button>';
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $fld_dttim1_zztests =isset($_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests'] )?$_SESSION[PGMK][NAV][BNF]['fld_dttim1_zztests']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_dttim1_zztests_403_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="hidden" name="fld_dttim1_zztests"    id="fld_dttim1_zztests"   value="'.enti1($fld_dttim1_zztests).'" />'.CRLF;
  $o1.='   <button type="button" style="padding:0px!important;font-size:0.8em;"  id="button_datetime_fld_dttim1_zztests" onclick="javascript:setDateTime1(\'fld_dttim1_zztests\',\'button_datetime_fld_dttim1_zztests\',1,0,0,\'\')" >';
  $o1.=($fld_dttim1_zztests==''?txtsys1('datetime null'):($fld_dttim1_zztests=='NULL'?txtsys1('datetime null'):($fld_dttim1_zztests=='NOT NULL'?txtsys1('datetime not null'):$fld_dttim1_zztests)));
  $o1.='</button>';
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $fld_color1_zztests =isset($_SESSION[PGMK][NAV][BNF]['fld_color1_zztests'] )?$_SESSION[PGMK][NAV][BNF]['fld_color1_zztests']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_color1_zztests_413_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div style="display:flex;">'.CRLF;
  $o1.='   <input type="hidden" name="fld_color1_zztests" id="fld_color1_zztests"   value="'.enti1($fld_color1_zztests).'" />'.CRLF;
  $o1.='   <div id="div__display_color_fld_color1_zztests" style="display:flex;">'.CRLF;
  if($fld_color1_zztests!=''){  // fld_color1_zztests
   $val=json_decode($fld_color1_zztests,true);
   $o1.='    <div style="width:35px;height:35px;border:1px #eee inset;background-color:#'.$val['hexValue'].'"></div>'; // fld_color1_zztests
   $o1.='    <div>'.$val['hexValue'].'';
   if(isset($val['webName']) && $val['webName']!=''){
    $o1.=','.$val['webName'].'';
   }
   if(isset($val['pantoneName']) && $val['pantoneName']!=''){
    $o1.=', pantone:'.$val['pantoneName'].'';
   }
   $o1.='    </div>';
  }
  $o1.='   </div>';
  $o1.='   <div>';
  $o1.='    <button type="button" id="button_color_fld_color1_zztests" onclick="javascript:setColor1(\'fld_color1_zztests\',\'button_color_fld_color1_zztests\',\'div__display_color_fld_color1_zztests\',1,0)" style="display:inline-block;border-style:outset;font-size:0.8em;padding:5px;">';
  $o1.=txtsys1('update color');
  $o1.='</button>';
  $o1.='   </div>';
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('record_the_element').'</button>'.CRLF;
  $o1.='   <input type="hidden" value="0" name="id1" id="id1" />'.CRLF;
  $o1.='   <input type="hidden" value="c" name="a" id="a" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.='</form>'.CRLF;

 }
 $o1.=htmlFoot0(array('js' => $js1));
 dw1($o1);
 if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);
}