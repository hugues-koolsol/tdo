function translatePageElement1(fromId,id){
 ajaxCall({
  data  : {funct:'translatePageElement1',value:document.getElementById(fromId).value,id:id,fromId:fromId},
  url   : 'translatePageElement1',
  retu  : afterTranslatePageElement1
 });
}
//=====================================================================================================================
function afterTranslatePageElement1(dataJson,objSend){
 console.log(dataJson,objSend);
 document.getElementById('trjs__va_'+objSend.data.i).style.background='lime';
}
//=====================================================================================================================
function tanslateMenu2(fromId,id){
 ajaxCall({
  data  : {funct:'translateMenu2',value:document.getElementById(fromId).value,id:id,fromId:fromId},
  url   : 'translateMenu2',
  retu  : afterTanslateMenu2
 });
}
//=====================================================================================================================
function afterTanslateMenu2(dataJson,objSend){
// console.log(dataJson,objSend);
 document.getElementById(objSend.data.fromId).style.background='lime';
}
//=====================================================================================================================
function tanslateMenu1(fromId,page,lang){
 ajaxCall({
  data  : {funct:'translateMenu1',value:document.getElementById(fromId).value,page:page,lang:lang,fromId:fromId},
  url   : 'translateMenu1',
  retu  : afterTanslateMenu1
 });
}
//=====================================================================================================================
function afterTanslateMenu1(dataJson,objSend){
// console.log(dataJson,objSend);
 document.getElementById(objSend.data.fromId).style.background='lime';
}
//=====================================================================================================================
function addTranslateSys1(i){
 var data={
  funct   : 'addTranslateSys1',
  key     : document.getElementById('trjs__ke_'+i).value,
  lang    : document.getElementById('trjs__la_'+i).value,
  value   : document.getElementById('trjs__va_'+i).value,
  i       : i
 }
 ajaxCall({
  data  : data,
  url   : 'addTranslateSys1',
  retu  : afterAddTranslateSys1
 });
}
//=====================================================================================================================
function afterAddTranslateSys1(dataJson,objSend){
// console.log(dataJson,objSend);
 document.getElementById('trjs__va_'+objSend.data.i).style.background='lime';
}
//=====================================================================================================================
function addTranslationJs1(e){
 var elem=e.srcElement?e.srcElement:e;
// console.log(elem);
 var targetText='';
 var srcZone='';
 srcZone=elem.getAttribute('data-idparent');
 targetText=document.getElementById(elem.getAttribute('data-idparent')).value;
 var targetTranslation=elem.getAttribute('data-idtranslate').split('|');
 var data={
  funct   : 'addTranslationJs1',
  key     : revent1(targetTranslation[1]),
  page    : targetTranslation[0],
  lang    : targetTranslation[2],
  value   : targetText,
  page_id : 0 ,
  srcZone : srcZone ,
 }
 ajaxCall({
  data  : data,
  url   : 'addTranslationJs1',
  retu  : afterAddTranslationJs1
 });
}
//=====================================================================================================================
function afterAddTranslationJs1(dataJson,objSend){
// console.log(dataJson,objSend);
 document.getElementById(objSend.data.srcZone).style.background='lime';
}
//=====================================================================================================================
function addTranslation(e){
 var elem=e.srcElement?e.srcElement:e;
// console.log(elem);
 var targetText='';
 var srcZone='';
 if(elem.getAttribute('data-otherSpan')==''){
  srcZone=elem.getAttribute('data-idparent');
  if(elem.getAttribute('data-fromValue')=='true'){
   targetText=document.getElementById(elem.getAttribute('data-idparent')).value;
  }else{
   targetText=document.getElementById(elem.getAttribute('data-idparent')).innerHTML;
  }
  
 }else{
  srcZone=elem.getAttribute('data-otherSpan');
  if(elem.getAttribute('data-fromValue')=='true'){
   targetText=document.getElementById(elem.getAttribute('data-otherSpan')).value;
  }else{
   targetText=document.getElementById(elem.getAttribute('data-otherSpan')).innerHTML;
  }
 }
 var page_id=elem.getAttribute('data-pageid');
 var targetTranslation=elem.getAttribute('data-idtranslate').split('|');

 var data={
  funct   : 'translateText1',
  key     : revent1(targetTranslation[1]).replace(/___quot___/g,'"'),
  page    : targetTranslation[0],
  lang    : targetTranslation[2],
  value   : targetText,
  page_id : page_id ,
  srcZone : srcZone ,
 }
 ajaxCall({
  data  : data,
  url   : 'translateText1',
  retu  : afterTranslateText1
 });
}
//=====================================================================================================================
function afterTranslateText1(dataJson,objSend){
// console.log(dataJson,objSend);
 document.getElementById(objSend.data.srcZone).style.background='lime';
}
//=====================================================================================================================
function afterWriteTranslationFiles1(dataJson,objSend){
 console.log(dataJson,objSend);
}
//=====================================================================================================================
function afterTranslate1(dataJson,objSend){
// console.log(dataJson,objSend);
 var bgColor='white';
 var out='';
 var theInitTranslatedValue={};
 if(dataJson.status=='OK'){
  var lstToTranslate='';
  lstToTranslate+='';
  var i=0;
//  console.log(dataJson.output);
  for(var elem in dataJson.output){
//   console.log(elem , dataJson.output[elem]);
   if(dataJson.output[elem].type=='txt1'){
    lstToTranslate+='<tr id="trjs__tr_'+i+'">';
    lstToTranslate+='<td class="thinBorder" style="width:34%;">';
    lstToTranslate+=''+globLang+'';
    theInitTranslatedValue=getTranslateValueInit(dataJson.output[elem].key,globLang);
    if(theInitTranslatedValue.theValue==''){
     var textSuggestion='';
     if(dataJson.suggestionValues){
//      console.log(dataJson.suggestionValues , dataJson.output[elem].key);
      for(var sug in dataJson.suggestionValues){
       if(dataJson.suggestionValues[sug].lang==globalLangTranslate && dataJson.output[elem].key == dataJson.suggestionValues[sug].key ){
        textSuggestion=dataJson.suggestionValues[sug].value;
       }
      }
     }
     lstToTranslate+='<input type="text" value="'+ent1(textSuggestion)+'" id="trjs__va_'+i+'" style="width:75%;font-size:0.8em;'+theInitTranslatedValue.theBackgroundColor+'">';         
    }else{
     lstToTranslate+='<input type="text" value="'+ent1(theInitTranslatedValue.theValue)+'" id="trjs__va_'+i+'" style="width:75%;font-size:0.8em;'+theInitTranslatedValue.theBackgroundColor+'">';    
    }
    lstToTranslate+='<button onclick="translate2('+i+','+zz_page_id+','+dataJson.output[elem].lineNumber+','+dataJson.output[elem].colNumber+',\''+objSend.data.page+'\')" id="trjs__inp_'+i+'" style="min-width:15px;width:15px;padding:0;">T</button>';
    lstToTranslate+='</td>';
    lstToTranslate+='<td class="thinBorder" id="trjs__ke_'+i+'" style="background-color:'+bgColor+';width:33%;word-break: break-word;">'+dataJson.output[elem].key+'</td>';
    lstToTranslate+='<td class="thinBorder" style="font-size:0.8em;word-break: break-word;width:33%;">'+ent1(dataJson.output[elem].line)+'</td>';
    lstToTranslate+='</tr>';
   }
   i++;
  }
//  console.log('lstToTranslate=',lstToTranslate);
  if(lstToTranslate!=''){
   out+='<div style="overflow-x:scroll;"><table class="thinBorder" style="border-collapse: collapse;"><tr><td colspan="3" class="danger" style="text-align:center;font-size:1.5em;">'+globLang+'</td></tr>'+lstToTranslate+'</table></div>';
  }
  var listeDesBoutonsTranslateAvecCles=[];
  var numberOfLanguages=0;
  for(var lang in globAvailableLanguages){
   numberOfLanguages++;
  }
  var elem2='';
  if(dataJson.translateValues!=null){
   var lstValTranslated='<div style="overflow-x:scroll;"><table border="1" style="border-collapse:collapse;"><tr><th>key</th><th>lg</th><th>value</th></tr>';
   for(var elem in dataJson.translateValues){
    var countLanguage=0;
    for( var lang in globAvailableLanguages){
     countLanguage++;
     lstValTranslated+='<tr>';
     if(countLanguage==1){
      lstValTranslated+='<td rowspan="'+numberOfLanguages+'" style="white-space: pre-wrap;word-break: break-word;width:30%;">'+elem+'</td>';
     }
     lstValTranslated+='<td style="width:10%;">'+lang+'</td>';
     lstValTranslated+='<td style="width:60%;">';
     if(dataJson.translateValues[elem][lang]){
      if(dataJson.translateValues[elem][lang].value != ''){
       var regex = /^.*\_[0-9]{1,5}\_[0-9]{1,5}$/;
       var resultatRegEx = regex.test(dataJson.translateValues[elem][lang].value);
       if(resultatRegEx===true){
        lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem).replace(/&quot;/g,'___quot___')+'" type="text" value="'+ent1(dataJson.translateValues[elem][lang].value)+'" style="background-color:red;color:black;width:90%;font-size:0.8em;" />';            
       }else{
        lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem).replace(/&quot;/g,'___quot___')+'" type="text" value="'+ent1(dataJson.translateValues[elem][lang].value)+'" style="width:90%;font-size:0.8em;" />';            
       }
      }else{
       lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem).replace(/&quot;/g,'___quot___')+'" type="text" value="'+ent1(dataJson.translateValues[elem][lang].value)+'" style="background-color:red;color:black;width:90%;font-size:0.8em;" />';     
      }
     }else{
      elem2=elem;
      if(elem.lastIndexOf('_')>=0){
       elem2=elem.substr(0,elem.lastIndexOf('_'));
       if(elem2.lastIndexOf('_')>=0){
        elem2=elem2.substr(0,elem2.lastIndexOf('_'));
       }
      }
      
      theInitTranslatedValue=getTranslateValueInit(elem2,lang);
      if(theInitTranslatedValue.theValue==''){
       var textSuggestion='';
       if(dataJson.suggestionValues){
        for(var sug in dataJson.suggestionValues){
         if(dataJson.suggestionValues[sug].lang==lang && elem == dataJson.suggestionValues[sug].key ){
          textSuggestion=dataJson.suggestionValues[sug].value;
         }
        }
       }
       lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem).replace(/&quot;/g,'___quot___')+'" type="text" value="'+ent1(textSuggestion)+'" style="background-color:red;width:30em;font-size:0.8em;" />';           
      }else{
       lstValTranslated+='<input id="translate__key_'+lang+'_'+ent1(elem).replace(/&quot;/g,'___quot___')+'" type="text" value="'+ent1(theInitTranslatedValue.theValue)+'" style="width:30em;font-size:0.8em;'+theInitTranslatedValue.theBackgroundColor+'" />';           
      }
     }
     lstValTranslated+='<button ';
     lstValTranslated+=' type="button" ';
     lstValTranslated+=' id="'+lang+'__'+ent1(elem).replace(/&quot;/g,'___quot___')+'" ';
     lstValTranslated+=' style="width:15px;height:35px;min-width:15px;min-height:35px;padding:0;border-radius:2px;"';
     lstValTranslated+=' data-pageid="'+zz_page_id+'"';
     lstValTranslated+=' data-fromValue="true"';
     lstValTranslated+=' data-otherSpan=""';
     lstValTranslated+=' data-idparent="translate__key_'+lang+'_'+ent1(elem).replace(/&quot;/g,'___quot___')+'"';
     lstValTranslated+=' data-idtranslate="'+globBNF+'|'+ent1(elem).replace(/&quot;/g,'___quot___')+'|'+lang+'"';
     lstValTranslated+='>T</button>';
     listeDesBoutonsTranslateAvecCles.push(lang+'__'+ent1(elem).replace(/&quot;/g,'___quot___'));
     lstValTranslated+='</td>';
    }
    lstValTranslated+='</tr>';
   }
   lstValTranslated+='</table></table>'
   out+=lstValTranslated;
  }
  
//  console.log('objSend=',objSend);
  out+='<button onclick="writeTranslationFiles1('+objSend.data.page_id+',\''+objSend.data.page+'\')">'+txt2('generate_translation_files_1912_109')+'</button>';
  
  var lst=document.getElementsByTagName('span');
  var lstElements=[];
  for(var i=0;i<lst.length;i++){
   if(lst[i].className && lst[i].className=='forTranslation'){
    var parentIsAnchorOrButton=false;
    if(lst[i].parentNode.nodeName.toLowerCase()=='a' || lst[i].parentNode.nodeName.toLowerCase()=='button'){
     parentIsAnchorOrButton=true;
    }
    var newElement=document.createElement('button');
    newElement.innerHTML='T';
    newElement.type='button';
    newElement.style.width='15px';
    newElement.style.height='15px';
    newElement.style.minWidth='15px';
    newElement.style.minHeight='15px';
    newElement.style.padding='0';
    newElement.style.borderRadius='2px';
    newElement.setAttribute('data-idtranslate',lst[i].getAttribute('data-idtranslate'));
    newElement.setAttribute('data-idparent',lst[i].id);
    newElement.setAttribute('data-pageid',zz_page_id);
    if(parentIsAnchorOrButton){
     
     newElement.setAttribute('data-otherSpan','other__span__'+lst[i].id);
     var newSpan=document.createElement('span');
     newSpan.id='other__span__'+lst[i].id;
     newSpan.setAttribute('data-idtranslate',lst[i].getAttribute('data-idtranslate'));
     newSpan.setAttribute('data-idparent',lst[i].id);
     newSpan.contentEditable=true
     newSpan.contentEditable="true";
     newSpan.setAttribute("contenteditable", "true");
     newSpan.innerHTML=lst[i].innerHTML;
     newSpan.className='forTranslation2';
     lst[i].parentNode.parentNode.insertBefore(newElement, lst[i].parentNode.nextSibling);
     lst[i].parentNode.parentNode.insertBefore(newSpan, lst[i].parentNode.nextSibling);
    }else{
     newElement.setAttribute('data-otherSpan','');
     lst[i].parentNode.insertBefore(newElement, lst[i].nextSibling);
    }
    lstElements.push(newElement);
   }
  }
  document.getElementById('zztranslate').innerHTML=out;
  if(lstElements.length>0){
   for(var i=0;i<lstElements.length;i++){
    lstElements[i].addEventListener('click',addTranslation,false);
   }
  }
  if(listeDesBoutonsTranslateAvecCles.length>0){
   for(var i=0;i<listeDesBoutonsTranslateAvecCles.length;i++){
    try{
     document.getElementById(listeDesBoutonsTranslateAvecCles[i]).addEventListener('click',addTranslation,false);
    }catch(e){
     console.log('e=',e,listeDesBoutonsTranslateAvecCles[i]);
    }
   }
  }
 }
}
//=====================================================================================================================
function translate2(i,page_id,lineNumber,columnNumber,pageName){
 var data={
  funct   : 'translatePage2',
  line    : lineNumber    ,
  column  : columnNumber  ,
  key     : document.getElementById('trjs__ke_'+i).innerHTML         ,
  value   : document.getElementById('trjs__va_'+i).value             ,
  page    : pageName ,
  lang    : globLang       ,
  elem    : 'trjs__va_'+i  ,
  butt    : 'trjs__inp_'+i ,
  page_id : page_id ,
 }
 ajaxCall({
  data  : data,
  url   : 'translatePage2',
  retu  : afterTranslate2
 });
 
}
//=====================================================================================================================
function launchTranslate(){
 ajaxCall({
  data  : {funct:'getPageToTranslate1',page:globBNF,page_id:zz_page_id,currentLanguage:globalLangTranslate},
  url   : 'getPageToTranslate1',
  retu  : afterTranslate1
 });
}
//=====================================================================================================================
function getTranslateValueInit(key,lang){
 theValue='';
 theBackgroundColor='';
 if('the value must be numerical for the field'==key){
  if(lang=='fr'){
   theValue='la valeur doit être numérique pour le champ';
   theBackgroundColor='background-color:lightgreen;'
  }else if(lang=='en'){
   theValue='the value must be numerical for the field';
   theBackgroundColor='background-color:lightgreen;'
  }
 }
 else if('no_record_founded'==key){
  if(lang=='fr'){
   theValue='aucune valeur trouvée avec les critères indiqués';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='no values were founded with these criterias';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('page_title_list'==key){
  if(lang=='fr'){
   theValue='liste de';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='list of the ';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('add_a_new_record'==key){
  if(lang=='fr'){
   theValue='ajouter une nouvelle un nouveau ';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='add a new ';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('the new value has been inserted'==key){
  if(lang=='fr'){
   theValue='une nouvelle un nouveau xxx a été inséré';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='the new value has been inserted';
   theBackgroundColor='background-color:orange;'
  }
 } 
 else if('update a record'==key){
  if(lang=='fr'){
   theValue='modification d\'un d\'une xxx';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='modification of a xxx';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if('Add a new record'==key){
  if(lang=='fr'){
   theValue='ajout d\'un d\'une xxx';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='add a new xxx';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if(key.indexOf('_id_')>=0){
  if(lang=='fr'){
   theValue='id';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='id';
   theBackgroundColor='background-color:orange;'
  }
 }
 else if(key.indexOf('must not be empty')>=0){
  if(lang=='fr'){
   theValue='le la xxx ne doit pas être vide';
   theBackgroundColor='background-color:orange;'
  }else if(lang=='en'){
   theValue='the xxx must not be void';
   theBackgroundColor='background-color:orange;'
  }
 }
 
 return {theValue:theValue,theBackgroundColor:theBackgroundColor};
}
//=====================================================================================================================
function afterTranslate2(dataJson,objSend){
// console.log(dataJson,objSend);
 document.getElementById(objSend.data.elem).style.background='lime';
 document.getElementById(objSend.data.butt).style.display='none';
}
//=====================================================================================================================
function writeTranslationFiles1(pageId,pageName){
 var data={
  funct   : 'writeTranslationFiles1',
  page    : pageName ,
  page_id : pageId   ,
 }
 ajaxCall({
  data  : data,
  url   : 'writeTranslationFiles1',
  retu  : afterWriteTranslationFiles1
 });
}
