<?php
// setup for databases
$GLOBALS['glob_db'][0]['server']   ='localhost:3306';
$GLOBALS['glob_db'][0]['user']     ='admin';
$GLOBALS['glob_db'][0]['password'] ='admin';
$GLOBALS['glob_db'][0]['dbname']   ='tdo';
$GLOBALS['glob_db'][0]['setname']  ='utf8mb4';
$GLOBALS['glob_db'][0]['link']     =null;

/*

$GLOBALS['glob_db'][1]['server']   ='localhost:3306';
$GLOBALS['glob_db'][1]['user']     ='admin';
$GLOBALS['glob_db'][1]['password'] ='admin';
$GLOBALS['glob_db'][1]['dbname']   ='an_other_database';
$GLOBALS['glob_db'][0]['setname']  ='latin1';
$GLOBALS['glob_db'][1]['link']     =null;



$GLOBALS['glob_db'][2]['server']   ='localhost:3306';
$GLOBALS['glob_db'][2]['user']     ='admin';
$GLOBALS['glob_db'][2]['password'] ='admin';
$GLOBALS['glob_db'][2]['dbname']   ='a_third_database';
$GLOBALS['glob_db'][0]['setname']  ='utf8'; // try to avoid this 💩 ! 
$GLOBALS['glob_db'][2]['link']     =null;


*/