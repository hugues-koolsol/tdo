"use strict";
var myDraw1=null;
//====================================================================================================
//====================================================================================================

//====================================================================================================
function design1(par){
 if(par.data.glob=='globTableData'){
  var div=document.getElementById(par.data.divId1);
  var pos1=div.getBoundingClientRect();
  var canvas = document.createElement('canvas');
  if(globTableData.canvas.width!=0 && globTableData.canvas.height!=0 ){
   canvas.width =globTableData.canvas.width;
   canvas.height=globTableData.canvas.height;
  }else{
   canvas.width =pos1.width;
   canvas.height=pos1.height;
  }
  canvas.id='design1';
  canvas.className='thinBorder';
  div.appendChild(canvas);  
  var options={
   canvas       : null            ,
   ctx          : null            ,   
   canvasId     : 'design1'       ,
   width        : canvas.width    ,
   height        : canvas.height  ,
   parentDiv    : par.data.divId1 ,
   hauteurBoite : 20              ,
   data         : globTableData   ,
   handleHeight : 35              ,   
   canvasBorder : 0               ,
   divContainer : div             ,
   minWidth     : 500             ,
   minHeight    : 500             ,
  };
  myDraw1=new resizDbDraw4(options);
 }
}
//====================================================================================================
function resizDbDraw4(opt) {
 // utilities
 var dogid    =function(s){return document.getElementById(s);};
 var noop     =function(){}; // simple no operation function
 var offloadFn=function(fn){setTimeout(fn||noop,0)}; // offload a functions execution
 var is_touch_device=function(){return (('ontouchstart' in window)||(navigator.MaxTouchPoints>0)||(navigator.msMaxTouchPoints>0));} 

 // check browser capabilities
 var browser = {
  addEventListener: !!window.addEventListener,
  touch:('ontouchstart' in window)||window.DocumentTouch && document instanceof DocumentTouch,
  transitions: (function(temp) {
    var props=['transitionProperty', 'WebkitTransition', 'MozTransition', 'OTransition', 'msTransition'];
    for(var i in props) if(temp.style[props[i]]!==undefined) return true;
    return false;
  })(document.createElement('swipe'))
 };

 
 opt.canvas=dogid(opt.canvasId);
 opt.ctx=opt.canvas.getContext('2d');
 
 var kneeTable=[];
 var kneeRadius=0;
 if(is_touch_device()){
  kneeRadius=8;
 }else{
  kneeRadius=5;
 }
 var posCanvas=null;
 //===============================================================================================================================
 function setPosCanvas(){
  var tmp=opt.canvas.getBoundingClientRect();
  if(is_touch_device()){
   posCanvas = {left:tmp.left,top:tmp.top};
  }else{
   posCanvas = {left:tmp.left+window.scrollX,top:tmp.top+window.scrollY};
  }
 }
 setPosCanvas();
 //===============================================================================================================================
 var myEfficientFn = debounce(function() {
  console.log('myEfficientFn');
  setPosCanvas();
  var posDivCanvas=opt.divContainer.getBoundingClientRect();
  resizeCanvas.style.top    =(parseInt(posDivCanvas.bottom,10)+window.scrollY)+'px';
  myDraw1.draw(); // All the taxing stuff you do
 }, 300);
 window.addEventListener('resize', myEfficientFn);
 
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 function debounce(func, wait, immediate) {
  var timeout;
  return function() {
   var context = this, args = arguments;
   var later = function() {
    timeout = null;
    if (!immediate) func.apply(context, args);
   };
   var callNow = immediate && !timeout;
   clearTimeout(timeout);
   timeout = setTimeout(later, wait);
   if (callNow) func.apply(context, args);
  };
 };
 //===============================================================================================================================
 function moveTableHorizontal1(){
  var delta=parseInt(event.target.value,10);
  for(var i=0;i<opt.data['tables'].length;i++){
   opt.data['tables'][i]['table']['fld_left_table']=parseInt(opt.data['tables'][i]['table']['fld_left_table'],10)+delta;
   for(var j=0;j<opt.data['tables'][i].fields.length;j++){
    if(opt.data['tables'][i].fields[j].parent){
     opt.data['tables'][i].fields[j].parent.kneeX+=delta;
    }
   }
  }
  draw();
 }
 //===============================================================================================================================
 function moveTableVertical1(event){
  var delta=parseInt(event.target.value,10);
  for(var i=0;i<opt.data['tables'].length;i++){
   opt.data['tables'][i]['table']['fld_top_table']=parseInt(opt.data['tables'][i]['table']['fld_top_table'],10)+delta;
   for(var j=0;j<opt.data['tables'][i].fields.length;j++){
    if(opt.data['tables'][i].fields[j].parent){
     opt.data['tables'][i].fields[j].parent.kneeY+=delta;
    }
   }
  }
  draw();
 }
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 function setParentLinkMandatory1(){
  
  var r = new XMLHttpRequest();
  r.open("POST",'za_ajax.php?design1',true);
  r.timeout=6000;
  r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
  r.onreadystatechange = function () {
   if (r.readyState != 4 || r.status != 200) return;
   try{
    var jsonRet=JSON.parse(r.responseText);
    if(jsonRet.status=='OK'){
     

     if(opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.fld_link_mandatory_pglnks==true){
      opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.fld_link_mandatory_pglnks=false;
      document.getElementById('setParentLinkMandatory1').className='edit';
     }else{
      opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.fld_link_mandatory_pglnks=true;
      document.getElementById('setParentLinkMandatory1').className='';
     }
     draw();
     return;
     
    }else{
     console.error(r);
     return;
    }
   }catch(e){
    console.error(e,r);
    return;
   }
  };
  r.onerror=function(e){
   console.error('e=',e);
   return;
  }
  var data={
   funct                     : 'design1',
   subFunct                  : 'setParentLinkMandatory1',
   fld_link_mandatory_pglnks : opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.fld_link_mandatory_pglnks ,
   db_id_link                : opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.db_id_link,
  }
  r.send('data='+encodeURIComponent(JSON.stringify(data)));  

  
  
 }
 //===============================================================================================================================
 function centerLink1(){
  if(opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.centerKnee==true){
   opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.centerKnee=false;
   document.getElementById('centerLink1').className='edit';
  }else{
   opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.centerKnee=true;
   document.getElementById('centerLink1').className='';
  }
  draw();
 }
 //===============================================================================================================================
 function revertChildrenLink1(){
  
  if(opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.childOnRight==true){
   opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.childOnRight=false;
   document.getElementById('revertChildrenLink1').className='';
  }else{
   opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.childOnRight=true;
   document.getElementById('revertChildrenLink1').className='edit';
  }
  draw();
  
 }
 //===============================================================================================================================
 function revertParentLink1(){
  var fieldName='';
  var fieldNameDb='';
  if(opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.parentOnLeft==true){
   opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.parentOnLeft=false;
   document.getElementById('revertParentLink1').className='';
  }else{
   opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.parentOnLeft=true;
   document.getElementById('revertParentLink1').className='edit';
  }
  draw();
 }
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 function linkDelete1(event){

   if(confirm(txt2('sure ?_18_18'))){
      
     var beforeAjax_child_view=kneeTable[theIdOfTheKnee].fld_view_tables;
     var beforeAjax_theIdOfTheKnee=theIdOfTheKnee;
      
     var r = new XMLHttpRequest();
     r.open("POST",'za_ajax.php?design1',true);
     r.timeout=6000;
     r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
     r.onreadystatechange = function () {
       if (r.readyState != 4 || r.status != 200) return;
       try{
         var jsonRet=JSON.parse(r.responseText);
         if(jsonRet.status=='OK'){
           for(var i=0;i<opt.data['tables'].length;i++){
             for(var j=0;j<opt.data['tables'][i].fields.length;j++){
               if(opt.data['tables'][i].fields[j].parent   &&   opt.data['tables'][i].fields[j].parent.db_id_link==jsonRet.db_id_link){
                
                 if(beforeAjax_child_view==1){
//                   console.log(kneeTable[beforeAjax_theIdOfTheKnee], opt.data['tables'] );
                   var parId=kneeTable[beforeAjax_theIdOfTheKnee].parentTableIndex;
                   var fiId=kneeTable[beforeAjax_theIdOfTheKnee].parentField.position;
                   opt.data['tables'][parId].fields[fiId]['comment']=jsonRet.newComment;
                 }
                 delete opt.data['tables'][i].fields[j].parent;
                 delete kneeTable[beforeAjax_theIdOfTheKnee];
                 break;
               }
             }
           }
           closeModal(false);
           draw();
           return;
         }else{
           console.error(r);
           return;
         }
       }catch(e){
         console.error(e,r);
         return;
       }
     };
     r.onerror=function(e){
       console.error('e=',e);
       return;
     }
     var data={
       funct                     : 'design1'                                       ,
       subFunct                  : 'linkDelete1'                                   ,
       fld_view_tables           : kneeTable[theIdOfTheKnee].fld_view_tables       ,
       tableName                 : kneeTable[theIdOfTheKnee].tableName             ,
       parentField               : kneeTable[theIdOfTheKnee].parentField.nom_champ ,
       parentTableName           : kneeTable[theIdOfTheKnee].childField.parent.fld_name_tables ,
       actualComment             : kneeTable[theIdOfTheKnee].parentField.comment   ,
       db_id_link                : opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.db_id_link,
     }
     r.send('data='+encodeURIComponent(JSON.stringify(data)));     
   }
 }
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 function displayModalKnee(event){
  //var fieldIdDB=opt.data[kneeTableIndex].fields[kneeFielIndex]['fld_id_field'];
//  console.log(theIdOfTheKnee, kneeTable[theIdOfTheKnee]);
  var modalcontent=document.createElement('div');

  var span=document.createElement('span');
  span.innerHTML='Field ';//+fieldIdDB;modalcontent.appendChild(span);
  var br=document.createElement('br');modalcontent.appendChild(br);

  var button=document.createElement('button');
  button.innerHTML='supprimer le lien';
  button.id='linkDelete1';
  button.className='danger';
  button.addEventListener('click', linkDelete1, false);
  modalcontent.appendChild(button);
  var br=document.createElement('br');modalcontent.appendChild(br);
  
  var button=document.createElement('button');
  button.innerHTML='Inverser la position du lien parent';
  if(opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.parentOnLeft==true){
   button.className='edit';
  }
  button.id='revertParentLink1';
  button.addEventListener('click', revertParentLink1, false);
  modalcontent.appendChild(button);

  var br=document.createElement('br');modalcontent.appendChild(br);
  var button=document.createElement('button');
  button.innerHTML='Inverser la position du lien enfant';
  if(opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.childOnRight==true){
   button.className='edit';
  }
  button.id='revertChildrenLink1';
  button.addEventListener('click', revertChildrenLink1, false);
  modalcontent.appendChild(button);

  var br=document.createElement('br');modalcontent.appendChild(br);
  var button=document.createElement('button');
  button.innerHTML='Décentrer le lien';
  button.id='centerLink1';
  if(opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.centerKnee==false){
   button.className='edit';
  }
  button.addEventListener('click', centerLink1, false);
  modalcontent.appendChild(button);

  
  var br=document.createElement('br');modalcontent.appendChild(br);
  var button=document.createElement('button');
  button.innerHTML='Rendre facultative la référence au parent';
  button.id='setParentLinkMandatory1';
  if(opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent.fld_link_mandatory_pglnks==false){
   button.className='edit';
  }
  button.addEventListener('click', setParentLinkMandatory1, false);
  modalcontent.appendChild(button);
  
  showModal({
   bodyModalContent   : modalcontent       ,
   event              : event              ,
   x                  : startPosOnCanvas.x ,
   y                  : startPosOnCanvas.y
  });
 }
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 function displayModalMoveTables(event){
  var modalcontent=document.createElement('div');
  var span=document.createElement('span');span.innerHTML='Déplacer toutes les tables';modalcontent.appendChild(span);
  var br=document.createElement('br');modalcontent.appendChild(br);
  
  var tb=document.createElement('table');

  var tr=document.createElement('tr');
  tb.appendChild(tr);
  
  var td=document.createElement('td');
  td.setAttribute('colspan','3');
  tr.appendChild(td);
  
  var tab=[-1,-3,-10,-30,-100];     
  for(var i=0;i<tab.length;i++){
   var button=document.createElement('button');
   button.innerHTML=tab[i]+'⇑'; // ↑
   button.value=(tab[i]<0?tab[i]:'+'+tab[i]);
   button.addEventListener('click', moveTableVertical1, false);
   td.appendChild(button);
  }

  var tr=document.createElement('tr');
  tb.appendChild(tr);
  
  var td=document.createElement('td');
  tr.appendChild(td);
  var tab=[-100,-30,-10,-3,-1];     
  for(var i=0;i<tab.length;i++){
   var button=document.createElement('button');
   button.innerHTML='⇦'+tab[i]; // ←
   button.value=(tab[i]<0?tab[i]:'+'+tab[i]);
   button.addEventListener('click', moveTableHorizontal1, false);
   td.appendChild(button);
  }

  var td=document.createElement('td');
  td.innerHTML='&nbsp;';
  tr.appendChild(td);

  
  var td=document.createElement('td');
  tr.appendChild(td);
  var tab=[1,3,10,30,100];
  for(var i=0;i<tab.length;i++){
   var button=document.createElement('button');
   button.innerHTML='⇨'+tab[i]; // ←
   button.value=(tab[i]<0?tab[i]:'+'+tab[i]);
   button.addEventListener('click', moveTableHorizontal1, false);
   td.appendChild(button);
  }
  
  var tr=document.createElement('tr');
  tb.appendChild(tr);

  var td=document.createElement('td');
  td.setAttribute('colspan','3');
  tr.appendChild(td);

  var tab=[1,3,10,30,100];
  for(var i=0;i<tab.length;i++){
   var button=document.createElement('button');
   button.innerHTML=tab[i]+'⇩'; // ↓
   button.value=(tab[i]<0?tab[i]:'+'+tab[i]);
   button.addEventListener('click', moveTableVertical1, false);
   td.appendChild(button);
  }
  
  
  modalcontent.appendChild(tb);
  
//  console.log( 'startPosOnCanvas=',startPosOnCanvas )
  
  showModal({
   bodyModalContent   : modalcontent       ,
   event              : event              ,
   x                  : startPosOnCanvas.x ,
   y                  : startPosOnCanvas.y 
  });
 }
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================

 var delta={};
 var startPosOnPage={};
 var startPosOnCanvas={};
 var endPosOnCanvas={};
 var mousePosOnPage={};
 var isScrolling=undefined;
 var isMouseDownOrTouchDown=false;
 var theIdOfTheCurrTabl=-1;
 var initialTablePosition={};
 var theIdOfTheKnee=-1;
 var initialKneePosition={};
 var kneeTableIndex=-1;
 var kneeFielIndex=-1;
 var newPosX=0;
 var newPosY=0;
 var theIdOfTheCurrField=-1;
 var theIdOfTheCurrTablOfCurrentField=-1;
 var mouseDownTime=0;
 var mouseUpTime=0;



 var events={
  handleEvent:function(event){ /* handleEvent est une fonction standart appelée automatiquement  */
   switch (event.type) {

    case 'touchstart'   : this.touchStartCanvas(event); break;
    case 'touchmove'    : this.touchMoveCanvas(event);  break;
    case 'touchend'     : this.touchEndCanvas(event);   break;
    
//    case 'resize'       : offloadFn(setup);            break;
    case 'mousedown'    : this.mouseDownCanvas(event); break;
    case 'mousemove'    : this.mouseMoveCanvas(event); break;
    case 'mouseup'      : this.mouseUp(event);         break;
   }
//   if (options.stopPropagation) event.stopPropagation();
  },
  //===============================================================================================================================
  touchMoveCanvas:function(e){
   if(isMouseDownOrTouchDown==true){
    if(theIdOfTheKnee==-1&&theIdOfTheCurrTabl==-1&&theIdOfTheCurrField==-1&&theIdOfTheCurrField==-1){
     delta={x:e.touches[0].pageX-startPosOnPage.x,y:e.touches[0].pageY-startPosOnPage.y};
     return;
    }
    e.stopPropagation();
//    e.preventDefault();

    var touches=e.touches[0];   
   
    if(theIdOfTheCurrTabl>=0){
     
     mousePosOnPage={x:touches.pageX,y: touches.pageY};
     delta={x:mousePosOnPage.x-startPosOnPage.x,y:mousePosOnPage.y-startPosOnPage.y};
     newPosX=initialTablePosition.x+delta.x; 
     if(newPosX<=0) newPosX=0;
     newPosY=initialTablePosition.y+delta.y; 
     if(newPosY<=0) newPosY=0;
     opt.data['tables'][theIdOfTheCurrTabl]['table']['fld_left_table']=newPosX;
     opt.data['tables'][theIdOfTheCurrTabl]['table']['fld_top_table']=newPosY;
     draw();
     
    }else if(theIdOfTheKnee>=0){
     mousePosOnPage={x:touches.pageX,y: touches.pageY};
     delta={x:mousePosOnPage.x-startPosOnPage.x,y:mousePosOnPage.y-startPosOnPage.y};
     newPosX=initialKneePosition.x+delta.x; 
     if(newPosX<=1) newPosX=1;
     newPosY=initialKneePosition.y+delta.y; 
     if(newPosY<=1) newPosY=1;
     opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent['kneeX']=newPosX;
     opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent['kneeY']=newPosY;
     draw();

    }else if(theIdOfTheCurrField>=0){
     mousePosOnPage={x:touches.pageX,y: touches.pageY};
     delta={x:mousePosOnPage.x-startPosOnPage.x,y:mousePosOnPage.y-startPosOnPage.y};
     
     endPosOnCanvas.x=startPosOnCanvas.x+delta.x; 
     if(endPosOnCanvas.x<=0) endPosOnCanvas.x=0;
     endPosOnCanvas.y=startPosOnCanvas.y+delta.y; 
     if(endPosOnCanvas.y<=0) endPosOnCanvas.y=0;
     
     draw();   
     opt.ctx.beginPath();
     opt.ctx.moveTo( startPosOnCanvas.x , startPosOnCanvas.y );
     opt.ctx.lineTo( endPosOnCanvas.x   , endPosOnCanvas.y   );
     opt.ctx.lineWidth = 2;
     opt.ctx.strokeStyle = '#ff0000';
     opt.ctx.lineCap = 'round';
     opt.ctx.stroke();
    }
   }
  },
  //===============================================================================================================================
  touchEndCanvas:function(e){
   if(opt.data['canvas']['mode']=='mode_field1' || opt.data['canvas']['mode']=='mode_link1'  ){
    document.body.style.overflow='';
    return;
   }else{
    document.body.style.overflow='';
   }

   isMouseDownOrTouchDown=false;
   window.removeEventListener('touchmove', events , false );
   window.removeEventListener('touchend' , events , false );
   mouseUpTime=new Date().getTime();
   if(mouseUpTime-mouseDownTime<=250){
    if(theIdOfTheKnee>=0){
     displayModalKnee(e);
     return;
    }else if(theIdOfTheCurrTabl<0 && theIdOfTheCurrField<0){
     if(Math.abs(delta.x)>3||Math.abs(delta.y)>4){
      delta.x=0;
      delta.y=0;
      return;
     }
     displayModalMoveTables(e);
     return;
    }
   }else{
    if(theIdOfTheCurrTabl>=0){
     
    }else if(theIdOfTheKnee>=0){
     return;
    }else if(theIdOfTheCurrField>=0){

     var targetTable=-1;
     var targetField=-1;
     for(var i=0;i<opt.data.length && targetField<0 ;i++){
      targetTable=i;
      for(var j=0;j<opt.data[i].fields.length && targetField<0 ;j++){
       if( endPosOnCanvas.x>=opt.data[i].fields[j].left && endPosOnCanvas.x<=(opt.data[i].fields[j].left + opt.data[i]['fld_width_table'])
        && endPosOnCanvas.y>=opt.data[i].fields[j].top  && endPosOnCanvas.y<=(opt.data[i].fields[j].top  + opt.hauteurBoite)
       ){
        targetField=j;
        break;
       }
      }
     }
     if(targetTable>=0&&targetField>=0){
      if(
          (targetTable==theIdOfTheCurrTablOfCurrentField&&targetField!=theIdOfTheCurrField)
       || (targetTable!=theIdOfTheCurrTablOfCurrentField)
      ){
       var newParent={
        fld_idParentField_field  : opt.data[theIdOfTheCurrTablOfCurrentField].fields[theIdOfTheCurrField]['fld_id_field'] ,
        fld_id_field             : opt.data[targetTable].fields[targetField]['fld_id_field'] ,
        fld_idBase_table         : opt.baseId
       };
       return;
      }
     }else{
      draw();
     }
    
    }
   }
  },
  //===============================================================================================================================
  mouseUp:function(event){
   if(opt.data['canvas']['mode']=='mode_field1' || opt.data['canvas']['mode']=='mode_link1') return;
   var touches=event;
   window.removeEventListener('mouseup'       , events, false);
   isMouseDownOrTouchDown=false;
   mouseUpTime=new Date().getTime();
   if(mouseUpTime-mouseDownTime<=250){
    if(theIdOfTheKnee>=0){
     displayModalKnee(event);
     return;
    }else if( theIdOfTheCurrTabl<0 && theIdOfTheCurrField<0 ){
     displayModalMoveTables(event);
     return;
    }
   }else{
    
    
    if(theIdOfTheCurrTabl>=0){
    }else if(theIdOfTheKnee>=0){
    }else if(theIdOfTheCurrField>=0){

     mousePosOnPage={x:touches.pageX,y: touches.pageY};
     delta={x:mousePosOnPage.x-startPosOnPage.x,y:mousePosOnPage.y-startPosOnPage.y};
     newPosX=startPosOnCanvas.x+delta.x; 
     if(newPosX<=0) newPosX=0;
     newPosY=startPosOnCanvas.y+delta.y; 
     if(newPosY<=0) newPosY=0;
    
     var targetTable=-1;
     var targetField=-1;
     
     
     for(var i=0;i<opt.data['tables'].length && targetField<0 ;i++){
      targetTable=i;
      for(var j=0;j<opt.data['tables'][i].fields.length && targetField<0 ;j++){
       
       if( newPosX>=opt.data['tables'][i].fields[j].left && newPosX<=(opt.data['tables'][i].fields[j].left + opt.data['tables'][i]['table']['fld_width_table'])
        && newPosY>=opt.data['tables'][i].fields[j].top  && newPosY<=(opt.data['tables'][i].fields[j].top  + opt.hauteurBoite)
       ){
        targetField=j;
        break;
       }
      }
     }
     if(targetTable>=0&&targetField>=0){
      if(
          (targetTable==theIdOfTheCurrTablOfCurrentField&&targetField!=theIdOfTheCurrField)
       || (targetTable!=theIdOfTheCurrTablOfCurrentField)
      ){
/*
       console.log('childTable  = ' + targetTable + ':' + opt.data['tables'][targetTable]['table']['fld_name_tables']);
       console.log('childField  = ' + targetField + ':' + opt.data['tables'][targetTable].fields[targetField]['nom_champ']);
       console.log('parentTable = ' + theIdOfTheCurrTablOfCurrentField + ':' + opt.data['tables'][theIdOfTheCurrTablOfCurrentField]['table']['fld_name_tables']);
       console.log('parentField = ' + theIdOfTheCurrField + ':' + opt.data['tables'][theIdOfTheCurrTablOfCurrentField].fields[theIdOfTheCurrField]['nom_champ']);
*/       
       var baforeAjax_theIdOfTheCurrField             =theIdOfTheCurrField;
       var beforeAjax_theIdOfTheCurrTablOfCurrentField=theIdOfTheCurrTablOfCurrentField;
       var beforeAjax_child_view                      =parseInt(opt.data['tables'][targetTable]['table']['fld_view_tables'],10);
       
       var r = new XMLHttpRequest();
       r.open("POST",'za_ajax.php?design1',true); // ajax_addLinkFromDesign1.php
       r.timeout=6000;
       r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
       r.onreadystatechange = function () {
        if (r.readyState != 4 || r.status != 200) return;
        try{
         var jsonRet=JSON.parse(r.responseText);
         if(jsonRet.status=='OK'){
          // creer un nouveau lien
          delete opt.data['tables'][targetTable].fields[targetField].parent;
          opt.data['tables'][targetTable].fields[targetField].parent={
           'db_id_link'                : parseInt(jsonRet.db_id_link,10),
           'fld_name_tables'           : opt.data['tables'][beforeAjax_theIdOfTheCurrTablOfCurrentField]['table']['fld_name_tables'] ,
           'fld_parent_field_pglnks'   : opt.data['tables'][beforeAjax_theIdOfTheCurrTablOfCurrentField].fields[baforeAjax_theIdOfTheCurrField]['nom_champ'] ,
           'fld_link_mandatory_pglnks' : true,
           'centerKnee'                : true,
           'parentOnLeft'              : false,
           'childOnRight'              : false,
           'kneeX'                     : 0,
           'kneeY'                     : 0,
          };       
          if(beforeAjax_child_view==1){
           opt.data['tables'][beforeAjax_theIdOfTheCurrTablOfCurrentField].fields[baforeAjax_theIdOfTheCurrField]['comment']=jsonRet.newComment;
          }
          draw();
          return;
         }else{
          console.error(r);
          return;
         }
        }catch(e){
         console.error(e,r);
         return;
        }
       };
       r.onerror=function(e){
        console.error('e=',e);
        return;
       }
       var data={
        funct           : 'design1',
        subFunct        : 'addLinkFromDesign1',
        parentTable     : opt.data['tables'][theIdOfTheCurrTablOfCurrentField]['table']['fld_id_tables']                ,
        childTable      : opt.data['tables'][targetTable]['table']['fld_id_tables']                                     ,
        parentField     : opt.data['tables'][theIdOfTheCurrTablOfCurrentField].fields[theIdOfTheCurrField]['nom_champ'] ,
        childField      : opt.data['tables'][targetTable].fields[targetField]['nom_champ']                              ,
        child_view      : opt.data['tables'][targetTable]['table']['fld_view_tables']                                   ,
        parentTableName : opt.data['tables'][theIdOfTheCurrTablOfCurrentField]['table']['fld_name_tables']              ,
        toto            : 1,
        actualComment   : opt.data['tables'][theIdOfTheCurrTablOfCurrentField].fields[theIdOfTheCurrField]['comment']   ,
        tato            : 1,
        comment         : '{"view_key_for":["'+opt.data['tables'][targetTable]['table']['fld_name_tables']+'"]}'        ,
        view_to_add     : opt.data['tables'][targetTable]['table']['fld_name_tables']                                   ,
       }
       r.send('data='+encodeURIComponent(JSON.stringify(data)));
       
       draw();
       return;
      }
      draw();
     }else{
      draw();
     }
     
    }
   }
  },
  //===============================================================================================================================
  mouseDownCanvas:function(event){
   if(opt.data['canvas']['mode']=='mode_field1' ){
    if(theIdOfTheCurrTabl>=0){
     fillFields(theIdOfTheCurrTabl);
    }else{
     document.getElementById('list_of_fields1').innerHTML='';
    }
    return;
   }
   if(opt.data['canvas']['mode']=='mode_link1' ){
    if(theIdOfTheKnee>=0){
     fillLinks(theIdOfTheKnee);
    }else{
     document.getElementById('list_of_fields1').innerHTML='';
    }
    return;
   }
   
   var touches=event;
   mouseDownTime=new Date().getTime();
   isMouseDownOrTouchDown=true;
   window.addEventListener('mouseup'       , events, false);
   startPosOnPage={x:touches.pageX,y: touches.pageY};
   startPosOnCanvas={x:startPosOnPage.x-posCanvas.left,y:startPosOnPage.y-posCanvas.top};
//   console.log('startPosOnCanvas=',startPosOnCanvas);
   isScrolling=undefined;
   delta = {};
  },
  //===============================================================================================================================
  touchStartCanvas:function(e){


   if(opt.data['canvas']['mode']=='mode_field1' || opt.data['canvas']['mode']=='mode_link1'  ){
    document.body.style.overflow='';
   }else{
    document.body.style.overflow='hidden';
   }
   mouseDownTime=new Date().getTime();
   var pos=opt.canvas.getBoundingClientRect();
   var posX=e.touches[0].clientX-pos.left;
   var posY=e.touches[0].clientY-pos.top;
   isMouseDownOrTouchDown=true;
   startPosOnCanvas={ x : posX               ,  y : posY               };
   startPosOnPage  ={ x : e.touches[0].pageX ,  y : e.touches[0].pageY };
   
   isScrolling = undefined;
   theIdOfTheCurrTabl               =-1;
   theIdOfTheKnee                   =-1;
   theIdOfTheCurrField              =-1;
   theIdOfTheCurrTablOfCurrentField =-1;
   for(var i=0;i<opt.data['tables'].length;i++){
    if( startPosOnCanvas.x>=opt.data['tables'][i]['table']['fld_left_table'] && startPosOnCanvas.x<=(opt.data['tables'][i]['table']['fld_left_table']+opt.data['tables'][i]['table']['fld_width_table'])
     && startPosOnCanvas.y>=opt.data['tables'][i]['table']['fld_top_table']  && startPosOnCanvas.y<=(opt.data['tables'][i]['table']['fld_top_table']+opt.hauteurBoite)
    ){
     theIdOfTheCurrTabl=i;
//     console.log('theIdOfTheCurrTabl='+theIdOfTheCurrTabl);
     break;
    }
   }
   
   if(theIdOfTheCurrTabl>=0){
    opt.canvas.style.cursor='move';
    initialTablePosition={x:opt.data['tables'][theIdOfTheCurrTabl]['table']['fld_left_table'],y:opt.data['tables'][theIdOfTheCurrTabl]['table']['fld_top_table']};
    
    if(opt.data['canvas']['mode']=='mode_field1' ){
     document.body.style.overflow='';

     if(theIdOfTheCurrTabl>=0){
//      console.log('touchStartCanvas',theIdOfTheCurrTabl);
      fillFields(theIdOfTheCurrTabl);
     }else{
      document.getElementById('list_of_fields1').innerHTML='';
     }
     return;
    }
    window.addEventListener('touchmove'    , events , false );
    window.addEventListener('touchend'     , events , false );
    return;
   }

   kneeTableIndex=-1;
   kneeFielIndex=-1; 
   for(var i=0;i<kneeTable.length;i++){
    if( startPosOnCanvas.x>=(kneeTable[i].kneeX-kneeRadius) && startPosOnCanvas.x<=(kneeTable[i].kneeX+kneeRadius)
     && startPosOnCanvas.y>=(kneeTable[i].kneeY-kneeRadius) && startPosOnCanvas.y<=(kneeTable[i].kneeY+kneeRadius)
    ){
     theIdOfTheKnee=i;
     kneeTableIndex=kneeTable[theIdOfTheKnee].tableIndex;
     kneeFielIndex =kneeTable[theIdOfTheKnee].fieldIndex;
     break;
    }
   }
   if(theIdOfTheKnee>=0){
    if(opt.data['canvas']['mode']=='mode_link1' ){
     document.body.style.overflow='';
     if(theIdOfTheKnee>=0){
      fillLinks(theIdOfTheKnee);
     }else{
      document.getElementById('list_of_fields1').innerHTML='';
     }
     return;
    }
    initialKneePosition={x:kneeTable[theIdOfTheKnee].kneeX,y:kneeTable[theIdOfTheKnee].kneeY};
    window.addEventListener('touchmove', events , false );
    window.addEventListener('touchend' , events , false );
    return;
   }
   theIdOfTheCurrTablOfCurrentField=-1;
   theIdOfTheCurrField=-1;
   for(var i=0;i<opt.data.length && theIdOfTheCurrField<0 ;i++){
    theIdOfTheCurrTablOfCurrentField=i;
    for(var j=0;j<opt.data[i].fields.length && theIdOfTheCurrField<0 ;j++){
     if( startPosOnCanvas.x>=opt.data[i].fields[j].left && startPosOnCanvas.x<=(opt.data[i].fields[j].left + opt.data[i]['fld_width_table'])
      && startPosOnCanvas.y>=opt.data[i].fields[j].top  && startPosOnCanvas.y<=(opt.data[i].fields[j].top  + opt.hauteurBoite)
     ){
      theIdOfTheCurrField=j;
      break;
     }
    }
   }
   if(theIdOfTheCurrField>=0){
    window.addEventListener('touchmove', events , false );
    window.addEventListener('touchend' , events , false );
    return;
   }
   window.addEventListener('touchmove', events , false );
   window.addEventListener('touchend' , events , false );
  },
  //===============================================================================================================================
  mouseMoveCanvas:function(event){

   var touches = event;
   if(modalIsOpen==true){
    
   }else{
    
    if(isMouseDownOrTouchDown==true){
     event.stopPropagation();
     event.preventDefault();
     
     if(theIdOfTheCurrTabl>=0){
//      console.log('theIdOfTheCurrTabl=',theIdOfTheCurrTabl);
      mousePosOnPage={x:touches.pageX,y: touches.pageY};
      delta={x:mousePosOnPage.x-startPosOnPage.x,y:mousePosOnPage.y-startPosOnPage.y};
      newPosX=initialTablePosition.x+delta.x; 
      if(newPosX<=0) newPosX=0;
      newPosY=initialTablePosition.y+delta.y; 
      if(newPosY<=0) newPosY=0;
      opt.data['tables'][theIdOfTheCurrTabl]['table']['fld_left_table']=newPosX;
      opt.data['tables'][theIdOfTheCurrTabl]['table']['fld_top_table']=newPosY;
      draw();
      
     }else if(theIdOfTheKnee>=0){
//      console.log('theIdOfTheKnee=',theIdOfTheKnee);
      
      mousePosOnPage={x:touches.pageX,y: touches.pageY};
      delta={x:mousePosOnPage.x-startPosOnPage.x,y:mousePosOnPage.y-startPosOnPage.y};
      newPosX=initialKneePosition.x+delta.x; 
      if(newPosX<=0) newPosX=0;
      newPosY=initialKneePosition.y+delta.y; 
      if(newPosY<=0) newPosY=0;
      opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent['kneeX']=newPosX;
      opt.data['tables'][kneeTable[theIdOfTheKnee]['tableIndex']]['fields'][kneeTable[theIdOfTheKnee]['fieldIndex']].parent['kneeY']=newPosY;
      draw();
      
     }else if(theIdOfTheCurrField>=0){
//      console.log('theIdOfTheCurrField=',theIdOfTheCurrField);
      
      mousePosOnPage={x:touches.pageX,y: touches.pageY};
      delta={x:mousePosOnPage.x-startPosOnPage.x,y:mousePosOnPage.y-startPosOnPage.y};
      newPosX=startPosOnCanvas.x+delta.x; 
      if(newPosX<=0) newPosX=0;
      newPosY=startPosOnCanvas.y+delta.y; 
      if(newPosY<=0) newPosY=0;
      
      draw();   
      opt.ctx.beginPath();
      opt.ctx.moveTo(startPosOnCanvas.x , startPosOnCanvas.y );
      opt.ctx.lineTo(newPosX            , newPosY            );
      opt.ctx.lineWidth = 3;
      opt.ctx.strokeStyle = '#ff0000';
      opt.ctx.lineCap = 'round';
      opt.ctx.stroke();
      
     }
     
    }else{
     
     startPosOnPage={x:touches.pageX,y: touches.pageY};
     startPosOnCanvas={x:startPosOnPage.x-posCanvas.left,y:startPosOnPage.y-posCanvas.top};
//     console.log('startPosOnCanvas',startPosOnCanvas);
//     console.log(startPosOnCanvas);
     isScrolling = undefined;
     theIdOfTheCurrTabl               =-1;
     theIdOfTheKnee                   =-1;
     theIdOfTheCurrField              =-1;
     theIdOfTheCurrTablOfCurrentField =-1;
//     console.log('aa=',opt.data['tables'][10]['table']['fld_left_table']);
     for(var i=0;i<opt.data['tables'].length;i++){
      if( startPosOnCanvas.x>=opt.data['tables'][i]['table']['fld_left_table'] && startPosOnCanvas.x<=(opt.data['tables'][i]['table']['fld_left_table']+opt.data['tables'][i]['table']['fld_width_table'])
       && startPosOnCanvas.y>=opt.data['tables'][i]['table']['fld_top_table']  && startPosOnCanvas.y<=(opt.data['tables'][i]['table']['fld_top_table']+opt.hauteurBoite)
      ){
       theIdOfTheCurrTabl=i;
//       console.log('theIdOfTheCurrTabl=',theIdOfTheCurrTabl);
       break;
      }
     }
     if(theIdOfTheCurrTabl>=0){
      opt.canvas.style.cursor='move';
      initialTablePosition={x:opt.data['tables'][theIdOfTheCurrTabl]['table']['fld_left_table'],y:opt.data['tables'][theIdOfTheCurrTabl]['table']['fld_top_table']};
      return;
     }else{
      opt.canvas.style.cursor='default';
     }
     if(opt.data['canvas']['mode']=='mode_field1'){
      return;
     }
     kneeTableIndex=-1;
     kneeFielIndex=-1; 
     for(var i=0;i<kneeTable.length;i++){
      if( startPosOnCanvas.x>=(kneeTable[i].kneeX-kneeRadius) && startPosOnCanvas.x<=(kneeTable[i].kneeX+kneeRadius)
       && startPosOnCanvas.y>=(kneeTable[i].kneeY-kneeRadius) && startPosOnCanvas.y<=(kneeTable[i].kneeY+kneeRadius)
      ){
       theIdOfTheKnee=i;
       kneeTableIndex=kneeTable[theIdOfTheKnee].tableIndex;
       kneeFielIndex =kneeTable[theIdOfTheKnee].fieldIndex;
       break;
      }
     }
     if(theIdOfTheKnee>=0){
      initialKneePosition={x:kneeTable[theIdOfTheKnee].kneeX,y:kneeTable[theIdOfTheKnee].kneeY};
      opt.canvas.style.cursor='move';
      return;
     }else{
      opt.canvas.style.cursor='default';
     }
     if(opt.data['canvas']['mode']=='mode_link1'){
      return;
     }
     

     
     theIdOfTheCurrTablOfCurrentField=-1;
     for(var i=0;i<opt.data['tables'].length && theIdOfTheCurrField<0 ;i++){
      theIdOfTheCurrTablOfCurrentField=i;
      for(var j=0;j<opt.data['tables'][i].fields.length && theIdOfTheCurrField<0 ;j++){
       if( startPosOnCanvas.x>=opt.data['tables'][i].fields[j].left && startPosOnCanvas.x<=(opt.data['tables'][i].fields[j].left + opt.data['tables'][i]['table']['fld_width_table'])
        && startPosOnCanvas.y>=opt.data['tables'][i].fields[j].top  && startPosOnCanvas.y<=(opt.data['tables'][i].fields[j].top  + opt.hauteurBoite)
       ){
        theIdOfTheCurrField=j;
        break;
       }
      }
     }
     if(theIdOfTheCurrField>=0){
      opt.canvas.style.cursor='crosshair';
     }else{
      opt.canvas.style.cursor='default';
     }
    }
   }
  }
 } 
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 
 
 var backgroundModal=null;
 var modalDiv=null;
 var headerModal=null;
 var closeModalButton=null;
 var bodyModal=null;
 var parentModal=null;
 var modalIsOpen=false;
 var initPositionMouseDown={};
 var initPositionModal={};
 
 //===============================================================================================================================
 //================================================= MODAL =======================================================================
 //===============================================================================================================================
 function mouseUpModal(event){
  window.removeEventListener('mousemove', mouseMoveModal , false );
  window.removeEventListener('mouseup'  , mouseUpModal   , false );
//  console.log(event);
 }
 //===============================================================================================================================
 function mouseMoveModal(event){
  event.stopPropagation();
  event.preventDefault();
  var deltaX=event.pageX-initPositionMouseDown.x;
  var newX=initPositionModal.x+deltaX;
  if(newX<=0) newX=0;
  var deltaY=event.pageY-initPositionMouseDown.y;
  var newY=initPositionModal.y+deltaY;
  if(newY<=0) newY=0;
  modalDiv.style.left=newX+'px';
  modalDiv.style.top=newY+'px';
 }
 //===============================================================================================================================
 function mouseDownHeaderModal(event){
  initPositionMouseDown={x:event.pageX,y:event.pageY};
  initPositionModal={x:parseInt(modalDiv.style.left,10),y:parseInt(modalDiv.style.top,10)};
  window.addEventListener('mousemove', mouseMoveModal , false );
  window.addEventListener('mouseup'  , mouseUpModal   , false );
//  console.log(event);
 }
 //===============================================================================================================================
 function touchEndModal(event){
  window.removeEventListener('touchmove' , touchMoveModal , false );
  window.removeEventListener('touchend'  , touchEndModal   , false );
//  console.log(event);
 }
 //===============================================================================================================================
 function touchMoveModal(e){
  event=e.touches[0];
  e.stopPropagation();
  e.preventDefault();
  var deltaX=event.pageX-initPositionMouseDown.x;
  var newX=initPositionModal.x+deltaX;
  if(newX<=0) newX=0;
  var deltaY=event.pageY-initPositionMouseDown.y;
  var newY=initPositionModal.y+deltaY;
  if(newY<=0) newY=0;
  modalDiv.style.left=newX+'px';
  modalDiv.style.top=newY+'px';
 }
 //===============================================================================================================================
 function touchStartHeaderModal(e){
  event=e.touches[0];
  initPositionMouseDown={x:event.pageX,y:event.pageY};
  initPositionModal={x:parseInt(modalDiv.style.left,10),y:parseInt(modalDiv.style.top,10)};
  window.addEventListener('touchmove', touchMoveModal , false );
  window.addEventListener('touchend' , touchEndModal  , false );
 }
 //===============================================================================================================================
 function buildModal(obj){
  parentModal=dogid(opt.parentDiv);
  var bckWidth=(parseInt(parentModal.style.width,10)-opt.parentBorder*2);
  var bckHeight=(parseInt(parentModal.style.height,10)-opt.parentBorder*2);
  
  backgroundModal=document.createElement('div');
  backgroundModal.style.top='0px';
  backgroundModal.style.left='0px';
  backgroundModal.style.width =bckWidth+'px';
  backgroundModal.style.height=bckHeight+'px';
  backgroundModal.style.backgroundColor='black';
  backgroundModal.style.opacity=0.5;
  backgroundModal.style.position='absolute';
  backgroundModal.style.display='block';
  parentModal.appendChild(backgroundModal);
  
  var childrenWidth=bckWidth;
  var childrenLeft=0;
  if(bckWidth>500){
   childrenWidth=500;
   childrenLeft=parseInt((bckWidth-500)/2,10);
  }
  
  var childrenHeight=bckHeight;
  var childrenTop=0;
  if(bckHeight>500){
   childrenHeight=500;
   childrenTop=parseInt((bckHeight-500)/2,10);
  }
  
  modalDiv=document.createElement('div');
  modalDiv.style.top=childrenTop+'px';
  modalDiv.style.left=childrenLeft+'px';
  modalDiv.style.width =childrenWidth+'px';
  modalDiv.style.maxHeight=childrenHeight+'px';
  modalDiv.style.backgroundColor='rgba(200,200,200,0.9)';
//  modalDiv.style.opacity=0.9;
  modalDiv.style.position='absolute';
  modalDiv.style.display='block';
  parentModal.appendChild(modalDiv);

  headerModal=document.createElement('div');
  headerModal.id='__headerModal';
  headerModal.style.top='0px';
  headerModal.style.left='0px';
  headerModal.style.height='24px';
  headerModal.style.backgroundColor='rgba(255,255,255,0.2)';
//  headerModal.style.opacity=1;
  headerModal.style.position='relative';
  headerModal.style.margin='2px';
  headerModal.style.display='block';
  headerModal.style.opacity=1;
  headerModal.style.cursor='move';
  modalDiv.appendChild(headerModal);
  headerModal.addEventListener('mousedown', mouseDownHeaderModal, false);
  if(is_touch_device()){
   headerModal.addEventListener('touchstart', touchStartHeaderModal, false);
  }
  

  closeModalButton=document.createElement('button');
  closeModalButton.style.backgroundColor='#999';
  closeModalButton.style.opacity=1;
  closeModalButton.style.lineHeight='24px';
  closeModalButton.style.color='red';
  closeModalButton.style.cursor='pointer';
  closeModalButton.style.float='right';
  headerModal.appendChild(closeModalButton);
  closeModalButton.innerHTML='&#10060;'; // &#10006; &#9587; x , X
  closeModalButton.addEventListener('click', closeModal, false);
  
  bodyModal=document.createElement('div');
  bodyModal.style.width ='100%';
  bodyModal.style.overflow='scroll';
  bodyModal.style.backgroundColor='white';
  bodyModal.style.opacity=1;
  bodyModal.style.position='relative';
  bodyModal.style.textAlign='center';
  bodyModal.id='bodyModal';
  modalDiv.appendChild(bodyModal);
 }
 //===============================================================================================================================
 function closeModal(event){
  modalIsOpen=false;
  if(event){
   event.stopPropagation();
   event.preventDefault();
  }
  modalDiv.style.display='none';
  backgroundModal.style.display='none';
 }
 //===============================================================================================================================
 function showModal(obj){
  if(backgroundModal==null){
   buildModal();
  }
  modalIsOpen=true;
  var bckWidth=(parseInt(parentModal.style.width,10)-opt.parentBorder*2);
  var bckHeight=(parseInt(parentModal.style.height,10)-opt.parentBorder*2);
  backgroundModal.style.width =bckWidth+'px';
  backgroundModal.style.height=bckHeight+'px';
  backgroundModal.style.display='block';
  modalDiv.style.left=(obj.x)+'px';
  modalDiv.style.top =(obj.y)+'px';
  modalDiv.style.display='block';
  bodyModal.innerHTML='';
  bodyModal.appendChild(obj.bodyModalContent)
 } 
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 function draw(){
   var top=0,left=0,width=0,widthText=0,height=0,txt='',txtMetrics=0,idParent=0;
   kneeTable=[];
   height=parseInt(opt.hauteurBoite,10)-2;
   opt.ctx.clearRect(0, 0, opt.canvas.width, opt.canvas.height);
 //  return;
   
   if(theIdOfTheCurrTabl>=0){
//    console.log(theIdOfTheCurrTabl);
    var phase=[theIdOfTheCurrTabl,theIdOfTheCurrTabl] ; // phase 0 on dessine les autres tables, phase 1 on dessine la table ctive
   }else{
    var phase=[-1];
   }
//   console.log(phase.length);
   var doIt=true;
   for(var numPhase=0;numPhase<phase.length;numPhase++){
     for(var i=0;i<opt.data['tables'].length;i++){
       if(opt.data['tables'][i].table.displayed){
       
         doIt=false;
         if(phase.length==1){
          doIt=true;
         }else{
          if(numPhase==0&&i!=theIdOfTheCurrTabl){
           doIt=true;  // phase 0 on dessine les autres tables
          }else{
           if(numPhase==1&&i==theIdOfTheCurrTabl){
            doIt=true; // phase 1 on dessine la table active
           }else{
            doIt=false;
           }
          }
         }
         if(doIt){       
           opt.ctx.save();
           opt.ctx.beginPath();
           opt.data['tables'][i]['table']['fld_left_table']=parseInt(opt.data['tables'][i]['table']['fld_left_table'],10);
           opt.data['tables'][i]['table']['fld_top_table'] =parseInt(opt.data['tables'][i]['table']['fld_top_table'],10);
           top=opt.data['tables'][i]['table']['fld_top_table'];
           left=opt.data['tables'][i]['table']['fld_left_table'];
           width=0; //eTable.width;
           opt.ctx.font = (height-6)+'px Arial';
           
           if(top<=0){
             top=0;
             opt.data['tables'][i]['table']['fld_top_table']=top;
           }
           if(left<=0){
             left=0;
             opt.data['tables'][i]['table']['fld_left_table']=left;
           }
           txt=opt.data['tables'][i]['table']['fld_name_tables'];
           txtMetrics = opt.ctx.measureText(txt);
           widthText = txtMetrics.width;
           if(width<(widthText+4)){
             width=widthText+4;
             opt.data['tables'][i]['table']['fld_width_table']=width;
           }
           
           for(var j=0;j<opt.data['tables'][i].fields.length;j++){
             txt=opt.data['tables'][i].fields[j]['nom_champ'];
             txtMetrics = opt.ctx.measureText(txt);
             widthText = txtMetrics.width;
             if((widthText+4)>width){
              width=widthText+4;
             }
           }
           opt.data['tables'][i]['table']['fld_width_table']=width;
           
           if(opt.data['tables'][i]['table']['fld_view_tables']==1){
            // viewBox
            opt.ctx.fillStyle = '#eeeeee';
           }else{
            // tableBox
            opt.ctx.fillStyle = 'yellow';
           }
           opt.ctx.rect(left , top , width , height );
           opt.ctx.lineWidth = 2;
           opt.ctx.strokeStyle = 'black';
           opt.ctx.fill();
           opt.ctx.stroke();
           
           opt.ctx.save();
           opt.ctx.beginPath();
           opt.ctx.textAlign    = 'left';
           opt.ctx.textBaseline = 'top';
           opt.ctx.fillStyle    = '#00f';
           opt.ctx.strokeStyle  = '#fff';
           
           // table name
           opt.ctx.fillText( 
             opt.data['tables'][i]['table']['fld_name_tables']     , 
             parseInt((opt.data['tables'][i]['table']['fld_left_table']+2),10) , 
             parseInt(opt.data['tables'][i]['table']['fld_top_table'],10) +3
           );

           opt.ctx.stroke();
           opt.ctx.restore();
           
           for(var j=0;j<opt.data['tables'][i].fields.length;j++){
             top=top+height;
            
             idParent=opt.data['tables'][i].fields[j]['T0.fld_idParentField_field'];
             
             opt.data['tables'][i].fields[j].top=top;
             opt.data['tables'][i].fields[j].left=left;
             opt.data['tables'][i].fields[j].width=width;
             opt.ctx.save();
             opt.ctx.beginPath();
             opt.data['tables'][i].fields[j].top =top +0.5;
             opt.data['tables'][i].fields[j].left=left+0.5;
             opt.data['tables'][i].fields[j].width=width;
             opt.ctx.rect(left+0.5 , top+0.5 , width-1 , height );
             opt.ctx.fillStyle = '#fff';
             opt.ctx.fill();
             opt.ctx.lineWidth = 1;
             opt.ctx.strokeStyle = 'black';
             opt.ctx.stroke();
             opt.ctx.save();
             opt.ctx.beginPath();
             opt.ctx.fillStyle    = 'black';
             opt.ctx.textBaseline = 'top';
             txt=opt.data['tables'][i].fields[j]['nom_champ'];
             opt.ctx.fillText(txt, left+2, top+3);
             opt.ctx.stroke();
             opt.ctx.restore();
             opt.ctx.stroke();
             opt.ctx.restore();
           }
         }
       }
     }
   }
   
   var connectorRadius=3;
   var childPositionX=0,childPositionY=0,parentPositionX=0,parentPositionY=0,connectorRadius=3;
   
   for(var i=0;i<opt.data['tables'].length;i++){
     if(opt.data['tables'][i].table.displayed){
       for(var j=0;j<opt.data['tables'][i].fields.length;j++){
         if(opt.data['tables'][i].fields[j].parent){
           for(var k=0;k<opt.data['tables'].length;k++){
             if(opt.data['tables'][k].table.displayed && opt.data['tables'][i].fields[j].parent.fld_name_tables ==  opt.data['tables'][k]['table']['fld_name_tables'] ){
               for(var l=0;l<opt.data['tables'][k].fields.length;l++){
                 if(opt.data['tables'][k].fields[l]['nom_champ'] == opt.data['tables'][i].fields[j].parent.fld_parent_field_pglnks){
                   var champParent =opt.data['tables'][k].fields[l]['nom_champ'];
                   var champEnfant =opt.data['tables'][i].fields[j]['nom_champ'];
                   var tableParente=opt.data['tables'][k]['table']['fld_name_tables'];
                   var tableEnfant =opt.data['tables'][i]['table']['fld_name_tables'];
                   // le champ parent est dans une des tables affichées
 /*                 
                   console.log('parent of ' + txt + ' is ' + opt.data['tables'][i].fields[j].parent.fld_parent_field_pglnks + '\n' , 
                    opt.data['tables'][i].fields[j].parent  ,
                    opt.data['tables'][k].fields[l]         ,   // from ( parent )
                    opt.data['tables'][i].fields[j]             // to   ( enfant )
                   );
 */                  
                   opt.data['tables'][i].fields[j].parent.childX=opt.data['tables'][i].fields[j].left;
                   if(opt.data['tables'][i].fields[j].parent.childOnRight==true){
                    opt.data['tables'][i].fields[j].parent.childX+=opt.data['tables'][i].fields[j].width;
                   }
                   childPositionX=opt.data['tables'][i].fields[j].parent.childX;

                   opt.data['tables'][i].fields[j].parent.childY=opt.data['tables'][i].fields[j].top;
                   childPositionY=opt.data['tables'][i].fields[j].parent.childY;

                   opt.data['tables'][i].fields[j].parent.parentX=opt.data['tables'][k].fields[l].left;
                   if(opt.data['tables'][i].fields[j].parent.parentOnLeft==false){
                    opt.data['tables'][i].fields[j].parent.parentX+=opt.data['tables'][k].fields[l].width;
                   }
                   parentPositionX=opt.data['tables'][i].fields[j].parent.parentX;
                   opt.data['tables'][i].fields[j].parent.ParentY=opt.data['tables'][k].fields[l].top;
                   parentPositionY=opt.data['tables'][i].fields[j].parent.ParentY;
                   
   
                   if(opt.data['tables'][i].fields[j].parent.centerKnee==true || opt.data['tables'][i].fields[j].parent.kneeX===0 || opt.data['tables'][i].fields[j].parent.kneeY===0){
                     opt.data['tables'][i].fields[j].parent.kneeX=parseInt(
                      (childPositionX+parentPositionX)/2
                      ,10
                     );
                     
                     opt.data['tables'][i].fields[j].parent.kneeY=parseInt(
                      (childPositionY+parseInt(height/2,10)+parentPositionY+parseInt(height/2,10))/2
                      ,10
                     );
                     opt.data['tables'][i].fields[j].parent.centerKnee=true;
                   }else{
                     opt.data['tables'][i].fields[j].parent.centerKnee=false;
                   }

                   var kneeColor='yellow';
                   if(opt.data['tables'][i].fields[j].parent.centerKnee==false){
                     kneeColor='gold';
                   }
                   var linkColor='#ff0000';
                   if(opt.data['tables'][i].fields[j].parent.fld_link_mandatory_pglnks==0){
                     linkColor='pink';
                   }
                   
                   // ligne pere centre
                   opt.ctx.beginPath();
                   opt.ctx.moveTo(
                     parentPositionX, 
                     parentPositionY+parseInt(height/2,10)
                   );
                   opt.ctx.lineTo(
                     opt.data['tables'][i].fields[j].parent.kneeX , 
                     opt.data['tables'][i].fields[j].parent.kneeY
                   );
                   opt.ctx.lineWidth = 2;
                   opt.ctx.strokeStyle = linkColor;
                   opt.ctx.lineCap = 'round';
                   opt.ctx.stroke();
                   
                   
                   
                   // ligne centre fils
                   opt.ctx.beginPath();
                   opt.ctx.moveTo(
                     opt.data['tables'][i].fields[j].parent.kneeX          , 
                     opt.data['tables'][i].fields[j].parent.kneeY          
                   );
                   opt.ctx.lineTo(
                     childPositionX , 
                     childPositionY+parseInt(height/2,10) 
                   );
                   opt.ctx.lineWidth = 2;
                   opt.ctx.strokeStyle = linkColor;
                   opt.ctx.lineCap = 'round';
                   opt.ctx.stroke();
                   
                   // cercle centre
                   opt.ctx.beginPath();
                   opt.ctx.arc(
                     opt.data['tables'][i].fields[j].parent.kneeX , 
                     opt.data['tables'][i].fields[j].parent.kneeY , 
                     kneeRadius , 
                     0 , 
                     2 * Math.PI, 
                     false
                   );
                   opt.ctx.fillStyle = kneeColor;
                   opt.ctx.fill();
                   opt.ctx.lineWidth = 1;
                   opt.ctx.strokeStyle = '#ff0000';
                   opt.ctx.stroke();    
                   
                   // hugues displayModalKnee
                   kneeTable[kneeTable.length]={
                     parentField       : opt.data['tables'][k].fields[l],
                     childField        : opt.data['tables'][i].fields[j],
                     tableName         : opt.data['tables'][i]['table']['fld_name_tables'] ,
                     fld_view_tables   : parseInt(opt.data['tables'][i]['table']['fld_view_tables'],10) ,
                     parentTableIndex  : k ,
                     tableIndex        : i ,
                     fieldIndex        : j ,
                     'fld_id_field'    : j, // opt.data['tables'][i].fields[j]['fld_id_field'] ,
                     field             : opt.data['tables'][i].fields[j]                 ,
                     parentOnLeft                    : opt.data['tables'][i].fields[j].parent.parentOnLeft                    ,
                     childOnRight                    : opt.data['tables'][i].fields[j].parent.childOnRight                    ,
                     kneeX                           : opt.data['tables'][i].fields[j].parent.kneeX                           ,
                     kneeY                           : opt.data['tables'][i].fields[j].parent.kneeY                           ,
                     centerKnee                      : opt.data['tables'][i].fields[j].parent.centerKnee                      ,
                     fld_link_mandatory_pglnks       : opt.data['tables'][i].fields[j].parent.fld_link_mandatory_pglnks       ,
                     db_id_link                      : opt.data['tables'][i].fields[j].parent.db_id_link                      ,
                     fld_parent_field_display_pglnks : opt.data['tables'][i].fields[j].parent.fld_parent_field_display_pglnks ,
                   };
                   
                   

                    
                   // parent circle
                   opt.ctx.beginPath();
                   opt.ctx.arc(
                     parentPositionX , 
                     parentPositionY + parseInt(height/2,10), 
                     connectorRadius , 
                     0 , 
                     2 * Math.PI, 
                     false
                   );
                   opt.ctx.fillStyle = 'blue';
                   opt.ctx.fill();
                   opt.ctx.lineWidth = 1;
                   opt.ctx.strokeStyle = '#0000ff';
                   opt.ctx.stroke();    
                   
                   
                   // child circle
                   opt.ctx.beginPath();
                   opt.ctx.arc(
                     opt.data['tables'][i].fields[j].parent.childX , 
                     opt.data['tables'][i].fields[j].parent.childY + parseInt(height/2,10), 
                     connectorRadius , 
                     0 , 
                     2 * Math.PI, 
                     false
                   );
                   opt.ctx.fillStyle = 'green';
                   opt.ctx.fill();
                   opt.ctx.lineWidth = 1;
                   opt.ctx.strokeStyle = '#00ff00';
                   opt.ctx.stroke();    
                   
                 }
               }
             }
           }
         }
       }
     }
   }
 }
 //===============================================================================================================================
 //===============================================================================================================================
 //=============================================================================================================================== 
 var initPosResizCanvas={};
 var initSizeResizCanvas={};
 var deltaResizCanvas={};
 var bodyHeight=0;
 var resizerDiv=null;
 var simCanvasDiv=null;

 //====================================================================================================
 function mouseDownResize(e){

  var posDivCanvas=opt.divContainer.getBoundingClientRect();
//  console.log(posDivCanvas);
 
  initPosResizCanvas={x:e.pageX,y:e.pageY};
  initSizeResizCanvas={
   x           : parseInt(posDivCanvas.left,10) ,
   y           : parseInt(posDivCanvas.top,10),
   resizeLeft  : parseInt(resizeCanvas.style.left,10) ,
   resizeTop   : parseInt(resizeCanvas.style.top,10),
   topCanvas   : parseInt(posDivCanvas.top,10),
  };
  window.addEventListener('mousemove', mouseMoveResize , false);
  window.addEventListener('mouseup'  , mouseUpResize   , false);
 }
 
 //====================================================================================================
 function mouseMoveResize(e){
  e.stopPropagation();
  e.preventDefault();
  deltaResizCanvas={x:e.pageX-initPosResizCanvas.x,y:e.pageY-initPosResizCanvas.y};
  
  var newX=initSizeResizCanvas.resizeLeft+deltaResizCanvas.x;
  if(newX<opt.minWidth){
   newX=opt.minWidth;
  }
  newX=parseInt(newX,10);
  resizeCanvas.style.left=newX+'px';
  resizeCanvas.style.top=(initSizeResizCanvas.resizeTop+deltaResizCanvas.y)+'px';
  
  var newY=initSizeResizCanvas.resizeTop+deltaResizCanvas.y;
  if(newY<opt.minHeight+initSizeResizCanvas.topCanvas){
   newY=opt.minHeight+initSizeResizCanvas.topCanvas;
  }
  newY=parseInt(newY,10);
  resizeCanvas.style.left=newX+'px';
  resizeCanvas.style.top=newY+'px';
 }

 
 //====================================================================================================
 function touchStartResize(e){ // hugues
  if(opt.data['canvas']['mode']=='mode_field1' || opt.data['canvas']['mode']=='mode_link1'  ){
   document.body.style.overflow='';
   return;
  }else{
   document.body.style.overflow='hidden';
  }

  
  var posDivCanvas=opt.divContainer.getBoundingClientRect();
//  console.log(posDivCanvas);
  
  initPosResizCanvas={x:e.touches[0].pageX,y:e.touches[0].pageY};
  initSizeResizCanvas={
   x           : parseInt(posDivCanvas.left,10) ,
   y           : parseInt(posDivCanvas.top,10),
   resizeLeft  : parseInt(resizeCanvas.style.left,10) ,
   resizeTop   : parseInt(resizeCanvas.style.top,10),
   topCanvas   : parseInt(posDivCanvas.top,10),
  };
  window.addEventListener('touchmove' , touchMoveResize , false);
  window.addEventListener('touchend'  , touchEndResize   , false);
 } 
 //====================================================================================================
 function touchMoveResize(e){
  e.stopPropagation();
  deltaResizCanvas={x:e.touches[0].pageX-initPosResizCanvas.x,y:e.touches[0].pageY-initPosResizCanvas.y};
  var newX=initSizeResizCanvas.resizeLeft+deltaResizCanvas.x;
  if(newX<opt.minWidth){
   newX=opt.minWidth;
  }
  newX=parseInt(newX,10);
  resizeCanvas.style.left=newX+'px';
  resizeCanvas.style.top=(initSizeResizCanvas.resizeTop+deltaResizCanvas.y)+'px';
  var newY=initSizeResizCanvas.resizeTop+deltaResizCanvas.y;
  if(newY<opt.minHeight+initSizeResizCanvas.topCanvas+18){
   newY=opt.minHeight+initSizeResizCanvas.topCanvas+18;
  }
  newY=parseInt(newY,10);
  resizeCanvas.style.left=newX+'px';
  resizeCanvas.style.top=newY+'px';
 }
 //====================================================================================================
 function mouseUpResize(e){
  window.removeEventListener('mousemove', mouseMoveResize , false);
  window.removeEventListener('mouseup'  , mouseUpResize   , false);
  var posDivCanvas=opt.divContainer.getBoundingClientRect();
  var posResiz=resizeCanvas.getBoundingClientRect();
  var newWidth  = parseInt(posResiz.left - posDivCanvas.left , 10 )+countHandleWidth*opt.handleHeight;
  var newHeight = parseInt(posResiz.top  - posDivCanvas.top  , 10 );
  opt.canvas.width =newWidth;
  opt.canvas.height=newHeight;
  opt.data['canvas']['width'] =newWidth;
  opt.data['canvas']['height']=newHeight;
  draw();
 }

 //====================================================================================================
 function touchEndResize(e){
  document.body.style.overflow='';
  window.removeEventListener('touchmove' , touchMoveResize , false);
  window.removeEventListener('touchend'  , touchEndResize   , false);
  var posDivCanvas=opt.divContainer.getBoundingClientRect();
  var posResiz=resizeCanvas.getBoundingClientRect();
  var newWidth  = parseInt(posResiz.left - posDivCanvas.left , 10 )+countHandleWidth*opt.handleHeight;
  var newHeight = parseInt(posResiz.top  - posDivCanvas.top  , 10 );
  opt.canvas.width =newWidth;
  opt.canvas.height=newHeight;
  opt.data['canvas']['width'] =newWidth;
  opt.data['canvas']['height']=newHeight;
  draw();
 }
 
 
 //====================================================================================================
 function _save1(){
  var r = new XMLHttpRequest();
  r.open("POST",'za_ajax.php?design1',true); // ajax_writeGeneratedFile2.php
  r.timeout=6000;
  r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
  r.onreadystatechange = function () {
   if (r.readyState != 4 || r.status != 200) return;
   try{
    var jsonRet=JSON.parse(r.responseText);
    if(jsonRet.status=='OK'){
     alert('Good job !');
     return;
    }else{
     console.error(r);
     alert('BAD job !');
     return;
    }
   }catch(e){
    console.error(e,r);
   }
  };
  r.onerror=function(e){
   console.error('e=',e);
  }
  var data={
   funct          : 'design1',
   subFunct       : 'saveDesign1',
   design1        : opt.data     ,
  }
  r.send('data='+encodeURIComponent(JSON.stringify(data)));  
 }
 
 //===============================================================================================================================
 function fillLinks(idOfTheCurrKnee){ // mode_link1 kneeTable
  var txt1='';
  var knee=kneeTable[idOfTheCurrKnee];
  var childTableIndex=knee.tableIndex;
  var childFieldIndex=knee.fieldIndex;
  var parentTableId=knee.parentTableIndex;
  var fieldsPresent=[];
  
  txt1+='<div style="margin-left:5px;">display fields = "';
  if(knee.fld_parent_field_display_pglnks){
   if(knee.fld_parent_field_display_pglnks!=''){
//    console.log(knee.fld_parent_field_display_pglnks);
    fieldsPresent=knee.fld_parent_field_display_pglnks.split(',');
   }    
  }
  txt1+=''+(fieldsPresent.join(','))+'';
  txt1+='"</div>';
  
  
  for(var i=0;i<opt.data['tables'][parentTableId].fields.length;i++){
   txt1+='<tr>';
   
   txt1+='<td style="text-align:center;">';
   txt1+=opt.data['tables'][parentTableId].fields[i]['nom_champ'];
   txt1+='</td>';
   
   txt1+='<td style="text-align:center;">';
   var founded=false;
   for(var j=0;j<fieldsPresent.length;j++){
    if(opt.data['tables'][parentTableId].fields[i]['nom_champ']===fieldsPresent[j]){
     founded=true;
     txt1+='<a href="javascript:myDraw1.removeLinkDisplayField1(';
     txt1+= ''+idOfTheCurrKnee+',';
     txt1+= ''+knee.db_id_link+',';
     txt1+= '\''+fieldsPresent[j]+'\',';
     txt1+= '\''+fieldsPresent.join(',')+'\'';
     txt1+=')" class="danger">remove</a>';
    }
   }
   if(founded==false){
    txt1+='<a href="javascript:myDraw1.addLinkDisplayField1(';
    txt1+= ''+idOfTheCurrKnee+',';
    txt1+= ''+knee.db_id_link+',';
    txt1+= '\''+opt.data['tables'][parentTableId].fields[i]['nom_champ']+'\',';
    txt1+= '\''+fieldsPresent.join(',')+'\'';
    txt1+=')" class="">add</a>';
   }
   txt1+='</td>';

   
   txt1+='</tr>';
  }
  if(txt1!=''){
   txt1='<table style="margin-bottom:50px;margin-left:5px;"><thead><tr><th>field</th><th>action</th></thead><tbody>'+txt1+'</tbody></table>';
  }
  document.getElementById('list_of_fields1').innerHTML=txt1;
  return;   

 }
 //===============================================================================================================================
 function _removeLinkDisplayField1(idOfTheCurrKnee,db_id_link,nom_champ,actualList){
   var r = new XMLHttpRequest();
   r.open("POST",'za_ajax.php?design1',true); // ajax_writeGeneratedFile2.php
   r.timeout=6000;
   r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
   r.onreadystatechange = function () {
    if (r.readyState != 4 || r.status != 200) return;
    try{
     var jsonRet=JSON.parse(r.responseText);
     if(jsonRet.status=='OK'){
      
//      console.log(jsonRet);
      var knee=kneeTable[jsonRet.input.idOfTheCurrKnee];
      var childTableIndex=knee.tableIndex;
      var childFieldIndex=knee.fieldIndex;
      
      kneeTable[jsonRet.input.idOfTheCurrKnee].fld_parent_field_display_pglnks=jsonRet.newList;
      opt.data['tables'][childTableIndex].fields[childFieldIndex].fld_parent_field_display_pglnks=jsonRet.newList;
      
      fillLinks(jsonRet.input.idOfTheCurrKnee);
      return;
     }else{
      console.error(r.responseText);
      alert('BAD job !');
      return;
     }
    }catch(e){
     console.error(e,r);
    }
   };
   r.onerror=function(e){
    console.error('e=',e);
   }
   var data={
    funct                : 'design1'                 ,
    subFunct             : 'removeLinkDisplayField1' ,
    nom_champ            : nom_champ                 ,
    idOfTheCurrKnee      : idOfTheCurrKnee           ,
    db_id_link           : db_id_link                ,
    actualList           : actualList
   }
   r.send('data='+encodeURIComponent(JSON.stringify(data)));     
 }
 
 //===============================================================================================================================
 function _addLinkDisplayField1(idOfTheCurrKnee,db_id_link,nom_champ,actualList){
   var r = new XMLHttpRequest();
   r.open("POST",'za_ajax.php?design1',true); // ajax_writeGeneratedFile2.php
   r.timeout=6000;
   r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
   r.onreadystatechange = function () {
    if (r.readyState != 4 || r.status != 200) return;
    try{
     var jsonRet=JSON.parse(r.responseText);
     if(jsonRet.status=='OK'){
      
//      console.log(jsonRet);
      var knee=kneeTable[jsonRet.input.idOfTheCurrKnee];
      var childTableIndex=knee.tableIndex;
      var childFieldIndex=knee.fieldIndex;
      
      kneeTable[jsonRet.input.idOfTheCurrKnee].fld_parent_field_display_pglnks=jsonRet.newList;
      opt.data['tables'][childTableIndex].fields[childFieldIndex].fld_parent_field_display_pglnks=jsonRet.newList;
      
      fillLinks(jsonRet.input.idOfTheCurrKnee);
      return;
     }else{
      console.error(r);
      alert('BAD job !');
      return;
     }
    }catch(e){
     console.error(e,r);
    }
   };
   r.onerror=function(e){
    console.error('e=',e);
   }
   var data={
    funct                : 'design1'              ,
    subFunct             : 'addLinkDisplayField1' ,
    nom_champ            : nom_champ              ,
    idOfTheCurrKnee      : idOfTheCurrKnee        ,
    db_id_link           : db_id_link             ,
    actualList           : actualList             
   }
   r.send('data='+encodeURIComponent(JSON.stringify(data)));     
 }
 //===============================================================================================================================
 function jsonSyntaxHighlight(json){
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
        var cls = 'number';
        if (/^"/.test(match)) {
            if (/:$/.test(match)) {
                cls = 'key';
            } else {
                cls = 'string';
            }
        } else if (/true|false/.test(match)) {
            cls = 'boolean';
        } else if (/null/.test(match)) {
            cls = 'null';
        }
        return '<span class="' + cls + '">' + match + '</span>';
    });
 }
 //===============================================================================================================================
 function fillFields(idOfTheCurrTabl){
  if(opt.data['tables'][idOfTheCurrTabl]['table']['fld_view_tables']==1){
   document.getElementById('list_of_fields1').innerHTML='';
   return;
  }
  var txt1='';
  var nomChamp='';
  var doIt=true;
  
  
  var typeTime=false;
  var typeParam=false;
  var typeString=false;
  var typeNumeric=false;
  var typeAutoIncrement=false;
  var typeSet=false;
  var typeDateOrTime=false;
  var typeText=false;
  var typeDatetime=false;
  var typeDate=false;
  var typeBlob=false;
  var hasParentOrAutoIncrement=false;
  
  
//  console.log(idOfTheCurrTabl);
  for(var i=0;i<opt.data['tables'][idOfTheCurrTabl].fields.length;i++){
   
   typeTime=false;
   typeParam=false;
   typeString=false;
   typeNumeric=false;
   typeAutoIncrement=false;
   typeSet=false;
   typeDateOrTime=false;
   typeText=false;
   typeDatetime=false;
   typeDate=false;
   typeBlob=false;
   hasParentOrAutoIncrement=false;
   
   
   txt1+='<tr>';
   
   txt1+='<td class="thinBorder" style="width:15%;word-break:break-word;">';
   if(opt.data['tables'][idOfTheCurrTabl].fields[i].parent){
    hasParentOrAutoIncrement=true;
    txt1+='<span class="badge0">Has parent</span>';
    txt1+='<br />';
   }
   txt1+=''+i+'';
   txt1+='<br />';
   txt1+=''+opt.data['tables'][idOfTheCurrTabl].fields[i]['nom_champ']+'';
   nomChamp=opt.data['tables'][idOfTheCurrTabl].fields[i]['nom_champ'];
   txt1+='<br />';
   if(opt.data['tables'][idOfTheCurrTabl].fields[i]['extra'].indexOf('auto_increment')>=0){
    txt1+='<span class="badge1">'+opt.data['tables'][idOfTheCurrTabl].fields[i]['extra']+'</span>';
    typeAutoIncrement=true;
    hasParentOrAutoIncrement=true;
   }
   txt1+='<br />';
   txt1+='NULL:'+opt.data['tables'][idOfTheCurrTabl].fields[i]['null_possible']+'';
   txt1+='<br />';
   txt1+='TYPE:'+opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ']+'';
   if(
       opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ'].indexOf('char(')>=0
    || opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ'].indexOf('text')>=0
   ){
    typeString=true;
   }else if(
       opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ'].indexOf('int(')>=0
    || opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ'].indexOf('decimal(')>=0
   ){
    typeNumeric=true;
   }else if(
       opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ'].indexOf('blob')>=0
   ){
    typeBlob=true;
   }else if(
       opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ'].substr(0,4)=='set('
   ){
    typeSet=true;
   }else if(
       opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ'].indexOf('time')>=0
    || opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ'].indexOf('date')>=0
   ){
    typeDateOrTime=true;
    if( opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ'].indexOf('datetime')>=0 ){
     typeDatetime=true;
    }
    if(opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ']=='date'){
     typeDate=true;
    }
   }else if(
       opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ'].indexOf('text')>=0
   ){
    typeText=true;
   }
   
   
   if(opt.data['tables'][idOfTheCurrTabl].fields[i]['type_champ']=='time'){
    typeTime=true;
   }
   
   txt1+='</td>';
   
   
   txt1+='<td  style="width:25%;word-break:break-word;font-size:0.9em;white-space:pre;font-famimy:monospace;">';
   if(opt.data['tables'][idOfTheCurrTabl].fields[i]['comment']==''){
   }else{
    var prettystr = JSON.stringify(JSON.parse(opt.data['tables'][idOfTheCurrTabl].fields[i]['comment']), null, 1); // spacing level = 2 
    txt1+=''+prettystr+'';
    if(opt.data['tables'][idOfTheCurrTabl].fields[i]['comment'].indexOf('"param"')>=0){
     typeParam=true;
    }
   }
   txt1+='</td>';
   
   
   
   txt1+='<td>';
   if(opt.data['tables'][idOfTheCurrTabl].fields[i]['comment']!=''){
    
    txt1+='<a href="javascript:myDraw1.clearComment1(';
    txt1+= ''+idOfTheCurrTabl+',';
    txt1+= ''+opt.data['tables'][idOfTheCurrTabl]['table']['fld_id_server_tables']+',';
    txt1+= '\''+opt.data['tables'][idOfTheCurrTabl]['table']['fld_name_tables']+'\',';
    txt1+= '\''+opt.data['tables'][idOfTheCurrTabl].fields[i]['nom_champ']+'\'';
    txt1+=')" class="danger">clear props</a>';
    
   }
   
   
   var PropTable=[
     {'prop':{"showDeleteField":true   },'test':false},
     {'prop':{"showDeleteField":false  },'test':false},
     
     {'prop':{"subtype":"webcolor"     },'test':false,'notForParam':true,'notForAutoIncrement':true,'notForDateTime':true,'notForNumeric':true},
     {'prop':{"subtype":"password"     },'test':false,'notForParam':true,'notForAutoIncrement':true,'notForDateTime':true,'notForNumeric':true},
     {'prop':{"subtype":"pictureInDb"  },'test':false,'notForParam':true,'notForAutoIncrement':true,'notForDateTime':true,'onlyForBlob':true},
     
     {'prop':{"isUser":true            },'test':false,'notForParam':true,'notForDateTime':true}, // todo
     {'prop':{"isUser":false           },'test':false,'notForParam':true,'notForDateTime':true}, // todo
     {'prop':{"isGroup":true           },'test':false,'notForParam':true,'notForDateTime':true}, // todo
     {'prop':{"isGroup":false          },'test':false,'notForParam':true,'notForDateTime':true}, // todo
     
     {'prop':{"timeOption":1           },'test':false,'forTypeTime':true},
     {'prop':{"timeOption":2           },'test':false,'forTypeTime':true},
     {'prop':{"timeOption":3           },'test':false,'forTypeTime':true},
     {'prop':{"timeOption":4           },'test':false,'forTypeTime':true},
     {'prop':{"timeOption":5           },'test':false,'forTypeTime':true},
     {'prop':{"timeOption":6           },'test':false,'forTypeTime':true},
     {'prop':{"timeOption":7           },'test':false,'forTypeTime':true},
     
     {'prop':{"cntupd":true            },'test':false,'isCntupd':true},
     {'prop':{"cntupd":false           },'test':false,'isCntupd':true},
     {'prop':{"tscrt":true             },'test':false,'isTsCrtUpd':true},
     {'prop':{"tscrt":false            },'test':false,'isTsCrtUpd':true},
     {'prop':{"tsupd":true             },'test':false,'isTsCrtUpd':true},
     {'prop':{"tsupd":false            },'test':false,'isTsCrtUpd':true},
     {'prop':{"dtupd":true             },'test':false,'isTsDtUpd':true},  // todo
     {'prop':{"dtupd":false            },'test':false,'isTsDtUpd':true},  // todo
     {'prop':{"dtcrt":true             },'test':false,'isTsDtUpd':true},  // todo
     {'prop':{"dtcrt":false            },'test':false,'isTsDtUpd':true},  // todo
     {'prop':{"isUser":true            },'test':false,'isTsCrtUpd':true}, // todo
     {'prop':{"isUser":false           },'test':false,'isTsCrtUpd':true}, // todo
     
     {'prop':{"tests":{"email":true}       },'test':true ,'notForParam':true,'notForNumeric':true,'notForDateTime':true},
     {'prop':{"tests":{"email":false}      },'test':true ,'notForParam':true,'notForNumeric':true,'notForDateTime':true},
     {'prop':{"tests":{"min":0}            },'test':true ,'notForParam':true,'notForDateTime':true},
     {'prop':{"tests":{"max":100}          },'test':true ,'notForParam':true,'notForDateTime':true},
     {'prop':{"tests":{"notVoid":true}     },'test':true ,'notForParam':true},
     {'prop':{"tests":{"notVoid":false}    },'test':true ,'notForParam':true},
     {'prop':{"tests":{"mustNumeric":true} },'test':true }, // todo
     {'prop':{"tests":{"mustNumeric":false}},'test':true }, // todo
     {'prop':{"tests":{"mustPhone":true}   },'test':true },
     {'prop':{"tests":{"mustPhone":false}  },'test':true },
     {'prop':{"tests":{"todo":true}        },'test':true },
     {'prop':{"tests":{"todo":false}       },'test':true },
     
     {'prop':{"unsetPossible":false    },'test':false,'forTypeParam':true,'notForDateTime':true,'notForNumeric':false},
     {'prop':{"unsetPossible":true     },'test':false,'forTypeParam':true,'notForDateTime':true,'notForNumeric':false},
     {'prop':{"dropDown":true          },'test':false,'forTypeParam':true,'notForDateTime':true,'notForNumeric':false},
     {'prop':{"dropDown":false         },'test':false,'forTypeParam':true,'notForDateTime':true,'notForNumeric':false},
     {'prop':{"set":true               },'test':false,'forTypeParam':true,'notForDateTime':true,'notForNumeric':false},
     {'prop':{"set":false              },'test':false,'forTypeParam':true,'notForDateTime':true,'notForNumeric':false},
     
   ];

   // ajout des paramètres yorno ,,,  
   for(var j=0;j<globParamList.length;j++){
    PropTable.push({'prop':{"param":globParamList[j]},'test':false,'isParam':true});
   }
  
   var currentParam={}; 
   try{
    currentParam=JSON.parse(opt.data['tables'][idOfTheCurrTabl].fields[i]['comment']);
   }catch(e){
   }
   var txtHid1='';
   for(var j=0;j<PropTable.length;j++){
     
     
//      if(nomChamp=='xxx' && PropTable[j].prop.unsetPossible){
//        debugger;
//      }
     
     doIt=true;
     if(hasParentOrAutoIncrement){
      doIt=false;
     }

     if(typeTime==false && PropTable[j].forTypeTime && PropTable[j].forTypeTime==true ){
      doIt=false;
     }
     if(typeParam==false && PropTable[j].forTypeParam && PropTable[j].forTypeParam==true ){
      doIt=false;
     }
     if(typeParam==true && PropTable[j].notForParam &&  PropTable[j].notForParam==true ){
      doIt=false;
     }
     if(typeAutoIncrement==true && PropTable[j].isParam &&  PropTable[j].isParam==true ){
      doIt=false;
     }
     if(typeAutoIncrement==true && PropTable[j].notForAutoIncrement &&  PropTable[j].notForAutoIncrement==true ){
      doIt=false;
     }
     if(typeNumeric==true && PropTable[j].notForNumeric &&  PropTable[j].notForNumeric==true ){
      doIt=false;
     }
     if(typeDateOrTime==true && PropTable[j].isParam &&  PropTable[j].isParam==true ){
      doIt=false;
     }
     if(typeDateOrTime==true && PropTable[j].notForDateTime &&  PropTable[j].notForDateTime==true ){
      doIt=false;
     }
     if(typeBlob==true ){
      if( !( PropTable[j].onlyForBlob &&  PropTable[j].onlyForBlob==true ) ){
       doIt=false;
      }
     }else{
      if( ( PropTable[j].onlyForBlob &&  PropTable[j].onlyForBlob==true ) ){
       doIt=false;
      }
     }
     if( PropTable[j].isUser &&  PropTable[j].isUser==true  ){
      if(!typeNumeric){
       doIt=false;
      }
     }
     if( PropTable[j].isCntupd &&  PropTable[j].isCntupd==true  ){
      if(!typeNumeric){
       doIt=false;
      }
     }
     if( PropTable[j].isTsCrtUpd &&  PropTable[j].isTsCrtUpd==true  ){
      if(!typeDatetime){
       doIt=false;
      }
     }
     if( PropTable[j].isTsDtUpd &&  PropTable[j].isTsDtUpd==true  ){
      if(!typeDate){
       doIt=false;
      }
     }
     
     if(PropTable[j].prop.hasOwnProperty('showDeleteField') && (PropTable[j].prop.showDeleteField==true || PropTable[j].prop.showDeleteField==false)){
       doIt=true;
     }
     
     
     if(doIt){
       if(opt.data['tables'][idOfTheCurrTabl].fields[i]['comment']==''){
        var actualComment={};
       }else{
        var actualComment=JSON.parse(opt.data['tables'][idOfTheCurrTabl].fields[i]['comment']);
       }
       var cssClass='';
       if(PropTable[j].prop.tests){
        cssClass='success';
       }else if(PropTable[j].prop.param){
        cssClass='edit';
       }
       txt1+='<a href="javascript:myDraw1.addComment1(';
       txt1+= ''+idOfTheCurrTabl+',';
       txt1+= ''+opt.data['tables'][idOfTheCurrTabl]['table']['fld_id_server_tables']+',';
       txt1+= '\''+opt.data['tables'][idOfTheCurrTabl]['table']['fld_name_tables']+'\',';
       txt1+= '\''+opt.data['tables'][idOfTheCurrTabl].fields[i]['nom_champ']+'\',';
       txt1+= '\''+encodeURIComponent(JSON.stringify(PropTable[j].prop))+'\',';
       txt1+= '\''+encodeURIComponent(JSON.stringify(actualComment))+'\','; // actualComment
       txt1+= ''+(PropTable[j]['test']?1:0)+'';
       
       txt1+=')" class="'+cssClass+'">'+j+' '+JSON.stringify(PropTable[j].prop)+'</a>';
     }else{
//        txtHid1+='<span class="btn unset edit">'+j+' '+JSON.stringify(PropTable[j].prop)+' </span>'
     }

   }
 
   txt1+=txtHid1;
    
   txt1+='</td>';
   txt1+='</tr>';
  }
  if(txt1!=''){
   txt1='<table style="margin-bottom:50px;"><thead><tr><th>field</th><th>actual prop</th><th>action</th></thead><tbody>'+txt1+'</tbody></table>';
  }
  document.getElementById('list_of_fields1').innerHTML=txt1;
  return;   
 }
 //====================================================================================================
 function _addComment1(theIdOfTheCurrTabl,fld_id_server_tables,fld_name_tables,nom_champ,comment,actualComment,isTestProp){
//  console.log('comment='+comment+', theIdOfTheCurrTabl=' + theIdOfTheCurrTabl);
  
   var r = new XMLHttpRequest();
   r.open("POST",'za_ajax.php?design1',true); // ajax_writeGeneratedFile2.php
   r.timeout=6000;
   r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
   r.onreadystatechange = function () {
    if (r.readyState != 4 || r.status != 200) return;
    try{
     var jsonRet=JSON.parse(r.responseText);
     if(jsonRet.status=='OK'){
      
//      console.log(jsonRet);
      for(var i=0;i<opt.data['tables'][jsonRet.input.theIdOfTheCurrTabl].fields.length;i++){
        if(opt.data['tables'][jsonRet.input.theIdOfTheCurrTabl].fields[i].nom_champ===jsonRet.input.nom_champ){
          opt.data['tables'][jsonRet.input.theIdOfTheCurrTabl].fields[i].comment=jsonRet.newComment;
        }
      }
      fillFields(jsonRet.input.theIdOfTheCurrTabl);

      return;
     }else{
      console.error(r);
      alert('BAD job !');
      return;
     }
    }catch(e){
     console.error(e,r);
    }
   };
   r.onerror=function(e){
    console.error('e=',e);
   };
   var data={
    funct                : 'design1'            ,
    subFunct             : 'addComment1'      ,
    nom_champ            : nom_champ            ,
    fld_name_tables      : fld_name_tables      ,
    fld_id_server_tables : fld_id_server_tables ,
    theIdOfTheCurrTabl   : theIdOfTheCurrTabl   ,
    comment              : comment              ,
    actualComment        : actualComment        ,
    isTestProp           : isTestProp
   }
//   console.log('data=',data);
   r.send('data='+encodeURIComponent(JSON.stringify(data)));    
  
 } 
 //====================================================================================================
 function _clearComment1(theIdOfTheCurrTabl,fld_id_server_tables,fld_name_tables,nom_champ){
  
   var r = new XMLHttpRequest();
   r.open("POST",'za_ajax.php?design1',true); // ajax_writeGeneratedFile2.php
   r.timeout=6000;
   r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
   r.onreadystatechange = function () {
    if (r.readyState != 4 || r.status != 200) return;
    try{
     var jsonRet=JSON.parse(r.responseText);
     if(jsonRet.status=='OK'){
//      console.log(jsonRet);
      for(var i=0;i<opt.data['tables'][jsonRet.input.theIdOfTheCurrTabl].fields.length;i++){
        if(opt.data['tables'][jsonRet.input.theIdOfTheCurrTabl].fields[i].nom_champ===jsonRet.input.nom_champ){
          opt.data['tables'][jsonRet.input.theIdOfTheCurrTabl].fields[i].comment='';
        }
      }
      fillFields(jsonRet.input.theIdOfTheCurrTabl);
      return;
     }else{
      console.error(r);
      alert('BAD job !');
      return;
     }
    }catch(e){
     console.error(e,r);
    }
   };
   r.onerror=function(e){
    console.error('e=',e);
   }
   var data={
    funct                : 'design1'            ,
    subFunct             : 'clearComment1'      ,
    nom_champ            : nom_champ            ,
    fld_name_tables      : fld_name_tables      ,
    fld_id_server_tables : fld_id_server_tables ,
    theIdOfTheCurrTabl   : theIdOfTheCurrTabl   ,
   }
   r.send('data='+encodeURIComponent(JSON.stringify(data)));    
  
 }
 
 //====================================================================================================
 function _addTable1(fld_name_tables,fld_id_server_tables){
  var r = new XMLHttpRequest();
  r.open("POST",'za_ajax.php?design1',true); // ajax_writeGeneratedFile2.php
  r.timeout=6000;
  r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
  r.onreadystatechange = function () {
   if (r.readyState != 4 || r.status != 200) return;
   try{
    var jsonRet=JSON.parse(r.responseText);
    if(jsonRet.status=='OK'){
     document.location=String(document.location);
     return;
    }else{
     console.error(r.responseText);
     alert('BAD job !');
     return;
    }
   }catch(e){
    console.error(e,r);
   }
  };
  r.onerror=function(e){
   console.error('e=',e);
  }
  var data={
   funct                : 'design1',
   subFunct             : 'addTable1',
   fld_id_server_tables : fld_id_server_tables,
   fld_name_tables      : fld_name_tables
  }
  r.send('data='+encodeURIComponent(JSON.stringify(data)));    
 }
 
 //====================================================================================================
 function _addTableRefForView1(view_name,fld_id_server_tables,fld_id_reftbl_of_view_tables){
  var r = new XMLHttpRequest();
  r.open("POST",'za_ajax.php?design1',true); // ajax_writeGeneratedFile2.php
  r.timeout=6000;
  r.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
  r.onreadystatechange = function () {
   if (r.readyState != 4 || r.status != 200) return;
   try{
    var jsonRet=JSON.parse(r.responseText);
    if(jsonRet.status=='OK'){
     document.location=String(document.location);
     return;
    }else{
     console.error(r.responseText);
     alert('BAD job !');
     return;
    }
   }catch(e){
    console.log(e,r);
   }
  };
  r.onerror=function(e){
   console.log('e=',e);
  }
  var data={
   funct                        : 'design1'                    ,
   subFunct                     : 'addView1'                   ,
   fld_id_server_tables         : fld_id_server_tables         ,
   fld_id_reftbl_of_view_tables : fld_id_reftbl_of_view_tables ,
   view_name                    : view_name
  }
  r.send('data='+encodeURIComponent(JSON.stringify(data)));    
 }
 //====================================================================================================
 function displayModalSelectRefTableForView(view_name,fld_id_server_tables){
  //var fieldIdDB=opt.data[kneeTableIndex].fields[kneeFielIndex]['fld_id_field'];
//  console.log(theIdOfTheKnee, kneeTable[theIdOfTheKnee]);
  var modalcontent=document.createElement('div');

  var span=document.createElement('span');
  span.innerHTML='Select the reference table for the view ';
  modalcontent.appendChild(span);
  var br=document.createElement('br');modalcontent.appendChild(br);
  for(var i=0;i<opt.data['tables'].length;i++){
   if(opt.data['tables'][i]['table']['fld_system_tables']==0){
    var button=document.createElement('a');
    button.innerHTML=opt.data['tables'][i]['table']['fld_name_tables'];
    button.className='';
    button.href='javascript:myDraw1.addTableRefForView1(\''+view_name+'\','+fld_id_server_tables+','+opt.data['tables'][i]['table']['fld_id_tables']+')';
    modalcontent.appendChild(button);
   }
  }
  
  var can=document.getElementById('canvas1');
  var dim=can.getBoundingClientRect();
  var y=dim.top;
  var x=parseInt((dim.width-450)/2,10);
  showModal({
   bodyModalContent   : modalcontent       ,
   event              : null               ,
   x                  : x ,
   y                  : y
  });
 }
 
 //====================================================================================================
 function _addView1(view_name,fld_id_server_tables){
  displayModalSelectRefTableForView(view_name,fld_id_server_tables);
 }
 
 //====================================================================================================
 function _setDesignMode1(modeName){
   opt.data['canvas']['mode']=modeName;
   var arr=['mode_table1','mode_field1','mode_link1'];
   for(var i=0;i<arr.length;i++){
    document.getElementById(arr[i]).className='';
   }
   document.getElementById(modeName).className='edit';
   document.getElementById('list_of_fields1').innerHTML='';
 }
 //====================================================================================================
 function _activateTable2(parTableName){
//   console.log('parTableName=',parTableName);
   for(var i=0;i<opt.data['tables'].length;i++){
     if(opt.data['tables'][i].table.fld_name_tables===parTableName){
       if(opt.data['tables'][i].table.displayed){
        opt.data['tables'][i].table.displayed=false;
        document.getElementById('link1_'+parTableName).className='';
       }else{
        opt.data['tables'][i].table.displayed=true;
        document.getElementById('link1_'+parTableName).className='edit';
       }
       draw();
       return;
     }
   }
 }
 
 
 
 
 //====================================================================================================
 var posDivCanvas=opt.divContainer.getBoundingClientRect();
 var countHandleWidth=5;
 var resizeCanvas=null;
 resizeCanvas=document.createElement('div');
 resizeCanvas.className='edit';
 resizeCanvas.style.opacity=0.5;
 resizeCanvas.style.width  =countHandleWidth*opt.handleHeight+'px';
 resizeCanvas.style.height =opt.handleHeight+'px';
 resizeCanvas.style.position='absolute';
 resizeCanvas.style.left   =(parseInt(opt.canvas.width ,10)-countHandleWidth*opt.handleHeight+2*opt.canvasBorder)+'px';
 resizeCanvas.style.top    =(parseInt(posDivCanvas.bottom,10)+window.scrollY)+'px';
 resizeCanvas.style.cursor ='nw-Resize';
 resizeCanvas.innerHTML='<div style="position:absolute;right:0;bottom:0;font-size:2em;line-height:'+opt.handleHeight+'px;margin-bottom:-4px;">&#8690;</div>';
 
 parentModal=dogid(opt.parentDiv);
 parentModal.appendChild(resizeCanvas);
 if(browser.touch){
  resizeCanvas.addEventListener('touchstart', touchStartResize , false);
 }else{
  resizeCanvas.addEventListener('mousedown' , mouseDownResize , false);
 }
 
 
 // console.log(opt);

 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 draw();
 if(browser.touch){
  opt.canvas.addEventListener( 'touchstart' , events , false );
 }else{
  opt.canvas.addEventListener('mousedown' , events, false);
  window.addEventListener('mousemove'     , events, false); // mouse move et mouse up sur window car la souris peut dépasser les bords du canvas
 }
//  window.addEventListener('mouseup'       , events, false);
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
 
 return {
  draw                   : function()             { draw();                               },
  activateTable2         : function(p)            { _activateTable2(p);                   },
  addTable1              : function(n,i)          { _addTable1(n,i);                      },
  addView1               : function(n,i)          { _addView1(n,i);                       },
  setDesignMode1         : function(n)            { _setDesignMode1(n);                   },
  clearComment1          : function(i,d,t,f)      { _clearComment1(i,d,t,f);              },
  addComment1            : function(i,d,t,f,c,a,z){ _addComment1(i,d,t,f,c,a,z);          },
  removeLinkDisplayField1: function(k,i,f,a)      { _removeLinkDisplayField1(k,i,f,a);    },
  addLinkDisplayField1   : function(k,i,f,a)      { _addLinkDisplayField1(k,i,f,a);       },
  addTableRefForView1    : function(n,i,j)        { _addTableRefForView1(n,i,j);          },
  
  save1                  : function()             { _save1();                             }
 } 
 //===============================================================================================================================
 //===============================================================================================================================
 //===============================================================================================================================
}