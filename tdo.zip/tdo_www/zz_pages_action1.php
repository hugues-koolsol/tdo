<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
require_once $GLOBALS['glob_incPath1'].'/zz_inc_pages1.php';

openDb1();
//========================================================================================================================
function btl1(){
 return '&nbsp;<a href="zz_pages.php" class="btn btn-sm btn-primary">'.txtsys1('back_to_the_list').'</a>';
}
//========================================================================================================================
function test_input_tdo_pagesKO1(){
 $err=0;
 if($err==0&&$_SESSION[PGMK][NAV][BNF]['fld_name_pages']==''){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('fld_name_pages must not be empty_17_92');
  $err=1;
 }
 return($err);
}
if(isset($_POST)&&sizeof($_POST)>=1){ // post action
 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= POST ACTIONS  =====================================================================
 //=================================================================================================================================
 //=================================================================================================================================
// echo __LINE__ . '$_POST=<pre>' . var_export($_POST,true) . '</pre>'; exit();
 $_SESSION[PGMK][NAV][BNF]['fld_name_pages']       =isset($_POST['fld_name_pages'])       ?$_POST['fld_name_pages']       : '';
 $_SESSION[PGMK][NAV][BNF]['fld_menu_pages']       =isset($_POST['fld_menu_pages'])       ?$_POST['fld_menu_pages']       : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_isajax_pages']     =isset($_POST['fld_isajax_pages'])     ?$_POST['fld_isajax_pages']     : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_isremote_pages']   =isset($_POST['fld_isremote_pages'])   ?$_POST['fld_isremote_pages']   : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_isuser_pages']     =isset($_POST['fld_isuser_pages'])     ?$_POST['fld_isuser_pages']     : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_localadmin_pages'] =isset($_POST['fld_localadmin_pages']) ?$_POST['fld_localadmin_pages'] : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_isaction_pages']   =isset($_POST['fld_isaction_pages'])   ?$_POST['fld_isaction_pages']   : 0;
 $_SESSION[PGMK][NAV][BNF]['fld_parent_pages']     =isset($_POST['fld_parent_pages'])     ?$_POST['fld_parent_pages']     : 0;

 // dependant field 
 if(!(isset($_POST['a'])&&($_POST['a']=='cd'||$_POST['a']=='cd'))){ // NOT confirm delete
  $_SESSION[PGMK][NAV][BNF]['choose__fld_parent_pages'] =isset($_POST['choose__fld_parent_pages'] )?$_POST['choose__fld_parent_pages']  :'';
  if($_SESSION[PGMK][NAV][BNF]['choose__fld_parent_pages']==txtsys1('text_for_the_select_button')){
   $_SESSION[PGMK]['choose']['urlBack']=$_SERVER['HTTP_ORIGIN'].$_SERVER['REQUEST_URI'];
   header("HTTP/1.1 303 See Other");header('Location: zz_pages_choose1.php'); // todo check 
   exit();
  }
 }
 
 //=================================================================================================================================
 //============================================= POST UPDATE =======================================================================
 //=================================================================================================================================
 if(isset($_POST['a'])&&$_POST['a']=='u'){ // update action
  if(test_input_tdo_pagesKO1()){
   if(isset($_POST['id1'])&&is_numeric($_POST['id1'])){
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=u&id='.$_POST['id1']);
    exit();
   }else{
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : POST id1 = ' . $_POST['id1'];
    header("HTTP/1.1 303 See Other");header('Location: index.php');
    exit();
   }
  }
  $req6="UPDATE `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__pages` SET
      `fld_name_pages`       = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_name_pages'])       ."'
    , `fld_menu_pages`       =  ".$_SESSION[PGMK][NAV][BNF]['fld_menu_pages']                   ."
    , `fld_isajax_pages`     =  ".$_SESSION[PGMK][NAV][BNF]['fld_isajax_pages']                 ."
    , `fld_isremote_pages`   =  ".$_SESSION[PGMK][NAV][BNF]['fld_isremote_pages']               ."
    , `fld_isuser_pages`     =  ".$_SESSION[PGMK][NAV][BNF]['fld_isuser_pages']                 ."
    , `fld_localadmin_pages` =  ".$_SESSION[PGMK][NAV][BNF]['fld_localadmin_pages']             ."
    , `fld_isaction_pages`   =  ".$_SESSION[PGMK][NAV][BNF]['fld_isaction_pages']               ."
    , `fld_parent_pages`     =  ".$_SESSION[PGMK][NAV][BNF]['fld_parent_pages']                 ."
    , `fld_tsupd_pages`      = '".addslashes($GLOBALS['glob_setdate'])                          ."'
    , `fld_cntupd_pages`     =  " . ((int)$_POST['fld_cntupd_pages']+1)                         ."
  ";
  $req6.="
   WHERE `fld_id_pages`=".$_POST['id1']."
     AND `fld_cntupd_pages` = ".$_POST['fld_cntupd_pages']."
  ";
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
     break;
    default   :
     $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
     txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    break;
   }
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
  }else{
   if(mysqli_affected_rows($GLOBALS['glob_db'][0]['link'])!=1){
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('this_record_has_not_been_updated_because_of_an_other_user');
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('please_retry');
    unset($_SESSION[PGMK][NAV][BNF]['fld_name_pages']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_menu_pages']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_isajax_pages']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_isremote_pages']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_isuser_pages']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_localadmin_pages']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_isaction_pages']);
    unset($_SESSION[PGMK][NAV][BNF]['fld_parent_pages']);
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&id='.$_POST['id1']); exit();
   }
   writePageList();
   require_once $GLOBALS['glob_incPath1'].'/zz_inc_grpspgs1.php';
   updateGrpPgsFiles1();
   $_SESSION[PGMK][NAV][BNF]['message'][]=txtsys1('the_modification_has_been_recorded_at') . ' ' . substr($GLOBALS['glob_setdate'],11);
   
   if(isset($_POST['record_the_element_and_back_to_list'])){
    header("HTTP/1.1 303 See Other");header('Location: zz_pages.php');
    exit();
   }else if(isset($_POST['record_the_element_and_go_to_group_pages'])){
    header("HTTP/1.1 303 See Other");header('Location: zz_grpspgs.php?xsrch_idgr1=1');
    exit();    
   }else{
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=n&id='.$_POST['id1']);
    exit();
   }
  }
 //=================================================================================================================================
 //============================================= POST CONFIRM DELETE ===============================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='cd'){

  $xvalueName=getPages1($_POST['id1']);
  // on efface les pages attachées au groupe 1 qui a toutes les pages autorisées
  $req6="
   DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__grpspgs` WHERE
        `fld_group_id_grpspgs`  = 1
    AND `fld_page_id_grpspgs`   =  ".$_POST['id1']."
  " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  
  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__langvalues` WHERE `fld_page_id_lngVals` = ".$_POST['id1']." " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  
  require_once $GLOBALS['glob_incPath1'].'/__tableDependencies1.php';
  $retDependantTables=dependentValuesExist1(0,'tdo_tbl__pages',$_POST['id1'] );
  if(true === $retDependantTables['valuesExist']){
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error') . ' ' . __LINE__ . ' ' . txtsys1('you_cannot_delete_because_some_values_are_still_present_in_dependant_table') . ' ' . var_export( $retDependantTables['tables'] , true ) . ' ';
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=d&id='.$_POST['id1']);   
  }

//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $_POST , true ) . '</pre>' ; exit(0);
  $req6="DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__pages` WHERE `fld_id_pages`=".$_POST['id1']." " ;
  $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
   $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
   txtlog1($xtxterr , BNF , __LINE__ , 'error' );
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=d&id='.$_POST['id1']);
   exit();
  }else{
   writePageList();
   foreach($GLOBALS['glob__availableLanguages'] as $k1 => $v1){
    @unlink($GLOBALS['glob_noVcPath1'].'/translation_for_pages/'.$k1.'_'.$xvalueName['fld_name_pages']);
   }   
   unset($_SESSION[PGMK][NAV][BNF]);
   require_once $GLOBALS['glob_incPath1'].'/zz_inc_grpspgs1.php';
   updatePagesOfGroups();
   updateMenus();
   updateGrpPgsFiles1();
   header("HTTP/1.1 303 See Other");header('Location: zz_pages.php');
   exit();

  }
 //=================================================================================================================================
 //============================================= POST CREATE ACTION ================================================================
 //=================================================================================================================================
 }else if(isset($_POST['a'])&&$_POST['a']=='c'){
  if(test_input_tdo_pagesKO1()){
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
   exit();
  }
  $req6="
   INSERT INTO `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__pages` SET
      `fld_name_pages`       = '".addslashes1($_SESSION[PGMK][NAV][BNF]['fld_name_pages'])     ."'
    , `fld_menu_pages`       =  ".$_SESSION[PGMK][NAV][BNF]['fld_menu_pages']                 ."
    , `fld_isajax_pages`     =  ".$_SESSION[PGMK][NAV][BNF]['fld_isajax_pages']               ."
    , `fld_isremote_pages`   =  ".$_SESSION[PGMK][NAV][BNF]['fld_isremote_pages']             ."
    , `fld_isuser_pages`     =  ".$_SESSION[PGMK][NAV][BNF]['fld_isuser_pages']               ."
    , `fld_localadmin_pages` =  ".$_SESSION[PGMK][NAV][BNF]['fld_localadmin_pages']           ."
    , `fld_isaction_pages`   =  ".$_SESSION[PGMK][NAV][BNF]['fld_isaction_pages']             ."
    , `fld_parent_pages`     =  ".$_SESSION[PGMK][NAV][BNF]['fld_parent_pages']               ."
    , `fld_tsupd_pages`      = '".addslashes($GLOBALS['glob_setdate'])                        ."'
    , `fld_tscrt_pages`      = '".addslashes($GLOBALS['glob_setdate'])                        ."'
  " ;
//  echo __FILE__ . ' ' . __LINE__ . ' $req6 =' . $req6 . '' ; exit();
  $res6=@mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
  if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
   switch(mysqli_errno($GLOBALS['glob_db'][0]['link'])){
    case 1062 :
     $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('this_record_already_exist');
    break;
    default;
    $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    break;
   }
   header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
   exit();
  }else{
   $resIns=mysqli_query($GLOBALS['glob_db'][0]['link'],'SELECT LAST_INSERT_ID()');
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])!=0){
    $xtxterr=txtsys1('error').' ' . __LINE__ . ' mysqli_error='. mysqli_error($GLOBALS['glob_db'][0]['link']) . 'req=' . $req6 . txtsys1('please_retry') ;
    $_SESSION[PGMK][NAV][BNF]['errormessage'][]=$xtxterr;
    txtlog1($xtxterr , BNF , __LINE__ , 'error' );
    header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=c');
    exit();
   }else{
    $NewCode=mysqli_fetch_row($resIns);
    $NewCode=$NewCode[0];
    mysqli_free_result($resIns);
    writePageList();   
    SetSessionMessageAndLog1( txt2('the new value has been inserted_160_36') . ' ('.$NewCode.').' , BNF , __LINE__ , 3);
    if(isset($_POST['record_the_element_and_back_to_list'])){
     header("HTTP/1.1 303 See Other");header('Location: zz_pages.php');
     exit();
    }else if(isset($_POST['record_the_element_and_go_to_group_pages'])){
     header("HTTP/1.1 303 See Other");header('Location: zz_grpspgs.php?xsrch_idgr1=1');
     exit();    
    }else{
     header("HTTP/1.1 303 See Other");header('Location: '.BNF.'?a=u&t=n&id='.$NewCode);
     exit();
    }
   }
  }
 }
 
}else{ // get action

 //=================================================================================================================================
 //=================================================================================================================================
 //============================================= GET ACTION ========================================================================
 //=================================================================================================================================
 //=================================================================================================================================
 $o1=htmlHead1(array());
 $js1=array();
// echo __LINE__ . '$_SESSION[PGMK]=<pre>' . var_export( $_SESSION[PGMK] , true ) . '</pre>'; exit();
 //=================================================================================================================================
 //============================================= GET DELETE ========================================================================
 //=================================================================================================================================
 if(isset($_GET['a'])&&$_GET['a']=='d'){ // delete action
  $id=(isset($_GET['id'])&&is_numeric($_GET['id']))?$_GET['id']:0;
  if($id==0){
   header("HTTP/1.1 303 See Other");header('Location: zz_pages.php');
   exit();
  }else{
   $xvalueName=getPages1($_GET['id']);
   if($xvalueName['fld_name_pages']==''){
    $_SESSION[PGMK][NAV]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txtsys1('you_cannot_delete_this_value');
    header("HTTP/1.1 303 See Other");header('Location: zz_pages.php');
    exit();
   }else{
    // on efface les pages attachées au groupe 1 qui a toutes les pages autorisées
    $req6="
     DELETE FROM `".$GLOBALS['glob_db'][0]['dbname']."`.`tdo_tbl__grpspgs` WHERE
          `fld_group_id_grpspgs`  = 1
      AND `fld_page_id_grpspgs`   =  ".$_GET['id']."
    " ;
    $res6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
    require_once $GLOBALS['glob_incPath1'].'/__tableDependencies1.php';
    $retDependantTables=dependentValuesExist1(0,'tdo_tbl__pages',$_GET['id'] );
    if(isset($retDependantTables['valuesExist']) && $retDependantTables['valuesExist']==true){
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <div>'.CRLF;
     $o1.=' '.txtsys1('dependent_values_exist').''.CRLF;
     $o1.=' <ul>'.CRLF;
     foreach( $retDependantTables['tables'] as $k1 => $v1){
      $o1.='  <li>'.$v1.'</li>'.CRLF;
     }
     $o1.=' </ul>'.CRLF;
     $o1.=' </div>'.CRLF;
     $o1.=btl1();
    }else{
     $o1.=displaySessionMessage1(BNF);
     $o1.=' <form method="post" class="formDelete">'.CRLF;
     $o1.='   '.txtsys1('please_confirm_deletion_of').' : '.CRLF;
     $o1.='   <br /><br /><b>'.enti1($xvalueName['fld_name_pages']).'</b><br /><br />'.CRLF;
     $o1.='   <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
     $o1.='   <input type="hidden" value="cd" name="a" id="a" />'."\r\n";
     $o1.='   <button type="submit" class="danger">'.txtsys1('i_confirm_the_deletion_button').'</button>'.CRLF;
     $o1.=btl1();
     $o1.=' </form>'."\r\n";
    }
   }
  }
 //=================================================================================================================================
 //============================================= GET UPDATE ========================================================================
 //=================================================================================================================================
 
 }else if(isset($_GET['a'])&&$_GET['a']=='u'){ // update action
  $xxxFldValues=array();
  $js1=array();
  $o1.='<h4>'.txt2('update a record_225_20').' ('.$_GET['id'].')'.btl1().'</h4>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $name2=getPages1($_GET['id']);
  $xxxFldValues['fld_name_pages']       =isset( $_SESSION[PGMK][NAV][BNF]['fld_name_pages'] )       ? $_SESSION[PGMK][NAV][BNF]['fld_name_pages']       : $name2['fld_name_pages']       ;
  $xxxFldValues['fld_menu_pages']       =isset( $_SESSION[PGMK][NAV][BNF]['fld_menu_pages'] )       ? $_SESSION[PGMK][NAV][BNF]['fld_menu_pages']       : $name2['fld_menu_pages']       ;
  $xxxFldValues['fld_isajax_pages']     =isset( $_SESSION[PGMK][NAV][BNF]['fld_isajax_pages'] )     ? $_SESSION[PGMK][NAV][BNF]['fld_isajax_pages']     : $name2['fld_isajax_pages']     ;
  $xxxFldValues['fld_isremote_pages']   =isset( $_SESSION[PGMK][NAV][BNF]['fld_isremote_pages'] )   ? $_SESSION[PGMK][NAV][BNF]['fld_isremote_pages']   : $name2['fld_isremote_pages']   ;
  $xxxFldValues['fld_isuser_pages']     =isset( $_SESSION[PGMK][NAV][BNF]['fld_isuser_pages'] )     ? $_SESSION[PGMK][NAV][BNF]['fld_isuser_pages']     : $name2['fld_isuser_pages']     ;
  $xxxFldValues['fld_localadmin_pages'] =isset( $_SESSION[PGMK][NAV][BNF]['fld_localadmin_pages'] ) ? $_SESSION[PGMK][NAV][BNF]['fld_localadmin_pages'] : $name2['fld_localadmin_pages'] ;
  $xxxFldValues['fld_isaction_pages']   =isset( $_SESSION[PGMK][NAV][BNF]['fld_isaction_pages'] )   ? $_SESSION[PGMK][NAV][BNF]['fld_isaction_pages']   : $name2['fld_isaction_pages']   ;
  $xxxFldValues['fld_parent_pages']     =isset( $_SESSION[PGMK][NAV][BNF]['fld_parent_pages'] )     ? $_SESSION[PGMK][NAV][BNF]['fld_parent_pages']     : $name2['fld_parent_pages']     ;

  

  $o1.='<form method="post" >'.CRLF;

  $o1.=' <input type="hidden" value="u" name="a" id="a" />'.CRLF;
  $o1.=' <input type="hidden" value="'.$_GET['id'].'" name="id1" id="id1" />'.CRLF;
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_name_pages_239_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($xxxFldValues['fld_name_pages']).'" name="fld_name_pages" id="fld_name_pages" maxlength="64" style="width:100%;max-width:66em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_menu_pages_300_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$xxxFldValues['fld_menu_pages'],'fld_menu_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_isajax_pages_257_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$xxxFldValues['fld_isajax_pages'],'fld_isajax_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_isremote_pages_267_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$xxxFldValues['fld_isremote_pages'],'fld_isremote_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_isuser_pages_331_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$xxxFldValues['fld_isuser_pages'],'fld_isuser_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_localadmin_pages_341_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$xxxFldValues['fld_localadmin_pages'],'fld_localadmin_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_isaction_pages_350_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$xxxFldValues['fld_isaction_pages'],'fld_isaction_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $xDisplayValueFetch = '' ;
  if(
   isset($_SESSION[PGMK][NAV][BNF]['choose__fld_parent_pages'])&&
   $_SESSION[PGMK][NAV][BNF]['choose__fld_parent_pages']==txtsys1('text_for_the_select_button')&&
   isset($_SESSION[PGMK]['choose']['valueBack'])&&
   $_SESSION[PGMK]['choose']['valueBack']!=0
  ){
   if($_SESSION[PGMK][NAV][BNF]['choose__fld_parent_pages']==txtsys1('text_for_the_select_button')){
    $xxxFldValues['fld_parent_pages']=$_SESSION[PGMK]['choose']['valueBack'];
   }
   unset($_SESSION[PGMK]['choose']);
  }
  $xGroupValues=getPages1($xxxFldValues['fld_parent_pages']);
  $xDisplayValueFetch = '' . enti1( $xGroupValues['fld_name_pages'] ) . ' (' . $xGroupValues['fld_id_pages'] . ')' . '' ; // todo choose among parent fields 
   
  $o1.='  <div class="fdiv1">'.CRLF;
  $o1.='   <div class="flab1"><div>'.txt2('parent_fld_parent_pages_374_43').'</div></div>'.CRLF;
  $o1.='   <div class="finp1"><div>'.CRLF;
  $o1.='    <input type="hidden" value="'.enti1($xxxFldValues['fld_parent_pages']).'" name="fld_parent_pages" id="fld_parent_pages" />'.CRLF;
  $o1.='     <span id="span__dep_fld_parent_pages">'.$xDisplayValueFetch.'</span>';
  $o1.='    <button type="submit" name="choose__fld_parent_pages" class="btn" value="'. txtsys1('text_for_the_select_button') . '">';
  $o1.=''   . txtsys1('text_for_the_select_button') . '';
  $o1.=     '</button>'."\r\n";
  $o1.='    <button type="button" class="btn btn-warning" onclick="razDependant1(\'span__dep_fld_parent_pages\',\'fld_parent_pages\')">';
  $o1.=''   . txtsys1('raz_button') . '';
  $o1.=     '</button>'."\r\n";
  $o1.='   </div></div>'.CRLF;
  $o1.='  </div>'.CRLF;

  
  

  $o1.='<div class="fdiv1">'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="hidden" name="fld_cntupd_pages" id="fld_cntupd_pages" value="'.$name2['fld_cntupd_pages'].'" />'.CRLF;
  $o1.='   <button type="submit" class="btn btn-primary">'.txtsys1('save_the_modification').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="record_the_element_and_back_to_list">'.txtsys1('record_the_element_and_back_to_list').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="record_the_element_and_go_to_group_pages">'.txt2('enregistrer et aller aux pages des groupes_418_98').'</button>'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.='</div>'.CRLF;

  $o1.='</form>'.CRLF;

 //=================================================================================================================================
 //============================================= GET VIEW ==========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='v'&&isset($_GET['id'])&&is_numeric($_GET['id'])){ // view action
  // if you vant to do something here, go !
 //=================================================================================================================================
 //============================================= GET CREATE ========================================================================
 //=================================================================================================================================
 }else if(isset($_GET['a'])&&$_GET['a']=='c'){ // create action
 
  $o1.='<h2>'.txt2('Add a new record_295_20'). ' '.btl1().'</h2>'.CRLF;
  $o1.=displaySessionMessage1(BNF);
  $o1.='<form method="post" class="form1">'.CRLF;
 
  
  $fld_name_pages =isset($_SESSION[PGMK][NAV][BNF]['fld_name_pages'] )?$_SESSION[PGMK][NAV][BNF]['fld_name_pages']:'';
  if($fld_name_pages==''&&isset($_GET['newPage']) && $_GET['newPage']!=''){
   $fld_name_pages=$_GET['newPage'];
  }
  
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_name_pages_239_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <input type="text" value="'.enti1($fld_name_pages).'" name="fld_name_pages" id="fld_name_pages" maxlength="64" style="width:100%;max-width:66em;" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $fld_menu_pages =isset($_SESSION[PGMK][NAV][BNF]['fld_menu_pages'] )?$_SESSION[PGMK][NAV][BNF]['fld_menu_pages']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_menu_pages_300_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$fld_menu_pages,'fld_menu_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $fld_isajax_pages =isset($_SESSION[PGMK][NAV][BNF]['fld_isajax_pages'] )?$_SESSION[PGMK][NAV][BNF]['fld_isajax_pages']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_isajax_pages_257_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$fld_isajax_pages,'fld_isajax_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $fld_isremote_pages =isset($_SESSION[PGMK][NAV][BNF]['fld_isremote_pages'] )?$_SESSION[PGMK][NAV][BNF]['fld_isremote_pages']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_isremote_pages_267_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$fld_isremote_pages,'fld_isremote_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $fld_isuser_pages =isset($_SESSION[PGMK][NAV][BNF]['fld_isuser_pages'] )?$_SESSION[PGMK][NAV][BNF]['fld_isuser_pages']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_isuser_pages_331_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$fld_isuser_pages,'fld_isuser_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $fld_localadmin_pages =isset($_SESSION[PGMK][NAV][BNF]['fld_localadmin_pages'] )?$_SESSION[PGMK][NAV][BNF]['fld_localadmin_pages']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_localadmin_pages_341_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$fld_localadmin_pages,'fld_localadmin_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;
  
  $fld_isaction_pages =isset($_SESSION[PGMK][NAV][BNF]['fld_isaction_pages'] )?$_SESSION[PGMK][NAV][BNF]['fld_isaction_pages']:'';
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="flab1"><div>'.txt2('fld_isaction_pages_350_42').'</div></div>'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  require_once($GLOBALS['glob_noVcPath1'].'/parameters/yorno.php');
  $retParam=displayParam2('yorno',$fld_isaction_pages,'fld_isaction_pages',array());
  $o1.=$retParam['html'];
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;

  $fld_parent_pages=isset($_SESSION[PGMK][NAV][BNF]['fld_parent_pages'] )?$_SESSION[PGMK][NAV][BNF]['fld_parent_pages']:0;
  if(
   isset($_SESSION[PGMK][NAV][BNF]['choose__fld_parent_pages'])&&
   $_SESSION[PGMK][NAV][BNF]['choose__fld_parent_pages']==txtsys1('text_for_the_select_button')&&
   isset($_SESSION[PGMK]['choose']['valueBack'])&&
   $_SESSION[PGMK]['choose']['valueBack']!=0
  ){
   if($_SESSION[PGMK][NAV][BNF]['choose__fld_parent_pages']==txtsys1('text_for_the_select_button')){
    $fld_parent_pages=$_SESSION[PGMK]['choose']['valueBack'];
   }
   unset($_SESSION[PGMK]['choose']);
  }
  $xGroupValues=getPages1($fld_parent_pages);
  $xDisplayValueFetch = '' . enti1( $xGroupValues['fld_name_pages'] ) . ' (' . $xGroupValues['fld_id_pages'] . ')' . '' ;
  $o1.='  <div class="fdiv1">'.CRLF;
  $o1.='   <div class="flab1"><div>'.txt2('parent_fld_parent_pages_374_43').'</div></div>'.CRLF;
  $o1.='   <div class="finp1"><div>'.CRLF;
  $o1.='    <input type="hidden" value="'.enti1($fld_parent_pages).'" name="fld_parent_pages" id="fld_parent_pages" />'.CRLF;
  $o1.='     '.$xDisplayValueFetch.'';
  $o1.='    <button type="submit" name="choose__fld_parent_pages" class="btn" value="'. txtsys1('text_for_the_select_button') . '">';
  $o1.=''   . txtsys1('text_for_the_select_button') . '';
  $o1.=     '</button>'."\r\n";
  $o1.='   </div></div>'.CRLF;
  $o1.='  </div>'.CRLF;

  
  $o1.=' <div class="fdiv1">'.CRLF;
  $o1.='  <div class="finp1"><div>'.CRLF;
  $o1.='   <button type="submit">'.txtsys1('record_the_element').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="record_the_element_and_back_to_list">'.txtsys1('record_the_element_and_back_to_list').'</button>'.CRLF;
  $o1.='   <button type="submit" class="" name="record_the_element_and_go_to_group_pages">'.txt2('enregistrer et aller aux pages des groupes_418_98').'</button>'.CRLF;
  $o1.='   <input type="hidden" value="0" name="id1" id="id1" />'.CRLF;
  $o1.='   <input type="hidden" value="c" name="a" id="a" />'.CRLF;
  $o1.='  </div></div>'.CRLF;
  $o1.=' </div>'.CRLF;


  $o1.='</form>'.CRLF;

 }
 $o1.=htmlFoot0(array('js' => $js1));
 dw1($o1);
 if(isset($_SESSION[PGMK][NAV][BNF])) unset($_SESSION[PGMK][NAV][BNF]);
}