<?php
$GLOBALS['param__country']=array (
  'param__Name__Display' => 'n',
  'param__Name__Sort' => 'n',
  'param__Name__key' => 'country_code',
  'param__Key__type' => 'char',
  '__values' => 
  array (
    'fr' => 
    array (
      'BE' => 
      array (
        'country_code' => 'BE',
        'n' => 'Belgique',
        'badge' => 'yybadge0',
        'rule' => '1',
        'fld_id_parvals' => '43',
        '__order' => 0,
        'param__Name__Display' => 'n',
      ),
      'CA' => 
      array (
        'country_code' => 'CA',
        'n' => 'Canada',
        'badge' => 'yybadge1',
        'rule' => '0',
        'fld_id_parvals' => '62',
        '__order' => 1,
        'param__Name__Display' => 'n',
      ),
      'KO' => 
      array (
        'country_code' => 'KO',
        'n' => 'Corée du Sud',
        'badge' => 'yybadge4',
        'rule' => '3',
        'fld_id_parvals' => '46',
        '__order' => 2,
        'param__Name__Display' => 'n',
      ),
      'ES' => 
      array (
        'country_code' => 'ES',
        'n' => 'Espagne',
        'badge' => 'yybadge0',
        'rule' => '1',
        'fld_id_parvals' => '49',
        '__order' => 3,
        'param__Name__Display' => 'n',
      ),
      'US' => 
      array (
        'country_code' => 'US',
        'n' => 'Etats Unis d\'Amérique',
        'badge' => 'yybadge1',
        'rule' => '2',
        'fld_id_parvals' => '41',
        '__order' => 4,
        'param__Name__Display' => 'n',
      ),
      'FR' => 
      array (
        'country_code' => 'FR',
        'n' => 'France',
        'badge' => 'yybadge0',
        'rule' => '1',
        'fld_id_parvals' => '40',
        '__order' => 5,
        'param__Name__Display' => 'n',
      ),
      'GB' => 
      array (
        'country_code' => 'GB',
        'n' => 'Grande-Bretagne',
        'badge' => 'yybadge0',
        'rule' => '1',
        'fld_id_parvals' => '42',
        '__order' => 6,
        'param__Name__Display' => 'n',
      ),
      'JP' => 
      array (
        'country_code' => 'JP',
        'n' => 'Japon',
        'badge' => 'yybadge4',
        'rule' => '3',
        'fld_id_parvals' => '57',
        '__order' => 7,
        'param__Name__Display' => 'n',
      ),
    ),
    'en' => 
    array (
      'BE' => 
      array (
        'country_code' => 'BE',
        'n' => 'Belgium',
        'badge' => 'yybadge0',
        'rule' => '1',
        'fld_id_parvals' => '43',
        '__order' => 0,
        'param__Name__Display' => 'n',
      ),
      'CA' => 
      array (
        'country_code' => 'CA',
        'n' => 'Canada',
        'badge' => 'yybadge1',
        'rule' => '0',
        'fld_id_parvals' => '62',
        '__order' => 1,
        'param__Name__Display' => 'n',
      ),
      'FR' => 
      array (
        'country_code' => 'FR',
        'n' => 'France',
        'badge' => 'yybadge0',
        'rule' => '1',
        'fld_id_parvals' => '40',
        '__order' => 2,
        'param__Name__Display' => 'n',
      ),
      'GB' => 
      array (
        'country_code' => 'GB',
        'n' => 'Great-Britain',
        'badge' => 'yybadge0',
        'rule' => '1',
        'fld_id_parvals' => '42',
        '__order' => 3,
        'param__Name__Display' => 'n',
      ),
      'JP' => 
      array (
        'country_code' => 'JP',
        'n' => 'Japan',
        'badge' => 'yybadge4',
        'rule' => '3',
        'fld_id_parvals' => '57',
        '__order' => 4,
        'param__Name__Display' => 'n',
      ),
      'KO' => 
      array (
        'country_code' => 'KO',
        'n' => 'South Korea',
        'badge' => 'yybadge4',
        'rule' => '3',
        'fld_id_parvals' => '46',
        '__order' => 5,
        'param__Name__Display' => 'n',
      ),
      'ES' => 
      array (
        'country_code' => 'ES',
        'n' => 'Spain',
        'badge' => 'yybadge0',
        'rule' => '1',
        'fld_id_parvals' => '49',
        '__order' => 6,
        'param__Name__Display' => 'n',
      ),
      'US' => 
      array (
        'country_code' => 'US',
        'n' => 'USA',
        'badge' => 'yybadge1',
        'rule' => '2',
        'fld_id_parvals' => '41',
        '__order' => 7,
        'param__Name__Display' => 'n',
      ),
    ),
  ),
  'param__definition' => 
  array (
    'comment' => 'This is an example',
    'key' => 'country_code',
    'fields' => 
    array (
      0 => 
      array (
        'name' => 'country_code',
        'type' => 'char',
        'length' => 2,
        'comment' => 'FR, US, GB, BE, ....',
      ),
      1 => 
      array (
        'name' => 'n',
        'type' => 'char',
        'length' => 64,
        'languageTranslation' => true,
        'comment1' => 'the language name',
      ),
    ),
    'dependencies' => 
    array (
      0 => 
      array (
        'id_db' => 0,
        'table' => 'tdo_tbl__zztests',
        'field' => 'fld_visited_countries_zztests',
      ),
      1 => 
      array (
        'id_db' => 0,
        'table' => 'tdo_tbl__zztests',
        'field' => 'fld_country1_zztests',
      ),
    ),
    'id' => '5',
  ),
);