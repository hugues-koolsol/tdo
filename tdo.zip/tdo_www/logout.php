<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
//checkGroupPages(); NO check on logout !
$translate=0;
if($_SESSION[PGMK]['groupInit']==1 && $_SESSION[PGMK]['translate']==1){
 $translate=1; // super user only can translate the login page
}
unset($_SESSION[PGMK]);
if($translate==1){
 $_SESSION[PGMK]['translate']=1;
}
setcookie( 'cookLogged' , '0');
header("HTTP/1.1 303 See Other");header('Location: login.php'); 
exit();
