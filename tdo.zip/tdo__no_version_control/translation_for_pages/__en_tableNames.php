<?php
$__tableNames=array (
  'tdo_tbl__css' => 'css',
  'tdo_tbl__groups' => 'user groups',
  'tdo_tbl__grpspgs' => 'pages of user groups',
  'tdo_tbl__langvalues' => 'translations',
  'tdo_tbl__log' => 'logs',
  'tdo_tbl__pages' => 'pages',
  'tdo_tbl__paramnames' => 'paramètres',
  'tdo_tbl__paramrules' => 'parameter rules',
  'tdo_tbl__paramvalues' => 'parameters values',
  'tdo_tbl__tablelinks' => 'links between tables',
  'tdo_tbl__tables' => 'tables',
  'tdo_tbl__todos' => 'todos',
  'tdo_tbl__uploadeddocs' => 'uploaded documents',
  'tdo_tbl__users' => 'users',
  'tdo_tbl__zztests' => 'my test table',
);