<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb2();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
//echo __LINE__ ; exit();
$xsrch_key1  =saveSessionSearch1( 'xsrch_key1'  , BNF );
$xsrch_lab1  =saveSessionSearch1( 'xsrch_lab1'  , BNF );
$xsrch_5     =saveSessionSearch1('xsrch_5',BNF);// fld_isuser_parnams
$xsrch_id1   =saveSessionSearch1( 'xsrch_id1'   , BNF );


if($xsrch_id1!=''){
 if(!is_numeric($xsrch_id1)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('The id must be numerical_24_92');
 }
}

$autofocus='xsrch_key1';
if($xsrch_key1!=''){       $autofocus='xsrch_key1';
}else if($xsrch_lab1!=''){ $autofocus='xsrch_lab1';
}else if($xsrch_5!=''){    $autofocus='xsrch_5';
}else if($xsrch_id1!=''){  $autofocus='xsrch_id1';
}


$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_35_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="filterForm">'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_key1">'.txt2('fld_key_parnams_42_53').'</label>'.CRLF;
$o1.='    <input class="form-control form-control-sm" type="text" name="xsrch_key1"    id="xsrch_key1"   value="'.enti1($xsrch_key1).'"  size="8" maxlength="32"';
if($xsrch_key1!=''){$o1.=' class="backgroundYellow"';}
$o1.=' '.($autofocus=='xsrch_key1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_lab1">'.txt2('fld_label_parnams_45_53').'</label>'.CRLF;
$o1.='    <input class="form-control form-control-sm" type="text" name="xsrch_lab1"    id="xsrch_lab1"   value="'.enti1($xsrch_lab1).'"  size="8" maxlength="32"';
if($xsrch_lab1!=''){$o1.=' class="backgroundYellow"';}
$o1.=' '.($autofocus=='xsrch_lab1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id1">'.txt2('fld_id_parnams_50_52').'</label>'.CRLF;
$o1.='    <input class="form-control form-control-sm" type="text" name="xsrch_id1"    id="xsrch_id1"   value="'.enti1($xsrch_id1).'"  size="8" maxlength="32"';
if($xsrch_id1!=''){$o1.=' class="backgroundYellow"';}
$o1.=' '.($autofocus=='xsrch_id1'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_5">'.txt2('fld_isuser_parnams_70_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_5!=''?'class="backgroundYellow"':'').' name="xsrch_5"  id="xsrch_5" '.($autofocus=='xsrch_5'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='<option value="" '.($xsrch_5==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_5){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;



$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </div>'.CRLF;
$o1.=' </form>'.CRLF;
//===================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS
  T0.`fld_id_parnams`     , T0.`fld_key_parnams`  , T0.`fld_comment_parnams` , T0.`fld_json_parnams` , T0.`fld_label_parnams` ,
  T0.`fld_isuser_parnams`
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__paramnames` T0 
 WHERE T0.`fld_key_parnams`        LIKE \'%' . addslashes($xsrch_key1) . '%\' 
   AND T0.`fld_label_parnams`      LIKE \'%' . addslashes($xsrch_lab1) . '%\' 
';
if($_SESSION[PGMK]['login']!=1){
 $req6.='
  AND T0.`fld_isuser_parnams`        = 1
 '; 
 
}
if($xsrch_id1!='' && is_numeric($xsrch_id1)){
 $req6.='
  AND T0.`fld_id_parnams`        = '.$xsrch_id1.'
 '; 
}
if($xsrch_5!='' && is_numeric($xsrch_5)){
 $req6.='
  AND T0.`fld_isuser_parnams` = '.$xsrch_5.'
 '; 
}

$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 $reqCount6='SELECT FOUND_ROWS();';
 $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $mpsrcount6=mysqli_fetch_row($rescount6);
  $__count=$mpsrcount6[0];
 }
 $lsttbl='';
 if($__count==0){
  $lst.='<p>'.CRLF;
  $lst.=''.txt2('no_record_founded_87_17').''.CRLF;
  $lst.='<a href="zz_paramkeys_action1.php?a=c">'.txt2('add_a_new_record_88_74').'</a>'.CRLF;
  $lst.='</p>'.CRLF;
  $o1.=''.$lst.''.CRLF;  
 }else{
  $consUrlRedir='&amp;xsrch_key1='.rawurlencode($xsrch_key1).
                '&amp;xsrch_id1='.rawurlencode($xsrch_id1).
                '&amp;xsrch_lab1='.rawurlencode($xsrch_lab1).
                '&amp;xsrch_5='.rawurlencode($xsrch_5). // fld_isuser_parnams 
                '';  
  $ri=' <span class="btn unset">&raquo;</span>';
  if($__start+$__nbMax<$__count){
   $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
  }
  $le=' <span class="btn unset">&laquo;</span>';
  if($__xpage>0){
   $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
  }
  if($_SESSION[PGMK]['login']==1){
   $o1.='<div class="actionColumn">';
   $o1.='<form method="post">';
   $o1.='<a href="zz_paramkeys_action1.php?a=c">'.txt2('add_a_new_record_88_74').'</a>'.CRLF;
   $o1.='&nbsp;'.$le.''.CRLF;  
   $o1.='&nbsp;'.$ri.''.CRLF;  
   $o1.='</form>';
   $o1.='</div>';
 }
$css='<style type="text/css">
@media screen and (max-width: 890px){/* todo adjust size */
  table.tableResult1 {
    border: 0;
    width:100%;
    max-width:540px;
  }
  table.tableResult1 thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  table.tableResult1 tr {
    border-bottom: 3px solid #eee;
    display: block;
    margin-bottom: 2.001em;
  }
  table.tableResult1 td {
    border-bottom: 1px solid #eee;
    display: block;
    text-align: right!important;
    min-height:35px;
  }
  table.tableResult1 td:before {
    content: attr(data-label);
    float: left!important;
    font-weight:bold;
    margin-right:5px;
  }
  table.tableResult1 td:last-child {
    border-bottom: 0;
  }
  table.tableResult1 td.actionColumn div{
   display:contents;
  }
  table.tableResult1 td.actionColumn{
   height:auto;
  }
  .tableResult1 td {
   height:auto;
  }
}
</style>';
  $o1.=$css;                
  $lsttbl.='<thead><tr>';
  $lsttbl.='<th>'.txtsys1('column_action').'</th>';
  $lsttbl.='<th>'.txt2('fld_key_parnams_42_53').'</th>';
  $lsttbl.='<th>'.txt2('fld_label_parnams_45_53').'</th>';
  $lsttbl.='<th>'.txt2('fld_comment_parnams_100_24').'</th>';
  if($_SESSION[PGMK]['login']==1){
   $lsttbl.='<th>'.txt2('fld_isuser_parnams_70_39').'</th>';
  }
  $lsttbl.='</tr></thead>';
  $lsttbl.='<tbody>';
  while($mpsr6=mysqli_fetch_row($result6)){
   $lsttbl.='<tr>';
   
   $lsttbl.='<td class="actionColumn" style="min-width:120px;" data-label="'.txtsys1('column_action').'">';
   $lsttbl.='<div>';
   if($_SESSION[PGMK]['login']==1){
    $lsttbl.='<a href="zz_paramkeys_action1.php?a=u&amp;id='.$mpsr6[0].'" class="edit" title="'.txtsys1('edit_button').'">&#9998;</a>'; // 
   }
   if(1!=$mpsr6[0]){
    if($_SESSION[PGMK]['login']==1){
     $lsttbl.='<a class="danger" href="zz_paramkeys_action1.php?a=d&amp;id='.$mpsr6[0].'" class="danger" title="'.txtsys1('delete_button').'">&#10008;</a>';
    }
   }
   $lsttbl.='<a  href="zz_paramvalues1.php?m=1&amp;id='.$mpsr6[0].'" title="'.txt2('manage_param_values_124_88').'">&#8658;</a>';
   $lsttbl.='</div>';
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_key_parnams_42_53').'" >';
   $lsttbl.=''.enti1($mpsr6[1]).' ('.$mpsr6[0].') '; // fld_key_parnams fld_id_parnams 
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_label_parnams_45_53').'">';
   $lsttbl.=''.enti1($mpsr6[4]).'';  // fld_label_parnams
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_comment_parnams_100_24').'">';
   $lsttbl.='<pre>'.enti1(mb_substr($mpsr6[2],0,100)).'</pre>'; // fld_comment_parnams
   $lsttbl.='</td>';

   if($_SESSION[PGMK]['login']==1){
    $lsttbl.='<td data-label="'.txt2('fld_isuser_parnams_70_39').'" style="text-align:center;">';
    require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
    $lsttbl.=displayParam1('yorno',$mpsr6[5]); // fld_isuser_parnams
    $lsttbl.='</td>';
   }
   
   $lsttbl.='</tr>';
  }
  $lsttbl.='</tbody>';
  $o1.='<table class="tableResult1">'.CRLF.$lsttbl.'</table>'.CRLF; // table-condensed
   
  $o1.=' <div>'.CRLF;
  $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_128_99').' )'.CRLF;
  if($_SESSION[PGMK]['login']==1){
   $o1.='   &nbsp;<a class="buttonAdd btn btn-sm btn-primary" href="zz_paramkeys_action1.php?a=c">'.txt2('add_a_new_record_88_74').'</a>'.CRLF;
  }
  $o1.=' </div>'.CRLF;
   
 }
  mysqli_free_result($result6);
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6));
}
$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();