<?php
define('BNF',basename( __FILE__ ));
require_once 'za_inc.php';
session_start();
@include  $GLOBALS['glob_dataPath1'].'/generated/lang/'.$GLOBALS['glob_lang'].'_'.BNF;
checkGroupPages();
openDb2();
//========================================================================================================================
$o1='';
$__nbMax=20;
$__start=0;
$__count=0;
$__xpage=0;
if(isset($_GET['__xpage'])&&is_numeric($_GET['__xpage'])){
 $__xpage=$_GET['__xpage'];
}else{
 if(isset($_SESSION[PGMK][NAV][BNF]['__xpage'])) $__xpage=$_SESSION[PGMK][NAV][BNF]['__xpage'];
}
$xsrch_0=saveSessionSearch1('xsrch_0',BNF);// fld_yorno1_zztests
$xsrch_1=saveSessionSearch1('xsrch_1',BNF);// fld_visited_countries_zztests
$xsrch_2=saveSessionSearch1('xsrch_2',BNF);// fld_title32_zztests
$xsrch_3=saveSessionSearch1('xsrch_3',BNF);// fld_id_parent_zztests
$xsrch_4=saveSessionSearch1('xsrch_4',BNF);// fld_date1_zztests
$xsrch_5=saveSessionSearch1('xsrch_5',BNF);// fld_time1_zztests
$xsrch_6=saveSessionSearch1('xsrch_6',BNF);// fld_dttim1_zztests
$xsrch_7=saveSessionSearch1('xsrch_7',BNF);// fld_color1_zztests
$xsrch_id=saveSessionSearch1('xsrch_id',BNF);// fld_id_zztests
if($xsrch_3!=''){
 if(!is_numeric($xsrch_3)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_28_92') . ' : ' . txt2('fld_id_parent_zztests_28_152');
 }
}
if($xsrch_id!=''){
 if(!is_numeric($xsrch_id)){
  $_SESSION[PGMK][NAV][BNF]['errormessage'][]=txtsys1('error').' '. __LINE__ .' : ' . txt2('the value must be numerical for the field_28_92') . ' : ' . txt2('fld_id_zztests_33_152');
 }
}
if(is_array($xsrch_1) && sizeof($xsrch_1)==1 && $xsrch_1[0]==''){ // fld_visited_countries_zztests
 $xsrch_1='';
}
$autofocus='xsrch_0';
if($xsrch_0!=''){      $autofocus='xsrch_0'; } // fld_yorno1_zztests
else if($xsrch_1!=''){ $autofocus='xsrch_1'; } // fld_visited_countries_zztests
else if($xsrch_2!=''){ $autofocus='xsrch_2'; } // fld_title32_zztests
else if($xsrch_3!=''){ $autofocus='xsrch_3'; } // fld_id_parent_zztests
else if($xsrch_4!=''){ $autofocus='xsrch_4'; } // fld_date1_zztests
else if($xsrch_5!=''){ $autofocus='xsrch_5'; } // fld_time1_zztests
else if($xsrch_6!=''){ $autofocus='xsrch_6'; } // fld_dttim1_zztests
else if($xsrch_7!=''){ $autofocus='xsrch_7'; } // fld_color1_zztests
else if($xsrch_id!=''){ $autofocus='xsrch_id'; }
$o1.=htmlHead1(array('nomenu'=>true));
$o1.='<h1>'.txt2('page_title_list_49_18').'</h1>';
$o1.=displaySessionMessage1(BNF);

$o1.=' <form method="get" class="filterForm">'.CRLF;
require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_0">'.txt2('fld_yorno1_zztests_55_39').'</label>'.CRLF;
$o1.='    <select '.($xsrch_0!=''?'class="backgroundYellow"':'').' name="xsrch_0"  id="xsrch_0" '.($autofocus=='xsrch_0'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='<option value="" '.($xsrch_0==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
foreach($GLOBALS['param__yorno']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if((string)$kp==(string)$xsrch_0){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__yorno']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;

require_once($GLOBALS['glob_dataPath1'].'/generated/_params/country.php');
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_1">'.txt2('fld_visited_countries_zztests_70_39').'</label>'.CRLF;
$o1.='    <select size="3" name="xsrch_1[]"   multiple="multiple" style="max-width:10em;" id="xsrch_1" '.($autofocus=='xsrch_1'?'autofocus="autofocus"':'').' ';
if(is_array($xsrch_1)){
 if($xsrch_1[0]!=''){
  $o1.=' class="backgroundYellow" ';
 }
}else{
 if($xsrch_1!=''){$o1.=' class="backgroundYellow" ';}
}
$o1.='  />'.CRLF;
$o1.='<option value="" '.($xsrch_1==''?'  selected="selected" ':'').'>&nbsp;</option>'.CRLF;
if(!is_array($xsrch_1)) $xsrch_1=array();
if(is_array($xsrch_1) && in_array( '__all_values_of_set__' , $xsrch_1 )){
 $o1.='<option value="__all_values_of_set__" selected="selected" >'.txtsys1('all_values_of_set_list').'</option>'.CRLF;
}else{
 $o1.='<option value="__all_values_of_set__">'.txtsys1('all_values_of_set_list').'</option>'.CRLF; 
}
foreach($GLOBALS['param__country']['__values'][$GLOBALS['glob_lang']] as $kp => $vp){
 if(in_array($kp,$xsrch_1)){
  $o1.='<option value="'.$kp.'" selected="selected">'.$vp[$GLOBALS['param__country']['param__Name__Display']].'</option>'.CRLF;
 }else{
  $o1.='<option value="'.$kp.'">'.$vp[$GLOBALS['param__country']['param__Name__Display']].' </option>'.CRLF;  
 }
}
$o1.='    </select>';
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_2">'.txt2('fld_title32_zztests_99_39').'</label>'.CRLF; // fld_title32_zztests
$o1.='    <input '.($xsrch_2!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_2" id="xsrch_2"   value="'.enti1($xsrch_2).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_2'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_3">'.txt2('fld_id_parent_zztests_28_152').'</label>'.CRLF; // fld_id_parent_zztests
$o1.='    <input '.($xsrch_3!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_3" id="xsrch_3"   value="'.enti1($xsrch_3).'"  size="8" maxlength="32"  '.($autofocus=='xsrch_3'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

if($xsrch_4=='1000-01-01') $xsrch_4='';
$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_4">'.txt2('fld_date1_zztests_111_39').'</label>'.CRLF; // fld_date1_zztests
$o1.='    <input type="hidden" name="xsrch_4"    id="xsrch_4"   value="'.enti1($xsrch_4).'" />'.CRLF;
$o1.='    <button '.($xsrch_4!=''?'class="backgroundYellow"':'').' style="padding:0px!important;font-size:0.8em;" type="button" id="button_date_xsrch_4" onclick="javascript:setDate1(\'xsrch_4\',\'button_date_xsrch_4\',1,1)" style="border-style:outset;font-size:0.8em;padding:5px;">';
$o1.=(($xsrch_4=='1000-01-01' || $xsrch_4=='' )?txtsys1('date all'):($xsrch_4=='NULL'?txtsys1('date null'):($xsrch_4=='NOT NULL'?txtsys1('date not null'):$xsrch_4)));
$o1.='</button>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_5">'.txt2('fld_time1_zztests_119_39').'</label>'.CRLF; // fld_time1_zztests
$o1.='    <input type="hidden" name="xsrch_5"    id="xsrch_5"   value="'.enti1($xsrch_5).'" />'.CRLF;
$o1.='    <button '.($xsrch_5!=''?'class="backgroundYellow"':'').' style="padding:0px!important;font-size:0.8em;" type="button" id="button_time_xsrch_5" onclick="javascript:setTime1(\'xsrch_5\',\'button_time_xsrch_5\',1,1)" style="border-style:outset;font-size:0.8em;padding:5px;">';
$o1.=($xsrch_5==''?txtsys1('time all'):($xsrch_5=='NULL'?txtsys1('time null'):($xsrch_5=='NOT NULL'?txtsys1('time not null'):$xsrch_5)));
$o1.='</button>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_6">'.txt2('fld_dttim1_zztests_127_39').'</label>'.CRLF; // fld_dttim1_zztests
$o1.='    <input type="hidden" name="xsrch_6"    id="xsrch_6"   value="'.enti1($xsrch_6).'" />'.CRLF;
$o1.='    <button '.($xsrch_6!=''?'class="backgroundYellow"':'').' style="padding:0px!important;font-size:0.8em;" type="button" id="button_datetime_xsrch_6" onclick="javascript:setDateTime1(\'xsrch_6\',\'button_datetime_xsrch_6\',1,1)" style="border-style:outset;font-size:0.8em;padding:5px;">';
$o1.=($xsrch_6==''?txtsys1('datetime all'):($xsrch_6=='NULL'?txtsys1('datetime null'):($xsrch_6=='NOT NULL'?txtsys1('datetime not null'):$xsrch_6)));
$o1.='</button>';
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_7">'.txt2('fld_color1_zztests_137_39').'</label>'.CRLF; // fld_color1_zztests
$o1.='    <input type="hidden" name="xsrch_7" id="xsrch_7"   value="'.enti1($xsrch_7).'"  '.($autofocus=='xsrch_7'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='    <button '.($xsrch_7!=''?'class="backgroundYellow"':'').' style="padding:0px!important;" type="button" id="button_color_xsrch_7" onclick="javascript:setColor1(\'xsrch_7\',\'button_color_xsrch_7\',\'\',1,1)" style="border-style:outset;font-size:0.8em;padding:5px;">';
$o1.=($xsrch_7==''?txtsys1('color all'):($xsrch_7=='NULL'?txtsys1('color null'):($xsrch_7=='NOT NULL'?txtsys1('color not null'):$xsrch_7)));
$o1.='</button>';
$o1.='   </div>'.CRLF;


$o1.='   <div>'.CRLF;
$o1.='    <label for="xsrch_id">'.txt2('fld_id_zztests_33_152').'</label>'.CRLF; // fld_id_zztests
$o1.='    <input '.($xsrch_id!=''?'class="backgroundYellow"':'').' type="text" name="xsrch_id"    id="xsrch_id"   value="'.enti1($xsrch_id).'"  size="8" maxlength="32" '.($autofocus=='xsrch_id'?'autofocus="autofocus"':'').' />'.CRLF;
$o1.='   </div>'.CRLF;

$o1.='   <div>'.CRLF;
$o1.='    <button class="button_search">&#128270;</button>'.CRLF;
$o1.='    <input type="hidden" name="__xpage" id="__xpage" value="0" />'.CRLF; // '.$__xpage.'
$o1.='   </div>'.CRLF;

$o1.=' </form>'.CRLF;
//====================================================================================================
$__start=$__xpage*$__nbMax;
$_SESSION[PGMK][NAV][BNF]['__xpage']=$__xpage;
$lst='';
$req6='
 SELECT  SQL_CALC_FOUND_ROWS   
   T0.`fld_id_zztests`                ,T0.`fld_yorno1_zztests`            ,T0.`fld_visited_countries_zztests` ,T0.`fld_title32_zztests`           ,T0.`fld_id_parent_zztests`         ,
   T0.`fld_date1_zztests`             ,T0.`fld_time1_zztests`             ,T0.`fld_dttim1_zztests`            ,T0.`fld_color1_zztests`            ,T0.`fld_country1_zztests`
 FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__zztests` T0 
 WHERE 1=1 
';
if($xsrch_0!='' ){
 $req6.='
  AND T0.`fld_yorno1_zztests` LIKE \'%'.$xsrch_0.'%\'
 '; 
}
if($xsrch_1!='' ){
 $req6.=buildSetCondition($xsrch_1,'param__country', 'T0.`fld_visited_countries_zztests`' );
}
if($xsrch_2!='' ){
 $req6.='
  AND T0.`fld_title32_zztests` LIKE \'%'.$xsrch_2.'%\'
 '; 
}
if($xsrch_3!='' && is_numeric($xsrch_3)){
 $req6.='
  AND T0.`fld_id_parent_zztests` = '.$xsrch_3.'
 '; 
}
if($xsrch_4!='' ){
 if($xsrch_4=='NULL'){
  $req6.='
   AND T0.`fld_date1_zztests` IS NULL
  ';   
 }else if($xsrch_4=='NOT NULL'){
  $req6.='
   AND T0.`fld_date1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_date1_zztests` LIKE \'%'.$xsrch_4.'%\'
  '; 
 }
}
if($xsrch_5!='' ){
 if($xsrch_5=='NULL'){
  $req6.='
   AND T0.`fld_time1_zztests` IS NULL
  ';   
 }else if($xsrch_5=='NOT NULL'){
  $req6.='
   AND T0.`fld_time1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_time1_zztests` LIKE \'%'.$xsrch_5.'%\'
  '; 
 }
}
if($xsrch_6!='' ){
 if($xsrch_6=='NULL'){
  $req6.='
   AND T0.`fld_dttim1_zztests` IS NULL
  ';   
 }else if($xsrch_6=='NOT NULL'){
  $req6.='
   AND T0.`fld_dttim1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_dttim1_zztests` LIKE \'%'.$xsrch_6.'%\'
  '; 
 }
}
if($xsrch_7!='' ){
 if($xsrch_7=='NULL'){
  $req6.='
   AND T0.`fld_color1_zztests` IS NULL
  ';   
 }else if($xsrch_7=='NOT NULL'){
  $req6.='
   AND T0.`fld_color1_zztests` IS NOT NULL
  ';   
 }else{
  $req6.='
   AND T0.`fld_color1_zztests` LIKE \'%'.$xsrch_7.'%\'
  '; 
 }
}

if($xsrch_id!='' && is_numeric($xsrch_id)){
 $req6.='
  AND T0.`fld_id_zztests` = '.$xsrch_id.'
 '; 
}
$req6.='
 ORDER BY T0.`fld_id_zztests` DESC 
'; 
$req6.=' LIMIT '.$__start.','.$__nbMax.' ' ;
//echo __FILE__ . ' ' . __LINE__ . ' $req6 = <pre>' .$req6  . '</pre>' ; exit(0);
$result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
 $reqCount6='SELECT FOUND_ROWS();';
 $rescount6=mysqli_query($GLOBALS['glob_db'][0]['link'],$reqCount6);
 if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
  $mpsrcount6=mysqli_fetch_row($rescount6);
  $__count=$mpsrcount6[0];
 }
 $lsttbl='';
 if($__count==0){
  $lst.='<p>'.CRLF;
  $lst.=''.txt2('no_record_founded_241_17').''.CRLF;
  $lst.='<a href="zz_zztests_action1.php?a=c">'.txt2('add_a_new_record_242_54').'</a>'.CRLF;
  $lst.='</p>'.CRLF;
  $o1.=''.$lst.''.CRLF;  
 }else{
  $consUrlRedir=''.
                '&amp;xsrch_0='.rawurlencode($xsrch_0). // fld_yorno1_zztests 
                '&amp;xsrch_2='.rawurlencode($xsrch_2). // fld_title32_zztests 
                '&amp;xsrch_3='.rawurlencode($xsrch_3). // fld_id_parent_zztests 
                '&amp;xsrch_4='.rawurlencode($xsrch_4). // fld_date1_zztests 
                '&amp;xsrch_5='.rawurlencode($xsrch_5). // fld_time1_zztests 
                '&amp;xsrch_6='.rawurlencode($xsrch_6). // fld_dttim1_zztests 
                '&amp;xsrch_7='.rawurlencode($xsrch_7). // fld_color1_zztests 
                '&amp;xsrch_id='.rawurlencode($xsrch_id).
                '';
  if(is_array($xsrch_1)){
   foreach($xsrch_1 as $k1 => $v1){
    $consUrlRedir.='&amp;xsrch_1%5B%5D='.rawurlencode($v1);
   }
  }else{
   $consUrlRedir.='&amp;xsrch_1='.rawurlencode($xsrch_1); // fld_visited_countries_zztests
  }
  $ri=' <span class="btn unset">&raquo;</span>';
  if($__start+$__nbMax<$__count){
   $ri=' <a href="'.BNF.'?__xpage='.($__xpage+1).$consUrlRedir.'">&raquo;</a>';
  }
  $le=' <span class="btn unset">&laquo;</span>';
  if($__xpage>0){
   $le=' <a href="'.BNF.'?__xpage='.($__xpage-1).$consUrlRedir.'">&laquo;</a>';
  }
  $o1.='<div>';
  $o1.='<form method="post">';
//  $o1.='<button type="submit" name="action1">'.txt0('action1').'</button>';
//  $o1.='<button type="submit" name="action2">'.txt0('action2').'</button>';
  $o1.='<a href="zz_zztests_action1.php?a=c">'.txt2('add_a_new_record_242_54').'</a>'.CRLF;
  $o1.='&nbsp;'.$le.''.CRLF;  
  $o1.='&nbsp;'.$ri.''.CRLF;  
  $o1.='</form>';
  $o1.='</div>';

$css='<style type="text/css">
@media screen and (max-width: 890px){/* todo adjust size */
  table.tableResult1 {
    border: 0;
    width:100%;
    max-width:540px;
  }
  table.tableResult1 thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  table.tableResult1 tr {
    border-bottom: 3px solid #eee;
    display: block;
    margin-bottom: 2.001em;
  }
  table.tableResult1 td {
    border-bottom: 1px solid #eee;
    display: block;
    text-align: right!important;
    min-height:30px;
  }
  table.tableResult1 td:before {
    content: attr(data-label);
    float: left!important;
    font-weight:bold;
    margin-right:5px;
  }
  table.tableResult1 td:last-child {
    border-bottom: 0;
  }
  table.tableResult1 td.actionColumn div{
   display:contents;
  }
  table.tableResult1 td.actionColumn{
   height:auto;
  }
  .tableResult1 td {
   height:auto;
  }
}
</style>';
  $o1.=$css;

  $lsttbl.='<thead><tr>';
  $lsttbl.='<th style="min-width:85px;">'.txtsys1('column_action').'</th>';
  $lsttbl.='<th>'.txt2('fld_id_zztests_33_152').'</th>';
  $lsttbl.='<th>'.txt2('fld_yorno1_zztests_55_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_visited_countries_zztests_70_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_title32_zztests_99_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_id_parent_zztests_28_152').'</th>';
  $lsttbl.='<th style="min-width:95px;">'.txt2('fld_date1_zztests_111_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_time1_zztests_119_39').'</th>';
  $lsttbl.='<th style="min-width:95px;">'.txt2('fld_dttim1_zztests_127_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_color1_zztests_137_39').'</th>';
  $lsttbl.='<th>'.txt2('fld_country1_zztests_368_24').'</th>';
  
  $lsttbl.='</tr></thead><tbody>';
  while($mpsr6=mysqli_fetch_row($result6)){
   
   $lsttbl.='<tr>';

   $lsttbl.='<td data-label="'.txtsys1('column_action').'">';
   $lsttbl.='<div>';
   $lsttbl.='<a href="zz_zztests_action1.php?a=u&amp;id='.$mpsr6[0].'" class="edit" title="'.txtsys1('edit_button').'">&#9998;</a>';
   $lsttbl.='<a class="danger" href="zz_zztests_action1.php?a=d&amp;id='.$mpsr6[0].'" class="danger" title="'.txtsys1('delete_button').'">&#10008;</a>';
   $lsttbl.='</div>';
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_id_zztests_33_152').'" style="text-align:right;">';
   $lsttbl.=''.enti1($mpsr6[0]).''; // fld_id_zztests
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_yorno1_zztests_55_39').'" style="text-align:center;">';
   require_once($GLOBALS['glob_dataPath1'].'/generated/_params/yorno.php');
   $lsttbl.=displayParam1('yorno',$mpsr6[1],array('unsetPossible'=>true)) . '' ; // fld_yorno1_zztests
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_visited_countries_zztests_70_39').'">';
   require_once($GLOBALS['glob_dataPath1'].'/generated/_params/country.php');
   $lsttbl.=displayParam1('country',$mpsr6[2],array('set'=>true)); // fld_visited_countries_zztests
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_title32_zztests_99_39').'">';
   $lsttbl.=''.enti1($mpsr6[3]).''; // fld_title32_zztests
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_id_parent_zztests_28_152').'" style="text-align:center;">';
   $lsttbl.=''.enti1($mpsr6[4]).''; // fld_id_parent_zztests
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_date1_zztests_111_39').'"  style="text-align:center;">';
   $lsttbl.=''.enti1($mpsr6[5]).''; // fld_date1_zztests
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_time1_zztests_119_39').'" style="text-align:center;">';
   $lsttbl.=''.enti1($mpsr6[6]).''; // fld_time1_zztests
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_dttim1_zztests_127_39').'"  style="text-align:center;">';
   $lsttbl.=''.enti1($mpsr6[7]).''; // fld_dttim1_zztests
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_color1_zztests_137_39').'">';
   if($mpsr6[8]==''){
    $lsttbl.=''.enti1($mpsr6[8]).''; // fld_color1_zztests
   }else{
    $val=json_decode($mpsr6[8],true);
    $lsttbl.='<div style="display:inline-block;width:35px;height:20px;border:1px #eee outset;background-color:#'.$val['hexValue'].'"></div>'; // fld_color1_zztests
    $lsttbl.=''.enti1($val['hexValue']).''; // fld_color1_zztests
    if(isset($val['webName']) && $val['webName']!=''){
     $lsttbl.='<br />'.enti1($val['webName']).''; // fld_color1_zztests
    }
    if(isset($val['pantoneName']) && $val['pantoneName']!=''){
     $lsttbl.='<br /> pantone:'.enti1($val['pantoneName']).''; // fld_color1_zztests
    }
   }
   $lsttbl.='</td>';

   $lsttbl.='<td data-label="'.txt2('fld_country1_zztests_368_24').'" style="text-align:center;">';
   require_once($GLOBALS['glob_dataPath1'].'/generated/_params/country.php');
   $lsttbl.=displayParam1('country',$mpsr6[9],array('unsetPossible'=>true)); // fld_country1_zztests
   $lsttbl.='</td>';
   
   $lsttbl.='</tr>';
   
  }
  $o1.='<table class="tableResult1">'.CRLF.$lsttbl.'</tbody></table>'.CRLF;
   
  $o1.=' <div>'.CRLF;
  $o1.='   '.$le.' '.$ri.' page '.($__xpage+1).'/'.ceil($__count/$__nbMax).' ('.$__count.' '.txt2('number_of_records_391_99').' )'.CRLF;
  $o1.='   &nbsp;<a class="buttonAdd btn btn-sm btn-primary" href="zz_zztests_action1.php?a=c">'.txt2('add_a_new_record_242_54').'</a>'.CRLF;
  $o1.=' </div>'.CRLF;
   
 }
 mysqli_free_result($result6);
}else{
 $o1.=debugSql1(array('sqler' => mysqli_error($GLOBALS['glob_db'][0]['link']),'reque' => $req6)); 
}
$o1.=htmlFoot0(array());
dw1($o1);
cleanSession1();
