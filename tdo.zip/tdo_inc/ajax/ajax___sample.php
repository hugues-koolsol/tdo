<?php
// do not forget to put this file in the file list !
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
// if($fd=fopen('toto.txt','a')){fwrite($fd,''.date('Y-m-d H:i:s'). ' ' . __LINE__ ."\r\n".'$ret='.var_export($ret,true)."\r\n"); fclose($fd);}
/*
  $ret=array (
    'status' => 'KO',
    'message' => 
    array (
    ),
    'input' => 
    array (
      'funct' => 'thisfilename',
      'param1' => 'hello',
      'param2' => 'world',
    ),
  )

*/
 openDb1();
 $err=0;
 $ret['status']='OK';
 $ret['message'][]='hello' . BNF;    
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;   
}