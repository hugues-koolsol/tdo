<?php
$GLOBALS['glob__availableLanguages']=array (
  'fr' => 
  array (
    'language_code' => 'fr',
    'n' => 'Français',
    'badge' => 'badge1',
    'rule' => '0',
    'fld_id_parvals' => '1',
    '__order' => 0,
  ),
  'en' => 
  array (
    'language_code' => 'en',
    'n' => 'English',
    'badge' => 'badge0',
    'rule' => '0',
    'fld_id_parvals' => '2',
    '__order' => 1,
  ),
);