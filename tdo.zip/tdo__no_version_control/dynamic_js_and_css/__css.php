<?php
$__css=array (
  1 => 
  array (
    'fld_id_css' => '1',
    'fld_name_css' => 'production',
    'fld_active_css' => '1',
    'main' => 
    array (
      'mainBackgroundColor' => 
      array (
        'hexValue' => 'FFFDE7',
      ),
      'mainBackgroundColEnd' => 
      array (
        'hexValue' => 'FFF59D',
      ),
      'mainTextColor' => 
      array (
        'hexValue' => '8E1818',
      ),
    ),
    'fld_tsupd_css' => '2019-05-16-12_12_40',
    'fld_tscrt_css' => '2019-03-13 15:26:56',
  ),
  2 => 
  array (
    'fld_id_css' => '2',
    'fld_name_css' => 'développement',
    'fld_active_css' => '1',
    'main' => 
    array (
      'mainBackgroundColor' => 
      array (
        'hexValue' => 'ECEFF1',
      ),
      'mainBackgroundColEnd' => 
      array (
        'hexValue' => 'DBDBDB',
      ),
      'mainTextColor' => 
      array (
        'hexValue' => '555555',
      ),
    ),
    'fld_tsupd_css' => '2019-05-16-12_13_03',
    'fld_tscrt_css' => '2017-11-17 15:39:34',
  ),
  3 => 
  array (
    'fld_id_css' => '3',
    'fld_name_css' => 'préproduction',
    'fld_active_css' => '1',
    'main' => 
    array (
      'mainBackgroundColor' => 
      array (
        'hexValue' => 'D3ECFF',
      ),
      'mainBackgroundColEnd' => 
      array (
        'hexValue' => 'BAE2FF',
      ),
      'mainTextColor' => 
      array (
        'hexValue' => '0D47A1',
      ),
    ),
    'fld_tsupd_css' => '2019-05-16-12_13_20',
    'fld_tscrt_css' => '2019-03-13 15:49:20',
  ),
  4 => 
  array (
    'fld_id_css' => '4',
    'fld_name_css' => 'rouge',
    'fld_active_css' => '1',
    'main' => 
    array (
      'mainBackgroundColor' => 
      array (
        'hexValue' => 'FFF4F6',
      ),
      'mainBackgroundColEnd' => 
      array (
        'hexValue' => 'FFE0E4',
      ),
      'mainTextColor' => 
      array (
        'hexValue' => '5B0404',
      ),
    ),
    'fld_tsupd_css' => '2019-05-16-12_13_26',
    'fld_tscrt_css' => '2019-03-13 17:42:26',
  ),
  5 => 
  array (
    'fld_id_css' => '5',
    'fld_name_css' => 'green',
    'fld_active_css' => '1',
    'main' => 
    array (
      'mainBackgroundColor' => 
      array (
        'hexValue' => 'E8F5E9',
      ),
      'mainBackgroundColEnd' => 
      array (
        'hexValue' => 'BFFCC6',
      ),
      'mainTextColor' => 
      array (
        'hexValue' => '1B5E20',
      ),
    ),
    'fld_tsupd_css' => '2019-05-16-12_13_29',
    'fld_tscrt_css' => '2019-03-14 22:40:59',
  ),
  6 => 
  array (
    'fld_id_css' => '6',
    'fld_name_css' => 'material Blue grey',
    'fld_active_css' => '1',
    'main' => 
    array (
      'mainBackgroundColor' => 
      array (
        'hexValue' => 'ECEFF1',
      ),
      'mainBackgroundColEnd' => 
      array (
        'hexValue' => 'DBDEE0',
      ),
      'mainTextColor' => 
      array (
        'hexValue' => '263238',
      ),
    ),
    'fld_tsupd_css' => '2019-05-16-12_13_33',
    'fld_tscrt_css' => '2019-03-17 16:40:49',
  ),
  7 => 
  array (
    'fld_id_css' => '7',
    'fld_name_css' => 'material Blue grey sombre',
    'fld_active_css' => '1',
    'main' => 
    array (
      'mainBackgroundColor' => 
      array (
        'hexValue' => '34444C',
      ),
      'mainBackgroundColEnd' => 
      array (
        'hexValue' => '111111',
      ),
      'mainTextColor' => 
      array (
        'hexValue' => 'B0BEC5',
      ),
    ),
    'fld_tsupd_css' => '2019-05-16-16_09_21',
    'fld_tscrt_css' => '2019-03-17 16:59:06',
  ),
);