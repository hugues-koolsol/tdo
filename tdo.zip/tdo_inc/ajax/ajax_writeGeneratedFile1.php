<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages()){
// if($fd=fopen('toto.txt','a')){fwrite($fd,''.date('Y-m-d H:i:s'). ' ' . __LINE__ ."\r\n".'$ret='.var_export($ret,true)."\r\n"); fclose($fd);}
/*
$ret=array (
  'status' => 'KO',
  'message' => 
  array (
  ),
  'input' => 
  array (
    'funct' => 'writeGeneratedFile1',
    'type' => 'inc',
    'file_name' => 'zz_inc_tablelinks1.php',
  ),
)
*/
 openDb2();
 $err=0;
 if($ret['input']['type']=='inc'){
  $path=$GLOBALS['glob_incPath1'].'/'.$ret['input']['file_name'];
 }else{
  $path=$ret['input']['file_name'];  
 }
 if(!is_file($path)){
  $ret['status']='OK';
  $ret['alreadyExist']=false;
  $ret['message']='file does not exists yet';    
 }else{
  $ret['status']='OK';
  $ret['alreadyExist']=true;
  $ret['message']='file exists already';    
 }
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;   
}