<?php
if(session_status()==PHP_SESSION_NONE){
 session_start();
}
if(true===checkGroupAjaxPages() || $_SESSION[PGMK]['translate']==1  || isset($_SESSION[PGMK]['__i18n_languages']) ){
  openDb1();
  $filesArray=scandir( 'js' ,SCANDIR_SORT_ASCENDING);
  $filesArray2=array();
  foreach($filesArray as $k1=>$v1){
   if($v1=='.'||$v1=='..'||substr($v1,0,1)=='_'){
    unset($filesArray[$k1]);
   }else{
    $filesArray2[]=array('fileName'=>$v1);
   }
  }
  foreach($filesArray2 as $k1=>$v1){
   $filesArray2[$k1]['content']=file('js/'.$v1['fileName']);
  }
//  echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $filesArray2 , true ) . '</pre>' ; exit(0);
  
  $output=array();
  $ret['suggestionValues']=array();
  $clesDejaTraitees=array();
  $listOfTypes=array('txt1','txt2');
  foreach($listOfTypes as $k0 => $v0){
   foreach($filesArray2 as $k2=>$v2){
    foreach($v2['content'] as $k1 => $v1){
     $start=0;
     $buff='';
     $countWhile=20; // 20 mots max par ligne !
     $pos=strpos($v1,$v0.'(\'',$start);
     while($pos!==false && $countWhile>0){
      for($i=$pos+6;$i<strlen($v1);$i++){
       $c=substr($v1,$i,1);
       $key=str_replace('\\\'','\'',$buff);
       if($c=='\'' && !( substr($v1,$i-1,1)=='\\' && substr($v1,$i-2,1)!='\\') ){
        if(!in_array( $key , $clesDejaTraitees ) ){
         $doIt=true;
         if(($v0=='txt1' && (!$GLOBALS['glob_isLocalHost']))){
          $doIt=false;// on ne change pas un source en prod, seulement les valeurs traduites
         }
         if($_SESSION[PGMK]['login']!=1){ // de même si on n'est pas root...
          if(($v0=='txt1' && ($GLOBALS['glob_isLocalHost']))){
           $doIt=false;// ... on ne change pas un source en prod, seulement les valeurs traduites
          }
         }
         if(!isset($_SESSION[PGMK]['login'])){ // si on est pas connecté, on n'a pas le droit de modifier une traduction
          $doIt=false;
         }
         if($doIt){
          $output[]=array(
           'fileName'   => 'js/'.$v2['fileName'],
           'lineNumber' => $k1,
           'colNumber'  => $col,
           'line'       => $v1,
           'key'        => $key,
           'type'       => $v0,
          );
          if($v0=='txt2'){
           $checkDb[]=array(
           'key'        => $key,
           );
          }
         }
        }
        $pos=strpos($v1,$v0.'(\'',$i);
        $buff='';
        array_push( $clesDejaTraitees , $key );
        break;
       }else{
        if($buff==''){
         $col=$i;
        }
        $buff.=$c;
       }
      }
      $countWhile--;
     }
    }    
   }
  }
  $listeDesCles='';
  
  foreach($checkDb as $k1=>$v1){
   foreach($GLOBALS['glob__availableLanguages'] as $k0 => $v0){
    $req6='
     SELECT T0.`fld_id_lngVals`  
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0 
     WHERE T0.`fld_type_lngVals` = \'javascript\'
       AND T0.`fld_key_lngVals`  = \''.addslashes($v1['key']).'\'
       AND T0.`fld_lang_lngVals` = \''.addslashes($k0).'\'
    ';
    $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
    $founded=false;
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
     while($mpsr6=mysqli_fetch_row($result6)){
      $founded=true;
     }
     mysqli_free_result($result6);
     if(!$founded){
      $req7='
       INSERT INTO `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` SET
         `fld_key_lngVals`     = \''.addslashes($v1['key']).'\'
       , `fld_lang_lngVals`    = \''.addslashes($k0).'\'
       , `fld_type_lngVals`    = \'javascript\'
       , `fld_value_lngVals`   = \''.addslashes($v1['key']).'\'
      ';
      $result7=mysqli_query($GLOBALS['glob_db'][0]['link'],$req7);
     }
    }
   }
  }
  
  
  foreach($output as $k1 => $v1){
   if($v1['type']=='txt2'){
    $listeDesCles.=''.var_export($v1['key'],true).',';
   }
  }
  //echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . var_export( $listeDesCles , true ) . '</pre>' ; exit(0);
  $ret['translateValues']=array();
  if($listeDesCles!=''){
   $listeDesCles=substr($listeDesCles,0,-1);
   if(isset($ret['input']['typeJs']) && $ret['input']['typeJs'] == true ){
    $req6='
     SELECT T0.`fld_lang_lngVals`  , T0.`fld_value_lngVals` , T0.`fld_key_lngVals`
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0 
     WHERE T0.`fld_type_lngVals` = \'javascript\'
       AND T0.`fld_key_lngVals` IN ('.$listeDesCles.')
    ';
   }else{
    $req6='
     SELECT T0.`fld_lang_lngVals`  , T0.`fld_value_lngVals` , T0.`fld_key_lngVals`
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0 
     WHERE T0.`fld_page_id_lngVals` = ' . $ret['input']['page_id'] . '
       AND T0.`fld_key_lngVals` IN ('.$listeDesCles.')
    ';
   }
//   echo __FILE__ . ' ' . __LINE__ . ' __LINE__ = <pre>' . $req6 . '</pre>' ; exit(0);
   $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
   if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
    while($mpsr6=mysqli_fetch_row($result6)){
     $ret['translateValues'][$mpsr6[2]][$mpsr6[0]]=array(
      'lang'  => $mpsr6[0],
      'value' => $mpsr6[1],
      'key'   => $mpsr6[2],
     );
    }
    mysqli_free_result($result6);
   }else{
    $ret['message']='mysqli_error() "'.mysqli_error($GLOBALS['glob_db'][0]['link']).'" , $req6='.$req6;
   }
   
  }
  if(sizeof($ret['translateValues'])==0){
   $ret['translateValues']=null;
  }
  foreach($output as $k1 => $v1){
   $keyToSearch=$v1['key'];
   if(strpos($v1['key'],'.')!==false){
    $keyToSearch=substr($v1['key'],strpos($v1['key'],'.')+1);
   }
   $pattern="/^(.*)_([0-9]*)_([0-9]*)$/";
   if(preg_match($pattern,$keyToSearch,$matches)){
    if(sizeof($matches)>1){
     $keyToSearch=$matches[1];
     if(strpos($keyToSearch,' ')!==false){
      $keyToSearch=substr($keyToSearch,0,strpos($keyToSearch,' '));
      if(strlen($keyToSearch)<5){
       $keyToSearch='';
      }
     }else{
      if(strlen($keyToSearch)<5){
       $keyToSearch='';
      }      
     }
    }
   }
   if($keyToSearch!=''){
    $req6='
     SELECT T0.`fld_lang_lngVals`  , T0.`fld_value_lngVals` , T0.`fld_key_lngVals`
     FROM `'.$GLOBALS['glob_db'][0]['dbname'].'`.`tdo_tbl__langvalues` T0 
     WHERE T0.`fld_key_lngVals` LIKE \'%'.$keyToSearch.'%\'
       AND T0.`fld_lang_lngVals` = \''.$ret['input']['currentLanguage'].'\'
     ORDER BY 	fld_tsupd_lngVals DESC
     LIMIT 1
    ';
    $result6=mysqli_query($GLOBALS['glob_db'][0]['link'],$req6);
    if(mysqli_errno($GLOBALS['glob_db'][0]['link'])==0){
     while($mpsr6=mysqli_fetch_row($result6)){
      $ret['suggestionValues'][]=array(
       'lang'  => $mpsr6[0],
       'value' => $mpsr6[1],
       'key'   => $v1['key'],
      );
     }
     mysqli_free_result($result6);
    }else{
     $ret['message']='mysqli_error() "'.mysqli_error($GLOBALS['glob_db'][0]['link']).'" , $req6='.$req6;
    }
   }
  }
  $ret['output']=$output;
  $ret['status']='OK';
}else{
 $ret['status']='KO';
 $ret['message']='NOT authorised on ' . BNF;  
}